Vehicle188 whole-region saved evidence

One previously outcome-selected public case; complete within-case enumeration.
Original strict W=K: 8,064 states. Released helper=false W: 6,656 states.
Loss: 1,408. Gain: 0. Helper=true slice: all 33,792 source states; that slice
is not legally initialized because the released initializer requires !helper.
Every lost state occurs after one legal transition under some initialized
cooperative winning policy. The policy and compatible play may depend on the
target. No frequency, deployment, forced reachability or common-policy claim.

Python 3.9+ standard library, macOS/Linux (no network, Java or native solver):
  python3 -I -S -B replay.py --bundle . --out ../whole-region-replay
The output directory must be new and outside this immutable package. Expected:
  PASS_WHOLE_REGION_DUAL_REPLAY
The command verifies all file hashes, runs the producer and independently
written raw-DAG checker, reconciles all 33,792 valuations by their 12 named
values, checks five membership fields and all fixed predecessor conditions,
and compares the complete generated tables to the adopted tables. It checks
source/BDD predicate identity and the initializer fibers. It evaluates saved
native W; it does not independently recompute a winning fixed point.

Read records/ROOT_ADOPTION.json for the adopted quantifiers and limitations,
records/producer/PROOF_AND_SCOPE.txt for the proof, and
records/independent_audit/INDEPENDENT_AUDIT_REPORT_JA.txt for its independent
audit. Historical status/deadline fields remain as originally recorded; the
later ROOT_ADOPTION governs the adopted conclusion and replay has a fresh cap.

Native source, typed models and all copied BDDs are byte-identical to the prior
vehicle188-native-evidence-20261024-v1 snapshot. Exact archive/member bindings
are in PRIOR_NATIVE_SNAPSHOT_BINDINGS.json. That prior snapshot is unchanged.
TRANSFORMATIONS.json records anonymous historical-preimage bindings, exact
mathematical-body extractions and the two independent-checker I/O edits.
MANIFEST.json binds actual package bytes. origin:* values are provenance IDs,
not missing files to locate or execute. The source_checker_sha256 fields identify the private adopted checkers; their selected mathematical bodies are
publicly present and pinned in the transformations record.

The source is the unchanged 3,924-byte AutonomousVehicle_sprint02_ver1.spectra
from Zenodo 10553249, icse24_artifact.zip member
artifact/experiments/specs/syn20/AutonomousVehicle_sprint02_ver1.spectra.
See THIRD_PARTY_NOTICES.txt and the included original BSD 3-Clause licenses.
No runtime binary, manuscript, publisher PDF, review or personal path is included.

This saved-evidence package preserves shared native-solver/exporter/typed-map
trust dependencies. Dual replay is not external replication or a new native run.
