import java.io.*;
import java.nio.file.*;
import java.util.*;
import com.google.gson.*;
import net.sf.javabdd.*;
import org.apache.log4j.Logger;
import tau.smlab.syntech.spectragameinput.SpectraInputProviderNoIDE;
import tau.smlab.syntech.gameinput.model.*;
import tau.smlab.syntech.gameinput.kind.PitermanSyntacticReduction;
import tau.smlab.syntech.gameinputtrans.TranslationProvider;
import tau.smlab.syntech.gameinputtrans.translator.DefaultTranslators;
import tau.smlab.syntech.bddgenerator.BDDGenerator;
import tau.smlab.syntech.bddgenerator.BDDGenerator.TraceInfo;
import tau.smlab.syntech.gamemodel.*;
import tau.smlab.syntech.jtlv.*;

/** One fixed retained-boundary wrapper, one parsed/translated model, no solver.
 * Compare every non-initial predicate with the prior certified full helper model,
 * explicitly compare all four helper quadrants and ordered justice predicates,
 * and bind the new nonempty singleton initialization separately.
 * This does not compute a winning region or simulate an extracted controller.
 */
public final class RetainedBoundaryExportOnly {
  static final String H="~envHelp";
  static void need(boolean b,String message){ReleasedKindJobProducer.require(b,message);}
  static JsonObject read(Path p)throws Exception{return JsonParser.parseString(Files.readString(p)).getAsJsonObject();}
  static JsonObject object(Object x){return JsonParser.parseString(ReleasedKindJobProducer.json(x)).getAsJsonObject();}
  static Path pinned(JsonObject pin)throws Exception{
    Path p=Paths.get(pin.get("path").getAsString());byte[] bytes=Files.readAllBytes(p);
    need(bytes.length==pin.get("bytes").getAsInt()&&ReleasedKindJobProducer.sha(bytes).equals(pin.get("sha256").getAsString()),"Frozen input pin: "+p.getFileName());return p;
  }
  static Map<String,JsonObject> fields(JsonObject m){
    Map<String,JsonObject> out=new LinkedHashMap<>();
    for(JsonElement e:m.getAsJsonArray("fields")){JsonObject f=e.getAsJsonObject();need(out.put(f.get("name").getAsString(),f)==null,"Unique field names");}
    return out;
  }
  static int integer(JsonElement e){return e.getAsInt();}
  static void validateFieldMetadata(JsonObject m){
    Set<Integer> all=new HashSet<>(),curr=new HashSet<>(),next=new HashSet<>();int n=m.get("bdd_variable_count").getAsInt();
    JsonArray order=m.getAsJsonArray("bdd_variable_order");need(order.size()==n,"Complete variable order");for(int i=0;i<n;i++)need(order.get(i).getAsInt()==i,"Natural variable order");
    for(JsonObject field:fields(m).values()){
      String owner=field.get("owner").getAsString(),role=field.get("role").getAsString();need((owner.equals("ENV")&&role.equals("ENV"))||(owner.equals("SYS")&&(role.equals("SYS")||role.equals("AUX"))),"Exact declared ownership/role");
      JsonArray values=field.getAsJsonArray("values");Set<String> names=new LinkedHashSet<>();for(JsonElement v:values)need(names.add(v.getAsString()),"Distinct field values");need(values.size()==field.get("domain_size").getAsInt(),"Complete value domain");
      need(field.getAsJsonObject("encoding").keySet().equals(names),"Every and only declared value encoded");
      List<String> codesCurrent=new ArrayList<>(),codesNext=new ArrayList<>();
      for(String phase:new String[]{"current","next"}){
        Set<String> keys=new LinkedHashSet<>();for(JsonElement e:field.getAsJsonArray(phase+"_bits")){int bit=e.getAsInt();need(bit>=0&&bit<n&&all.add(bit),"Each field bit has exactly one owner/phase");keys.add(String.valueOf(bit));(phase.equals("current")?curr:next).add(bit);}
        Set<String> codes=new HashSet<>();
        for(JsonElement value:values){JsonObject enc=field.getAsJsonObject("encoding").getAsJsonObject(value.getAsString()).getAsJsonObject(phase);need(enc.keySet().equals(keys),"Encoding covers exactly field bits");StringBuilder code=new StringBuilder();
          for(JsonElement bit:field.getAsJsonArray(phase+"_bits")){JsonElement v=enc.get(String.valueOf(bit.getAsInt()));need(v.isJsonPrimitive()&&v.getAsJsonPrimitive().isBoolean(),"Boolean encoding literal");code.append(v.getAsBoolean()?'1':'0');}
          need(codes.add(code.toString()),"Injective value encoding");(phase.equals("current")?codesCurrent:codesNext).add(code.toString());
        }
      }
      need(codesCurrent.equals(codesNext),"Current/next value codes agree");
    }
    need(all.size()==n,"All BDD bits covered");for(int i=0;i<n;i++)need(all.contains(i),"No undeclared bit");
    Set<Integer> declaredCurrent=new HashSet<>(),declaredNext=new HashSet<>();for(JsonElement x:m.getAsJsonArray("all_current_bits"))need(declaredCurrent.add(x.getAsInt()),"Distinct declared current bits");for(JsonElement x:m.getAsJsonArray("all_next_bits"))need(declaredNext.add(x.getAsInt()),"Distinct declared next bits");need(curr.equals(declaredCurrent)&&next.equals(declaredNext),"Declared field bit unions exact");
  }

  /** Maps all source bits by exact field name and value encoding, including AUX.
   * No name heuristics, changed monitor rosters, or partial field projection.
   */
  static Map<Integer,Integer> fieldMap(JsonObject old,JsonObject fresh,boolean helper){
    validateFieldMetadata(old);validateFieldMetadata(fresh);
    Map<String,JsonObject>a=fields(old),b=fields(fresh);
    if(helper)need(!a.containsKey(H),"Source model has no helper before extension");
    Set<String> expected=new LinkedHashSet<>(a.keySet());if(helper)expected.add(H);
    need(b.keySet().equals(expected),"Exactly source fields plus actual helper; AUX names preserved");
    if(helper){JsonObject h=b.get(H);need(h.get("owner").getAsString().equals("ENV")&&h.get("role").getAsString().equals("ENV"),"Helper ENV ownership");need(h.get("domain_size").getAsInt()==2&&h.getAsJsonArray("values").toString().equals("[\"false\",\"true\"]"),"Boolean helper domain");for(String phase:new String[]{"current","next"}){need(h.getAsJsonArray(phase+"_bits").size()==1,"One bit per helper phase");String bit=h.getAsJsonArray(phase+"_bits").get(0).getAsString();need(!h.getAsJsonObject("encoding").getAsJsonObject("false").getAsJsonObject(phase).get(bit).getAsBoolean()&&h.getAsJsonObject("encoding").getAsJsonObject("true").getAsJsonObject(phase).get(bit).getAsBoolean(),"Helper false/true codes 0/1");}}
    Map<Integer,Integer> map=new LinkedHashMap<>();Set<Integer> targets=new HashSet<>();
    for(String name:a.keySet()){
      JsonObject x=a.get(name),y=b.get(name);
      for(String k:new String[]{"owner","role","domain_size","values"})need(x.get(k).equals(y.get(k)),"Field metadata "+name+"/"+k);
      for(String phase:new String[]{"current","next"}){
        JsonArray xb=x.getAsJsonArray(phase+"_bits"),yb=y.getAsJsonArray(phase+"_bits");need(xb.size()==yb.size(),"Field bit width "+name);
        for(int j=0;j<xb.size();j++){
          int u=integer(xb.get(j)),v=integer(yb.get(j));need(map.put(u,v)==null&&targets.add(v),"Full injective bit map");
          for(JsonElement value:x.getAsJsonArray("values")){
            String val=value.getAsString();JsonObject xe=x.getAsJsonObject("encoding").getAsJsonObject(val).getAsJsonObject(phase),ye=y.getAsJsonObject("encoding").getAsJsonObject(val).getAsJsonObject(phase);
            need(xe.get(String.valueOf(u)).equals(ye.get(String.valueOf(v))),"Value encoding "+name+"/"+val+"/"+phase);
          }
        }
      }
    }
    need(map.size()==old.get("bdd_variable_count").getAsInt(),"Every old bit mapped");
    for(int i=0;i<map.size();i++)need(map.containsKey(i),"No unmapped old bit");
    need(fresh.get("bdd_variable_count").getAsInt()==map.size()+(helper?2:0),"No undeclared fresh bits");
    ReleasedKindJobProducer.out.put(helper?"source_to_actual_bit_map":"prior_helper_to_actual_bit_map",map);return map;
  }

  /** Read the prior pinned node-table into the current manager under a bit map.
   * ITE permits non-monotone renaming; raw node IDs are never reused as functions.
   */
  static BDD mapped(JsonObject ref,Path directory,Map<Integer,Integer> map,BDDFactory f)throws Exception{
    Path p=directory.resolve(ref.get("file").getAsString());byte[] data=Files.readAllBytes(p);
    need(data.length==ref.get("bytes").getAsLong()&&ReleasedKindJobProducer.sha(data).equals(ref.get("sha256").getAsString()),"Saved predicate hash "+p.getFileName());
    List<int[]> lines=new ArrayList<>();
    for(String line:new String(data,java.nio.charset.StandardCharsets.US_ASCII).split("\\R"))if(!line.trim().isEmpty())lines.add(Arrays.stream(line.trim().split("\\s+")).mapToInt(Integer::parseInt).toArray());
    if(lines.size()==1){int[]c=lines.get(0);need(c.length==2&&c[0]==0&&(c[1]==0||c[1]==1)&&ref.get("node_count").getAsInt()==0,"Saved constant syntax");return c[1]==0?f.zero():f.one();}
    need(lines.size()>=3&&lines.get(0).length==1&&lines.get(0)[0]==map.size(),"Saved BDD variable count");
    int[]order=lines.get(1);need(order.length==map.size(),"Saved BDD order width");for(int i=0;i<order.length;i++)need(order[i]==i,"Saved natural order");
    need(lines.size()-2==ref.get("node_count").getAsInt(),"Saved BDD node count");
    Map<Integer,BDD> nodes=new LinkedHashMap<>();nodes.put(0,f.zero());nodes.put(1,f.one());int last=-1;
    try{
      for(int k=2;k<lines.size();k++){
        int[]r=lines.get(k);need(r.length==4&&r[0]>1&&!nodes.containsKey(r[0])&&map.containsKey(r[1])&&nodes.containsKey(r[2])&&nodes.containsKey(r[3]),"Saved node table topology");
        BDD bit=f.ithVar(map.get(r[1]));BDD n=bit.ite(nodes.get(r[3]),nodes.get(r[2]));bit.free();nodes.put(r[0],n);last=r[0];
      }
      need(last>1,"Saved root exists");return nodes.get(last).id();
    }finally{for(BDD b:nodes.values())b.free();}
  }


  static JsonElement withoutTraceIds(JsonElement x){
    if(x.isJsonObject()){
      JsonObject r=new JsonObject();for(Map.Entry<String,JsonElement>e:x.getAsJsonObject().entrySet())
        if(!e.getKey().equals("trace_id"))r.add(e.getKey(),withoutTraceIds(e.getValue()));return r;
    }
    if(x.isJsonArray()){JsonArray r=new JsonArray();for(JsonElement y:x.getAsJsonArray())r.add(withoutTraceIds(y));return r;}
    return x.deepCopy();
  }
  static JsonObject noninitialInventory(JsonObject inventory,boolean wrapper){
    JsonObject out=new JsonObject();
    for(String owner:new String[]{"ENV","SYS","AUX"}){
      JsonObject p=inventory.getAsJsonObject(owner),r=new JsonObject();
      r.add("variables",withoutTraceIds(p.get("variables")));
      need(p.getAsJsonArray("patterns").size()==0&&p.getAsJsonArray("triggers").size()==0&&p.get("existential_count").getAsInt()==0,"No patterns/triggers/existential constraints");
      JsonArray constraints=new JsonArray();int initial=0;
      for(JsonElement e:p.getAsJsonArray("constraints")){
        JsonObject c=e.getAsJsonObject();
        if(c.get("kind").getAsString().equals("INI")){
          initial++;need(wrapper&&!owner.equals("AUX"),"Only wrapper adds source initializers");
          String expected=owner.equals("ENV")?"retainedBoundaryEnv":"retainedBoundarySys";
          need(c.get("name").getAsString().equals(expected),"Exact wrapper initializer name");
        }else{
          JsonObject n=new JsonObject();for(String k:new String[]{"name","kind","spec_ast"})n.add(k,withoutTraceIds(c.get(k)));constraints.add(n);
        }
      }
      need(initial==(wrapper&&!owner.equals("AUX")?1:0),"Exactly one wrapper INI for each original owner");
      r.add("noninitial_constraints",constraints);out.add(owner,r);
    }
    return out;
  }
  static void equal(String label,BDD actual,BDD expected,BDD typedMask)throws Exception{
    boolean raw=actual.equals(expected);BDD a=actual.and(typedMask),b=expected.and(typedMask);boolean typed=a.equals(b);a.free();b.free();
    ReleasedKindJobProducer.out.put(label,ReleasedKindJobProducer.m("raw_boolean_equal",raw,"typed_equal",typed,"actual_nodes",actual.nodeCount(),"expected_nodes",expected.nodeCount()));
    need(raw&&typed,"Non-initial correspondence: "+label);
  }
  static BDD helperCube(int h,int hp){
    BDD current=Env.getBDDValue(H,h==0?"false":"true").id(),next=Env.prime(Env.getBDDValue(H,hp==0?"false":"true"));return current.andWith(next);
  }
  static void compareSaved(String label,BDD actual,JsonObject ref,Path dir,Map<Integer,Integer> map,BDD typedMask)throws Exception{
    BDD expected=mapped(ref,dir,map,actual.getFactory());try{equal(label,actual,expected,typedMask);}finally{expected.free();}
  }
  static void compareNoninitial(GameModel gm,JsonObject prior,JsonObject source,JsonObject fresh,Path priorDir,Path sourceDir)throws Exception{
    Map<Integer,Integer> fullMap=fieldMap(prior,fresh,false),sourceMap=fieldMap(source,fresh,true);
    BDD typed=ReleasedKindJobProducer.domain(gm.getEnv(),false).andWith(ReleasedKindJobProducer.domain(gm.getSys(),false));
    BDD edge=typed.id();edge.andWith(ReleasedKindJobProducer.domain(gm.getEnv(),true));edge.andWith(ReleasedKindJobProducer.domain(gm.getSys(),true));
    JsonObject previous=prior.getAsJsonObject("original_bdds"),original=source.getAsJsonObject("original_bdds");
    BDD h0=Env.getBDDValue(H,"false").id(),h00=helperCube(0,0);
    try{
      compareSaved("full_rhoE",gm.getEnv().trans(),previous.getAsJsonObject("rhoE"),priorDir,fullMap,edge);
      compareSaved("full_rhoS",gm.getSys().trans(),previous.getAsJsonObject("rhoS"),priorDir,fullMap,edge);
      for(String key:new String[]{"domain","domain_ENV_next","domain_SYS_next"}){
        BDD actual=key.equals("domain")?typed.id():ReleasedKindJobProducer.domain(key.equals("domain_ENV_next")?gm.getEnv():gm.getSys(),true);
        BDD all=Env.TRUE();try{compareSaved("full_"+key,actual,previous.getAsJsonObject(key),priorDir,fullMap,all);}finally{actual.free();all.free();}
      }
      BDD priorE=mapped(previous.getAsJsonObject("rhoE"),priorDir,fullMap,typed.getFactory());
      BDD priorS=mapped(previous.getAsJsonObject("rhoS"),priorDir,fullMap,typed.getFactory());
      Map<String,Object> quadrants=new LinkedHashMap<>();
      try{
        for(int h=0;h<2;h++)for(int hp=0;hp<2;hp++){
          String q=""+h+hp;BDD cube=helperCube(h,hp),mask=edge.restrict(cube);
          BDD ae=gm.getEnv().trans().restrict(cube),as=gm.getSys().trans().restrict(cube),be=priorE.restrict(cube),bs=priorS.restrict(cube);
          equal("quadrant_"+q+"_rhoE",ae,be,mask);equal("quadrant_"+q+"_rhoS",as,bs,mask);
          quadrants.put(q,ReleasedKindJobProducer.m("rhoE",ReleasedKindJobProducer.snapshot("quadrant_"+q+"_rhoE",ae),"rhoS",ReleasedKindJobProducer.snapshot("quadrant_"+q+"_rhoS",as)));
          ae.free();as.free();be.free();bs.free();cube.free();mask.free();
        }
      }finally{priorE.free();priorS.free();}
      ReleasedKindJobProducer.out.put("helper_quadrants",quadrants);
      JsonObject justices=prior.getAsJsonObject("original_justices"),sj=source.getAsJsonObject("original_justices");
      need(sj.getAsJsonArray("ENV").size()==0&&sj.getAsJsonArray("SYS").size()==2,"Frozen source justice roster");
      for(String owner:new String[]{"ENV","SYS"}){
        PlayerModule pm=owner.equals("ENV")?gm.getEnv():gm.getSys();JsonArray js=justices.getAsJsonArray(owner);
        need(js.size()==pm.justiceNum()&&js.size()==(owner.equals("ENV")?1:2),"Exact ordered helper justice count");
        for(int i=0;i<js.size();i++)compareSaved("ordered_"+owner+"_justice_"+i,pm.justiceAt(i),js.get(i).getAsJsonObject(),priorDir,fullMap,typed);
      }
      need(gm.getEnv().justiceAt(0).equals(h0),"Only added ENV justice is !helper");
      BDD sourceMask=typed.restrict(h0),sourceEdge=edge.restrict(h00);
      try{
        BDD ae=gm.getEnv().trans().restrict(h00),as=gm.getSys().trans().restrict(h00);
        compareSaved("source_rhoE_00",ae,original.getAsJsonObject("rhoE"),sourceDir,sourceMap,sourceEdge);
        compareSaved("source_rhoS_00",as,original.getAsJsonObject("rhoS"),sourceDir,sourceMap,sourceEdge);ae.free();as.free();
        for(int i=0;i<2;i++){BDD actual=gm.getSys().justiceAt(i).restrict(h0);compareSaved("source_SYS_justice_"+i,actual,sj.getAsJsonArray("SYS").get(i).getAsJsonObject(),sourceDir,sourceMap,sourceMask);actual.free();}
      }finally{sourceMask.free();sourceEdge.free();}
    }finally{typed.free();edge.free();h0.free();h00.free();}
  }
  static void pointInitializers(GameModel gm)throws Exception{
    BDD env=Env.getBDDValue("obstacle[0]","3").id();env.andWith(Env.getBDDValue("obstacle[1]","5").id());env.andWith(Env.getBDDValue("obsWait","true").id());env.andWith(Env.getBDDValue(H,"false").id());
    BDD sys=Env.getBDDValue("robot[0]","5").id();sys.andWith(Env.getBDDValue("robot[1]","5").id());
    BDD typed=ReleasedKindJobProducer.domain(gm.getEnv(),false).andWith(ReleasedKindJobProducer.domain(gm.getSys(),false));
    try{
      equal("point_thetaE",gm.getEnv().initial(),env,typed);equal("point_thetaS",gm.getSys().initial(),sys,typed);
      need(!env.isZero()&&!sys.isZero(),"Both point initial predicates nonempty");
      need(!Env.hasVars(gm.getEnv().initial(),gm.getSys().moduleUnprimeVars()),"ENV point initialization has no SYS dependency");
      BDD joint=gm.getEnv().initial().and(gm.getSys().initial());try{
        Object valuation=ReleasedKindJobProducer.singletonValuation(joint,gm);need(valuation!=null,"Joint point initialization has exactly one full typed valuation");
        ReleasedKindJobProducer.out.put("point_singleton",valuation);ReleasedKindJobProducer.out.put("point_joint_nonempty",!joint.isZero());
        ReleasedKindJobProducer.out.put("point_joint",ReleasedKindJobProducer.snapshot("point_joint",joint));
      }finally{joint.free();}
    }finally{env.free();sys.free();typed.free();}
  }
  public static void main(String[]args)throws Exception{
    if(args.length!=3)throw new IllegalArgumentException("fixed-config output-json origins");
    Path config=Paths.get(args[0]),out=Paths.get(args[1]),origins=Paths.get(args[2]);JsonObject c=read(config);
    need(c.get("id").getAsString().equals("B_NEW_POINT_R2404"),"Only fixed retained query");
    need(!Files.exists(out),"Fresh output only");Files.createDirectories(out.toAbsolutePath().getParent());
    Path input=pinned(c.getAsJsonObject("input")),projected=pinned(c.getAsJsonObject("projected_source"));
    Path priorFile=pinned(c.getAsJsonObject("prior_helper_model")),sourceFile=pinned(c.getAsJsonObject("prior_source_model"));
    JsonObject prior=read(priorFile),source=read(sourceFile);byte[] wrapper=Files.readAllBytes(input),prefix=Files.readAllBytes(projected);
    need(wrapper.length==2026&&prefix.length==1902&&Arrays.equals(Arrays.copyOf(wrapper,prefix.length),prefix),"Exact public projection plus frozen appendix");
    need(ReleasedKindJobProducer.sha(Arrays.copyOfRange(wrapper,prefix.length,wrapper.length)).equals("c37b91aac8d16864bcc7e6597d193a5831255222c1e54b5d36687639854e4d90"),"Exact retained-boundary appendix");
    String projectionSha=ReleasedKindJobProducer.sha(prefix);need(prior.getAsJsonObject("input").get("sha256").getAsString().equals(projectionSha)&&source.getAsJsonObject("input").get("sha256").getAsString().equals(projectionSha),"Prior models bind to same uninitialized projected source");
    ReleasedKindJobProducer.receipt=out;ReleasedKindJobProducer.fixtureId="OBSTACLE_NEW__point_r2404_export";ReleasedKindJobProducer.caseId="B_NEW_POINT_R2404";ReleasedKindJobProducer.variant="syntactic_export_only_with_explicit_point_initializers";
    ReleasedKindJobProducer.start=System.nanoTime();ReleasedKindJobProducer.startHeapSampler();
    ExactDiagnosticPrintStream capture=new ExactDiagnosticPrintStream(System.out,out.resolveSibling("EXACT_DIAGNOSTIC_RECEIPT.json"));
    Runtime.getRuntime().addShutdownHook(new Thread(()->{try{capture.finish();}catch(Exception e){e.printStackTrace(System.err);}},"retained-export-lossless-capture"));System.setOut(capture);
    Map<String,Object> r=ReleasedKindJobProducer.out;r.put("schema","v71-retained-boundary-export-and-binding-v1");r.put("status","RUNNING");r.put("id","B_NEW_POINT_R2404");
    r.put("native_strict_solver_calls",0);r.put("solver_constructions",0);r.put("raw_four_fixed_point_calls",0);r.put("controller_extraction_calls",0);r.put("winning_region_computations",0);r.put("syntactic_reduction_calls",0);r.put("semantic_reduction_calls",0);r.put("source_initializers_changed",true);r.put("initializer_scope","Explicit point-query wrapper appends one ENV and one SYS INI; original updated source has none. Old original initializers are not copied or conjoined.");r.put("source_or_monitor_reset",false);r.put("controller_memory","unrecorded/not extracted; not zero");r.put("extra_transition_restrictions",false);r.put("GUI_execution",false);r.put("provider_scope","NoIDE file URI provider; common release translator with GUI, not an observed GUI model export");
    r.put("query_class",ReleasedKindJobProducer.identity(RetainedBoundaryExportOnly.class));r.put("serializer_class",ReleasedKindJobProducer.identity(ReleasedKindJobProducer.class));r.put("capture_class",ReleasedKindJobProducer.identity(ExactDiagnosticPrintStream.class));
    Logger.getRootLogger().addAppender(new ReleasedKindJobProducer.ValidationLogWatch());GameModel gm=null;BDDFactory factory=null;int exit=0;
    try{
      ReleasedKindJobProducer.checkOrigins(origins);r.put("input_sha256",ReleasedKindJobProducer.sha(wrapper));r.put("case_config_sha256",ReleasedKindJobProducer.sha(Files.readAllBytes(config)));
      ReleasedKindJobProducer.checkpoint("PARSE_FIXED_POINT_WRAPPER");GameInput gi=new SpectraInputProviderNoIDE().getGameInput(input.toString());ReleasedKindJobProducer.validationHealthy();Object parsed=ReleasedKindJobProducer.inventory(gi);r.put("parsed_before_reduction",parsed);
      JsonObject cleaned=noninitialInventory(object(parsed),true),oldCleaned=noninitialInventory(source.getAsJsonObject("source_inventory").getAsJsonObject("parsed"),false);
      need(cleaned.equals(oldCleaned),"Parsed noninitial inventory unchanged from exact public projection");r.put("parsed_noninitial_inventory_equal_ignoring_trace_ids",true);
      need(gi.getAux().getVars().size()==0&&gi.getAux().getConstraints().size()==0,"No source monitor/AUX fields");
      Set<String> pe=new LinkedHashSet<>(Arrays.asList("obstacle[0]","obstacle[1]","obsWait",H)),ps=new LinkedHashSet<>(Arrays.asList("robot[0]","robot[1]"));
      PitermanSyntacticReduction.doReduction(gi);r.put("syntactic_reduction_calls",1);r.put("parsed_after_reduction",ReleasedKindJobProducer.inventory(gi));
      TranslationProvider.translate(gi,DefaultTranslators.getDefaultTranslators());ReleasedKindJobProducer.validationHealthy();ReleasedKindJobProducer.auditTranslated(gi);Object translated=ReleasedKindJobProducer.inventory(gi);
      BDDPackage.setCurrPackage(BDDPackage.JTLV,BDDPackage.BBDPackageVersion.DEFAULT);Env.disableReorder();BDD one=Env.TRUE();factory=one.getFactory();one.free();r.put("observed_backend",ReleasedKindJobProducer.backend());
      ReleasedKindJobProducer.checkpoint("GENERATE_WRAPPER_MODEL_ONLY");r.put("model_generations",1);gm=BDDGenerator.generateGameModel(gi,TraceInfo.NONE,false,PlayerModule.TransFuncType.SINGLE_FUNC);
      Map<String,Object> model=ReleasedKindJobProducer.modelExport(gm,pe,ps,parsed,translated,input);r.put("model_export",ReleasedKindJobProducer.writeJson("model.json",model));
      need(Env.getVar(H)!=null&&ReleasedKindJobProducer.carrierSize.intValueExact()==12544,"Exact helper-extended typed carrier");
      need(!Env.hasVars(gm.getEnv().trans(),gm.getSys().modulePrimeVars()),"ENV next-SYS independence");
      ReleasedKindJobProducer.checkpoint("COMPARE_ONLY_SAVED_NONINITIAL_PREDICATES");compareNoninitial(gm,prior,source,object(model),priorFile.getParent(),sourceFile.getParent());pointInitializers(gm);
      r.put("typed_domain_states",ReleasedKindJobProducer.carrierSize.toString());r.put("helper_introduced",true);r.put("all_noninitial_predicates_and_ordered_justices_equal",true);r.put("all_four_helper_quadrants_equal",true);r.put("point_initializer_binding_pass",true);
      r.put("interpretation","All fixed-point input predicates unchanged except explicitly separately checked point initializers. No four-fixed-point evaluation, no fresh winning region, no GUI model identity claimed.");
      ReleasedKindJobProducer.checkOrigins(origins);ReleasedKindJobProducer.validationHealthy();r.put("status","PASS_EXPORTED_AND_BOUND_NO_SOLVER");ReleasedKindJobProducer.checkpoint("BINDING_DONE_NO_SOLVER");
    }catch(Throwable e){exit=2;r.put("status","UNKNOWN_EXPORT_OR_BINDING_EXCEPTION");r.put("failed_stage",ReleasedKindJobProducer.stage);r.put("exception",e.toString());StringWriter sw=new StringWriter();e.printStackTrace(new PrintWriter(sw));r.put("traceback",sw.toString());
    }finally{
      try{if(gm!=null)gm.free();if(factory!=null)factory.done();r.put("teardown","COMPLETED");}catch(Throwable e){exit=3;r.put("status","UNKNOWN_EXPORT_TEARDOWN");r.put("teardown_exception",e.toString());}
      if(ReleasedKindJobProducer.heapSampler!=null)ReleasedKindJobProducer.heapSampler.cancel();ReleasedKindJobProducer.checkpoint("PROCESS_FINISHED");
    }
    System.exit(exit);
  }
}
