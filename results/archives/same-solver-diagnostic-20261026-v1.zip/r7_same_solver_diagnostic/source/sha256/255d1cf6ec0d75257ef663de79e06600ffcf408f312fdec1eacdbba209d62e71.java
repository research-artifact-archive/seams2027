import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

/** Ordered, reversible stdout transport. No BDD or solver dependencies. */
public final class ExactDiagnosticPrintStream extends PrintStream {
  public static final String DIAGNOSTIC = "lookup, class net.sf.javabdd.JTLVJavaFactory$BddCache";
  private final Encoder encoder;

  public ExactDiagnosticPrintStream(OutputStream target, Path receipt) throws Exception {
    this(new Encoder(target, receipt, 16L * 1024 * 1024));
  }
  public ExactDiagnosticPrintStream(OutputStream target, Path receipt, long cap) throws Exception {
    this(new Encoder(target, receipt, cap));
  }
  private ExactDiagnosticPrintStream(Encoder encoder) {
    super(encoder, true, StandardCharsets.UTF_8);
    this.encoder = encoder;
  }
  @Override public synchronized void println(String value) {
    if (DIAGNOSTIC.equals(value)) encoder.repeat();
    else super.println(value);
  }
  public synchronized void finish() throws IOException { encoder.finish(); }
  @Override public void close() { try { finish(); } catch (IOException e) { throw new UncheckedIOException(e); } }

  private static final class Encoder extends OutputStream {
    final OutputStream target;
    final Path receipt;
    final long cap;
    final byte[] line = (DIAGNOSTIC + System.lineSeparator()).getBytes(StandardCharsets.UTF_8);
    final MessageDigest digest;
    long rawBytes, encodedBytes, repeatedLines, run, records;
    boolean finished, capReached;

    Encoder(OutputStream target, Path receipt, long cap) throws Exception {
      this.target = target; this.receipt = receipt; this.cap = cap;
      this.digest = MessageDigest.getInstance("SHA-256");
      record("{\"kind\":\"dictionary\",\"id\":\"cache_lookup\",\"data\":\"" + Base64.getEncoder().encodeToString(line) + "\"}");
    }
    private void record(String text) {
      byte[] bytes = (text + "\n").getBytes(StandardCharsets.US_ASCII);
      if (encodedBytes + bytes.length > cap) {
        capReached = true;
        throw new IllegalStateException("ENCODED_STDOUT_16_MIB_CAP");
      }
      try { target.write(bytes); } catch (IOException e) { throw new UncheckedIOException(e); }
      digest.update(bytes); encodedBytes += bytes.length; records++;
    }
    private void flushRun() {
      if (run != 0) {
        record("{\"kind\":\"repeat\",\"id\":\"cache_lookup\",\"count\":" + run + "}");
        run = 0;
      }
    }
    synchronized void repeat() {
      if (finished) throw new IllegalStateException("CAPTURE_ALREADY_FINISHED");
      run = Math.addExact(run, 1); repeatedLines = Math.addExact(repeatedLines, 1);
      rawBytes = Math.addExact(rawBytes, line.length);
      if (run == 1000000) flushRun();
    }
    @Override public synchronized void write(byte[] data, int off, int len) {
      if (finished) throw new IllegalStateException("CAPTURE_ALREADY_FINISHED");
      Objects.checkFromIndexSize(off, len, data.length);
      if (len == 0) return;
      flushRun();
      for (int at = off; at < off + len;) {
        int end = Math.min(off + len, at + 65536);
        byte[] bytes = Arrays.copyOfRange(data, at, end);
        record("{\"kind\":\"bytes\",\"data\":\"" + Base64.getEncoder().encodeToString(bytes) + "\"}");
        rawBytes = Math.addExact(rawBytes, end - at); at = end;
      }
    }
    @Override public synchronized void write(int value) { write(new byte[]{(byte)value}, 0, 1); }
    @Override public synchronized void flush() throws IOException { target.flush(); }
    synchronized void finish() throws IOException {
      if (finished) return;
      String error = null;
      try {
        flushRun();
        record("{\"kind\":\"end\",\"raw_bytes\":" + rawBytes + ",\"repeated_lines\":" + repeatedLines + "}");
      } catch (RuntimeException e) { error = e.getClass().getName(); }
      target.flush(); finished = true;
      String hash = HexFormat.of().formatHex(digest.digest());
      String info = "{\"schema\":\"exact-println-dictionary-rle-v1\",\"capture_complete\":" + (error == null && !capReached)
        + ",\"raw_bytes\":" + rawBytes + ",\"raw_sha256\":null,\"encoded_bytes\":" + encodedBytes
        + ",\"encoded_sha256\":\"" + hash + "\",\"repeated_lines\":" + repeatedLines
        + ",\"unflushed_repeated_lines\":" + run + ",\"records\":" + records
        + ",\"encoded_cap_bytes\":" + cap + ",\"cap_reached\":" + capReached
        + ",\"diagnostic_line_base64\":\"" + Base64.getEncoder().encodeToString(line) + "\",\"capture_error\":"
        + (error == null ? "null" : "\"" + error + "\"") + "}";
      if (receipt != null) Files.writeString(receipt, info + "\n", StandardCharsets.US_ASCII, StandardOpenOption.CREATE_NEW);
    }
  }
}
