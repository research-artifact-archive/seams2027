"""Stdlib-only macOS process identity and RSS support; no work at import.

Structures and constants follow the installed macOS 15.5 SDK proc_info.h.
The birth-time identity design follows the earlier owned_eclipse_guard.py,
but process enumeration here uses libproc and treats normal exit races as
observations, never as fabricated return codes.
"""
from __future__ import annotations

import ctypes
import errno
import os
import signal


class BSDInfo(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint32) for name in (
        "flags", "status", "xstatus", "pid", "ppid", "uid", "gid", "ruid", "rgid",
        "svuid", "svgid", "reserved")]
    _fields_ += [("comm", ctypes.c_char * 16), ("name", ctypes.c_char * 32)]
    _fields_ += [(name, ctypes.c_uint32) for name in ("nfiles", "pgid", "pjobc", "tdev", "tpgid")]
    _fields_ += [("nice", ctypes.c_int32), ("start_sec", ctypes.c_uint64), ("start_usec", ctypes.c_uint64)]


class TaskInfo(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint64) for name in (
        "virtual_size", "resident_size", "total_user", "total_system", "threads_user", "threads_system")]
    _fields_ += [(name, ctypes.c_int32) for name in (
        "policy", "faults", "pageins", "cow_faults", "messages_sent", "messages_received",
        "syscalls_mach", "syscalls_unix", "csw", "threadnum", "numrunning", "priority")]


def _library():
    lib = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
    lib.proc_pidinfo.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint64, ctypes.c_void_p, ctypes.c_int]
    lib.proc_pidinfo.restype = ctypes.c_int
    lib.proc_pidpath.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
    lib.proc_pidpath.restype = ctypes.c_int
    lib.proc_listallpids.argtypes = [ctypes.c_void_p, ctypes.c_int]
    lib.proc_listallpids.restype = ctypes.c_int
    return lib


def _bsd(lib, pid: int, *, unrelated: bool = False):
    info = BSDInfo()
    ctypes.set_errno(0)
    result = lib.proc_pidinfo(pid, 3, 0, ctypes.byref(info), ctypes.sizeof(info))
    if result == 0:
        error = ctypes.get_errno()
        if error in (errno.ESRCH, errno.ENOENT):
            return None
        if unrelated and error in (errno.EPERM, errno.EACCES):
            return None
        # Darwin may report errno=0 for a PID that disappeared between APIs.
        # A second zero is recorded as absent only when kill(0) says ESRCH.
        if error == 0:
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                return None
            except PermissionError:
                if unrelated:
                    return None
        raise RuntimeError(f"Unreadable process identity pid={pid}, errno={error}")
    if result != ctypes.sizeof(info) or info.pid != pid:
        raise RuntimeError("Incomplete or mismatched proc_bsdinfo")
    return {
        "pid": int(info.pid), "ppid": int(info.ppid), "pgid": int(info.pgid),
        "uid": int(info.uid), "status": int(info.status),
        "start_sec": int(info.start_sec), "start_usec": int(info.start_usec),
    }


def same_birth(expected: dict, actual: dict | None) -> bool:
    return actual is not None and all(actual.get(k) == expected.get(k)
                                      for k in ("pid", "uid", "start_sec", "start_usec"))


def identity(pid: int, *, executable: bool = True) -> dict | None:
    lib = _library()
    result = _bsd(lib, pid)
    if result is None:
        return None
    if executable and result["status"] != 5:  # SZOMB has no required executable path.
        path = ctypes.create_string_buffer(4096)
        n = lib.proc_pidpath(pid, path, len(path))
        if n <= 0:
            second = _bsd(lib, pid)
            if second is None:
                return None
            if not same_birth(result, second):
                raise RuntimeError("PID changed during executable lookup")
            if second["status"] == 5:
                result = second
            else:
                raise RuntimeError("Cannot identify live owned executable")
        else:
            result["executable"] = path.value.decode("utf-8")
            second = _bsd(lib, pid)
            if second is None:
                return None
            if not same_birth(result, second):
                raise RuntimeError("PID changed during executable lookup")
    return result


def _all_pids(lib) -> list[int]:
    count = lib.proc_listallpids(None, 0)
    if count <= 0:
        raise RuntimeError("Cannot size process inventory")
    capacity = count * 2 + 128
    for _ in range(3):
        buffer = (ctypes.c_int * capacity)()
        used = lib.proc_listallpids(buffer, ctypes.sizeof(buffer))
        if used < 0:
            raise RuntimeError("Cannot read process inventory")
        if used < capacity:
            return sorted({int(buffer[i]) for i in range(used) if buffer[i] > 0})
        capacity *= 2
    raise RuntimeError("Process inventory repeatedly filled its buffer")


def _rss(lib, expected: dict) -> int | None:
    if expected["status"] == 5:
        return 0
    value = TaskInfo()
    ctypes.set_errno(0)
    n = lib.proc_pidinfo(expected["pid"], 4, 0, ctypes.byref(value), ctypes.sizeof(value))
    after = _bsd(lib, expected["pid"])
    if after is None or after["status"] == 5:
        return None
    if not same_birth(expected, after):
        raise RuntimeError("PID changed during RSS sample")
    if n != ctypes.sizeof(value):
        raise RuntimeError("Incomplete owned process RSS sample")
    return int(value.resident_size)


def snapshot(expected_root: dict, known: dict[int, dict] | None = None) -> dict:
    """Sample the owned session group, descendants, and already known survivors.

    An exited root is normal. Same-PID/different-birth is an error; it never
    transfers ownership. Sampling is not an instantaneous peak guarantee.
    """
    lib = _library()
    actual_root = _bsd(lib, expected_root["pid"])
    if actual_root is not None and not same_birth(expected_root, actual_root):
        raise RuntimeError("Root PID was reused; group refresh is forbidden")
    rows = {}
    for pid in _all_pids(lib):
        item = _bsd(lib, pid, unrelated=True)
        if item is not None:
            rows[pid] = item
    if expected_root["pid"] in rows and not same_birth(expected_root, rows[expected_root["pid"]]):
        raise RuntimeError("Root PID changed during group refresh")
    # A numeric PGID alone never establishes ownership after the original
    # root disappears: the number could have been reused for another group.
    # While its birth identity is present (including an unreaped zombie),
    # that identity anchors group ownership. Otherwise start only with
    # previously recorded, still-matching births and their descendants.
    root_in_inventory = rows.get(expected_root["pid"])
    anchored_group = root_in_inventory is not None and same_birth(expected_root, root_in_inventory)
    selected = ({pid for pid, row in rows.items() if row["pgid"] == expected_root["pid"]}
                if anchored_group else set())
    for pid, previous in (known or {}).items():
        if pid in rows and same_birth(previous, rows[pid]):
            selected.add(pid)
    while True:
        children = {pid for pid, row in rows.items() if row["ppid"] in selected} - selected
        if not children:
            break
        selected.update(children)
    unclaimed_group = {pid for pid, row in rows.items()
                       if row["pgid"] == expected_root["pid"]} - selected
    if unclaimed_group:
        raise RuntimeError("Unanchored PGID members cannot be claimed: " + repr(sorted(unclaimed_group)))
    processes = []
    root_birth = (expected_root["start_sec"], expected_root["start_usec"])
    for pid in sorted(selected):
        row = rows[pid]
        if row["uid"] != expected_root["uid"]:
            raise RuntimeError("Foreign UID in owned group/tree")
        if (row["start_sec"], row["start_usec"]) < root_birth:
            raise RuntimeError("Unexpected older process in owned group/tree")
        value = _rss(lib, row)
        if value is None:
            continue  # Exited between identity and RSS; waitpid decides the root exit.
        row["rss_bytes"] = value
        processes.append(row)
    return {
        "root_exited": actual_root is None or actual_root["status"] == 5,
        "rss_bytes": sum(x["rss_bytes"] for x in processes),
        "processes": processes,
        "live_processes": [x for x in processes if x["status"] != 5],
    }


def signal_verified(expected: dict, signum: int) -> dict:
    """Signal an individually verified birth identity; never a bare reused PGID."""
    actual = identity(expected["pid"], executable=False)
    if actual is None or actual["status"] == 5:
        return {"pid": expected["pid"], "action": "already_exited"}
    if not same_birth(expected, actual):
        return {"pid": expected["pid"], "action": "identity_changed_no_signal"}
    try:
        os.kill(expected["pid"], signum)
        return {"pid": expected["pid"], "action": signal.Signals(signum).name,
                "identity": actual}
    except ProcessLookupError:
        return {"pid": expected["pid"], "action": "exited_before_signal"}


def live_known(known: dict[int, dict]) -> tuple[list[dict], list[int]]:
    live, reused = [], []
    for pid, expected in known.items():
        actual = identity(pid, executable=False)
        if actual is None or actual["status"] == 5:
            continue
        if not same_birth(expected, actual):
            reused.append(pid)
        else:
            live.append(actual)
    return live, reused
