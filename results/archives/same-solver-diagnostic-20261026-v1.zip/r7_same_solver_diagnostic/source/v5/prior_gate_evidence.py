"""Pin/provenance checks only; no model, BDD, solver or process execution.

The caller supplies checked I/O so the saved checker records every observed
input and the supervisor applies the same physical-file contract. This shared
administrative code is separate from the unchanged independent Boolean DAG.
"""
import json
from pathlib import Path
import path_identity as identity

CROSS = "cross_arm_gate_revalidation"
ARMS = ("gate_unchanged", "gate_S01_release")
GC_LINE = b"Garbage collection #1: 50021 nodes / 26282 free / 0.008s / 0.008s total\n"
GC_SHA = "42ec246d108db325f76a57ebeb56302a3727bd5671857df0ddf4b90f8634758e"
BUDGET = {"model_builds_already_completed": 3, "raw_solver_calls_already_completed": 0,
          "additional_model_cap": 2, "total_model_cap": 5, "additional_raw_solver_cap": 2,
          "future_cross_attempts_if_separately_authorized": 1, "retries": 0}


def strict(a, b):
    return json.dumps(a, sort_keys=True, allow_nan=False) == json.dumps(b, sort_keys=True, allow_nan=False)


def match(a, b, check, need, label):
    check(a)
    check(b)
    need(identity.same_file_pin(a, b), label)


def manifest(value, folder, stage, read, check, need, roster):
    folder = identity.canonical_directory(folder)
    need(identity.same_file(check(value), folder / "OUTPUT_MANIFEST.json"), stage + "_manifest_in_original_folder")
    data = read(folder / "OUTPUT_MANIFEST.json")
    need(data.get("schema") == "v71-r7-stage-output-manifest-v1" and data.get("stage") == stage, stage + "_manifest_identity")
    need(isinstance(data.get("files"), list) and bool(data["files"]), stage + "_nonempty_manifest")
    expected = set()
    for row in data["files"]:
        path = check(row)
        key = identity.file_key(path)
        need(identity.file_within(path, folder) and path.name not in ("SUPERVISOR_RESULT.json", "OUTPUT_MANIFEST.json") and key not in expected, stage + "_manifest_member_in_place")
        expected.add(key)
    excluded = {identity.file_key(folder / name) for name in ("SUPERVISOR_RESULT.json", "OUTPUT_MANIFEST.json")}
    actual = roster(folder)
    need(len({identity.file_key(p) for p in actual}) == len(actual) and expected == {identity.file_key(p) for p in actual} - excluded, stage + "_exact_original_output_roster")
    return data


def launch(value, stage, plan, plan_pin, freeze_pin, auth_pin, cwd, code, read, check, need):
    if plan.get("schema") == "v71-r7-v5-three-stage-plan-v1":
        need(identity.same_file(check(value), plan["root_launch_receipts"][stage]), stage + "_fixed_new_root_launch_receipt_path")
    receipt = read(check(value))
    need(receipt.get("schema") == "v71-r7-root-actual-stage-launch-v1" and receipt.get("stage") == stage and receipt.get("status") == "OUTER_PROCESS_EXITED", stage + "_actual_root_launch_identity")
    need(type(receipt.get("outer_return_code")) is int and receipt["outer_return_code"] == code and receipt.get("outer_command_uses_shell") is False, stage + "_actual_root_exit_and_no_shell")
    need(identity.same_directory(receipt["cwd"], cwd), stage + "_actual_root_cwd")
    for key, expected in (("plan", plan_pin), ("input_freeze", freeze_pin), ("authorization", auth_pin)):
        match(receipt[key], expected, check, need, stage + "_root_launch_" + key)
    expected_argv = plan["supervisor_launch_prefix"] + [stage, "--authorization", auth_pin["path"], "--authorization-sha256", auth_pin["sha256"]]
    need(strict(receipt.get("actual_outer_argv"), expected_argv) and strict(receipt.get("declared_effective_outer_environment"), plan["supervisor_environment"]), stage + "_exact_actual_root_argv_environment")
    for key in ("root_launcher", "stdout", "stderr"):
        check(receipt[key])
    if plan.get("schema") == "v71-r7-v5-three-stage-plan-v1":
        match(receipt["root_launcher"], plan["root_launcher"], check, need, stage + "_fixed_new_root_launcher")
    need(receipt["stderr"]["bytes"] == 0, stage + "_root_launch_stderr_empty")
    return receipt


def state_complete(data, stage, need):
    need(data.get("schema") == "v71-r7-bounded-stage-result-v1" and data.get("stage") == stage and data.get("status") == "COMPLETE_STAGE", stage + "_real_complete_supervisor")
    need(type(data.get("return_code")) is int and data["return_code"] == 0 and data.get("limit_reason") is None and data.get("capture_complete") is True and data.get("signals") == [], stage + "_real_zero_exit_capture_no_limits_signals")


def stderr_classification(stage, value, gc, check, need):
    path = check(value)
    expected = b"" if stage == "gate_unchanged" else GC_LINE
    need(stage in ARMS and value["bytes"] == len(expected) and path.read_bytes() == expected, stage + "_only_exact_saved_stderr_bytes")
    if stage == "gate_S01_release":
        need(value["sha256"] == GC_SHA, stage + "_exact_saved_GC_sha256")
    return {"classification": "EMPTY" if not expected else "EXACT_PINNED_JTLV_POST_GC_NOTICE",
            "raw_pin": value, "raw_utf8": expected.decode("ascii"),
            "origin_inspection": gc["inspection"], "jar": gc["jar"],
            "general_stderr_allowance": False}


def prior_bundle(value, root, new_config_pin, frozen, read, check, need, roster):
    need(identity.same_file(check(value), root / "PRIOR_GATE_BUNDLE.json"), "fixed_prior_bundle_file")
    data = read(root / "PRIOR_GATE_BUNDLE.json")
    need(data.get("schema") == "v71-r7-v5-prior-gate-bundle-v1" and data.get("status") == "FROZEN_PRIOR_V4_GATES_AND_UNKNOWN_CROSS", "explicit_prior_v4_bundle_schema")
    need(strict(data.get("history_budget"), BUDGET), "history_three_models_zero_raw_plus_two_only")
    source = identity.canonical_directory(data["source_root"])
    need(not identity.same_directory(source, root), "prior_gates_in_distinct_original_preparation")
    for key, name in (("source_plan", "PLAN.json"), ("source_input_freeze", "INPUT_FREEZE.json"), ("source_config", "B_CONFIG.json"), ("source_origins", "origins.properties")):
        need(identity.same_file(check(data[key]), source / name), "original_" + key + "_path")
    check(new_config_pin)
    need(not identity.same_file(data["source_config"]["path"], new_config_pin["path"]) and all(data["source_config"][key] == new_config_pin[key] for key in ("bytes", "sha256")), "new_config_distinct_file_exact_old_bytes")
    plan = read(check(data["source_plan"]))
    freeze = read(check(data["source_input_freeze"]))
    auth = read(check(data["source_authorization"]))
    need(plan.get("schema") == "v71-r7-two-arm-plan-v1" and set(plan["stages"]) == set(ARMS) | {"cross_arm_gate", "solve_unchanged", "solve_S01_release"}, "original_v4_plan_identity")
    need(freeze.get("schema") == "v71-r7-two-arm-input-freeze-v1", "original_v4_freeze_identity")
    # Every old frozen member must also belong to the already verified new
    # freeze. Old directory rosters are checked in place; no gate is copied.
    old_pins = list(freeze["files"])
    for directory in freeze["directories"]:
        folder = identity.canonical_directory(directory["path"])
        members = []
        for row in directory["files"]:
            rel = row["relative_path"]
            need(isinstance(rel, str) and rel and not rel.startswith("/") and all(x not in ("", ".", "..") for x in rel.split("/")), "safe_prior_frozen_relative_path")
            members.append({"path": str(folder / rel), "bytes": row["bytes"], "sha256": row["sha256"]})
        need({identity.file_key(p) for p in roster(folder)} == {identity.file_key(p["path"]) for p in members}, "prior_frozen_directory_roster_" + str(folder))
        old_pins.extend(members)
    for item in old_pins:
        key = identity.file_key(item["path"])
        need(key in frozen and identity.same_file_pin(item, frozen[key]), "prior_frozen_member_retained_" + item["path"])
    need(auth.get("schema") == "v71-r7-two-arm-root-authorization-v1" and auth.get("status") == "GO_GATE_STAGES_ONLY" and set(auth["authorized_stages"]) == set(ARMS) | {"cross_arm_gate"}, "original_gate_only_GO")
    match(auth["plan"], data["source_plan"], check, need, "original_GO_plan")
    match(auth["input_freeze"], data["source_input_freeze"], check, need, "original_GO_freeze")
    need(set(data["gates"]) == set(ARMS), "exact_two_original_gate_roster")
    gc = data["gc_diagnostic"]
    for key in ("inspection", "source_excerpts", "diagnosis", "independent_handoff", "jar"):
        check(gc[key])
    inspection = read(check(gc["inspection"]))
    match(inspection["jar"], gc["jar"], check, need, "GC_inspection_same_pinned_runtime_JAR")
    need(gc["jar"]["bytes"] == 1058213 and gc["jar"]["sha256"] == "556686e33f01dbe3552547c261b580e756012825207503aed8dc7825627b1644", "fixed_JTLV_GC_origin_JAR")
    expected_classes = {"net.sf.javabdd.BDDFactory", "net.sf.javabdd.BDDFactory$GCStats", "net.sf.javabdd.JTLVJavaFactory"}
    need({row["class"] for row in gc["runtime_class_identities"]} == expected_classes and len(gc["runtime_class_identities"]) == 3, "three_pinned_GC_runtime_class_identities")
    members = {row["member"]: row for row in inspection["embedded_members"]}
    for row in gc["runtime_class_identities"]:
        need(row["class_sha256"] == members[row["class"].replace(".", "/") + ".class"]["sha256"], "GC_runtime_class_matches_actual_JAR_" + row["class"])
    for stage, evidence in data["gates"].items():
        folder = source / "runs" / stage
        names = {"supervisor_result": "SUPERVISOR_RESULT.json", "native_result": "native_result/RESULT.json", "output_manifest": "OUTPUT_MANIFEST.json", "baseline_model": "native_result/baseline/model.json", "arm_model": "native_result/arm/model.json", "capture_receipt": "native_result/CAPTURE_RECEIPT.json", "stdout": "stdout.txt", "stderr": "stderr.txt"}
        need(set(evidence) == set(names) | {"root_launch"}, stage + "_complete_prior_evidence_roster")
        for key, rel in names.items():
            need(identity.same_file(check(evidence[key]), folder / rel), stage + "_original_" + key + "_path")
        state = read(check(evidence["supervisor_result"]))
        state_complete(state, stage, need)
        for key, expected in (("plan", data["source_plan"]), ("input_freeze", data["source_input_freeze"]), ("authorization", data["source_authorization"]), ("native_result", evidence["native_result"]), ("output_manifest", evidence["output_manifest"])):
            match(state[key], expected, check, need, stage + "_supervisor_" + key)
        item = plan["stages"][stage]
        argv = [data["source_authorization"]["path"] if x == "{authorization_path}" else data["source_authorization"]["sha256"] if x == "{authorization_sha256}" else x for x in item["argv"]]
        need(strict(state["target_argv"], argv) and strict(state["environment"], item["env"]) and strict(state["limits"], item["limits"]), stage + "_original_target_argv_environment_limits")
        result = read(check(evidence["native_result"]))
        for pointer, expected in item["required_result_fields"].items():
            actual = result
            for part in pointer.lstrip("/").split("/"):
                actual = actual[part.replace("~1", "/").replace("~0", "~")]
            need(strict(actual, expected), stage + "_original_required_native_" + pointer)
        for key, expected in (("authorization", data["source_authorization"]), ("config", data["source_config"]), ("baseline_model", evidence["baseline_model"]), ("arm_model", evidence["arm_model"]), ("capture_receipt", evidence["capture_receipt"])):
            match(result[key], expected, check, need, stage + "_native_" + key)
        for row in gc["runtime_class_identities"]:
            need(sum(strict(row, actual) for actual in result["class_identities"]) == 1, stage + "_GC_runtime_identity_" + row["class"])
        stderr_classification(stage, evidence["stderr"], gc, check, need)
        manifest(evidence["output_manifest"], folder, stage, read, check, need, roster)
        launch(evidence["root_launch"], stage, plan, data["source_plan"], data["source_input_freeze"], data["source_authorization"], source, 0, read, check, need)
    failed = data["failed_cross"]
    need(set(failed) == {"supervisor_result", "native_result", "output_manifest", "root_launch"}, "failed_cross_evidence_roster")
    folder = source / "runs/cross_arm_gate"
    for key, rel in (("supervisor_result", "SUPERVISOR_RESULT.json"), ("native_result", "RESULT.json"), ("output_manifest", "OUTPUT_MANIFEST.json")):
        need(identity.same_file(check(failed[key]), folder / rel), "original_UNKNOWN_" + key + "_path")
    state = read(check(failed["supervisor_result"]))
    result = read(check(failed["native_result"]))
    need(state.get("schema") == "v71-r7-bounded-stage-result-v1" and state.get("stage") == "cross_arm_gate" and state.get("status") == "UNKNOWN_STAGE" and type(state.get("return_code")) is int and state["return_code"] == 2 and state.get("native_result") is None, "original_cross_supervisor_UNKNOWN_OS2_never_adopted_as_complete")
    need(state.get("limit_reason") is None and state.get("capture_complete") is True and state.get("signals") == [], "original_cross_capture_complete_no_limit_or_signal")
    need(result.get("schema") == "v71-r7-saved-cross-arm-gate-v1" and result.get("status") == "UNKNOWN_CROSS_ARM_GATE" and result.get("stage") == "cross_arm_gate" and result.get("exception") == "RuntimeError('gate_S01_release_stderr_empty')", "original_cross_failed_exact_ancillary_condition")
    need(all(type(v) is int and v == 0 for v in result["activity"].values()), "original_cross_zero_scientific_activity")
    for key, expected in (("plan", data["source_plan"]), ("input_freeze", data["source_input_freeze"]), ("authorization", data["source_authorization"]), ("output_manifest", failed["output_manifest"])):
        match(state[key], expected, check, need, "original_UNKNOWN_" + key)
    manifest(failed["output_manifest"], folder, "cross_arm_gate", read, check, need, roster)
    launch(failed["root_launch"], "cross_arm_gate", plan, data["source_plan"], data["source_input_freeze"], data["source_authorization"], source, 2, read, check, need)
    preliminary = data["historical_preliminary"]
    state = read(check(preliminary["supervisor_result"]))
    state_complete(state, "gate_unchanged", need)
    match(state["native_result"], preliminary["native_result"], check, need, "historical_preliminary_native_binding")
    result = read(check(preliminary["native_result"]))
    need(result.get("status") == "PASS_ARM_GATE_NO_SOLVE" and type(result.get("model_generations")) is int and result["model_generations"] == 1 and type(result.get("raw_four_fixed_point_calls")) is int and result["raw_four_fixed_point_calls"] == 0, "historical_preliminary_one_model_zero_raw")
    match(state["output_manifest"], preliminary["output_manifest"], check, need, "historical_preliminary_manifest_binding")
    check(data["preparation_decision"])
    need(not any((source / "runs" / s).exists() for s in ("solve_unchanged", "solve_S01_release")), "no_v4_solve_attempts")
    return data


def revalidation(evidence, auth, plan, bundle, root, read, check, need, roster):
    need(set(evidence) == {"supervisor_result", "native_result", "output_manifest", "root_launch"}, "new_cross_adoption_evidence_roster")
    folder = root / "runs" / CROSS
    for key, rel in (("supervisor_result", "SUPERVISOR_RESULT.json"), ("native_result", "RESULT.json"), ("output_manifest", "OUTPUT_MANIFEST.json")):
        need(identity.same_file(check(evidence[key]), folder / rel), "new_cross_" + key + "_actual_path")
    state = read(check(evidence["supervisor_result"]))
    state_complete(state, CROSS, need)
    for key in ("plan", "input_freeze", "prior_gate_bundle"):
        match(state[key], auth[key], check, need, "new_cross_supervisor_current_" + key)
    match(state["native_result"], evidence["native_result"], check, need, "new_cross_supervisor_native")
    match(state["output_manifest"], evidence["output_manifest"], check, need, "new_cross_supervisor_manifest")
    result = read(check(evidence["native_result"]))
    need(result.get("schema") == "v71-r7-saved-cross-arm-revalidation-v2" and result.get("status") == "PASS_CROSS_ARM_SAVED_PREDICATE_GATE" and result.get("stage") == CROSS, "new_cross_complete_native_schema_status_stage")
    need(result.get("original_failed_cross_preserved") is True and strict(result.get("verified_prior_gate_evidence"), bundle), "new_cross_actually_checked_exact_prior_evidence")
    match(result["prior_gate_bundle"], auth["prior_gate_bundle"], check, need, "new_cross_exact_prior_bundle")
    for key in ("plan", "input_freeze"):
        match(result[key], auth[key], check, need, "new_cross_native_current_" + key)
    match(result["authorization"], state["authorization"], check, need, "new_cross_native_GO")
    item = plan["stages"][CROSS]
    argv = [result["authorization"]["path"] if x == "{authorization_path}" else result["authorization"]["sha256"] if x == "{authorization_sha256}" else x for x in item["argv"]]
    need(strict(state["target_argv"], argv) and strict(state["environment"], item["env"]) and strict(state["limits"], item["limits"]), "new_cross_exact_inner_target_argv_environment_limits")
    cross_auth = read(check(result["authorization"]))
    need(cross_auth.get("schema") == "v71-r7-v5-root-authorization-v1" and cross_auth.get("status") == "GO_SAVED_CROSS_ONLY" and cross_auth.get("authorized_stages") == [CROSS], "new_cross_separate_single_attempt_GO")
    for key in ("plan", "input_freeze", "prior_gate_bundle"):
        match(cross_auth[key], auth[key], check, need, "new_cross_GO_current_" + key)
    checks = result.get("checks")
    need(isinstance(checks, dict) and bool(checks) and all(v is True for v in checks.values()) and type(result.get("checks_count")) is int and result["checks_count"] == len(checks), "new_cross_all_checks_completed_true")
    activities = ("model_generations", "model_builds", "Java_runs", "solver_calls", "fixed_point_calls", "CPre_calls", "signals", "GUI_actions")
    need(set(result["activity"]) == set(activities) and all(type(result["activity"][k]) is int and result["activity"][k] == 0 for k in activities), "new_cross_zero_scientific_activity")
    need(set(result["stderr_classifications"]) == set(ARMS), "new_cross_two_exact_stderr_classifications")
    for stage in ARMS:
        expected = stderr_classification(stage, bundle["gates"][stage]["stderr"], bundle["gc_diagnostic"], check, need)
        need(strict(result["stderr_classifications"][stage], expected), stage + "_new_cross_retains_exact_raw_stderr_classification")
    manifest(evidence["output_manifest"], folder, CROSS, read, check, need, roster)
    launch(evidence["root_launch"], CROSS, plan, auth["plan"], auth["input_freeze"], result["authorization"], root, 0, read, check, need)
    return result
