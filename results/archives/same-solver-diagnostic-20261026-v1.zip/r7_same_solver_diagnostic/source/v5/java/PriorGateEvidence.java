import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.charset.StandardCharsets;
import java.util.*;
import com.google.gson.*;

/** Administrative provenance guard. No model/BDD/solver operations occur here. */
final class PriorGateEvidence {
  static final String CROSS="cross_arm_gate_revalidation";
  static final Set<String> ARMS=new HashSet<>(Arrays.asList("gate_unchanged","gate_S01_release"));
  static final String GC_LINE="Garbage collection #1: 50021 nodes / 26282 free / 0.008s / 0.008s total\n";
  static final String GC_SHA="42ec246d108db325f76a57ebeb56302a3727bd5671857df0ddf4b90f8634758e";
  static void need(boolean ok,String label){if(!ok)throw new IllegalStateException(label);}
  static JsonObject read(Path p)throws Exception{return ExactBSameSolverDiagnostic.read(p);}
  static Path canonical(Path p,boolean directory)throws Exception{
    need(p.isAbsolute()&&p.normalize().equals(p),"Canonical absolute provenance path");
    Path at=p.getRoot();
    for(Path part:p){at=at.resolve(part);need(!Files.isSymbolicLink(at),"No provenance path symlinks");if(!at.equals(p))need(Files.isDirectory(at),"Directory provenance parents");}
    need(directory?Files.isDirectory(p):Files.isRegularFile(p),"Provenance path type");return p.toRealPath();
  }
  static Path pinned(JsonObject value)throws Exception{return canonical(ExactBSameSolverDiagnostic.pinned(value),false);}
  static JsonObject object(JsonObject pin)throws Exception{return read(pinned(pin));}
  static void match(JsonObject a,JsonObject b,String label)throws Exception{
    Path pa=pinned(a),pb=pinned(b);need(a.get("bytes").getAsLong()==b.get("bytes").getAsLong()&&a.get("sha256").getAsString().equals(b.get("sha256").getAsString())&&Files.isSameFile(pa,pb),label);
  }
  static void at(JsonObject pin,Path path,String label)throws Exception{need(Files.isSameFile(pinned(pin),canonical(path,false)),label);}
  static Object fileKey(Path path)throws Exception{Object key=Files.readAttributes(canonical(path,false),BasicFileAttributes.class).fileKey();need(key!=null,"Physical file identity available");return key;}
  static boolean within(Path file,Path folder)throws Exception{
    Path ancestor=canonical(file,false).getParent(),root=canonical(folder,true);
    while(ancestor!=null){if(Files.isSameFile(ancestor,root))return true;ancestor=ancestor.getParent();}return false;
  }
  static boolean number(JsonObject x,String key,int n){return x.has(key)&&x.get(key).isJsonPrimitive()&&x.getAsJsonPrimitive(key).isNumber()&&x.get(key).getAsString().equals(Integer.toString(n));}
  static boolean yes(JsonObject x,String key){return x.has(key)&&x.get(key).isJsonPrimitive()&&x.getAsJsonPrimitive(key).isBoolean()&&x.get(key).getAsBoolean();}
  static boolean no(JsonObject x,String key){return x.has(key)&&x.get(key).isJsonPrimitive()&&x.getAsJsonPrimitive(key).isBoolean()&&!x.get(key).getAsBoolean();}
  static void complete(JsonObject s,String stage){
    need(s.get("schema").getAsString().equals("v71-r7-bounded-stage-result-v1")&&s.get("stage").getAsString().equals(stage)&&s.get("status").getAsString().equals("COMPLETE_STAGE"),"Real completed supervisor "+stage);
    need(number(s,"return_code",0)&&s.get("limit_reason").isJsonNull()&&yes(s,"capture_complete")&&s.getAsJsonArray("signals").size()==0,"Real zero exit/no limits/signals/full capture "+stage);
  }
  static void target(JsonObject state,JsonObject plan,String stage,JsonObject auth){
    JsonObject item=plan.getAsJsonObject("stages").getAsJsonObject(stage);JsonArray argv=new JsonArray();
    for(JsonElement e:item.getAsJsonArray("argv")){String v=e.getAsString();argv.add(v.equals("{authorization_path}")?auth.get("path").getAsString():v.equals("{authorization_sha256}")?auth.get("sha256").getAsString():v);}
    need(argv.equals(state.getAsJsonArray("target_argv"))&&item.getAsJsonObject("env").equals(state.getAsJsonObject("environment"))&&item.getAsJsonObject("limits").equals(state.getAsJsonObject("limits")),"Actual inner target argv/environment/limits "+stage);
  }
  static JsonElement field(JsonObject value,String pointer){
    need(pointer.startsWith("/"),"JSON pointer required");JsonElement at=value;
    for(String raw:pointer.substring(1).split("/")){String part=raw.replace("~1","/").replace("~0","~");at=at.isJsonArray()?at.getAsJsonArray().get(Integer.parseInt(part)):at.getAsJsonObject().get(part);need(at!=null,"Required native field "+pointer);}
    return at;
  }
  static void manifest(JsonObject value,Path folder,String stage)throws Exception{
    folder=canonical(folder,true);at(value,folder.resolve("OUTPUT_MANIFEST.json"),"Actual manifest path "+stage);
    JsonObject m=object(value);need(m.get("schema").getAsString().equals("v71-r7-stage-output-manifest-v1")&&m.get("stage").getAsString().equals(stage),"Manifest identity "+stage);
    Set<Object> expected=new HashSet<>();
    for(JsonElement e:m.getAsJsonArray("files")){
      Path p=pinned(e.getAsJsonObject());
      need(within(p,folder)&&!Arrays.asList("SUPERVISOR_RESULT.json","OUTPUT_MANIFEST.json").contains(p.getFileName().toString())&&expected.add(fileKey(p)),"Manifest contained distinct physical members "+stage);
    }
    Set<Object> actual=new HashSet<>();
    try(java.util.stream.Stream<Path> walk=Files.walk(folder)){
      for(Iterator<Path> it=walk.iterator();it.hasNext();){Path path=it.next();need(!Files.isSymbolicLink(path),"No output links");if(Files.isDirectory(path))continue;need(actual.add(fileKey(path)),"Distinct physical output members");}
    }
    actual.remove(fileKey(folder.resolve("SUPERVISOR_RESULT.json")));actual.remove(fileKey(folder.resolve("OUTPUT_MANIFEST.json")));
    need(!expected.isEmpty()&&actual.equals(expected),"Exact output manifest roster "+stage);
  }
  static void launch(JsonObject value,String stage,JsonObject plan,JsonObject planPin,JsonObject freezePin,JsonObject authPin,Path cwd,int code)throws Exception{
    boolean current=plan.get("schema").getAsString().equals("v71-r7-v5-three-stage-plan-v1");if(current)at(value,Paths.get(plan.getAsJsonObject("root_launch_receipts").get(stage).getAsString()),"Fixed new root launch receipt path");
    JsonObject r=object(value);need(r.get("schema").getAsString().equals("v71-r7-root-actual-stage-launch-v1")&&r.get("stage").getAsString().equals(stage)&&r.get("status").getAsString().equals("OUTER_PROCESS_EXITED"),"Actual root launch "+stage);
    need(number(r,"outer_return_code",code)&&no(r,"outer_command_uses_shell")&&Files.isSameFile(canonical(Paths.get(r.get("cwd").getAsString()),true),canonical(cwd,true)),"Actual root exit/no shell/cwd "+stage);
    match(r.getAsJsonObject("plan"),planPin,"Launch plan");match(r.getAsJsonObject("input_freeze"),freezePin,"Launch freeze");match(r.getAsJsonObject("authorization"),authPin,"Launch GO");
    JsonArray argv=plan.getAsJsonArray("supervisor_launch_prefix").deepCopy();argv.add(stage);argv.add("--authorization");argv.add(authPin.get("path"));argv.add("--authorization-sha256");argv.add(authPin.get("sha256"));
    need(argv.equals(r.getAsJsonArray("actual_outer_argv"))&&plan.getAsJsonObject("supervisor_environment").equals(r.getAsJsonObject("declared_effective_outer_environment")),"Exact actual outer argv/environment "+stage);
    for(String key:new String[]{"root_launcher","stdout","stderr"})pinned(r.getAsJsonObject(key));
    if(current)match(r.getAsJsonObject("root_launcher"),plan.getAsJsonObject("root_launcher"),"Fixed new root launcher source");
    need(number(r.getAsJsonObject("stderr"),"bytes",0),"Outer stderr empty "+stage);
  }
  static void stderr(String stage,JsonObject value)throws Exception{
    byte[] expected=(stage.equals("gate_unchanged")?"":GC_LINE).getBytes(StandardCharsets.US_ASCII);
    need(ARMS.contains(stage)&&Arrays.equals(Files.readAllBytes(pinned(value)),expected)&&number(value,"bytes",expected.length),"Only exact saved stderr bytes "+stage);
    if(stage.equals("gate_S01_release"))need(value.get("sha256").getAsString().equals(GC_SHA),"Exact saved post-GC SHA");
  }
  static JsonObject prior(JsonObject auth,Path root)throws Exception{
    JsonObject bundlePin=auth.getAsJsonObject("prior_gate_bundle");at(bundlePin,root.resolve("PRIOR_GATE_BUNDLE.json"),"Reviewed local prior gate bundle");
    JsonObject b=object(bundlePin);need(b.get("schema").getAsString().equals("v71-r7-v5-prior-gate-bundle-v1")&&b.get("status").getAsString().equals("FROZEN_PRIOR_V4_GATES_AND_UNKNOWN_CROSS"),"Explicit reused v4 bundle");
    JsonObject budget=b.getAsJsonObject("history_budget");String[] budgetKeys={"model_builds_already_completed","raw_solver_calls_already_completed","additional_model_cap","total_model_cap","additional_raw_solver_cap","future_cross_attempts_if_separately_authorized","retries"};int[] values={3,0,2,5,2,1,0};
    need(budget.keySet().equals(new HashSet<>(Arrays.asList(budgetKeys))),"Exact history budget fields");for(int i=0;i<values.length;i++)need(number(budget,budgetKeys[i],values[i]),"Fixed history budget "+budgetKeys[i]);
    Path source=canonical(Paths.get(b.get("source_root").getAsString()),true);need(!Files.isSameFile(source,canonical(root,true)),"Original gates stay in distinct source preparation");
    String[] sourceKeys={"source_plan","source_input_freeze","source_config","source_origins"},sourceNames={"PLAN.json","INPUT_FREEZE.json","B_CONFIG.json","origins.properties"};for(int i=0;i<sourceKeys.length;i++)at(b.getAsJsonObject(sourceKeys[i]),source.resolve(sourceNames[i]),"Original source "+sourceKeys[i]);
    Path oldConfig=pinned(b.getAsJsonObject("source_config")),newConfig=canonical(root.resolve("B_CONFIG.json"),false);
    need(!Files.isSameFile(oldConfig,newConfig)&&Arrays.equals(Files.readAllBytes(oldConfig),Files.readAllBytes(newConfig)),"New config is distinct physical file with exact old bytes");
    JsonObject plan=object(b.getAsJsonObject("source_plan")),freeze=object(b.getAsJsonObject("source_input_freeze")),go=object(b.getAsJsonObject("source_authorization"));
    need(plan.get("schema").getAsString().equals("v71-r7-two-arm-plan-v1")&&freeze.get("schema").getAsString().equals("v71-r7-two-arm-input-freeze-v1"),"Original v4 plan/freeze schemas");
    need(go.get("schema").getAsString().equals("v71-r7-two-arm-root-authorization-v1")&&go.get("status").getAsString().equals("GO_GATE_STAGES_ONLY"),"Original gate-only GO");
    Set<String> oldStages=new HashSet<>();for(JsonElement e:go.getAsJsonArray("authorized_stages"))need(oldStages.add(e.getAsString()),"Distinct original GO stage");need(oldStages.equals(new HashSet<>(Arrays.asList("gate_unchanged","gate_S01_release","cross_arm_gate"))),"Exact original three gate GO");
    match(go.getAsJsonObject("plan"),b.getAsJsonObject("source_plan"),"Original GO plan");match(go.getAsJsonObject("input_freeze"),b.getAsJsonObject("source_input_freeze"),"Original GO freeze");
    JsonObject gates=b.getAsJsonObject("gates"),gc=b.getAsJsonObject("gc_diagnostic");need(gates.keySet().equals(ARMS),"Exactly two original gates");
    for(String key:new String[]{"inspection","source_excerpts","diagnosis","independent_handoff","jar"})pinned(gc.getAsJsonObject(key));
    JsonObject inspection=object(gc.getAsJsonObject("inspection"));match(inspection.getAsJsonObject("jar"),gc.getAsJsonObject("jar"),"GC static inspection runtime JAR");
    need(number(gc.getAsJsonObject("jar"),"bytes",1058213)&&gc.getAsJsonObject("jar").get("sha256").getAsString().equals("556686e33f01dbe3552547c261b580e756012825207503aed8dc7825627b1644"),"Exact pinned GC JAR");
    need(gc.getAsJsonArray("runtime_class_identities").size()==3,"Three GC runtime identities");
    Set<String> gcClasses=new HashSet<>();for(JsonElement item:gc.getAsJsonArray("runtime_class_identities")){JsonObject c=item.getAsJsonObject();String name=c.get("class").getAsString();need(gcClasses.add(name),"Distinct GC class identity");String member=name.replace('.','/')+".class";int count=0;for(JsonElement embedded:inspection.getAsJsonArray("embedded_members")){JsonObject m=embedded.getAsJsonObject();if(m.get("member").getAsString().equals(member)&&m.get("sha256").equals(c.get("class_sha256")))count++;}need(count==1,"GC runtime class matches actual inspected JAR member");}need(gcClasses.equals(new HashSet<>(Arrays.asList("net.sf.javabdd.BDDFactory","net.sf.javabdd.BDDFactory$GCStats","net.sf.javabdd.JTLVJavaFactory"))),"Exact GC runtime class roster");
    for(String stage:ARMS){
      JsonObject e=gates.getAsJsonObject(stage);Path folder=source.resolve("runs").resolve(stage);
      String[] keys={"supervisor_result","native_result","output_manifest","baseline_model","arm_model","capture_receipt","stdout","stderr"},names={"SUPERVISOR_RESULT.json","native_result/RESULT.json","OUTPUT_MANIFEST.json","native_result/baseline/model.json","native_result/arm/model.json","native_result/CAPTURE_RECEIPT.json","stdout.txt","stderr.txt"};for(int i=0;i<keys.length;i++)at(e.getAsJsonObject(keys[i]),folder.resolve(names[i]),"Original gate "+stage+" "+keys[i]);
      JsonObject s=object(e.getAsJsonObject("supervisor_result"));complete(s,stage);
      for(String key:new String[]{"native_result","output_manifest"})match(s.getAsJsonObject(key),e.getAsJsonObject(key),"Original gate supervisor "+key);
      match(s.getAsJsonObject("plan"),b.getAsJsonObject("source_plan"),"Original gate plan");match(s.getAsJsonObject("input_freeze"),b.getAsJsonObject("source_input_freeze"),"Original gate freeze");match(s.getAsJsonObject("authorization"),b.getAsJsonObject("source_authorization"),"Original gate GO");
      target(s,plan,stage,b.getAsJsonObject("source_authorization"));
      JsonObject n=object(e.getAsJsonObject("native_result"));need(n.get("schema").getAsString().equals("v71-r7-exact-B-same-solver-result-v1")&&n.get("status").getAsString().equals("PASS_ARM_GATE_NO_SOLVE")&&n.get("requested_stage").getAsString().equals(stage)&&n.get("stage").getAsString().equals("PROCESS_FINISHED")&&n.get("teardown").getAsString().equals("COMPLETED")&&number(n,"model_generations",1),"Original completed one-model native gate");
      for(Map.Entry<String,JsonElement> required:plan.getAsJsonObject("stages").getAsJsonObject(stage).getAsJsonObject("required_result_fields").entrySet())need(field(n,required.getKey()).equals(required.getValue()),"Original required native "+required.getKey());
      for(String key:new String[]{"solver_constructions","raw_four_fixed_point_calls","native_strict_solver_calls","winning_region_computations","controller_extraction_calls"})need(number(n,key,0),"Original no-solver counter "+key);
      match(n.getAsJsonObject("authorization"),b.getAsJsonObject("source_authorization"),"Original native GO");match(n.getAsJsonObject("config"),b.getAsJsonObject("source_config"),"Original native config");
      for(String key:new String[]{"baseline_model","arm_model","capture_receipt"})match(n.getAsJsonObject(key),e.getAsJsonObject(key),"Original native "+key);
      for(JsonElement expected:gc.getAsJsonArray("runtime_class_identities")){int count=0;for(JsonElement actual:n.getAsJsonArray("class_identities"))if(expected.equals(actual))count++;need(count==1,"Original runtime-bound GC class identity");}
      stderr(stage,e.getAsJsonObject("stderr"));manifest(e.getAsJsonObject("output_manifest"),folder,stage);
      launch(e.getAsJsonObject("root_launch"),stage,plan,b.getAsJsonObject("source_plan"),b.getAsJsonObject("source_input_freeze"),b.getAsJsonObject("source_authorization"),source,0);
    }
    JsonObject failed=b.getAsJsonObject("failed_cross");Path folder=source.resolve("runs/cross_arm_gate");at(failed.getAsJsonObject("supervisor_result"),folder.resolve("SUPERVISOR_RESULT.json"),"Original UNKNOWN supervisor path");at(failed.getAsJsonObject("native_result"),folder.resolve("RESULT.json"),"Original UNKNOWN native path");
    JsonObject fs=object(failed.getAsJsonObject("supervisor_result")),fn=object(failed.getAsJsonObject("native_result"));
    need(fs.get("schema").getAsString().equals("v71-r7-bounded-stage-result-v1")&&fs.get("stage").getAsString().equals("cross_arm_gate")&&fs.get("status").getAsString().equals("UNKNOWN_STAGE")&&number(fs,"return_code",2)&&fs.get("native_result").isJsonNull(),"Original UNKNOWN OS2 is never a completed gate");
    need(fs.get("limit_reason").isJsonNull()&&yes(fs,"capture_complete")&&fs.getAsJsonArray("signals").size()==0,"Original cross capture completed without limit or signal");
    need(fn.get("schema").getAsString().equals("v71-r7-saved-cross-arm-gate-v1")&&fn.get("status").getAsString().equals("UNKNOWN_CROSS_ARM_GATE")&&fn.get("exception").getAsString().equals("RuntimeError('gate_S01_release_stderr_empty')"),"Original failed exact ancillary check retained");
    for(Map.Entry<String,JsonElement> e:fn.getAsJsonObject("activity").entrySet())need(e.getValue().getAsString().equals("0"),"Failed cross had no science activity");
    match(fs.getAsJsonObject("plan"),b.getAsJsonObject("source_plan"),"Failed cross plan");match(fs.getAsJsonObject("input_freeze"),b.getAsJsonObject("source_input_freeze"),"Failed cross freeze");match(fs.getAsJsonObject("authorization"),b.getAsJsonObject("source_authorization"),"Failed cross GO");match(fs.getAsJsonObject("output_manifest"),failed.getAsJsonObject("output_manifest"),"Failed cross manifest");
    manifest(failed.getAsJsonObject("output_manifest"),folder,"cross_arm_gate");launch(failed.getAsJsonObject("root_launch"),"cross_arm_gate",plan,b.getAsJsonObject("source_plan"),b.getAsJsonObject("source_input_freeze"),b.getAsJsonObject("source_authorization"),source,2);
    JsonObject pre=b.getAsJsonObject("historical_preliminary"),ps=object(pre.getAsJsonObject("supervisor_result")),pn=object(pre.getAsJsonObject("native_result"));complete(ps,"gate_unchanged");match(ps.getAsJsonObject("native_result"),pre.getAsJsonObject("native_result"),"Historical preliminary native");match(ps.getAsJsonObject("output_manifest"),pre.getAsJsonObject("output_manifest"),"Historical preliminary manifest");need(pn.get("status").getAsString().equals("PASS_ARM_GATE_NO_SOLVE")&&number(pn,"model_generations",1)&&number(pn,"raw_four_fixed_point_calls",0),"Historical preliminary one model zero raw");pinned(b.getAsJsonObject("preparation_decision"));
    need(!Files.exists(source.resolve("runs/solve_unchanged"))&&!Files.exists(source.resolve("runs/solve_S01_release")),"No v4 solve attempts");return b;
  }
  static JsonObject adoption(JsonObject auth,Path root)throws Exception{
    JsonObject d=object(auth.getAsJsonObject("gate_adoption"));need(d.get("schema").getAsString().equals("v71-r7-v5-reused-gates-adoption-v1")&&d.get("status").getAsString().equals("ADOPT_PRIOR_ARM_GATES_AND_SAVED_REVALIDATION"),"Explicit v5 adoption required");
    for(String key:new String[]{"plan","input_freeze","prior_gate_bundle"})match(d.getAsJsonObject(key),auth.getAsJsonObject(key),"Current adoption "+key);
    JsonObject b=prior(auth,root),gates=d.getAsJsonObject("gate_results");need(gates.keySet().equals(ARMS),"Only original arm gates adopted");for(String stage:ARMS)match(gates.getAsJsonObject(stage),b.getAsJsonObject("gates").getAsJsonObject(stage).getAsJsonObject("native_result"),"Exact original adopted native "+stage);
    JsonObject e=d.getAsJsonObject("revalidation");need(e.keySet().equals(new HashSet<>(Arrays.asList("supervisor_result","native_result","output_manifest","root_launch"))),"Exact new cross evidence roster");Path folder=root.resolve("runs").resolve(CROSS);
    at(e.getAsJsonObject("supervisor_result"),folder.resolve("SUPERVISOR_RESULT.json"),"Actual new cross supervisor");at(e.getAsJsonObject("native_result"),folder.resolve("RESULT.json"),"Actual new cross native");
    JsonObject s=object(e.getAsJsonObject("supervisor_result"));complete(s,CROSS);for(String key:new String[]{"native_result","output_manifest"})match(s.getAsJsonObject(key),e.getAsJsonObject(key),"New cross supervisor "+key);for(String key:new String[]{"plan","input_freeze","prior_gate_bundle"})match(s.getAsJsonObject(key),auth.getAsJsonObject(key),"New cross current "+key);
    JsonObject n=object(e.getAsJsonObject("native_result"));need(n.get("schema").getAsString().equals("v71-r7-saved-cross-arm-revalidation-v2")&&n.get("status").getAsString().equals("PASS_CROSS_ARM_SAVED_PREDICATE_GATE")&&n.get("stage").getAsString().equals(CROSS)&&yes(n,"original_failed_cross_preserved")&&n.getAsJsonObject("verified_prior_gate_evidence").equals(b),"New complete cross checked exact original gate evidence and UNKNOWN");
    for(String key:new String[]{"plan","input_freeze","prior_gate_bundle"})match(n.getAsJsonObject(key),auth.getAsJsonObject(key),"New cross native "+key);match(n.getAsJsonObject("authorization"),s.getAsJsonObject("authorization"),"New cross native GO");target(s,object(auth.getAsJsonObject("plan")),CROSS,n.getAsJsonObject("authorization"));
    JsonObject go=object(n.getAsJsonObject("authorization"));need(go.get("schema").getAsString().equals("v71-r7-v5-root-authorization-v1")&&go.get("status").getAsString().equals("GO_SAVED_CROSS_ONLY")&&go.getAsJsonArray("authorized_stages").size()==1&&go.getAsJsonArray("authorized_stages").get(0).getAsString().equals(CROSS),"Separate one-attempt saved cross GO");for(String key:new String[]{"plan","input_freeze","prior_gate_bundle"})match(go.getAsJsonObject(key),auth.getAsJsonObject(key),"New cross GO "+key);
    JsonObject checks=n.getAsJsonObject("checks");need(checks.size()>0&&number(n,"checks_count",checks.size()),"Complete new cross check roster");for(String key:checks.keySet())need(yes(checks,key),"New cross all checks true");
    JsonObject activity=n.getAsJsonObject("activity");Set<String> zero=new HashSet<>(Arrays.asList("model_generations","model_builds","Java_runs","solver_calls","fixed_point_calls","CPre_calls","signals","GUI_actions"));need(activity.keySet().equals(zero),"Saved cross activity roster");for(String key:zero)need(number(activity,key,0),"Saved cross no scientific activity");
    JsonObject classifications=n.getAsJsonObject("stderr_classifications");need(classifications.keySet().equals(ARMS),"Exact saved stderr classification roster");for(String stage:ARMS){JsonObject c=classifications.getAsJsonObject(stage),old=b.getAsJsonObject("gates").getAsJsonObject(stage);match(c.getAsJsonObject("raw_pin"),old.getAsJsonObject("stderr"),"Cross exact raw stderr pin");need(c.get("classification").getAsString().equals(stage.equals("gate_unchanged")?"EMPTY":"EXACT_PINNED_JTLV_POST_GC_NOTICE")&&c.get("raw_utf8").getAsString().equals(stage.equals("gate_unchanged")?"":GC_LINE)&&no(c,"general_stderr_allowance"),"No general stderr allowance");match(c.getAsJsonObject("origin_inspection"),b.getAsJsonObject("gc_diagnostic").getAsJsonObject("inspection"),"Cross exact GC origin");match(c.getAsJsonObject("jar"),b.getAsJsonObject("gc_diagnostic").getAsJsonObject("jar"),"Cross exact GC JAR");}
    manifest(e.getAsJsonObject("output_manifest"),folder,CROSS);JsonObject plan=object(auth.getAsJsonObject("plan"));launch(e.getAsJsonObject("root_launch"),CROSS,plan,auth.getAsJsonObject("plan"),auth.getAsJsonObject("input_freeze"),n.getAsJsonObject("authorization"),root,0);
    need(d.getAsJsonArray("qa_evidence").size()>0,"Independent complete gate QA evidence required");for(JsonElement q:d.getAsJsonArray("qa_evidence"))pinned(q.getAsJsonObject());return d;
  }
}
