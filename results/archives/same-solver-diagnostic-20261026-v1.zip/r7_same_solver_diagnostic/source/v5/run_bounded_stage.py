#!/usr/bin/env python3
"""One explicitly authorized stage of the exact-B two-arm diagnostic.

Startup checks precede the local support import. Preparation may parse this
file but must not import it or invoke its main/internal exec shim. Only
stdlib and the adjacent pinned support/identity files are imported; no scientific
module is imported by this supervisor.
"""
from __future__ import annotations

import os
import sys


def require_python_startup():
    """Reject cache reads/writes outside the frozen empty prefix before imports."""
    expected = os.path.join(os.path.dirname(os.path.realpath(__file__)), "empty_python_cache")
    if not (sys.flags.no_site == 1 and sys.flags.dont_write_bytecode == 1 and
            sys.dont_write_bytecode is True):
        raise RuntimeError("Python -B -S startup flags are required")
    if sys.pycache_prefix != expected or sys._xoptions.get("pycache_prefix") != expected:
        raise RuntimeError("Exact -X pycache_prefix=" + expected + " is required")
    if not (os.path.isabs(expected) and os.path.realpath(expected) == expected and
            os.path.isdir(expected) and not os.path.islink(expected)):
        raise RuntimeError("Python cache prefix must be an existing canonical non-symlink directory")
    # Reject even empty child directories: no immediate entries implies no
    # descendant bytecode files can be consumed from the remapped cache.
    with os.scandir(expected) as entries:
        if next(entries, None) is not None:
            raise RuntimeError("Python cache prefix must remain entirely empty")
    return expected


PYTHON_CACHE_PREFIX = require_python_startup()

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import resource
import secrets
import signal
import stat
import subprocess
import threading
import time

import supervisor_support as support
import path_identity as identity
import prior_gate_evidence as evidence

P = Path(__file__).resolve().parent
STAGES = ("cross_arm_gate_revalidation", "solve_unchanged", "solve_S01_release")
GATES = STAGES[:1]
ARMS = ("gate_unchanged", "gate_S01_release")
STATE_NAME = "SUPERVISOR_RESULT.json"
MANIFEST_NAME = "OUTPUT_MANIFEST.json"
RUNTIME_ALIAS_PATHS = (
    "/opt/homebrew/opt/openssl@3/lib/libssl.3.dylib",
    "/opt/homebrew/opt/openssl@3/lib/libcrypto.3.dylib",
    "/opt/homebrew/opt/gettext/lib/libintl.8.dylib",
)


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        while data := f.read(1024 * 1024):
            h.update(data)
    return h.hexdigest()


def absolute_regular(path):
    return identity.canonical_file(path)


def pin(path):
    path = absolute_regular(path)
    before = (identity.file_key(path), path.stat().st_size)
    value = {"path": str(path), "bytes": before[1], "sha256": digest(path)}
    need((identity.file_key(path), path.stat().st_size) == before, "File identity or size changed while hashing")
    return value


def check_pin(value):
    need(isinstance(value, dict) and set(value) == {"path", "bytes", "sha256"}, "Exact file-pin keys required")
    need(type(value["bytes"]) is int and value["bytes"] >= 0, "Nonnegative integer byte count required")
    need(isinstance(value["sha256"], str) and len(value["sha256"]) == 64 and
         all(c in "0123456789abcdef" for c in value["sha256"]), "SHA256 must be lowercase 64-hex")
    path = absolute_regular(value["path"])
    need(path.stat().st_size == value["bytes"] and digest(path) == value["sha256"], "Pin mismatch: " + str(path))
    return path


def read_json(path, max_bytes=16 * 1024 * 1024):
    path = absolute_regular(path)
    need(path.stat().st_size <= max_bytes, "JSON input exceeds read bound")
    def no_duplicates(pairs):
        d = {}
        for k, v in pairs:
            need(k not in d, "Duplicate JSON key: " + k)
            d[k] = v
        return d
    return json.loads(path.read_text(), object_pairs_hook=no_duplicates,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError("Nonfinite JSON value")))


def save(path, value):
    path = Path(path)
    need(identity.same_directory(path.parent, path.parent.resolve()) and not path.is_symlink(), "Unsafe output path")
    temporary = path.with_name(path.name + ".tmp")
    need(not temporary.is_symlink(), "Unsafe temporary path")
    raw = (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()
    with temporary.open("wb") as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    os.replace(temporary, path)


def strict_equal(a, b):
    return json.dumps(a, sort_keys=True, ensure_ascii=False, allow_nan=False) == \
           json.dumps(b, sort_keys=True, ensure_ascii=False, allow_nan=False)


def relative_path(value):
    need(isinstance(value, str) and value and not value.startswith("/"), "Nonempty relative path required")
    need("\\" not in value and all(p not in ("", ".", "..") for p in value.split("/")), "Unsafe relative path")
    return Path(value)


def file_roster(root):
    root = identity.canonical_directory(root)
    rows = []
    for base, dirs, files in os.walk(root, followlinks=False):
        for name in dirs:
            p = Path(base) / name
            need(not p.is_symlink() and stat.S_ISDIR(p.stat().st_mode), "Output/input directory contains link or special entry")
        for name in files:
            p = Path(base) / name
            need(not p.is_symlink() and stat.S_ISREG(p.stat().st_mode), "Directory contains link or nonregular file")
            rows.append(p)
    return sorted(rows)


def verify_freeze(freeze, plan):
    need(freeze.get("schema") == "v71-r7-v5-input-freeze-v1", "Wrong input-freeze schema")
    need(isinstance(freeze.get("files"), list) and isinstance(freeze.get("directories"), list), "Freeze file/directory lists required")
    cache_rosters = [entry for entry in freeze["directories"]
                     if isinstance(entry, dict) and isinstance(entry.get("path"), str)
                     and identity.same_directory(entry["path"], PYTHON_CACHE_PREFIX)]
    need(len(cache_rosters) == 1 and cache_rosters[0].get("files") == [],
         "Freeze must include exactly one empty roster for the Python cache prefix")
    frozen = {}
    for item in freeze["files"]:
        path = check_pin(item)
        key = identity.file_key(path)
        need(key not in frozen, "Duplicate physical frozen file")
        frozen[key] = item
    for item in freeze["directories"]:
        need(set(item) == {"path", "files"} and isinstance(item["files"], list), "Exact directory-roster keys required")
        folder = identity.canonical_directory(item["path"])
        expected = {}
        for row in item["files"]:
            need(set(row) == {"relative_path", "bytes", "sha256"}, "Exact directory-file pin required")
            p = folder / relative_path(row["relative_path"])
            key = identity.file_key(p)
            need(key not in expected and key not in frozen, "Duplicate physical frozen directory member")
            fp = {"path": str(p), "bytes": row["bytes"], "sha256": row["sha256"]}
            check_pin(fp)
            expected[key] = fp
        actual_paths = file_roster(folder)
        actual_keys = {identity.file_key(path) for path in actual_paths}
        need(len(actual_keys) == len(actual_paths) and set(expected) == actual_keys, "Physical frozen directory roster changed")
        frozen.update(expected)
    aliases = freeze.get("runtime_aliases")
    need(isinstance(aliases, list) and len(aliases) == len(RUNTIME_ALIAS_PATHS),
         "Exactly the three known Homebrew runtime aliases are required")
    seen_aliases = set()
    for entry in aliases:
        need(isinstance(entry, dict) and set(entry) == {"path", "resolved_path"} and
             all(isinstance(entry[key], str) for key in ("path", "resolved_path")),
             "Exact runtime-alias path/resolved_path keys required")
        alias, target = Path(entry["path"]), Path(entry["resolved_path"])
        need(entry["path"] in RUNTIME_ALIAS_PATHS and entry["path"] not in seen_aliases,
             "Unknown or duplicate runtime alias")
        need(alias.is_absolute() and target.is_absolute() and
             identity.file_key(target) in frozen,
             "Runtime alias must bind a canonical target in the verified frozen file map")
        need(identity.same_file(alias.resolve(strict=True), target), "Runtime alias resolution changed: " + str(alias))
        seen_aliases.add(entry["path"])
    need(seen_aliases == set(RUNTIME_ALIAS_PATHS), "Known runtime alias roster changed")
    required = {identity.file_key(path) for path in (Path(__file__).resolve(), P / "supervisor_support.py", P / "path_identity.py", P / "prior_gate_evidence.py", Path(sys.executable).resolve())}
    for item in plan["stages"].values():
        required.add(identity.file_key(item["argv"][0]))
    need(required <= set(frozen), "Freeze must pin supervisor, support, interpreter and every target executable")
    return frozen


def lookup_pointer(obj, pointer):
    need(isinstance(pointer, str) and pointer.startswith("/"), "Result field must be a JSON pointer")
    value = obj
    for raw in pointer[1:].split("/"):
        part = raw.replace("~1", "/").replace("~0", "~")
        if isinstance(value, list):
            need(part.isdigit() and str(int(part)) == part and int(part) < len(value), "Missing result list element")
            value = value[int(part)]
        else:
            need(isinstance(value, dict) and part in value, "Missing result field: " + pointer)
            value = value[part]
    return value


def validate_result(path, stage_plan):
    result = read_json(path)
    fields = stage_plan["required_result_fields"]
    need(isinstance(fields, dict) and fields and "/status" in fields, "Explicit required result status/fields missing")
    for key, expected in fields.items():
        need(strict_equal(lookup_pointer(result, key), expected), "Unexpected result field: " + key)
    return result


def validate_plan(plan):
    require_python_startup()
    need(plan.get("schema") == "v71-r7-v5-three-stage-plan-v1", "Wrong plan schema")
    need(isinstance(plan.get("stages"), dict) and set(plan["stages"]) == set(STAGES), "Exactly one saved revalidation and two solve stages required")
    need(plan.get("order") == list(STAGES) and plan.get("maximum_stage_attempts") == 1 and plan.get("maximum_concurrency") == 1, "One attempt per fixed ordered stage, concurrency one")
    need(plan.get("historical_model_generations") == 3 and plan.get("maximum_future_model_generations") == 2 and plan.get("maximum_total_model_generations_including_preliminary") == 5 and plan.get("historical_raw_four_fixed_point_calls") == 0 and plan.get("maximum_future_raw_four_fixed_point_calls") == 2, "Fixed history model/raw budget")
    for name, item in plan["stages"].items():
        need(isinstance(item.get("argv"), list) and item["argv"] and all(isinstance(x, str) and "\0" not in x for x in item["argv"]), "Exact argv list required")
        need(Path(item["argv"][0]).is_absolute(), "Target executable must be absolute")
        need(identity.same_directory(item.get("cwd"), P), "Every stage cwd must be preparation root")
        env = item.get("env")
        need(isinstance(env, dict) and all(isinstance(k, str) and isinstance(v, str) and "=" not in k and "\0" not in k + v for k, v in env.items()), "Exact string environment required")
        dangerous = {"PYTHONPATH", "PYTHONHOME", "JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS", "CLASSPATH", "LD_PRELOAD"}
        need(not (set(env) & dangerous) and not any(k.startswith("DYLD_") for k in env), "Implicit code-loading environment prohibited")
        need(not any(k.startswith("PYTHON") and k not in {"PYTHONDONTWRITEBYTECODE", "PYTHONNOUSERSITE"}
                     for k in env), "Unreviewed Python environment option prohibited")
        result = relative_path(item["result_file"])
        need(result.parts[:2] == ("runs", name) and len(result.parts) >= 3, "Result must be inside its own stage folder")
        need(isinstance(item.get("required_result_fields"), dict) and "/status" in item["required_result_fields"], "Result checks required")
        limits = item.get("limits")
        required_limits = {"wall_seconds", "cpu_seconds_per_process", "rss_process_tree_bytes", "poll_seconds", "per_stream_bytes", "artifact_bytes", "artifact_file_count", "sigterm_grace_seconds", "sigkill_grace_seconds", "java_heap_bytes"}
        need(isinstance(limits, dict) and set(limits) == required_limits, "Exact limit keys required")
        for key in required_limits - {"poll_seconds"}:
            need(type(limits[key]) is int and limits[key] > 0, "Positive integer limit required")
        need(1 <= limits["wall_seconds"] <= 300 and 1 <= limits["cpu_seconds_per_process"] <= 240, "Time cap exceeds preparation scope")
        need(limits["rss_process_tree_bytes"] <= 1024 ** 3 and limits["per_stream_bytes"] <= 64 * 1024 ** 2 and limits["artifact_bytes"] <= 256 * 1024 ** 2, "Memory/output cap exceeds scope")
        need(limits["artifact_file_count"] <= 4096 and type(limits["poll_seconds"]) in (int, float) and .1 <= limits["poll_seconds"] <= 1, "Invalid file/sampling bound")
        need(limits["sigterm_grace_seconds"] == 5 and limits["sigkill_grace_seconds"] == 2 and limits["java_heap_bytes"] == 512 * 1024 ** 2, "Fixed cleanup/heap limits changed")
        if Path(item["argv"][0]).name == "java":
            need("-Xmx512m" in item["argv"] and sum(x.startswith("-Xmx") for x in item["argv"]) == 1, "One exact Java heap cap required")
        if (identity.same_file(item["argv"][0], Path(sys.executable).resolve()) or
                Path(item["argv"][0]).name.startswith("python")):
            expected_options = ["-B", "-S", "-X", "pycache_prefix=" + PYTHON_CACHE_PREFIX]
            need(item["argv"][1:5] == expected_options, "Python target requires the exact frozen startup options")
            need(all(item["argv"].count(option) == 1 for option in ("-B", "-S", "-X")) and
                 sum(value.startswith("pycache_prefix") or value.startswith("-Xpycache_prefix")
                     for value in item["argv"]) == 1, "Duplicate or alternative Python cache/startup options prohibited")
    return plan


def completed_stage(stage, plan, expected_pin=None):
    path = P / "runs" / stage / STATE_NAME
    if expected_pin is not None:
        need(identity.same_file(check_pin(expected_pin), path), "Supervisor receipt belongs to another stage")
    state = read_json(path)
    need(state.get("schema") == "v71-r7-bounded-stage-result-v1" and state.get("stage") == stage and state.get("status") == "COMPLETE_STAGE", "Prerequisite stage not complete")
    need(type(state.get("return_code")) is int and state["return_code"] == 0 and state.get("limit_reason") is None and state.get("capture_complete") is True and state.get("signals") == [], "Prerequisite has nonzero exit, limit, capture failure or signals")
    native = check_pin(state["native_result"])
    need(identity.same_file(native, P / plan["stages"][stage]["result_file"]), "Prerequisite native path changed")
    validate_result(native, plan["stages"][stage])
    return state


def validate_stage_manifest(value, stage):
    path = check_pin(value)
    folder = P / "runs" / stage
    need(identity.same_file(path, folder / MANIFEST_NAME), "Wrong stage-output manifest path")
    manifest = read_json(path)
    need(manifest.get("schema") == "v71-r7-stage-output-manifest-v1" and manifest.get("stage") == stage, "Wrong stage-output manifest")
    need(isinstance(manifest.get("files"), list) and manifest["files"], "Empty output manifest")
    expected = set()
    for member in manifest["files"]:
        p = check_pin(member)
        need(identity.file_within(p, folder) and p.name not in (STATE_NAME, MANIFEST_NAME), "Manifest member outside stage or self-referential")
        key = identity.file_key(p)
        need(key not in expected, "Duplicate physical stage manifest member")
        expected.add(key)
    excluded = {identity.file_key(folder / name) for name in (STATE_NAME, MANIFEST_NAME)}
    actual_paths = file_roster(folder)
    actual_keys = {identity.file_key(path) for path in actual_paths}
    need(len(actual_keys) == len(actual_paths) and expected == actual_keys - excluded, "Physical stage-output roster changed after gate")
    return manifest


def validate_adoption(adoption_pin, auth, plan, bundle):
    adoption = read_json(check_pin(adoption_pin))
    need(adoption.get("schema") == "v71-r7-v5-reused-gates-adoption-v1" and adoption.get("status") == "ADOPT_PRIOR_ARM_GATES_AND_SAVED_REVALIDATION", "No explicit v5 reused-gate adoption")
    for key in ("plan", "input_freeze", "prior_gate_bundle"):
        evidence.match(adoption.get(key), auth[key], check_pin, need, "Adoption binds current " + key)
    need(isinstance(adoption.get("gate_results"), dict) and set(adoption["gate_results"]) == set(ARMS), "Adoption names exactly the two original native arm gates")
    for name in ARMS:
        evidence.match(adoption["gate_results"][name], bundle["gates"][name]["native_result"], check_pin, need, "Adoption original gate " + name)
    evidence.revalidation(adoption["revalidation"], auth, plan, bundle, P, read_json, check_pin, need, file_roster)
    need(isinstance(adoption.get("qa_evidence"), list) and adoption["qa_evidence"], "Independent gate/revalidation QA evidence required")
    for item in adoption["qa_evidence"]:
        check_pin(item)
    return adoption


def validate_authorization(stage, path, expected_sha):
    path = absolute_regular(path)
    need(isinstance(expected_sha, str) and len(expected_sha) == 64 and digest(path) == expected_sha, "Authorization hash mismatch")
    auth = read_json(path)
    need(auth.get("schema") == "v71-r7-v5-root-authorization-v1", "Wrong root authorization schema")
    expected_status = "GO_SOLVE_STAGES_ONLY" if stage.startswith("solve_") else "GO_SAVED_CROSS_ONLY"
    need(auth.get("status") == expected_status, "Wrong stage authorization category")
    permitted = auth.get("authorized_stages")
    category = STAGES[1:] if stage.startswith("solve_") else GATES
    need(isinstance(permitted, list) and len(permitted) == len(set(permitted)) and stage in permitted and set(permitted) <= set(category), "Stage not explicitly authorized")
    if "expires_utc" in auth:
        expiry = dt.datetime.fromisoformat(auth["expires_utc"].replace("Z", "+00:00"))
        need(expiry.tzinfo is not None and dt.datetime.now(dt.timezone.utc) < expiry, "Authorization expired")
    plan_path, freeze_path = check_pin(auth["plan"]), check_pin(auth["input_freeze"])
    need(identity.same_file(plan_path, P / "PLAN.json") and identity.same_file(freeze_path, P / "INPUT_FREEZE.json"), "Plan/freeze must belong to this preparation folder")
    plan = validate_plan(read_json(plan_path))
    frozen = verify_freeze(read_json(freeze_path), plan)
    evidence.match(auth["prior_gate_bundle"], plan["prior_gate_bundle"], check_pin, need, "GO binds reviewed prior gate bundle")
    bundle = evidence.prior_bundle(auth["prior_gate_bundle"], P, pin(P / "B_CONFIG.json"), frozen, read_json, check_pin, need, file_roster)
    old_plan = read_json(check_pin(bundle["source_plan"]))
    for name in STAGES:
        previous = "cross_arm_gate" if name == evidence.CROSS else name
        need(strict_equal(plan["stages"][name]["limits"], old_plan["stages"][previous]["limits"]), "Every v4 per-stage limit unchanged")
    if stage.startswith("solve_"):
        validate_adoption(auth.get("gate_adoption"), auth, plan, bundle)
    if stage == "solve_S01_release":
        first = completed_stage("solve_unchanged", plan)
        validate_stage_manifest(first["output_manifest"], "solve_unchanged")
    item = plan["stages"][stage]
    argv = []
    for value in item["argv"]:
        if value == "{authorization_path}":
            value = str(path)
        elif value == "{authorization_sha256}":
            value = expected_sha
        else:
            need("{authorization_" not in value, "Only whole authorization tokens may be substituted")
        argv.append(value)
    need(identity.file_key(argv[0]) in frozen, "Unpinned executable")
    return auth, plan, item, argv


def output_size(folder):
    paths = file_roster(folder)
    return len(paths), sum(p.stat().st_size for p in paths)


def stop_direct_child(proc, state, limits):
    # Popen owns an unreaped direct child, so poll(None) cannot refer to a
    # reused PID. This fallback does not claim or signal a numeric group.
    if proc.poll() is None:
        proc.terminate()
        state["signals"].append({"pid": proc.pid, "action": "SIGTERM_OWN_UNREAPED_DIRECT_CHILD"})
        try:
            proc.wait(timeout=limits["sigterm_grace_seconds"])
        except subprocess.TimeoutExpired:
            proc.kill()
            state["signals"].append({"pid": proc.pid, "action": "SIGKILL_OWN_UNREAPED_DIRECT_CHILD"})
            proc.wait(timeout=limits["sigkill_grace_seconds"])


def cleanup(proc, root, known, state, limits):
    """Only the direct unreaped child and birth-verified descendants are signaled."""
    if root is None:
        stop_direct_child(proc, state, limits)
        state["cleanup_scope"] = "direct child only; no kernel birth was obtained"
        raise RuntimeError("Direct child reaped, but no birth identity proves complete process-tree cleanup")
    known[root["pid"]] = root
    for sig, seconds in ((signal.SIGTERM, limits["sigterm_grace_seconds"]), (signal.SIGKILL, limits["sigkill_grace_seconds"])):
        deadline = time.monotonic() + seconds
        sent = set()
        while True:
            refreshed = False
            try:
                snap = support.snapshot(root, known)
                known.update({x["pid"]: x for x in snap["processes"]})
                refreshed = True
            except Exception as error:
                state.setdefault("cleanup_refresh_errors", []).append(repr(error))
            live, reused = support.live_known(known)
            if reused:
                state.setdefault("reused_pids_not_signaled", []).extend(reused)
            if not live:
                need(refreshed, "No owned processes remain known, but process-tree refresh failed")
                return
            for expected in sorted(live, key=lambda x: (x["pid"] == root["pid"], x["start_sec"], x["start_usec"])):
                key = (expected["pid"], expected["start_sec"], expected["start_usec"])
                if key not in sent:
                    state["signals"].append(support.signal_verified(expected, sig))
                    sent.add(key)
            if time.monotonic() >= deadline:
                break
            time.sleep(min(.1, max(0, deadline - time.monotonic())))
    live, _ = support.live_known(known)
    need(not live, "Owned process cleanup remains unconfirmed")
    support.snapshot(root, known)  # Require a final complete ownership refresh.


def exec_shim(stage, auth_path, auth_sha, spawn_token):
    # Revalidate GO and all inputs within the child before replacing it.
    require_python_startup()
    resource.setrlimit(resource.RLIMIT_CPU, (240, 240))
    resource.setrlimit(resource.RLIMIT_FSIZE, (256 * 1024 ** 2, 256 * 1024 ** 2))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    _, _, item, argv = validate_authorization(stage, auth_path, auth_sha)
    reservation = read_json(P / "runs" / stage / "RESERVATION.json")
    lock = read_json(P / "RUN_LOCK.json")
    need(all(strict_equal(reservation.get(k), v) for k, v in lock.items()), "Reservation differs from active serial lock")
    need(lock.get("stage") == stage and lock.get("authorization_sha256") == auth_sha and
         lock.get("spawn_token") == spawn_token and lock.get("supervisor_pid") == os.getppid(),
         "Internal exec requires the owning supervisor and its one-shot reservation")
    parent = support.identity(os.getppid(), executable=False)
    need(support.same_birth(lock["supervisor_identity"], parent), "Supervisor parent birth changed")
    limits = item["limits"]
    resource.setrlimit(resource.RLIMIT_CPU, (limits["cpu_seconds_per_process"], limits["cpu_seconds_per_process"]))
    resource.setrlimit(resource.RLIMIT_FSIZE, (limits["artifact_bytes"], limits["artifact_bytes"]))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    os.chdir(item["cwd"])
    os.execve(argv[0], argv, item["env"])


def supervise(stage, auth_path, auth_sha):
    require_python_startup()
    auth, plan, item, target_argv = validate_authorization(stage, auth_path, auth_sha)
    limits = item["limits"]
    runs = P / "runs"
    runs.mkdir(exist_ok=True)
    need(identity.same_directory(runs, runs.resolve()), "Unsafe runs directory")
    output = runs / stage
    # An existing stage directory consumes the attempt even after failure.
    need(not output.exists(), "This stage already has an attempt; automatic retry forbidden")
    lock = P / "RUN_LOCK.json"
    token = {"stage": stage, "supervisor_pid": os.getpid(), "created_utc": now(), "authorization_sha256": auth_sha,
             "spawn_token": secrets.token_hex(24), "supervisor_identity": support.identity(os.getpid(), executable=False)}
    need(token["supervisor_identity"] is not None, "Cannot identify supervisor birth")
    fd = os.open(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(token, f, ensure_ascii=False)
        f.flush()
        os.fsync(f.fileno())
    state = {"schema": "v71-r7-bounded-stage-result-v1", "stage": stage, "status": "STARTING",
             "created_utc": now(), "authorization": pin(auth_path), "plan": auth["plan"],
             "input_freeze": auth["input_freeze"], "prior_gate_bundle": auth["prior_gate_bundle"], "target_argv": target_argv,
             "environment": item["env"], "limits": limits, "signals": [],
             "return_code": None, "limit_reason": None, "capture_complete": False,
             "sampled_peak_process_tree_rss_bytes": None, "sample_count": 0, "live_rss_sample_count": 0,
             "resource_scope": "CPU RLIMIT is per process, including threads and inherited after exec, not an aggregate tree budget. RSS and total artifact limits are sampled, not instantaneous peaks. RLIMIT_FSIZE is a per-file kernel cap. Java heap cap is separate from RSS.",
             "native_result": None, "output_manifest": None}
    proc = None
    root = None
    output_created = False
    known = {}
    threads = []
    capture_failure = threading.Event()
    capture_lock = threading.Lock()
    counts = {"stdout": 0, "stderr": 0}
    capture_errors = {}
    emergency = False
    started = time.monotonic()

    def reader(pipe, name):
        try:
            with (output / (name + ".txt")).open("xb") as stream:
                while chunk := pipe.read(65536):
                    with capture_lock:
                        before = counts[name]
                        counts[name] += len(chunk)
                    stream.write(chunk[:max(0, limits["per_stream_bytes"] - before)])
                    if counts[name] > limits["per_stream_bytes"]:
                        capture_failure.set()
                stream.flush()
                os.fsync(stream.fileno())
        except BaseException as error:
            with capture_lock:
                capture_errors[name] = repr(error)
            capture_failure.set()
        finally:
            pipe.close()

    try:
        output.mkdir(exist_ok=False)
        output_created = True
        save(output / "RESERVATION.json", {**token, "attempt": 1, "maximum_concurrency": 1})
        save(output / STATE_NAME, state)
        launch_argv = [str(Path(sys.executable).resolve()), "-B", "-S", "-X",
                       "pycache_prefix=" + PYTHON_CACHE_PREFIX, str(Path(__file__).resolve()),
                       "_limit_exec", stage, "--authorization", str(auth_path),
                       "--authorization-sha256", auth_sha, "--spawn-token", token["spawn_token"]]
        state["launch_argv"] = launch_argv
        # Empty inheritance: the exact stage environment is used for both
        # shim and target. -B prevents cache writes; -X redirects cache reads
        # into the existing, frozen, entirely empty directory checked above.
        proc = subprocess.Popen(launch_argv, cwd=P, env=item["env"], stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
        state["pid"] = proc.pid
        root = support.identity(proc.pid)
        if root is not None:
            need(root["uid"] == os.getuid() and root["pgid"] == proc.pid, "Child is not in its new owned session group")
            known[root["pid"]] = root
            state["owned_root"] = root
        for name, pipe in (("stdout", proc.stdout), ("stderr", proc.stderr)):
            thread = threading.Thread(target=reader, args=(pipe, name), daemon=True)
            thread.start()
            threads.append(thread)
        state["status"] = "RUNNING"
        save(output / STATE_NAME, state)
        while proc.poll() is None:
            elapsed = time.monotonic() - started
            if capture_failure.is_set():
                state["limit_reason"] = "output_capture_error_or_per_stream_limit"
            elif elapsed >= limits["wall_seconds"]:
                state["limit_reason"] = "wall_seconds"
            if root is None:
                root = support.identity(proc.pid)
                if root is not None:
                    need(root["uid"] == os.getuid() and root["pgid"] == proc.pid, "Child group identity mismatch")
                    known[root["pid"]] = root
                    state["owned_root"] = root
            if root is not None:
                snap = support.snapshot(root, known)
                known.update({x["pid"]: x for x in snap["processes"]})
                state["last_snapshot"] = snap
                if snap["live_processes"]:
                    previous = state["sampled_peak_process_tree_rss_bytes"]
                    state["sampled_peak_process_tree_rss_bytes"] = max(previous or 0, snap["rss_bytes"])
                    state["live_rss_sample_count"] += 1
                state["sample_count"] += 1
                if snap["rss_bytes"] > limits["rss_process_tree_bytes"]:
                    state["limit_reason"] = "sampled_process_tree_rss_bytes"
                with (output / "RSS_SAMPLES.jsonl").open("a") as f:
                    f.write(json.dumps({"at": now(), "elapsed_seconds": elapsed, **snap}) + "\n")
            count, total = output_size(output)
            if count > limits["artifact_file_count"] or total > limits["artifact_bytes"]:
                state["limit_reason"] = "sampled_artifact_size_or_count"
            if state["limit_reason"]:
                cleanup(proc, root, known, state, limits)
                break
            time.sleep(limits["poll_seconds"])
        # This actual wait value, not a native completion marker, is the
        # authoritative OS exit status. A normal root disappearance above
        # never throws solely because it exited during a snapshot.
        state["return_code"] = proc.wait(timeout=limits["sigkill_grace_seconds"] + 1)
        state["process_elapsed_seconds"] = time.monotonic() - started
        if state["process_elapsed_seconds"] > limits["wall_seconds"]:
            state["limit_reason"] = state["limit_reason"] or "wall_seconds_at_reap"
        need(root is not None, "No kernel process birth was captured; tree supervision is unverified")
        if root is not None:
            snap = support.snapshot(root, known)
            known.update({x["pid"]: x for x in snap["processes"]})
            if snap["live_processes"]:
                state["limit_reason"] = state["limit_reason"] or "surviving_descendants_after_root_exit"
                cleanup(proc, root, known, state, limits)
        for thread in threads:
            thread.join(2)
        state["capture_complete"] = not any(t.is_alive() for t in threads) and not capture_failure.is_set()
        if not state["capture_complete"]:
            state["limit_reason"] = state["limit_reason"] or "capture_incomplete_or_limit"
            if any(t.is_alive() for t in threads):
                emergency = True
        count, total = output_size(output)
        if count > limits["artifact_file_count"] or total > limits["artifact_bytes"]:
            state["limit_reason"] = state["limit_reason"] or "final_artifact_size_or_count"
        need(not state["limit_reason"] and state["return_code"] == 0 and state["signals"] == [], "Stage incomplete, limited, signaled or nonzero exit")
        result_path = P / item["result_file"]
        validate_result(result_path, item)
        state["native_result"] = pin(result_path)
        # Rehash the authorization and all frozen input files after exit.
        # Subsequent phases are forbidden when a run modified its inputs.
        validate_authorization(stage, auth_path, auth_sha)
        need(not any(p.name.endswith(".tmp") for p in file_roster(output)), "Unfinished temporary output remains")
        state["status"] = "COMPLETE_STAGE"
    except BaseException as error:
        state["status"] = "UNKNOWN_STAGE"
        state["exception"] = repr(error)
        if proc is not None:
            try:
                cleanup(proc, root, known, state, limits)
            except BaseException as cleanup_error:
                state["status"] = "EMERGENCY_OWNED_PROCESS_STOP_UNCONFIRMED"
                state["cleanup_error"] = repr(cleanup_error)
                emergency = True
                try:
                    stop_direct_child(proc, state, limits)
                except BaseException as direct_error:
                    state["direct_child_stop_error"] = repr(direct_error)
            # Reap our actual Popen child independently of tree-inspection
            # success. An inspection race must not erase an available exit.
            try:
                state["return_code"] = proc.wait(timeout=3)
            except BaseException as reap_error:
                state["status"] = "EMERGENCY_OWNED_PROCESS_STOP_UNCONFIRMED"
                state["reap_error"] = repr(reap_error)
                emergency = True
        for thread in threads:
            thread.join(2)
        state["capture_complete"] = bool(threads) and not any(t.is_alive() for t in threads) and not capture_failure.is_set()
        if any(t.is_alive() for t in threads):
            emergency = True
    finally:
        state["finished_utc"] = now()
        state["elapsed_seconds"] = time.monotonic() - started
        with capture_lock:
            state["stream_bytes"] = dict(counts)
            state["capture_errors"] = dict(capture_errors)
        if output_created:
            try:
                members = [pin(p) for p in file_roster(output)
                           if not (p.name in (STATE_NAME, MANIFEST_NAME, STATE_NAME + ".tmp")
                                   and identity.same_directory(p.parent, output))]
                manifest = {"schema": "v71-r7-stage-output-manifest-v1", "stage": stage,
                            "created_utc": now(), "files": members,
                            "excluded_cycle_files": [STATE_NAME, MANIFEST_NAME]}
                save(output / MANIFEST_NAME, manifest)
                state["output_manifest"] = pin(output / MANIFEST_NAME)
                save(output / STATE_NAME, state)
                count, total = output_size(output)
                if count > limits["artifact_file_count"] or total > limits["artifact_bytes"]:
                    state["status"] = "UNKNOWN_STAGE"
                    state["limit_reason"] = state["limit_reason"] or "final_receipts_exceed_artifact_limit"
                    save(output / STATE_NAME, state)
            except BaseException as receipt_error:
                state["status"] = "UNKNOWN_RECEIPT_PERSISTENCE"
                state["receipt_error"] = repr(receipt_error)
                emergency = True  # Keep the lock for explicit inspection.
                try:
                    save(output / STATE_NAME, state)
                except BaseException:
                    pass
        if not emergency:
            try:
                need(read_json(lock) == token, "Run lock ownership changed")
                lock.unlink()
            except BaseException as lock_error:
                state["status"] = "UNKNOWN_LOCK_RELEASE"
                state["lock_error"] = repr(lock_error)
                if output_created:
                    save(output / STATE_NAME, state)
        print(json.dumps({k: state.get(k) for k in (
            "stage", "status", "return_code", "limit_reason", "elapsed_seconds",
            "sampled_peak_process_tree_rss_bytes", "capture_complete", "exception")}, ensure_ascii=False), flush=True)
    return 0 if state["status"] == "COMPLETE_STAGE" else 2


def main():
    arguments = list(sys.argv[1:])
    internal = bool(arguments and arguments[0] == "_limit_exec")
    if internal:
        arguments.pop(0)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=STAGES)
    parser.add_argument("--authorization", type=Path, required=True)
    parser.add_argument("--authorization-sha256", required=True)
    if internal:
        parser.add_argument("--spawn-token", required=True, help=argparse.SUPPRESS)
    args = parser.parse_args(arguments)
    if internal:
        exec_shim(args.stage, args.authorization, args.authorization_sha256, args.spawn_token)
        raise RuntimeError("execve returned unexpectedly")
    return supervise(args.stage, args.authorization, args.authorization_sha256)


if __name__ == "__main__":
    raise SystemExit(main())
