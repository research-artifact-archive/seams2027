"""Physical path identity for already-existing, pinned local files.

Import defines functions only. No normalization of Unicode is used as identity.
Callers retain original path spellings and separately verify bytes and SHA256.
This is a controlled local-filesystem contract, not an adversarial race barrier.
"""
from __future__ import annotations

import os
from pathlib import Path
import stat


def _checked(path, directory):
    value = Path(path)
    if not value.is_absolute() or any(part in (".", "..") for part in value.parts):
        raise ValueError("Absolute path without traversal components required")
    # Check every component so samefile does not silently relax the existing
    # no-symlink input policy. Unicode aliases of the same component are fine.
    for index, component in enumerate((value, *value.parents)):
        info = os.lstat(component)
        if stat.S_ISLNK(info.st_mode):
            raise ValueError("Symbolic-link path component prohibited: " + str(component))
        if index and not stat.S_ISDIR(info.st_mode):
            raise ValueError("Non-directory parent component")
    info = os.stat(value, follow_symlinks=False)
    if not (stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)):
        raise ValueError("Canonical directory required" if directory else "Canonical regular file required")
    resolved = value.resolve(strict=True)
    resolved_info = os.stat(resolved, follow_symlinks=False)
    if (info.st_dev, info.st_ino) != (resolved_info.st_dev, resolved_info.st_ino) or not os.path.samefile(value, resolved):
        raise ValueError("Resolved path identity differs")
    return value, info


def canonical_file(path):
    return _checked(path, False)[0]


def canonical_directory(path):
    return _checked(path, True)[0]


def file_key(path):
    _, info = _checked(path, False)
    return info.st_dev, info.st_ino


def directory_key(path):
    _, info = _checked(path, True)
    return info.st_dev, info.st_ino


def same_file(left, right):
    a, sa = _checked(left, False)
    b, sb = _checked(right, False)
    return (sa.st_dev, sa.st_ino) == (sb.st_dev, sb.st_ino) and os.path.samefile(a, b)


def same_directory(left, right):
    a, sa = _checked(left, True)
    b, sb = _checked(right, True)
    return (sa.st_dev, sa.st_ino) == (sb.st_dev, sb.st_ino) and os.path.samefile(a, b)


def file_within(path, folder):
    value, _ = _checked(path, False)
    root, root_info = _checked(folder, True)
    wanted = root_info.st_dev, root_info.st_ino
    # Existing ancestor directories are compared by physical identity, never
    # by lexical prefix/is_relative_to. _checked rejected all symlink parents.
    for parent in value.parents:
        info = os.stat(parent, follow_symlinks=False)
        if not stat.S_ISDIR(info.st_mode):
            raise ValueError("Non-directory ancestor")
        if (info.st_dev, info.st_ino) == wanted and os.path.samefile(parent, root):
            return True
    return False


def same_file_pin(left, right):
    for item in (left, right):
        if not isinstance(item, dict) or set(item) != {"path", "bytes", "sha256"}:
            raise ValueError("Exact file-pin keys required")
        if not isinstance(item["path"], str) or type(item["bytes"]) is not int or item["bytes"] < 0:
            raise ValueError("String path and nonnegative integer byte count required")
        digest = item["sha256"]
        if not isinstance(digest, str) or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
            raise ValueError("Lowercase SHA256 required")
    # This compares pin metadata and physical identity; the caller's pin reader
    # still hashes actual bytes. Equal content in different files is rejected.
    return (left["bytes"] == right["bytes"] and left["sha256"] == right["sha256"]
            and same_file(left["path"], right["path"]))
