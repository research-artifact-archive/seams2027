#!/usr/bin/env python3
"""Static integrity only; no prepared modules, scientific evaluation or subprocess."""
import base64, hashlib, json, pathlib, sys, zipfile

PREFIX='r7_same_solver_diagnostic/'
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    root=pathlib.Path(__file__).resolve().parent
    archive=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else None
    if archive:
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
            names=z.namelist();assert len(names)==len(set(names))
            assert all(n.startswith(PREFIX) and '..' not in pathlib.PurePosixPath(n).parts and not n.endswith('/') for n in names)
            files={n:z.read(n) for n in names}
    else:files={PREFIX+str(p.relative_to(root)):p.read_bytes() for p in root.rglob('*') if p.is_file()}
    checks=0
    def require(ok,label):
        nonlocal checks
        assert ok,label;checks+=1
    def read(member):return json.loads(files[member if member.startswith(PREFIX) else PREFIX+member])
    def pinok(member,p):
        b=files[member];require(len(b)==p['bytes'] and sha(b)==p['sha256'],member)
    manifest=read('MANIFEST.json')
    require(manifest['evidence_id']=='AF-R7-SAME-SOLVER-DIAGNOSTIC','evidence ID')
    roster=[r['member'] for r in manifest['files']]
    require(len(roster)==len(set(roster)),'manifest unique')
    require(set(roster)|{PREFIX+'MANIFEST.json'}==set(files),'exact archive roster')
    for r in manifest['files']:pinok(r['member'],r)
    ledger=read('TRANSFORMATION_LEDGER.json')
    require({r['member'] for r in ledger['files']}==set(files)-{PREFIX+'MANIFEST.json',PREFIX+'TRANSFORMATION_LEDGER.json'},'ledger roster')
    for r in ledger['files']:
        pinok(r['member'],r['public'])
        if r['representation']=='exact_original':require(r['original']==r['public'] and not r['transformations'],'exact original')
        if r['representation']=='disclosed_derivative':require(r['original'] is not None and bool(r['transformations']),'declared derivative')
    mapping=read('inputs/ORIGINAL_TO_PUBLIC.json')['rows']
    for r in mapping:
        if r['member']:
            pinok(r['member'],r['public'])
            if r['representation']=='exact_original':require(r['original']==r['public'],'mapping exact')
    fixed=read('inputs/FIXED_INPUT_BINDINGS.json')
    require(len(fixed['rows'])==1377,'1377 fixed inputs')
    require([r['input_id'] for r in fixed['rows']]==[f'F{i:04d}' for i in range(1,1378)],'fixed input order')
    require(len(fixed['directory_rosters'])==12,'12 rosters')
    require(len(fixed['runtime_aliases'])==3,'3 runtime aliases')
    require(len(fixed['observed_path_aliases'])==2,'2 observed Unicode alias records')
    for r in fixed['rows']:
        if r['member']:
            require(r['member'] in files,'fixed member')
            if r['availability']=='included_exact':pinok(r['member'],r['original'])
        else:require(r['recipe_member'] in files,'dependency/withheld recipe')
    source=read('source/SOURCE_INDEX.json')
    require(bool(source['rows']),'source roster')
    for r in source['rows']:pinok(r['member'],r['original']);require(r['public']==r['original'],'unchanged source bytes')
    # Inspect parsed JSONL data, not code identifier literals or string mentions.
    identifiers={'pid','ppid','pgid','uid','device','inode','owned_root'}
    def no_host_fields(x):
        if isinstance(x,dict):
            require(not (set(x)&identifiers),'private JSONL host identifier fields')
            for v in x.values():no_host_fields(v)
        elif isinstance(x,list):
            for v in x:no_host_fields(v)
    jsonl_members=[m for m in files if m.endswith('.jsonl')]
    require(len(jsonl_members)==7,'seven retained RSS JSONL files')
    for member in jsonl_members:
        lines=files[member].splitlines();require(bool(lines) and all(lines),'JSONL line retention')
        for line in lines:no_host_fields(json.loads(line))
    dependency=read('dependencies/DEPENDENCIES.json')
    for member in dependency['public_auxiliary_members'].values():
        if isinstance(member,list):require(all(m in files for m in member),'license members')
        else:require(member in files,'current dependency auxiliary member')
    recipe=read('dependencies/SOURCE_RESTORATION.json')
    require(recipe['schema']=='v71-r8-diagnostic-source-restoration-six-routes-v1','current R8 recipe')
    require(recipe['status']=='R8_CURRENT_RESTORATION_RECIPE_NO_SCIENTIFIC_EXECUTION' and recipe['route_count']==6 and len(recipe['routes'])==6,'six current routes, no execution')
    require(sorted(r['original']['bytes'] for r in recipe['routes'])==[1902,2026,2026,2026,2026,2026],'one projection/five retained copies')
    require(all(r['bundled'] is False for r in recipe['historical_references']),'historical R6 reader docs unbundled')
    class_members=[m for m in files if m.endswith('.class')]
    notice=files[PREFIX+'dependencies/THIRD_PARTY_NOTICES.md'].decode()
    require(str(len(class_members))+' original compiled harness/helper class members' in notice,'notice class count matches archive')
    require('six-route recipe' in notice and 'No Eclipse/Spectra JAR, compiled class' not in notice,'correct included/excluded notice')
    require('replay/VERIFICATION_ADDENDUM.txt' not in notice and 'replay/records/RESTORATION_RECEIPT.json' not in files[PREFIX+'dependencies/SOURCE_RESTORATION.json'].decode(),'no stale local replay links')
    refs=read('inputs/REFERENCE_DISPOSITIONS.json')['rows']
    require(len(refs)==50 and sum(bool(r['matching_original_ids']) for r in refs)==12,'50 refs/12 explicit matches')
    byid={r['original_id']:r for r in mapping}
    for ref in refs:
        require(ref['historical_path_identity_asserted'] is False,'no inferred path identity')
        for ident in ref['matching_original_ids']:require(byid[ident]['original']==ref['original'],'same-pinned-content reference')
        for representation in ref['available_representations']:
            if representation['member']:pinok(representation['member'],representation['public'])
    gui=next(r for r in refs if r['reference_id']=='REF035')
    require(gui['current_location_observation']['matches_historical_pin'] is False and gui['current_location_observation']['historical_bytes_available_at_current_location'] is False,'historical GUI bytes unavailable explicitly')
    history=read('records/HISTORY.json')
    events=history['events']
    require([r['event_id'] for r in events]==['rev3_gate_unchanged','v4_gate_unchanged','v4_gate_S01_release','v4_cross_arm_gate','v5_cross_arm_gate_revalidation','v5_solve_unchanged','v5_solve_S01_release'],'seven events')
    require([r['disposition'] for r in events]==['COMPLETE','COMPLETE','COMPLETE','UNKNOWN','COMPLETE','COMPLETE','UNKNOWN'],'honest event statuses')
    require(history['v4_unrun_solves']['status']=='NOT_RUN_AFTER_ORIGINAL_V4_CROSS_UNKNOWN','v4 not run')
    require(history['budget']['total_models']==5 and history['budget']['raw_calls_entered']==2 and history['budget']['raw_calls_returned']==1,'history budget')
    require(history['scientific_result']['unchanged']['outcome'] is False and history['scientific_result']['S01_release']['outcome']=='UNKNOWN','adopted outcomes')
    observations={}
    for e in events:
        for member in e['public_record_members']:require(member in files,'event member')
        # Member order follows native, supervisor, manifest, launch.
        native=read(e['public_record_members'][0]);sup=read(e['public_record_members'][1])
        if e['event_id']=='v4_cross_arm_gate':require(sup['status']=='UNKNOWN_STAGE','original failed cross')
        if e['event_id']=='v5_cross_arm_gate_revalidation':require(sup['status']=='COMPLETE_STAGE' and native['status']=='PASS_CROSS_ARM_SAVED_PREDICATE_GATE','actual completed revalidation')
        if e['event_id'].startswith('v5_solve'):
            observations[e['stage']]=(native,sup)
            require(native['model_generations']==1 and native['raw_four_fixed_point_calls']==1 and native['winning_region_computations']==1,'call entry counters')
            require(sup['capture_complete'] is True,'complete supervisor encoded pipes')
    n,s=observations['solve_unchanged'];require(n['realizable'] is False and s['status']=='COMPLETE_STAGE','unchanged complete false')
    n,s=observations['solve_S01_release'];require('realizable' not in n and n['failed_stage']=='ONE_RAW_FOUR_FP_CALL_BEGIN' and s['status']=='UNKNOWN_STAGE','no S01 Boolean')
    require('RAW_STDOUT_CAP' in str(n['exception']),'observed cap failure')
    captures=read('records/CAPTURE_INTEGRITY.json')['captures']
    for c in captures:
        data=files[c['member']];dictionary={};h=hashlib.sha256();size=0;terminal=None;records=[]
        for line in data.splitlines():
            r=json.loads(line);records.append(r)
            if r['kind']=='dictionary':dictionary[r['id']]=base64.b64decode(r['data'],validate=True);continue
            if r['kind']=='end':terminal=r;continue
            if r['kind']=='bytes':chunk=base64.b64decode(r['data'],validate=True);count=1
            elif r['kind']=='repeat':chunk=dictionary[r['id']];count=r['count']
            else:raise AssertionError('unsupported capture framing')
            require(not any(t in chunk for t in (b'/Users/',b'Bearer ',b'AKIA')),'decoded privacy tokens')
            while count:
                k=min(count,10000);v=chunk*k;h.update(v);size+=len(v);count-=k
        require(size==c['raw_bytes'] and h.hexdigest()==c['raw_sha256'],'decoded stream pin')
        require(terminal and terminal['raw_bytes']==size and len(records)==c['record_count'],'capture terminal')
        if c.get('stage')=='solve_unchanged':require(size==62483773 and c['native_capture_complete'] is True,'complete unchanged stream')
        if c.get('stage')=='solve_S01_release':require(size==67108819 and c['native_capture_complete'] is False and c['raw_cap_bytes']==67108864,'S01 prefix only')
    for member,b in files.items():
        # The verifier's own literal patterns are not private data.
        if member.endswith('/verify_integrity.py'):continue
        require(not any(t in b for t in (b'/Users/',b'/private/var/',b'Bearer ',b'AKIA',b'-----BEGIN PRIVATE KEY')),'privacy tokens: '+member)
    print(json.dumps({'status':'PASS_STATIC_INTEGRITY_ONLY','members':len(files),'checks':checks,'fixed_inputs':1377,'history_events':7,'science_executed':False,'independent_privacy_QA_or_root_package_adoption':False},sort_keys=True))

if __name__=='__main__':main()
