# R8 diagnostic third-party boundary

This notice applies to AF-R7-SAME-SOLVER-DIAGNOSTIC, the private R8 diagnostic
publication candidate. It does not grant rights to third-party software or inputs.

The package contains 64 original compiled harness/helper class members,
their available original Java/Python sources, and saved research evidence. It
does not contain complete Eclipse/Spectra JARs, external runtime installations,
the distributor specifications ZIP, publisher PDFs, or full upstream specification
bodies. The source index and manifest enumerate the exact included members.

SOURCE_RESTORATION.json is the current six-route recipe: one1902-byte ordinary
projection and five2026-byte retained copies. The supplied124-byte retained-point
appendix is exact original study material. The official source ZIP/member pins,
source byte ranges and output hashes are explicit. No license/readme/notice member
was found in the prior inspected official ZIP; absence is not a rights grant.
Obtain upstream inputs separately under distributor terms.

DEPENDENCIES.json records actual prior distributor URLs, acquisition receipts,
observed license metadata and exact existing-host runtime pins. Several released
Spectra bundles lack embedded license notices; no blanket license is asserted.
Runtime license texts are included as identified historical dependency evidence.
Original artifact licensing does not extend to third-party code or installations.

This candidate performed saved-byte construction/hash checks only. It performed
no source execution, solver/checker replay, new network fetch, portable-adapter
execution or fresh-host validation. Current remote availability was not checked.
Earlier R6 five-input/replay documents remain private historical references with
original pins in SOURCE_RESTORATION.json; they are not this package's current
notice or recipe. No local R6 replay record is implied to be bundled here.
