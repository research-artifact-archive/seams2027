AF-R7-SAME-SOLVER-DIAGNOSTIC
Exact-B same released solver diagnostic, 2026-10-26 candidate v1 errata01.

Observed: unchanged=false (complete); typed S01 release=UNKNOWN. The second call
stopped at RAW_STDOUT_CAP before a Boolean return. The intervention effect remains
unresolved. This is not a completed causal comparison.

Start with REPRODUCTION.txt, records/HISTORY.json and records/CAPTURE_INTEGRITY.json.
inputs/ORIGINAL_TO_PUBLIC.json maps every selected original to exact public bytes
or an explicit dependency/withheld-provenance disposition. Scientific predicate
files are exact bytes; JSON record views with symbolic paths are derivatives.
source/SOURCE_INDEX.json identifies exact original source/class files.
MANIFEST.json and verify_integrity.py provide static byte checks only.
inputs/REFERENCE_DISPOSITIONS.json explains50 historical nested references,
including private/unavailable records and content matches without path identity.

This local private candidate awaits independent privacy/integrity QA and root
public-input/package adoption. No publication, relocated replay or fresh-host
validation is represented. No release URL, DOI or tag is assigned here.
