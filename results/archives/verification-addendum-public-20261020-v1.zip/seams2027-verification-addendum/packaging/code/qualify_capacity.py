"""Generated-plan checks for the combined 96 MiB reader reservation."""
from pathlib import Path
import hashlib
import importlib.util
import json
from collections import namedtuple

HERE = Path(__file__).resolve().parent
OUT = HERE / 'capacity_fixtures'

def need(ok, message):
    if not ok:
        raise ValueError(message)

def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def main():
    need(not OUT.exists(), 'Fresh generated capacity fixtures')
    spec = importlib.util.spec_from_file_location('qualified_combined_builder', HERE / 'build_zip.py')
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    OUT.mkdir()
    toy = OUT / 'toy.txt'
    toy.write_bytes(b'generated capacity fixture\n')
    plan = OUT / 'toy_plan.json'
    plan.write_text(json.dumps({'schema': 'outer-zip-build-plan-v1', 'status': 'PREPARED_NOT_ZIP_BUILD_GO', 'top_directory': builder.archive.TOP,
                               'files': [{'file': 'toy.txt', 'source': str(toy), **identity(toy.read_bytes())}], 'source_code': []}) + '\n')
    first = builder.measure(plan)
    need(first['consumer_output_reserve_bytes'] == 96 * 1024 ** 2, 'Combined reservation96MiB')
    need(sum(first['consumer_reserve_breakdown'].values()) == first['consumer_output_reserve_bytes'], 'Breakdown exact sum')
    fixed = first['predicted_zip_bytes'] + first['fresh_file_allocation_estimate_bytes'] + first['directory_reservation_bytes'] + first['consumer_output_reserve_bytes']
    usage = namedtuple('usage', 'total used free')
    original = builder.shutil.disk_usage
    try:
        builder.shutil.disk_usage = lambda path: usage(3 * builder.FLOOR, 0, builder.FLOOR + fixed - 1)
        below = builder.measure(plan)
        need(below['normal_extraction_fits_estimate'] is False and below['after_zip_and_fresh_extraction_and_consumer_reserve'] == builder.FLOOR - 1, 'Below floor rejected')
        builder.shutil.disk_usage = lambda path: usage(3 * builder.FLOOR, 0, builder.FLOOR + fixed)
        exact = builder.measure(plan)
        need(exact['normal_extraction_fits_estimate'] is True and exact['after_zip_and_fresh_extraction_and_consumer_reserve'] == builder.FLOOR, 'Exact floor accepted')
    finally:
        builder.shutil.disk_usage = original
    report = {'schema': 'combined-reader-capacity-artificial-qualification-v1', 'status': 'PASS', 'checks': 4,
              'tests': ['reserve96MiB', 'exact_breakdown_sum', 'one_byte_below_floor_rejected', 'exact_floor_accepted'],
              'source_code': [{'file': name, **identity((HERE / name).read_bytes())} for name in ['build_zip.py', 'verify_archive.py', 'qualify_capacity.py']],
              'scientific_imports': 0, 'saved_evaluations': 0, 'native_calls': 0, 'final_ZIP_created': False}
    raw = (json.dumps(report, indent=2) + '\n').encode()
    (HERE / 'CAPACITY_QUALIFICATION.json').write_bytes(raw)
    print(json.dumps({'status': 'PASS', 'checks': 4, 'report': identity(raw)}))

if __name__ == '__main__':
    main()
