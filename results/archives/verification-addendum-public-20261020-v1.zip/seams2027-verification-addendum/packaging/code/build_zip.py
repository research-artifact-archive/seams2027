"""Measure or build the reviewed archive directly from immutable inputs."""
import argparse
import gzip
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import stat
import sys
import zipfile
import zlib
sys.path.insert(0, str(Path(__file__).resolve().parent))
import verify_archive as archive

B = Path(__file__).resolve().parent
FLOOR = 1024 ** 3
ZIP_LIMIT = 128 * 1024 ** 2
RESERVE = 2 * 1024 ** 2

def need(ok, message):
    if not ok: raise ValueError(message)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def pin(path):
    raw = Path(path).read_bytes()
    return {'bytes': len(raw), 'sha256': sha(raw)}
def read(path):
    raw = Path(path).read_bytes()
    if Path(path).suffix == '.gz': raw = gzip.decompress(raw)
    need(len(raw) <= 32 * 1024 ** 2, 'Plan/GO metadata size cap')
    return json.loads(raw)
def raw_input(row):
    p = Path(row['source'])
    need(p.is_file() and not p.is_symlink() and p.absolute() == p.resolve(), 'Noncanonical plan input')
    raw = p.read_bytes()
    need({'bytes': len(raw), 'sha256': sha(raw)} == {k: row[k] for k in ('bytes', 'sha256')}, 'Plan input changed')
    return raw
def checked_plan(path):
    plan = read(path)
    need(plan['schema'] == 'outer-zip-build-plan-v1' and plan['status'] == 'PREPARED_NOT_ZIP_BUILD_GO', 'Plan schema/status')
    need(plan['top_directory'] == archive.TOP, 'Top directory mismatch')
    need(0 < len(plan['files']) <= archive.MAX_FILES, 'Plan file count cap')
    names = [archive.safe_name(archive.TOP + '/' + r['file']) for r in plan['files']]
    need(len(set(names)) == len(names), 'Duplicate planned member')
    need(sum(r['bytes'] for r in plan['files']) <= archive.MAX_TOTAL, 'Plan total cap')
    for row in plan['files']: need(0 <= row['bytes'] <= archive.MAX_FILE, 'Plan file cap')
    for row in plan['source_code']:
        need(pin(row['path']) == {k: row[k] for k in ('bytes', 'sha256')}, 'Builder code changed after preparation')
    return plan
def compression(row): return zipfile.ZIP_STORED if row['file'].endswith(('.gz', '.zip')) else zipfile.ZIP_DEFLATED
def measure(plan_path):
    plan = checked_plan(plan_path)
    zip_bytes = 22
    allocation = 0
    directories = set()
    for row in plan['files']:
        raw = raw_input(row)
        name = archive.TOP + '/' + row['file']
        if compression(row) == zipfile.ZIP_STORED: compressed = len(raw)
        else:
            compressor = zlib.compressobj(9, zlib.DEFLATED, -15)
            compressed = len(compressor.compress(raw)) + len(compressor.flush())
        zip_bytes += compressed + 30 + 46 + 2 * len(name.encode('utf-8'))
        allocation += ((len(raw) + 4095) // 4096) * 4096
        directories.update(str(p) for p in PurePosixPath(name).parents if str(p) != '.')
    need(zip_bytes <= ZIP_LIMIT, 'ZIP bound exceeded')
    free = shutil.disk_usage(B).free
    directory_bytes = (len(directories) + 1) * 4096
    consumer_reserve = 96 * 1024 ** 2
    return {'schema': 'outer-prebuild-capacity-v1', 'status': 'MEASURED_NO_ZIP_CREATED',
            'build_plan': {'path': str(plan_path), **pin(plan_path)},
            'predicted_zip_bytes': zip_bytes, 'prediction_method': 'Exact input raw-DEFLATE9 or stored sizes plus seekable ZIP local/central headers and EOCD; actual ZIP is verified separately.',
            'file_members': len(plan['files']), 'decoded_member_bytes': sum(r['bytes'] for r in plan['files']),
            'fresh_file_allocation_estimate_bytes': allocation,
            'directory_reservation_bytes': directory_bytes,
            'consumer_output_reserve_bytes': consumer_reserve,
            'consumer_reserve_breakdown': {'retained_output_and_helper_phase_peak': 80 * 1024 ** 2,
                                           'request_and_receipt_margin': 16 * 1024 ** 2},
            'free_bytes_now': free, 'minimum_free_bytes': FLOOR,
            'after_zip_and_fresh_extraction_and_consumer_reserve': free - zip_bytes - allocation - directory_bytes - consumer_reserve,
            'normal_extraction_fits_estimate': free - zip_bytes - allocation - directory_bytes - consumer_reserve >= FLOOR,
            'zip_build_alone_fits': free >= FLOOR + zip_bytes + RESERVE,
            'scientific_computations': 0, 'cleanup_performed': False}
def save_fresh(path, obj):
    raw = (json.dumps(obj, indent=2, ensure_ascii=False) + '\n').encode()
    need(shutil.disk_usage(path.parent).free >= FLOOR + len(raw), 'Receipt free floor')
    with path.open('xb') as f: f.write(raw)
def build(plan_path, go_path, receipt_path):
    plan = checked_plan(plan_path)
    go = read(go_path)
    need(go['schema'] == 'outer-zip-build-go-v1' and go['status'] == 'GO' and go['authority'] == 'Root', 'Exact Root ZIP GO required')
    need(go['build_plan'] == {'path': str(plan_path), **pin(plan_path)}, 'GO plan binding')
    need(datetime.now(timezone.utc) < datetime.fromisoformat(go['expires_utc'].replace('Z', '+00:00')), 'Expired ZIP GO')
    need(go['top_directory'] == archive.TOP and go['minimum_free_bytes'] == FLOOR, 'GO boundaries')
    target = archive.canonical(go['zip_path'], False)
    need(target.name == plan['zip_basename'], 'GO basename mismatch')
    receipt = archive.canonical(receipt_path, False)
    need(target != receipt, 'ZIP/receipt path collision')
    capacity = measure(plan_path)
    need(capacity['zip_build_alone_fits'], 'ZIP cannot preserve the free floor')
    free_before = shutil.disk_usage(target.parent).free
    need(free_before >= FLOOR + capacity['predicted_zip_bytes'] + RESERVE, 'Target-volume ZIP free floor')
    # x creates one new archive. Any partial result is retained after failure.
    with zipfile.ZipFile(target, 'x', allowZip64=False) as z:
        for row in plan['files']:
            need(datetime.now(timezone.utc) < datetime.fromisoformat(go['expires_utc'].replace('Z', '+00:00')), 'ZIP GO expired during build')
            raw = raw_input(row)
            need(shutil.disk_usage(target.parent).free >= FLOOR + RESERVE + len(raw), 'Ongoing ZIP free floor')
            info = zipfile.ZipInfo(archive.TOP + '/' + row['file'], date_time=(2000, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            info.compress_type = compression(row)
            z.writestr(info, raw, compress_type=info.compress_type, compresslevel=9)
            need(target.stat().st_size <= ZIP_LIMIT and shutil.disk_usage(target.parent).free >= FLOOR + RESERVE, 'ZIP size/free floor reached')
    actual = pin(target)
    need(actual['bytes'] == capacity['predicted_zip_bytes'], 'ZIP-format prediction mismatch')
    verified = archive.verify(target, actual['sha256'])
    need(verified['member_count'] == len(plan['files']), 'ZIP member count changed')
    for row in plan['files']: raw_input(row)
    for row in plan['source_receipts']:
        need(pin(row['path']) == {k: row[k] for k in ('bytes', 'sha256')}, 'Original receipt changed')
    save_fresh(receipt, {'schema': 'outer-zip-build-receipt-v1', 'status': 'PASS_ZIP_CREATED_AND_VERIFIED',
                        'zip': {'path': str(target), **actual}, 'build_plan': {'path': str(plan_path), **pin(plan_path)},
                        'root_go': {'path': str(go_path), **pin(go_path)}, 'capacity_before': capacity,
                        'verification': verified, 'all_sources_unchanged': True,
                        'free_bytes_before': free_before, 'free_bytes_after': shutil.disk_usage(target.parent).free,
                        'scientific_computations': 0, 'extraction_started': False, 'cleanup_performed': False})
    print(json.dumps({'status': 'PASS_ZIP_CREATED_AND_VERIFIED', 'zip': actual, 'receipt': pin(receipt)}))
def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode', choices=['measure', 'build'])
    p.add_argument('--plan', required=True)
    p.add_argument('--receipt', required=True)
    p.add_argument('--go')
    args = p.parse_args()
    plan_path = Path(args.plan).resolve()
    receipt = archive.canonical(args.receipt, False)
    if args.mode == 'measure':
        result = measure(plan_path)
        save_fresh(receipt, result)
        print(json.dumps(result))
    else:
        need(args.go is not None, 'Root GO required')
        build(plan_path, Path(args.go).resolve(), receipt)
if __name__ == '__main__': main()
