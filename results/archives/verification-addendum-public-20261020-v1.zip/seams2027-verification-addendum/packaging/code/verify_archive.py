"""Inspect or freshly extract this evidence ZIP; never run scientific code."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import zipfile

TOP = 'seams2027-verification-addendum'
FLOOR = 1024 ** 3
MAX_FILES = 2048
MAX_FILE = 8 * 1024 ** 2
MAX_TOTAL = 64 * 1024 ** 2

def need(ok, message):
    if not ok:
        raise ValueError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def pin(path):
    raw = Path(path).read_bytes()
    return {'bytes': len(raw), 'sha256': digest(raw)}

def safe_name(name):
    need(type(name) is str and name and '\\' not in name and '\x00' not in name,
         'Invalid member name')
    parts = name.split('/')
    need(not name.startswith('/') and all(p not in ('', '.', '..') for p in parts),
         'Absolute, empty, dot or parent member path')
    need(all(not re.match(r'^[A-Za-z]:', p) for p in parts), 'Windows drive member path')
    need(str(PurePosixPath(name)) == name and parts[0] == TOP and len(parts) > 1,
         'Unexpected member prefix')
    return name

def canonical(path, exists):
    p = Path(path).absolute()
    need('..' not in p.parts and str(p) == str(p.resolve()), 'Noncanonical or symlink path')
    need(p.exists() if exists else not p.exists(), 'Input absent or destination already exists')
    if exists:
        need(p.is_file() and not p.is_symlink(), 'Input is not a regular file')
    else:
        need(p.parent.is_dir(), 'Destination parent must already exist')
    return p

def index(zip_file):
    infos = zip_file.infolist()
    need(0 < len(infos) <= MAX_FILES, 'ZIP member count cap')
    names = set()
    total = 0
    for info in infos:
        name = safe_name(info.filename)
        need(name not in names, 'Duplicate ZIP member')
        names.add(name)
        mode = (info.external_attr >> 16) & 0xffff
        need(not info.is_dir() and (mode & 0o170000) in (0, stat.S_IFREG),
             'ZIP directory, symlink or nonregular member')
        need(not info.flag_bits & 1, 'Encrypted ZIP member')
        need(info.compress_type in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED),
             'Unsupported ZIP compression')
        need(0 <= info.file_size <= MAX_FILE, 'ZIP single-member size cap')
        total += info.file_size
        need(total <= MAX_TOTAL, 'ZIP decoded total cap')
    for name in names:
        need(not any(str(parent) in names for parent in PurePosixPath(name).parents),
             'ZIP file and directory prefix conflict')
    check_name = TOP + '/SHA256SUMS'
    need(check_name in names, 'SHA256SUMS is required')
    check_raw = zip_file.read(check_name)
    need(len(check_raw) <= 4 * 1024 ** 2, 'Checksum index size cap')
    expected = {}
    for line in check_raw.decode('utf-8').splitlines():
        need(len(line) > 66 and line[64:66] == '  ', 'Malformed checksum line')
        sha, relative = line[:64], line[66:]
        need(re.fullmatch('[0-9a-f]{64}', sha), 'Malformed checksum digest')
        full = safe_name(TOP + '/' + relative)
        need(full not in expected and full != check_name, 'Duplicate or self checksum')
        expected[full] = sha
    need(set(expected) == names - {check_name}, 'Checksum/member set mismatch')
    expected[check_name] = digest(check_raw)
    return infos, expected

def verify(zip_path, expected_sha, destination=None, reserve=8 * 1024 ** 2):
    need(re.fullmatch('[0-9a-f]{64}', expected_sha or ''), 'Expected ZIP SHA256 required')
    need(type(reserve) is int and reserve >= 1024 ** 2, 'At least 1 MiB operation reserve required')
    src = canonical(zip_path, True)
    before = pin(src)
    need(before['sha256'] == expected_sha, 'ZIP digest mismatch')
    dest = canonical(destination, False) if destination is not None else None
    rows = []
    with zipfile.ZipFile(src, 'r') as z:
        infos, checksums = index(z)
        directories = {str(p) for i in infos for p in PurePosixPath(i.filename).parents if str(p) != '.'}
        allocated_estimate = sum(((i.file_size + 4095) // 4096) * 4096 for i in infos)
        allocation_reservation = allocated_estimate + 4096 * (len(directories) + 1)
        free_before = shutil.disk_usage(dest.parent if dest else src.parent).free
        if dest:
            need(free_before >= FLOOR + allocation_reservation + reserve,
                 'Extraction cannot preserve the 1 GiB free floor and operation reserve')
            dest.mkdir()
        for info in infos:
            # read() checks each member CRC, bounded by the admitted decoded sizes.
            data = z.read(info)
            need(len(data) == info.file_size and digest(data) == checksums[info.filename],
                 'ZIP decoded member identity mismatch')
            if dest:
                need(shutil.disk_usage(dest).free >= FLOOR + ((len(data) + 4095) // 4096) * 4096 + reserve,
                     'Free floor reached; partial extraction is preserved')
                target = dest / info.filename
                target.parent.mkdir(parents=True, exist_ok=True)
                need(str(target) == str(target.resolve()), 'Extraction target became noncanonical')
                with target.open('xb') as out:
                    out.write(data)
                need(pin(target) == {'bytes': len(data), 'sha256': checksums[info.filename]},
                     'Written member identity mismatch')
                need(shutil.disk_usage(dest).free >= FLOOR + reserve,
                     'Free floor reached after write; partial extraction is preserved')
            rows.append({'file': info.filename, 'bytes': len(data), 'sha256': checksums[info.filename]})
    need(pin(src) == before, 'ZIP changed during operation')
    if dest:
        actual = set()
        for p in dest.rglob('*'):
            need(not p.is_symlink(), 'Unexpected extracted symlink')
            if p.is_file(): actual.add(p.relative_to(dest).as_posix())
        need(actual == {r['file'] for r in rows}, 'Fresh extraction file-set mismatch')
        for row in rows:
            need(pin(dest / row['file']) == {k: row[k] for k in ('bytes', 'sha256')},
                 'Extracted member changed during final check')
    return {'schema': 'saved-evidence-zip-inspection-v1',
            'status': 'PASS_FRESH_EXTRACTION' if dest else 'PASS_ZIP_VERIFIED',
            'zip': before, 'member_count': len(rows),
            'decoded_bytes': sum(r['bytes'] for r in rows),
            'allocated_file_estimate': allocated_estimate,
            'directory_reservation_bytes': allocation_reservation - allocated_estimate,
            'minimum_free_bytes': FLOOR, 'operation_reserve_bytes': reserve,
            'free_bytes_before': free_before,
            'free_bytes_after': shutil.disk_usage(dest if dest else src.parent).free,
            'member_files': rows, 'scientific_computations': 0,
            'native_calls': 0, 'cleanup_performed': False}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('zip')
    parser.add_argument('--expected-sha256', required=True)
    parser.add_argument('--extract-to', help='Fresh canonical inspection directory; never overwrite')
    parser.add_argument('--receipt', required=True, help='Fresh receipt outside extraction')
    parser.add_argument('--reserve-bytes', type=int, default=8 * 1024 ** 2)
    args = parser.parse_args()
    receipt = canonical(args.receipt, False)
    if args.extract_to:
        dest = Path(args.extract_to).absolute()
        need(not receipt.is_relative_to(dest), 'Receipt must stay outside the inspected tree')
    result = verify(args.zip, args.expected_sha256, args.extract_to, args.reserve_bytes)
    raw = (json.dumps(result, indent=2) + '\n').encode()
    need(shutil.disk_usage(receipt.parent).free >= FLOOR + len(raw), 'Receipt free-floor guard')
    with receipt.open('xb') as out: out.write(raw)
    print(json.dumps({k: v for k, v in result.items() if k != 'member_files'}))

if __name__ == '__main__':
    main()
