"""Create a static byte manifest without importing or executing scientific code."""
from pathlib import Path
import ast,hashlib,json
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'FROZEN_MANIFEST.json'
if OUT.exists():raise SystemExit('Frozen manifest already exists; use a new revision')
def pin(p):
    raw=p.read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
inputs=json.loads((ROOT/'INPUT_MANIFEST.json').read_text())
for row in inputs['files']:
    if pin(ROOT/row['file'])!={k:row[k] for k in ('bytes','sha256')}:raise ValueError('Input pin mismatch: '+row['file'])
files=sorted(p for p in ROOT.rglob('*') if p.is_file())
if len(files)!=30 or any(p.is_symlink() for p in ROOT.rglob('*')):raise ValueError('Unexpected static closure roster')
for p in files:
    if p.suffix=='.py':ast.parse(p.read_text(),filename=str(p))
record={'schema':'fixed188-portable-frozen-manifest-v1','scope':'target_original_literal','case':'corpus188__original','status':'STATIC_FROZEN_AWAITING_PREPARATION_GO','files':[{'file':str(p.relative_to(ROOT)),**pin(p)} for p in files],'input_manifest_sha256':pin(ROOT/'INPUT_MANIFEST.json')['sha256'],'unchanged_scientific_core_files':3,'saved_DAG_evaluations':0,'native_calls':0,'full_reset_uses':0,'scope_note':'Single original/literal target recheck only after artificial/import qualification and a separate fresh Root GO. Mathematical target, Context and ROBDD bytes remain unchanged; no old runner/authorization or fallback.'}
raw=(json.dumps(record,ensure_ascii=False,indent=2)+'\n').encode()
with OUT.open('xb') as f:f.write(raw)
print(json.dumps({'file':str(OUT),'files':len(files),'input_bytes':sum(x['bytes']for x in record['files']),**pin(OUT),'static_AST_only':True,'saved_DAG_evaluations':0}))
