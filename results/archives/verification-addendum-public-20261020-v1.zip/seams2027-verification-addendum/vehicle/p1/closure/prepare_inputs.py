#!/usr/bin/env python3
"""Copy a minimal, explicitly bound saved-input closure; no scientific imports."""
from pathlib import Path,PurePosixPath
import hashlib,json,tarfile
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
ARCHIVE=HERE.parent/'additional_evidence_build_01/execution_02/additional-evidence.tar.gz'
INNER=ROOT/'experiment/seams_research_reframing_20261018/portable_verification_build_05/package'
A='additional-evidence/vehicle188/'
E='evidence/experiment/seams_research_reframing_20261017/'
T=E+'corpus188_target_certificate_preparation/'
O=E+'released_transform_188_preparation/runs/corpus188__original/original/'
def digest(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def pin(path):return digest(path.read_bytes())
def emit(name,obj):
    p=HERE/name;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def bytes_copy(name,raw):
    p=HERE/name;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);assert p.read_bytes()==raw
assert pin(ARCHIVE)=={'bytes':2256380,'sha256':'f22189add83fecffe56b4a74157f7fa52642bfcaa91e53cfa3f415a88d8e7887'}
assert pin(INNER/'MANIFEST.json')['sha256']=='adc9466569209fab91ecd0085ccca41633409bca8d1e7ad80d4d782fb48d3607'
inner_manifest=json.loads((INNER/'MANIFEST.json').read_text());inner={x['file']:x for x in inner_manifest['files']}
entries=[];origin_bindings=[]
with tarfile.open(ARCHIVE,'r:gz') as tar:
    members={m.name:m for m in tar.getmembers()}
    manifest=json.load(tar.extractfile('additional-evidence/MANIFEST.json'));ad={x['file']:x for x in manifest['files']}
    origin=json.load(tar.extractfile(A+'ORIGIN_DIGESTS.json'));oi={x['copy_file']:x for x in origin['files']}
    def take(member,name,role):
        assert member in ad and member in members
        m=members[member];assert m.isfile() and not m.issym() and not m.islnk()
        raw=tar.extractfile(m).read();actual=digest(raw);assert actual=={k:ad[member][k] for k in ('bytes','sha256')}
        bytes_copy(name,raw)
        row={'file':name,**actual,'role':role,'authority':{'container':'additional-evidence/additional-evidence.tar.gz','member':member,'current_copy_pin':actual}}
        key=member.removeprefix(A)
        if key in oi:
            old=oi[key];assert actual=={'bytes':old['copy_bytes'],'sha256':old['copy_sha256']}
            row['authority']['historical_origin']={k:old[k] for k in ('origin_path','origin_bytes','origin_sha256','transformation','changed_paths')}
            origin_bindings.append({'file':name,'member':member,**old})
        entries.append(row);return json.loads(raw) if member.endswith('.json') else raw
    model=take(A+O+'model.json','inputs/original/model.json','ORIGINAL_MODEL_METADATA')
    refs=list(model['original_bdds'].values())+model['original_justices']['ENV']+model['original_justices']['SYS']
    assert len(refs)==11 and len({r['file'] for r in refs})==11
    for r in refs:
        name=r['file'];p=PurePosixPath(name);assert p.name==name and name.endswith('.bdd') and '/' not in name and '\\' not in name
        raw=take(A+O+name,'inputs/original/'+name,'SAVED_DECLARED_BDD')
        assert digest(raw)=={k:r[k] for k in ('bytes','sha256')}
    profile=take(A+T+'PROFILE.json','inputs/PROFILE.json','ORIGINAL_SOURCE_PROFILE')
    take(A+T+'target_certificate.py','code/target_certificate.py','UNCHANGED_TARGET_MATHEMATICS')
    expected=take(A+T+'target_result/RESULT.json','expected/RESULT.json','HISTORICAL_TARGET_RESULT')
    take(A+T+'target_result/FUNCTIONS.json','expected/FUNCTIONS.json','HISTORICAL_CANONICAL_FUNCTION_EXPORT')
for origin,name,role in [
('base/'+E+'kind_corpus/original/artifact/experiments/specs/syn20/AutonomousVehicle_sprint02_ver1.spectra','inputs/source.spectra','UNCHANGED_SOURCE_BYTES'),
('base/'+E+'released_kind_corpus_checker/generic_base.py','code/context/generic_base.py','UNCHANGED_CONTEXT_MATHEMATICS'),
('base/'+E+'released_kind_corpus_checker/vendor/bdd_core.py','code/context/vendor/bdd_core.py','UNCHANGED_ROBDD_MATHEMATICS'),
('code/runtime_guard.py','code/runtime_guard.py','UNCHANGED_QUALIFIED_IO_GUARD'),
('code/supervisor/bounded_process.py','code/supervisor/bounded_process.py','UNCHANGED_QUALIFIED_SUPERVISOR'),
('code/supervisor/owned_process.py','code/supervisor/owned_process.py','UNCHANGED_QUALIFIED_PROCESS_OWNERSHIP')]:
    raw=(INNER/origin).read_bytes();actual=digest(raw);assert actual=={k:inner[origin][k] for k in ('bytes','sha256')}
    bytes_copy(name,raw);entries.append({'file':name,**actual,'role':role,'authority':{'container':'package','file':origin,'current_copy_pin':actual}})
assert pin(HERE/'inputs/source.spectra')=={k:profile['source'][k] for k in ('bytes','sha256')}
assert model['input']==profile['source']
assert expected['status']=='PASS_TARGET_COOPERATIVE_RESIDUAL_LOSS_AND_INITIAL_PRESERVATION' and len(expected['checks'])==30 and len(expected['root_digests'])==39
assert expected['predicate_counts']=={'R_speed_rule':3072,'P':2560,'C':6656,'bad_state':1}
assert len([x for x in expected['checks'].values() if 'counterexample_canonical_sha256' in x])==28
emit('authority/ORIGIN_COPY_BINDINGS.json',{'schema':'fixed188-target-saved-copy-origin-bindings-v1','archive':pin(ARCHIVE),'archive_member_manifest':pin(HERE.parent/'additional_evidence_build_01/execution_02/generated/additional-evidence/MANIFEST.json'),'bindings':origin_bindings,'scope':'Current local bytes equal exact archive/inner copies. Historical digest fields are not rewritten and are compared to separately recorded origin identities.'})
entries.append({'file':'authority/ORIGIN_COPY_BINDINGS.json',**pin(HERE/'authority/ORIGIN_COPY_BINDINGS.json'),'role':'GENERATED_ORIGIN_COPY_BINDING'})
emit('INPUT_MANIFEST.json',{'schema':'fixed188-target-input-closure-v1','status':'STATIC_COPY_ONLY_NOT_EXECUTED','fixture_id':'corpus188__original','archive':pin(ARCHIVE),'inner_manifest':pin(INNER/'MANIFEST.json'),'files':entries,'declared_original_BDD_files':11,'scientific_code_changes':0,'expected_scope':{'checks':30,'zero_failure_roots':28,'root_digests':39,'predicate_counts':expected['predicate_counts']},'historical_compiler_provenance_premise':True,'actual_released_correspondence_rechecked':False,'scientific_evaluations':0,'native_runs':0,'full_reset_uses':0})
for x in entries:assert pin(HERE/x['file'])=={k:x[k] for k in ('bytes','sha256')}
print(json.dumps({'status':'PASS_STATIC_COPY_ONLY','files':len(entries),'bytes':sum(x['bytes'] for x in entries),'manifest':pin(HERE/'INPUT_MANIFEST.json')}))
