"""Small generated metadata/authority tests; no scientific module is imported."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import argparse,copy,json,sys
from unittest.mock import patch
from types import SimpleNamespace
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import adapter as a
import review

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--expected-manifest',required=True);ap.add_argument('--output',required=True);args=ap.parse_args()
    frozen=a.Frozen(args.root,args.expected_manifest);out=a.canonical_path(args.output);a.need(not out.exists() and not out.is_relative_to(frozen.root),'Fresh artificial output outside closure');out.mkdir()
    tests=[]
    def case(name,fn):
        fn();tests.append({'name':name,'status':'PASS'})
    def rejected(fn,kind=Exception):
        try:fn()
        except kind:return
        raise AssertionError('Expected explicit rejection')
    def equal(a1,b1):a.exact(a1,b1,'Toy equality')
    case('duplicate JSON keys rejected',lambda:rejected(lambda:a.decode(b'{"x":1,"x":2}')))
    case('unsafe relative parent filename rejected',lambda:rejected(lambda:a.relative_name('../outside.bdd')))
    case('wrong frozen manifest rejected before imports',lambda:rejected(lambda:a.Frozen(frozen.root,'0'*64)))
    # One small generated tree tests byte pin and symlink handling. Scientific
    # code bytes are copied only because Frozen requires their exact identities.
    toy=out/'toy_closure';toy.mkdir();rows=[]
    for name in a.CORE_PINS:
        raw=frozen.raw(name);p=toy/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);rows.append({'file':name,**a.digest(raw)})
    f=toy/'toy.txt';f.write_bytes(b'original toy bytes');rows.append({'file':'toy.txt',**a.digest(f.read_bytes())})
    m={'schema':'fixed188-portable-frozen-manifest-v1','scope':a.SCOPE,'case':a.CASE,'files':rows};(toy/'FROZEN_MANIFEST.json').write_bytes(a.encoded(m));tf=a.Frozen(toy,a.sha((toy/'FROZEN_MANIFEST.json').read_bytes()))
    def changed_bytes():
        f.write_bytes(b'changed toy bytes')
        try:rejected(lambda:tf.raw('toy.txt'))
        finally:f.write_bytes(b'original toy bytes')
    case('changed declared bytes rejected',changed_bytes)
    def absent_bytes():
        f.unlink()
        try:rejected(lambda:tf.raw('toy.txt'))
        finally:f.write_bytes(b'original toy bytes')
    case('missing declared input rejected',absent_bytes)
    def unmanifested_file():
        extra=toy/'unmanifested.pyc';extra.write_bytes(b'generated extra-file probe, not Python bytecode')
        try:rejected(lambda:tf.verify())
        finally:extra.unlink()
        tf.verify()
    case('unmanifested file rejected by exact frozen closure roster',unmanifested_file)
    def mocked_symlink_component():
        original=Path.is_symlink
        with patch.object(Path,'is_symlink',lambda self:True if self==f else original(self)):
            rejected(lambda:a.file_bytes(f))
    case('mocked symlink input component rejected',mocked_symlink_component)
    src=out/'toy_source.spectra';src.write_text('artificial source-location probe only\n')
    source={'path':'research:experiment/toy/source.spectra',**a.SOURCE}
    profile={'fixture_id':a.CASE,'case_id':'corpus188','variant':'original','source':source,'kept':[False,0,'digest-shaped-'+('1'*64)]}
    model={'fixture_id':a.CASE,'case_id':'corpus188','variant':'original','schema':'k7-native-model-export-v1','input':copy.deepcopy(source),'extra':{'raw_hash':'2'*64,'count':3,'flag':False}}
    def valid_projection():
        pv,mv,report=a.project_inputs(profile,model,src,dict(a.SOURCE));equal(pv['kept'],profile['kept']);equal(mv['extra'],model['extra']);equal(len(report['changes']),2)
        equal(profile['source']['path'],source['path']);equal(model['input']['path'],source['path'])
    case('only two in-memory path fields change; original objects and values remain',valid_projection)
    def mismatch_source():
        p=copy.deepcopy(profile);p['source']['sha256']='0'*64;rejected(lambda:a.project_inputs(p,model,src,dict(a.SOURCE)))
    case('profile/model source digest mismatch rejected',mismatch_source)
    # Generated result dictionaries exercise comparison boundaries only.
    def result():
        r={k:'TOY_METADATA' for k in a.OUTPUT_KEYS};r.update(schema='fixed188-target-policy-certificate-v1',status=a.PASS_STATUS,fixture_id=a.CASE,admitted_scientific_result=False,checks={f'toy_failure_{i}':{'passes':True,'counterexample_canonical_sha256':a.sha(b'0'),'counterexample_support':[]} for i in range(28)},predicate_counts={'R_speed_rule':3072,'P':2560,'C':6656,'bad_state':1},algorithmic_counters={'native_calls':0,'solver_calls':0,'fixed_point_iterations':0,'graph_extractions':0},source_justice_correspondence=['toy_first','toy_second'],BDD_nodes_including_terminals=2,root_digests={f'toy_root_{i}':a.sha(b'0') for i in range(39)})
        r['checks'].update(toy_deterministic={'passes':True},toy_nonempty={'passes':True});return r
    actual=result();expected=copy.deepcopy(actual);expected.update({k:None for k in a.WRAPPER_KEYS});expected['admitted_scientific_result']=True;expected['model_audit']={'status':'TOY_TYPED_AUDIT'}
    case('complete toy comparison keeps historical adoption metadata separate',lambda:a.compare_result(actual,expected,expected['model_audit']))
    def bad_result(kind):
        r=copy.deepcopy(actual)
        if kind=='false_check':r['checks']['toy_failure_3']['passes']=False
        elif kind=='bool_count':r['predicate_counts']['bad_state']=True
        elif kind=='root_digest':r['root_digests']['toy_root_1']='f'*64
        elif kind=='missing_check':del r['checks']['toy_failure_1']
        elif kind=='justice_order':r['source_justice_correspondence'].reverse()
        elif kind=='extra_field':r['undeclared']='wrong'
        rejected(lambda:a.compare_result(r,expected,expected['model_audit']))
    for k in ('false_check','bool_count','root_digest','missing_check','justice_order','extra_field'):case('comparison rejects '+k,lambda k=k:bad_result(k))
    toy_export={'schema':'fixed188-canonical-target-functions-v1','variable_count':2,'fields':[],'roots':{'x':2},'nodes':[[2,0,0,1]]}
    case('generated one-node canonical export hash',lambda:equal(a.canonical_export(toy_export),{'x':a.sha(f'0:{a.sha(b"0")}:{a.sha(b"1")}'.encode())}))
    bad_export=copy.deepcopy(toy_export);bad_export['nodes'][0][2]=2
    case('canonical cycle/nonordered child rejected',lambda:rejected(lambda:a.canonical_export(bad_export)))
    # Fresh authority tests use explicitly artificial qualification receipts.
    qrefs=[]
    for kind in ('artificial','imports'):
        p=out/(kind+'_toy_receipt.json');p.write_bytes(a.encoded({'status':'PASS_QUALIFIED_PREPARATION','qualification_kind':kind,'frozen_manifest_sha256':'3'*64}));qrefs.append(a.pin(p))
    go={'schema':'fixed188-portable-single-scope-go-v1','status':'GO','frozen_manifest_sha256':'3'*64,'scope':a.SCOPE,'case':a.CASE,'output_root':str(out/'toy_actual_output'),'attempts':1,'saved_evaluations':1,'native_calls':0,'solver_calls':0,'fixed_point_calls':0,'deadline_utc':(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat(),'limits':dict(a.LIMITS),'qualification_receipts':qrefs}
    gp=out/'toy_GO.json'
    def check_go(obj):gp.write_bytes(a.encoded(obj));return a.load_go(gp,'3'*64,out/'toy_actual_output')
    case('new exact toy authority accepted',lambda:check_go(go))
    def bad_go(kind):
        g=copy.deepcopy(go)
        if kind=='old_schema':g['schema']='APPROVED_FIXED188_TARGET_CERTIFICATE'
        elif kind=='boolean_attempt':g['attempts']=True
        elif kind=='wrong_scope':g['scope']='released_pair'
        elif kind=='expired':g['deadline_utc']='2020-01-01T00:00:00+00:00'
        elif kind=='native_call':g['native_calls']=1
        elif kind=='solver_call':g['solver_calls']=1
        elif kind=='wrong_manifest':g['frozen_manifest_sha256']='4'*64
        elif kind=='wrong_output':g['output_root']=str(out/'wrong_output')
        elif kind=='duplicate_attempt':g['attempts']=2
        elif kind=='missing_qualification':g['qualification_receipts']=g['qualification_receipts'][:1]
        rejected(lambda:check_go(g))
    for k in ('old_schema','boolean_attempt','wrong_scope','expired','native_call','solver_call','wrong_manifest','wrong_output','duplicate_attempt','missing_qualification'):case('authority rejects '+k,lambda k=k:bad_go(k))
    proc={'schema':'contained-stage-process-v2','status':'PROCESS_COMPLETED','exit_code':0,'process_started':True,'owned_child_reaped':True,'receipt_persisted':True,'parent_finalization_completed':True,'parent_aborted':False,'exact_child_wait4':{'exact_child_reaped':True,'authority_lost':False},'final_group_observation':{'state':'ABSENT'},'fatal_reasons':[],'resource_reasons':[],'capture':{k:{'file':k+'.txt','bytes':0,'sha256':a.sha(b''),'complete':True,'observed_bytes':0,'captured_bytes':0} for k in ('stdout','stderr')}}
    case('generated complete process receipt accepted',lambda:equal(review.valid_process(proc),True))
    pbad=copy.deepcopy(proc);pbad['exit_code']=False
    case('boolean child exit code rejected',lambda:equal(review.valid_process(pbad),False))
    pbad2=copy.deepcopy(proc);pbad2['owned_child_reaped']=False
    case('unreaped child receipt rejected',lambda:equal(review.valid_process(pbad2),False))
    def actual_capture_integrity():
        d=out/'capture_completion_toy';(d/'process').mkdir(parents=True);(d/'worker').mkdir()
        process=copy.deepcopy(proc)
        for name,raw in [('stdout',b'captured'),('stderr',b'')]:
            (d/'process'/(name+'.txt')).write_bytes(raw)
            process['capture'][name].update(a.digest(raw),observed_bytes=len(raw),captured_bytes=len(raw))
        (d/'process/PROCESS_RECEIPT.json').write_bytes(a.encoded(process))
        (d/'worker/QUALIFICATION.json').write_bytes(a.encoded({'status':'PASS_ARTIFICIAL_ADAPTER_QUALIFICATION','frozen_manifest_sha256':'3'*64,'saved_DAG_evaluations':0,'scientific_modules_imported':0}))
        fake=SimpleNamespace(manifest_hash='3'*64)
        good=review.completion_record(d,fake,'artificial',process,True,None)
        equal(good['status'],'PASS_QUALIFIED_PREPARATION')
        (d/'process/stdout.txt').write_bytes(b'tampered')
        bad=review.completion_record(d,fake,'artificial',process,True,None)
        equal(bad['status'],'UNKNOWN_SCOPE_NOT_ADMITTED')
        a.need(any(x['phase']=='owned_process' for x in bad['errors']),'Same-length capture tampering rejected before worker result')
    case('parent rehashes actual captures and rejects same-length byte mutation',actual_capture_integrity)
    # Permanent I/O audit hook comes last; all following writes are assigned output.
    external=out.parent/'artificial_external_probe.txt';external.write_bytes(b'outside worker output')
    guard_module=a.load_module('fixed188_artificial_qualified_guard',frozen.path('code/runtime_guard.py'))
    guard=guard_module.install(frozen.root,out)
    case('actual guard own-output readback',lambda:equal(src.read_text(),'artificial source-location probe only\n'))
    case('actual guard external read denied',lambda:rejected(lambda:external.read_bytes(),PermissionError))
    case('actual guard path traversal outside denied',lambda:rejected(lambda:(out/'..'/'artificial_external_probe.txt').read_bytes(),PermissionError))
    case('actual guard process attempt denied before launch',lambda:rejected(lambda:sys.audit('subprocess.Popen',None,None,None,None),PermissionError))
    case('actual guard network attempt denied before access',lambda:rejected(lambda:sys.audit('socket.connect',None,None),PermissionError))
    equal(guard['external_data_reads_blocked'],2);equal(guard['network_process_attempts_blocked'],2)
    frozen.verify()
    a.save(out/'QUALIFICATION.json',{'schema':'fixed188-artificial-adapter-qualification-v1','status':'PASS_ARTIFICIAL_ADAPTER_QUALIFICATION','frozen_manifest_sha256':frozen.manifest_hash,'tests':tests,'test_count':len(tests),'saved_DAG_evaluations':0,'scientific_modules_imported':0,'native_calls':0,'new_scientific_samples':0,'guard':guard,'symlink_test_scope':'Mocked Path.is_symlink for a generated toy file; no physical symlink is created in the supervised output tree.','scope':'Generated metadata, one-node canonical toy, authority and actual Python audit events only. No real scientific module imported, native library loaded or saved predicate interpreted.'})
    print(json.dumps({'status':'PASS_ARTIFICIAL_ADAPTER_QUALIFICATION','test_count':len(tests)}),flush=True)

if __name__=='__main__':main()
