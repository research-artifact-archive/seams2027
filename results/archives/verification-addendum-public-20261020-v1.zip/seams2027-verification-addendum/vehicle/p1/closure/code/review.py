"""Bounded new authority for fixed188 target saved-input rechecks.

Preparation modes never evaluate the saved model. Actual mode needs a fresh GO.
"""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import argparse, importlib.util, json, math, re, shutil, signal, sys, time, traceback
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import adapter as a
if Path(a.__file__).resolve()!=HERE/'adapter.py':raise RuntimeError('Unexpected adapter origin')

def science_profile(frozen,imports):
    previous=sys.getprofile();events={'target_evaluations':0,'context_constructions':0,'model_audits':0,'canonical_exports':0,'blocked_scientific_calls':0,'blocked_legacy_or_out_of_scope_calls':0}
    target=frozen.path('code/target_certificate.py');context=frozen.path('code/context/generic_base.py');bdd=frozen.path('code/context/vendor/bdd_core.py')
    legacy={'run','load_profile','viability','audit_normalization','audit_quantification','graph_analyzer','analyze_controller','check','main'}
    mathematical={'evaluate_context','exact_context','count','digest','export_roots','audit_model','read_bdd','domain_of','literal','cube','equal','mk','var','apply','conj','disj','exists','forall','rename','read_native'}
    def hook(frame,event,arg):
        if event!='call':return
        p=Path(frame.f_code.co_filename).absolute()
        if p not in (target,context,bdd):return
        name=frame.f_code.co_name;cls=type(frame.f_locals.get('self')).__name__
        if name in legacy:
            events['blocked_legacy_or_out_of_scope_calls']+=1;raise RuntimeError('Forbidden old runner or out-of-scope computation: '+name)
        constructor=name=='__init__' and cls in ('Context','BDD')
        if imports and (constructor or name in mathematical):
            events['blocked_scientific_calls']+=1;raise RuntimeError('Import-only scientific call rejected: '+name)
        if p==target and name=='evaluate_context':events['target_evaluations']+=1
        if p==context and constructor:events['context_constructions']+=1
        if p==context and name=='audit_model':events['model_audits']+=1
        if p==target and name=='export_roots':events['canonical_exports']+=1
    sys.setprofile(hook)
    return events,previous

def worker(args):
    frozen=a.Frozen(args.root,args.expected_manifest)
    output=a.canonical_path(args.output);a.need(output.parent.is_dir() and not output.exists(),'Fresh canonical worker output')
    a.need(not output.is_relative_to(frozen.root),'Worker output must be outside immutable closure')
    if args.action=='actual-worker':
        go,go_pin=a.load_go(args.go,frozen.manifest_hash,output.parent)
        start=a.decode(a.file_bytes(output.parent/'START.json'))
        a.exact(start['GO'],go_pin,'Parent/worker GO identity');a.need(start['frozen_manifest_sha256']==frozen.manifest_hash and start['scope']==a.SCOPE,'Parent exact frozen scope')
    output.mkdir()
    guard_module=a.load_module('fixed188_qualified_runtime_guard',frozen.path('code/runtime_guard.py'))
    guard=guard_module.install(frozen.root,output)
    trace=None;previous=None
    try:
        importing=args.action=='imports-worker'
        trace,previous=science_profile(frozen,importing)
        try:
            target,context=a.load_scientific(frozen)
            prepared=a.admit_saved_inputs(frozen)
            if importing:
                probe=output/'assigned_output_probe.txt';raw=b'fixed188 own output readback probe\n'
                with probe.open('xb') as f:f.write(raw)
                a.need(probe.read_bytes()==raw and probe.read_text()==raw.decode(),'Own output readback')
                a.exact(a.digest(probe.read_bytes()),a.digest(raw),'Own output pin')
                old_root=a.canonical_path(args.reject_read_root)
                a.need(old_root!=frozen.root and not old_root.is_relative_to(frozen.root),'External old-root probe')
                try:(old_root/'MANIFEST.json').read_bytes()
                except PermissionError:old_probe='REJECTED_BEFORE_READ'
                else:raise a.Rejection('Historical root read was not blocked')
                a.need(all(v==0 for v in trace.values()),'No mathematical call during guarded import')
                a.need(guard['external_data_reads_blocked']==1 and guard['network_process_attempts_blocked']==0,'Exact deliberate import I/O probe count')
                result={'schema':'fixed188-guarded-import-result-v1','status':'PASS_IMPORT_ONLY','frozen_manifest_sha256':frozen.manifest_hash,'science_calls':trace,'old_root_read_probe':old_probe,'assigned_output_probe':a.digest(raw),'module_origins':{'target':str(target.__file__),'context':str(context.__file__),'bdd':str(context._bdd_module.__file__)},'in_memory_projection':prepared['projection'],'guard':guard,'saved_DAG_evaluations':0,'native_calls':0}
                a.save(output/'IMPORT_RESULT.json',result)
            else:
                deadline=datetime.fromisoformat(go['deadline_utc'])
                def timed_out(*_):raise TimeoutError('Fixed188 target worker deadline')
                signal.signal(signal.SIGALRM,timed_out)
                signal.alarm(max(1,math.ceil(min(a.LIMITS['wall_seconds'],(deadline-datetime.now(timezone.utc)).total_seconds()))))
                ctx=context.Context(frozen.root/'inputs/original',prepared['profile'],prepared['model'])
                audit=ctx.audit_model()
                actual,roots=target.evaluate_context(ctx)
                a.need(set(ctx.refs)=={(r['file'],r['sha256']) for r in prepared['declared_refs']},'All and only eleven saved declared BDDs consumed')
                comparison=a.compare_result(actual,prepared['expected'],audit)
                target.export_roots(output/'FUNCTIONS.json',ctx,roots)
                export=a.decode(a.file_bytes(output/'FUNCTIONS.json'))
                export_comparison=a.compare_exports(export,frozen.read('expected/FUNCTIONS.json'),actual,prepared['expected'])
                a.need(trace=={'target_evaluations':1,'context_constructions':1,'model_audits':1,'canonical_exports':1,'blocked_scientific_calls':0,'blocked_legacy_or_out_of_scope_calls':0},'Exactly one authorized mathematical scope')
                a.need(guard['external_data_reads_blocked']==guard['network_process_attempts_blocked']==0,'No unexpected I/O boundary attempts')
                comparison.update(frozen_manifest_sha256=frozen.manifest_hash,in_memory_projection=prepared['projection'],scientific_call_trace=trace,guard=guard,canonical_function_comparison=export_comparison)
                a.save(output/'TARGET_RESULT.json',actual);a.save(output/'MODEL_AUDIT.json',audit);a.save(output/'COMPARISON.json',comparison)
                result={'status':'PASS_SAVED_TARGET_FIELDS_RECHECK'}
        finally:
            signal.alarm(0)
            if previous is not None or sys.getprofile()is not None:sys.setprofile(previous)
        frozen.verify()
        complete={'schema':'fixed188-portable-worker-complete-v1','status':result['status'],'frozen_manifest_sha256':frozen.manifest_hash,'scope':a.SCOPE,'case':a.CASE,'all_inputs_unchanged':True,'guard':guard,'scientific_call_trace':trace,'native_calls':0,'new_scientific_samples':0}
        a.save(output/'WORKER_COMPLETE.json',complete)
        print(json.dumps({'status':result['status'],'scope':a.SCOPE,'case':a.CASE}),flush=True);return 0
    except BaseException as error:
        signal.alarm(0)
        if previous is not None or sys.getprofile()is not None:sys.setprofile(previous)
        failure={'schema':'fixed188-portable-worker-failure-v1','status':'UNKNOWN_SAVED_TARGET_RECHECK','error_type':type(error).__name__,'reason':str(error),'traceback':traceback.format_exc(),'frozen_manifest_sha256':frozen.manifest_hash,'guard':guard,'scientific_call_trace':trace,'historical_result_unchanged':True,'scientific_adoption':False,'native_calls':0}
        a.save(output/'UNKNOWN.json',failure);print(json.dumps({k:failure[k] for k in ('status','error_type','reason')}),flush=True);return 2

def valid_process(p):
    if type(p)is not dict:return False
    if any(type(p.get(k))is not dict for k in ('exact_child_wait4','final_group_observation','capture')):return False
    if set(p['capture'])!={'stdout','stderr'} or any(type(v)is not dict for v in p['capture'].values()):return False
    for name,v in p['capture'].items():
        if v.get('file')!=name+'.txt' or type(v.get('bytes'))is not int or v['bytes']<0 or type(v.get('sha256'))is not str or re.fullmatch('[0-9a-f]{64}',v['sha256'])is None:return False
        if v['bytes']!=v.get('captured_bytes'):return False
    return (p.get('schema')=='contained-stage-process-v2' and p.get('status')=='PROCESS_COMPLETED' and type(p.get('exit_code'))is int and p['exit_code']==0
      and p.get('process_started')is True and p.get('owned_child_reaped')is True and p.get('receipt_persisted')is True and p.get('parent_finalization_completed')is True and p.get('parent_aborted')is False
      and p['exact_child_wait4'].get('exact_child_reaped')is True and p['exact_child_wait4'].get('authority_lost')is False and p['final_group_observation'].get('state')=='ABSENT'
      and type(p.get('fatal_reasons'))is list and p['fatal_reasons']==[] and type(p.get('resource_reasons'))is list and p['resource_reasons']==[]
      and all(v.get('complete')is True and type(v.get('observed_bytes'))is int and type(v.get('captured_bytes'))is int and v['observed_bytes']==v['captured_bytes'] and v['observed_bytes']>=0 for v in p['capture'].values()))

def completion_record(output,frozen,kind,process,unchanged,launch_error):
    errors=[];records={}
    if launch_error is not None:errors.append({'phase':'launch','reason':launch_error})
    try:
        persisted=a.decode(a.file_bytes(output/'process/PROCESS_RECEIPT.json'));a.exact(persisted,process,'Persisted exact process receipt')
        a.need(valid_process(process),'Clean exact owned process/capture completion')
        records['process']=a.pin(output/'process/PROCESS_RECEIPT.json')
        for name,row in process['capture'].items():
            raw=a.file_bytes(output/'process'/(name+'.txt'),a.LIMITS['stream_bytes'])
            a.exact(a.digest(raw),{k:row[k] for k in ('bytes','sha256')},'Actual '+name+' capture bytes and SHA256')
            a.need(len(raw)==row['captured_bytes']==row['observed_bytes'],'Complete '+name+' byte counts')
            records[name]=a.pin(output/'process'/(name+'.txt'))
    except BaseException as error:errors.append({'phase':'owned_process','reason':str(error)})
    if unchanged is not True:errors.append({'phase':'input_integrity','reason':'Frozen inputs not confirmed unchanged'})
    if not errors:
        try:
            if kind=='artificial':
                report=a.decode(a.file_bytes(output/'worker/QUALIFICATION.json'))
                a.need(report['status']=='PASS_ARTIFICIAL_ADAPTER_QUALIFICATION' and report['frozen_manifest_sha256']==frozen.manifest_hash,'Exact artificial report')
                a.need(all(type(report[k])is int and report[k]==0 for k in ('saved_DAG_evaluations','scientific_modules_imported')),'Artificial metadata-only report')
                records['report']=a.pin(output/'worker/QUALIFICATION.json')
            else:
                complete=a.decode(a.file_bytes(output/'worker/WORKER_COMPLETE.json'))
                expected='PASS_IMPORT_ONLY' if kind=='imports' else 'PASS_SAVED_TARGET_FIELDS_RECHECK'
                a.need(complete['status']==expected and complete['frozen_manifest_sha256']==frozen.manifest_hash,'Exact complete worker identity')
                a.need(complete['scope']==a.SCOPE and complete['case']==a.CASE and complete['all_inputs_unchanged']is True,'Exact scope/case/unchanged inputs')
                a.need(type(complete['native_calls'])is int and complete['native_calls']==0 and type(complete['new_scientific_samples'])is int and complete['new_scientific_samples']==0,'No native call/new sample')
                g=complete['guard'];a.need(type(g['external_data_reads_blocked'])is int and g['external_data_reads_blocked']==(1 if kind=='imports' else 0) and type(g['network_process_attempts_blocked'])is int and g['network_process_attempts_blocked']==0,'Exact expected guard observations')
                file='IMPORT_RESULT.json' if kind=='imports' else 'COMPARISON.json';report=a.decode(a.file_bytes(output/'worker'/file))
                a.need(report['status']==expected and report['frozen_manifest_sha256']==frozen.manifest_hash,'Exact scoped comparison/import result')
                if kind=='imports':
                    a.exact(report['science_calls'],{'target_evaluations':0,'context_constructions':0,'model_audits':0,'canonical_exports':0,'blocked_scientific_calls':0,'blocked_legacy_or_out_of_scope_calls':0},'Import-only zero scientific calls')
                    a.exact(complete['scientific_call_trace'],report['science_calls'],'Import complete trace')
                    a.need(report['old_root_read_probe']=='REJECTED_BEFORE_READ','Actual old-root read rejected')
                if kind=='actual':
                    a.exact(complete['scientific_call_trace'],report['scientific_call_trace'],'Actual complete trace')
                    a.exact(report['scientific_call_trace'],{'target_evaluations':1,'context_constructions':1,'model_audits':1,'canonical_exports':1,'blocked_scientific_calls':0,'blocked_legacy_or_out_of_scope_calls':0},'Single target evaluation trace')
                    a.need(report['all_compared_scientific_fields_equal']is True and report['actual_released_correspondence_rechecked']is False,'Target-only scientific comparison')
                    a.need(report['canonical_function_comparison']['status']=='PASS_ALL_39_CANONICAL_FUNCTION_DIGESTS','Canonical comparison complete')
                    a.need(report['in_memory_projection']['scientific_hash_fields_rewritten']is False and report['in_memory_projection']['original_workspace_fallback']is False,'No digest rewrite/fallback')
                records['complete']=a.pin(output/'worker/WORKER_COMPLETE.json');records['report']=a.pin(output/'worker'/file)
        except BaseException as error:errors.append({'phase':'worker_record','reason':str(error)})
    return {'schema':'fixed188-portable-scope-parent-result-v1','status':('PASS_QUALIFIED_PREPARATION' if kind!='actual' else 'PASS_ONE_SAVED_TARGET_RECHECK_PENDING_INDEPENDENT_ADOPTION') if not errors else 'UNKNOWN_SCOPE_NOT_ADMITTED','qualification_kind':kind if kind!='actual' else None,'frozen_manifest_sha256':frozen.manifest_hash,'scope':a.SCOPE,'case':a.CASE,'inputs_unchanged':unchanged,'records':records,'errors':errors,'attempts':1,'scientific_adoption':False,'native_calls':0,'new_scientific_samples':0,'full_reset_uses':0}

def parent(args):
    frozen=a.Frozen(args.root,args.expected_manifest);output=a.canonical_path(args.output)
    a.need(output.parent.is_dir() and not output.exists(),'Fresh exact parent output')
    a.need(not output.is_relative_to(frozen.root),'Output must be outside immutable closure')
    a.need(shutil.disk_usage(output.parent).free>a.LIMITS['min_free_bytes']+a.LIMITS['output_tree_bytes'],'Disk floor plus output reserve')
    if args.action=='actual':go,go_pin=a.load_go(args.go,frozen.manifest_hash,output);deadline=go['deadline_utc']
    else:
        a.need(args.preparation_go is not None,'Explicit preparation-only GO required')
        prep_pin=a.pin(args.preparation_go);prep=a.decode(a.file_bytes(args.preparation_go))
        a.need(prep.get('status')=='GO_ARTIFICIAL_AND_IMPORT_QUALIFICATION' and prep.get('frozen_manifest_sha256')==frozen.manifest_hash,'Exact preparation-only authority')
        a.need(prep.get('saved_DAG_evaluations_authorized')==0 and type(prep.get('saved_DAG_evaluations_authorized'))is int,'Preparation prohibits saved math')
        a.need(prep.get('output_roots',{}).get(args.action)==str(output),'Exact qualification output root')
        deadline=prep['deadline_utc'];go_pin=prep_pin
    dt=datetime.fromisoformat(deadline);a.need(dt.tzinfo is not None and (dt-datetime.now(timezone.utc)).total_seconds()>a.LIMITS['wall_seconds']+10,'Enough authorized time for bounded scope/finalization')
    output.mkdir()
    a.save(output/'START.json',{'schema':'fixed188-new-scope-start-v1','GO':go_pin,'frozen_manifest_sha256':frozen.manifest_hash,'scope':a.SCOPE,'case':a.CASE,'action':args.action,'started_utc':datetime.now(timezone.utc).isoformat(),'python':a.pin(Path(sys.executable).resolve())})
    supervisor=a.load_module('fixed188_qualified_exact_child_supervisor',frozen.path('code/supervisor/bounded_process.py'))
    if args.action=='artificial':argv=[sys.executable,'-I','-S','-B',str(frozen.path('code/qualify_artificial.py')),'--root',str(frozen.root),'--expected-manifest',frozen.manifest_hash,'--output',str(output/'worker')]
    else:
        argv=[sys.executable,'-I','-S','-B',str(frozen.path('code/review.py')),args.action+'-worker','--root',str(frozen.root),'--expected-manifest',frozen.manifest_hash,'--output',str(output/'worker')]
        argv+=['--go',str(Path(args.go).absolute())] if args.action=='actual' else ['--reject-read-root',args.reject_read_root]
    process=None;error=None
    try:
        process=supervisor.run_bounded(argv,output/'process',deadline,wall_seconds=a.LIMITS['wall_seconds'],rss_bytes=a.LIMITS['rss_bytes'],stream_bytes=a.LIMITS['stream_bytes'],file_bytes=a.LIMITS['file_bytes'],watch_files=[output/'worker'/n for n in ['TARGET_RESULT.json','FUNCTIONS.json','COMPARISON.json','UNKNOWN.json','IMPORT_RESULT.json','QUALIFICATION.json']],output_tree=output,output_tree_bytes=a.LIMITS['output_tree_bytes'],min_free_bytes=a.LIMITS['min_free_bytes'])
    except BaseException as ex:error=repr(ex)
    try:unchanged=frozen.verify()
    except BaseException as ex:unchanged=False;error=(error+'; ' if error else '')+'Input integrity: '+repr(ex)
    result=completion_record(output,frozen,args.action,process,unchanged,error);result['GO']=go_pin
    a.save(output/'RUN_RECEIPT.json',result);print(json.dumps({k:result[k] for k in ('status','qualification_kind','errors')}),flush=True)
    return 0 if result['status'].startswith('PASS_') else 2

def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['artificial','imports','actual','imports-worker','actual-worker']);p.add_argument('--root',required=True);p.add_argument('--expected-manifest',required=True);p.add_argument('--output',required=True);p.add_argument('--go');p.add_argument('--preparation-go');p.add_argument('--reject-read-root');args=p.parse_args()
    return worker(args) if args.action.endswith('-worker') else parent(args)

if __name__=='__main__':raise SystemExit(main())
