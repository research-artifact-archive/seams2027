"""Strict saved-input authority and comparison for one fixed188 target scope.

This adapter does not call the old target runner or any native/solver entry.
Scientific source modules remain byte-identical and are loaded by exact path.
"""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import copy, hashlib, importlib.util, json, re, sys

CASE='corpus188__original'
SCOPE='target_original_literal'
SOURCE={'bytes':3924,'sha256':'0e6faaedcd2bf8ab7b80d239231973f4588922ae5ff85a95927894cf78531e3b'}
LIMITS={'wall_seconds':60,'rss_bytes':536870912,'stream_bytes':1048576,'file_bytes':2097152,'output_tree_bytes':8388608,'min_free_bytes':1073741824}
CORE_PINS={
 'code/target_certificate.py':'f77a6c2ce63c94a53b13a551aa2a5cbaa48f70336d6a1c1e2e3b9a5cd41422d8',
 'code/context/generic_base.py':'3c465e4253712c6f021920e6a164ef48c63c5bf6cfb3432d17ab95fb5778ebda',
 'code/context/vendor/bdd_core.py':'f9497519b8a073a29e5748c908cadc804f437080cf12d36558d9e0210462dbac',
 'code/runtime_guard.py':'c6df8c8921976cd0f8e1ea03fefd11b65705603dbc755e41b49de020eece3b12',
 'code/supervisor/bounded_process.py':'ee08963ad88b0259c744cbed732f339536fd504a89342c5e661449ffc0e367c9',
 'code/supervisor/owned_process.py':'20ce5ef1912afd9ff144a9c4c102d347e09e5006596372d38bd3e05ad3b57596'}
OUTPUT_KEYS={'schema','status','admitted_scientific_result','fixture_id','checks','predicate_counts','source_justice_correspondence','proof_composition','scientific_conclusions','separate_evidence_not_claimed','valuation_witnesses','algorithmic_counters','all_model_AUX_policy','model_fields','BDD_nodes_including_terminals','root_digests'}
WRAPPER_KEYS={'limits','model_audit','authorization','producer_admission','original_model','profile','full_reset_uses','started_utc','saved_BDD_inputs','functions','input_pins','finished_utc','elapsed_seconds'}
OPERATIONAL_KEYS={'admitted_scientific_result','BDD_nodes_including_terminals'}
PASS_STATUS='PASS_TARGET_COOPERATIVE_RESIDUAL_LOSS_AND_INITIAL_PRESERVATION'

class Rejection(ValueError):pass

def need(ok,message):
    if not ok:raise Rejection(message)

def sha(raw):return hashlib.sha256(raw).hexdigest()
def digest(raw):return {'bytes':len(raw),'sha256':sha(raw)}
def unique(pairs):
    result={}
    for k,v in pairs:
        need(k not in result,'Duplicate JSON key: '+str(k));result[k]=v
    return result

def decode(raw):
    def bad(value):raise Rejection('Nonfinite JSON number: '+value)
    return json.loads(raw.decode('utf-8'),object_pairs_hook=unique,parse_constant=bad)

def encoded(obj):return (json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def exact(a,b,label='value'):
    need(type(a)is type(b),label+' type differs')
    if isinstance(a,dict):
        need(set(a)==set(b),label+' key set differs')
        for k in a:exact(a[k],b[k],label+'/'+k)
    elif isinstance(a,list):
        need(len(a)==len(b),label+' length differs')
        for i,(x,y) in enumerate(zip(a,b)):exact(x,y,label+'/'+str(i))
    else:need(a==b,label+' differs')

def canonical_path(path):
    p=Path(path).absolute()
    need('..' not in p.parts and p.resolve()==p,'Canonical path required')
    cur=Path(p.anchor)
    for part in p.parts[1:]:
        cur/=part;need(not cur.is_symlink(),'Symlink path component')
    return p

def relative_name(name):
    need(type(name)is str and bool(name),'Relative file name')
    p=PurePosixPath(name)
    need(not p.is_absolute() and p.as_posix()==name and '\\' not in name,'Canonical relative file name')
    need(all(x not in ('','.','..') for x in name.split('/')),'Unsafe relative file name')
    return name

def file_bytes(path,cap=2097152):
    p=canonical_path(path);need(p.is_file() and p.stat().st_size<=cap,'Regular bounded input file')
    raw=p.read_bytes();need(len(raw)<=cap,'Read byte cap');return raw

def pin(path):return {'path':str(canonical_path(path)),**digest(file_bytes(path))}

def save(path,obj):
    raw=encoded(obj);need(len(raw)<=LIMITS['file_bytes'],'Output file cap')
    p=Path(path);need(p.parent.is_dir() and not p.exists() and not p.is_symlink(),'Fresh output file')
    with p.open('xb') as f:f.write(raw)
    return {'file':p.name,**digest(raw)}

class Frozen:
    def __init__(self,root,expected_manifest):
        self.root=canonical_path(root);need(self.root.is_dir(),'Closure directory')
        raw=file_bytes(self.root/'FROZEN_MANIFEST.json');need(sha(raw)==expected_manifest,'Frozen manifest hash')
        self.manifest_hash=expected_manifest;self.manifest=decode(raw)
        need(self.manifest.get('schema')=='fixed188-portable-frozen-manifest-v1','Frozen manifest schema')
        need(self.manifest.get('scope')==SCOPE and self.manifest.get('case')==CASE,'Fixed target scope/case')
        self.files={}
        for row in self.manifest['files']:
            name=relative_name(row['file']);need(name not in self.files,'Duplicate manifest file')
            need(type(row.get('bytes'))is int and row['bytes']>=0,'Exact integer byte pin')
            need(type(row.get('sha256'))is str and re.fullmatch('[0-9a-f]{64}',row['sha256'])is not None,'SHA256 pin')
            self.files[name]=row
        for name,h in CORE_PINS.items():need(name in self.files and self.files[name]['sha256']==h,'Unchanged core pin: '+name)
        self.verify()
    def path(self,name):
        name=relative_name(name);need(name in self.files,'File outside frozen authority: '+name)
        return canonical_path(self.root/name)
    def raw(self,name):
        raw=file_bytes(self.path(name));row=self.files[name]
        exact(digest(raw),{k:row[k] for k in ('bytes','sha256')},'Input pin '+name);return raw
    def read(self,name):return decode(self.raw(name))
    def verify(self):
        present=set()
        for entry in self.root.rglob('*'):
            need(not entry.is_symlink(),'Symlink anywhere in frozen closure')
            if entry.is_file():present.add(str(entry.relative_to(self.root)))
            else:need(entry.is_dir(),'Nonregular entry in frozen closure')
        need(present==set(self.files)|{'FROZEN_MANIFEST.json'},'Exact frozen file roster; unmanifested or missing file')
        for name in self.files:self.raw(name)
        need(sha(file_bytes(self.root/'FROZEN_MANIFEST.json'))==self.manifest_hash,'Manifest changed')
        return True

def check_reference(ref):
    need(type(ref)is dict,'BDD reference object')
    name=relative_name(ref.get('file'));need(PurePosixPath(name).name==name and name.endswith('.bdd'),'BDD basename only')
    need(type(ref.get('bytes'))is int and ref['bytes']>=0,'BDD exact byte count')
    need(type(ref.get('sha256'))is str and re.fullmatch('[0-9a-f]{64}',ref['sha256'])is not None,'BDD SHA256')
    return name

def model_references(model):
    need(type(model.get('original_bdds'))is dict and set(model['original_bdds'])=={'thetaE','thetaS','rhoE','rhoS','domain','domain_ENV_next','domain_SYS_next'},'All seven original relation/domain references')
    just=model.get('original_justices');need(type(just)is dict and set(just)=={'ENV','SYS'},'Justice owners')
    need(type(just['ENV'])is list and len(just['ENV'])==3 and type(just['SYS'])is list and len(just['SYS'])==1,'All ordered original justices')
    refs=list(model['original_bdds'].values())+just['ENV']+just['SYS']
    names=[check_reference(x) for x in refs];need(len(names)==11 and len(set(names))==11,'Exactly eleven declared BDD basenames')
    return refs

def project_inputs(profile,model,source_path,source_pin):
    exact(source_pin,SOURCE,'Exact source bytes')
    need(type(profile)is dict and type(model)is dict,'Metadata objects')
    for obj in (profile,model):
        exact({k:obj.get(k) for k in ('fixture_id','case_id','variant')},{'fixture_id':CASE,'case_id':'corpus188','variant':'original'},'Fixed identity')
    need(model.get('schema')=='k7-native-model-export-v1','Model schema')
    need(type(profile.get('source'))is dict and set(profile['source'])=={'path','bytes','sha256'},'Exact profile source fields')
    exact(model.get('input'),profile['source'],'Identical recorded source references')
    exact({k:profile['source'][k] for k in ('bytes','sha256')},SOURCE,'Source metadata pin')
    old=profile['source']['path'];need(type(old)is str and old.startswith('research:experiment/'),'Recorded anonymous source path')
    profile_view=copy.deepcopy(profile);model_view=copy.deepcopy(model)
    local=str(canonical_path(source_path));profile_view['source']['path']=local;model_view['input']['path']=local
    back_p=copy.deepcopy(profile_view);back_m=copy.deepcopy(model_view);back_p['source']['path']=old;back_m['input']['path']=old
    exact(back_p,profile,'Profile non-path identity');exact(back_m,model,'Model non-path identity')
    return profile_view,model_view,{'projection':'IN_MEMORY_DECLARED_SOURCE_LOCATION_ONLY','changes':[{'file':'inputs/PROFILE.json','json_pointer':'/source/path','recorded_path':old,'local_path':local},{'file':'inputs/original/model.json','json_pointer':'/input/path','recorded_path':old,'local_path':local}],'scientific_hash_fields_rewritten':False,'original_workspace_fallback':False,'persisted_input_mutations':0}

def origin_pin(row):return {'bytes':row['origin_bytes'],'sha256':row['origin_sha256']}

def admit_saved_inputs(frozen):
    profile=frozen.read('inputs/PROFILE.json');model=frozen.read('inputs/original/model.json')
    refs=model_references(model)
    for r in refs:exact(digest(frozen.raw('inputs/original/'+r['file'])),{k:r[k] for k in ('bytes','sha256')},'Declared BDD current bytes')
    need({n for n in frozen.files if n.startswith('inputs/original/') and n.endswith('.bdd')}=={'inputs/original/'+r['file'] for r in refs},'No missing or undeclared model BDD inputs')
    source=frozen.raw('inputs/source.spectra')
    pv,mv,projection=project_inputs(profile,model,frozen.path('inputs/source.spectra'),digest(source))
    origins=frozen.read('authority/ORIGIN_COPY_BINDINGS.json');by={x['file']:x for x in origins['bindings']}
    expected=frozen.read('expected/RESULT.json')
    for file,key in [('inputs/original/model.json','original_model'),('inputs/PROFILE.json','profile'),('expected/FUNCTIONS.json','functions')]:
        need(file in by,'Historical origin mapping exists')
        exact(digest(frozen.raw(file)),{'bytes':by[file]['copy_bytes'],'sha256':by[file]['copy_sha256']},'Current anonymous copy identity')
        exact({k:expected[key][k] for k in ('bytes','sha256')},origin_pin(by[file]),'Historical result binds original identity')
    saved=expected['saved_BDD_inputs'];need(type(saved)is list and len(saved)==11,'Historical result used eleven BDD files')
    old={PurePosixPath(x['path']).name:{k:x[k] for k in ('bytes','sha256')} for x in saved}
    need(len(old)==11,'Distinct historical BDD names')
    exact(old,{r['file']:{k:r[k] for k in ('bytes','sha256')} for r in refs},'Historical/current BDD bytes')
    return {'profile':pv,'model':mv,'expected':expected,'projection':projection,'declared_refs':refs}

def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);need(spec is not None and spec.loader is not None,'Exact module loader')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    need(Path(module.__file__).resolve()==Path(path).resolve(),'Imported module origin')
    return module

def load_scientific(frozen):
    target=load_module('fixed188_portable_unchanged_target',frozen.path('code/target_certificate.py'))
    context=load_module('fixed188_portable_unchanged_context',frozen.path('code/context/generic_base.py'))
    need(Path(context._bdd_module.__file__).resolve()==frozen.path('code/context/vendor/bdd_core.py'),'Nested exact ROBDD origin')
    context.MAX_CARRIER=33792
    return target,context

def validate_result_shape(result,historical):
    need(set(result)==(OUTPUT_KEYS|WRAPPER_KEYS if historical else OUTPUT_KEYS),'Exact result field roster')
    need(result['schema']=='fixed188-target-policy-certificate-v1' and result['fixture_id']==CASE,'Target result identity')
    need(result['status']==PASS_STATUS,'Target obligations must pass')
    need(result['admitted_scientific_result']is (True if historical else False),'Keep historical/new adoption flags distinct')
    need(type(result['checks'])is dict and len(result['checks'])==30,'All thirty target checks')
    need(all(type(x)is dict and type(x.get('passes'))is bool and x['passes']is True for x in result['checks'].values()),'All target pass flags are literal True')
    failure_checks=[v for v in result['checks'].values() if 'counterexample_canonical_sha256'in v]
    need(len(failure_checks)==28,'All twenty-eight failure roots')
    for row in failure_checks:
        need(row['counterexample_canonical_sha256']==sha(b'0'),'Every failure canonical root is zero')
        exact(row['counterexample_support'],[],'Failure support')
    exact(result['predicate_counts'],{'R_speed_rule':3072,'P':2560,'C':6656,'bad_state':1},'Fixed predicate counts')
    need(type(result['root_digests'])is dict and len(result['root_digests'])==39,'Complete canonical root roster')
    need(all(type(v)is str and re.fullmatch('[0-9a-f]{64}',v)is not None for v in result['root_digests'].values()),'Canonical root SHA256 format')
    exact(result['algorithmic_counters'],{'native_calls':0,'solver_calls':0,'fixed_point_iterations':0,'graph_extractions':0},'No solver/native/graph extraction')
    need(type(result['BDD_nodes_including_terminals'])is int and 2<=result['BDD_nodes_including_terminals']<=500000,'Bounded BDD allocation count')

def compare_result(actual,expected,model_audit):
    validate_result_shape(actual,False);validate_result_shape(expected,True)
    compared=sorted(OUTPUT_KEYS-OPERATIONAL_KEYS)
    for key in compared:exact(actual[key],expected[key],'Scientific field '+key)
    exact(model_audit,expected['model_audit'],'Original model typed audit')
    return {'status':'PASS_SAVED_TARGET_FIELDS_RECHECK','all_compared_scientific_fields_equal':True,'compared_fields':compared,'historical_wrapper_fields_not_replayed':sorted(WRAPPER_KEYS),'operational_allocation_counts':{'historical':expected['BDD_nodes_including_terminals'],'current':actual['BDD_nodes_including_terminals']},'historical_admitted_scientific_result':True,'current_mathematical_module_admitted_scientific_result':False,'fresh_adoption_requires_root_and_independent_review':True,'actual_released_correspondence_rechecked':False,'native_calls':0,'new_scientific_samples':0}

def canonical_export(export):
    need(type(export)is dict and set(export)=={'schema','variable_count','fields','roots','nodes'},'Canonical export fields')
    need(export['schema']=='fixed188-canonical-target-functions-v1','Canonical export schema')
    n=export['variable_count'];need(type(n)is int and 0<n<=64,'Canonical variable count')
    need(type(export['roots'])is dict and type(export['nodes'])is list,'Canonical root/node records')
    nodes={};unique_nodes=set()
    for row in export['nodes']:
        need(type(row)is list and len(row)==4 and all(type(v)is int for v in row),'Canonical node integer tuple')
        u,v,lo,hi=row;need(u>=2 and u not in nodes and 0<=v<n and lo>=0 and hi>=0 and lo!=hi,'Canonical node identity/reduction')
        need((v,lo,hi)not in unique_nodes,'Unique reduced node');nodes[u]=(v,lo,hi);unique_nodes.add((v,lo,hi))
    for u,(v,lo,hi) in nodes.items():
        for child in (lo,hi):need(child in (0,1) or child in nodes and nodes[child][0]>v,'Strict canonical variable order and closed children')
    seen=set();memo={0:sha(b'0'),1:sha(b'1')}
    def visit(u):
        need(type(u)is int and (u in (0,1) or u in nodes),'Closed integer canonical root')
        if u in memo:return memo[u]
        seen.add(u);v,lo,hi=nodes[u];memo[u]=sha(f'{v}:{visit(lo)}:{visit(hi)}'.encode());return memo[u]
    digests={name:visit(u) for name,u in export['roots'].items()}
    need(seen==set(nodes),'No unreachable canonical export nodes')
    return digests

def compare_exports(current,historical,actual_result,expected_result):
    exact(current['fields'],historical['fields'],'Export model fields')
    exact(current['variable_count'],32,'Exact original export variable count');exact(historical['variable_count'],32,'Historical original variable count')
    cur=canonical_export(current);old=canonical_export(historical)
    exact(cur,actual_result['root_digests'],'Current roots and recomputed canonical digests')
    exact(old,expected_result['root_digests'],'Historical roots and recorded canonical digests')
    exact(cur,old,'All historical/current canonical root digests')
    return {'status':'PASS_ALL_39_CANONICAL_FUNCTION_DIGESTS','root_count':len(cur),'digests':cur,'current_export_nodes':len(current['nodes']),'historical_export_nodes':len(historical['nodes']),'node_ids_or_file_bytes_not_required_equal':True}

def load_go(path,manifest_hash,output):
    ref=pin(path);go=decode(file_bytes(path))
    keys={'schema','status','frozen_manifest_sha256','scope','case','output_root','attempts','saved_evaluations','native_calls','solver_calls','fixed_point_calls','deadline_utc','limits','qualification_receipts'}
    need(type(go)is dict and set(go)==keys,'Exact new scope authority fields')
    need(go['schema']=='fixed188-portable-single-scope-go-v1' and go['status']=='GO','Fresh target authority required')
    need(go['frozen_manifest_sha256']==manifest_hash and go['scope']==SCOPE and go['case']==CASE,'GO exact manifest/scope/case')
    need(go['output_root']==str(canonical_path(output)),'GO exact output root')
    for k,n in [('attempts',1),('saved_evaluations',1),('native_calls',0),('solver_calls',0),('fixed_point_calls',0)]:need(type(go[k])is int and go[k]==n,'Exact integer authority '+k)
    exact(go['limits'],LIMITS,'Exact scope limits')
    deadline=datetime.fromisoformat(go['deadline_utc']);need(deadline.tzinfo is not None and (deadline-datetime.now(timezone.utc)).total_seconds()>1,'Unexpired timezone-aware GO')
    need(type(go['qualification_receipts'])is list and len(go['qualification_receipts'])==2,'Exactly artificial/import qualification bindings')
    kinds=set()
    for q in go['qualification_receipts']:
        need(type(q)is dict and set(q)=={'path','bytes','sha256'},'Qualification receipt pin fields');exact(pin(q['path']),q,'Qualification receipt pin')
        record=decode(file_bytes(q['path']))
        need(record.get('status')=='PASS_QUALIFIED_PREPARATION' and record.get('frozen_manifest_sha256')==manifest_hash,'Prior qualification passed for this exact freeze')
        kind=record.get('qualification_kind');need(kind in ('artificial','imports') and kind not in kinds,'Distinct artificial/import qualifications');kinds.add(kind)
    need(kinds=={'artificial','imports'},'Both prerequisite qualifications')
    return go,ref
