"""Prepared fixed188 source-policy certificate; no fixed point or native calls.

Importing this module performs no model load and constructs no BDD manager.
Root must authorize a fresh saved original model before main() is dispatched.
evaluate_context() can be called by an independently authorized pair wrapper.
"""
from functools import lru_cache
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import math
import signal
import sys
import time
import traceback

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BASE = HERE.parent
FIXTURE = 'corpus188__original'
SOURCE_SHA = '0e6faaedcd2bf8ab7b80d239231973f4588922ae5ff85a95927894cf78531e3b'
SOURCE_BYTES = 3924
LANES = ('First', 'Second', 'Third')
EXPECTED_ENV = tuple(prefix + lane + 'Lane' for prefix in ('pedestrian', 'greenLight', 'obstacle') for lane in LANES) + ('crosswalk',)
LIMITS = {'variables': 32, 'typed_carrier': 33792, 'BDD_nodes_including_terminals': 500000, 'wall_seconds': 60}


def require(test, message):
    if not test:
        raise ValueError(message)


def pin(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


def verify_pin(ref):
    require(pin(ref['path']) == ref, 'Pinned input drift: ' + ref['path'])


def count(b, root, variables):
    variables = tuple(sorted(variables))
    where = {v: i for i, v in enumerate(variables)}
    require(b.support(root) <= set(variables), 'Counting support mismatch')
    @lru_cache(None)
    def visit(u, pos):
        if u < 2:
            return u << (len(variables) - pos)
        v, lo, hi = b.nodes[u]
        k = where[v]
        return (visit(lo, k + 1) + visit(hi, k + 1)) << (k - pos)
    return visit(root, 0)


def digest(b, root):
    @lru_cache(None)
    def visit(u):
        if u < 2:
            return hashlib.sha256(str(u).encode()).hexdigest()
        v, lo, hi = b.nodes[u]
        return hashlib.sha256(f'{v}:{visit(lo)}:{visit(hi)}'.encode()).hexdigest()
    return visit(root)


def exact_context(ctx):
    """Reject added logical state rather than project it away."""
    require(ctx.model['schema'] == 'k7-native-model-export-v1', 'Model schema')
    require(ctx.model['fixture_id'] == FIXTURE and ctx.model['case_id'] == 'corpus188' and ctx.model['variant'] == 'original', 'Only original fixed188')
    require(ctx.model['input']['sha256'] == SOURCE_SHA and ctx.model['input']['bytes'] == SOURCE_BYTES, 'Original188 source identity')
    require(ctx.b.n == 32 and ctx.carrier == 33792, 'Exact fixed188 variables/carrier; unexpected compiler support')
    require(ctx.b.limit <= 500000, 'BDD node limit')
    require(set(ctx.by_name) == set(EXPECTED_ENV) | {'currentLane', 'speed'}, 'Exact12 fields; no AUX/helper')
    for name in EXPECTED_ENV:
        field = ctx.by_name[name]
        require(field['owner'] == field['role'] == 'ENV' and set(field['values']) == {'false', 'true'}, 'Exact Boolean ENV field: ' + name)
    for name, values in [('currentLane', set(LANES)), ('speed', {str(i) for i in range(11)})]:
        field = ctx.by_name[name]
        require(field['owner'] == field['role'] == 'SYS' and set(field['values']) == values, 'Exact SYS field: ' + name)
    require(len(ctx.current) == len(ctx.next) == 16 and len(ctx.current_env) == len(ctx.env_next) == 10 and len(ctx.current_sys) == len(ctx.sys_next) == 6, 'Exact bit partitions')
    require(len(ctx.justices['ENV']) == 3 and len(ctx.justices['SYS']) == 1, 'Ordered original justice counts')


def evaluate_context(ctx):
    """Only evaluate fixed188 target obligations on a fully admitted Context.

    The enclosing launcher is responsible for authorization and native-producer
    admission. This function verifies model identity, all actual relation
    obligations, all original justices and the actual original initializer.
    It does not solve W/V/K/W_C, emit a controller or analyze actual helper logic.
    """
    exact_context(ctx)
    b, f = ctx.b, ctx.formulas
    D = ctx.domain
    Dn = b.rename(D, ctx.prime)
    edge = b.conj(D, Dn)
    lit = ctx.literal
    def lane(i, nxt=False):
        return lit('currentLane', LANES[i], nxt)
    def obs(i, nxt=False):
        return lit('obstacle' + LANES[i] + 'Lane', 'true', nxt)
    def free(i, nxt=False):
        return b.conj(lit('greenLight' + LANES[i] + 'Lane', 'true', nxt), lit('pedestrian' + LANES[i] + 'Lane', 'false', nxt), lit('obstacle' + LANES[i] + 'Lane', 'false', nxt))
    F = b.disj(*(b.conj(lane(i), free(i)) for i in range(3)))
    Fn = b.rename(F, ctx.prime)
    speed_rule = b.disj(b.conj(F, lit('speed', '1')), b.conj(b.neg(F), lit('speed', '0')))
    R = b.conj(D, speed_rule)
    Q = b.disj(b.neg(lane(1)), b.neg(obs(1)))
    P = b.conj(R, Q)
    Pn = b.rename(P, ctx.prime)
    Rn = b.rename(R, ctx.prime)

    # Disjoint ordered guards, with a single next-lane choice in every case.
    g1 = b.conj(lane(1), obs(1))
    g2 = b.conj(b.neg(g1), b.disj(b.conj(lane(0), obs(0)), b.conj(lane(2), obs(2))))
    g3 = b.conj(b.neg(b.disj(g1, g2)), b.neg(obs(1, True)))
    g4 = b.neg(b.disj(g1, g2, g3))
    c1 = b.ite(b.neg(obs(0, True)), lane(0, True), lane(2, True))
    c4 = b.disj(b.conj(lane(0), lane(0, True)), b.conj(lane(2), lane(2, True)), b.conj(lane(1), lane(0, True)))
    selected_lane = b.disj(b.conj(g1, c1), b.conj(g2, lane(1, True)), b.conj(g3, lane(1, True)), b.conj(g4, c4))
    policy = b.conj(edge, selected_lane, Rn)
    legal_R = b.conj(policy, R, f['rhoE'])
    legal_P = b.conj(policy, P, f['rhoE'])

    # C quantifies every typed next ENV input, including original-illegal ones.
    response = b.exists(b.conj(f['rhoS'], ctx.domain_sn), ctx.sys_next)
    missing_typed_reply = b.conj(D, b.exists(b.conj(ctx.domain_en, b.neg(response)), ctx.env_next))
    C = b.conj(D, b.neg(missing_typed_reply))

    clear_env = {name: ('true' if name.startswith('greenLight') else 'false') for name in EXPECTED_ENV}
    bad_env = dict(clear_env, obstacleSecondLane='true')
    bad = dict(bad_env, currentLane='Second', speed='0')
    initial = dict(clear_env, currentLane='First', speed='1')
    bad_next = dict(clear_env, obstacleFirstLane='true', obstacleThirdLane='true')
    s = ctx.cube(bad)
    t = ctx.cube(initial)
    bad_input = ctx.cube(bad_next, True)
    clear = ctx.cube(clear_env)
    clear_next = ctx.cube(clear_env, True)
    selector = b.conj(R, lane(0))
    prefix_edge = b.conj(t, ctx.cube(bad, True))
    allclear_first = ctx.cube(dict(clear_env, currentLane='First', speed='1'), True)
    allclear_second = ctx.cube(dict(clear_env, currentLane='Second', speed='1'), True)

    failures = {}
    def zero(name, root):
        failures[name] = root
    # Totality and exact edge count together establish one output per typed input.
    policy_input_count = ctx.carrier * 1024
    actual_policy_edges = count(b, policy, ctx.current + ctx.next)
    zero('policy_missing_typed_response', b.conj(D, ctx.domain_en, b.neg(b.exists(policy, ctx.sys_next))))
    zero('policy_bad_safety_response', b.conj(legal_R, b.neg(f['rhoS'])))
    zero('policy_does_not_enter_P', b.conj(legal_R, b.neg(Pn)))
    zero('P_legal_freeSecond_does_not_select_free_lane', b.conj(legal_P, free(1, True), b.neg(Fn)))
    zero('P_legal_freeSecond_does_not_select_Second', b.conj(legal_P, free(1, True), b.neg(lane(1, True))))
    zero('P_outside_C', b.conj(P, b.neg(C)))
    zero('initial_selector_outside_P', b.conj(selector, b.neg(P)))
    zero('initial_selector_violates_thetaS', b.conj(selector, f['thetaE'], b.neg(f['thetaS'])))
    initial_missing = b.conj(ctx.domain_ec, f['thetaE'], b.neg(b.exists(b.conj(selector, f['thetaS']), ctx.current_sys)))
    zero('unanswered_original_initial_ENV', initial_missing)
    zero('allclear_suffix_not_ENV_safe', b.conj(D, clear_next, b.neg(f['rhoE'])))
    for i, justice in enumerate(ctx.justices['ENV']):
        zero(f'ENV_justice_{i}_source_mismatch', b.conj(D, b.apply('xor', justice, free(i))))
        zero(f'allclear_suffix_violates_ENV_justice_{i}', b.conj(D, clear, b.neg(justice)))
    zero('SYS_justice_source_mismatch', b.conj(D, b.apply('xor', ctx.justices['SYS'][0], F)))
    zero('bad_state_outside_R', b.conj(s, b.neg(R)))
    zero('bad_state_in_C', b.conj(s, C))
    zero('bad_input_has_any_full_typed_SYS_response', b.conj(s, bad_input, response))
    zero('bad_input_is_original_ENV_legal', b.conj(s, bad_input, f['rhoE']))
    zero('bad_state_not_original_initialized', b.conj(s, b.neg(b.conj(f['thetaE'], f['thetaS']))))
    zero('prefix_initial_state_not_initialized', b.conj(t, b.neg(b.conj(f['thetaE'], f['thetaS']))))
    zero('prefix_edge_not_original_safe', b.conj(prefix_edge, b.neg(b.conj(f['rhoE'], f['rhoS']))))
    zero('prefix_start_outside_R', b.conj(t, b.neg(R)))
    zero('bad_allclear_first_response_policy_mismatch', b.conj(s, allclear_first, b.neg(policy)))
    zero('allclear_First_to_Second_policy_mismatch', b.conj(t, allclear_second, b.neg(policy)))
    stationary_second = ctx.cube(dict(clear_env, currentLane='Second', speed='1'))
    zero('allclear_Second_selfloop_policy_mismatch', b.conj(stationary_second, allclear_second, b.neg(policy)))

    checks = {name: {'passes': root == 0, 'counterexample_canonical_sha256': digest(b, root), 'counterexample_support': sorted(b.support(root))} for name, root in failures.items()}
    checks['policy_exactly_one_response_for_each_typed_input'] = {'passes': actual_policy_edges == policy_input_count and failures['policy_missing_typed_response'] == 0, 'actual_policy_edge_count': actual_policy_edges, 'typed_current_times_typed_next_ENV': policy_input_count}
    checks['specified_objects_nonempty'] = {'passes': all(x != 0 for x in (D, R, P, selector, s, t, bad_input, prefix_edge)) and count(b, s, ctx.current) == 1 and count(b, t, ctx.current) == 1, 'bad_state_count': count(b, s, ctx.current), 'prefix_start_count': count(b, t, ctx.current)}
    passed = all(row['passes'] for row in checks.values())
    roots = {'D': D, 'R_speed_rule': R, 'P': P, 'C': C, 'base_policy': policy, 'original_legal_R_policy': legal_R, 'initial_selector': selector, 'bad_state': s, 'bad_typed_next_ENV': bad_input, 'legal_initial_to_bad_edge': prefix_edge, 'allclear_ENV': clear, **{'failure_' + name: root for name, root in failures.items()}}
    result = {
        'schema': 'fixed188-target-policy-certificate-v1',
        'status': 'PASS_TARGET_COOPERATIVE_RESIDUAL_LOSS_AND_INITIAL_PRESERVATION' if passed else 'UNKNOWN_TARGET_OBLIGATION_FAILED',
        'admitted_scientific_result': False,
        'fixture_id': FIXTURE,
        'checks': checks,
        'predicate_counts': {name: count(b, root, ctx.current) for name, root in [('R_speed_rule', R), ('P', P), ('C', C), ('bad_state', s)]},
        'source_justice_correspondence': 'Three ordered original ENV free-lane justices; one original SYS occupied-free justice. All checked on the full typed current domain.',
        'proof_composition': ['Base policy is total and deterministic for all typed inputs.', 'Every original-legal base-policy response from R is safe and enters P.', 'On P every next freeSecond input yields a next occupied free lane, so original assumption justice2 forces SYS justice.', 'All-clear ENV suffix is legal from every typed state and satisfies every original ENV justice; the same policy remains safe, proving legal-prefix cooperation.', 'The original initial selector lies in P subset C and answers every original initial ENV value, establishing initial cooperation and initial strict feasibility under C.', 'The specified original-initialized bad state lies in R outside C; its first legal policy response enters P. It is therefore cooperative but excluded by the literal complete-relation transform.', 'The explicit safe first edge from an initialized allclear/First state to the bad state can be prepended on the matching first-input branch. Thereafter the base policy wins. The one-bit strategy memory for this finite prefix is not source-model AUX.'],
        'scientific_conclusions': {'original_initial_cooperation': True if passed else None, 'literal_initial_W_C': True if passed else None, 'specified_cooperative_state_lost_by_literal_transform': True if passed else None, 'initial_loss': False if passed else None},
        'separate_evidence_not_claimed': ['Complete K/W/W_C region or fixed points', 'Actual released helper behavior', 'A native emitted controller', 'A repair or deployment episode', 'Historical C model identity'],
        'valuation_witnesses': {'initial_to_bad_prefix': [initial, bad], 'bad_typed_next_ENV': bad_next, 'allclear_suffix_ENV': clear_env},
        'algorithmic_counters': {'native_calls': 0, 'solver_calls': 0, 'fixed_point_iterations': 0, 'graph_extractions': 0},
        'all_model_AUX_policy': 'Exact source profile requires no AUX; any unexpected AUX is rejected, never projected away.',
        'model_fields': ctx.fields,
        'BDD_nodes_including_terminals': len(b.nodes),
        'root_digests': {name: digest(b, root) for name, root in roots.items()},
    }
    return result, roots


def export_roots(path, ctx, roots):
    seen, stack = set(), list(roots.values())
    while stack:
        root = stack.pop()
        if root < 2 or root in seen:
            continue
        seen.add(root)
        stack.extend(ctx.b.nodes[root][1:])
    save(path, {'schema': 'fixed188-canonical-target-functions-v1', 'variable_count': ctx.b.n, 'fields': ctx.fields, 'roots': roots, 'nodes': [[u, *ctx.b.nodes[u]] for u in sorted(seen)]})


def run(model_directory, profile_path, authorization_path, output_directory):
    """Gated offline dispatch, never a native producer invocation."""
    started = time.monotonic()
    started_utc = datetime.now(timezone.utc).isoformat()
    output_directory = Path(output_directory).resolve()
    require(output_directory.is_relative_to(HERE), 'Output must be under this preparation directory')
    require(not output_directory.exists(), 'Fresh output required')
    output_directory.mkdir(parents=True)
    result = {'status': 'UNKNOWN_INCOMPLETE', 'fixture_id': FIXTURE, 'limits': LIMITS, 'native_calls': 0, 'full_reset_uses': 0, 'started_utc': started_utc}
    def timeout(*_):
        raise TimeoutError('Fixed188 target certificate60-second wall limit')
    refs = []
    try:
        signal.signal(signal.SIGALRM, timeout)
        signal.alarm(60)
        auth_path = Path(authorization_path).resolve()
        auth = json.loads(auth_path.read_text())
        require(auth.get('status') == 'APPROVED_FIXED188_TARGET_CERTIFICATE' and auth.get('fixture_id') == FIXTURE, 'Explicit fixed188 target authorization required')
        require(type(auth.get('native_calls_authorized')) is int and auth['native_calls_authorized'] == 0 and type(auth.get('fixed_points_authorized')) is int and auth['fixed_points_authorized'] == 0, 'Target-only scope uses exact integer zero')
        deadline = datetime.fromisoformat(auth['deadline_utc'].replace('Z', '+00:00'))
        require(deadline.tzinfo is not None, 'Authorization deadline must include timezone')
        remaining_seconds = (deadline - datetime.now(timezone.utc)).total_seconds()
        require(remaining_seconds > 0, 'Root target-authorization deadline passed')
        signal.alarm(min(60, math.ceil(remaining_seconds)))
        require(Path(auth['model_directory']).resolve() == Path(model_directory).resolve(), 'Authorized exact model directory')
        require(Path(auth['profile_path']).resolve() == Path(profile_path).resolve(), 'Authorized exact profile')
        require(Path(auth['output_directory']).resolve() == output_directory, 'Authorized exact output directory')
        freeze = json.loads((HERE / 'PREPARATION_FREEZE.json').read_text())
        require(pin(HERE / 'PREPARATION_FREEZE.json') in auth['input_pins'], 'Root authorization must bind the exact preparation freeze')
        required_code = {str((HERE / 'target_certificate.py').resolve()), str((BASE / 'released_kind_corpus_checker/generic_base.py').resolve()), str((BASE / 'released_kind_corpus_checker/vendor/bdd_core.py').resolve())}
        require(required_code <= {ref['path'] for ref in freeze['files']}, 'Freeze must cover exact target/context/BDD code')
        refs = freeze['files'] + [pin(HERE / 'PREPARATION_FREEZE.json'), pin(auth_path)] + auth['input_pins']
        for ref in refs:
            verify_pin(ref)
        model_directory = Path(model_directory).resolve()
        require(pin(model_directory / 'model.json') in auth['input_pins'], 'Model metadata must be pinned in authorization')
        require(pin(profile_path) in auth['input_pins'], 'Profile must be pinned in authorization')
        require(auth.get('producer_admission') is not None, 'Separate fresh producer-admission receipt is required')
        verify_pin(auth['producer_admission'])
        refs.append(auth['producer_admission'])
        producer = json.loads(Path(auth['producer_admission']['path']).read_text())
        require(producer.get('schema') == 'fixed188-model-main-check-v1' and producer.get('status') == 'PASS' and producer.get('id') == FIXTURE, 'Fresh fixed188 model-pair admission must PASS')
        require(producer['native_exports']['original']['model'] == pin(model_directory / 'model.json'), 'Producer admission binds this exact original model')
        require(producer.get('ready_for_separately_reviewed_target_strategy_certificate') is True, 'Producer explicitly admits the separate target certificate')
        spec = importlib.util.spec_from_file_location('fixed188_frozen_context', BASE / 'released_kind_corpus_checker/generic_base.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        module.MAX_CARRIER = 33792
        profile = module.read_json(Path(profile_path))
        model = module.read_json(model_directory / 'model.json')
        require(model.get('bdd_variable_count') == 32, 'Reject unexpected original variable count before BDD loading')
        source_ref = pin(profile['source']['path'])
        require(source_ref == profile['source'] and source_ref['sha256'] == SOURCE_SHA and source_ref['bytes'] == SOURCE_BYTES, 'Pinned exact original source')
        refs.append(source_ref)
        ctx = module.Context(model_directory, profile, model)
        model_audit = ctx.audit_model()
        result, roots = evaluate_context(ctx)
        result.update(limits=LIMITS, model_audit=model_audit, authorization=pin(auth_path), producer_admission=auth['producer_admission'], original_model=pin(model_directory / 'model.json'), profile=pin(profile_path), full_reset_uses=0, started_utc=started_utc)
        result['saved_BDD_inputs'] = [pin(model_directory / name) for name, _ in sorted(ctx.refs)]
        export_roots(output_directory / 'FUNCTIONS.json', ctx, roots)
        result['functions'] = pin(output_directory / 'FUNCTIONS.json')
        for ref in refs + result['saved_BDD_inputs']:
            verify_pin(ref)
        result['input_pins'] = refs
    except BaseException as exc:
        result.update(status='UNKNOWN_RESOURCE' if isinstance(exc, (TimeoutError, MemoryError)) or exc.__class__.__name__ == 'ResourceRefusal' else 'UNKNOWN_INTEGRITY_OR_OBLIGATION', reason=repr(exc), traceback=traceback.format_exc())
    finally:
        signal.alarm(0)
        result['admitted_scientific_result'] = result.get('status') == 'PASS_TARGET_COOPERATIVE_RESIDUAL_LOSS_AND_INITIAL_PRESERVATION'
        if not result['admitted_scientific_result']:
            result['scientific_conclusions'] = {name: None for name in ('original_initial_cooperation', 'literal_initial_W_C', 'specified_cooperative_state_lost_by_literal_transform', 'initial_loss')}
        result.update(finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic() - started)
        save(output_directory / 'RESULT.json', result)
    print(json.dumps({k: result.get(k) for k in ('status', 'fixture_id', 'reason')}), flush=True)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model-directory', required=True)
    parser.add_argument('--profile', required=True)
    parser.add_argument('--authorization', required=True)
    parser.add_argument('--output-directory', required=True)
    args = parser.parse_args()
    run(args.model_directory, args.profile, args.authorization, args.output_directory)
