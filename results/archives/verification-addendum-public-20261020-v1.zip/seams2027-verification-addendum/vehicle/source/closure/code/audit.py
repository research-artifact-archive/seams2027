"""One independent original-source comparison; no apply or fixed-point code.

Importing this file does not load inputs, construct a DAG, or evaluate formulas.
The separate launcher supplies exact frozen file authority after a fresh GO.
"""
from itertools import product
import time


class DomainMismatch(ValueError):
    def __init__(self, comparisons):
        super().__init__('Exact typed domain mismatch; relation quotient was not evaluated')
        self.partial_comparisons = comparisons


def validate_fields(model, source, need):
    need(model.get('schema') == 'k7-native-model-export-v1', 'Model schema')
    need((model.get('fixture_id'), model.get('case_id'), model.get('variant'))
         == ('corpus188__original', 'corpus188', 'original'), 'Original identity')
    need(type(model.get('bdd_variable_count')) is int and model['bdd_variable_count'] == 32,
         'Exact 32 native bits')
    need(model.get('bdd_variable_order') == list(range(32)) and
         all(type(v) is int for v in model['bdd_variable_order']), 'Exact native order')
    fields = model.get('fields')
    need(type(fields) is list and len(fields) == 12, 'Twelve fields, no AUX/helper')
    by_name, encoding, current, nxt = {}, {}, [], []
    for f in fields:
        name = f.get('name')
        need(name in source.NAMES and name not in by_name, 'Exact unique source field')
        owner = 'ENV' if name in source.ENV else 'SYS'
        need(f.get('owner') == f.get('role') == owner, 'Exact field owner/role')
        expected = ({'false', 'true'} if owner == 'ENV' else
                    set(source.LANES) if name == 'currentLane' else {str(i) for i in range(11)})
        values = f.get('values')
        need(type(values) is list and all(type(v) is str for v in values) and
             len(values) == len(set(values)) and set(values) == expected, 'Typed values: ' + name)
        need(type(f.get('domain_size')) is int and f['domain_size'] == len(expected), 'Domain size')
        cb, nb = f.get('current_bits'), f.get('next_bits')
        width = 1 if owner == 'ENV' else 2 if name == 'currentLane' else 4
        need(type(cb) is list and type(nb) is list and len(cb) == len(nb) == width and
             all(type(x) is int and 0 <= x < 32 for x in cb + nb), 'Exact field bit widths')
        need(len(set(cb + nb)) == 2 * width and not set(cb + nb).intersection(current + nxt),
             'Disjoint current/next bit partitions')
        need(type(f.get('encoding')) is dict and set(f['encoding']) == expected, 'Encoding values')
        codes, table = set(), {}
        for label in values:
            enc = f['encoding'][label]
            need(type(enc) is dict and set(enc) == {'current', 'next'}, 'Encoding phases')
            maps = []
            for phase, bits in (('current', cb), ('next', nb)):
                z = enc[phase]
                need(type(z) is dict and set(z) == {str(x) for x in bits} and
                     all(type(v) is bool for v in z.values()), 'Complete Boolean bit map')
                maps.append({bit: z[str(bit)] for bit in bits})
            ccode = tuple(maps[0][bit] for bit in cb)
            need(ccode == tuple(maps[1][bit] for bit in nb) and ccode not in codes,
                 'Injective same-value current/next encoding')
            codes.add(ccode)
            # Numerical meaning comes from the value label, never its list position.
            value = label == 'true' if owner == 'ENV' else int(label) if name == 'speed' else label
            table[value] = tuple(maps)
        by_name[name] = f
        encoding[name] = table
        current.extend(cb)
        nxt.extend(nb)
    need(set(by_name) == set(source.NAMES) and set(current + nxt) == set(range(32)),
         'All source fields and every native bit accounted for')
    for key, actual in (('all_current_bits', current), ('all_next_bits', nxt)):
        need(type(model.get(key)) is list and all(type(v) is int for v in model[key]) and
             model[key] == actual, 'Exact recorded bit union')
    need(model.get('public_fields') == {'ENV': [f['name'] for f in fields if f['owner'] == 'ENV'],
                                      'SYS': [f['name'] for f in fields if f['owner'] == 'SYS']},
         'Complete public roster')
    env_current = [bit for name in source.ENV for bit in by_name[name]['current_bits']]
    env_next = [bit for name in source.ENV for bit in by_name[name]['next_bits']]
    sys_current = [bit for name in ('currentLane', 'speed') for bit in by_name[name]['current_bits']]
    sys_next = [bit for name in ('currentLane', 'speed') for bit in by_name[name]['next_bits']]
    need(tuple(map(len, (current, nxt, env_current, env_next, sys_current, sys_next)))
         == (16, 16, 10, 10, 6, 6), 'Exact source bit partition sizes')
    return {'fields': by_name, 'encoding': encoding, 'current': current, 'next': nxt,
            'env_current': env_current, 'env_next': env_next,
            'sys_current': sys_current, 'sys_next': sys_next}


def encode(state, mapping, prime=False):
    out = {}
    for name, value in state.items():
        out.update(mapping['encoding'][name][value][int(prime)])
    return out


class Comparison:
    def __init__(self, name, quotient, multiplicity, full_domain):
        if any(type(x) is not int or x <= 0 for x in (quotient, multiplicity, full_domain)):
            raise ValueError('Positive exact comparison cardinalities')
        if quotient * multiplicity != full_domain:
            raise ValueError('Quotient cardinality does not cover full domain')
        self.name, self.quotient, self.multiplicity, self.full_domain = name, quotient, multiplicity, full_domain
        self.evaluations = self.mismatches = self.expected_true = self.actual_true = 0
        self.first = None

    def add(self, expected, actual, witness=None):
        if type(expected) is not bool or type(actual) is not bool:
            raise ValueError('Exact Boolean predicate values')
        if self.evaluations >= self.quotient:
            raise ValueError('Comparison exceeded declared domain')
        self.evaluations += 1
        self.expected_true += int(expected) * self.multiplicity
        self.actual_true += int(actual) * self.multiplicity
        if expected != actual:
            self.mismatches += self.multiplicity
            if self.first is None:
                self.first = witness() if callable(witness) else witness
                if self.first is None:
                    raise ValueError('A differing predicate requires a counterexample')

    def result(self):
        if self.evaluations != self.quotient:
            raise ValueError('Incomplete comparison is not a result')
        return {'name': self.name, 'equal': self.mismatches == 0,
                'quotient_evaluations': self.evaluations, 'multiplicity': self.multiplicity,
                'full_domain_cardinality': self.full_domain, 'mismatch_count': self.mismatches,
                'source_true_count': self.expected_true, 'saved_true_count': self.actual_true,
                'first_counterexample': self.first}


def check_support(dag, allowed, need, name):
    need(dag.support <= set(allowed), 'Unexpected actual DAG support: ' + name)


def validate_ref(dag, ref, model, need):
    need(type(ref.get('node_count')) is int and 0 <= ref['node_count'] <= 500000 and
         len(dag.nodes) == ref['node_count'], 'Decoded DAG node count equals metadata')
    need(type(ref.get('support')) is list and all(type(v) is int for v in ref['support']) and
         ref['support'] == sorted(dag.support), 'Decoded support equals metadata')
    need(type(ref.get('zero')) is bool and type(ref.get('one')) is bool and
         ref['zero'] == (dag.root == 0) and ref['one'] == (dag.root == 1), 'DAG constant metadata')
    need(dag.order is None or dag.order == tuple(model['bdd_variable_order']), 'DAG order identity')


def run(frozen, authority, core, source):
    started = time.monotonic()
    need = authority.need
    need(authority.digest(frozen.raw('inputs/source.spectra')) == authority.SOURCE, 'Exact unchanged source')
    model = frozen.read('inputs/original/model.json')
    need({k: model['input'].get(k) for k in ('bytes', 'sha256')} == authority.SOURCE,
         'Model bound to exact source bytes')
    mapping = validate_fields(model, source, need)
    refs = authority.model_references(model)
    need({n for n in frozen.files if n.startswith('inputs/original/') and n.endswith('.bdd')}
         == {'inputs/original/' + r['file'] for r in refs}, 'All and only eleven declared DAGs')
    loaded, metadata = {}, []
    for ref in refs:
        raw = frozen.raw('inputs/original/' + ref['file'])
        need(authority.digest(raw) == {k: ref[k] for k in ('bytes', 'sha256')}, 'Declared DAG content pin')
        dag = core.SavedDag(raw, 32, model['bdd_variable_order'])
        validate_ref(dag, ref, model, need)
        loaded[ref['file']] = dag
        metadata.append({'file': ref['file'], 'bytes': len(raw), 'sha256': authority.sha(raw),
                         'decoded_node_count': len(dag.nodes), 'decoded_support': sorted(dag.support)})
    need(sum(len(d.nodes) for d in loaded.values()) <= 500000, 'Aggregate input DAG node cap')
    formulas = {name: loaded[ref['file']] for name, ref in model['original_bdds'].items()}
    justices = {owner: [loaded[ref['file']] for ref in model['original_justices'][owner]]
               for owner in ('ENV', 'SYS')}
    fields = mapping['fields']
    obs_names = tuple('obstacle' + lane + 'Lane' for lane in source.LANES)
    env_support = [bit for name in obs_names for phase in ('current_bits', 'next_bits')
                   for bit in fields[name][phase]]
    sys_support = (mapping['current'] + mapping['sys_next'] +
                   fields['obstacleFirstLane']['next_bits'] + fields['obstacleThirdLane']['next_bits'])
    allowed = {'thetaE': mapping['env_current'], 'thetaS': mapping['current'],
               'rhoE': env_support, 'rhoS': sys_support, 'domain': mapping['current'],
               'domain_ENV_next': mapping['env_next'], 'domain_SYS_next': mapping['sys_next']}
    for name, dag in formulas.items():
        check_support(dag, allowed[name], need, name)
    for owner in justices:
        for index, dag in enumerate(justices[owner]):
            check_support(dag, mapping['current'], need, owner + '_justice_' + str(index))

    comparisons = []
    # Full raw encodings of each independent domain factor, including unused codes.
    for name, bitnames, selected_names, prime in (
        ('domain', mapping['current'], source.NAMES, False),
        ('domain_ENV_next', mapping['env_next'], source.ENV, True),
        ('domain_SYS_next', mapping['sys_next'], ('currentLane', 'speed'), True)):
        expected_codes = {}
        for field_name in selected_names:
            bits = fields[field_name]['next_bits' if prime else 'current_bits']
            expected_codes[field_name] = (bits, {tuple(code[int(prime)][bit] for bit in bits)
                                                for code in mapping['encoding'][field_name].values()})
        table = Comparison(name, 1 << len(bitnames), 1, 1 << len(bitnames))
        for values in product((False, True), repeat=len(bitnames)):
            assignment = dict(zip(bitnames, values))
            expected = all(tuple(assignment[bit] for bit in bits) in codes
                           for bits, codes in expected_codes.values())
            table.add(expected, formulas[name].value(assignment),
                      lambda a=assignment: {'raw_bits': {str(k): v for k, v in sorted(a.items())}})
        comparisons.append(table.result())
    # A domain discrepancy prevents interpreting the typed quotient.
    if not all(c['equal'] for c in comparisons):
        raise DomainMismatch(comparisons)

    tables = {name: Comparison(name, 33792, 1, 33792)
              for name in ('thetaE', 'thetaS', 'ENV_justice_0', 'ENV_justice_1', 'ENV_justice_2', 'SYS_justice_0')}
    full_edges = 1141899264
    rho_s = Comparison('rhoS', 4460544, 256, full_edges)
    # For each side-obstacle/lane quotient choice retain all eleven typed speeds.
    groups = []
    for o1n, o3n, lane in product((False, True), (False, True), source.LANES):
        rows = []
        for speed in range(11):
            successor = {name: False for name in source.ENV}
            successor.update(obstacleFirstLane=o1n, obstacleThirdLane=o3n, currentLane=lane, speed=speed)
            rows.append((successor, encode(successor, mapping, True)))
        groups.append((o1n, o3n, lane, rows))
    actual_rho_s = formulas['rhoS'].value
    state_count = 0
    source_sys_calls = source_env_calls = source_initial_calls = source_justice_calls = 0
    for values in product(*(source.VALUES[name] for name in source.NAMES)):
        state = dict(zip(source.NAMES, values))
        current_bits = encode(state, mapping)
        state_count += 1
        expected_initial = source.initializers(state)
        source_initial_calls += 1
        for name, expected in zip(('thetaE', 'thetaS'), expected_initial):
            tables[name].add(expected, formulas[name].value(current_bits), lambda s=state: {'current': dict(s)})
        expected_justices = source.justices(state)
        source_justice_calls += 1
        for owner, expected_values in zip(('ENV', 'SYS'), expected_justices):
            for index, expected in enumerate(expected_values):
                tables[owner + '_justice_' + str(index)].add(expected, justices[owner][index].value(current_bits),
                                                             lambda s=state: {'current': dict(s)})
        for o1n, o3n, lane, rows in groups:
            clauses = source.system_clauses(state, o1n, o3n, lane)
            source_sys_calls += 1
            need(len(clauses) == 14 and all(type(v) is bool for v in clauses), 'Fourteen scalar SYS clauses')
            expected = all(clauses)
            for successor, next_bits in rows:
                # Current and next partitions are disjoint and independently typed.
                assignment = current_bits | next_bits
                rho_s.add(expected, actual_rho_s(assignment),
                          lambda s=state, t=successor, c=clauses: {
                              'current': dict(s), 'next': dict(t),
                              'failed_source_lines': [line for line, ok in zip(source.SYS_SOURCE_LINES, c) if not ok]})
    need(state_count == 33792, 'Every typed current state exactly once')
    comparisons.extend(t.result() for t in tables.values())
    comparisons.append(rho_s.result())

    rho_e = Comparison('rhoE', 64, 17842176, full_edges)
    for values in product((False, True), repeat=6):
        current = {name: False for name in source.ENV}
        current.update(currentLane='First', speed=0)
        nxt = dict(current)
        current.update(zip(obs_names, values[:3]))
        nxt.update(zip(obs_names, values[3:]))
        expected = all(source.environment_clauses(*values))
        source_env_calls += 1
        rho_e.add(expected, formulas['rhoE'].value(encode(current, mapping) | encode(nxt, mapping, True)),
                  lambda s=current, t=nxt: {'current': dict(s), 'next': dict(t)})
    comparisons.append(rho_e.result())
    need(len(comparisons) == 11 and len({c['name'] for c in comparisons}) == 11, 'All eleven predicates compared')
    equal = all(c['equal'] for c in comparisons)
    return {'schema': 'fixed188-independent-source-equations-result-v1',
            'status': 'PASS_SOURCE_EQUATIONS' if equal else 'FAIL_SOURCE_EQUATIONS',
            'admitted_scientific_result': False, 'scope': authority.SCOPE, 'case': authority.CASE,
            'frozen_manifest_sha256': frozen.manifest_hash,
            'all_eleven_predicates_equal': equal, 'comparisons': comparisons,
            'source': authority.SOURCE, 'source_lines': {'ENV_safety': list(source.ENV_SOURCE_LINES),
                'SYS_safety': list(source.SYS_SOURCE_LINES), 'ENV_justices': list(source.ENV_JUSTICE_LINES),
                'SYS_justice': list(source.SYS_JUSTICE_LINES)},
            'timing': 'No explicit initializer; seven current-only speed duties, seven next-lane duties. No implicit priming added.',
            'input_DAG_metadata': metadata,
            'typed_state_count': state_count, 'full_typed_edge_count': full_edges,
            'quotient_proof': {'rhoS': {'typed_current': 33792, 'next_side_obstacle_values': 4,
                'next_lanes': 3, 'next_speeds': 11, 'evaluations': 4460544,
                'omitted_next_ENV_fields': [name for name in source.ENV if name not in ('obstacleFirstLane', 'obstacleThirdLane')],
                'each_omitted_field_values': 2, 'multiplicity': 256},
                'rhoE': {'six_obstacle_bits': 64, 'multiplicity': 17842176},
                'decoded_support_verified': True, 'exact_domain_predicates_verified': True,
                'sampling': False, 'reachable_or_ENV_legal_edge_restriction': False},
            'trust_boundary': 'Direct independent scalar source equations and an independent saved-DAG branch reader for one fixed original. Native value encodings are explicitly checked; no general compiler correctness claim.',
            'unchanged_limits': ['Original full-region UNKNOWN_RESOURCE remains unresolved.',
                'No W/K/V/W_C fixed point, new producer compilation, native controller, repair, or deployment conclusion.',
                'The earlier synthetic HandContext extra next-speed duties are not used.'],
            'algorithmic_counters': {'saved_DAG_files_loaded': len(loaded),
                'saved_DAG_scalar_evaluations': sum(c['quotient_evaluations'] for c in comparisons),
                'source_SYS_clause_tuple_evaluations': source_sys_calls,
                'source_ENV_clause_tuple_evaluations': source_env_calls,
                'source_initializer_evaluations': source_initial_calls,
                'source_justice_tuple_evaluations': source_justice_calls},
            'elapsed_seconds': time.monotonic() - started}
