"""Direct transcription of the unchanged 84-line Vehicle source.

Only scalar Boolean/integer operations. No saved model, translated AST,
production Context, BDD operator, or native compiler defines these equations.
States use ten bools, one lane string, and one integer speed in 0..10.
Source G clauses without next are evaluated at the current state only.
"""
LANES = ('First', 'Second', 'Third')
ENV = tuple(prefix + lane + 'Lane'
            for prefix in ('pedestrian', 'greenLight', 'obstacle')
            for lane in LANES) + ('crosswalk',)
VALUES = {name: (False, True) for name in ENV}
VALUES.update(currentLane=LANES, speed=tuple(range(11)))
NAMES = ENV + ('currentLane', 'speed')
SYS_SOURCE_LINES = (57, 58, 59, 62, 63, 64, 65, 66, 69, 78, 79, 80, 83, 84)
ENV_SOURCE_LINES = (49, 50, 51)
ENV_JUSTICE_LINES = (44, 45, 46)
SYS_JUSTICE_LINES = (72, 73, 74, 75)


def free(s, lane):
    """Source predicate at lines 40-41: green and no pedestrian/obstacle."""
    return (s['greenLight' + lane + 'Lane']
            and not s['pedestrian' + lane + 'Lane']
            and not s['obstacle' + lane + 'Lane'])


def initializers(s):
    """No explicit ENV or SYS initializer in this fixed source."""
    return (True, True)


def environment_clauses(o1, o2, o3, o1n, o2n, o3n):
    """Source lines 49,50,51 in order; all arguments are Boolean."""
    return (not o1 or not o2n,
            not o2 or not o1n or not o3n,
            not o3 or not o2n)


def system_clauses(s, o1n, o3n, ln):
    """Fourteen source safety clauses, in source order.

    The only next inputs used by a SYS clause are obstacles 1 and 3.
    No SYS clause mentions next speed, pedestrian, light, crosswalk or o2.
    The typed-domain checker still enumerates every next speed value.
    """
    lane, speed = s['currentLane'], s['speed']
    o1, o2, o3 = (s['obstacle' + x + 'Lane'] for x in LANES)
    stop1 = s['pedestrianFirstLane'] or not s['greenLightFirstLane']
    stop2 = s['pedestrianSecondLane'] or not s['greenLightSecondLane']
    stop3 = s['pedestrianThirdLane'] or not s['greenLightThirdLane']
    return (
        not (stop1 and lane == 'First') or speed == 0,       # 57
        not (stop2 and lane == 'Second') or speed == 0,      # 58
        not (stop3 and lane == 'Third') or speed == 0,       # 59
        not (lane == 'First' and o1) or ln == 'Second',     # 62
        not (lane == 'Second' and o2 and o1n) or ln == 'Third',  # 63
        not (lane == 'Second' and o2 and o3n) or ln == 'First',  # 64
        not (lane == 'Second' and o2 and not o3n and not o1n)
            or ln != 'Second',                             # 65
        not (lane == 'Third' and o3) or ln == 'Second',     # 66
        not s['crosswalk'] or speed < 5,                    # 69
        not (free(s, 'First') and lane == 'First') or speed > 0,  # 78
        not (free(s, 'Second') and lane == 'Second') or speed > 0,  # 79
        not (free(s, 'Third') and lane == 'Third') or speed > 0,  # 80
        lane != 'First' or ln != 'Third',                  # 83
        lane != 'Third' or ln != 'First',                  # 84
    )


def justices(s):
    """Three ordered lane-free ENV predicates, then occupied-free SYS."""
    env = tuple(free(s, lane) for lane in LANES)
    sys = any(s['currentLane'] == lane and predicate
              for lane, predicate in zip(LANES, env))
    return env, (sys,)
