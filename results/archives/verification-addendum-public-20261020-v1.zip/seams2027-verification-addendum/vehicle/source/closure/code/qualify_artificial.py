"""Independent hand expectations and artificial DAG/authority mutations.

This never loads or interprets an input/original/*.bdd file. Generated tiny DAGs
are constructed directly as ASCII toy bytes. Execution needs preparation GO.
"""
from datetime import datetime, timezone, timedelta
from types import SimpleNamespace
import copy


def synthetic_model(source):
    fields, current, nxt = [], [], []
    cursor = 0
    for name in source.NAMES:
        owner = 'ENV' if name in source.ENV else 'SYS'
        width = 1 if owner == 'ENV' else 2 if name == 'currentLane' else 4
        values = ['false', 'true'] if owner == 'ENV' else list(source.LANES) if name == 'currentLane' else ['10'] + [str(i) for i in range(10)]
        cb, nb = list(range(cursor, cursor+width)), list(range(cursor+width, cursor+2*width))
        cursor += 2*width
        encoding = {}
        for index, value in enumerate(values):
            encoding[value] = {'current': {str(bit): bool(index & (1 << k)) for k, bit in enumerate(cb)},
                               'next': {str(bit): bool(index & (1 << k)) for k, bit in enumerate(nb)}}
        fields.append({'name': name, 'owner': owner, 'role': owner, 'values': values,
                       'domain_size': len(values), 'current_bits': cb, 'next_bits': nb, 'encoding': encoding})
        current.extend(cb); nxt.extend(nb)
    return {'schema': 'k7-native-model-export-v1', 'fixture_id': 'corpus188__original', 'case_id': 'corpus188',
            'variant': 'original', 'bdd_variable_count': 32, 'bdd_variable_order': list(range(32)),
            'fields': fields, 'all_current_bits': current, 'all_next_bits': nxt,
            'public_fields': {'ENV': list(source.ENV), 'SYS': ['currentLane', 'speed']}}


def run(frozen, out, a, core, source, audit, pv, complete_parent):
    tests, case_ids = [], set()
    def equal(actual, expected): a.exact(actual, expected, 'Artificial expected value')
    def check(name, fn):
        fn(); tests.append({'name': name, 'status': 'PASS'})
    def rejected(fn):
        try: fn()
        except (ValueError, TypeError, KeyError, RuntimeError): return
        raise AssertionError('Expected rejection did not occur')
    hand = frozen.read('qualification/HAND_CASES.json')
    a.need(hand['schema'] == 'fixed188-independent-hand-source-cases-v1' and hand['case_count'] == len(hand['cases']) == 97,
           'Exact independently authored hand-case roster')
    equal({k: hand['source'][k] for k in ('bytes', 'sha256')}, a.SOURCE)
    equal(hand['system_clause_lines'], list(source.SYS_SOURCE_LINES))
    equal(hand['environment_clause_lines'], list(source.ENV_SOURCE_LINES))
    def typed(state):
        a.need(set(state) == set(source.NAMES), 'Complete hand state')
        for name in source.NAMES:
            a.need(type(state[name]) is (bool if name in source.ENV else int if name == 'speed' else str)
                   and state[name] in source.VALUES[name], 'Hand state exact typed value')
    single_false_system = set(); single_false_environment = set()
    for row in hand['cases']:
        a.need(row['id'] not in case_ids, 'Distinct hand case ID'); case_ids.add(row['id'])
        for key in ('current', 'next'):
            if key in row: typed(row[key])
        def execute(row=row):
            kind = row['kind']
            if kind == 'system':
                t = row['next']
                actual = list(source.system_clauses(row['current'], t['obstacleFirstLane'], t['obstacleThirdLane'], t['currentLane']))
                equal(actual, row['expected_clauses']); equal(all(actual), row['expected_conjunction'])
                if row['id'].endswith('_isolated_false'):
                    indices = [i for i, v in enumerate(actual) if not v]
                    a.need(len(indices) == 1, 'Single isolated false system clause')
                    i = indices[0]; single_false_system.add(i)
                    a.need(all(v for j, v in enumerate(actual) if j != i) and not all(actual), 'Dropping SYS clause changes truth')
                    table = audit.Comparison('missing_SYS_conjunct', 1, 1, 1)
                    table.add(False, True, {'case': row['id']})
                    equal(table.result()['mismatch_count'], 1)
            elif kind == 'environment':
                actual = list(source.environment_clauses(*row['obstacles']))
                equal(actual, row['expected_clauses']); equal(all(actual), row['expected_conjunction'])
                if row['id'].endswith('_isolated_false'):
                    indices = [i for i, v in enumerate(actual) if not v]
                    a.need(len(indices) == 1, 'Single isolated false ENV clause')
                    i = indices[0]; single_false_environment.add(i)
                    a.need(all(v for j, v in enumerate(actual) if j != i), 'Dropping ENV clause changes truth')
            elif kind == 'justice':
                env, sys = source.justices(row['current'])
                equal(list(env), row['expected_ENV']); equal(list(sys), row['expected_SYS'])
            elif kind == 'initializers': equal(list(source.initializers(row['current'])), row['expected'])
            else: raise ValueError('Unknown hand-case kind')
        check('independent hand '+row['id'], execute)
    equal(sorted(single_false_system), list(range(14)))
    equal(sorted(single_false_environment), list(range(3)))
    check('duplicate JSON rejected', lambda: rejected(lambda: a.decode(b'{"x":1,"x":2}')))
    check('nonfinite JSON rejected', lambda: rejected(lambda: a.decode(b'{"x":NaN}')))
    check('Boolean and integer result types distinguished', lambda: rejected(lambda: equal(True, 1)))
    check('unsafe parent path rejected', lambda: rejected(lambda: a.relative_name('../outside.bdd')))
    check('wrong frozen hash rejected before scope import', lambda: rejected(lambda: a.Frozen(frozen.root, '0'*64)))
    def toy_ref(name): return {'file': name+'.bdd', 'bytes': 0, 'sha256': '0'*64}
    roster = {'original_bdds': {name: toy_ref(name) for name in
              ('thetaE', 'thetaS', 'rhoE', 'rhoS', 'domain', 'domain_ENV_next', 'domain_SYS_next')},
              'original_justices': {'ENV': [toy_ref('e'+str(i)) for i in range(3)], 'SYS': [toy_ref('s0')]}}
    check('all eleven toy reference bindings accepted', lambda: equal(len(a.model_references(roster)), 11))
    def bad_roster(kind):
        r = copy.deepcopy(roster)
        if kind == 'missing_justice': r['original_justices']['ENV'].pop()
        elif kind == 'duplicate_file': r['original_bdds']['thetaS']['file'] = 'thetaE.bdd'
        elif kind == 'unsafe_file': r['original_bdds']['rhoS']['file'] = '../rhoS.bdd'
        else: r['original_bdds']['rhoS']['bytes'] = False
        rejected(lambda: a.model_references(r))
    for kind in ('missing_justice', 'duplicate_file', 'unsafe_file', 'boolean_bytes'):
        check('toy input binding rejects '+kind, lambda kind=kind: bad_roster(kind))
    model = synthetic_model(source)
    mapped = audit.validate_fields(model, source, a.need)
    check('numeric speed label is not encoding-list position', lambda: equal(
        list(mapped['encoding']['speed'][10][0].values()), [False]*4))
    check('distinct value zero retains its separate encoding', lambda: equal(
        list(mapped['encoding']['speed'][0][0].values()), [True, False, False, False]))
    for mutation in ('bool_bit', 'duplicate_value', 'overlap', 'extra_aux', 'missing_field', 'wrong_phase', 'missing_encoding'):
        def bad(mutation=mutation):
            m = copy.deepcopy(model)
            if mutation == 'bool_bit': m['fields'][0]['current_bits'][0] = False
            elif mutation == 'duplicate_value': m['fields'][0]['values'] = ['false', 'false']
            elif mutation == 'overlap': m['fields'][1]['current_bits'] = list(m['fields'][0]['current_bits'])
            elif mutation == 'extra_aux': m['fields'][0]['role'] = 'AUX'
            elif mutation == 'missing_field': m['fields'].pop()
            elif mutation == 'wrong_phase': m['fields'][0]['encoding']['false']['next']['1'] = True
            else: del m['fields'][0]['encoding']['false']['current']['0']
            rejected(lambda: audit.validate_fields(m, source, a.need))
        check('generated encoding rejects '+mutation, bad)
    order = list(range(32))
    prefix = ('32\n'+' '.join(map(str, order))+'\n').encode()
    raw = prefix+b'2 0 0 1\n'
    dag = core.SavedDag(raw, 32, order)
    check('toy one-node false branch', lambda: equal(dag.value({0: False}), False))
    check('toy one-node true branch', lambda: equal(dag.value({0: True}), True))
    check('toy inverted branch detected', lambda: equal(core.SavedDag(prefix+b'2 0 1 0\n', 32, order).value({0: False}), True))
    check('toy missing assignment rejected', lambda: rejected(lambda: dag.value({})))
    check('toy non-Boolean assignment rejected', lambda: rejected(lambda: dag.value({0: 0})))
    for name, malformed in [('unresolved_child', prefix+b'2 0 4 1\n'), ('nonreduced', prefix+b'2 0 1 1\n'),
                            ('unreachable', prefix+b'2 0 0 1\n3 1 0 1\n'),
                            ('wrong_order', b'32\n'+' '.join(map(str, reversed(order))).encode()+b'\n2 0 0 1\n')]:
        check('toy DAG rejects '+name, lambda raw=malformed: rejected(lambda: core.SavedDag(raw, 32, order)))
    check('actual decoded support accepted only in declared quotient', lambda: audit.check_support(dag, {0}, a.need, 'toy'))
    check('extra actual support is never silently projected', lambda: rejected(lambda: audit.check_support(dag, set(), a.need, 'toy')))
    ref = {'node_count': 1, 'support': [0], 'zero': False, 'one': False}
    check('toy decoded metadata matches', lambda: audit.validate_ref(dag, ref, model, a.need))
    badref = dict(ref, support=[])
    check('metadata cannot conceal actual support', lambda: rejected(lambda: audit.validate_ref(dag, badref, model, a.need)))
    check('quotient wrong multiplicity rejected', lambda: rejected(lambda: audit.Comparison('toy', 2, 3, 5)))
    check('quotient Boolean cardinality rejected', lambda: rejected(lambda: audit.Comparison('toy', True, 2, 2)))
    partial = audit.Comparison('toy', 2, 3, 6); partial.add(False, False)
    check('incomplete quotient not reported', lambda: rejected(partial.result))
    partial.add(True, False, {'typed_current': {'toy': True}})
    check('weighted mismatch and first witness retained', lambda: equal(
        (partial.result()['mismatch_count'], partial.result()['first_counterexample']),
        (3, {'typed_current': {'toy': True}})))
    check('quotient overcount rejected', lambda: rejected(lambda: partial.add(True, True)))
    dm = audit.DomainMismatch([partial.result()])
    check('domain failure preserves partial counterexample before typed quotient', lambda: equal(dm.partial_comparisons, [partial.result()]))
    qrefs = []
    for kind in ('artificial', 'imports'):
        path = out/(kind+'_toy_qualification.json')
        a.save(path, {'status': 'PASS_SOURCE_AUDIT_QUALIFICATION', 'qualification_kind': kind,
                      'scope': a.SCOPE, 'frozen_manifest_sha256': '3'*64})
        qrefs.append(a.pin(path))
    go = {'schema': 'fixed188-independent-source-single-go-v1', 'status': 'GO',
          'frozen_manifest_sha256': '3'*64, 'scope': a.SCOPE, 'case': a.CASE,
          'output_root': str(out/'toy_actual'), 'attempts': 1, 'saved_evaluations': 1,
          'native_calls': 0, 'solver_calls': 0, 'fixed_point_calls': 0,
          'deadline_utc': (datetime.now(timezone.utc)+timedelta(hours=1)).isoformat(),
          'limits': dict(a.LIMITS), 'qualification_receipts': qrefs}
    def check_go(value, expected='3'*64):
        path = out/('toy_GO_'+str(len(tests))+'.json'); a.save(path, value)
        return a.load_go(path, expected, out/'toy_actual')
    check('fresh synthetic actual GO accepted', lambda: check_go(go))
    for key, value in [('attempts', True), ('saved_evaluations', 2), ('native_calls', 1),
                       ('scope', 'old_scope'), ('schema', 'old_schema'), ('frozen_manifest_sha256', '4'*64),
                       ('qualification_receipts', qrefs[:1]), ('deadline_utc', '2000-01-01T00:00:00+00:00')]:
        check('actual GO rejects '+key, lambda key=key, value=value: rejected(lambda: check_go(dict(go, **{key: value}))))
    proc = {'schema': 'contained-stage-process-v2', 'status': 'PROCESS_COMPLETED', 'exit_code': 0,
            'process_started': True, 'owned_child_reaped': True, 'receipt_persisted': True,
            'parent_finalization_completed': True, 'parent_aborted': False,
            'exact_child_wait4': {'exact_child_reaped': True, 'authority_lost': False},
            'final_group_observation': {'state': 'ABSENT'}, 'fatal_reasons': [], 'resource_reasons': [],
            'capture': {name: {'file': name+'.txt', 'bytes': 0, 'sha256': a.sha(b''), 'complete': True,
                               'observed_bytes': 0, 'captured_bytes': 0} for name in ('stdout', 'stderr')}}
    check('toy clean exact process accepted', lambda: equal(pv.valid_process(proc), True))
    check('Boolean exit code rejected', lambda: equal(pv.valid_process(dict(proc, exit_code=False)), False))
    check('unreaped exact process rejected', lambda: equal(pv.valid_process(dict(proc, owned_child_reaped=False)), False))
    def capture_case():
        folder = out/'capture_toy'; (folder/'process').mkdir(parents=True); (folder/'worker').mkdir()
        p = copy.deepcopy(proc)
        for name, raw in (('stdout', b'abc'), ('stderr', b'')):
            (folder/'process'/(name+'.txt')).write_bytes(raw)
            p['capture'][name].update(a.digest(raw), observed_bytes=len(raw), captured_bytes=len(raw))
        a.save(folder/'process/PROCESS_RECEIPT.json', p)
        result = {'status': 'PASS_IMPORT_ONLY', 'scope': a.SCOPE, 'case': a.CASE,
                  'frozen_manifest_sha256': '3'*64, 'saved_DAG_evaluations': 0,
                  'execution_events': {'audit_entries': 0, 'blocked_graph_calls': 0, 'blocked_native_library_loads': 0},
                  'guard': {'external_data_reads_blocked': 1, 'network_process_attempts_blocked': 0}}
        a.save(folder/'worker/RESULT.json', result)
        done = dict(result, all_inputs_unchanged=True, kind='imports', result=a.pin(folder/'worker/RESULT.json'))
        a.save(folder/'worker/WORKER_COMPLETE.json', done)
        fake = SimpleNamespace(manifest_hash='3'*64)
        equal(complete_parent(folder, fake, 'imports', p, True, None)['status'], 'PASS_SOURCE_AUDIT_QUALIFICATION')
        (folder/'process/stdout.txt').write_bytes(b'xyz')
        changed = complete_parent(folder, fake, 'imports', p, True, None)
        equal(changed['status'], 'UNKNOWN_SOURCE_SCOPE_NOT_ADMITTED')
        a.need(any(e['phase'] == 'owned_process' for e in changed['errors']), 'Same-size capture mutation caught')
    check('parent rehash rejects same-length output tampering', capture_case)
    frozen.verify()
    return {'schema': 'fixed188-independent-source-artificial-qualification-v1',
            'status': 'PASS_ARTIFICIAL_SOURCE_QUALIFICATION', 'tests': tests, 'check_count': len(tests),
            'independent_hand_cases': 97, 'isolated_SYS_mutations': 14, 'isolated_ENV_mutations': 3,
            'saved_DAG_evaluations': 0, 'native_calls': 0,
            'generated_toy_DAGs_only': True, 'source_expectations_origin': hand['authoring_independence'],
            'full_reset_uses': 0}
