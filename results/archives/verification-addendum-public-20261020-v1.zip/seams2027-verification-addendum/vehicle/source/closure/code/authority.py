"""Pinned file authority for the independent fixed188 source-equation scope."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib, importlib.util, json, re, sys
CASE="corpus188__original"
SCOPE="independent_original_source_equations"
SOURCE={"bytes":3924,"sha256":"0e6faaedcd2bf8ab7b80d239231973f4588922ae5ff85a95927894cf78531e3b"}
LIMITS={"wall_seconds":180,"rss_bytes":536870912,"stream_bytes":65536,"file_bytes":2097152,"output_tree_bytes":2097152,"reserve_bytes":8388608,"min_free_bytes":1073741824}
CORE_PINS={"code/independent_core.py":"aa7aa11d0ab35f9505db132db45cb9cc7832e91216e80f56651bf0b3cea8805e","code/runtime_guard.py":"c6df8c8921976cd0f8e1ea03fefd11b65705603dbc755e41b49de020eece3b12","code/supervisor/bounded_process.py":"ee08963ad88b0259c744cbed732f339536fd504a89342c5e661449ffc0e367c9","code/supervisor/owned_process.py":"20ce5ef1912afd9ff144a9c4c102d347e09e5006596372d38bd3e05ad3b57596"}

class Rejection(ValueError):pass



def need(ok,message):
    if not ok:raise Rejection(message)



def sha(raw):return hashlib.sha256(raw).hexdigest()



def digest(raw):return {'bytes':len(raw),'sha256':sha(raw)}



def unique(pairs):
    result={}
    for k,v in pairs:
        need(k not in result,'Duplicate JSON key: '+str(k));result[k]=v
    return result



def decode(raw):
    def bad(value):raise Rejection('Nonfinite JSON number: '+value)
    return json.loads(raw.decode('utf-8'),object_pairs_hook=unique,parse_constant=bad)



def encoded(obj):return (json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()



def exact(a,b,label='value'):
    need(type(a)is type(b),label+' type differs')
    if isinstance(a,dict):
        need(set(a)==set(b),label+' key set differs')
        for k in a:exact(a[k],b[k],label+'/'+str(k))
    elif isinstance(a,list):
        need(len(a)==len(b),label+' length differs')
        for i,(x,y) in enumerate(zip(a,b)):exact(x,y,label+'/'+str(i))
    else:need(a==b,label+' differs')



def canonical_path(path):
    p=Path(path).absolute()
    need('..' not in p.parts and p.resolve()==p,'Canonical path required')
    cur=Path(p.anchor)
    for part in p.parts[1:]:
        cur/=part;need(not cur.is_symlink(),'Symlink path component')
    return p



def relative_name(name):
    need(type(name)is str and bool(name),'Relative file name')
    p=PurePosixPath(name)
    need(not p.is_absolute() and p.as_posix()==name and '\\' not in name,'Canonical relative file name')
    need(all(x not in ('','.','..') for x in name.split('/')),'Unsafe relative file name')
    return name



def file_bytes(path,cap=2097152):
    p=canonical_path(path);need(p.is_file() and p.stat().st_size<=cap,'Regular bounded input file')
    raw=p.read_bytes();need(len(raw)<=cap,'Read byte cap');return raw



def pin(path):return {'path':str(canonical_path(path)),**digest(file_bytes(path))}



def save(path,obj):
    raw=encoded(obj);need(len(raw)<=LIMITS['file_bytes'],'Output file cap')
    p=Path(path);need(p.parent.is_dir() and not p.exists() and not p.is_symlink(),'Fresh output file')
    with p.open('xb') as f:f.write(raw)
    return {'file':p.name,**digest(raw)}



def check_reference(ref):
    need(type(ref)is dict,'BDD reference object')
    name=relative_name(ref.get('file'));need(PurePosixPath(name).name==name and name.endswith('.bdd'),'BDD basename only')
    need(type(ref.get('bytes'))is int and ref['bytes']>=0,'BDD exact byte count')
    need(type(ref.get('sha256'))is str and re.fullmatch('[0-9a-f]{64}',ref['sha256'])is not None,'BDD SHA256')
    return name



def model_references(model):
    need(type(model.get('original_bdds'))is dict and set(model['original_bdds'])=={'thetaE','thetaS','rhoE','rhoS','domain','domain_ENV_next','domain_SYS_next'},'All seven original relation/domain references')
    just=model.get('original_justices');need(type(just)is dict and set(just)=={'ENV','SYS'},'Justice owners')
    need(type(just['ENV'])is list and len(just['ENV'])==3 and type(just['SYS'])is list and len(just['SYS'])==1,'All ordered original justices')
    refs=list(model['original_bdds'].values())+just['ENV']+just['SYS']
    names=[check_reference(x) for x in refs];need(len(names)==11 and len(set(names))==11,'Exactly eleven declared BDD basenames')
    return refs



def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);need(spec is not None and spec.loader is not None,'Exact module loader')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    need(Path(module.__file__).resolve()==Path(path).resolve(),'Imported module origin')
    return module



class Frozen:
    def __init__(self,root,expected_manifest):
        self.root=canonical_path(root);need(self.root.is_dir(),'Closure directory')
        raw=file_bytes(self.root/'FROZEN_MANIFEST.json');need(sha(raw)==expected_manifest,'Frozen manifest hash')
        self.manifest_hash=expected_manifest;self.manifest=decode(raw)
        need(self.manifest.get('schema')=='fixed188-independent-source-freeze-v1','Frozen manifest schema')
        need(self.manifest.get('scope')==SCOPE and self.manifest.get('case')==CASE,'Fixed target scope/case')
        self.files={}
        for row in self.manifest['files']:
            name=relative_name(row['file']);need(name not in self.files,'Duplicate manifest file')
            need(type(row.get('bytes'))is int and row['bytes']>=0,'Exact integer byte pin')
            need(type(row.get('sha256'))is str and re.fullmatch('[0-9a-f]{64}',row['sha256'])is not None,'SHA256 pin')
            self.files[name]=row
        for name,h in CORE_PINS.items():need(name in self.files and self.files[name]['sha256']==h,'Unchanged core pin: '+name)
        self.verify()
    def path(self,name):
        name=relative_name(name);need(name in self.files,'File outside frozen authority: '+name)
        return canonical_path(self.root/name)
    def raw(self,name):
        raw=file_bytes(self.path(name));row=self.files[name]
        exact(digest(raw),{k:row[k] for k in ('bytes','sha256')},'Input pin '+name);return raw
    def read(self,name):return decode(self.raw(name))
    def verify(self):
        present=set()
        for entry in self.root.rglob('*'):
            need(not entry.is_symlink(),'Symlink anywhere in frozen closure')
            if entry.is_file():present.add(str(entry.relative_to(self.root)))
            else:need(entry.is_dir(),'Nonregular entry in frozen closure')
        need(present==set(self.files)|{'FROZEN_MANIFEST.json'},'Exact frozen file roster; unmanifested or missing file')
        for name in self.files:self.raw(name)
        need(sha(file_bytes(self.root/'FROZEN_MANIFEST.json'))==self.manifest_hash,'Manifest changed')
        return True


def load_preparation_go(path, manifest_hash, output, kind):
    ref = pin(path)
    go = decode(file_bytes(path))
    keys = {'schema', 'status', 'frozen_manifest_sha256', 'scope', 'case',
            'output_roots', 'deadline_utc', 'limits', 'saved_DAG_evaluations_authorized'}
    need(type(go) is dict and set(go) == keys, 'Exact preparation authority fields')
    need(go['schema'] == 'fixed188-independent-source-preparation-go-v1' and
         go['status'] == 'GO_ARTIFICIAL_AND_IMPORT_QUALIFICATION', 'New preparation authority')
    need(go['frozen_manifest_sha256'] == manifest_hash and go['scope'] == SCOPE and
         go['case'] == CASE, 'Exact preparation scope/case/freeze')
    need(type(go['saved_DAG_evaluations_authorized']) is int and
         go['saved_DAG_evaluations_authorized'] == 0, 'Preparation prohibits saved-DAG evaluation')
    need(type(go['output_roots']) is dict and set(go['output_roots']) == {'artificial', 'imports'},
         'Two distinct preparation output roots')
    need(len(set(go['output_roots'].values())) == 2 and
         go['output_roots'][kind] == str(canonical_path(output)), 'Exact fresh qualification output')
    exact(go['limits'], LIMITS, 'Preparation limits')
    deadline = datetime.fromisoformat(go['deadline_utc'])
    need(deadline.tzinfo is not None and (deadline-datetime.now(timezone.utc)).total_seconds() > 1,
         'Unexpired timezone-aware preparation authority')
    return go, ref


def load_go(path, manifest_hash, output):
    ref = pin(path)
    go = decode(file_bytes(path))
    keys = {'schema', 'status', 'frozen_manifest_sha256', 'scope', 'case', 'output_root',
            'attempts', 'saved_evaluations', 'native_calls', 'solver_calls', 'fixed_point_calls',
            'deadline_utc', 'limits', 'qualification_receipts'}
    need(type(go) is dict and set(go) == keys, 'Exact actual authority fields')
    need(go['schema'] == 'fixed188-independent-source-single-go-v1' and go['status'] == 'GO',
         'New actual source-equation authority')
    need(go['frozen_manifest_sha256'] == manifest_hash and go['scope'] == SCOPE and
         go['case'] == CASE and go['output_root'] == str(canonical_path(output)), 'Exact actual scope/output')
    for key, value in [('attempts', 1), ('saved_evaluations', 1), ('native_calls', 0),
                       ('solver_calls', 0), ('fixed_point_calls', 0)]:
        need(type(go[key]) is int and go[key] == value, 'Exact integer authority ' + key)
    exact(go['limits'], LIMITS, 'Actual limits')
    deadline = datetime.fromisoformat(go['deadline_utc'])
    need(deadline.tzinfo is not None and (deadline-datetime.now(timezone.utc)).total_seconds() > 1,
         'Unexpired timezone-aware actual authority')
    need(type(go['qualification_receipts']) is list and len(go['qualification_receipts']) == 2,
         'Exactly artificial and import qualification receipts')
    kinds = set()
    for q in go['qualification_receipts']:
        need(type(q) is dict and set(q) == {'path', 'bytes', 'sha256'}, 'Qualification pin fields')
        exact(pin(q['path']), q, 'Qualification receipt current identity')
        record = decode(file_bytes(q['path']))
        need(record.get('status') == 'PASS_SOURCE_AUDIT_QUALIFICATION' and
             record.get('frozen_manifest_sha256') == manifest_hash and record.get('scope') == SCOPE,
             'Qualified same immutable source scope')
        kind = record.get('qualification_kind')
        need(kind in ('artificial', 'imports') and kind not in kinds, 'Distinct qualification kinds')
        kinds.add(kind)
    need(kinds == {'artificial', 'imports'}, 'Both qualification prerequisites')
    return go, ref

