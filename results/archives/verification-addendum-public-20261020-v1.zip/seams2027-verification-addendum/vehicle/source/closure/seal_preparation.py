"""Static byte freeze only. Never imports scope modules or interprets a DAG."""
from pathlib import Path
import ast, hashlib, json

root = Path(__file__).resolve().parent
target = root/'FROZEN_MANIFEST.json'
if target.exists(): raise FileExistsError('No frozen overwrite')
rows = []
for path in sorted(root.rglob('*')):
    if path.is_symlink(): raise ValueError('No closure symlinks')
    if not path.is_file(): continue
    raw = path.read_bytes()
    if path.suffix == '.py': ast.parse(raw.decode(), filename=str(path.relative_to(root)))
    private_markers = (bytes([47,85,115,101,114,115,47]), bytes([47,104,111,109,101,47]),
                       bytes([105,116,97,107,117,51]))
    if any(marker in raw for marker in private_markers):
        raise ValueError('Private location marker in public frozen preparation')
    rows.append({'file': str(path.relative_to(root)), 'bytes': len(raw),
                 'sha256': hashlib.sha256(raw).hexdigest()})
value = {'schema': 'fixed188-independent-source-freeze-v1',
         'scope': 'independent_original_source_equations', 'case': 'corpus188__original',
         'status': 'STATIC_FROZEN_AWAITING_INDEPENDENT_REVIEW_AND_PREPARATION_GO',
         'files': rows, 'saved_DAG_evaluations': 0, 'scientific_module_imports': 0,
         'new_native_calls': 0, 'full_reset_uses': 0}
raw = (json.dumps(value, ensure_ascii=False, indent=2)+'\n').encode()
with target.open('xb') as stream: stream.write(raw)
print(json.dumps({'file': 'FROZEN_MANIFEST.json', 'bytes': len(raw),
                  'sha256': hashlib.sha256(raw).hexdigest(), 'frozen_files': len(rows),
                  'frozen_file_bytes': sum(row['bytes'] for row in rows)}))
