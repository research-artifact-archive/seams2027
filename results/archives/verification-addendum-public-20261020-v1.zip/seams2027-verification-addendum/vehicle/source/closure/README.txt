Vehicle188 independent original-source equation audit

This is a new static preparation. No qualification or scientific execution has
occurred. A separate reviewed preparation GO is required for the artificial and
guarded-import qualifications. A second single-attempt GO is required for one
saved original-source audit after both qualifications pass for the exact freeze.
The immutable FROZEN_MANIFEST.json identifies every input and code byte.

Purpose and boundary
The direct source oracle transcribes fourteen SYS safety clauses, three ENV
safety clauses, true source initialization, and the original three ordered ENV
justices and single SYS justice. It does not read the compiler's translated AST
to define these expressions. The exact source has no initializer or AUX state.
The seven current-only speed duties remain at the current state; no next-state
speed duty or initial restriction is added. The previous synthetic HandContext
is not imported or treated as an equivalent source oracle.

Inputs are thirteen byte-identical copies from the independently adopted P1
closure: source.spectra, original model.json, and its eleven declared BDDs.
The model's recorded source-location string remains unchanged and is an
historical identity; the audit reads only the frozen inputs/source.spectra.
SOURCE_AUTHORITY.json binds the previous anonymous copies and their historical
origins without copying the old experiment's entire provenance tree.

Method
The unchanged independent SavedDag parser follows saved decision branches.
No production Context, BDD apply operator, solver, region fixed point, controller
or graph algorithm is used. Full field ownership, value-label meanings, bijective
current/next codes, all 32 bits, and exact native support are checked first.
The domain comparisons check all 65,536 current encodings, 1,024 next-ENV
encodings and 64 next-SYS encodings, including unused lane/speed bit codes.
This uses proved support factoring and never enumerates 2^32 untyped pairs.
A domain mismatch stops the typed relation comparison and retains its raw-bit
counterexample and completed domain comparisons in UNKNOWN.json.

Both initializers and all four ordered justices are compared on all 33,792
typed states. SYS safety is compared on 33,792 current states times four next
side-obstacle choices times three next lanes times eleven next speeds. The
4,460,544 evaluations each represent exactly 256 valuations of the other eight
next ENV fields, absent from both scalar source equations and decoded support.
ENV safety uses all 64 assignments of its six current/next obstacle bits,
each representing 17,842,176 complete typed edges. Thus each relation comparison
covers every one of 1,141,899,264 typed current/next pairs. It includes unreachable
and ENV-illegal pairs and is not sampling or a reachability-restricted audit.

Qualification
The independent HAND_CASES.json contains 97 hand-derived expectations for all
source clauses, threshold and timing cases, contradictory next obstacles,
initializer truth and ordered justice semantics. Fourteen SYS and three ENV
cases isolate one false conjunct. Additional generated toy DAG, support,
encoding, exact-type, byte-reference, authority, complete-count, partial-witness
and process-capture mutations exercise the new adapter boundaries. No original
saved DAG is interpreted by qualification. Guarded imports permit no mathematical
function calls and demonstrate rejection of an external data read.

Entry points
Use Python with -I -S -B and the frozen code/review.py.
Actions are artificial, imports and actual. Every action takes --root,
--expected-manifest and a fresh --output outside this closure. Qualification
actions require --preparation-go; imports additionally requires an external
--reject-read-root. The actual action requires --go. Matching worker actions
are internal and additionally verify the parent START.json and exact GO.
Both GO schemas and fixed resource fields are listed in PREPARATION_SCOPE.json.
The preparation file itself never starts any worker. Reader-facing request
generation will be supplied separately after a result is independently adopted.

Bounds and outcomes
One worker, 180 seconds, 512MiB sampled group RSS, 64KiB each captured stream,
2MiB each file and sampled whole output tree, 8MiB initial disk reserve above
the existing 1GiB free-space floor. The reused supervisor preserves exact-child
wait/capture/termination records. Sampled limits are not exact OS disk quotas.
Runtime is not predicted by this preparation. Completion requires all eleven
comparisons and exact executed iteration counters, closed captures and unchanged
input bytes. A complete mismatch is retained as FAIL_SOURCE_EQUATIONS pending
review. Resource, integrity or interrupted results remain UNKNOWN without retry.
No result is scientifically adopted by the worker itself.

The previous complete K/W/W_C region UNKNOWN remains unchanged. This audit is
one source-to-saved-original correspondence check, not general compiler proof,
new native compilation, native-controller evidence, a new case or a repair event.
Full-reset use is prohibited and is not part of this workflow.
