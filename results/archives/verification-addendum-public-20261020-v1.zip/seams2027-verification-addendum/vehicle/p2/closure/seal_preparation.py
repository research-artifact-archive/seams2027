"""Freeze exactly the static pair preparation; no scientific code import."""
from pathlib import Path
import ast,hashlib,json
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'FROZEN_MANIFEST.json'
if OUT.exists():raise SystemExit('Already frozen; preserve this revision')
def pin(p):
 raw=p.read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
inputs=json.loads((ROOT/'INPUT_MANIFEST.json').read_text());names={x['file']for x in inputs['files']}
for row in inputs['files']:
 if pin(ROOT/row['file'])!={k:row[k]for k in ('bytes','sha256')}:raise ValueError('Changed copied input')
expected=names|{'prepare_inputs.py','INPUT_MANIFEST.json','PREPARATION_SCOPE.json','seal_preparation.py','code/adapter.py','code/review.py','code/qualify_artificial.py'}
files=sorted(p for p in ROOT.rglob('*')if p.is_file())
if {str(p.relative_to(ROOT))for p in files}!=expected or any(p.is_symlink()for p in ROOT.rglob('*')):raise ValueError('Exact static closure roster required')
for p in files:
 if p.suffix=='.py':ast.parse(p.read_text(),filename=str(p))
d={'schema':'fixed188-pair-portable-frozen-manifest-v1','scope':'saved_actual_original_released_pair','case':'corpus188__original','status':'STATIC_FROZEN_AWAITING_PREPARATION_GO','files':[{'file':str(p.relative_to(ROOT)),**pin(p)}for p in files],'input_manifest_sha256':pin(ROOT/'INPUT_MANIFEST.json')['sha256'],'unchanged_scientific_core_files':6,'saved_DAG_evaluations':0,'native_calls':0,'full_reset_uses':0,'scope_note':'Actual saved original/released full typed relations, initial conditions, ordered justices and115canonical functions only. Historical partial-original bridge, producer admission and target policy excluded. Fresh separate Root scope GO after qualification.'}
with OUT.open('xb')as f:f.write((json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'file':str(OUT),'files':len(files),'input_bytes':sum(x['bytes']for x in d['files']),**pin(OUT),'static_AST_only':True,'saved_DAG_evaluations':0}))
