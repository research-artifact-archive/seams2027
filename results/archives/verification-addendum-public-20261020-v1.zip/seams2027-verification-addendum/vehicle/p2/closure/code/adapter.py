"""Fresh authority for one archived fixed188 actual-original/released pair recheck."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
from types import ModuleType
import copy, gzip, hashlib, importlib.util, io, json, re, sys
CASE='corpus188__original'
SCOPE='saved_actual_original_released_pair'
SOURCE={'bytes':3924,'sha256':'0e6faaedcd2bf8ab7b80d239231973f4588922ae5ff85a95927894cf78531e3b'}
LIMITS={'wall_seconds':60,'rss_bytes':536870912,'stream_bytes':1048576,'file_bytes':2097152,'output_tree_bytes':8388608,'min_free_bytes':1073741824}
SCIENTIFIC_TRACE={'pair_builds':1,'relation_comparisons':1,'supplemental_checks':1,'canonical_exports':1,'context_constructions':2,'BDD_constructions':3,'model_audits':2,'blocked_scientific_calls':0,'blocked_legacy_or_out_of_scope_calls':0}
CORE_PINS={'code/context/generic_base.py': '3c465e4253712c6f021920e6a164ef48c63c5bf6cfb3432d17ab95fb5778ebda', 'code/context/vendor/bdd_core.py': 'f9497519b8a073a29e5748c908cadc804f437080cf12d36558d9e0210462dbac', 'code/pair/map_pair.py': 'ee0cb299030f685298d6a0f0c760d301bb1a40f6f760146f6610e21bd064cc76', 'code/pair/model_gate.py': 'e16ff49ee503d3fde38d9543145816fe8e201f3ff514b9765522dc2115984078', 'code/pair/pair_support.py': 'e3eeaa76375c954eae26ef44ed5de1738fd0fcbd95b6fd746d9221309a2f863b', 'code/pair/relations.py': '95822c564c54f38b2ed036b8659897b09e69ea32241b6122f73ac871d24afcf6', 'code/runtime_guard.py': 'c6df8c8921976cd0f8e1ea03fefd11b65705603dbc755e41b49de020eece3b12', 'code/supervisor/bounded_process.py': 'ee08963ad88b0259c744cbed732f339536fd504a89342c5e661449ffc0e367c9', 'code/supervisor/owned_process.py': '20ce5ef1912afd9ff144a9c4c102d347e09e5006596372d38bd3e05ad3b57596'}

class Rejection(ValueError):pass

def need(ok,message):
    if not ok:raise Rejection(message)

def sha(raw):return hashlib.sha256(raw).hexdigest()
def digest(raw):return {'bytes':len(raw),'sha256':sha(raw)}
def unique(pairs):
    result={}
    for k,v in pairs:
        need(k not in result,'Duplicate JSON key: '+str(k));result[k]=v
    return result

def decode(raw):
    def bad(value):raise Rejection('Nonfinite JSON number: '+value)
    return json.loads(raw.decode('utf-8'),object_pairs_hook=unique,parse_constant=bad)

def encoded(obj):return (json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def exact(a,b,label='value'):
    need(type(a)is type(b),label+' type differs')
    if isinstance(a,dict):
        need(set(a)==set(b),label+' key set differs')
        for k in a:exact(a[k],b[k],label+'/'+k)
    elif isinstance(a,list):
        need(len(a)==len(b),label+' length differs')
        for i,(x,y) in enumerate(zip(a,b)):exact(x,y,label+'/'+str(i))
    else:need(a==b,label+' differs')

def canonical_path(path):
    p=Path(path).absolute()
    need('..' not in p.parts and p.resolve()==p,'Canonical path required')
    cur=Path(p.anchor)
    for part in p.parts[1:]:
        cur/=part;need(not cur.is_symlink(),'Symlink path component')
    return p

def relative_name(name):
    need(type(name)is str and bool(name),'Relative file name')
    p=PurePosixPath(name)
    need(not p.is_absolute() and p.as_posix()==name and '\\' not in name,'Canonical relative file name')
    need(all(x not in ('','.','..') for x in name.split('/')),'Unsafe relative file name')
    return name

def file_bytes(path,cap=2097152):
    p=canonical_path(path);need(p.is_file() and p.stat().st_size<=cap,'Regular bounded input file')
    raw=p.read_bytes();need(len(raw)<=cap,'Read byte cap');return raw

def pin(path):return {'path':str(canonical_path(path)),**digest(file_bytes(path))}

def save(path,obj):
    raw=encoded(obj);need(len(raw)<=LIMITS['file_bytes'],'Output file cap')
    p=Path(path);need(p.parent.is_dir() and not p.exists() and not p.is_symlink(),'Fresh output file')
    with p.open('xb') as f:f.write(raw)
    return {'file':p.name,**digest(raw)}

class Frozen:
    def __init__(self,root,expected_manifest):
        self.root=canonical_path(root);need(self.root.is_dir(),'Closure directory')
        raw=file_bytes(self.root/'FROZEN_MANIFEST.json');need(sha(raw)==expected_manifest,'Frozen manifest hash')
        self.manifest_hash=expected_manifest;self.manifest=decode(raw)
        need(self.manifest.get('schema')=='fixed188-pair-portable-frozen-manifest-v1','Frozen manifest schema')
        need(self.manifest.get('scope')==SCOPE and self.manifest.get('case')==CASE,'Fixed target scope/case')
        self.files={}
        for row in self.manifest['files']:
            name=relative_name(row['file']);need(name not in self.files,'Duplicate manifest file')
            need(type(row.get('bytes'))is int and row['bytes']>=0,'Exact integer byte pin')
            need(type(row.get('sha256'))is str and re.fullmatch('[0-9a-f]{64}',row['sha256'])is not None,'SHA256 pin')
            self.files[name]=row
        for name,h in CORE_PINS.items():need(name in self.files and self.files[name]['sha256']==h,'Unchanged core pin: '+name)
        self.verify()
    def path(self,name):
        name=relative_name(name);need(name in self.files,'File outside frozen authority: '+name)
        return canonical_path(self.root/name)
    def raw(self,name):
        raw=file_bytes(self.path(name));row=self.files[name]
        exact(digest(raw),{k:row[k] for k in ('bytes','sha256')},'Input pin '+name);return raw
    def read(self,name):return decode(self.raw(name))
    def verify(self):
        present=set()
        for entry in self.root.rglob('*'):
            need(not entry.is_symlink(),'Symlink anywhere in frozen closure')
            if entry.is_file():present.add(str(entry.relative_to(self.root)))
            else:need(entry.is_dir(),'Nonregular entry in frozen closure')
        need(present==set(self.files)|{'FROZEN_MANIFEST.json'},'Exact frozen file roster; unmanifested or missing file')
        for name in self.files:self.raw(name)
        need(sha(file_bytes(self.root/'FROZEN_MANIFEST.json'))==self.manifest_hash,'Manifest changed')
        return True

def check_reference(ref):
    need(type(ref)is dict,'BDD reference object')
    name=relative_name(ref.get('file'));need(PurePosixPath(name).name==name and name.endswith('.bdd'),'BDD basename only')
    need(type(ref.get('bytes'))is int and ref['bytes']>=0,'BDD exact byte count')
    need(type(ref.get('sha256'))is str and re.fullmatch('[0-9a-f]{64}',ref['sha256'])is not None,'BDD SHA256')
    return name

def model_references(model,mode):
    need(mode in ('original','released'),'Exact mode')
    need(type(model.get('original_bdds'))is dict and set(model['original_bdds'])=={'thetaE','thetaS','rhoE','rhoS','domain','domain_ENV_next','domain_SYS_next'},'All seven relation/domain references')
    just=model.get('original_justices');need(type(just)is dict and set(just)=={'ENV','SYS'},'Exact justice owners')
    count=3 if mode=='original'else 4
    need(type(just['ENV'])is list and len(just['ENV'])==count and type(just['SYS'])is list and len(just['SYS'])==1,'Complete ordered justice counts')
    refs=list(model['original_bdds'].values())+just['ENV']+just['SYS'];names=[check_reference(r)for r in refs]
    need(len(refs)==count+8 and len(set(names))==len(refs),'Distinct complete declared BDD references')
    return refs

def project_inputs(profile,models,source_path,source_pin):
    exact(source_pin,SOURCE,'Exact source bytes');need(type(profile)is dict and type(models)is dict and set(models)=={'original','released'},'Profile and exact two models')
    exact({k:profile.get(k)for k in ('fixture_id','case_id','variant')},{'fixture_id':CASE,'case_id':'corpus188','variant':'original'},'Profile original identity')
    need(type(profile.get('source'))is dict and set(profile['source'])=={'path','bytes','sha256'},'Exact source reference fields')
    exact({k:profile['source'][k]for k in ('bytes','sha256')},SOURCE,'Source metadata')
    old=profile['source']['path'];need(type(old)is str and old.startswith('research:experiment/'),'Anonymous recorded source path')
    local=str(canonical_path(source_path));pv=copy.deepcopy(profile);pv['source']['path']=local;back=copy.deepcopy(pv);back['source']['path']=old;exact(back,profile,'Profile non-path values')
    projected={};changes=[{'file':'inputs/PROFILE.json','json_pointer':'/source/path','recorded_path':old,'local_path':local}]
    for mode,model in models.items():
        need(type(model)is dict and model.get('schema')=='k7-native-model-export-v1','Native model object/schema')
        identity={'fixture_id':CASE,'case_id':'corpus188'if mode=='original'else CASE,'variant':'original'if mode=='original'else'initializers'}
        exact({k:model.get(k)for k in identity},identity,'Exact '+mode+' identity');exact(model.get('input'),profile['source'],'Equal model source reference')
        view=copy.deepcopy(model);view['input']['path']=local;back=copy.deepcopy(view);back['input']['path']=old;exact(back,model,'Model non-path identity');projected[mode]=view
        changes.append({'file':'inputs/'+mode+'/model.json','json_pointer':'/input/path','recorded_path':old,'local_path':local})
    return pv,projected,{'projection':'IN_MEMORY_DECLARED_SOURCE_LOCATION_ONLY','changes':changes,'scientific_hash_fields_rewritten':False,'original_workspace_fallback':False,'persisted_input_mutations':0}

def admit_saved_inputs(frozen):
    profile=frozen.read('inputs/PROFILE.json');models={mode:frozen.read('inputs/'+mode+'/model.json')for mode in ('original','released')};results={mode:frozen.read('inputs/'+mode+'/result.json')for mode in models};declared={}
    for mode,model in models.items():
        refs=model_references(model,mode);declared[mode]=refs
        for r in refs:exact(digest(frozen.raw('inputs/'+mode+'/'+r['file'])),{k:r[k]for k in ('bytes','sha256')},'Declared saved BDD bytes')
        need({n for n in frozen.files if n.startswith('inputs/'+mode+'/')and n.endswith('.bdd')}=={'inputs/'+mode+'/'+r['file']for r in refs},'No missing or extra declared BDD')
        identity={'fixture_id':CASE,'case_id':'corpus188'if mode=='original'else CASE,'variant':'original'if mode=='original'else'initializers'}
        exact({k:results[mode].get(k)for k in identity},identity,'Native result identity')
        need(results[mode].get('input_sha256')==SOURCE['sha256'],'Native result source digest')
        need(results[mode].get('helper_added')is(mode=='released')and results[mode].get('helper_is_native_nonaux_ENV')is(mode=='released'),'Exact native helper branch/owner metadata')
    pv,mv,projection=project_inputs(profile,models,frozen.path('inputs/source.spectra'),digest(frozen.raw('inputs/source.spectra')))
    expected=frozen.read('expected/CHECK.json');need(expected.get('schema')=='fixed188-model-main-check-v1'and expected.get('status')=='PASS'and expected.get('id')==CASE,'Historical pair result identity')
    need(expected.get('historical_original_reference_only')is True and expected.get('historical_full_region_outcome_retained')=='UNKNOWN_RESOURCE','Historical partial reference remains incomplete')
    origin=frozen.read('authority/ORIGIN_COPY_BINDINGS.json');by={x['file']:x for x in origin['bindings']};need(len(by)==len(origin['bindings']),'Distinct origin/copy bindings')
    def bound(file,ref):
        row=by[file];exact(digest(frozen.raw(file)),{'bytes':row['copy_bytes'],'sha256':row['copy_sha256']},'Current exact copy');exact({k:ref[k]for k in ('bytes','sha256')},{'bytes':row['origin_bytes'],'sha256':row['origin_sha256']},'Historical origin identity')
    for mode in models:
        bound('inputs/'+mode+'/model.json',expected['native_exports'][mode]['model']);bound('inputs/'+mode+'/result.json',expected['native_exports'][mode]['native_result'])
    bound('expected/FUNCTIONS.json.gz',expected['canonical_functions'])
    need('bindings'not in pv,'No saved builder bindings overwritten')
    builder_profile={**pv,'bindings':{mode+'_native_model':pin(frozen.path('inputs/'+mode+'/model.json'))for mode in ('original','released')}}
    projection['generated_nonsemantic_builder_bindings']=builder_profile['bindings']
    return {'profile':pv,'builder_profile':builder_profile,'models':mv,'results':results,'projection':projection,'expected':expected,'declared_refs':declared}

def load_module(name,path,register=False):
    spec=importlib.util.spec_from_file_location(name,path);need(spec is not None and spec.loader is not None,'Exact module loader');module=importlib.util.module_from_spec(spec)
    if register:need(name not in sys.modules,'Unexpected preexisting dependency module');sys.modules[name]=module
    spec.loader.exec_module(module);need(Path(module.__file__).resolve()==Path(path).resolve(),'Exact loaded source origin');return module

def dependency_facade(check_directory):
    facade=ModuleType('evidence');facade.CHECK=canonical_path(check_directory);facade.ID=CASE;facade.require=need;return facade

def load_scientific(frozen):
    need('evidence'not in sys.modules,'No prior historical evidence module')
    facade=dependency_facade(frozen.path('code/context/generic_base.py').parent);sys.modules['evidence']=facade
    gate=load_module('model_gate',frozen.path('code/pair/model_gate.py'),True)
    mapping=load_module('map_pair',frozen.path('code/pair/map_pair.py'),True)
    relations=load_module('relations',frozen.path('code/pair/relations.py'),True)
    support=load_module('pair_support',frozen.path('code/pair/pair_support.py'),True)
    need(Path(mapping.base.__file__).resolve()==frozen.path('code/context/generic_base.py'),'Exact nested Context origin')
    need(Path(mapping.base._bdd_module.__file__).resolve()==frozen.path('code/context/vendor/bdd_core.py'),'Exact nested ROBDD origin')
    need(mapping.base.MAX_CARRIER==67584,'Unchanged fixed188 pair carrier configuration')
    return {'map':mapping,'relations':relations,'support':support,'gate':gate,'context':mapping.base,'facade':facade}

class ReadBridge:
    """Only the unchanged builder's three metadata reads can use projected copies."""
    def __init__(self,root,prepared):
        self.root=canonical_path(root);self.values={self.root/'inputs/original/model.json':prepared['models']['original'],self.root/'inputs/released/model.json':prepared['models']['released'],self.root/'inputs/released/result.json':prepared['results']['released']};self.calls={str(p.relative_to(self.root)):0 for p in self.values}
    def __call__(self,path):
        p=canonical_path(path);need(p in self.values,'Metadata read outside exact three-path bridge');key=str(p.relative_to(self.root));self.calls[key]+=1
        need(self.calls[key]==1,'Duplicate metadata read in single pair build');return copy.deepcopy(self.values[p])
    def complete(self):
        exact(self.calls,{'inputs/original/model.json':1,'inputs/released/model.json':1,'inputs/released/result.json':1},'Exactly three model/result metadata reads');return dict(self.calls)

def witness_bits_wire_view(summary, variables):
    """Convert only validated relation-witness bit keys to their JSON wire form."""
    need(type(variables) in (list, tuple) and len(variables) == 32 and
         all(type(v) is int for v in variables) and set(variables) == set(range(32)),
         'Exact original32 current/next integer bit roster')
    need(type(summary) is dict and type(summary.get('quadrants')) is list and
         len(summary['quadrants']) == 4, 'Exact four-quadrant summary')
    view = copy.deepcopy(summary)
    changed_paths = []
    check_names = {'ENV_literal_and_corrected', 'SYS_literal', 'SYS_corrected',
                   'joint_legal_edges_literal', 'joint_legal_edges_corrected'}
    witness_names = {'difference', 'actual_only', 'expected_only'}
    witness_fields = {'current', 'next', 'bits', 'actual_relation_value', 'expected_relation_value'}
    for i, (source_row, target_row) in enumerate(zip(summary['quadrants'], view['quadrants'])):
        need(type(source_row) is dict and source_row.get('quadrant') == ('00', '01', '10', '11')[i],
             'Exact ordered helper quadrants')
        checks = source_row.get('checks')
        need(type(checks) is dict and set(checks) == check_names, 'Exact five relation checks')
        for check_name, check in checks.items():
            need(type(check) is dict, 'Relation check object')
            witnesses = check.get('typed_witnesses')
            need(type(witnesses) is dict and set(witnesses) == witness_names,
                 'Exact three declared typed-witness positions')
            for kind, witness in witnesses.items():
                if witness is None:
                    continue
                need(type(witness) is dict and set(witness) == witness_fields,
                     'Exact nonnull relation-witness fields')
                bits = witness['bits']
                need(type(bits) is dict and len(bits) == 32 and
                     all(type(k) is int for k in bits) and set(bits) == set(variables),
                     'Complete runtime witness bits with exact integer keys, no bool/float/string keys')
                need(all(type(value) is bool for value in bits.values()),
                     'Runtime witness bit values must be exact booleans')
                wire = {str(key): value for key, value in bits.items()}
                need(len(wire) == len(bits) and set(wire) == {str(v) for v in variables},
                     'Injective complete canonical witness wire keys')
                target_row['checks'][check_name]['typed_witnesses'][kind]['bits'] = wire
                changed_paths.append('/quadrants/' + str(i) + '/checks/' + check_name +
                                     '/typed_witnesses/' + kind + '/bits')
    return view, {'normalization': 'DECLARED_RELATION_WITNESS_BIT_KEYS_TO_JSON_WIRE_VIEW',
                  'paths': changed_paths, 'original_current_next_bit_roster': list(variables),
                  'runtime_key_type': 'int_not_bool', 'wire_key_type': 'canonical_decimal_string',
                  'values_unchanged': True, 'source_summary_mutated': False,
                  'historical_expected_mutated': False, 'unrelated_data_coercions': 0}

def compare_pair(pair,summary,extra,expected):
    wire_summary, wire_projection = witness_bits_wire_view(summary, tuple(pair['original_current_bits']) + tuple(pair['original_next_bits']))
    exact(wire_summary,expected['all_quadrant_relations'],'All four full typed relation quadrants')
    exact(extra,expected['supplemental_full_current_checks'],'Full typed initial and ordered justice correspondence')
    need([r['quadrant']for r in summary['quadrants']]==['00','01','10','11']and summary['typed_original_edge_domain_count']==33792**2,'Exact whole typed edge domain')
    need(summary['helper_added']is True and extra['all_equal']is True,'Actual helper and full current-domain correspondence')
    shape={'status':'PASS','all_original_fields_and_AUX_retained':pair['all_original_AUX_retained'],'helper_added':pair['helper_added'],'original_carrier':pair['original'].carrier,'released_carrier':pair['job'].carrier,'original_AUX_fields':[f['name']for f in pair['original_fields']if f['role']=='AUX']}
    exact(shape,{k:expected['pair_structure'][k]for k in shape},'Pair structure scientific metadata')
    for mode,key in [('original','original_audit'),('released','job_audit')]:exact(pair[key],expected['native_exports'][mode]['typed_audit'],'Complete '+mode+' typed model audit')
    return {'status':'PASS_SAVED_PAIR_FIELDS_RECHECK','runtime_witness_bits_wire_view':wire_projection,'all_compared_scientific_fields_equal':True,'compared_fields':['all_quadrant_relations','supplemental_full_current_checks','pair_structure_scientific_metadata','native_exports.original.typed_audit','native_exports.released.typed_audit'],'scientific_pair_structure':shape,'actual_released_correspondence_rechecked':True,'historical_original_reference_comparison_replayed':False,'historical_producer_admission_replayed':False,'target_policy_replayed':False,'historical_full_region_outcome_retained':'UNKNOWN_RESOURCE','source_compiler_premise':'Historical pinned producer/source translation; not freshly compiled.','native_calls':0,'solver_calls':0,'fixed_point_calls':0,'new_scientific_samples':0}

def read_export(raw):
    need(len(raw)<=LIMITS['file_bytes'],'Bounded compressed canonical file')
    with gzip.GzipFile(fileobj=io.BytesIO(raw),mode='rb')as stream:
        expanded=stream.read(LIMITS['file_bytes']+1)
    need(len(expanded)<=LIMITS['file_bytes'],'Bounded expanded canonical file');return decode(expanded)

def canonical_export(export):
    keys={'schema','variable_count','canonical_variable_order','original_fields','original_current_bits','original_next_bits','helper_current_bit','helper_next_bit','roots','nodes'}
    need(type(export)is dict and set(export)==keys,'Canonical pair export roster')
    need(export['schema']=='helper-quadrant-canonical-functions-v1','Canonical pair schema');n=export['variable_count'];need(type(n)is int and 0<n<=64,'Canonical variable count')
    exact(export['canonical_variable_order'],list(range(n)),'Canonical variable order')
    need(type(export['roots'])is dict and type(export['nodes'])is list,'Canonical roots and node records');nodes={};unique_nodes=set()
    for row in export['nodes']:
        need(type(row)is list and len(row)==4and all(type(v)is int for v in row),'Canonical node exact integer tuple');u,v,lo,hi=row
        need(u>=2and u not in nodes and 0<=v<n and lo>=0and hi>=0and lo!=hi,'Reduced canonical node identity')
        need((v,lo,hi)not in unique_nodes,'Unique reduced node');nodes[u]=(v,lo,hi);unique_nodes.add((v,lo,hi))
    for u,(v,lo,hi)in nodes.items():
        for child in(lo,hi):need(child in(0,1)or child in nodes and nodes[child][0]>v,'Closed strict canonical variable order')
    seen=set();memo={0:sha(b'0'),1:sha(b'1')}
    def visit(u):
        need(type(u)is int and (u in(0,1)or u in nodes),'Closed integer canonical root')
        if u in memo:return memo[u]
        seen.add(u);v,lo,hi=nodes[u];memo[u]=sha(f'{v}:{visit(lo)}:{visit(hi)}'.encode());return memo[u]
    digests={name:visit(u)for name,u in export['roots'].items()};need(seen==set(nodes),'No unreachable export nodes');return digests

def compare_exports(current,historical):
    metadata=sorted(set(current)-{'roots','nodes'});need(metadata==sorted(set(historical)-{'roots','nodes'}),'Same export metadata roster')
    for key in metadata:exact(current[key],historical[key],'Exact canonical metadata '+key)
    exact(current['variable_count'],34,'Pair common variable count');exact(current['helper_current_bit'],32,'Semantic helper current bit');exact(current['helper_next_bit'],33,'Semantic helper next bit')
    need(len(current['original_fields'])==12and len(current['original_current_bits'])==len(current['original_next_bits'])==16,'Complete original fields and bit partitions')
    cur=canonical_export(current);old=canonical_export(historical);exact(cur,old,'Every canonical pair function digest');need(len(cur)==115,'All115 complete canonical roots')
    return {'status':'PASS_ALL_115_CANONICAL_PAIR_FUNCTION_DIGESTS','root_count':115,'digests':cur,'metadata_fields':metadata,'current_export_nodes':len(current['nodes']),'historical_export_nodes':len(historical['nodes']),'node_ids_or_compressed_file_bytes_not_required_equal':True}

def load_go(path,manifest_hash,output):
    ref=pin(path);go=decode(file_bytes(path))
    keys={'schema','status','frozen_manifest_sha256','scope','case','output_root','attempts','saved_evaluations','native_calls','solver_calls','fixed_point_calls','deadline_utc','limits','qualification_receipts'}
    need(type(go)is dict and set(go)==keys,'Exact new scope authority fields')
    need(go['schema']=='fixed188-portable-pair-scope-go-v1' and go['status']=='GO','Fresh saved-pair authority required')
    need(go['frozen_manifest_sha256']==manifest_hash and go['scope']==SCOPE and go['case']==CASE,'GO exact manifest/scope/case')
    need(go['output_root']==str(canonical_path(output)),'GO exact output root')
    for k,n in [('attempts',1),('saved_evaluations',1),('native_calls',0),('solver_calls',0),('fixed_point_calls',0)]:need(type(go[k])is int and go[k]==n,'Exact integer authority '+k)
    exact(go['limits'],LIMITS,'Exact scope limits')
    deadline=datetime.fromisoformat(go['deadline_utc']);need(deadline.tzinfo is not None and (deadline-datetime.now(timezone.utc)).total_seconds()>1,'Unexpired timezone-aware GO')
    need(type(go['qualification_receipts'])is list and len(go['qualification_receipts'])==2,'Exactly artificial/import qualification bindings')
    kinds=set()
    for q in go['qualification_receipts']:
        need(type(q)is dict and set(q)=={'path','bytes','sha256'},'Qualification receipt pin fields');exact(pin(q['path']),q,'Qualification receipt pin')
        record=decode(file_bytes(q['path']))
        need(record.get('status')=='PASS_QUALIFIED_PREPARATION' and record.get('frozen_manifest_sha256')==manifest_hash,'Prior qualification passed for this exact freeze')
        kind=record.get('qualification_kind');need(kind in ('artificial','imports') and kind not in kinds,'Distinct artificial/import qualifications');kinds.add(kind)
    need(kinds=={'artificial','imports'},'Both prerequisite qualifications')
    return go,ref
