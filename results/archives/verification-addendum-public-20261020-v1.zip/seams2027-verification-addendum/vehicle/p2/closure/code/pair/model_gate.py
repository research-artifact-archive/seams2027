"""Exact target metadata gate; no BDD imports or evaluation."""
from math import prod
from evidence import require,ID
LANES=('First','Second','Third')
ENV=tuple(prefix+lane+'Lane' for prefix in ('pedestrian','greenLight','obstacle') for lane in LANES)+('crosswalk',)

def admit_model_shape(model,mode):
    require(mode in ('original','released'),'Exact188 mode')
    require(model['fixture_id']==ID and model['case_id']==('corpus188' if mode=='original' else ID) and model['variant']==('original' if mode=='original' else 'initializers'),'Exact188 model identity')
    fields=model['fields'];expected=set(ENV)|{'currentLane','speed'}|({'~envHelp'} if mode=='released' else set())
    require(type(fields) is list and len(fields)==len(expected) and {f['name'] for f in fields}==expected,'Exact188 full field roster; unexpected AUX or helper rejected')
    for f in fields:
        name=f['name'];owner='ENV' if name in ENV or name=='~envHelp' else 'SYS'
        require(f['owner']==f['role']==owner,'Exact nonAUX ownership:'+name)
        values=set(LANES) if name=='currentLane' else {str(i) for i in range(11)} if name=='speed' else {'false','true'}
        require(type(f['domain_size']) is int and f['domain_size']==len(values) and type(f['values']) is list and len(f['values'])==len(values) and set(f['values'])==values,'Exact188 typed values:'+name)
    carrier=prod(f['domain_size'] for f in fields);target=33792 if mode=='original' else 67584
    require(carrier==target,'Exact188 carrier, not a generic cap relaxation')
    require(type(model['bdd_variable_count']) is int and model['bdd_variable_count']==(32 if mode=='original' else 34),'Exact188 BDD variable roster size')
    current=[v for f in fields for v in f['current_bits']];nxt=[v for f in fields for v in f['next_bits']]
    require(all(type(x) is int for x in current+nxt) and len(current)==len(set(current)) and len(nxt)==len(set(nxt)) and not set(current)&set(nxt) and set(current+nxt)==set(range(model['bdd_variable_count'])),'Exact188 disjoint current/next complete bit cover')
    require(len(model['original_justices']['ENV'])==(3 if mode=='original' else 4) and len(model['original_justices']['SYS'])==1,'Exact188 justice counts; order/functions checked later')
    return {'status':'PASS_EXACT_188_METADATA_GATE','mode':mode,'typed_carrier':carrier,'logical_AUX_fields':[],'field_count':len(fields),'variables':model['bdd_variable_count'],'BDD_computations':0}
