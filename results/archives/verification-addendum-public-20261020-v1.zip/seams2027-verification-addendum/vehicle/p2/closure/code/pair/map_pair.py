"""Typed name/value lift into original bits and two semantic Boolean helper bits."""
from functools import lru_cache
from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
from evidence import CHECK,require
sys.path.insert(0,str(CHECK))
spec=importlib.util.spec_from_file_location('helper_quadrant_frozen_base',CHECK/'generic_base.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
base.MAX_CARRIER=67584
BDD=base.BDD;ResourceRefusal=base.ResourceRefusal;HELPER='~envHelp'

def transfer(src,dst,replacements):
    @lru_cache(None)
    def visit(u):
        if u<2:return u
        v,lo,hi=src.nodes[u];require(v in replacements,'Incomplete typed bit lift')
        return dst.ite(replacements[v],visit(hi),visit(lo))
    return visit

def build(original_directory,job_directory,ident,profile=None):
    od,jd=Path(original_directory),Path(job_directory)
    om,jm=base.read_json(od/'model.json'),base.read_json(jd/'model.json');native=base.read_json(jd/'result.json')
    p=base.load_profile(ident) if profile is None else profile
    require({k:om[k] for k in ('fixture_id','case_id','variant')}=={k:p[k] for k in ('fixture_id','case_id','variant')},'Original model identity')
    require(native['fixture_id']==native['case_id']==jm['fixture_id']==jm['case_id']==ident and native['variant']==jm['variant']=='initializers','Released model identity')
    for m in (om,jm):
        if m['bdd_variable_count']>64:raise ResourceRefusal('Native model Boolean variable cap64')
    from model_gate import admit_model_shape
    admit_model_shape(om,'original');admit_model_shape(jm,'released')
    original=base.Context(od,p,om)
    if original.carrier!=33792:raise ResourceRefusal('Exact188 original typed carrier33792')
    job=base.Context(jd,{**p,'fixture_id':ident,'case_id':ident,'variant':'initializers'},jm)
    original_audit,job_audit=original.audit_model(),job.audit_model()
    require(native['input_sha256']==om['input']['sha256']==jm['input']['sha256']==p['source']['sha256'] and om['input']['bytes']==jm['input']['bytes']==p['source']['bytes'],'Exact original/job public source')
    helper=native.get('helper_added');require(type(helper) is bool,'Explicit helper branch')
    predicted=any(c['kind'] in ('SAFETY','STATE_INV') for c in om['source_inventory']['parsed']['ENV']['constraints'])
    require(helper==predicted,'Helper branch matches parsed ENV safety presence')
    require(HELPER not in original.by_name and set(job.by_name)==set(original.by_name)|({HELPER} if helper else set()),'Exact fields with optional helper; retain every original AUX')
    for name,f in original.by_name.items():
        g=job.by_name[name];require((f['owner'],f['role'],set(f['values']))==(g['owner'],g['role'],set(g['values'])),'Typed original/job field correspondence:'+name)
    if helper:
        f=job.by_name[HELPER];require((f['owner'],f['role'],set(f['values']))==('ENV','ENV',{'false','true'}) and native['helper_is_native_nonaux_ENV'] is True,'Helper native nonAUX ENV Boolean ownership')
    else:require(native['helper_is_native_nonaux_ENV'] is False,'No-helper branch ownership')
    n=original.b.n+2*int(helper)
    if n>64:raise ResourceRefusal('Common original-plus-helper variable cap64')
    common=BDD(n,node_limit=500000);otr=transfer(original.b,common,{v:common.var(v) for v in range(original.b.n)})
    replacements={}
    for name,field in job.by_name.items():
        for prime,key in ((False,'current_bits'),(True,'next_bits')):
            for v in field[key]:
                if name==HELPER:
                    bv=common.var(original.b.n+int(prime));false=job.enc[name]['false'][int(prime)][v];true=job.enc[name]['true'][int(prime)][v]
                    replacements[v]=common.ite(bv,int(true),int(false))
                else:replacements[v]=common.disj(*(otr(original.literal(name,value,prime)) for value in field['values'] if job.enc[name][value][int(prime)][v]))
    jtr=transfer(job.b,common,replacements)
    current=otr(original.domain);edge=common.conj(current,otr(original.b.rename(original.domain,original.prime)))
    require(common.conj(current,common.neg(jtr(job.domain)))==0,'Typed original-to-job domain lift')
    original_roots={k:otr(v) for k,v in original.formulas.items()};job_roots={k:jtr(v) for k,v in job.formulas.items()}
    # Keep full current domain for both helper values. Do not assume the old 00 audit covers it.
    b=common.var(original.b.n) if helper else 0
    initial={}
    for key,expected in [('thetaE',common.conj(original_roots['thetaE'],common.neg(b)) if helper else original_roots['thetaE']),('thetaS',original_roots['thetaS'])]:
        delta=common.conj(current,common.apply('xor',job_roots[key],expected))
        initial[key]={'equal_full_typed_current_domain':delta==0,'difference_root':delta}
    justice={}
    for owner in ('ENV','SYS'):
        expected=[otr(v) for v in original.justices[owner]];actual=[jtr(v) for v in job.justices[owner]];filtered=list(actual);helper_indices=[]
        if helper and owner=='ENV':
            helper_indices=[i for i,u in enumerate(actual) if common.conj(current,common.apply('xor',u,common.neg(b)))==0]
            if len(helper_indices)==1:filtered.pop(helper_indices[0])
        inserted_ok=not(helper and owner=='ENV') or len(helper_indices)==1
        differences=[common.conj(current,common.apply('xor',a,e)) for a,e in zip(filtered,expected)]
        expected_count=len(expected)+int(helper and owner=='ENV')
        justice[owner]={'count_equal':len(actual)==expected_count,'expected_count':expected_count,'actual_count':len(actual),'helper_justice_indices':helper_indices,
            'equal_identity_and_order_full_typed_current_domain':inserted_ok and len(actual)==expected_count and len(filtered)==len(expected) and all(x==0 for x in differences),'difference_roots':differences}
    return {'common':common,'original':original,'job':job,'typed_edge_mask':edge,'original_roots':original_roots,'job_roots':job_roots,'helper_added':helper,
        'helper_current_bit':original.b.n if helper else None,'helper_next_bit':original.b.n+1 if helper else None,
        'original_current_bits':tuple(original.current),'original_next_bits':tuple(original.next),'original_fields':original.fields,
        'original_audit':original_audit,'job_audit':job_audit,'source_bindings':p.get('bindings',{'synthetic_profile':True}),
        'initial_full_domain':initial,'justice_full_domain':justice,'all_original_AUX_retained':True,'independent_source_compiler':False,
        'AUX_attribution_status':'UNKNOWN_NO_PER_CONSTRAINT_SEMANTIC_PROOF'}
