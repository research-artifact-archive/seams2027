"""Copy the exact saved fixed188 pair bytes; no scientific module import/evaluation."""
from pathlib import Path,PurePosixPath
import hashlib,json,tarfile
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
ARCHIVE=HERE.parent/'additional_evidence_build_01/execution_02/additional-evidence.tar.gz'
INNER=ROOT/'experiment/seams_research_reframing_20261018/portable_verification_build_05/package'
A='additional-evidence/vehicle188/'
E='evidence/experiment/seams_research_reframing_20261017/'
P=E+'released_transform_188_preparation/'
T=E+'corpus188_target_certificate_preparation/'
R=P+'runs/corpus188__original/'
def digest(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def pin(path):return digest(path.read_bytes())
def emit(name,obj):
 p=HERE/name;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def put(name,raw):
 p=HERE/name;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);assert p.read_bytes()==raw
assert pin(ARCHIVE)=={'bytes':2256380,'sha256':'f22189add83fecffe56b4a74157f7fa52642bfcaa91e53cfa3f415a88d8e7887'}
assert pin(INNER/'MANIFEST.json')['sha256']=='adc9466569209fab91ecd0085ccca41633409bca8d1e7ad80d4d782fb48d3607'
inner={x['file']:x for x in json.loads((INNER/'MANIFEST.json').read_text())['files']}
entries=[];bindings=[];counts={};models={};results={}
with tarfile.open(ARCHIVE,'r:gz')as tar:
 members={m.name:m for m in tar.getmembers()};ad={x['file']:x for x in json.load(tar.extractfile('additional-evidence/MANIFEST.json'))['files']};oi={x['copy_file']:x for x in json.load(tar.extractfile(A+'ORIGIN_DIGESTS.json'))['files']}
 def take(member,name,role):
  assert member in ad and member in members;m=members[member];assert m.isfile()and not m.issym()and not m.islnk();raw=tar.extractfile(m).read();actual=digest(raw);assert actual=={k:ad[member][k]for k in ('bytes','sha256')};put(name,raw)
  row={'file':name,**actual,'role':role,'authority':{'container':'additional-evidence/additional-evidence.tar.gz','member':member,'current_copy_pin':actual}};key=member.removeprefix(A)
  if key in oi:
   old=oi[key];assert actual=={'bytes':old['copy_bytes'],'sha256':old['copy_sha256']};row['authority']['historical_origin']={k:old[k]for k in ('origin_path','origin_bytes','origin_sha256','transformation','changed_paths')};bindings.append({'file':name,'member':member,**old})
  entries.append(row);return json.loads(raw)if member.endswith('.json')else raw
 for mode,justice_count in [('original',3),('released',4)]:
  model=take(A+R+mode+'/model.json','inputs/'+mode+'/model.json',mode.upper()+'_MODEL_METADATA');models[mode]=model
  results[mode]=take(A+R+mode+'/result.json','inputs/'+mode+'/result.json',mode.upper()+'_HISTORICAL_RESULT_METADATA')
  assert set(model['original_bdds'])=={'thetaE','thetaS','rhoE','rhoS','domain','domain_ENV_next','domain_SYS_next'}
  assert len(model['original_justices']['ENV'])==justice_count and len(model['original_justices']['SYS'])==1
  refs=list(model['original_bdds'].values())+model['original_justices']['ENV']+model['original_justices']['SYS'];assert len(refs)==justice_count+8 and len({r['file']for r in refs})==len(refs);counts[mode]=len(refs)
  for ref in refs:
   name=ref['file'];assert PurePosixPath(name).name==name and name.endswith('.bdd')and '/'not in name and '\\'not in name
   raw=take(A+R+mode+'/'+name,'inputs/'+mode+'/'+name,'SAVED_DECLARED_BDD');assert digest(raw)=={k:ref[k]for k in ('bytes','sha256')}
 for name in ['map_pair.py','model_gate.py','relations.py','pair_support.py']:take(A+P+name,'code/pair/'+name,'UNCHANGED_PAIR_MATHEMATICS')
 profile=take(A+T+'PROFILE.json','inputs/PROFILE.json','ORIGINAL_SOURCE_PROFILE')
 expected=take(A+R+'CHECK.json','expected/CHECK.json','HISTORICAL_PAIR_RESULT')
 take(A+R+'FUNCTIONS.json.gz','expected/FUNCTIONS.json.gz','HISTORICAL_CANONICAL_PAIR_EXPORT')
for origin,name,role in [
 ('base/'+E+'kind_corpus/original/artifact/experiments/specs/syn20/AutonomousVehicle_sprint02_ver1.spectra','inputs/source.spectra','UNCHANGED_SOURCE_BYTES'),
 ('base/'+E+'released_kind_corpus_checker/generic_base.py','code/context/generic_base.py','UNCHANGED_CONTEXT_MATHEMATICS'),
 ('base/'+E+'released_kind_corpus_checker/vendor/bdd_core.py','code/context/vendor/bdd_core.py','UNCHANGED_ROBDD_MATHEMATICS'),
 ('code/runtime_guard.py','code/runtime_guard.py','UNCHANGED_QUALIFIED_IO_GUARD'),
 ('code/supervisor/bounded_process.py','code/supervisor/bounded_process.py','UNCHANGED_QUALIFIED_SUPERVISOR'),
 ('code/supervisor/owned_process.py','code/supervisor/owned_process.py','UNCHANGED_QUALIFIED_PROCESS_OWNERSHIP')]:
 raw=(INNER/origin).read_bytes();actual=digest(raw);assert actual=={k:inner[origin][k]for k in ('bytes','sha256')};put(name,raw);entries.append({'file':name,**actual,'role':role,'authority':{'container':'package','file':origin,'current_copy_pin':actual}})
assert pin(HERE/'inputs/source.spectra')=={k:profile['source'][k]for k in ('bytes','sha256')}
assert all(model['input']==profile['source']for model in models.values())
assert expected['schema']=='fixed188-model-main-check-v1'and expected['id']=='corpus188__original'and expected['status']=='PASS'
assert expected['historical_original_reference_only']is True and expected['historical_full_region_outcome_retained']=='UNKNOWN_RESOURCE'
assert expected['all_quadrant_relations']['typed_original_edge_domain_count']==33792**2
emit('authority/ORIGIN_COPY_BINDINGS.json',{'schema':'fixed188-pair-saved-copy-origin-bindings-v1','archive':pin(ARCHIVE),'bindings':bindings,'scope':'Exact archived copies; retain historical origins separately and never rewrite digest fields.'})
entries.append({'file':'authority/ORIGIN_COPY_BINDINGS.json',**pin(HERE/'authority/ORIGIN_COPY_BINDINGS.json'),'role':'GENERATED_ORIGIN_COPY_BINDING'})
emit('INPUT_MANIFEST.json',{'schema':'fixed188-pair-input-closure-v1','status':'STATIC_COPY_ONLY_NOT_EXECUTED','fixture_id':'corpus188__original','archive':pin(ARCHIVE),'inner_manifest':pin(INNER/'MANIFEST.json'),'files':entries,'declared_BDD_counts':counts,'scientific_core_changes':0,'scope':'Actual archived original/released full typed relation and ordered justice correspondence; old partial-reference comparison and producer admission are not replayed.','scientific_evaluations':0,'native_calls':0,'full_reset_uses':0})
for row in entries:assert pin(HERE/row['file'])=={k:row[k]for k in ('bytes','sha256')}
print(json.dumps({'status':'PASS_STATIC_COPY_ONLY','files':len(entries),'bytes':sum(x['bytes']for x in entries),'manifest':pin(HERE/'INPUT_MANIFEST.json')}))
