"""Generate a reader's new P3 request files; never import or launch an audit.

Reader helper. Invoking 'actual' is an explicit decision to authorize one
bounded saved-original source comparison after reviewing both qualifications.
"""
from datetime import datetime, timedelta, timezone
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import re
import shutil

MANIFEST = '1edea1545a651f429645c698a4057331b57bcf33e54a2baf9f9c654532e0ebc4'
SCOPE = 'independent_original_source_equations'
CASE = 'corpus188__original'
LIMITS = {'wall_seconds': 180, 'rss_bytes': 536870912, 'stream_bytes': 65536,
          'file_bytes': 2097152, 'output_tree_bytes': 2097152,
          'reserve_bytes': 8388608, 'min_free_bytes': 1073741824}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def unique(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, 'Duplicate JSON key')
        result[key] = value
    return result


def decode(raw):
    def nonfinite(value):
        raise ValueError('Nonfinite JSON value')
    return json.loads(raw, object_pairs_hook=unique, parse_constant=nonfinite)


def canonical(path):
    p = Path(path).absolute()
    need('..' not in p.parts and p.resolve() == p, 'Canonical path without symlinks required')
    current = Path(p.anchor)
    for part in p.parts[1:]:
        current /= part
        need(not current.is_symlink(), 'Symlink path component')
    return p


def raw_file(path):
    p = canonical(path)
    need(p.is_file() and p.stat().st_size <= LIMITS['file_bytes'], 'Regular file at most2MiB')
    raw = p.read_bytes()
    need(len(raw) <= LIMITS['file_bytes'], 'Read byte cap')
    return raw


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def file_pin(path):
    return {'path': str(canonical(path)), **identity(raw_file(path))}


def frozen_closure(root):
    root = canonical(root)
    need(root.is_dir(), 'Source closure directory required')
    raw = raw_file(root/'FROZEN_MANIFEST.json')
    need(identity(raw)['sha256'] == MANIFEST, 'Published P3 manifest SHA256 required')
    manifest = decode(raw)
    need(manifest['schema'] == 'fixed188-independent-source-freeze-v1' and
         manifest['scope'] == SCOPE and manifest['case'] == CASE, 'Exact source schema/scope/case')
    need(type(manifest['files']) is list and len(manifest['files']) == 29, 'Exact29 frozen source files')
    names = set()
    for row in manifest['files']:
        name = row['file']
        need(type(name) is str and bool(name), 'Relative file name')
        p = PurePosixPath(name)
        need(not p.is_absolute() and p.as_posix() == name and '\\' not in name and
             all(part not in ('', '.', '..') for part in name.split('/')), 'Safe relative path')
        need(name not in names, 'Duplicate frozen file')
        names.add(name)
        need(type(row['bytes']) is int and row['bytes'] >= 0 and type(row['sha256']) is str and
             re.fullmatch('[0-9a-f]{64}', row['sha256']) is not None, 'Exact file pin types')
        need(identity(raw_file(root/name)) == {key: row[key] for key in ('bytes','sha256')}, 'Frozen file changed')
    present = set()
    for path in root.rglob('*'):
        need(not path.is_symlink(), 'Symlink anywhere in source closure')
        if path.is_file():
            present.add(path.relative_to(root).as_posix())
        else:
            need(path.is_dir(), 'Nonregular source closure entry')
    need(present == names | {'FROZEN_MANIFEST.json'}, 'Complete exact frozen roster')
    return root


def preparation_object(base, deadline):
    # The source authority rejects extra keys; do not reuse P1/P2's looser schema.
    return {'schema': 'fixed188-independent-source-preparation-go-v1',
            'status': 'GO_ARTIFICIAL_AND_IMPORT_QUALIFICATION',
            'frozen_manifest_sha256': MANIFEST, 'scope': SCOPE, 'case': CASE,
            'output_roots': {'artificial': str(base/'artificial'), 'imports': str(base/'imports')},
            'deadline_utc': deadline, 'limits': dict(LIMITS),
            'saved_DAG_evaluations_authorized': 0}


def actual_object(base, deadline, receipts):
    return {'schema': 'fixed188-independent-source-single-go-v1', 'status': 'GO',
            'frozen_manifest_sha256': MANIFEST, 'scope': SCOPE, 'case': CASE,
            'output_root': str(base/'actual'), 'attempts': 1, 'saved_evaluations': 1,
            'native_calls': 0, 'solver_calls': 0, 'fixed_point_calls': 0,
            'deadline_utc': deadline, 'limits': dict(LIMITS), 'qualification_receipts': receipts}


def save_new(path, value):
    need(path.parent.is_dir() and not path.exists() and not path.is_symlink(), 'Fresh request file required')
    raw = (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n').encode()
    need(len(raw) <= LIMITS['file_bytes'], 'Request byte cap')
    with path.open('xb') as stream:
        stream.write(raw)
    need(path.read_bytes() == raw, 'Request readback identity')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['prepare','actual'])
    parser.add_argument('--closure', required=True)
    parser.add_argument('--output-base', required=True)
    args = parser.parse_args()
    root = frozen_closure(args.closure)
    base = canonical(args.output_base)
    need(base != root and not base.is_relative_to(root) and not root.is_relative_to(base),
         'Reader output base must be separate from complete immutable source closure')
    need(base.parent.is_dir(), 'Existing output parent required')
    need(shutil.disk_usage(base.parent).free > LIMITS['min_free_bytes'] +
         LIMITS['reserve_bytes'] + 3*LIMITS['output_tree_bytes'], 'Disk floor plus run/reserve space')
    deadline = (datetime.now(timezone.utc)+timedelta(minutes=15)).isoformat()
    if args.action == 'prepare':
        need(not base.exists(), 'Fresh reader output base required')
        base.mkdir()
        (base/'external-probe').mkdir()
        save_new(base/'external-probe/OUTSIDE_READ_PROBE', {'generated_reader_probe': True})
        path = base/'PREPARATION_GO.json'
        save_new(path, preparation_object(base, deadline))
    else:
        need(base.is_dir() and not (base/'actual').exists(), 'Qualification base and fresh actual output required')
        receipts = []
        for kind in ('artificial','imports'):
            path = base/kind/'RUN_RECEIPT.json'
            ref = file_pin(path)
            report = decode(raw_file(path))
            need(report.get('status') == 'PASS_SOURCE_AUDIT_QUALIFICATION' and
                 report.get('qualification_kind') == kind and report.get('frozen_manifest_sha256') == MANIFEST and
                 report.get('scope') == SCOPE and report.get('case') == CASE,
                 'Both local source qualifications must pass for this exact freeze')
            need(report.get('inputs_unchanged') is True and report.get('errors') == [] and
                 type(report.get('attempts')) is int and report['attempts'] == 1 and
                 report.get('admitted_scientific_result') is False, 'Clean one-attempt qualification record')
            receipts.append(ref)
        path = base/'ACTUAL_GO.json'
        save_new(path, actual_object(base, deadline, receipts))
    print(json.dumps({'request':file_pin(path), 'checker_launched':False,
                      'saved_source_evaluations':0, 'native_calls':0, 'full_reset_uses':0}))


if __name__ == '__main__':
    main()
