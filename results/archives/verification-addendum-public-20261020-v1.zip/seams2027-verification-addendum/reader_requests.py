"""Create a reader's fresh bounded Vehicle request; never launch a checker."""
from datetime import datetime, timedelta, timezone
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import shutil

P1_MANIFEST = 'adfd09c317c25cea1e81e75692112fcbda6c5b004a6520de5f8aa26412640107'
P1_SCOPE = 'target_original_literal'
P2_MANIFEST = '2cae853764c28a4a2d7ec97d0d75911113b684368493777808a3bb14ff7a0f07'
P2_SCOPE = 'saved_actual_original_released_pair'
SCOPES = {'p1': {'manifest': P1_MANIFEST, 'scope': P1_SCOPE, 'actual_schema': 'fixed188-portable-single-scope-go-v1'},
          'p2': {'manifest': P2_MANIFEST, 'scope': P2_SCOPE, 'actual_schema': 'fixed188-portable-pair-scope-go-v1'}}
CASE = 'corpus188__original'
LIMITS = {'wall_seconds': 60, 'rss_bytes': 536870912, 'stream_bytes': 1048576,
          'file_bytes': 2097152, 'output_tree_bytes': 8388608, 'min_free_bytes': 1073741824}

def need(ok, message):
    if not ok:
        raise ValueError(message)

def unique(pairs):
    out = {}
    for key, value in pairs:
        need(key not in out, 'Duplicate JSON key')
        out[key] = value
    return out

def decode(raw):
    def bad(value):
        raise ValueError('Nonfinite JSON value')
    return json.loads(raw, object_pairs_hook=unique, parse_constant=bad)

def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()

def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def canonical(path):
    p = Path(path).absolute()
    need('..' not in p.parts and p.resolve() == p, 'Canonical path without symlinks required')
    current = Path(p.anchor)
    for part in p.parts[1:]:
        current /= part
        need(not current.is_symlink(), 'Symlink path component')
    return p

def file_pin(path):
    p = canonical(path)
    need(p.is_file() and p.stat().st_size <= LIMITS['file_bytes'], 'Regular file at most 2 MiB required')
    raw = p.read_bytes()
    return {'path': str(p), **identity(raw)}

def frozen_closure(root, scope_id):
    config = SCOPES[scope_id]
    root = canonical(root)
    need(root.is_dir(), 'Closure directory required')
    manifest_path = root / 'FROZEN_MANIFEST.json'
    need(file_pin(manifest_path)['sha256'] == config['manifest'], 'Expected published scope manifest SHA-256')
    manifest = decode(manifest_path.read_bytes())
    need(manifest['scope'] == config['scope'] and manifest['case'] == CASE, 'Exact scope and case')
    names = set()
    for row in manifest['files']:
        name = row['file']
        p = PurePosixPath(name)
        need(type(name) is str and p.as_posix() == name and not p.is_absolute() and '\\' not in name and all(x not in ('', '.', '..') for x in name.split('/')), 'Safe frozen relative path')
        need(name not in names, 'Duplicate frozen file')
        names.add(name)
        actual = file_pin(root / name)
        need({k: actual[k] for k in ['bytes', 'sha256']} == {k: row[k] for k in ['bytes', 'sha256']}, 'Frozen input changed')
    present = set()
    for p in root.rglob('*'):
        need(not p.is_symlink(), 'Symlink in frozen closure')
        if p.is_file():
            present.add(str(p.relative_to(root)))
        else:
            need(p.is_dir(), 'Nonregular frozen entry')
    need(present == names | {'FROZEN_MANIFEST.json'}, 'Complete exact frozen roster required')
    return root

def prepare_object(manifest, base, deadline):
    return {'schema': 'reader-fixed188-preparation-only-go-v1',
            'status': 'GO_ARTIFICIAL_AND_IMPORT_QUALIFICATION',
            'frozen_manifest_sha256': manifest, 'saved_DAG_evaluations_authorized': 0,
            'native_calls': 0, 'deadline_utc': deadline,
            'output_roots': {'artificial': str(base / 'artificial'), 'imports': str(base / 'imports')},
            'serial_order': ['artificial', 'imports'], 'maximum_attempts_each': 1,
            'stop_on_any_failure': True, 'full_reset_uses': 0}

def actual_object(manifest, base, deadline, receipts, scope_id='p1'):
    config = SCOPES[scope_id]
    return {'schema': config['actual_schema'], 'status': 'GO',
            'frozen_manifest_sha256': manifest, 'scope': config['scope'], 'case': CASE,
            'output_root': str(base / 'actual'), 'attempts': 1, 'saved_evaluations': 1,
            'native_calls': 0, 'solver_calls': 0, 'fixed_point_calls': 0,
            'deadline_utc': deadline, 'limits': dict(LIMITS), 'qualification_receipts': receipts}

def save_new(path, value):
    need(not path.exists() and not path.is_symlink(), 'Request already exists; no overwrite')
    raw = encode(value)
    with path.open('xb') as stream:
        stream.write(raw)
    need(path.read_bytes() == raw, 'Request readback mismatch')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['p1-prepare', 'p1-actual', 'p2-prepare', 'p2-actual'])
    parser.add_argument('--closure', required=True)
    parser.add_argument('--output-base', required=True)
    args = parser.parse_args()
    scope_id, action = args.action.split('-', 1)
    config = SCOPES[scope_id]
    root = frozen_closure(args.closure, scope_id)
    base = canonical(args.output_base)
    need(base != root and not base.is_relative_to(root) and not root.is_relative_to(base), 'Output base must be separate from the complete frozen closure')
    need(base.parent.is_dir(), 'Output parent must exist')
    need(shutil.disk_usage(base.parent).free > LIMITS['min_free_bytes'] + 4 * LIMITS['output_tree_bytes'], 'Free-space floor plus three run and receipt reserves')
    deadline = (datetime.now(timezone.utc) + timedelta(minutes=15)).isoformat()
    if action == 'prepare':
        need(not base.exists(), 'Fresh reader output base required')
        base.mkdir()
        (base / 'external-probe').mkdir()
        save_new(base / 'external-probe/MANIFEST.json', {'generated_probe': True})
        path = base / 'PREPARATION_GO.json'
        save_new(path, prepare_object(config['manifest'], base, deadline))
    else:
        need(base.is_dir() and not (base / 'actual').exists(), 'Existing qualification base and fresh actual output required')
        receipts = []
        for kind in ['artificial', 'imports']:
            path = base / kind / 'RUN_RECEIPT.json'
            ref = file_pin(path)
            report = decode(path.read_bytes())
            need(report.get('status') == 'PASS_QUALIFIED_PREPARATION' and report.get('qualification_kind') == kind and report.get('frozen_manifest_sha256') == config['manifest'], 'Both fresh local qualifications must pass for this exact manifest')
            receipts.append(ref)
        path = base / 'ACTUAL_GO.json'
        save_new(path, actual_object(config['manifest'], base, deadline, receipts, scope_id))
    print(json.dumps({'request': file_pin(path), 'checker_launched': False, 'saved_evaluations': 0, 'native_calls': 0}))

if __name__ == '__main__':
    main()
