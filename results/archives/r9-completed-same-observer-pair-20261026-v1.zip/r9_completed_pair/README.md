# R9 completed same-observer pair — AG evidence

This package records a completed local intervention at exact B_NEW_POINT_R2404:
the pinned released raw four-fixed-point solver returned false for unchanged
and true after the sole typed S01 SYS-safety release. Both arms used the same
lossless observer and finite limits in fresh processes. RESULT_SUMMARY.json
links the actual native, supervisor, launch, root adoption and saved-output QA.

The earlier AF/v5 false / UNKNOWN experiment remains a separate historical
record. This AG package does not replace it. Cumulative diagnostic-lineage
accounting is seven model attempts/completions, four entered raw calls and
three returned raw calls; no attempt or call slot remains.

Read CLAIM_SUPPORT.json, the independent result REPORT, and the root adoption
before interpreting a Boolean. All 39 recorded native comparisons per arm
pass. The S01 arm's serialized domain and domain_ENV_next bytes differ from
the original gate; the recorded in-model comparisons and metadata establish
the adopted local equality. File digests alone are not semantic BDD equality.

The result does not establish an exclusive cause of historical live GUI
negatives, global raw-region/strict/Kind equivalence, correctness of the full
corrected public pipeline, strategy extraction/transfer, controller deployment,
incidence, or a performance advantage. Timings are observations of these runs.

## Inspecting the supplied evidence

MANIFEST.json enumerates every archive member except itself, by bytes/SHA256.
ORIGINAL_TO_PUBLIC_MAPPING.json distinguishes exact bytes, sanitized bytes,
external runtimes, withheld records and source-restoration inputs. Original
digests in sanitized records still identify the private originals; they are
not digests of rewritten public records. TRANSFORMATIONS.json records each
JSON pointer/text transformation using value digests. The private reviewer
also has the full original/public ledger. Paths use symbolic roots. Process,
account and host identity fields are removed; scientific values, array order,
timings, counts, limits and status values are preserved. Public path equality
does not establish samefile/device/inode identity.

REFERENCE_AVAILABILITY.json states whether each encountered pinned reference
is supplied, restorable, external or only referenced. It does not claim
recursive closure of every historical review. Underlying fixed-input files
are individually classified, including all directory-roster members. Exact
source and class bytes are retained where privacy-safe; changed source bytes
are explicitly labeled. Do not equate sanitized sources with compiled bytes.

## Verification and reproducibility boundary

Run `python3 verify_public_package.py` from an extracted package, or pass its
ZIP path as the only argument. This standard-library checker verifies the
exact roster, bounded member bytes/SHA256 (and ZIP CRC when reading a ZIP),
typed false/true summary, encoded capture schema/count arithmetic and literal
privacy. It imports and executes no scientific source. It never expands
repeated diagnostics or recomputes raw-log SHA256. The 3,641,273,599 raw bytes
were fully checked by the already-completed pinned root QA; those actual
guardian/worker records and code are supplied as evidence. Encoded captures
are byte-exact. Dictionary and literal privacy was inspected without repeats.

SOURCE_INDEX.json retains the ordered classpath, compile receipt, source/class
pins and source diffs. The 164 JARs, complete host runtimes and upstream full
specification bodies are not redistributed. dependencies/DEPENDENCIES.json
retains exact hashes, acquisition provenance, licenses, unresolved license
limits and byte-specific restoration routes from the accepted AF catalog.
The retained-point appendix is supplied exactly. No network fetch or fresh
restoration was performed for AG; URLs are historical acquisition references.
Version strings alone do not replace exact files, classpath order or pins.

The original scientific harness and saved-QA runners bind to private physical
paths and root authorizations. They are inspection evidence, not a supported
relocated command. No fresh-host build/run or relocation adapter was tested.
Scientific execution would require a separate reviewed protocol and budget.
This private prepared package creates no root adoption, binder update,
external release or permission to rerun the experiment.
