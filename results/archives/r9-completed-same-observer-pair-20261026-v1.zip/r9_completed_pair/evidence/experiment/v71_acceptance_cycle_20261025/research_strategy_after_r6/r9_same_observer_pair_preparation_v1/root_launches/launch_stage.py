"""Root-only launcher: record the exact reviewed outer argv, without a shell."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time


def pin(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def require(condition, message):
    if not condition:
        raise ValueError(message)


parser = argparse.ArgumentParser()
parser.add_argument("stage")
parser.add_argument("--authorization", required=True)
parser.add_argument("--authorization-sha256", required=True)
parser.add_argument("--plan-sha256", required=True)
parser.add_argument("--freeze-sha256", required=True)
args = parser.parse_args()
receipts = Path(__file__).resolve().parent
preparation = receipts.parent
plan_path = preparation / "PLAN.json"
freeze_path = preparation / "INPUT_FREEZE.json"
authorization = Path(args.authorization).resolve(strict=True)
require(pin(plan_path)["sha256"] == args.plan_sha256, "Plan hash differs")
require(pin(freeze_path)["sha256"] == args.freeze_sha256, "Freeze hash differs")
require(pin(authorization)["sha256"] == args.authorization_sha256, "Authorization hash differs")
plan = json.loads(plan_path.read_text())
allowed = {"solve_unchanged", "solve_S01_release"}
auth = json.loads(authorization.read_text())
require(plan.get("schema") == "v71-r9-distinct-pair-plan-v1", "Distinct R9 plan required")
require(auth.get("schema") == "v71-r9-distinct-pair-root-authorization-v1" and auth.get("status") == "GO_DISTINCT_PAIR_SOLVES_ONLY", "Distinct current R9 GO required")
require(auth.get("authorized_stages") == ["solve_unchanged", "solve_S01_release"], "Exactly the fresh pair required")
require(args.stage in allowed and args.stage in plan["stages"], "Unrecognized stage")
require(not (preparation / "runs" / args.stage).exists(), "Stage already has a run directory")
record_path = receipts / (args.stage + "_LAUNCH.json")
require(not record_path.exists(), "Stage already has a launch receipt")
argv = plan["supervisor_launch_prefix"] + [args.stage, "--authorization", str(authorization), "--authorization-sha256", args.authorization_sha256]
require(argv[:2] == ["/usr/bin/env", "-i"], "Clean outer environment prefix required")
record = {
    "schema": "v71-r7-root-actual-stage-launch-v1",
    "protocol_identity": "v71-r9-distinct-same-observer-exact-B-pair-v1",
    "stage": args.stage, "status": "PREPARED_TO_SPAWN", "started_utc": now(),
    "cwd": str(preparation), "actual_outer_argv": argv, "outer_command_uses_shell": False,
    "declared_effective_outer_environment": plan["supervisor_environment"],
    "authorization": pin(authorization), "plan": pin(plan_path), "input_freeze": pin(freeze_path),
    "root_launcher": pin(Path(__file__).resolve()),
}
with record_path.open("x") as output:
    output.write(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
stdout_path = receipts / (args.stage + "_outer_stdout.txt")
stderr_path = receipts / (args.stage + "_outer_stderr.txt")
start = time.monotonic()
try:
    with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
        process = subprocess.Popen(argv, cwd=preparation, shell=False, stdout=stdout, stderr=stderr)
        record["outer_pid"] = process.pid
        record["status"] = "OUTER_PROCESS_RUNNING"
        record_path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
        code = process.wait()
    record.update(status="OUTER_PROCESS_EXITED", outer_return_code=code)
except BaseException as error:
    record.update(status="ROOT_LAUNCHER_EXCEPTION", exception_type=type(error).__name__, exception=str(error))
    raise
finally:
    record.update(finished_utc=now(), outer_elapsed_seconds=time.monotonic() - start)
    for key, path in (("stdout", stdout_path), ("stderr", stderr_path)):
        if path.exists():
            record[key] = pin(path)
    record_path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"stage": args.stage, "outer_return_code": code, "receipt": pin(record_path)}, ensure_ascii=False))
sys.exit(code)
