import java.nio.file.*;
import java.util.*;
import com.google.gson.*;

/** New authority around unchanged historical guards. Administrative I/O only. */
final class AdoptedV5Evidence {
  static final String PROTOCOL="v71-r9-distinct-same-observer-exact-B-pair-v1";
  static final long RAW_CAP=68719476736L, ENCODED_CAP=67108864L;
  static final Set<String> STAGES=new HashSet<>(Arrays.asList("solve_unchanged","solve_S01_release"));
  static void need(boolean ok,String label){PriorGateEvidence.need(ok,label);}
  static JsonObject read(Path p)throws Exception{return PriorGateEvidence.read(p);}
  static JsonObject object(JsonObject pin)throws Exception{return PriorGateEvidence.object(pin);}
  static void match(JsonObject a,JsonObject b,String label)throws Exception{PriorGateEvidence.match(a,b,label);}
  static void at(JsonObject pin,Path path,String label)throws Exception{PriorGateEvidence.at(pin,path,label);}
  static boolean number(JsonObject x,String key,long value){
    return x.has(key)&&x.get(key).isJsonPrimitive()&&x.getAsJsonPrimitive(key).isNumber()
      &&x.get(key).getAsString().equals(Long.toString(value));
  }
  static boolean yes(JsonObject x,String key){return PriorGateEvidence.yes(x,key);}
  static boolean no(JsonObject x,String key){return PriorGateEvidence.no(x,key);}
  static long boundedCounter(JsonObject x,String key,long maximum){
    need(x.has(key)&&x.get(key).isJsonPrimitive()&&x.getAsJsonPrimitive(key).isNumber(),"Integer capture counter "+key);
    String text=x.get(key).getAsString();need(text.matches("0|[1-9][0-9]{0,18}"),"Nonnegative canonical integer "+key);
    long value=Long.parseLong(text);need(value<=maximum,"Finite capture counter bound "+key);return value;
  }
  static JsonObject pin(Path p)throws Exception{return ExactBSameSolverDiagnostic.obj(ExactBSameSolverDiagnostic.pin(p));}
  static void historicalBudget(JsonObject finalAdoption){
    JsonObject h=finalAdoption.getAsJsonObject("history_budget");
    String[] keys={"total_models","model_limit","raw_calls_entered","raw_call_limit","raw_calls_returned","remaining_model_budget","remaining_raw_call_budget","retries_authorized"};
    long[] values={5,5,2,2,1,0,0,0};
    for(int i=0;i<keys.length;i++)need(number(h,keys[i],values[i]),"Exhausted historical budget "+keys[i]);
    need(no(h,"cap_increase_authorized")&&no(finalAdoption,"further_scientific_execution_authorized")
      &&no(finalAdoption,"retry_or_cap_change_authorized"),"Old authority remains exhausted");
  }
  static void currentPlan(JsonObject p){
    need(p.get("schema").getAsString().equals("v71-r9-distinct-pair-plan-v1")
      &&p.get("protocol_identity").getAsString().equals(PROTOCOL),"Distinct R9 plan identity");
    need(p.getAsJsonObject("stages").keySet().equals(STAGES),"Only two fresh solve stages");
    JsonArray order=p.getAsJsonArray("order");
    need(order.size()==2&&order.get(0).getAsString().equals("solve_unchanged")
      &&order.get(1).getAsString().equals("solve_S01_release"),"Fixed fresh pair order");
    need(number(p,"maximum_stage_attempts",1)&&number(p,"maximum_concurrency",1)
      &&number(p,"historical_model_generations",5)&&number(p,"historical_raw_four_fixed_point_calls",2)
      &&number(p,"historical_raw_four_fixed_point_calls_returned",1)
      &&number(p,"maximum_future_model_attempts",2)&&number(p,"maximum_model_attempts_per_arm",1)
      &&number(p,"maximum_raw_call_entries_per_arm",1)&&number(p,"retries",0)
      &&number(p,"maximum_future_model_generations",2)&&number(p,"maximum_future_raw_four_fixed_point_calls",2)
      &&number(p,"maximum_total_model_generations_including_preliminary",7)
      &&number(p,"maximum_total_raw_four_fixed_point_calls",4)
      &&number(p,"maximum_new_gate_only_model_generations",0)&&number(p,"maximum_new_cross_replays",0),
      "Distinct additional budget, no historical extension or gate replay");
    JsonObject c=p.getAsJsonObject("capture_limits");
    need(number(c,"raw_stdout_observed_bytes",RAW_CAP)&&number(c,"encoded_stdout_bytes",ENCODED_CAP)
      &&number(c,"stderr_bytes",ENCODED_CAP),"One finite observer envelope for both arms");
  }
  static JsonObject adoption(JsonObject auth,JsonObject authPin,Path root,String stage)throws Exception{
    need(object(authPin).equals(auth),"Exact current authorization bytes and physical pin");
    need(auth.get("schema").getAsString().equals("v71-r9-distinct-pair-root-authorization-v1")
      &&auth.get("status").getAsString().equals("GO_DISTINCT_PAIR_SOLVES_ONLY")
      &&auth.get("protocol_identity").getAsString().equals(PROTOCOL),"Current distinct R9 execution authority");
    JsonObject plan=object(auth.getAsJsonObject("plan"));currentPlan(plan);
    need(object(auth.getAsJsonObject("input_freeze")).get("schema").getAsString()
      .equals("v71-r9-distinct-pair-input-freeze-v1"),"Current distinct R9 freeze");
    JsonObject bridgePin=auth.getAsJsonObject("adopted_v5_evidence");
    at(bridgePin,root.resolve("ADOPTED_V5_EVIDENCE.json"),"Current local bridge descriptor");
    match(bridgePin,plan.getAsJsonObject("adopted_v5_evidence"),"Current plan bridge");
    JsonObject b=object(bridgePin);
    need(b.get("schema").getAsString().equals("v71-r9-adopted-v5-evidence-v1")
      &&b.get("status").getAsString().equals("FROZEN_HISTORICAL_V5_EVIDENCE_NOT_EXECUTION_AUTHORITY")
      &&b.get("protocol_identity").getAsString().equals(PROTOCOL),"Historical-only v5 bridge");
    Path old=PriorGateEvidence.canonical(Paths.get(b.get("historical_root").getAsString()),true);
    need(Files.isSameFile(old,root.getParent().resolve("same_solver_diagnostic_preparation_saved_cross_v5"))
      &&!Files.isSameFile(old,root),"Fixed distinct original v5 root");
    String[] historicalKeys={"historical_plan","historical_input_freeze","historical_prior_gate_bundle"};
    String[] historicalNames={"PLAN.json","INPUT_FREEZE.json","PRIOR_GATE_BUNDLE.json"};
    for(int i=0;i<historicalKeys.length;i++)at(b.getAsJsonObject(historicalKeys[i]),old.resolve(historicalNames[i]),"Original v5 "+historicalKeys[i]);
    String[] rootKeys={"historical_gate_adoption","historical_solve_authorization","historical_final_scientific_adoption"};
    String[] rootNames={"ROOT_V5_PRIOR_GATES_AND_CROSS_ADOPTION.json","ROOT_V5_SOLVE_ONLY_AUTHORIZATION.json","ROOT_V5_FINAL_SCIENTIFIC_RESULT_ADOPTION.json"};
    for(int i=0;i<rootKeys.length;i++)at(b.getAsJsonObject(rootKeys[i]),root.getParent().resolve("root_review_integration").resolve(rootNames[i]),"Actual historical root record");
    match(b.getAsJsonObject("preparation_decision"),plan.getAsJsonObject("preparation_decision"),"Original preparation decision");
    match(b.getAsJsonObject("raw_observation_amendment"),plan.getAsJsonObject("raw_observation_amendment"),"Preparation amendment");
    JsonObject decision=object(b.getAsJsonObject("preparation_decision"));
    need(decision.get("protocol_identity").getAsString().equals(PROTOCOL)&&no(decision,"scientific_execution_authorized")
      &&no(decision,"old_budget_extended"),"Original preparation is not execution GO");
    JsonObject envelope=decision.getAsJsonObject("planned_envelope_not_execution_GO");
    need(number(envelope,"raw_stdout_observed_bytes",1073741824L)&&number(envelope,"encoded_stdout_bytes",ENCODED_CAP)
      &&number(envelope,"max_additional_model_attempts",2)&&number(envelope,"max_additional_entered_raw_calls",2)
      &&number(envelope,"new_gate_only_model_or_cross_replay_budget",0),"Original preparation envelope retained");
    JsonObject amendment=object(b.getAsJsonObject("raw_observation_amendment"));
    need(amendment.get("schema").getAsString().equals("v71-r9-distinct-pair-preexecution-observation-amendment-v1")
      &&amendment.get("status").getAsString().equals("AMEND_PREPARATION_ONLY_NOT_SCIENTIFIC_GO")
      &&no(amendment,"scientific_execution_authorized")&&yes(amendment,"all_other_envelope_fields_unchanged"),
      "Explicit preparation-only finite observation amendment");
    match(amendment.getAsJsonObject("amends"),b.getAsJsonObject("preparation_decision"),"Amended exact original decision");
    JsonObject change=amendment.getAsJsonObject("only_envelope_change");JsonArray arms=change.getAsJsonArray("applies_identically_to");
    need(change.get("field").getAsString().equals("raw_stdout_observed_bytes")&&number(change,"previous",1073741824L)
      &&number(change,"new",RAW_CAP)&&change.get("units").getAsString().equals("bytes per arm")&&arms.size()==2
      &&arms.get(0).getAsString().equals("unchanged")&&arms.get(1).getAsString().equals("S01_release"),
      "Only raw-observed cap amended identically for both arms");
    JsonObject oldAuth=object(b.getAsJsonObject("historical_solve_authorization"));
    need(oldAuth.get("schema").getAsString().equals("v71-r7-v5-root-authorization-v1")
      &&oldAuth.get("status").getAsString().equals("GO_SOLVE_STAGES_ONLY"),"Historical GO only as evidence");
    String[] authKeys={"plan","input_freeze","prior_gate_bundle","gate_adoption"};
    String[] bridgeKeys={"historical_plan","historical_input_freeze","historical_prior_gate_bundle","historical_gate_adoption"};
    for(int i=0;i<authKeys.length;i++)match(oldAuth.getAsJsonObject(authKeys[i]),b.getAsJsonObject(bridgeKeys[i]),"Historical GO binding");
    // No execution authorization is obtained here: old validators receive the
    // actual historical root/plan/GO and inspect only immutable saved evidence.
    JsonObject oldAdoption=PriorGateEvidence.adoption(oldAuth,old);
    JsonObject prior=object(b.getAsJsonObject("historical_prior_gate_bundle"));
    Path originalConfig=PriorGateEvidence.pinned(prior.getAsJsonObject("source_config"));
    Path newConfig=PriorGateEvidence.canonical(root.resolve("B_CONFIG.json"),false);
    need(!Files.isSameFile(originalConfig,newConfig)
      &&Arrays.equals(Files.readAllBytes(originalConfig),Files.readAllBytes(newConfig)),
      "New R9 config is distinct and exact original bytes");
    at(plan.getAsJsonObject("config"),newConfig,"Current exact config pin");
    match(auth.getAsJsonObject("prior_gate_bundle"),b.getAsJsonObject("historical_prior_gate_bundle"),"Original prior bundle in place");
    JsonObject finalAdoption=object(b.getAsJsonObject("historical_final_scientific_adoption"));
    need(finalAdoption.get("schema").getAsString().equals("v71-r7-v5-root-final-scientific-result-adoption-v1")
      &&finalAdoption.get("status").getAsString().equals("ADOPT_BOUNDED_FALSE_AND_UNKNOWN_DIAGNOSTIC_EVIDENCE"),
      "Actual historical limited final adoption");
    String[] finalKeys={"plan","input_freeze","prior_gate_bundle","gate_adoption","solve_authorization"};
    String[] finalBridgeKeys={"historical_plan","historical_input_freeze","historical_prior_gate_bundle","historical_gate_adoption","historical_solve_authorization"};
    for(int i=0;i<finalKeys.length;i++)match(finalAdoption.getAsJsonObject(finalKeys[i]),b.getAsJsonObject(finalBridgeKeys[i]),"Historical final adoption binding");
    historicalBudget(finalAdoption);
    JsonObject oldPlan=object(b.getAsJsonObject("historical_plan"));
    for(String s:STAGES)need(plan.getAsJsonObject("stages").getAsJsonObject(s).getAsJsonObject("limits")
      .equals(oldPlan.getAsJsonObject("stages").getAsJsonObject(s).getAsJsonObject("limits")),"All outer solve limits unchanged");
    JsonObject current=object(auth.getAsJsonObject("gate_adoption"));
    need(current.get("schema").getAsString().equals("v71-r9-adopted-v5-gates-for-pair-v1")
      &&current.get("status").getAsString().equals("ADOPT_V5_EVIDENCE_FOR_R9_PAIR"),"New root R9 adoption required");
    for(String key:new String[]{"plan","input_freeze","prior_gate_bundle","adopted_v5_evidence"})
      match(current.getAsJsonObject(key),auth.getAsJsonObject(key),"New adoption current "+key);
    for(String key:new String[]{"historical_gate_adoption","historical_final_scientific_adoption"})
      match(current.getAsJsonObject(key),b.getAsJsonObject(key),"New adoption exact actual "+key);
    JsonObject gates=current.getAsJsonObject("gate_results");need(gates.keySet().equals(PriorGateEvidence.ARMS),"Exactly original two native gates");
    for(String gate:PriorGateEvidence.ARMS)match(gates.getAsJsonObject(gate),oldAdoption.getAsJsonObject("gate_results").getAsJsonObject(gate),"Only original adopted gate comparison target");
    need(current.getAsJsonArray("qa_evidence").size()>0,"Independent new R9 preexecution audit required");
    for(JsonElement q:current.getAsJsonArray("qa_evidence"))PriorGateEvidence.pinned(q.getAsJsonObject());
    if(stage.equals("solve_S01_release"))completedFirst(auth,authPin,root,plan);
    return current;
  }
  static void completedFirst(JsonObject auth,JsonObject authPin,Path root,JsonObject plan)throws Exception{
    String first="solve_unchanged";Path folder=root.resolve("runs").resolve(first);
    JsonObject s=read(PriorGateEvidence.canonical(folder.resolve("SUPERVISOR_RESULT.json"),false));
    PriorGateEvidence.complete(s,first);
    need(s.get("protocol_identity").getAsString().equals(PROTOCOL),"Fresh first current protocol");
    for(String key:new String[]{"plan","input_freeze","prior_gate_bundle","adopted_v5_evidence"})
      match(s.getAsJsonObject(key),auth.getAsJsonObject(key),"Fresh first current "+key);
    match(s.getAsJsonObject("authorization"),authPin,"Fresh first exact same GO physical file and bytes");
    JsonObject actualAuth=object(s.getAsJsonObject("authorization"));need(actualAuth.equals(auth),"Fresh first exact same GO object");
    JsonObject n=object(s.getAsJsonObject("native_result"));
    at(s.getAsJsonObject("native_result"),folder.resolve("native_result/RESULT.json"),"Fresh first actual native path");
    for(Map.Entry<String,JsonElement> required:plan.getAsJsonObject("stages").getAsJsonObject(first).getAsJsonObject("required_result_fields").entrySet())
      need(PriorGateEvidence.field(n,required.getKey()).equals(required.getValue()),"Fresh first required "+required.getKey());
    need(n.has("realizable")&&n.get("realizable").isJsonPrimitive()&&n.getAsJsonPrimitive("realizable").isBoolean(),"Fresh first returned Boolean of either value");
    match(n.getAsJsonObject("authorization"),s.getAsJsonObject("authorization"),"Fresh first native actual GO");
    match(n.getAsJsonObject("config"),plan.getAsJsonObject("config"),"Fresh first exact B config");
    match(n.getAsJsonObject("gate_adoption"),auth.getAsJsonObject("gate_adoption"),"Fresh first same R9 adoption");
    at(n.getAsJsonObject("capture_receipt"),folder.resolve("native_result/CAPTURE_RECEIPT.json"),"Fresh first actual native capture");
    JsonObject capture=object(n.getAsJsonObject("capture_receipt"));
    need(yes(capture,"capture_complete")&&no(capture,"cap_reached")&&capture.get("capture_error").isJsonNull()
      &&number(capture,"unflushed_repeated_lines",0)&&number(capture,"raw_cap_bytes",RAW_CAP)
      &&number(capture,"encoded_cap_bytes",ENCODED_CAP),"Fresh first complete capture under same finite observer");
    boundedCounter(capture,"raw_bytes",RAW_CAP);boundedCounter(capture,"encoded_bytes",ENCODED_CAP);
    boundedCounter(capture,"repeated_lines",RAW_CAP/54L);boundedCounter(capture,"records",ENCODED_CAP);
    for(String key:new String[]{"harness_class","capture_class"})
      need(n.getAsJsonObject(key).get("class_sha256").equals(plan.getAsJsonObject("expected_class_sha256").get(key)),"Fresh first exact harness/observer bytes");
    String[] events={"GENERATE_ONE_MODEL","ONE_MODEL_GENERATION_RETURNED","ONE_RAW_FOUR_FP_CALL_BEGIN","ONE_RAW_FOUR_FP_CALL_RETURNED"};
    int previous=-1;JsonArray recorded=n.getAsJsonArray("stage_events");
    for(String event:events){int count=0,position=-1;for(int i=0;i<recorded.size();i++)if(recorded.get(i).getAsJsonObject().get("stage").getAsString().equals(event)){count++;position=i;}need(count==1&&position>previous,"Fresh first generation/call event sequence");previous=position;}
    PriorGateEvidence.target(s,plan,first,s.getAsJsonObject("authorization"));
    PriorGateEvidence.manifest(s.getAsJsonObject("output_manifest"),folder,first);
    Path launchPath=Paths.get(plan.getAsJsonObject("root_launch_receipts").get(first).getAsString());
    need(Files.isSameFile(launchPath,root.resolve("root_launches/solve_unchanged_LAUNCH.json")),"Fresh first exact root receipt path");
    JsonObject launchPin=pin(launchPath),launch=object(launchPin);
    match(launch.getAsJsonObject("root_launcher"),plan.getAsJsonObject("root_launcher"),"Fresh first current launcher bytes");
    PriorGateEvidence.launch(launchPin,first,plan,auth.getAsJsonObject("plan"),auth.getAsJsonObject("input_freeze"),s.getAsJsonObject("authorization"),root,0);
  }
}
