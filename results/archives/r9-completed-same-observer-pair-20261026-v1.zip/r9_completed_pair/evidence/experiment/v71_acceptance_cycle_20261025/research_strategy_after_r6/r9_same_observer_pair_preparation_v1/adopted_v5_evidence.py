"""R9 authority bridge to immutable adopted v5 evidence; administrative I/O only.

The historical validators are unchanged. Their old context never authorizes
current execution. No model, BDD, predicate replay or scientific class runs here.
"""
import hashlib
from pathlib import Path

import path_identity as identity
import prior_gate_evidence as legacy

PROTOCOL = "v71-r9-distinct-same-observer-exact-B-pair-v1"
PLAN_SCHEMA = "v71-r9-distinct-pair-plan-v1"
FREEZE_SCHEMA = "v71-r9-distinct-pair-input-freeze-v1"
AUTH_SCHEMA = "v71-r9-distinct-pair-root-authorization-v1"
ADOPTION_SCHEMA = "v71-r9-adopted-v5-gates-for-pair-v1"
STAGES = ("solve_unchanged", "solve_S01_release")
RAW_CAP = 68719476736
ENCODED_CAP = 67108864


def historical(bridge_pin, root, plan, frozen, read, check, need, roster):
    need(identity.same_file(check(bridge_pin), root / "ADOPTED_V5_EVIDENCE.json"),
         "R9 bridge belongs to this preparation")
    bridge = read(check(bridge_pin))
    need(bridge.get("schema") == "v71-r9-adopted-v5-evidence-v1" and
         bridge.get("status") == "FROZEN_HISTORICAL_V5_EVIDENCE_NOT_EXECUTION_AUTHORITY" and
         bridge.get("protocol_identity") == PROTOCOL, "Explicit historical-only bridge")
    old = identity.canonical_directory(bridge["historical_root"])
    need(identity.same_directory(old, root.parent / "same_solver_diagnostic_preparation_saved_cross_v5") and
         not identity.same_directory(old, root), "Fixed distinct historical v5 root")
    for key, name in (("historical_plan", "PLAN.json"), ("historical_input_freeze", "INPUT_FREEZE.json"),
                      ("historical_prior_gate_bundle", "PRIOR_GATE_BUNDLE.json")):
        need(identity.same_file(check(bridge[key]), old / name), "Historical in-place " + key)
    for key, name in (("historical_gate_adoption", "ROOT_V5_PRIOR_GATES_AND_CROSS_ADOPTION.json"),
                      ("historical_solve_authorization", "ROOT_V5_SOLVE_ONLY_AUTHORIZATION.json"),
                      ("historical_final_scientific_adoption", "ROOT_V5_FINAL_SCIENTIFIC_RESULT_ADOPTION.json")):
        need(identity.same_file(check(bridge[key]), root.parent / "root_review_integration" / name),
             "Actual root historical record " + key)
    legacy.match(bridge["preparation_decision"], plan["preparation_decision"], check, need,
                 "R9 preparation decision binding")
    decision = read(check(bridge["preparation_decision"]))
    need(decision.get("protocol_identity") == PROTOCOL and
         decision.get("scientific_execution_authorized") is False and
         decision.get("old_budget_extended") is False, "Preparation is not execution authority")
    envelope = decision["planned_envelope_not_execution_GO"]
    need(envelope["arms_in_order"] == ["unchanged", "S01_release"] and
         envelope["max_additional_model_attempts"] == 2 and
         envelope["max_additional_entered_raw_calls"] == 2 and
         envelope["new_gate_only_model_or_cross_replay_budget"] == 0,
         "Root fixed new pair budget")
    need(envelope["raw_stdout_observed_bytes"] == 1073741824 and
         envelope["encoded_stdout_bytes"] == ENCODED_CAP, "Original preparation capture bounds retained")
    legacy.match(bridge["raw_observation_amendment"], plan["raw_observation_amendment"],
                 check, need, "R9 preparation amendment binding")
    amendment = read(check(bridge["raw_observation_amendment"]))
    need(amendment.get("schema") == "v71-r9-distinct-pair-preexecution-observation-amendment-v1" and
         amendment.get("status") == "AMEND_PREPARATION_ONLY_NOT_SCIENTIFIC_GO" and
         amendment.get("scientific_execution_authorized") is False and
         amendment.get("all_other_envelope_fields_unchanged") is True,
         "Explicit preparation-only raw observation amendment")
    legacy.match(amendment["amends"], bridge["preparation_decision"], check, need,
                 "Amendment binds exact original preparation decision")
    need(legacy.strict(amendment["only_envelope_change"], {
        "field": "raw_stdout_observed_bytes", "previous": 1073741824, "new": RAW_CAP,
        "units": "bytes per arm", "applies_identically_to": ["unchanged", "S01_release"]}),
        "Only finite raw-observation cap changed identically for both arms")
    old_plan = read(check(bridge["historical_plan"]))
    old_freeze = read(check(bridge["historical_input_freeze"]))
    old_auth = read(check(bridge["historical_solve_authorization"]))
    old_adoption = read(check(bridge["historical_gate_adoption"]))
    need(old_plan.get("schema") == "v71-r7-v5-three-stage-plan-v1" and
         old_freeze.get("schema") == "v71-r7-v5-input-freeze-v1", "Actual historical v5 schemas")
    need(old_auth.get("schema") == "v71-r7-v5-root-authorization-v1" and
         old_auth.get("status") == "GO_SOLVE_STAGES_ONLY" and
         old_auth.get("authorized_stages") == list(STAGES), "Historical solve GO retained only as data")
    for key, historical_key in (("plan", "historical_plan"), ("input_freeze", "historical_input_freeze"),
                                ("prior_gate_bundle", "historical_prior_gate_bundle"),
                                ("gate_adoption", "historical_gate_adoption")):
        legacy.match(old_auth[key], bridge[historical_key], check, need, "Historical GO " + key)
    # Require the whole old frozen input set in the already-verified new freeze.
    old_members = list(old_freeze["files"])
    for directory in old_freeze["directories"]:
        folder = identity.canonical_directory(directory["path"])
        rows = []
        for row in directory["files"]:
            rel = row["relative_path"]
            need(isinstance(rel, str) and rel and not rel.startswith("/") and
                 all(x not in ("", ".", "..") for x in rel.split("/")), "Safe historical roster member")
            rows.append({"path": str(folder / rel), "bytes": row["bytes"], "sha256": row["sha256"]})
        need({identity.file_key(p) for p in roster(folder)} ==
             {identity.file_key(p["path"]) for p in rows}, "Unchanged historical v5 directory roster")
        old_members.extend(rows)
    for item in old_members:
        key = identity.file_key(item["path"])
        need(key in frozen and identity.same_file_pin(item, frozen[key]), "Historical frozen member retained")
    current_config = {"path": str(root / "B_CONFIG.json"),
                      "bytes": (root / "B_CONFIG.json").stat().st_size,
                      "sha256": plan["config"]["sha256"]}
    legacy.match(current_config, plan["config"], check, need, "R9 fixed config")
    # New config is compared directly with original v4 exact bytes, while all
    # prior receipt paths and adoption checks remain in their historical context.
    bundle = legacy.prior_bundle(bridge["historical_prior_gate_bundle"], old, current_config,
                                 frozen, read, check, need, roster)
    need(old_adoption.get("schema") == "v71-r7-v5-reused-gates-adoption-v1" and
         old_adoption.get("status") == "ADOPT_PRIOR_ARM_GATES_AND_SAVED_REVALIDATION",
         "Actual historical gate adoption")
    for key in ("plan", "input_freeze", "prior_gate_bundle"):
        legacy.match(old_adoption[key], old_auth[key], check, need, "Historical adoption " + key)
    need(set(old_adoption["gate_results"]) == set(legacy.ARMS), "Exactly original two native gates")
    for stage in legacy.ARMS:
        legacy.match(old_adoption["gate_results"][stage], bundle["gates"][stage]["native_result"],
                     check, need, "Historical original gate " + stage)
    legacy.revalidation(old_adoption["revalidation"], old_auth, old_plan, bundle, old,
                        read, check, need, roster)
    need(old_adoption.get("qa_evidence"), "Historical independent full cross QA")
    for value in old_adoption["qa_evidence"]:
        check(value)
    final = read(check(bridge["historical_final_scientific_adoption"]))
    need(final.get("schema") == "v71-r7-v5-root-final-scientific-result-adoption-v1" and
         final.get("status") == "ADOPT_BOUNDED_FALSE_AND_UNKNOWN_DIAGNOSTIC_EVIDENCE",
         "Historical final limited scientific adoption")
    for key, historical_key in (("plan", "historical_plan"), ("input_freeze", "historical_input_freeze"),
                                ("prior_gate_bundle", "historical_prior_gate_bundle"),
                                ("gate_adoption", "historical_gate_adoption"),
                                ("solve_authorization", "historical_solve_authorization")):
        legacy.match(final[key], bridge[historical_key], check, need, "Final historical adoption " + key)
    budget = final["history_budget"]
    for key, expected in (("total_models", 5), ("model_limit", 5), ("raw_calls_entered", 2),
                          ("raw_call_limit", 2), ("raw_calls_returned", 1),
                          ("remaining_model_budget", 0), ("remaining_raw_call_budget", 0),
                          ("retries_authorized", 0)):
        need(type(budget.get(key)) is int and budget[key] == expected, "Exhausted historical budget " + key)
    need(budget.get("cap_increase_authorized") is False and
         final.get("further_scientific_execution_authorized") is False and
         final.get("retry_or_cap_change_authorized") is False, "Old authority exhausted")
    for stage in STAGES:
        need(legacy.strict(plan["stages"][stage]["limits"], old_plan["stages"][stage]["limits"]),
             "All outer per-solve limits unchanged")
    return bridge, bundle, old_adoption


def adoption(value, auth, root, plan, frozen, read, check, need, roster):
    current = read(check(value))
    need(current.get("schema") == ADOPTION_SCHEMA and
         current.get("status") == "ADOPT_V5_EVIDENCE_FOR_R9_PAIR", "Separate explicit R9 adoption")
    for key in ("plan", "input_freeze", "prior_gate_bundle", "adopted_v5_evidence"):
        legacy.match(current[key], auth[key], check, need, "R9 adoption binds current " + key)
    bridge, bundle, old_adoption = historical(auth["adopted_v5_evidence"], root, plan,
                                              frozen, read, check, need, roster)
    legacy.match(auth["prior_gate_bundle"], bridge["historical_prior_gate_bundle"], check, need,
                 "R9 names original historical bundle in place")
    for key in ("historical_gate_adoption", "historical_final_scientific_adoption"):
        legacy.match(current[key], bridge[key], check, need, "R9 adopts exact actual " + key)
    need(isinstance(current.get("gate_results"), dict) and set(current["gate_results"]) == set(legacy.ARMS),
         "R9 uses exactly the original native gate roster")
    for stage in legacy.ARMS:
        legacy.match(current["gate_results"][stage], old_adoption["gate_results"][stage],
                     check, need, "R9 original adopted gate " + stage)
    need(isinstance(current.get("qa_evidence"), list) and bool(current["qa_evidence"]),
         "Independent R9 preexecution audit required")
    for item in current["qa_evidence"]:
        check(item)
    return current


def completed_first(state, result, auth_pin, auth, plan, root, read, check, need):
    """The current completed control is a dependency, regardless of its Boolean."""
    for key in ("plan", "input_freeze", "prior_gate_bundle", "adopted_v5_evidence"):
        legacy.match(state[key], auth[key], check, need, "Fresh first arm current " + key)
    legacy.match(state["authorization"], auth_pin, check, need, "Fresh first arm same pair GO")
    legacy.match(result["authorization"], auth_pin, check, need, "Fresh first native same pair GO")
    legacy.match(result["config"], plan["config"], check, need, "Fresh first native exact config")
    legacy.match(result["gate_adoption"], auth["gate_adoption"], check, need, "Fresh first native R9 adoption")
    need(type(result.get("realizable")) is bool, "First arm has an actual Boolean of either value")
    need(state.get("protocol_identity") == PROTOCOL, "Fresh first arm current protocol identity")
    capture = read(check(result["capture_receipt"]))
    need(identity.same_file(check(result["capture_receipt"]),
                            root / "runs/solve_unchanged/native_result/CAPTURE_RECEIPT.json"),
         "Fresh first native capture receipt path")
    need(capture.get("capture_complete") is True and capture.get("cap_reached") is False and
         capture.get("capture_error") is None and capture.get("unflushed_repeated_lines") == 0 and
         capture.get("raw_cap_bytes") == RAW_CAP and capture.get("encoded_cap_bytes") == ENCODED_CAP,
         "Fresh first complete native capture at same observer limits")
    for key in ("harness_class", "capture_class"):
        need(result[key]["class_sha256"] == plan["expected_class_sha256"][key],
             "Fresh first exact observer/harness identity")
    item = plan["stages"]["solve_unchanged"]
    expected_argv = [auth_pin["path"] if x == "{authorization_path}" else
                     auth_pin["sha256"] if x == "{authorization_sha256}" else x for x in item["argv"]]
    need(legacy.strict(state["target_argv"], expected_argv) and
         legacy.strict(state["environment"], item["env"]) and
         legacy.strict(state["limits"], item["limits"]), "Fresh first target/environment/limits")
    launch_pin = plan["root_launch_receipts"]["solve_unchanged"]
    need(identity.same_file(launch_pin, root / "root_launches/solve_unchanged_LAUNCH.json"),
         "Fresh first exact root receipt path")
    actual = read(launch_pin)
    # Historical launch() intentionally keeps its old schema behavior; bind
    # both current paths explicitly before using its common receipt checks.
    need(identity.same_file(check(actual["root_launcher"]), check(plan["root_launcher"])),
         "Fresh first exact root launcher")
    # A completed outer launch is created after the supervisor exits; it cannot
    # be circularly pinned by that supervisor. Pin its actual file now.
    raw = Path(launch_pin).read_bytes()
    value = {"path": launch_pin, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    legacy.launch(value, "solve_unchanged", plan, auth["plan"], auth["input_freeze"], auth_pin,
                  root, 0, read, check, need)
