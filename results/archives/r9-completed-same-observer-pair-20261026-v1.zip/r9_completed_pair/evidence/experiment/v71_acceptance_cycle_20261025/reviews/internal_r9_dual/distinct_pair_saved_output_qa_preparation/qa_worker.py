"""One finite saved-data worker. Invoked only by qa_runner.py after root review."""
from pathlib import Path
import hashlib
import json
import os
import sys

sys.path.insert(0, str(Path(__file__).absolute().parent))
from capture_qa import Budget, QAError, need, ordinary_file, strict_json
from saved_stage_qa import HERE, request_header, run


def main():
    budget = Budget()
    need(len(sys.argv) == 4, "worker fixed arguments")
    auth_path, expected_hash, output = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
    need(output.parent.samefile(HERE / "executions") and output.name in ("solve_unchanged", "solve_S01_release"),
         "fixed worker output path")
    path, info = ordinary_file(auth_path)
    need(info.st_size <= 1_048_576, "QA authorization size")
    data = path.read_bytes()
    need(len(data) == info.st_size and hashlib.sha256(data).hexdigest() == expected_hash,
         "exact root QA authorization")
    request = strict_json(data)
    request_header(request)
    need(Path(request["output_directory"]).samefile(output) and output.name == request["stage"],
         "fixed authorized worker output")
    result = None
    code = 2
    try:
        result = run(request, budget)
        budget.check()
        code = 0
    except BaseException as error:
        result = {"schema": "v71-r9-saved-capture-administrative-qa-result-v1",
                  "status": "FAILED_OR_INCOMPLETE_QA", "error_type": type(error).__name__,
                  "error": str(error)[:4096], "scientific_adoption_permitted": False,
                  "scientific_outcome": "UNKNOWN_OR_UNVERIFIED"}
    result["qa_resources"] = budget.report()
    result["qa_authorization"] = {"path": str(path), "bytes": len(data), "sha256": expected_hash}
    encoded = (json.dumps(result, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    need(len(encoded) <= 1_048_576, "QA result size")
    with (output / "WORKER_RESULT.json").open("xb") as stream:
        stream.write(encoded); stream.flush(); os.fsync(stream.fileno())
    return code


if __name__ == "__main__":
    raise SystemExit(main())
