"""Read-only administrative/result/descriptor QA; no raw expansion or BDD work."""
from pathlib import Path
import datetime as dt
from decimal import Decimal
import hashlib
import json
import os
import re
import stat
import urllib.parse
import zipfile

A=Path(__file__).resolve().parent;O=A.parents[2];S=O/'research_strategy_after_r6'
P=S/'r9_same_observer_pair_preparation_v1';OLD=S/'same_solver_diagnostic_preparation_saved_cross_v5'
D=S/'root_review_integration';PRE=A.parent/'distinct_pair_preexecution'
observed={};checks=0

def need(ok,label):
    global checks
    checks+=1
    if not ok:raise ValueError(label)
def key(p):
    s=Path(p).stat();return s.st_dev,s.st_ino
def pin(p):
    p=Path(p);s=p.stat();need(p.is_absolute() and stat.S_ISREG(s.st_mode),'absolute regular input')
    for q in [p,*p.parents]:need(not q.is_symlink(),'non-symlink '+str(q))
    h=hashlib.sha256();n=0
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b);n+=len(b)
    t=p.stat();need((s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns),'stable input during hash')
    v={'path':str(p),'bytes':n,'sha256':h.hexdigest()};need(observed.setdefault(str(p),v)==v,'observed input unchanged');return v
def verify(v):
    need(set(v)=={'path','bytes','sha256'} and type(v['bytes']) is int and v['bytes']>=0,'strict pin shape')
    need(pin(v['path'])==v,'exact input pin '+v['path']);return Path(v['path'])
def same(a,b):
    verify(a);verify(b);need(Path(a['path']).samefile(b['path']) and a['bytes']==b['bytes'] and a['sha256']==b['sha256'],'physical and byte pin equality')
def pairs(rows):
    out={}
    for k,v in rows:need(k not in out,'duplicate JSON key');out[k]=v
    return out
def read(p):
    pin(p);return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def pins(v):
    if isinstance(v,dict):
        if set(v)=={'path','bytes','sha256'}:yield v
        else:
            for x in v.values():yield from pins(x)
    elif isinstance(v,list):
        for x in v:yield from pins(x)
def descriptors(v):
    if isinstance(v,dict):
        if {'file','bytes','sha256'}<=set(v):yield v
        else:
            for x in v.values():yield from descriptors(x)
    elif isinstance(v,list):
        for x in v:yield from descriptors(x)
def roster(p):
    out=[]
    for b,ds,fs in os.walk(p,followlinks=False):
        for n in ds+fs:need(not (Path(b)/n).is_symlink(),'no roster symlink')
        out.extend(Path(b)/n for n in fs)
    return out
def exact(a,b,label):need(type(a) is type(b) and a==b,label)
def timestamp(s):return dt.datetime.fromisoformat(s.replace('Z','+00:00'))
def field(v,p):
    for x in p.lstrip('/').split('/'):v=v[x.replace('~1','/').replace('~0','~')]
    return v
def model_descriptors(path):
    m=read(path)
    for desc in descriptors(m):
        rel=desc['file'];need('/' not in rel and rel not in ('','.','..'),'local descriptor file')
        verify({'path':str(Path(path).parent/rel),'bytes':desc['bytes'],'sha256':desc['sha256']})
    return m

def run():
    initial=read(A/'COMPLETED_PAIR_BASELINE_BEFORE_QA.json')
    expected={key(verify(v)) for v in initial['files']};actual=roster(P/'runs')+roster(P/'root_launches')
    need(len(actual)==len(expected)==97 and {key(x) for x in actual}==expected,'actual completed-pair roster stable')
    pre=read(PRE/'INPUT_PINS.json')
    for v in pre['files']:verify(v)
    freeze=read(P/'INPUT_FREEZE.json')
    for d in freeze['directories']:
        expected={key(Path(d['path'])/v['relative_path']) for v in d['files']};actual=roster(d['path'])
        need(len(actual)==len(expected) and {key(x) for x in actual}==expected,'old/current frozen directory roster stable')
    go_path=D/'ROOT_R9_PAIR_SOLVE_AUTHORIZATION.json';go_pin=pin(go_path);go=read(go_path)
    need(go_pin['sha256']=='8e2f0b313d376fa4f405bb850451cb394e1e66af6b8c1a134661a06e3f59583a','actual distinct pair GO')
    for v in pins(go):verify(v)
    plan=read(go['plan']['path']);adoption=read(go['gate_adoption']['path']);bundle=read(go['prior_gate_bundle']['path'])
    for v in pins(adoption):verify(v)
    need(go['schema']=='v71-r9-distinct-pair-root-authorization-v1' and go['status']=='GO_DISTINCT_PAIR_SOLVES_ONLY' and go['authorized_stages']==['solve_unchanged','solve_S01_release'],'exact pair authority')
    need(adoption['schema']=='v71-r9-adopted-v5-gates-for-pair-v1' and adoption['status']=='ADOPT_V5_EVIDENCE_FOR_R9_PAIR','new explicit prior evidence adoption')
    for k in ['plan','input_freeze','prior_gate_bundle','adopted_v5_evidence']:same(go[k],adoption[k])
    need(not (P/'RUN_LOCK.json').exists(),'normal final lock release')
    observed_root=read(D/'ROOT_R9_PAIR_OBSERVED_RETURN_RECEIPT_NOT_ADOPTED.json')
    need(pin(D/'ROOT_R9_PAIR_OBSERVED_RETURN_RECEIPT_NOT_ADOPTED.json')['sha256']=='192e609f23d1ea846a0650422d2019dede2fe80358b8161eeef4c1a72091200d','root observed receipt hash')
    for v in pins(observed_root):verify(v)
    gc=bundle['gc_diagnostic'];inspection=read(verify(gc['inspection']));verify(gc['source_excerpts']);verify(gc['jar'])
    with zipfile.ZipFile(gc['jar']['path']) as z:
        for member in inspection['embedded_members']:
            b=z.read(member['member']);need(len(b)==member['bytes'] and hashlib.sha256(b).hexdigest()==member['sha256'],'pinned GC embedded source/class identity')
    outputs={};previous=None;class_ids=None
    for stage,arm in [('solve_unchanged','unchanged'),('solve_S01_release','S01_release')]:
        f=P/'runs'/stage;s=read(f/'SUPERVISOR_RESULT.json');n=read(f/'native_result/RESULT.json');r=read(f/'RESERVATION.json');l=read(P/'root_launches'/(stage+'_LAUNCH.json'));m=read(f/'OUTPUT_MANIFEST.json');c=read(f/'native_result/CAPTURE_RECEIPT.json')
        for v in pins([s,n,l]):verify(v)
        need(s['status']=='COMPLETE_STAGE' and type(s['return_code']) is int and s['return_code']==0 and s['limit_reason'] is None and s['signals']==[] and s['capture_complete'] is True and s['capture_errors']=={},'complete actual supervised stage')
        need(n['status']=='PASS_ONE_RAW_FOUR_FP_RESULT' and n['teardown']=='COMPLETED' and n['stage']=='PROCESS_FINISHED' and type(n['realizable']) is bool,'actual returned Boolean and complete teardown')
        for k,expected in plan['stages'][stage]['required_result_fields'].items():exact(field(n,k),expected,'required native result '+k)
        for k in ['plan','input_freeze','prior_gate_bundle','adopted_v5_evidence','gate_adoption']:same(s[k],go[k])
        for obj in [s,n,l]:same(obj['authorization'],go_pin)
        same(n['config'],plan['config']);same(n['gate_adoption'],go['gate_adoption'])
        for k in ['plan','input_freeze']:same(l[k],go[k])
        same(l['root_launcher'],plan['root_launcher']);same(s['native_result'],pin(f/'native_result/RESULT.json'));same(s['output_manifest'],pin(f/'OUTPUT_MANIFEST.json'))
        same(n['capture_receipt'],pin(f/'native_result/CAPTURE_RECEIPT.json'))
        need(m['schema']=='v71-r7-stage-output-manifest-v1' and m['stage']==stage and m['excluded_cycle_files']==['SUPERVISOR_RESULT.json','OUTPUT_MANIFEST.json'],'manifest identity/exclusion')
        expected=[key(verify(v)) for v in m['files']];actual=[q for q in roster(f) if q.name not in ('SUPERVISOR_RESULT.json','OUTPUT_MANIFEST.json')]
        need(len(expected)==len(set(expected))==len(actual)==43 and set(expected)=={key(q) for q in actual},'complete exact physical output roster')
        need(len(roster(f))<=plan['stages'][stage]['limits']['artifact_file_count'] and sum(q.stat().st_size for q in roster(f))<=plan['stages'][stage]['limits']['artifact_bytes'],'final artifact limits')
        argv=[go_pin['path'] if x=='{authorization_path}' else go_pin['sha256'] if x=='{authorization_sha256}' else x for x in plan['stages'][stage]['argv']]
        need(s['target_argv']==argv and s['environment']==plan['stages'][stage]['env'] and s['limits']==plan['stages'][stage]['limits'],'exact actual native argv/environment/limits')
        outer=plan['supervisor_launch_prefix']+[stage,'--authorization',go_pin['path'],'--authorization-sha256',go_pin['sha256']]
        need(l['actual_outer_argv']==outer and l['outer_command_uses_shell'] is False and l['declared_effective_outer_environment']==plan['supervisor_environment'],'exact actual clean outer launch')
        need(Path(l['cwd']).samefile(P) and l['status']=='OUTER_PROCESS_EXITED' and l['outer_return_code']==0,'actual outer cwd/exit')
        need(r['stage']==stage and r['authorization_sha256']==go_pin['sha256'] and r['attempt']==r['maximum_concurrency']==1 and r['budget_reservation']=={'model_attempt_slots':1,'raw_call_entry_slots':1,'refundable':False},'one nonrefundable reservation')
        need(r['supervisor_pid']==r['supervisor_identity']['pid']==l['outer_pid']==s['owned_root']['ppid'] and s['pid']==s['owned_root']['pid']==s['owned_root']['pgid'],'actual birth-owned parent/child process chain')
        need(r['supervisor_identity']['start_sec']<=s['owned_root']['start_sec'],'supervisor birth before child')
        shim=plan['supervisor_invocation_prefix']+['_limit_exec',stage,'--authorization',go_pin['path'],'--authorization-sha256',go_pin['sha256'],'--spawn-token',r['spawn_token']]
        need(s['launch_argv']==shim,'actual exec shim owns reservation token')
        need(all(x['pid']==s['pid'] and all(x[k]==s['owned_root'][k] for k in ['pid','ppid','pgid','uid','start_sec','start_usec']) for x in s['last_snapshot']['processes']),'last live sample contains only birth-owned child')
        need(timestamp(go['created_utc'])<timestamp(l['started_utc'])<=timestamp(s['created_utc'])<timestamp(s['finished_utc'])<=timestamp(l['finished_utc'])<timestamp(go['expires_utc']),'authority and actual stage chronology')
        if previous:need(timestamp(previous)<timestamp(l['started_utc']),'fresh first finished before second actual launch')
        previous=l['finished_utc']
        need(0<s['process_elapsed_seconds']<300 and 0<s['sampled_peak_process_tree_rss_bytes']<=1073741824 and s['sample_count']>=s['live_rss_sample_count']>0,'observed finite process wall and sampled RSS')
        expected_events=['PARSE_FIXED_B','GENERATE_ONE_MODEL','ONE_MODEL_GENERATION_RETURNED','ALL_GATES_RECHECKED_BEFORE_SOLVER_CONSTRUCTION','ONE_RAW_FOUR_FP_CALL_BEGIN','ONE_RAW_FOUR_FP_CALL_RETURNED','PROCESS_FINISHED']
        need([e['stage'] for e in n['stage_events']]==expected_events,'one ordered parse/generation/gate/call/return/final sequence')
        times=[e['elapsed_ms'] for e in n['stage_events']];need(all(type(x) is int and x>=0 for x in times) and times==sorted(times),'native event time sequence')
        need(all(e['heap_max_bytes']==536870912 for e in n['stage_events']),'same native heap cap')
        for prefix,parts in [('baseline_exact_old_B',['rhoE','rhoS','thetaE','thetaS','domain','domain_ENV_next','domain_SYS_next','ENV_justice_0','SYS_justice_0','SYS_justice_1']),('adopted_arm_before_solver',['rhoE','rhoS','thetaE','thetaS','domain','domain_ENV_next','domain_SYS_next','ENV_justice_0','SYS_justice_0','SYS_justice_1']),('adopted_arm_after_solver_constructor',['rhoE','rhoS','thetaE','thetaS','domain','domain_ENV_next','domain_SYS_next','ENV_justice_0','SYS_justice_0','SYS_justice_1']),('preserved',['thetaE','thetaS','rhoE','domain','domain_ENV_next','domain_SYS_next','ENV_justice_0','SYS_justice_0','SYS_justice_1'])]:
            for part in parts:
                eq=n[prefix+'_'+part];need(eq['raw_boolean_equal'] is True and eq['typed_equal'] is True and eq['actual_nodes']==eq['expected_nodes'],'complete actual in-model equality '+prefix+'_'+part)
        for label in ['dispatch_after_generation','dispatch_before_intervention','dispatch_before_completion_or_solve','dispatch_after_solver_construction']:
            d=n[label];need(d['ENV_transFunc']==d['SYS_transFunc']=='SINGLE_FUNC' and d['ENV_simConjunctAbs'] is d['SYS_simConjunctAbs'] is False,'same actual SINGLE_FUNC/SCA false dispatch')
        intervention=n['intervention'];release=(arm=='S01_release')
        need(intervention['typed_S01_release'] is release and intervention['only_full_SYS_relation_changed'] is release and intervention['delta_zero'] is (not release) and intervention['removed_edges_zero'] is True and intervention['xor_outside_S01_zero'] is True,'exact sole typed S01 intervention flags')
        for q,d in intervention['SYS_quadrants'].items():need(d['unchanged'] is (not (release and q=='01')),'only S01 changes')
        need(intervention['SYS_quadrants']['11']['after']['one'] is True,'exact retained S11 remains one')
        old_gate=read(verify(adoption['gate_results']['gate_'+arm]));same(n['adopted_gate_model'],old_gate['arm_model'])
        models={};model_compare={}
        for kind in ['baseline_model','arm_model']:
            cur=model_descriptors(verify(n[kind]));orig=model_descriptors(verify(old_gate[kind]));historical=model_descriptors(OLD/'runs'/stage/'native_result'/('baseline' if kind=='baseline_model' else 'arm')/'model.json')
            need(cur==historical,'exact full saved model descriptor object equals historical v5 same arm')
            samebytes=Path(n[kind]['path']).read_bytes()==Path(old_gate[kind]['path']).read_bytes()
            differences={k:{'current':cur['original_bdds'][k],'original_gate':orig['original_bdds'][k]} for k in cur['original_bdds'] if cur['original_bdds'][k]!=orig['original_bdds'][k]}
            if not samebytes:
                need(arm=='S01_release' and kind=='arm_model' and set(differences)=={'domain','domain_ENV_next'},'only expected original gate descriptor differences')
                for k,diff in differences.items():need({x:v for x,v in diff['current'].items() if x!='sha256'}=={x:v for x,v in diff['original_gate'].items() if x!='sha256'},'only serialized-domain SHA differs')
                need({k:v for k,v in cur.items() if k!='original_bdds'}=={k:v for k,v in orig.items() if k!='original_bdds'},'all remaining model metadata exact')
            model_compare[kind]={'byte_identical_original_gate':samebytes,'byte_identical_historical_v5':True,'original_gate_descriptor_differences':differences};models[kind]=cur
        for k in ['fields','public_fields','all_current_bits','all_next_bits','bdd_variable_count','bdd_variable_order','original_justices','source_inventory']:need(models['baseline_model'][k]==models['arm_model'][k],'fixed model field/order/justice/inventory '+k)
        need(len(models['arm_model']['fields'])==6 and len(models['arm_model']['original_justices']['ENV'])==1 and len(models['arm_model']['original_justices']['SYS'])==2,'six fields and ordered justice counts')
        for desc in descriptors(intervention):verify({'path':str(f/'native_result/arm'/desc['file']),'bytes':desc['bytes'],'sha256':desc['sha256']})
        identities=n['class_identities']+[n[k] for k in ['solver_class','harness_class','helper_class','serializer_class','capture_class']]
        for row in identities:
            source=row['code_source'];need(source.startswith('(file:') and source.endswith(' <no signer certificates>)'),'class source form')
            path=Path(urllib.parse.unquote(source[len('(file:'):-len(' <no signer certificates>)')]));member=row['class'].replace('.','/')+'.class'
            if path.is_dir():data=(path/member).read_bytes();pin(path/member)
            else:
                pin(path)
                with zipfile.ZipFile(path) as z:data=z.read(member)
            need(hashlib.sha256(data).hexdigest()==row['class_sha256'],'actual loaded class matches pinned bytes')
        if class_ids is not None:need(n['class_identities']==class_ids,'identical loaded released classes across pair')
        class_ids=n['class_identities'];need(n['observed_backend']=='net.sf.javabdd.JTLVJavaFactory' and n['solver_class']['class']=='tau.smlab.syntech.games.gr1.GR1SeparatedGame','exact released backend/solver')
        for row in gc['runtime_class_identities']:need(row in n['class_identities'],'GC format bound to actual exact runtime classes')
        stderr=(f/'stderr.txt').read_bytes();lines=stderr.splitlines(keepends=True);total=Decimal(0);gc_rows=[]
        for i,line in enumerate(lines,1):
            match=re.fullmatch(rb'Garbage collection #([1-9][0-9]*): ([1-9][0-9]*) nodes / ([0-9]+) free / ([0-9]+\.[0-9]+)s / ([0-9]+\.[0-9]+)s total\n',line)
            need(match is not None,'exact full-line pinned JTLV GC diagnostic; no extra stderr')
            number,nodes,free,elapsed,cumulative=match.groups();need(int(number)==i and 0<=int(free)<=int(nodes),'sequential GC and valid nodes')
            total+=Decimal(elapsed.decode());need(total==Decimal(cumulative.decode()),'consistent printed cumulative GC time')
            gc_rows.append({'sequence':i,'nodes':int(nodes),'free':int(free),'seconds':elapsed.decode(),'cumulative_seconds':cumulative.decode()})
        need(len(lines)==(4 if arm=='unchanged' else 108),'exact fully classified stderr rows')
        need(s['stream_bytes']=={'stdout':pin(f/'stdout.txt')['bytes'],'stderr':len(stderr)},'full actual pipe byte counts')
        need(c['capture_complete'] is True and c['cap_reached'] is False and c['capture_error'] is None and c['unflushed_repeated_lines']==0 and c['raw_cap_bytes']==68719476736 and c['encoded_cap_bytes']==67108864,'reported complete bounded native capture')
        need(c['encoded_bytes']==pin(f/'stdout.txt')['bytes'] and c['encoded_sha256']==pin(f/'stdout.txt')['sha256'],'exact complete encoded stream digest')
        for k in ['raw_bytes','encoded_bytes','records','repeated_lines','unflushed_repeated_lines']:need(type(c[k]) is int and c[k]>=0,'strict recorded capture count')
        need(c['raw_bytes']<=68719476736 and c['encoded_bytes']<=67108864,'recorded finite native counts; raw digest verification still pending')
        need(c==observed_root['arms'][arm]['capture'] and n['realizable'] is observed_root['arms'][arm]['native']['realizable'],'independent administrative observations agree with root receipt')
        need(verify(l['stderr']).read_bytes()==b'','outer wrapper stderr empty')
        outer_stdout=read(l['stdout']['path']);need(outer_stdout['stage']==stage and outer_stdout['status']=='COMPLETE_STAGE' and outer_stdout['return_code']==0 and outer_stdout['exception'] is None,'actual root stdout completion line')
        outputs[arm]={'observed_returned_boolean':n['realizable'],'status':'ADMINISTRATIVE_AND_DESCRIPTOR_QA_PASS_RAW_DIGEST_PENDING','native_result':pin(f/'native_result/RESULT.json'),'supervisor':pin(f/'SUPERVISOR_RESULT.json'),'actual_launch':pin(P/'root_launches'/(stage+'_LAUNCH.json')),'model_comparisons':model_compare,'stderr':{'pin':pin(f/'stderr.txt'),'classification':'All exact bytes conform to the pinned loaded JTLV default GC diagnostic format; no other stderr. This is not empty stderr.','gc_records':gc_rows},'capture':c,'timing':{'native_elapsed_ms':n['elapsed_ms'],'raw_call_begin_to_return_event_delta_ms':times[5]-times[4],'supervised_process_seconds':s['process_elapsed_seconds'],'supervisor_total_seconds':s['elapsed_seconds'],'outer_launch_seconds':l['outer_elapsed_seconds'],'interpretation':'Observed timing under this pinned instrumented run only; no general performance inference.'},'sampled_peak_process_tree_rss_bytes':s['sampled_peak_process_tree_rss_bytes']}
    old=read(PRE/'OLD_V5_BASELINE_BEFORE.json')
    need({str(q.relative_to(OLD)) for q in roster(OLD)}=={v['path'] for v in old['files']},'old 155-file roster preserved')
    for v in old['files']:verify({**v,'path':str(OLD/v['path'])})
    for v in old['old_root_records']:verify(v)
    for v in initial['files']:verify(v)
    for v in list(observed.values()):need(pin(v['path'])==v,'all administrative inputs unchanged at completion')
    return {'schema':'v71-r9-independent-administrative-pair-qa-v1','status':'PASS_ADMINISTRATIVE_AND_DESCRIPTOR_QA_ONLY_RAW_DIGEST_QA_PENDING_NOT_SCIENTIFIC_ADOPTION','arms':outputs,'history':{'old_completed_models':5,'new_model_attempts':2,'new_completed_models':2,'total_model_attempts':7,'old_entered_calls':2,'new_entered_calls':2,'total_entered_calls':4,'old_returned_calls':1,'new_returned_calls':2,'total_returned_calls':3,'remaining_attempts':0,'remaining_call_slots':0,'retries':0},'old_155_files_and_10_root_records_preserved':True,'raw_expansion_performed':False,'new_saved_predicate_reconstruction':False,'scientific_execution_by_auditor':False,'next_required':'Reviewed finite full admitted raw-digest QA for BOTH captures and root scientific adoption.'}

if __name__=='__main__':
    target=A/'ADMINISTRATIVE_AND_DESCRIPTOR_QA.json'
    if target.exists():raise SystemExit('Refuse overwrite '+str(target))
    v=run();v['assertions']=checks;v['observed_file_pins']=list(observed.values());v['created_utc']=dt.datetime.now(dt.timezone.utc).isoformat();target.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':v['status'],'assertions':checks,'observed_files':len(observed),'history':v['history'],'report':pin(target)},ensure_ascii=False,indent=2))
