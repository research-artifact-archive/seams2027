"""Administrative saved-byte checks; deliberately not a scientific adoption validator."""
from __future__ import annotations

from pathlib import Path
import os

from capture_qa import (Budget, ENCODED_CAP, RAW_CAP, audit_capture, count,
                        need, ordinary_file, pin_shape, read_pinned, strict_json)

HERE = Path(__file__).absolute().parent
WORKSPACE = HERE.parents[4]
PREP = WORKSPACE / "experiment/v71_acceptance_cycle_20261025/research_strategy_after_r6/r9_same_observer_pair_preparation_v1"
PROTOCOL = "v71-r9-distinct-same-observer-exact-B-pair-v1"
PLAN_SHA = "acb4cebcd4646ce50eb2111455928b926faf0e47d19442359669943631631ae2"
FREEZE_SHA = "33acf79f57ea8d807669abb287558c8d980dc7477c748a302e61a5d754d1263b"
LIMITS = {"wall_seconds": 300, "cpu_seconds": 240, "sampled_worker_rss_bytes": 1073741824,
          "encoded_bytes": ENCODED_CAP, "raw_bytes": RAW_CAP, "workers": 1, "retries": 0}
REMAINING = [
    "Independent auditor must validate the complete frozen file/directory roster and runtime aliases, including preservation of historical evidence.",
    "Independent auditor must validate all adopted prior-gate/old-v5 authority semantics, preexecution review evidence, exact runtime class/JAR member identities, translator/backend/dispatch and saved comparison claims; this tool does not replay predicates.",
    "Independent auditor must verify current root-launch command/environment, launcher identity, root authorization authority, reservation uniqueness, serial stage order, first-arm dependency, resource samples, complete owned-process cleanup and aggregate nonrefundable accounting across both arms.",
    "Independent auditor must validate all original and exported model descriptor rosters and byte pins, source/field/justice/S01-only comparison evidence, and any remaining native-result assertions against the frozen protocol.",
    "Root must separately adopt independently reviewed results. This QA tool never permits scientific adoption or treats an end record as a returned solver call."
]
ROLES = {"plan", "input_freeze", "science_go", "gate_adoption", "config", "native",
         "supervisor", "manifest", "launch", "encoded_stream", "capture_receipt"}


def equivalent(left, right):
    pin_shape(left); pin_shape(right)
    return (left["bytes"] == right["bytes"] and left["sha256"] == right["sha256"] and
            Path(left["path"]).samefile(right["path"]))


def document(pin, budget):
    value = strict_json(read_pinned(pin, budget))
    need(type(value) is dict, "administrative JSON object required")
    return value


def request_header(request):
    required = {"schema", "status", "executor", "stage", "mode", "maximum_attempts", "limits",
                "output_directory", "qa_code_freeze", "review_handoff", "inputs", "remaining_review_acknowledged"}
    need(type(request) is dict and set(request) == required, "exact QA request fields")
    need(request["schema"] == "v71-r9-one-saved-capture-qa-authorization-v1" and
         request["status"] == "GO_VERIFY_ONE_SAVED_STAGE" and request["executor"] == "root only",
         "separate root QA authority required")
    need(request["stage"] in ("solve_unchanged", "solve_S01_release") and
         request["mode"] in ("COMPLETE", "PREFIX"), "fixed stage/mode")
    need(type(request["maximum_attempts"]) is int and request["maximum_attempts"] == 1 and
         request["limits"] == LIMITS and all(type(request["limits"][key]) is int for key in LIMITS) and
         request["remaining_review_acknowledged"] is True,
         "fixed finite once-only QA contract")
    need(type(request["inputs"]) is dict and set(request["inputs"]) == ROLES, "exact QA input roles")
    for name, pin in request["inputs"].items():
        if name == "capture_receipt" and pin is None and request["mode"] == "PREFIX":
            continue
        pin_shape(pin)
    pin_shape(request["qa_code_freeze"]); pin_shape(request["review_handoff"])


def verify_code(request, budget):
    pin = request["qa_code_freeze"]
    need(Path(pin["path"]).samefile(HERE / "CODE_FREEZE.json"), "fixed local QA code freeze")
    freeze = document(pin, budget)
    need(freeze["schema"] == "v71-r9-saved-qa-code-freeze-v1", "QA code freeze schema")
    expected = {"capture_qa.py", "saved_stage_qa.py", "qa_runner.py", "qa_worker.py"}
    need({Path(row["path"]).name for row in freeze["files"]} == expected and
         len(freeze["files"]) == len(expected), "exact QA source roster")
    for row in freeze["files"]:
        need(Path(row["path"]).parent.samefile(HERE), "local QA source only")
        read_pinned(row, budget, retain=False)
    read_pinned(freeze["python_executable"], budget, maximum=67_108_864, retain=False)
    need(Path(freeze["python_executable"]["path"]).samefile(os.sys.executable), "pinned Python runtime")
    # This pin records that root reviewed a concrete handoff; its review semantics remain independent.
    read_pinned(request["review_handoff"], budget, retain=False)
    return freeze


def verify_manifest(pin, stage, folder, budget):
    data = document(pin, budget)
    need(data["schema"] == "v71-r7-stage-output-manifest-v1" and data["stage"] == stage and
         data["excluded_cycle_files"] == ["SUPERVISOR_RESULT.json", "OUTPUT_MANIFEST.json"],
         "manifest schema/stage/exclusions")
    need(type(data["files"]) is list and 0 < len(data["files"]) <= 4094, "bounded manifest roster")
    expected, total = set(), 0
    for row in data["files"]:
        budget.check(); pin_shape(row)
        path, info = ordinary_file(row["path"])
        need(folder in path.parents and path.parent != folder.parent, "manifest lexical containment")
        physical = (info.st_dev, info.st_ino)
        need(physical not in expected, "manifest physical duplicate")
        expected.add(physical); total += row["bytes"]
        need(total <= 268435456, "manifest artifact-byte cap")
        read_pinned(row, budget, maximum=268435456, retain=False)
    actual, excluded, file_count, directory_count, total_size = set(), set(), 0, 0, 0
    for root, directories, files in os.walk(folder, followlinks=False):
        budget.check(); directory_count += 1
        need(directory_count <= 4096, "bounded directory traversal")
        for name in directories:
            need(not (Path(root) / name).is_symlink(), "manifest directory link")
        for name in files:
            path, info = ordinary_file(Path(root) / name)
            file_count += 1; total_size += info.st_size
            need(file_count <= 4096 and total_size <= 268435456, "actual artifact limits")
            physical = (info.st_dev, info.st_ino)
            need(physical not in actual, "actual physical duplicate")
            actual.add(physical)
            if Path(root) == folder and name in data["excluded_cycle_files"]:
                excluded.add(physical)
    need(len(excluded) == 2 and expected == actual - excluded, "exact physical manifest roster")
    return {"files": file_count, "bytes": total_size, "manifest_members": len(expected)}


def run(request, budget):
    request_header(request)
    verify_code(request, budget)
    pins = request["inputs"]
    stage = request["stage"]
    folder = PREP / "runs" / stage
    locations = {"plan": PREP / "PLAN.json", "input_freeze": PREP / "INPUT_FREEZE.json",
                 "config": PREP / "B_CONFIG.json", "native": folder / "native_result/RESULT.json",
                 "supervisor": folder / "SUPERVISOR_RESULT.json", "manifest": folder / "OUTPUT_MANIFEST.json",
                 "launch": PREP / "root_launches" / (stage + "_LAUNCH.json"),
                 "encoded_stream": folder / "stdout.txt", "capture_receipt": folder / "native_result/CAPTURE_RECEIPT.json"}
    for name, path in locations.items():
        if pins[name] is not None:
            ordinary_file(pins[name]["path"])
            need(Path(pins[name]["path"]).samefile(path), "original physical location: " + name)
    need(pins["plan"]["sha256"] == PLAN_SHA and pins["input_freeze"]["sha256"] == FREEZE_SHA,
         "exact frozen current R9 plan/freeze")
    docs = {name: document(pins[name], budget) for name in
            ("plan", "input_freeze", "science_go", "gate_adoption", "config", "native", "supervisor", "launch")}
    plan, go, adoption = (docs[name] for name in ("plan", "science_go", "gate_adoption"))
    native, supervisor, launch = (docs[name] for name in ("native", "supervisor", "launch"))
    need(plan["schema"] == "v71-r9-distinct-pair-plan-v1" and plan["protocol_identity"] == PROTOCOL,
         "current plan protocol")
    need(go["schema"] == "v71-r9-distinct-pair-root-authorization-v1" and
         go["status"] == "GO_DISTINCT_PAIR_SOLVES_ONLY" and go["protocol_identity"] == PROTOCOL and
         stage in go["authorized_stages"], "current scientific GO identity")
    for obj in (go, adoption, supervisor, launch):
        for name in ("plan", "input_freeze"):
            need(equivalent(obj[name], pins[name]), "current " + name + " binding")
    need(equivalent(go["gate_adoption"], pins["gate_adoption"]), "GO adoption binding")
    for obj in (native, supervisor, launch):
        need(equivalent(obj["authorization"], pins["science_go"]), "actual current GO binding")
    for obj in (native, supervisor):
        need(obj["protocol_identity"] == PROTOCOL and equivalent(obj["gate_adoption"], pins["gate_adoption"]),
             "actual current protocol/adoption")
    need(native["schema"] == "v71-r9-exact-B-same-observer-pair-result-v1" and
         native["requested_stage"] == stage and supervisor["stage"] == launch["stage"] == stage,
         "exact actual stage identity")
    need(equivalent(plan["config"], pins["config"]) and equivalent(native["config"], pins["config"]),
         "unchanged original comparison configuration")
    originals = []
    for name in ("prior_source_model", "prior_helper_model", "prior_exact_model", "prior_exact_gate_adoption"):
        row = docs["config"][name]
        read_pinned(row, budget, retain=False); originals.append({"role": name, "pin": row})
    need(equivalent(supervisor["output_manifest"], pins["manifest"]), "supervisor manifest binding")
    manifest_summary = verify_manifest(pins["manifest"], stage, folder, budget)
    receipt = None if pins["capture_receipt"] is None else document(pins["capture_receipt"], budget)
    capture = audit_capture(pins["encoded_stream"], receipt, request["mode"], budget)
    if native.get("capture_receipt") is not None:
        need(pins["capture_receipt"] is not None and equivalent(native["capture_receipt"], pins["capture_receipt"]),
             "native capture receipt binding")
    completion = {
        "native_status": native.get("status") == "PASS_ONE_RAW_FOUR_FP_RESULT",
        "typed_boolean_return": type(native.get("realizable")) is bool,
        "accounting_finalized": native.get("accounting_finalized") is True,
        "model_dispatch": native.get("model_generation_call_dispatched") is True,
        "raw_dispatch": native.get("raw_call_dispatch_recorded") is True,
        "teardown_complete": native.get("teardown") == "COMPLETED",
        "supervisor_complete": supervisor.get("status") == "COMPLETE_STAGE",
        "os_zero": type(supervisor.get("return_code")) is int and supervisor["return_code"] == 0,
        "no_limits": supervisor.get("limit_reason") is None,
        "no_signals": supervisor.get("signals") == [],
        "outer_capture_complete": supervisor.get("capture_complete") is True and supervisor.get("capture_errors") == {},
        "actual_root_launch_complete": launch.get("status") == "OUTER_PROCESS_EXITED" and
             type(launch.get("outer_return_code")) is int and launch["outer_return_code"] == 0,
        "complete_capture_and_raw_digest": capture["capture_complete_verified"] and capture["all_admitted_raw_digest_verified"],
        "nonrefundable_reservation": supervisor.get("budget_reservation") ==
            {"model_attempt_slots": 1, "raw_call_entry_slots": 1, "refundable": False} and
            type(supervisor.get("budget_reservation", {}).get("model_attempt_slots")) is int and
            type(supervisor.get("budget_reservation", {}).get("raw_call_entry_slots")) is int and
            supervisor.get("budget_reservation", {}).get("refundable") is False,
    }
    for name in ("model_generation_attempts", "model_generations", "raw_call_entry_attempts",
                 "raw_four_fixed_point_calls", "raw_four_fixed_point_calls_returned", "solver_constructions",
                 "winning_region_computations"):
        value = native.get(name)
        completion["one_" + name] = type(value) is int and value == 1
    for name in ("semantic_reduction_calls", "native_strict_solver_calls", "controller_extraction_calls"):
        value = native.get(name)
        completion["zero_" + name] = type(value) is int and value == 0
    return {"schema": "v71-r9-saved-capture-administrative-qa-result-v1",
            "status": "VERIFIED_CAPTURE_AND_LISTED_ADMINISTRATIVE_CHECKS", "stage": stage,
            "capture": capture, "inputs": pins, "original_comparison_pins_verified": originals,
            "manifest": manifest_summary, "observed_completion_conditions": completion,
            "all_listed_completion_conditions": all(completion.values()),
            "scientific_outcome": "NOT_ADOPTED_BY_THIS_TOOL", "scientific_adoption_permitted": False,
            "remaining_independent_auditor_checks": REMAINING}
