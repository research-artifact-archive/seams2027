"""Independent static data audit. Never imports/executes any prepared module."""
from pathlib import Path
import ast
import datetime
import difflib
import hashlib
import json
import os
import stat
import struct
import zipfile

A=Path(__file__).resolve().parent
O=A.parents[2]
S=O/'research_strategy_after_r6'
P=S/'r9_same_observer_pair_preparation_v1'
OLD=S/'same_solver_diagnostic_preparation_saved_cross_v5'
D=S/'root_review_integration'
observed={}
checks=0

def need(ok,label):
    global checks
    checks+=1
    if not ok: raise ValueError(label)

def ident(p):
    s=Path(p).stat();return s.st_dev,s.st_ino

def pin(p):
    p=Path(p);before=p.stat()
    need(p.is_absolute() and stat.S_ISREG(before.st_mode),'absolute regular '+str(p))
    for q in [p,*p.parents]:need(not q.is_symlink(),'no symlink '+str(q))
    h=hashlib.sha256();size=0
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b);size+=len(b)
    after=p.stat()
    need((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns),'stable read '+str(p))
    value={'path':str(p),'bytes':size,'sha256':h.hexdigest()}
    need(observed.setdefault(str(p),value)==value,'stable observed bytes '+str(p))
    return value

def verify(v):
    need(set(v)=={'path','bytes','sha256'} and type(v['bytes']) is int and v['bytes']>=0,'exact pin fields/types')
    need(pin(v['path'])==v,'exact pin '+str(v['path']));return Path(v['path'])

def pairs(rows):
    out={}
    for k,v in rows:need(k not in out,'duplicate JSON key '+k);out[k]=v
    return out

def read(p):
    pin(p)
    return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))

def nested(v):
    if isinstance(v,dict):
        if set(v)=={'path','bytes','sha256'}:yield v
        else:
            for x in v.values():yield from nested(x)
    elif isinstance(v,list):
        for x in v:yield from nested(x)

def roster(p):
    out=[]
    for base,dirs,files in os.walk(p,followlinks=False):
        for n in dirs:need(not (Path(base)/n).is_symlink(),'no directory link')
        for n in files:out.append(Path(base)/n)
    return out

def freeze_members(f,rehash):
    out={}
    def add(v):
        p=verify(v) if rehash else Path(v['path'])
        k=ident(p);need(k not in out,'no duplicate physical frozen file');out[k]=v
    for v in f['files']:add(v)
    for d in f['directories']:
        p=Path(d['path']);need(p.is_absolute() and p.is_dir(),'absolute roster root')
        expected=[]
        for v in d['files']:
            rel=v['relative_path'];need(isinstance(rel,str) and rel and not rel.startswith('/') and '\\' not in rel and all(x not in ('','.','..') for x in rel.split('/')),'safe relative file')
            q=p/rel;add({'path':str(q),'bytes':v['bytes'],'sha256':v['sha256']});expected.append(ident(q))
        actual=roster(p);need(len(actual)==len(expected) and {ident(x) for x in actual}==set(expected),'exact frozen roster '+str(p))
    return out

def longs(p):
    b=Path(p).read_bytes();need(b[:4]==b'\xca\xfe\xba\xbe','class magic')
    count=struct.unpack_from('>H',b,8)[0];pos=10;i=1;out=[]
    while i<count:
        tag=b[pos];pos+=1
        if tag==1:n=struct.unpack_from('>H',b,pos)[0];pos+=2+n
        elif tag in (3,4):pos+=4
        elif tag in (5,6):
            if tag==5:out.append(struct.unpack_from('>q',b,pos)[0])
            pos+=8;i+=1
        elif tag in (7,8,16,19,20):pos+=2
        elif tag in (9,10,11,12,17,18):pos+=4
        elif tag==15:pos+=3
        else:raise ValueError('Unknown class constant tag '+str(tag))
        i+=1
    return out

def run():
    need(pin(P/'HANDOFF.json')['sha256']=='06d3f7ff9f7d414c83cd819d015abdcf0e57f6e3f3a2d4d66d266e83d68fe261','final handoff hash')
    h=read(P/'HANDOFF.json')
    for v in nested(h):verify(v)
    plan=read(P/'PLAN.json');freeze=read(P/'INPUT_FREEZE.json')
    need(pin(P/'PLAN.json')['sha256']=='acb4cebcd4646ce50eb2111455928b926faf0e47d19442359669943631631ae2','final plan hash')
    need(pin(P/'INPUT_FREEZE.json')['sha256']=='33acf79f57ea8d807669abb287558c8d980dc7477c748a302e61a5d754d1263b','final freeze hash')
    files=freeze_members(freeze,True);old_files=freeze_members(read(OLD/'INPUT_FREEZE.json'),False)
    need(len(files)==1562 and sum(v['bytes'] for v in files.values())==361807721 and len(freeze['directories'])==14,'complete frozen scope')
    need(len(old_files)==1377 and set(old_files)<=set(files),'all old v5 frozen physical members retained')
    for k,v in old_files.items():need(v['bytes']==files[k]['bytes'] and v['sha256']==files[k]['sha256'],'old member bytes preserved')
    need(len(freeze['runtime_aliases'])==3,'runtime alias count')
    for v in freeze['runtime_aliases']:need(Path(v['path']).resolve(strict=True).samefile(v['resolved_path']) and ident(v['resolved_path']) in files,'runtime alias frozen target')
    for name in ['empty_python_cache','empty_sourcepath']:
        need(not list((P/name).iterdir()),'empty '+name)
        need(sum(Path(d['path']).samefile(P/name) and d['files']==[] for d in freeze['directories'])==1,'empty dir frozen')
    for v in nested(plan):verify(v)
    stages=['solve_unchanged','solve_S01_release']
    need(plan['schema']=='v71-r9-distinct-pair-plan-v1' and freeze['schema']=='v71-r9-distinct-pair-input-freeze-v1','new current schemas')
    need(plan['order']==stages and set(plan['stages'])==set(stages),'exact ordered pair')
    budget={'maximum_stage_attempts':1,'maximum_concurrency':1,'historical_model_generations':5,'historical_raw_four_fixed_point_calls':2,'historical_raw_four_fixed_point_calls_returned':1,'maximum_future_model_attempts':2,'maximum_model_attempts_per_arm':1,'maximum_raw_call_entries_per_arm':1,'maximum_future_model_generations':2,'maximum_future_raw_four_fixed_point_calls':2,'maximum_total_model_generations_including_preliminary':7,'maximum_total_raw_four_fixed_point_calls':4,'maximum_new_gate_only_model_generations':0,'maximum_new_cross_replays':0,'retries':0}
    for k,v in budget.items():need(type(plan[k]) is int and plan[k]==v,'fixed budget '+k)
    need(plan['capture_limits']=={'raw_stdout_observed_bytes':68719476736,'encoded_stdout_bytes':67108864,'stderr_bytes':67108864},'amended finite same observer')
    old_plan=read(OLD/'PLAN.json')
    for name in stages:
        s=plan['stages'][name];old=old_plan['stages'][name]
        need(s['limits']==old['limits'] and s['env']==old['env'],'all original outer limits and env')
        need(s['argv']==[x.replace(str(OLD),str(P)) for x in old['argv']],'only class/config/output root changes in exact argv')
        need('/realizable' not in s['required_result_fields'],'Boolean value not acceptance criterion')
        for k,v in old['required_result_fields'].items():
            if k!='/schema':need(s['required_result_fields'][k]==v,'old result criterion preserved '+k)
        for k,v in {'/model_generation_attempts':1,'/raw_call_entry_attempts':1,'/raw_four_fixed_point_calls_returned':1,'/model_generation_call_dispatched':True,'/raw_call_dispatch_recorded':True,'/accounting_finalized':True}.items():need(type(s['required_result_fields'][k]) is type(v) and s['required_result_fields'][k]==v,'new required accounting '+k)
    need(plan['supervisor_launch_prefix']==[x.replace(str(OLD),str(P)) for x in old_plan['supervisor_launch_prefix']],'clean outer invocation unchanged')
    need(plan['root_launcher_invocation_prefix'][:-1]==plan['supervisor_launch_prefix'][:-1],'same clean root prefix')
    need(plan['root_launcher_invocation_prefix'][-1]==str(P/'root_launches/launch_stage.py'),'current pinned root launcher')
    for name in ['B_CONFIG.json','origins.properties','RUNTIME_INPUTS.json','RUNTIME_DEPENDENCY_ALIAS_PINS.json','path_identity.py','supervisor_support.py','prior_gate_evidence.py','java/PriorGateEvidence.java','java/BoundedDiagnosticPrintStream.java','classes/PriorGateEvidence.class','classes/BoundedDiagnosticPrintStream.class','classes/BoundedDiagnosticPrintStream$Encoder.class']:
        need((P/name).read_bytes()==(OLD/name).read_bytes(),'byte-identical '+name)
    need(not (P/'B_CONFIG.json').samefile(OLD/'B_CONFIG.json'),'config distinct physical file')
    a=(OLD/'java/ExactBSameSolverDiagnostic.java').read_text();b=(P/'java/ExactBSameSolverDiagnostic.java').read_text()
    start='  static void selectReceipt';end='  public static void main'
    need(a[a.index(start):a.index(end)]==b[b.index(start):b.index(end)],'entire scientific helper method span unchanged')
    need(b.count('BDDGenerator.generateGameModel(')==b.count('solver.checkRealizability()')==b.count('new GR1SeparatedGame(')==1,'single syntactic scientific dispatch sites')
    for n in ['ExactBSameSolverDiagnostic.class','AdoptedV5Evidence.class']:need(68719476736 in longs(P/'classes'/n),'compiled exact long raw cap '+n)
    diff=read(P/'SOURCE_DIFF_MANIFEST.json');sources={str(q.relative_to(P)) for q in P.rglob('*') if q.suffix in ('.py','.java')}
    need(sources=={x['relative_path'] for x in diff['files']} and len(sources)==13,'complete source diff roster')
    changed=[];imports={}
    for row in diff['files']:
        q=verify(row['candidate']);verify(row['diff']);before=''
        if row['baseline']:before=verify(row['baseline']).read_text()
        after=q.read_text();expected_change='ADDED' if row['baseline'] is None else 'UNCHANGED' if before==after else 'MODIFIED'
        need(row['change']==expected_change,'source change classification')
        expected=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile=row['baseline']['path'] if row['baseline'] else '/dev/null',tofile=row['candidate']['path']))
        need(Path(row['diff']['path']).read_text()==expected,'complete actual source diff '+row['relative_path'])
        if expected_change!='UNCHANGED':changed.append(row['relative_path'])
        if q.suffix=='.py':
            tree=ast.parse(after,filename=str(q));compile(tree,str(q),'exec')
            imports[row['relative_path']]=[ast.unparse(x) for x in tree.body if isinstance(x,(ast.Import,ast.ImportFrom))]
    need(set(changed)=={'adopted_v5_evidence.py','java/AdoptedV5Evidence.java','java/ExactBSameSolverDiagnostic.java','root_launches/launch_stage.py','run_bounded_stage.py'},'exact allowed five source changes')
    old_vendor={str(q.relative_to(OLD/'vendor')):q for q in roster(OLD/'vendor')};new_vendor={str(q.relative_to(P/'vendor')):q for q in roster(P/'vendor')}
    need(set(old_vendor)==set(new_vendor),'vendor roster exact')
    for n,q in new_vendor.items():need(q.read_bytes()==old_vendor[n].read_bytes(),'vendor bytes '+n)
    cp=read(P/'CLASSPATH.json')['entries'];old_cp=read(OLD/'CLASSPATH.json')['entries']
    need(cp==[x.replace(str(OLD),str(P)) for x in old_cp] and len(cp)==166,'entire classpath order unchanged except local classes')
    contents={};jars=[]
    for n in cp:
        q=Path(n)
        if q.is_dir():need(any(q.samefile(d['path']) for d in freeze['directories']),'class directory frozen')
        else:
            jars.append(q);need(ident(q) in files,'classpath jar frozen')
            with zipfile.ZipFile(q) as z:
                contents[n]=set(z.namelist());m=z.read('META-INF/MANIFEST.MF').decode() if 'META-INF/MANIFEST.MF' in contents[n] else ''
                need(not any(x.lower().startswith('class-path:') for x in m.replace('\r\n','\n').replace('\n ','').splitlines()),'no extra manifest classpath')
    need(len(jars)==164,'released 164 JARs')
    origins=dict(x.split('=',1) for x in (P/'origins.properties').read_text().splitlines() if x)
    for n,target in origins.items():
        member=n.replace('.','/')+'.class';matches=[x for x in cp if (Path(x).is_dir() and (Path(x)/member).is_file()) or member in contents.get(x,set())]
        need(matches and Path(matches[0]).samefile(target),'first runtime origin '+n)
    c=read(P/'compile_receipts/final_verified_compile.json');cc=read(P/'COMPILED_CLASS_PINS.json')
    need(c['return_code']==0 and c['stdout']==c['stderr']=='' and c['inputs_after_identical'] is True and c['target_classes_executed'] is False,'safe successful compile receipt')
    need(len(c['inputs_before'])==241 and len(c['outputs_after'])==5 and len(c['source_file_pins'])==4,'compile scope')
    need(c['outputs_after']==cc['classes'],'compiled class manifest exact outputs')
    for v in [*c['inputs_before'],*c['outputs_after'],*c['source_file_pins']]:verify(v);need(ident(v['path']) in files,'compile source/input/output frozen')
    argv=c['argv'];need('-proc:none' in argv and '-implicit:none' in argv and c['annotation_processing'] is False and c['implicit_compilation'] is False and c['compiler_plugins']==[],'compiler code execution disabled')
    need(argv[argv.index('-sourcepath')+1]==str(P/'empty_sourcepath') and argv[argv.index('-cp')+1].split(':')==cp[1:],'explicit empty sourcepath and frozen compile classpath')
    need(argv[-4:]==[x['path'] for x in c['source_file_pins']],'exact four explicit sources')
    bridge=read(P/'ADOPTED_V5_EVIDENCE.json')
    for v in nested(bridge):verify(v);need(ident(v['path']) in files,'bridge original evidence frozen')
    need(Path(bridge['historical_root']).samefile(OLD),'actual old v5 root')
    hist={}
    for name in ['historical_gate_adoption','historical_solve_authorization','historical_final_scientific_adoption','historical_prior_gate_bundle']:
        hist[name]=read(bridge[name]['path'])
        for v in nested(hist[name]):verify(v)
    old_auth=hist['historical_solve_authorization'];old_adopt=hist['historical_gate_adoption'];final=hist['historical_final_scientific_adoption']
    need(old_auth['schema']=='v71-r7-v5-root-authorization-v1' and old_auth['status']=='GO_SOLVE_STAGES_ONLY','old GO historical category')
    need(final['history_budget']['total_models']==5 and final['history_budget']['raw_calls_entered']==2 and final['history_budget']['raw_calls_returned']==1 and final['history_budget']['remaining_model_budget']==final['history_budget']['remaining_raw_call_budget']==0,'actual exhausted history')
    cross=read(old_adopt['revalidation']['native_result']['path'])
    need(cross['status']=='PASS_CROSS_ARM_SAVED_PREDICATE_GATE' and len(cross['checks'])==2965 and all(x is True for x in cross['checks'].values()),'actual successful historical saved cross')
    baseline=read(A/'OLD_V5_BASELINE_BEFORE.json');need(Path(baseline['source_directory']).samefile(OLD),'independent initial baseline')
    need({str(q.relative_to(OLD)) for q in roster(OLD)}=={x['path'] for x in baseline['files']},'entire old 155 file roster unchanged')
    for v in baseline['files']:verify({**v,'path':str(OLD/v['path'])})
    for v in baseline['old_root_records']+baseline['preparation_only_authority_and_facts']:verify(v)
    full=read(P/'FILE_ROSTER.json');need({str(q.relative_to(P)) for q in roster(P)}=={x['relative_path'] for x in full['files']}|{'FILE_ROSTER.json','HANDOFF.json'},'entire current prepared 65-file roster exact')
    for row in full['files']:
        verify(row['current'])
        if row['baseline']:verify(row['baseline'])
    need(not (P/'runs').exists() and not (P/'RUN_LOCK.json').exists(),'no scientific execution during static audit')
    need({q.name for q in (P/'root_launches').iterdir()}=={'launch_stage.py'},'no fabricated launch receipts')
    for v in list(observed.values()):need(pin(v['path'])==v,'all observed inputs stable at completion')
    return {'status':'PASS_INDEPENDENT_R9_STATIC_PREEXECUTION_AUDIT','frozen_files':len(files),'frozen_bytes':sum(x['bytes'] for x in files.values()),'directory_rosters':len(freeze['directories']),'old_frozen_members_retained':len(old_files),'old_files_unchanged':len(baseline['files']),'old_root_records_unchanged':len(baseline['old_root_records']),'classpath_entries':len(cp),'released_JARs':len(jars),'class_origins':len(origins),'compile_inputs':len(c['inputs_before']),'compile_outputs':len(c['outputs_after']),'source_files':len(sources),'changed_sources':changed,'python_imports_inspected':imports,'full_raw_capture_QA':'Future separate finite saved-output QA is mandatory before scientific adoption; not performed by this preexecution audit.','science_execution_count':0,'prepared_module_import_count':0,'javac_invocations_by_auditor':0,'GO_issued':False}

if __name__=='__main__':
    target=A/'FINAL_STATIC_VERIFICATION.json'
    if target.exists():raise SystemExit('Refuse overwrite '+str(target))
    result=run();result['assertions']=checks;result['recorded_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    result['observed_file_pins']=list(observed.values())
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('observed_file_pins','python_imports_inspected')},ensure_ascii=False,indent=2))
