"""Root-only, once per stage, one-worker saved-byte QA guardian. Never retries."""
from __future__ import annotations

from pathlib import Path
import ctypes
import hashlib
import json
import os
import resource
import subprocess
import sys
import time

sys.path.insert(0, str(Path(__file__).absolute().parent))
from capture_qa import Budget, CPU_SECONDS, RSS_CAP, WALL_SECONDS, need, ordinary_file, strict_json
from saved_stage_qa import HERE, LIMITS, request_header, verify_code


class TaskInfo(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint64) for name in (
        "virtual_size", "resident_size", "total_user", "total_system", "threads_user", "threads_system")]
    _fields_ += [(name, ctypes.c_int32) for name in (
        "policy", "faults", "pageins", "cow_faults", "messages_sent", "messages_received",
        "syscalls_mach", "syscalls_unix", "csw", "threadnum", "numrunning", "priority")]


def worker_rss(proc):
    # The sole owned Popen child remains unreaped while running, so its PID cannot be reused.
    info = TaskInfo()
    lib = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
    lib.proc_pidinfo.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint64, ctypes.c_void_p, ctypes.c_int]
    lib.proc_pidinfo.restype = ctypes.c_int
    n = lib.proc_pidinfo(proc.pid, 4, 0, ctypes.byref(info), ctypes.sizeof(info))
    if n != ctypes.sizeof(info):
        if proc.poll() is not None:
            return None
        raise RuntimeError("QA_WORKER_RSS_UNREADABLE")
    return int(info.resident_size)


def child_limits():
    resource.setrlimit(resource.RLIMIT_CPU, (CPU_SECONDS, CPU_SECONDS))
    resource.setrlimit(resource.RLIMIT_FSIZE, (1_048_576, 1_048_576))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def stop_owned(proc, actions):
    if proc.poll() is not None:
        return
    proc.terminate(); actions.append("SIGTERM_OWNED_UNREAPED_CHILD")
    try:
        proc.wait(timeout=1)
    except subprocess.TimeoutExpired:
        proc.kill(); actions.append("SIGKILL_OWNED_UNREAPED_CHILD")
        proc.wait(timeout=2)


def main():
    started = time.monotonic()
    need(sys.platform == "darwin", "reviewed guardian requires macOS libproc")
    need(len(sys.argv) == 3, "usage: qa_runner.py ABSOLUTE_ROOT_QA_AUTHORIZATION SHA256")
    path, info = ordinary_file(Path(sys.argv[1]))
    need(info.st_size <= 1_048_576, "bounded root QA authorization")
    data = path.read_bytes()
    need(len(data) == info.st_size and hashlib.sha256(data).hexdigest() == sys.argv[2], "root QA authorization hash")
    request = strict_json(data)
    request_header(request)
    freeze = verify_code(request, Budget(wall=30, cpu=20))
    output_parent = HERE / "executions"
    if output_parent.exists():
        need(output_parent.is_dir() and not output_parent.is_symlink(), "ordinary execution parent")
    else:
        output_parent.mkdir()
    output = output_parent / request["stage"]
    need(Path(request["output_directory"]) == output, "fixed once-per-stage QA output directory")
    output.mkdir()  # Exclusive reservation: even a failed attempt consumes this stage's QA slot.
    reservation = {"schema": "v71-r9-saved-qa-reservation-v1", "stage": request["stage"],
                   "authorization": {"path": str(path), "bytes": len(data), "sha256": sys.argv[2]},
                   "attempts_reserved": 1, "refundable": False, "retries": 0, "limits": LIMITS}
    (output / "RESERVATION.json").write_text(json.dumps(reservation, indent=2) + "\n")
    argv = [freeze["python_executable"]["path"], "-I", "-B", "-S", str(HERE / "qa_worker.py"),
            str(path), sys.argv[2], str(output)]
    environment = {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8"}
    proc = None
    reason = None
    actions = []
    peak = samples = 0
    cleanup_confirmed = False
    with (output / "worker.stdout").open("xb") as stdout, (output / "worker.stderr").open("xb") as stderr:
        try:
            need(time.monotonic() - started < WALL_SECONDS, "QA_WALL_LIMIT_BEFORE_SPAWN")
            proc = subprocess.Popen(argv, cwd=HERE, env=environment, stdin=subprocess.DEVNULL,
                                    stdout=stdout, stderr=stderr, shell=False, preexec_fn=child_limits,
                                    start_new_session=True)
            while proc.poll() is None:
                if time.monotonic() - started >= WALL_SECONDS:
                    reason = "QA_WALL_LIMIT"; break
                rss = worker_rss(proc)
                if rss is not None:
                    peak = max(peak, rss); samples += 1
                    if rss > RSS_CAP:
                        reason = "QA_RSS_LIMIT"; break
                time.sleep(0.1)
        except BaseException as error:
            reason = type(error).__name__ + ": " + str(error)[:1024]
        finally:
            if proc is not None:
                try:
                    stop_owned(proc, actions)
                    proc.wait(timeout=2)
                    cleanup_confirmed = True
                except BaseException as error:
                    reason = (reason or "") + " CLEANUP_UNCONFIRMED: " + str(error)[:1024]
    code = None if proc is None else proc.returncode
    elapsed = time.monotonic() - started
    if elapsed >= WALL_SECONDS and reason is None:
        reason = "QA_WALL_LIMIT_AT_COMPLETION"
    result_path = output / "WORKER_RESULT.json"
    worker_result = None
    if result_path.is_file() and result_path.stat().st_size <= 1_048_576:
        worker_result = strict_json(result_path.read_bytes())
    success = (reason is None and code == 0 and cleanup_confirmed and actions == [] and
               worker_result is not None and worker_result.get("status") == "VERIFIED_CAPTURE_AND_LISTED_ADMINISTRATIVE_CHECKS")
    result = {"schema": "v71-r9-saved-qa-guardian-result-v1", "status": "COMPLETE_QA" if success else "FAILED_OR_INCOMPLETE_QA",
              "authorization": reservation["authorization"], "limits": LIMITS, "argv": argv,
              "environment": environment, "return_code": code, "limit_or_error": reason,
              "signals": actions, "cleanup_confirmed": cleanup_confirmed,
              "elapsed_seconds_including_setup_cleanup": elapsed, "sample_count": samples,
              "sampled_worker_peak_rss_bytes": peak, "poll_seconds": 0.1,
              "cpu_enforcement": "RLIMIT_CPU=240s for sole worker; includes threads; worker never spawns children",
              "rss_scope": "sampled worker RSS plus cooperative self high-water checks; not an instantaneous kernel memory cap",
              "cleanup_allowance_extra_seconds": 3, "retry_authorized": False,
              "scientific_adoption_permitted": False}
    (output / "GUARDIAN_RESULT.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "result": str(output / "GUARDIAN_RESULT.json")}, ensure_ascii=False))
    return 0 if success else 2


if __name__ == "__main__":
    raise SystemExit(main())
