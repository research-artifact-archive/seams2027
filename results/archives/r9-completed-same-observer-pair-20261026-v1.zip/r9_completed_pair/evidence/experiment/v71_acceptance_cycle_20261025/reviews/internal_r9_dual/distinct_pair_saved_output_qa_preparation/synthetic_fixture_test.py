"""Tiny synthetic decoder fixtures only. No preparation/result inputs are opened."""
from pathlib import Path
import base64
import copy
import hashlib
import json
import os
import resource
import signal
import sys

sys.path.insert(0, str(Path(__file__).absolute().parent))
import capture_qa as qa


def enc(value):
    return base64.b64encode(value).decode("ascii")


def line(row):
    return (json.dumps(row, separators=(",", ":")) + "\n").encode("ascii")


def fixture(literal=b"tiny\n", repeats=3, complete=True):
    rows = [{"kind": "dictionary", "id": "cache_lookup", "data": enc(qa.DICTIONARY)},
            {"kind": "bytes", "data": enc(literal)},
            {"kind": "repeat", "id": "cache_lookup", "count": repeats},
            {"kind": "end", "raw_bytes": len(literal) + len(qa.DICTIONARY) * repeats,
             "repeated_lines": repeats}]
    encoded = b"".join(line(row) for row in rows)
    raw = literal + qa.DICTIONARY * repeats  # Fixture ceiling 1.1 MiB; production decoder never does this.
    receipt = {"schema": qa.SCHEMA, "capture_complete": complete, "raw_bytes": len(raw),
               "raw_sha256": hashlib.sha256(raw).hexdigest(), "encoded_bytes": len(encoded),
               "encoded_sha256": hashlib.sha256(encoded).hexdigest(), "repeated_lines": repeats,
               "unflushed_repeated_lines": 0, "records": len(rows), "raw_cap_bytes": qa.RAW_CAP,
               "encoded_cap_bytes": qa.ENCODED_CAP, "cap_reached": not complete,
               "diagnostic_line_base64": enc(qa.DICTIONARY), "capture_error": None if complete else "RAW_STDOUT_CAP"}
    return rows, encoded, receipt


def main():
    resource.setrlimit(resource.RLIMIT_CPU, (10, 10))
    resource.setrlimit(resource.RLIMIT_FSIZE, (2_097_152, 2_097_152))
    signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(RuntimeError("SYNTHETIC_WALL_LIMIT")))
    signal.alarm(15)
    budget = qa.Budget(wall=15, cpu=10, rss=268_435_456)
    folder = Path(__file__).absolute().parent / "synthetic_fixtures_run_1"
    folder.mkdir()
    tests = []

    def test(name, data, receipt, mode="COMPLETE", expected="reject", expected_error=None):
        budget.check()
        path = folder / (name + ".jsonl")
        path.write_bytes(data)
        pin = {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
        receipt_path = folder / (name + ".receipt.json")
        receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
        try:
            answer = qa.audit_capture(pin, receipt, mode, budget)
            outcome = "accept"
            error = None
        except qa.QAError as exception:
            answer = None
            outcome = "reject"
            error = str(exception)
        passed = outcome == expected and (expected_error is None or expected_error in (error or ""))
        tests.append({"name": name, "input": pin, "receipt": str(receipt_path), "mode": mode,
                      "expected": expected, "expected_error_substring": expected_error,
                      "actual": outcome, "error": error, "answer": answer, "passed": passed})
        qa.need(passed, "synthetic fixture failed: " + name)

    rows, data, receipt = fixture()
    test("complete", data, receipt, expected="accept")
    _, large_data, large_receipt = fixture(repeats=20_000)
    test("reusable_block_and_remainder", large_data, large_receipt, expected="accept")
    _, literal_data, literal_receipt = fixture(literal=b"a" * 65_536, repeats=1)
    test("maximum_literal", literal_data, literal_receipt, expected="accept")
    _, prefix, prefix_receipt = fixture(complete=False)
    test("framed_incomplete_prefix", prefix, prefix_receipt, "PREFIX", "accept")
    test("prefix_cannot_upgrade", prefix, prefix_receipt, expected_error="complete capture")
    test("complete_receipt_cannot_claim_prefix", data, receipt, "PREFIX", expected_error="explicitly be incomplete")
    partial = b"".join(line(row) for row in rows[:2])
    test("receiptless_framed_prefix", partial, None, "PREFIX", "accept")
    test("receiptless_truncated_tail", partial + b'{"kind":"repeat",', None, "PREFIX", "accept")
    pending = copy.deepcopy(prefix_receipt)
    pending.update(encoded_bytes=len(partial), encoded_sha256=hashlib.sha256(partial).hexdigest(),
                   records=2, unflushed_repeated_lines=3, capture_error="ENCODED_STDOUT_CAP")
    test("unflushed_tail_not_hashed", partial, pending, "PREFIX", "accept")
    test("nonzero_unflushed_with_end", prefix, pending, "PREFIX", expected_error="encoded/record counts")
    def changed(index, row):
        changed_rows = copy.deepcopy(rows); changed_rows[index] = row
        return b"".join(line(item) for item in changed_rows)
    test("duplicate_key", data.replace(b'"count":3', b'"count":3,"count":3'), receipt,
         expected_error="duplicate JSON")
    test("extra_key", changed(2, {**rows[2], "extra": 0}), receipt, expected_error="exact repeat fields")
    test("nonfinite", data.replace(b'"count":3', b'"count":NaN'), receipt, expected_error="nonfinite")
    for label, value in [("boolean", True), ("float", 3.0), ("string", "3"), ("negative", -1), ("too_large", 1_000_001)]:
        test("repeat_" + label, changed(2, {**rows[2], "count": value}), receipt,
             expected_error="invalid integer")
    test("repeat_zero", changed(2, {**rows[2], "count": 0}), receipt, expected_error="positive repeat")
    test("dictionary_mismatch", changed(0, {**rows[0], "data": enc(b"wrong\n")}), receipt,
         expected_error="single first dictionary")
    test("second_dictionary", changed(1, rows[0]), receipt, expected_error="unknown kind")
    test("malformed_base64", changed(1, {**rows[1], "data": "!!!!"}), receipt, expected_error="malformed base64")
    test("empty_literal", changed(1, {**rows[1], "data": ""}), receipt, expected_error="nonempty bounded")
    test("oversized_literal", changed(1, {**rows[1], "data": enc(b"x" * 65_537)}), receipt,
         expected_error="noncanonical or oversized")
    test("oversized_line", b"x" * (qa.LINE_CAP + 1), None, "PREFIX", expected_error="JSON line exceeds")
    test("missing_end", data[:data.rfind(b'{"kind":"end"')], receipt, expected_error="encoded/record counts")
    test("after_end", data + line(rows[1]), receipt, expected_error="after terminal")
    test("wrong_end_count", changed(3, {**rows[3], "raw_bytes": receipt["raw_bytes"] + 1}), receipt,
         expected_error="terminal totals")
    wrong = {**receipt, "raw_sha256": "0" * 64}
    test("wrong_raw_digest", data, wrong, expected_error="raw digest mismatch")
    test("wrong_encoded_digest", data, {**receipt, "encoded_sha256": "0" * 64}, expected_error="encoded/record counts")
    test("receipt_count_boolean", data, {**receipt, "records": True}, expected_error="invalid integer")
    test("wrong_cap", data, {**receipt, "raw_cap_bytes": 67_108_864}, expected_error="exact R9 capture caps")
    test("receipt_raw_admission_before_hash", data, {**receipt, "raw_bytes": 5}, expected_error="receipt raw total")
    # Exact 64 GiB boundary checked with arithmetic only, without constructing/hashing a huge stream.
    arithmetic = []
    for current, added, expected in [(qa.RAW_CAP - 54, 54, True), (qa.RAW_CAP - 53, 54, False),
                                     (qa.RAW_CAP, 0, True), (qa.RAW_CAP, 1, False)]:
        try:
            qa.admit_raw(current, added); actual = True
        except qa.QAError:
            actual = False
        qa.need(actual is expected, "64 GiB boundary arithmetic")
        arithmetic.append({"current": current, "added": added, "expected": expected, "actual": actual})
    result = {"schema": "v71-r9-qa-tiny-synthetic-fixtures-v1", "all_passed": True,
              "tests": tests, "arithmetic_boundary_tests": arithmetic,
              "limits": {"wall_seconds": 15, "cpu_seconds": 10, "rss_bytes": 268435456,
                         "max_fixture_expanded_raw_bytes": 1_100_000, "production_results_read": 0},
              "resources": budget.report(), "scientific_execution": False}
    (folder / "RESULT.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    signal.alarm(0)
    print(json.dumps({"all_passed": True, "decoder_tests": len(tests), "boundary_tests": len(arithmetic),
                      "result": str(folder / "RESULT.json")}))


if __name__ == "__main__":
    main()
