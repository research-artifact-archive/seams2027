"""Final immutable-evidence QA only; never repeats raw expansion or science."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import os
import shlex
import stat

A=Path(__file__).resolve().parent;O=A.parents[2];S=O/'research_strategy_after_r6'
P=S/'r9_same_observer_pair_preparation_v1';OLD=S/'same_solver_diagnostic_preparation_saved_cross_v5'
D=S/'root_review_integration';Q=A.parent/'distinct_pair_saved_output_qa_preparation';PRE=A.parent/'distinct_pair_preexecution'
observed={};checks=0
def need(ok,label):
    global checks
    checks+=1
    if not ok:raise ValueError(label)
def key(p):
    s=Path(p).stat();return s.st_dev,s.st_ino
def pin(p):
    p=Path(p);s=p.stat();need(p.is_absolute() and stat.S_ISREG(s.st_mode),'absolute regular')
    for z in [p,*p.parents]:need(not z.is_symlink(),'no input symlink')
    h=hashlib.sha256();total=0
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b);total+=len(b)
    t=p.stat();need((s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns),'stable hashing input')
    v={'path':str(p),'bytes':total,'sha256':h.hexdigest()};need(observed.setdefault(str(p),v)==v,'observed pin unchanged');return v
def verify(v):
    need(set(v)=={'path','bytes','sha256'} and type(v['bytes']) is int and v['bytes']>=0,'strict pin')
    need(pin(v['path'])==v,'exact bytes SHA '+v['path']);return Path(v['path'])
def same(a,b):
    verify(a);verify(b);need(Path(a['path']).samefile(b['path']) and a['bytes']==b['bytes'] and a['sha256']==b['sha256'],'physical exact pin agreement')
def pairs(items):
    d={}
    for k,v in items:need(k not in d,'duplicate JSON key');d[k]=v
    return d
def read(p):
    pin(p);return json.loads(Path(p).read_text(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def pins(v):
    if isinstance(v,dict):
        if set(v)=={'path','bytes','sha256'}:yield v
        else:
            for x in v.values():yield from pins(x)
    elif isinstance(v,list):
        for x in v:yield from pins(x)
def roster(p):
    result=[]
    for b,ds,fs in os.walk(p,followlinks=False):
        for n in ds+fs:need(not (Path(b)/n).is_symlink(),'no roster symlink')
        result.extend(Path(b)/n for n in fs)
    return result

def run():
    admin=read(A/'ADMINISTRATIVE_AND_DESCRIPTOR_QA.json')
    need(pin(A/'ADMINISTRATIVE_AND_DESCRIPTOR_QA.json')['sha256']=='25dd69d360347d091b01fc0fe258b85692ca08055f3b5a5acd387a316b27e809','prior full independent admin QA unchanged')
    for v in admin['observed_file_pins']:verify(v)
    bytecheck=read(A/'EXACT_MODEL_BYTE_COMPARISON.json')
    for row in bytecheck['comparisons']:
        need(verify(row['current']).read_bytes()==verify(row['historical_v5']).read_bytes(),'all four actual current/historical model JSON bytes identical')
    initial=read(A/'COMPLETED_PAIR_BASELINE_BEFORE_QA.json')
    for v in initial['files']:verify(v)
    actual=roster(P/'runs')+roster(P/'root_launches')
    need(len(actual)==len(initial['files'])==97 and {key(p) for p in actual}=={key(v['path']) for v in initial['files']},'all97 completed pair files/roster unchanged after raw QA')
    freeze=read(P/'INPUT_FREEZE.json')
    for d in freeze['directories']:
        actual=roster(d['path']);expected={key(Path(d['path'])/v['relative_path']) for v in d['files']}
        need(len(actual)==len(expected) and {key(p) for p in actual}==expected,'entire scientific frozen directory roster retained')
    for alias in freeze['runtime_aliases']:need(Path(alias['path']).resolve(strict=True).samefile(alias['resolved_path']),'runtime alias unchanged')
    old=read(PRE/'OLD_V5_BASELINE_BEFORE.json')
    need({str(p.relative_to(OLD)) for p in roster(OLD)}=={v['path'] for v in old['files']},'old155 file roster unchanged')
    for v in old['files']:verify({**v,'path':str(OLD/v['path'])})
    for v in old['old_root_records']:verify(v)
    code_review=read(A/'QA_CODE_REVIEW_HANDOFF.json');code_static=read(A/'QA_CODE_STATIC_VERIFICATION.json')
    need(pin(A/'QA_CODE_REVIEW_HANDOFF.json')['sha256']=='63611ff86ff82667f5df96941b96ffe6c6a2ed6827a633fb3075f8bb6d022da8','exact independent code review')
    for v in code_static['files']:verify(v)
    for v in pins(code_review):verify(v)
    qa_roster=read(Q/'FILE_ROSTER.json');qa_freeze=read(Q/'CODE_FREEZE.json')
    for v in qa_roster['files']:verify(v)
    for v in pins(qa_freeze):verify(v)
    need({p.name for p in (Q/'executions').iterdir()}=={'solve_unchanged','solve_S01_release'},'exactly two exclusive QA attempt directories')
    expected_q={v['path'] for v in qa_roster['files']}|{str(Q/'FILE_ROSTER.json'),str(Q/'HANDOFF.json')}
    for stage in ['solve_unchanged','solve_S01_release']:
        for n in ['RESERVATION.json','worker.stdout','worker.stderr','WORKER_RESULT.json','GUARDIAN_RESULT.json']:expected_q.add(str(Q/'executions'/stage/n))
    need({str(p) for p in roster(Q)}==expected_q and len(expected_q)==89,'79 frozen QA files plus exact10 runtime outputs, no added code/cache')
    approved=read(D/'ROOT_R9_SAVED_QA_APPROVED_COMMANDS.json');tool=read(D/'ROOT_R9_SAVED_QA_ACTUAL_TOOL_RECEIPTS.json')
    for v in pins(approved):verify(v)
    root_review=read(approved['root_code_review']['path'])
    for v in pins(root_review):verify(v)
    need(tool['root_only'] is True and tool['scientific_execution'] is False and tool['no_retries'] is True,'root-only no-science actual tool receipt')
    need(tool['unchanged']['exit_code']==tool['S01_completion']['exit_code']==0 and type(tool['S01_initial']['session_id']) is int,'two one-shot actual completed tool executions; S01 completion resumes same session')
    need([v['stage'] for v in approved['launches']]==['solve_unchanged','solve_S01_release'],'approved serial pair order')
    first=Q/'executions/solve_unchanged/GUARDIAN_RESULT.json';second=Q/'executions/solve_S01_release/RESERVATION.json'
    need(first.stat().st_mtime_ns<second.stat().st_mtime_ns,'saved filesystem ordering corroborates root serial execution receipt')
    limits={'wall_seconds':300,'cpu_seconds':240,'sampled_worker_rss_bytes':1073741824,'encoded_bytes':67108864,'raw_bytes':68719476736,'workers':1,'retries':0}
    results={}
    for launch,arm in zip(approved['launches'],['unchanged','S01_release']):
        stage=launch['stage'];folder=Q/'executions'/stage;auth_pin=launch['authorization'];auth=read(verify(auth_pin));g=read(folder/'GUARDIAN_RESULT.json');w=read(folder/'WORKER_RESULT.json');r=read(folder/'RESERVATION.json')
        for v in pins([auth,g,w,r]):verify(v)
        need(auth['schema']=='v71-r9-one-saved-capture-qa-authorization-v1' and auth['status']=='GO_VERIFY_ONE_SAVED_STAGE' and auth['executor']=='root only' and auth['stage']==stage and auth['mode']=='COMPLETE' and type(auth['maximum_attempts']) is int and auth['maximum_attempts']==1,'separate exact one-shot COMPLETE QA authorization')
        need(auth['limits']==limits and all(type(v) is int for v in auth['limits'].values()) and auth['remaining_review_acknowledged'] is True,'strict fixed finite QA limits')
        same(auth['review_handoff'],pin(A/'QA_CODE_REVIEW_HANDOFF.json'));same(auth['qa_code_freeze'],pin(Q/'CODE_FREEZE.json'))
        need(Path(auth['output_directory']).samefile(folder),'current exact exclusive output directory')
        expected=[qa_freeze['python_executable']['path'],'-I','-B','-S',str(Q/'qa_runner.py'),auth_pin['path'],auth_pin['sha256']]
        need(launch['argv']==expected and shlex.split(launch['command'])==expected,'approved concrete exact guardian invocation')
        expected_worker=[qa_freeze['python_executable']['path'],'-I','-B','-S',str(Q/'qa_worker.py'),auth_pin['path'],auth_pin['sha256'],str(folder)]
        need(g['argv']==expected_worker and g['environment']=={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8'},'actual sole isolated worker invocation and clean environment')
        same(g['authorization'],auth_pin);same(w['qa_authorization'],auth_pin);same(r['authorization'],auth_pin)
        need(g['status']=='COMPLETE_QA' and type(g['return_code']) is int and g['return_code']==0 and g['limit_or_error'] is None and g['signals']==[] and g['cleanup_confirmed'] is True and g['retry_authorized'] is False,'actual guardian complete, no limits/signals, owned worker reaped')
        need(g['limits']==r['limits']==limits and r['attempts_reserved']==1 and r['refundable'] is False and r['retries']==0,'one consumed nonrefundable QA attempt')
        need(0<g['elapsed_seconds_including_setup_cleanup']<300 and type(g['sample_count']) is int and g['sample_count']>0 and 0<g['sampled_worker_peak_rss_bytes']<=1073741824,'guardian finite resource observations')
        need((folder/'worker.stdout').read_bytes()==(folder/'worker.stderr').read_bytes()==b'','worker raw streams empty')
        pin(folder/'worker.stdout');pin(folder/'worker.stderr')
        need(w['status']=='VERIFIED_CAPTURE_AND_LISTED_ADMINISTRATIVE_CHECKS' and w['stage']==stage and w['inputs']==auth['inputs'],'exact worker status/stage/input pins')
        conditions=w['observed_completion_conditions'];need(len(conditions)==24 and all(v is True for v in conditions.values()) and w['all_listed_completion_conditions'] is True,'all24 completion conditions genuinely true')
        resources=w['qa_resources'];need(0<resources['wall_seconds']<300 and 0<=resources['cpu_seconds']<240 and 0<resources['rss_peak_bytes']<=1073741824 and resources['cooperative_checks']>0,'worker completed within fixed CPU/wall/highwater allowance')
        c=w['capture'];receipt=read(auth['inputs']['capture_receipt']['path']);native=read(auth['inputs']['native']['path'])
        need(c['status']=='VERIFIED_COMPLETE_CAPTURE' and c['mode']=='COMPLETE' and c['capture_complete_verified'] is True and c['all_admitted_raw_digest_verified'] is True,'both complete whole raw-integrity conditions')
        need(c['terminal_end_present'] is True and c['unparsed_tail_bytes']==c['unflushed_repeats_not_reconstructed']==0 and c['maximum_reusable_raw_block_bytes']==1048572,'complete terminal and bounded reusable block')
        for a,b in [('framed_raw_bytes','raw_bytes'),('framed_raw_sha256','raw_sha256'),('encoded_bytes','encoded_bytes'),('encoded_sha256','encoded_sha256'),('records','records'),('repeated_lines','repeated_lines')]:need(type(c[a]) is type(receipt[b]) and c[a]==receipt[b],'independently computed whole capture matches native receipt '+a)
        need(c['framed_raw_bytes']==54*c['repeated_lines']+c['literal_bytes'] and c['records']==c['repeat_records']+c['literal_records']+2,'full raw/record accounting')
        need(c['terminal']=={'kind':'end','raw_bytes':c['framed_raw_bytes'],'repeated_lines':c['repeated_lines']},'exact verified terminal counters')
        encoded=pin(auth['inputs']['encoded_stream']['path']);need(c['encoded_bytes']==encoded['bytes'] and c['encoded_sha256']==encoded['sha256'],'actual immutable encoded payload pin')
        need(native['realizable'] is admin['arms'][arm]['observed_returned_boolean'],'returned Boolean matches fully reviewed native facts')
        same(auth['inputs']['native'],admin['arms'][arm]['native_result']);same(auth['inputs']['supervisor'],admin['arms'][arm]['supervisor']);same(auth['inputs']['launch'],admin['arms'][arm]['actual_launch'])
        complete_tool=tool['unchanged'] if arm=='unchanged' else tool['S01_completion'];entry=json.loads(complete_tool['output']);need(entry['status']=='COMPLETE_QA' and Path(entry['result']).samefile(folder/'GUARDIAN_RESULT.json'),'actual root tool output binds current guardian result')
        results[arm]={'stage':stage,'returned_raw_four_fixed_point_boolean':native['realizable'],'scientific_native_result':auth['inputs']['native'],'scientific_supervisor':auth['inputs']['supervisor'],'scientific_actual_launch':auth['inputs']['launch'],'qa_authorization':auth_pin,'qa_guardian':pin(folder/'GUARDIAN_RESULT.json'),'qa_worker':pin(folder/'WORKER_RESULT.json'),'full_raw_bytes':c['framed_raw_bytes'],'full_raw_sha256':c['framed_raw_sha256'],'encoded_bytes':c['encoded_bytes'],'encoded_sha256':c['encoded_sha256'],'records':c['records'],'repeated_lines':c['repeated_lines'],'literal_bytes':c['literal_bytes'],'all24completionconditions':True,'qa_resources':resources,'qa_guardian_elapsed_seconds':g['elapsed_seconds_including_setup_cleanup']}
    need(results['unchanged']['returned_raw_four_fixed_point_boolean'] is False and results['S01_release']['returned_raw_four_fixed_point_boolean'] is True,'record observed paired false/true result, not a prior acceptance criterion')
    need(not (P/'RUN_LOCK.json').exists(),'no unresolved scientific lock')
    for v in list(observed.values()):need(pin(v['path'])==v,'all final evidence stable before handoff')
    return {'schema':'v71-r9-independent-complete-pair-result-qa-v1','status':'PASS_COMPLETE_INDEPENDENT_RESULT_QA_READY_FOR_ROOT_SCIENTIFIC_ADOPTION','arms':results,'history':admin['history'],'full_raw_bytes_verified_total':sum(v['full_raw_bytes'] for v in results.values()),'full_raw_digest_execution_scope':'Root ran each separately authorized reviewed guardian/worker once. This independent auditor reviewed source, actual records and all final bound evidence; raw expansion was not rerun.','preservation':{'completed_scientific_run_and_launch_files_unchanged':97,'old_v5_files_unchanged':155,'old_ROOT_V5_records_unchanged':10,'all_scientific_frozen_directory_rosters_unchanged':14,'all_QA_preparation_files_unchanged':79,'exact_new_QA_output_files':10},'no_blocking_findings':True,'raw_expansion_repeated_by_auditor':False,'science_executed_by_auditor':False,'root_scientific_adoption_still_required':True,'interpretation':'At this exact B and pinned configuration, the fresh same-observer unchanged arm returned false and sole typed-S01 release arm returned true. Both complete full captures, all identity/equality gates and finite QA passed. This does not identify the historical GUI cause, establish global raw/strict/Kind equivalence, validate a complete pipeline/extraction or close unrelated UNKNOWN cases. Old v5 false/UNKNOWN remains unchanged.'}

if __name__=='__main__':
    target=A/'FINAL_COMBINED_RESULT_QA.json'
    if target.exists():raise SystemExit('Refuse overwrite '+str(target))
    result=run();result['assertions']=checks;result['created_utc']=dt.datetime.now(dt.timezone.utc).isoformat();result['input_pins']=list(observed.values());target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'assertions':checks,'bound_file_records':len(observed),'full_raw_bytes_verified_total':result['full_raw_bytes_verified_total'],'output':pin(target)},ensure_ascii=False,indent=2))
