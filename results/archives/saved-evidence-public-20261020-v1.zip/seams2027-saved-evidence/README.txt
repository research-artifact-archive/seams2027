Saved evidence and bounded verification supplement — 18 October 2026

This ZIP is the distribution artifact. It contains the unchanged saved-evidence
package and a small wrapper that connects paper claims, historical outcomes,
and the measured verification receipts. It does not reproduce native synthesis
or add scientific samples. Component rights and redistribution scope remain as
stated in package/LICENSES_AND_SCOPE.txt; packaging is not a publication decision.

Start here
  READER_GUIDE.txt                 Paper-to-evidence reading instructions.
  PAPER_EVIDENCE_INDEX.tsv         Claim and evidence locations.
  EVIDENCE_FILES.tsv               Additional evidence file identities.
  VERIFIED_STATUS.json            Current verification scope.
  verification/FILE_INDEX.json    Descriptor of the compressed receipt ledger.
  package/MANIFEST.json            Immutable inner-package file identities.

Primary verification
All 32 listed saved-data route/case checks ran against inner manifest
adc9466569209fab91ecd0085ccca41633409bca8d1e7ad80d4d782fb48d3607.
There are 31 PASS_SAVED_EVIDENCE_RECHECK results and one intentionally preserved
EXPECTED_UNKNOWN_REPRODUCED result: ordinal 07, lift__preferred. This is a count
of verification operations, not additional scientific cases or synthesis runs.
The public fixed denominator, original UNKNOWNs, native refusal and constructed
controls retain the distinctions explained by the reader guide.

The primary compact result, root acceptance and independent phase review are
verification/SAME_MANIFEST_32_COMPACT.json.gz,
verification/ROOT_ALL32_ACCEPTANCE.json.gz and
verification/INDEPENDENT_PHASE_REVIEW.json.gz. Per-case receipts are under
verification/runs/01 through 32. The TSV provides a quick summary.
Additional evidence archives and historical replay entrypoints have not been
qualified for extra scientific replay by these 32 operations.

The inner package is immutable. Its README and PREPARATION_STATUS describe the
earlier preparation stage and are retained verbatim; the later measured status
is recorded in this outer wrapper. No historic receipt has been relabeled as a
new run. A different Python consumer check, if performed, is a separate companion
receipt bound to this final ZIP digest; do not infer it from primary results.

Three byte identities
Recorded original execution hashes still identify the original receipts.
Anonymous expanded receipts change only recorded path strings; scientific
values, original hash fields, keys, types and array order remain unchanged.
The distributed gzip bytes have a third identity. FILE_INDEX.json identifies
the compressed full ledger and its expanded bytes. Each ledger entry records
all three sizes/hashes. PATH_ADAPTATIONS.json.gz records every changed pointer.
Never compare an original digest with projected or compressed bytes.

Logical links use expanded: for an anonymous receipt listed in the gzip ledger,
outer: for a path relative to the ZIP's top directory, origin: for a historical
workspace-relative identity, and external: for an opaque historical identity.
origin: and external: references are not promises that those files are present,
and never provide a runtime fallback. Decompress receipt JSON in memory or into
another fresh directory; keep the inspection tree unchanged.

Archive inspection and extraction
Use a trusted copy of verify_archive.py and an independently recorded ZIP SHA256.
The same script is inside the archive for inspection. Python 3.10+ and its
standard library are sufficient for this archive check. For example:

  python3 -I -S -B verify_archive.py /absolute/path/evidence.zip \
    --expected-sha256 INDEPENDENTLY_RECORDED_ZIP_SHA256 \
    --receipt /absolute/path/new-zip-check.json

To decode and write every member into one new inspection directory, add:

    --extract-to /absolute/path/new-inspection-directory

The destination parent must exist; the destination itself must not exist.
The receipt must be a new file outside that directory. The script rejects
duplicate, absolute, parent-traversal, backslash, Windows-drive and symlink
members; verifies size caps, exact checksum coverage and CRC; then writes and
rehashes every member. It checks a 1 GiB free-space floor before and during
extraction, plus an explicit operation reserve. It preserves partial output on
failure and never overwrites, removes files, or runs scientific code.
The decoded package is new-inspection-directory/seams2027-saved-evidence/package.

One representative saved-evidence route
CONSUMER_RECIPE.txt is the complete copy-and-run recipe. It creates one fresh
request and output directory for original_initial_K_V / arbiter__preferred,
then invokes the existing bounded driver. Creating the request and invoking the
command is the consumer's explicit choice; GO is the driver's request label,
and does not require permission from an author, research agent or maintainer.
Historical GOs must not be reused. The recipe includes the exact eleven request
fields, unchanged limits, a 15-minute deadline, commands and expected results.

The expected result is PASS_SAVED_EVIDENCE_RECHECK with both original initial
predicates I_M_K_universal_predicate and I_M_V_universal_predicate still false.
This successful negative-result recheck does not make the contract cooperatively
feasible. All outputs stay outside the immutable package. The recipe explains
UNKNOWN results, clean finalization, saved-region premises, and the tested
macOS/POSIX environment. Reading or extracting the archive does not start a run.

Inspection-tree lifecycle
The final ZIP remains the formal distribution. The companion consumer receipt
states how its temporary inspection tree was constructed. Full-scale normal ZIP
extraction may be NOT_RUN_CAPACITY. ZIP roundtrip byte verification plus an
independently relocated clone-based consumer test is a distinct, narrower check:
every ZIP member is decoded and verified; package files are independent-inode
copy-on-write clones of the immutable package; outer files are written from ZIP
decoded bytes; every resulting tree file is compared directly with its ZIP member.
This must not be described as a full fresh normal ZIP extraction.

Consumer qualifications and the representative saved case are separately scoped.
After independent closure and a full ZIP/member unchanged check, only a separate
explicit cleanup authorization may remove that new temporary inspection tree.
The ZIP, companion verification receipts, original package and existing research
records remain. This archive and its verifier never perform that cleanup.
