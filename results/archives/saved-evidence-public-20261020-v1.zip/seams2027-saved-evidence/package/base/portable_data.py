"""Closed package paths, original/copy pin distinction, source profiles only.

No BDD, game, controller or fairness algorithms are defined or imported here.
"""
from pathlib import Path
import ast,gzip,hashlib,json,posixpath,re

ROOT=Path(__file__).resolve().parent
E='evidence/experiment/seams_research_reframing_20261017/'
MAX_FILE_BYTES=128*1024*1024

class InvalidPackage(ValueError):pass
def require(x,why):
    if not x:raise InvalidPackage(why)
def unique(pairs):
    out={}
    for k,v in pairs:
        require(k not in out,'Duplicate JSON key');out[k]=v
    return out
def sha(raw):return hashlib.sha256(raw).hexdigest()
def json_bytes(raw):return json.loads(raw,object_pairs_hook=unique)
def source_imports(raw,name):
    toks=re.findall(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[A-Za-z_]\w*|\S',raw.decode('utf-8-sig'),re.S)
    toks=[t for t in toks if not t.startswith(('/*','//'))];out=[]
    for i,t in enumerate(toks):
        if t!='import':continue
        require(i+1<len(toks)and toks[i+1][0]in ('"',"'"),'Nonliteral import')
        val=toks[i+1][1:-1];require('\\'not in val,'Escaped import')
        val=posixpath.normpath(posixpath.join(posixpath.dirname(name),val))
        require(not val.startswith('/')and '..'not in val.split('/'),'Import escapes archive root');out.append(val)
    return out

class Package:
    def __init__(self,root=ROOT,verify=True):
        self.root=Path(root).resolve();self.index={};self.origins={}
        self.manifest=json_bytes((self.root/'MANIFEST.json').read_bytes())
        require(self.manifest.get('schema')=='all-cohort-offline-review-manifest-v1','Manifest schema')
        require(self.manifest.get('historical_evidence_not_fresh_computation')is True,'Historical status boundary')
        rows=self.manifest.get('files');require(isinstance(rows,list)and 1<=len(rows)<=20000,'Manifest roster cap')
        for r in rows:
            require(set(r)=={'file','bytes','sha256'},'Exact manifest pin schema')
            name=r['file'];require(name not in self.index and name!='MANIFEST.json'and not name.startswith('runs/'),'Duplicate/reserved manifest name')
            require(type(r['bytes'])is int and 0<=r['bytes']<=MAX_FILE_BYTES,'Manifest byte cap/type')
            require(type(r['sha256'])is str and re.fullmatch('[0-9a-f]{64}',r['sha256']),'Manifest digest')
            self.path(name);self.index[name]=r
        if verify:self.verify_files()
        origin=self.read('ORIGIN_DIGESTS.json')
        for r in origin['files']:
            name=r['file'];require(name not in self.origins and name in self.index,'Origin unique/staged file')
            require(self.index[name]['bytes']==r['copy_bytes']and self.index[name]['sha256']==r['copy_sha256'],'Copy digest binding')
            if r['transformation']=='BYTE_IDENTICAL':require((r['origin_bytes'],r['origin_sha256'])==(r['copy_bytes'],r['copy_sha256']),'False byte identity')
            else:require(r['transformation']=='PATH_STRINGS_ONLY','Unknown transformation')
            if Path(name).suffix in ('.py','.bdd','.spectra','.gz'):
                require(r['transformation']=='BYTE_IDENTICAL','Mathematical code/source/BDD/export must be byte-identical')
            self.origins[name]=r
        self.authority=self.read('SOURCE_AUTHORITY.json');self.profiles={p['fixture_id']:p for p in self.authority['corpus_profiles']}
        require(len(self.profiles)==len(self.authority['corpus_profiles'])==425,'Source-unit profile roster')
    def path(self,name,file=True):
        require(type(name)is str and name and not name.startswith('/')and '\\'not in name,'Relative path required')
        require(name==Path(name).as_posix()and all(p not in ('','.','..')for p in name.split('/')),'Noncanonical path')
        p=self.root
        for part in name.split('/'):
            p/=part;require(not p.is_symlink(),'Symlink package path')
        require(p.resolve().is_relative_to(self.root),'Escaping package path')
        require(p.is_file()if file else p.exists(),'Missing package path '+name)
        return p
    def reference(self,name,file=True):
        require(type(name)is str and name.startswith('pkg:'),'External or unresolved path is not an offline input')
        rel=name[4:]
        if file:require(rel in self.index,'Unmanifested input')
        return self.path(rel,file=file)
    def name(self,p):
        p=Path(p).resolve();require(p.is_relative_to(self.root),'Read outside package')
        name=p.relative_to(self.root).as_posix();require(name in self.index,'Read unmanifested file');return name
    def raw(self,name):
        require(name in self.index,'Unmanifested file');r=self.index[name];raw=self.path(name).read_bytes()
        require(len(raw)==r['bytes']and sha(raw)==r['sha256'],'File byte/hash drift: '+name);return raw
    def read(self,name):return json_bytes(self.raw(name))
    def verify_files(self):
        actual=set()
        for p in self.root.rglob('*'):
            name=p.relative_to(self.root).as_posix()
            if name=='runs'or name.startswith('runs/'):continue
            require(not p.is_symlink(),'Unlisted symlink')
            if p.is_file()and name!='MANIFEST.json':actual.add(name)
        require(actual==set(self.index),'Manifest must enumerate every package file')
        for name in self.index:self.raw(name)
    def origin_pin(self,ref):
        require(isinstance(ref,dict)and {'path','bytes','sha256'}<=set(ref),'Historical pin schema')
        path=self.reference(ref['path']);name=self.name(path);r=self.origins.get(name)
        require(r is not None and ref['bytes']==r['origin_bytes']and ref['sha256']==r['origin_sha256'],'Historical pin differs from the admitted original: '+name)
        return path
    def copied_pin(self,name,path_key='path'):
        r=self.index[name];return {path_key:str(self.path(name)),'bytes':r['bytes'],'sha256':r['sha256']}
    def materialize(self,obj,containing):
        """Relocate paths and verify origin pins before rebinding to copied bytes.

        This is an I/O metadata adapter only. Numerical, Boolean, root-ID, typed
        field, justice, graph/rank/memory and canonical-function values stay put.
        """
        if isinstance(obj,dict):
            out={k:self.materialize(v,containing)for k,v in obj.items()}
            if {'path','bytes','sha256'}<=set(obj)and isinstance(obj['path'],str)and obj['path'].startswith('pkg:'):
                p=self.origin_pin(obj);out.update(self.copied_pin(self.name(p)))
            elif {'file','bytes','sha256'}<=set(obj)and isinstance(obj['file'],str)and Path(obj['file']).name==obj['file']:
                name=(Path(containing).parent/obj['file']).as_posix()
                if name in self.index:
                    r=self.origins[name]
                    require((obj['bytes'],obj['sha256'])==(r['origin_bytes'],r['origin_sha256']),'Native basename origin pin mismatch')
                    out.update(bytes=self.index[name]['bytes'],sha256=self.index[name]['sha256'])
            if 'model_sha256'in obj:
                model=(Path(containing).parent/'model.json').as_posix()
                if model in self.origins:
                    require(obj['model_sha256']==self.origins[model]['origin_sha256'],'Graph origin model binding')
                    out['model_sha256']=self.index[model]['sha256']
            return out
        if isinstance(obj,list):return [self.materialize(v,containing)for v in obj]
        if isinstance(obj,str)and obj.startswith('pkg:'):return str(self.reference(obj,file=False))
        return obj
    def runtime_read(self,path):
        name=self.name(path);return self.materialize(self.read(name),name)
    def validate_sources(self):
        auth=self.authority;require(auth['archive_not_distributed']is True,'Archive scope')
        rows=auth['source_files'];require(len(rows)==449,'All logical archive paths')
        entries={};names=set()
        for r in rows:
            require(r['archive_entry']not in entries and r['file']not in names,'Duplicate source path')
            names.add(r['file']);entries[r['archive_entry']]=r
            require(self.index[r['file']]=={k:r[k]for k in ('file','bytes','sha256')},'Source manifest pin')
            require(r['literal_imports']==source_imports(self.raw(r['file']),r['archive_entry']),'Literal import metadata differs')
        for p in self.profiles.values():
            top=entries[p['source_archive_entry']]
            require((p['source_file'],p['source_bytes'],p['source_sha256'])==(top['file'],top['bytes'],top['sha256']),'Source profile top binding')
            seen=set();todo=[p['source_archive_entry']]
            while todo:
                name=todo.pop()
                if name in seen:continue
                require(name in entries,'Missing import source');seen.add(name);todo.extend(entries[name]['literal_imports'])
            require(sorted(p['source_closure'])==sorted(entries[x]['file']for x in seen),'Exact import closure')
        return {'logical_source_paths':449,'byte_distinct_source_units':425}
    def corpus_profile(self,fixture):
        require(fixture in self.profiles,'Fixture outside fixed original source roster');p=self.profiles[fixture]
        return {'fixture_id':fixture,'case_id':p['case_id'],'variant':p['variant'],
            'source':{'path':str(self.path(p['source_file'])),'bytes':p['source_bytes'],'sha256':p['source_sha256']},
            'bindings':{'scope':'Pinned extracted source/import closure, shared source compiler trust boundary',
                'manifest_sha256':sha((self.root/'MANIFEST.json').read_bytes()),'source_closure':p['source_closure'],
                'origin_archive':self.authority['origin_archive']}}
    def validate_models(self):
        count=0;predicates=0
        required={'thetaE','thetaS','rhoE','rhoS','domain','domain_ENV_next','domain_SYS_next'}
        repairs=self.read('evidence/experiment/seams_submission_push_20261016/v_restricted_strict/checker/source_audit/SOURCE_PROFILES.json')['profiles']
        for name in self.index:
            if not name.endswith('/model.json'):continue
            m=self.read(name)
            require(m.get('schema')=='k7-native-model-export-v1','Model schema')
            source=self.origin_pin(m['input']);fixture=m['fixture_id']
            if fixture in self.profiles:
                p=self.profiles[fixture]
                require(m['input']['sha256']==p['source_sha256']and m['input']['bytes']==p['source_bytes'],'Corpus model/source unit')
                expected_case=fixture if m['variant']=='initializers'else p['case_id']
                require(m['case_id']==expected_case and m['variant']in ('original','initializers'),'Corpus model original/released identity')
            elif fixture in repairs:
                p=repairs[fixture];require(m['input']['sha256']==p['source']['sha256'],'Repair model/source profile')
                require(all(m[k]==p[k]for k in ('fixture_id','case_id','variant')),'Repair profile identity')
            else:raise InvalidPackage('Model outside fixed original/repair source profiles')
            n=m['bdd_variable_count'];require(type(n)is int and 0<=n<=64,'Model variable count/cap')
            fields=m['fields'];require(isinstance(fields,list)and len(fields)<=32,'Model field roster')
            names=set();current=[];nxt=[]
            for f in fields:
                require(type(f['name'])is str and f['name']not in names,'Duplicate/invalid field name');names.add(f['name'])
                require(f['owner']in ('ENV','SYS')and f['role']in ('ENV','SYS','AUX')and (f['role']=='ENV')==(f['owner']=='ENV'),'Complete owner/role; no ENV logical AUX')
                values=f['values'];require(type(f['domain_size'])is int and f['domain_size']>0 and len(values)==len(set(values))==f['domain_size'],'Typed values')
                require(set(f['encoding'])==set(values),'Complete typed encoding')
                cb,nb=f['current_bits'],f['next_bits'];require(len(cb)==len(nb),'Paired current/next bits')
                current+=cb;nxt+=nb
                for phase,bits in (('current',cb),('next',nb)):
                    require(all(type(v)is int and 0<=v<n for v in bits),'Typed bit bounds')
                    codes=[]
                    for value in values:
                        code=f['encoding'][value][phase];require(set(code)=={str(v)for v in bits}and all(type(x)is bool for x in code.values()),'Exact Boolean value encoding')
                        codes.append(tuple(code[str(v)]for v in bits))
                    require(len(codes)==len(set(codes)),'Injective typed value encoding')
            require(len(current+nxt)==len(set(current+nxt))==n and set(current+nxt)==set(range(n)),'Complete disjoint variable ownership')
            require(m['all_current_bits']==sorted(current)and m['all_next_bits']==sorted(nxt),'Current/next bit roster')
            require(set(m['original_bdds'])==required and set(m['original_justices'])=={'ENV','SYS'},'Original predicates/justice owners')
            refs=list(m['original_bdds'].values())+m['original_justices']['ENV']+m['original_justices']['SYS']
            for r in refs:
                require(type(r['file'])is str and Path(r['file']).name==r['file']and r['file'].endswith('.bdd'),'Original BDD basename')
                target=(Path(name).parent/r['file']).as_posix();require(target in self.index,'Missing original initializer/relation/justice')
                require((r['bytes'],r['sha256'])==(self.index[target]['bytes'],self.index[target]['sha256']),'Original BDD current byte binding')
                require(self.origins[target]['transformation']=='BYTE_IDENTICAL','Mathematical BDD changed during preparation');predicates+=1
            count+=1
        return {'models':count,'original_initializer_relation_justice_refs':predicates,'BDD_evaluations':0}
    def validate_core(self):
        rows=self.read('CORE_PROVENANCE.json')['files'];seen=set()
        for r in rows:
            name=r['file'];require(name not in seen and name.endswith('.py'),'Core source roster');seen.add(name)
            require(self.index[name]=={k:r[k]for k in ('file','bytes','sha256')},'Core source byte pin')
            require(r['byte_identical']is True and self.origins[name]['transformation']=='BYTE_IDENTICAL','Core byte identity')
            parsed=ast.dump(ast.parse(self.raw(name).decode('utf-8')),include_attributes=False)
            require(sha(parsed.encode())==r['ast_sha256'],'Core AST identity')
        require(seen=={name for name in self.origins if name.endswith('.py')},'All copied Python kernels inventoried')
        return {'unchanged_copied_Python_files':len(rows),'byte_and_AST_identity':True,'mathematical_code_imported':False}
    def validate_canonical_exports(self):
        exports=nodes_count=0
        roster=self.read('CANONICAL_EXPORTS.json')['exports'];index={r['file']:r for r in roster}
        require(len(index)==len(roster)and set(index)=={n for n in self.index if n.endswith('.json.gz')},'Complete canonical export roster')
        for name in self.index:
            if not name.endswith('.json.gz'):continue
            with gzip.open(self.path(name),'rb')as f:raw=f.read(64*1024*1024+1)
            require(len(raw)<=64*1024*1024,'Expanded canonical export cap')
            obj=json_bytes(raw);n=obj.get('variable_count')
            saved=index[name]
            require(obj.get('schema')==saved['schema']and list(obj.get('roots',{}))==saved['named_roots'],'Complete saved named-root roster/order')
            require(type(n)is int and 0<=n<=64 and obj.get('canonical_variable_order')==list(range(n)),'Canonical variable order')
            nodes={};triples=set()
            for row in obj['nodes']:
                require(isinstance(row,list)and len(row)==4 and all(type(x)is int for x in row),'Canonical node record')
                ident,v,lo,hi=row;require(ident>1 and ident not in nodes and 0<=v<n and lo!=hi,'Canonical node identity/variable/reduction')
                require(all(x in (0,1)or x in nodes for x in (lo,hi)),'Canonical child postorder')
                require(all(x<2 or nodes[x][0]>v for x in (lo,hi)),'Strict canonical variable progression')
                require((v,lo,hi)not in triples,'Duplicate canonical node');triples.add((v,lo,hi));nodes[ident]=(v,lo,hi)
            require(isinstance(obj['roots'],dict)and obj['roots']and all(type(v)is int and(v in (0,1)or v in nodes)for v in obj['roots'].values()),'Every named canonical root resolves')
            exports+=1;nodes_count+=len(nodes)
        return {'canonical_exports':exports,'serialized_nodes_validated':nodes_count,'function_recomputations':0,
            'boundary':'Schema, node/reference/order structure only. Canonical function digests are compared by future kernel rechecks.'}
    def normalized(self,x):
        if isinstance(x,dict):return {k:self.normalized(v)for k,v in x.items()}
        if isinstance(x,list):return [self.normalized(v)for v in x]
        if isinstance(x,str):return x.replace(str(self.root),'[PACKAGE]')
        return x
