"""One isolated metadata/import qualification or explicitly reviewed saved case."""
from pathlib import Path
import argparse,importlib.util,json,sys,time
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s)
    sys.modules[name]=m;s.loader.exec_module(m);return m

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--metadata',action='store_true');ap.add_argument('--imports-only');ap.add_argument('--guard-probe',action='store_true')
    ap.add_argument('--route');ap.add_argument('--case');ap.add_argument('--output');ap.add_argument('--expected-manifest',required=True)
    a=ap.parse_args();data=load('portable_data',ROOT/'portable_data.py');guard=load('runtime_guard',ROOT/'runtime_guard.py')
    data.require(data.sha((ROOT/'MANIFEST.json').read_bytes())==a.expected_manifest,'Reviewed manifest mismatch')
    data.require(sum(bool(x)for x in (a.metadata,a.imports_only,a.route))==1,'One worker mode required')
    output=None
    if a.route:
        data.require(a.case and a.output,'One explicit case/output required');output=Path(a.output).resolve()
        data.require(output.is_relative_to(ROOT/'runs')and output.is_dir()and not output.is_symlink(),'Assigned result directory')
    else:data.require(not a.case and not a.output,'Qualification must not create a public computation result')
    events=guard.install(ROOT,output);started=time.monotonic()
    try:
        p=data.Package(ROOT);sources=p.validate_sources();p.validate_core()
        sys.path.insert(0,str(ROOT))
        if a.metadata:
            audit=load('saved_audit',ROOT/'saved_audit.py');result=audit.audit(p)
            if a.guard_probe:
                blocked=[]
                for label,fn in [('outside_read',lambda:(ROOT.parent/'PORTABLE_DENIED_PROBE.txt').read_bytes()),
                    ('network_event',lambda:sys.audit('socket.connect',None)),
                    ('process_event',lambda:sys.audit('subprocess.Popen',None,None,None,None))]:
                    try:fn()
                    except PermissionError:blocked.append(label)
                    else:raise ValueError('Guard probe was not blocked')
                result['guard_probes_blocked']=blocked
        elif a.imports_only:
            route=a.imports_only;mathcalls=[]
            def profile(frame,event,arg):
                if event=='call'and frame.f_code.co_name=='__init__':
                    obj=frame.f_locals.get('self')
                    if obj is not None and type(obj).__name__ in ('BDD','Context','Model'):
                        mathcalls.append(type(obj).__name__);raise ValueError('Import-only qualification attempted mathematical object construction')
            sys.setprofile(profile)
            try:
                compute=load('portable_compute',ROOT/'portable_compute.py');compute.prepare(route,p)
            finally:sys.setprofile(None)
            result={'schema':'portable-import-only-qualification-v1','status':'PASS_IMPORT_CLOSURE','route':route,
                'mathematical_object_constructions':mathcalls,'fresh_public_BDD_computations':0,'fresh_public_graph_checks':0,'native_runs':0}
        else:
            routes=p.read('ROUTES.json')['routes'];entry=next((r for r in routes if r['route']==a.route),None)
            data.require(entry is not None and a.case in entry['case_ids'],'Case outside reviewed fixed route; unknown cases are not retried')
            compute=load('portable_compute',ROOT/'portable_compute.py');result=compute.compute(a.route,a.case,output,p)
            p.verify_files()
        result.update(io_boundary=events,elapsed_seconds=round(time.monotonic()-started,6),manifest_sha256=a.expected_manifest)
        if output:(output/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
        print(json.dumps(result if not output else {k:result[k]for k in ('status','route','case_id','native_runs','new_scientific_samples')},ensure_ascii=False))
        return 0
    except BaseException as ex:
        sys.setprofile(None)
        result={'status':'UNKNOWN_PACKAGE_OR_RECHECK_ERROR','error_type':type(ex).__name__,
            'error':str(ex).replace(str(ROOT),'[PACKAGE]'),'route':a.route or a.imports_only,'case_id':a.case,
            'io_boundary':events,'native_runs':0,'new_scientific_samples':0,'full_reset_uses':0}
        if output:(output/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
        print(json.dumps(result,ensure_ascii=False));return 2
if __name__=='__main__':raise SystemExit(main())
