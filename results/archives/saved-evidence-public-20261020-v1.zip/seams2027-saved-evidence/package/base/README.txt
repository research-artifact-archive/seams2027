SEAMS 2027 — saved evidence for contract verdicts
PRIVATE LOCAL REVIEW DRAFT. Not published. Redistribution terms for research
code and paper listings are still unresolved; see LICENSES_AND_SCOPE.txt.

Start here

This folder connects the paper's mathematics (C1) and public-output evidence
(C2) to their saved inputs and results. Packaging and portable rechecking are
reproducibility support; they add zero scientific samples.

CLAIMS.json maps each claim to evidence and a prepared single-case route.
ROUTES.json preserves the exact admitted case rosters. QUALIFICATION_SUMMARY.json
records the metadata, synthetic-corruption and import checks. SOURCE_AUTHORITY.json
binds all 449 archive paths and the 425 byte-distinct source units, including
literal imports. MANIFEST.json enumerates every local input/code/document file.
No native runtime, Java archive, Slugs binary or network download is required
for the saved-data routes. The separate five-example mathematical package is
available as the sibling folder seams2027-20261017-math-examples.

There are three different kinds of evidence here.

1. Saved historical results under evidence/. These retain the original
   scientific statuses, UNKNOWNs, initial quantifiers, canonical functions,
   original and transformed models, native graph IDs/ranks/private memory,
   source/repair provenance and enclosing process history. They are historical
   results, even when their metadata contains PASS.
2. A metadata audit, saved_audit.py. It checks the closed manifest, source/import
   closure, unchanged kernel byte/AST identity, typed model metadata, canonical
   node-table structure, every named-root roster and all table totals. It does not evaluate BDDs, solve
   games or recheck a graph. Its successful status is PASS_SAVED_EVIDENCE_AUDIT.
3. Prepared saved-data computations, portable_compute.py. They invoke unchanged
   mathematical functions through a new path/profile and process adapter. These
   routes have NOT been executed on public cases during Stage 2 preparation.
   Fresh results, when separately reviewed and run, go only under runs/ and carry
   PASS_SAVED_KERNEL_RECHECK or an explicit UNKNOWN. They do not replace history.

How to inspect the tables

Use Python 3.10 or newer on a POSIX system with /bin/ps. From this folder:

  python3 -B run_review.py --metadata --expected-manifest REVIEWED_SHA256

Supply the independently recorded SHA-256 of MANIFEST.json. The command checks
all package files and prints the complete saved table audit. It creates no
public-case computation output. Adding --guard-probe checks that a harmless
outside-file read and synthetic network/process audit events are denied.

The table scope is fixed:
  59 authoritative original models:49 W subset C,10 violations;366 other units
  remain outside this completed semantic audit, not mathematical negatives.
  All10 exact-loss targets:9 completed;159 remains UNKNOWN_RESOURCE.
  All9 completed K/exact-loss intersections are empty; all10 original initial
  W_V verdicts are false, with all SYS-owned logical AUX existentially quantified.
  Same14 inputs on four routes, including every refusal/negative and223 UNKNOWN.
  13 complete actual transformed arenas:5 identity,8 helper,7 literal mismatches;
  all13 preserve the strict original region and original initial truth.
  Fixed11 repair candidates:8 nonempty K,3 empty; all K subset C;10 C equals D.
  Separate044 actual pair/decomposition is one outcome-informed case and never
  enlarges the14/13 cohorts. It has W=2387,U=18816,F=C=1211,W_F=0 and8 missing
  typed ENV initial choices. The raw Boolean missing-root count is different.

How to recheck one saved case after review

  python3 -B run_review.py --run-reviewed --route ROUTE --case CASE_ID \
    --expected-manifest REVIEWED_SHA256

Choose an exact route/case from ROUTES.json. There is no all-cohort loop or
automatic retry. Original159 exact loss and223 released graph have no replay
entry; their saved UNKNOWNs remain visible. Slugs032/058 preserve the historical
native negative and recheck the original arena export only; no independent
unrealizability proof is claimed. Every positive graph retains all reconstructed
original initial roots and private memory, without valuation/rank merging.

One worker has a60-second wall bound,62-second CPU bound and a64MiB minus64KiB
combined worker-output bound. The remaining64KiB is reserved for the START
marker and compact parent receipt, which references RESULT.json by bytes/SHA
instead of embedding it again. All retained per-case outputs, including START
and receipt, are measured after completion and must fit within64MiB. An observed
worker-output overflow is UNKNOWN; after reaping, only that new worker's files
are discarded except an8KiB diagnostic prefix. This is a final retained-output
bound, not a continuous filesystem quota against transient overshoot. The
worker also has a2GiB sampled RSS bound and the unchanged kernels' node/state
caps. On non-Darwin systems it also has a2GiB address-space bound. RSS sampling is
not continuous OS enforcement. Timeout, failed observation, mismatch or resource
refusal stops the attempt with UNKNOWN. A start marker prevents automatic reuse
of an attempted route/case in the same copy. No native synthesis is invoked.

The Python audit hook denies worker network/child-process operations, outside
data reads and writes outside the assigned fresh output directory. It is an
audited boundary for pinned code, not an operating-system sandbox for hostile
programs. Python's standard library is read from the local interpreter. The
parent samples only its own worker's RSS using /bin/ps.

Digest and provenance rules

Metadata paths were adapted only in this new copy. Original files remain
unchanged. ORIGIN_DIGESTS.json separates each original digest from the current
copy digest, and PATH_ADAPTATIONS.json lists the changed string locations.
Embedded historical bytes/sha256 fields still describe ORIGINAL bytes. They
must not be compared directly with an anonymized copy. Current file pins are
MANIFEST.json. The runtime metadata adapter checks an original pin against the
admitted origin record before rebinding it to the current copy's bytes.

pkg: references identify included package files/directories. external: labels
and [ORIGIN_WORKSPACE] command fragments identify historical context outside
the execution closure; see EXTERNAL_REFERENCES.json. Old runtime identities,
frozen interpreter paths, original ROOT_START decisions and AI reviews remain
historical records. None authorizes a new computation or proves a theorem.
The old run.py/measure.py launchers are retained for provenance; use the new
driver. Their main functions are not relocation-ready consumer entry points.

Mathematical and empirical limits

All typed fields, original initializer predicates, ENV/SYS ownership, every
logical AUX, bit orders and ordered justices are retained. Complete-semantic C
quantifies every typed ENV-next choice, without restricting by rhoE. W_C keeps
its outer C and both C guards. Actual helper decomposition uses the verified
saved pair; it does not assume equality with the literal published template.

The M5 bridge is an adopted written proof under finite total round-arena and
Q0-label assumptions, about final fixed-point values. It does not equate every
nested approximant, certify extracted ranks or provide a mechanical universal
proof. The package retains the adoption-time manuscript/proof snapshot and its
source evidence; the final paper may have later editorial changes.

The source parser/compiler is shared with the original producer. Some direct
and decomposed computations share the BDD/GR1 engine. A graph counterexample
refutes that emitted graph; arbitrary-memory strategy impossibility needs its
separate mathematical/source argument. Native negative verdicts, existential
model reachability and deployed-system behavior are distinct claims.
