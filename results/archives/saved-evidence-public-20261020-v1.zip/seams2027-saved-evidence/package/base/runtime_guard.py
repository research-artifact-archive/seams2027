"""Audited I/O boundary for the pinned Python worker, not an OS sandbox."""
from pathlib import Path
import os, sys, sysconfig

def install(root,output=None):
    root=Path(root).resolve();output=Path(output).resolve()if output else None
    stdlib=Path(sysconfig.get_path('stdlib')).resolve()
    evidence={'scope':'Python audit events for this pinned worker; not a general hostile-code sandbox.',
              'external_data_reads_blocked':0,'network_process_attempts_blocked':0,'file_open_events':0}
    def inside(p,base):return p==base or p.is_relative_to(base)
    def hook(event,args):
        if event.startswith('socket.')or event in ('subprocess.Popen','os.system','os.posix_spawn','os.exec','os.fork','pty.spawn'):
            evidence['network_process_attempts_blocked']+=1;raise PermissionError('Portable worker forbids network and child processes')
        if event=='open':
            name=args[0]
            if isinstance(name,int):return
            p=Path(os.fsdecode(name)).resolve();mode=args[1];flags=args[2]if len(args)>2 and isinstance(args[2],int)else 0
            write=(isinstance(mode,str)and any(c in mode for c in 'wax+'))or bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
            evidence['file_open_events']+=1
            if write:
                if output is None or not inside(p,output):raise PermissionError('Portable worker write outside assigned result directory')
            elif not (inside(p,root)or (inside(p,stdlib)and 'site-packages'not in p.parts and 'dist-packages'not in p.parts)):
                evidence['external_data_reads_blocked']+=1;raise PermissionError('Portable worker read outside package and standard library')
        if event in ('os.mkdir','os.remove','os.rmdir','os.rename','os.replace'):
            for name in args[:2]if event in ('os.rename','os.replace')else args[:1]:
                if isinstance(name,(str,bytes)):
                    p=Path(os.fsdecode(name)).resolve()
                    if output is None or not inside(p,output):raise PermissionError('Portable worker mutation outside assigned results')
    sys.addaudithook(hook)
    return evidence
