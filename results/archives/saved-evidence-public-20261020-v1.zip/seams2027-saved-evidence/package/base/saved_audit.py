"""Reaggregate closed saved receipts; never import a BDD or solver module."""
from collections import Counter
from pathlib import Path
import json
from portable_data import Package,ROOT,E,require,sha

STUDIES=('preservation_condition_public','preservation_loss_public','cooperative_preservation_loss_public',
    'helper_quadrant_public','helper_decomposition_public','repair_preservation_condition_20261017')

def _ids(rows):
    ids=[x['id']for x in rows];require(len(ids)==len(set(ids)),'Duplicate case identifier');return ids
def _result(package,ref):return package.read(package.name(package.origin_pin(ref)))
def _equal_subset(a,b,keys):
    for k in keys:require(a[k]==b[k],'Saved row/case disagreement: '+k)

def audit(package):
    src=package.validate_sources();models=package.validate_models();canonical=package.validate_canonical_exports();core=package.validate_core()
    roster=package.read(E+'kind_corpus/ROSTER.json');ids=_ids(roster['unique_inputs'])
    require(len(ids)==425 and len(roster['all_paths'])==449,'Fixed corpus denominator')
    receipts={d:package.read(E+d+'/RUN_RECEIPT.json')for d in STUDIES}
    selections={d:package.read(E+d+'/SELECTION.json')for d in STUDIES}
    allresults={};statuses={}
    for d,r in receipts.items():
        rows=r['rows'];ri=_ids(rows)
        require(r['unknown_is_negative']is False,'UNKNOWN must remain nonnegative')
        if d!=STUDIES[-1]:require(ri==ids,'Full population roster/order changed')
        else:require(len(ri)==11 and ri==selections[d]['eligible_ids'],'Fixed all-eleven repairs')
        statuses[d]=dict(Counter(x['status']for x in rows));got={}
        for row in rows:
            if row['status']!='PASS':continue
            result=_result(package,row['result']);require(result['status']=='PASS'and result['id']==row['id'],'Result status/identity')
            if 'functions'in result:package.origin_pin(result['functions'])
            if d==STUDIES[0]:_equal_subset(row,result,('W_subset_C','counts'))
            elif d==STUDIES[1]:_equal_subset(row,result,('counts','initial_quantification','initial_verdict_changed'))
            elif d==STUDIES[2]:_equal_subset(row,result,('counts','cooperative_loss_nonempty','original_K_initial_quantification'))
            elif d==STUDIES[3]:require(row['relation_comparison']==result['comparison'],'Quadrant saved comparison')
            elif d==STUDIES[4]:require(row['summary']==result['summary'],'Decomposition saved summary')
            else:_equal_subset(row,result,('counts','K_subset_C','W_V_subset_C'))
            got[row['id']]=result
        allresults[d]=got
    cond=allresults[STUDIES[0]];negative=[i for i,r in cond.items()if r['W_subset_C']is False]
    require(len(cond)==59 and len(negative)==10 and sum(r['W_subset_C']is True for r in cond.values())==49,'59 condition split')
    require(selections[STUDIES[0]]['eligible_ids']==list(cond),'All authoritative 59 selected')
    loss=allresults[STUDIES[1]];coop=allresults[STUDIES[2]]
    require(len(loss)==len(coop)==9 and set(loss)==set(coop)==set(negative)-{'corpus159__original'},'Nine completed exact-loss cases')
    for d in (STUDIES[1],STUDIES[2]):
        rows={r['id']:r for r in receipts[d]['rows']}
        require(rows['corpus159__original']['status'].startswith('UNKNOWN'),'159 resource unknown retained')
    flips=[i for i,r in loss.items()if r['initial_verdict_changed']]
    require(flips==['corpus044__original','corpus045__original','corpus046__original'],'Original initializer flips')
    require([loss[i]['counts']['delayed_loss']for i in flips]==[1211,6112,2292],'Delayed loss saved counts')
    require(all(r['counts']['cooperative_loss']==0 and r['counts']['original_reachable_cooperative_loss']==0 for r in coop.values()),'All nine K intersections')
    # Every original W_V initial verdict is read from the independent v2 result,
    # including 159; this makes no statement that 159 exact loss completed.
    ten=[]
    for ident in negative:
        r=package.read(E+'kind_corpus_symbolic_independent/runs/v2/'+ident+'/RESULT.json')
        require(r['id']==ident and r['status']=='PASS','Independent original authority')
        q=r['initial_quantification']['WV'];require(q['value']is False,'Original I_M(W_V) false')
        require(r['initial_quantification']['K']['value']is False,'Original I_M(K) false')
        ten.append({'id':ident,'WV_count':r['counts']['WV'],'K_count':r['counts']['K'],
            'original_initial_WV':q,'original_initial_K':r['initial_quantification']['K']})
    native=package.read(E+'small_native_recovery/RUN_RECEIPT.json')
    small=package.read(E+'small_native_recovery/SELECTION.json')['eligible_ids']
    require(len(small)==len(set(small))==14 and 'corpus044__original'not in small,'Fixed fourteen original inputs')
    nr=native['rows'];keys=[(r['id'],r['pipeline'])for r in nr]
    arms=('v_restricted_strict','normalized_kind','released_kind')
    require(len(nr)==len(set(keys))==42 and set(keys)=={(i,a)for i in small for a in arms},'42 main native arm rows')
    require(all(r['phase']=='runs'for r in nr),'Main/qualification rows remain separate')
    graph_rows=[]
    for r in nr:
        entry={k:r.get(k)for k in ('id','pipeline','outcome','strict_controller_pass','nonconflicting_pass')}
        entry['evidence_kind']='SAVED_MAIN_NATIVE_ROW';graph_rows.append(entry)
        if r.get('certificate'):
            c=_result(package,r['certificate'])
            if r['pipeline']!='released_kind':_equal_subset(r,c,('strict_controller_pass','nonconflicting_pass'))
        if r.get('model_join'):
            j=_result(package,r['model_join']);require(j.get('status')=='EXACT_ORIGINAL_ARENA_MATCH','Native arm original model/region join')
    slug=package.read(E+'slugs_small_recovery_contained_v2/RUN_RECEIPT.json')
    require(_ids(slug['rows'])==small and all(r['phase']=='main'for r in slug['rows']),'Slugs exact same fourteen')
    for r in slug['rows']:
        c=_result(package,r['certificate']);_equal_subset(r,c,('strict_controller_pass','nonconflicting_pass'))
        graph_rows.append({k:r.get(k)for k in ('id','outcome','strict_controller_pass','nonconflicting_pass')}|
            {'pipeline':'slugs','evidence_kind':'SAVED_MAIN_NATIVE_ROW'})
    arms_summary={}
    for a in arms+('slugs',):
        rows=[r for r in graph_rows if r['pipeline']==a]
        s={'inputs':len(rows),'both':sum(r['strict_controller_pass']is True and r['nonconflicting_pass']is True for r in rows),
           'strict_only':sum(r['strict_controller_pass']is True and r['nonconflicting_pass']is False for r in rows),
           'refusal_or_native_negative':sum(r['outcome']in ('COMPLETE_NATIVE_REGION_REFUSAL','COMPLETE_NATIVE_NEGATIVE')for r in rows),
           'unknown':sum(r['outcome'].startswith('UNKNOWN')for r in rows)}
        require(s['inputs']==s['both']+s['strict_only']+s['refusal_or_native_negative']+s['unknown'],'Exclusive graph categories')
        arms_summary[a]=s
    require([(arms_summary[a]['both'],arms_summary[a]['strict_only'],arms_summary[a]['refusal_or_native_negative'],arms_summary[a]['unknown'])for a in arms+('slugs',)]==[(12,1,1,0),(12,0,2,0),(11,2,0,1),(12,0,2,0)],'Four-path saved table')
    quad=allresults[STUDIES[3]];decomp=allresults[STUDIES[4]]
    require(len(quad)==len(decomp)==13 and set(quad)==set(decomp)==set(small)-{'corpus223__original'},'Thirteen saved actual arenas;223 remains UNKNOWN')
    helper=[i for i,r in quad.items()if r['comparison']['helper_added']]
    mismatch=[i for i in helper if quad[i]['comparison']['literal_complete_relation_equal']is False]
    require(len(helper)==8 and len(mismatch)==7,'Five identity/eight helper/seven literal mismatch')
    for ident,r in decomp.items():
        s=r['summary'];require(s['checks']['original_full_region_preserved']is True and s['checks']['initial_quantification_equal']is True,'All13 preservation/initial checks')
        if ident in helper:require(s['checks']['U_equals_D']is True and s['checks']['F_equals_C']is True,'Saved generalized sufficient-condition values')
        require(r['original_W_exact_authority_equal']is True and r['original_initial_quantification_authority_equal']is True,'Original W/initializer authority')
    repairs=allresults[STUDIES[5]];require(len(repairs)==11 and all(r['K_subset_C']is True for r in repairs.values()),'All eleven K subset C')
    nonempty=sum(r['counts']['K']>0 for r in repairs.values());total=sum(r['counts']['C']==r['carrier']for r in repairs.values())
    require(nonempty==8 and total==10,'Repair split8/3 and10 universal C')
    x=package.read(E+'released_transform_044_analysis/runs/corpus044__original/RESULT.json')
    require(x['status']=='PASS'and x['separate_outcome_informed_single_case']is True and x['folded_into_fixed14_cohort']is False,'Separate044 scope')
    xs=x['summary'];expected={'D':18816,'U':18816,'W_original':2387,'F':1211,'C':1211,'W_F':0,'W_minus_F':1176,'delayed_loss':1211}
    require(all(xs['counts'][k]==v for k,v in expected.items()),'Separate044 saved values')
    require(xs['initial_quantification']['W_original']['value']is True and xs['initial_quantification']['W_predicted']['value']is False and xs['initial_quantification']['W_predicted']['missing_initial_ENV_count']==8,'Separate044 original typed initializer flip')
    routebook=package.read('ROUTES.json');routes=routebook['routes'];names=[r['route']for r in routes]
    expected_routes={'condition':list(cond),'exact_loss':list(loss),'cooperative_loss':list(coop),
        'original_initial_WV':negative,'decomposition':list(decomp),'repair_condition':list(repairs),
        'released_graph':[i for i in small if i!='corpus223__original'],'v_restricted_graph':small,
        'normalized_graph':small,'slugs_graph':small,'actual044':['corpus044__original']}
    require(len(names)==len(set(names))and set(names)==set(expected_routes),'Exact computation route roster')
    for r in routes:require(r['case_ids']==expected_routes[r['route']],'Fixed computation case roster/order')
    require(routebook['preserved_unknowns']=={'exact_loss':['corpus159__original'],'released_graph':['corpus223__original']},'Saved UNKNOWN route exclusions')
    require(routebook['automatic_all_cohort_execution']is False and routebook['saved_native_negative_not_new_unrealizability']==['corpus032__original','corpus058__original'],'No automatic cohort run or fabricated negative proof')
    return {'schema':'all-cohort-saved-evidence-audit-v1','status':'PASS_SAVED_EVIDENCE_AUDIT',
        'scope':'Metadata, file pins and reaggregation of saved results only; no BDD or graph mathematics reexecuted.',
        'source':src,'model_metadata':models,'canonical_export_metadata':canonical,'core':core,
        'condition':{'authoritative':59,'preserved_condition':49,'violating_condition':10,'other_source_units':366},
        'loss':{'targeted':10,'completed':9,'unknown_ids':['corpus159__original'],'original_initial_flip_ids':flips},
        'cooperative_loss':{'completed_intersections':9,'nonempty_intersections':0},'all_ten_original_initial_WV':ten,
        'four_paths':arms_summary,'four_path_rows':graph_rows,
        'actual_pairs':{'fixed_inputs':14,'completed':13,'unknown_ids':['corpus223__original'],'identity':5,'helper':8,'literal_relation_mismatch':7,'strict_region_and_initial_preserved':13},
        'repair_candidates':{'fixed':11,'K_subset_C':11,'nonempty_K':8,'empty_K':3,'C_equals_D':10},
        'separate044':{'selected':1,'counts':expected,'typed_missing_ENV_initials':8,'enlarges_fixed14_or13':False},
        'saved_status_histograms':statuses,'source_and_model_compiler_independence':False,
        'fresh_public_BDD_computations':0,'fresh_public_graph_checks':0,'native_runs':0,'full_reset_uses':0,
        'manifest_sha256':sha((package.root/'MANIFEST.json').read_bytes())}

def main():
    p=Package();result=audit(p);print(json.dumps(result,ensure_ascii=False,indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
