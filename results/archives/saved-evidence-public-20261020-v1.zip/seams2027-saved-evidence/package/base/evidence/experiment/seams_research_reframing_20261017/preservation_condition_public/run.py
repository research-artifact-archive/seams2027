"""Offline prepare/preflight; corpus mathematics requires an exact root decision."""
import argparse,importlib.util,json,os,sys,time
from pathlib import Path
from datetime import datetime,timezone
sys.dont_write_bytecode=True
from evidence import B,E,S,select,read,save,pin,pins_in,unique,verify,require,now
STAGE=E/'contained_stage_process';MIN_START_SECONDS=75

def preserve_interrupted_attempt(value):
    if value.get('status')=='UNKNOWN_NOT_ATTEMPTED' and value.get('BDD_worker_started') is not False:
        value.update(status='UNKNOWN_RUNNER_FAILURE',reason='Worker start was confirmed or uncertain before runner interruption')
    return value

def prepare():
    require(not (B/'FROZEN.json').exists() and not (B/'RUN_STARTED.json').exists(),'No frozen overwrite')
    if not (B/'SELECTION.json').exists():save(B/'SELECTION.json',select())
    selection=read(B/'SELECTION.json');verify(selection['input_pins'])
    qualification=read(B/'OFFLINE_QUALIFICATION.json')
    require(qualification['status']=='PASS' and qualification['corpus_BDD_computations']==0,'Offline qualification')
    verify(qualification['source_pins'])
    code=[pin(B/n) for n in ('evidence.py','condition.py','measure.py','run.py','qualify.py','PROTOCOL_JA.txt','OFFLINE_QUALIFICATION.json')]
    code += [pin(S/n) for n in ('check_case.py','symbolic.py','vendor/bdd_core.py')]
    code += [pin(STAGE/'FROZEN.json')]+pins_in(read(STAGE/'FROZEN.json'))
    code += [pin(Path(sys.executable).resolve())]
    files=unique(code+selection['input_pins']+[pin(B/'SELECTION.json')]);verify(files)
    save(B/'FROZEN.json',{'schema':'preservation-condition-source-freeze-v1','created_utc':now(),
        'files':files,'code_files':unique(code),'python':pin(Path(sys.executable).resolve()),
        'limits':{'variables':64,'BDD_nodes_including_terminals':500000,'wall_seconds_per_case':60,'workers':1},
        'selection':pin(B/'SELECTION.json'),'parent_aborted':True,'native_runs':0,'corpus_BDD_computations':0,
        'root_review_status':'AWAITING_ROOT_REVIEW_NO_CORPUS_DISPATCH'})
    print(json.dumps({'status':'PREPARED_CORPUS_NOT_STARTED','eligible':59,'files':len(files),'native_runs':0}))

def run(deadline):
    from measure import authorization
    decision_pin=authorization();end=datetime.fromisoformat(deadline);require(end.tzinfo is not None,'Timezone-aware deadline')
    freeze=read(B/'FROZEN.json');verify(freeze['files'])
    require(freeze['python']==pin(Path(sys.executable).resolve()),'Frozen Python identity')
    selection=read(B/'SELECTION.json');require(selection['eligible_count']==59,'Fixed cohort')
    byid={r['id']:r for r in selection['rows']}
    require(not (B/'RUN_STARTED.json').exists() and not (B/'RUN_RECEIPT.json').exists(),'One dispatch only, no retry')
    sys.path.insert(0,str(STAGE))
    spec=importlib.util.spec_from_file_location('preservation_contained_stage',STAGE/'bounded_process.py')
    bounded=importlib.util.module_from_spec(spec);spec.loader.exec_module(bounded)
    with (B/'RUN_STARTED.json').open('x') as f:json.dump({'started_utc':now(),'owner_pid':os.getpid(),'freeze':pin(B/'FROZEN.json'),'root_authorization':decision_pin},f)
    outputs={};output_refs=[decision_pin];stop=False;reasons=[];started=time.monotonic()
    try:
        for ident in selection['eligible_ids']:
            value={'id':ident,'status':'UNKNOWN_NOT_ATTEMPTED','BDD_worker_started':False};outputs[ident]=value
            if stop or (end-datetime.now(timezone.utc)).total_seconds()<MIN_START_SECONDS:continue
            verify(freeze['code_files']+[decision_pin])
            if (end-datetime.now(timezone.utc)).total_seconds()<MIN_START_SECONDS:continue
            value['BDD_worker_started']=None
            folder=B/'runs'/ident
            process=bounded.run_bounded([sys.executable,'-B',str(B/'measure.py'),ident],folder/'process',deadline,
                wall_seconds=60,file_bytes=64*1024*1024,watch_files=[folder/'RESULT.json',folder/'FUNCTIONS.json.gz'])
            value.update(BDD_worker_started=process['process_started'],process=pin(folder/'process/PROCESS_RECEIPT.json'))
            output_refs.append(value['process'])
            if process['status']=='PROCESS_COMPLETED' and process['exit_code']==0 and (folder/'RESULT.json').exists():
                value['status']='UNKNOWN_INTEGRITY'
                result=read(folder/'RESULT.json');require(result['id']==ident and result.get('schema')=='preservation-condition-case-v1','Case result identity')
                require(result.get('status') in ('PASS','UNKNOWN_RESOURCE','UNKNOWN_INTEGRITY'),'Unknown child result status')
                require(result.get('root_authorization')==decision_pin and result.get('parent_aborted') is True,'Child authorization provenance')
                require(result.get('native_runs')==0 and result.get('full_reset_uses')==0 and result.get('W_minus_C_is_exact_lost_region') is False,'Child calculation scope')
                if result['status']=='PASS':
                    require(type(result.get('W_subset_C')) is bool,'Condition Boolean result')
                    counts=result['counts'];require(set(counts)=={'C','W','W_minus_C'} and all(type(n) is int and n>=0 for n in counts.values()),'Exact nonnegative counts')
                    require(counts['W_minus_C']<=counts['W'] and result['W_subset_C']==(counts['W_minus_C']==0),'Condition/count consistency')
                    require(result['independent_W_certificate']==byid[ident]['proof'] and result['independent_process']==byid[ident]['process'],'Independent W authority')
                    expected_refs=freeze['code_files']+byid[ident]['input_pins']+[pin(B/'FROZEN.json'),pin(B/'SELECTION.json'),decision_pin]
                    require(result['input_pins']==expected_refs,'Exact case/source/authorization evidence')
                    verify([result['functions']])
                value.update(status=result['status'],result=pin(folder/'RESULT.json'))
                output_refs += [value['result']]+pins_in(result)
                if result['status']=='PASS':value.update(W_subset_C=result['W_subset_C'],counts=result['counts'])
                elif result['status']=='UNKNOWN_INTEGRITY':stop=True;reasons.append('CASE_INTEGRITY')
            else:
                value['status']='UNKNOWN_RESOURCE' if process['status']=='UNKNOWN_RESOURCE' else 'UNKNOWN_PROCESS'
                if value['status']=='UNKNOWN_PROCESS':stop=True;reasons.append('UNEXPECTED_WORKER_EXIT_OR_MISSING_RESULT')
            if process['status'].startswith('FATAL_'):stop=True;reasons.append('PROCESS_INTEGRITY')
            verify([decision_pin])
            save(B/'PROGRESS.json',{'finished':False,'rows':list(outputs.values()),'native_runs':0})
    except BaseException as ex:stop=True;reasons.append(repr(ex))
    try:verify(freeze['files']+output_refs)
    except BaseException as ex:stop=True;reasons.append('FINAL_PIN_INTEGRITY:'+repr(ex))
    rows=[]
    for value in outputs.values():preserve_interrupted_attempt(value)
    for source in selection['rows']:
        rows.append(outputs.get(source['id'],{'id':source['id'],'status':'UNKNOWN_NOT_ATTEMPTED' if source['eligible'] else 'UNKNOWN_NO_AUTHORITATIVE_INDEPENDENT_W',
            'BDD_worker_started':False,'prior_status':source['prior_status']}))
    receipt={'schema':'preservation-condition-run-v1','finished_utc':now(),'elapsed_seconds':time.monotonic()-started,
        'source_denominator':425,'eligible_count':59,'rows':rows,'global_stop':stop,'stop_reasons':reasons,
        'parent_aborted':True,'root_authorization':decision_pin,'unknown_is_negative':False,'native_runs':0,'full_reset_uses':0,
        'W_minus_C_is_exact_lost_region':False,'initial_feasibility_conclusion':None,'released_route_loss_conclusion':None,
        'BDD_worker_calls':{'confirmed':sum(v.get('BDD_worker_started') is True for v in rows),'uncertain':sum(v.get('BDD_worker_started') is None for v in rows)}}
    save(B/'RUN_RECEIPT.json',receipt)
    save(B/'RESULT_FILES.json',{'files':[pin(p) for p in sorted(B.rglob('*')) if p.is_file() and p.name!='RESULT_FILES.json']})
    print(json.dumps({'global_stop':stop,'BDD_worker_calls':receipt['BDD_worker_calls']}))

def main():
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=('select','prepare','preflight','run'));parser.add_argument('--deadline-utc')
    args=parser.parse_args()
    if args.mode=='select':
        require(not (B/'SELECTION.json').exists(),'No selection overwrite');save(B/'SELECTION.json',select());print('Selected all 59; corpus BDD=0');return
    if args.mode=='prepare':prepare();return
    frozen=read(B/'FROZEN.json');verify(frozen['files'])
    if args.mode=='preflight':print(json.dumps({'status':'PASS_SOURCE_FREEZE','native_runs':0,'corpus_BDD_computations':0}));return
    require(args.deadline_utc is not None,'Root-specified absolute deadline required');run(args.deadline_utc)

if __name__=='__main__':main()
