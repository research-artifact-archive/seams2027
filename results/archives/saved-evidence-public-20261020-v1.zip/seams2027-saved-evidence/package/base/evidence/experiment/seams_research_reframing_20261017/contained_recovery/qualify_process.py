"""Explicitly authorized tiny Python process qualification; never starts a JVM."""
from contextlib import nullcontext
from datetime import datetime, timezone, timedelta
from pathlib import Path
from unittest.mock import patch
import gzip
import hashlib
import json
import os
import sys

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import launcher as l


def require(value, message):
    if not value:
        raise AssertionError(message)


def run():
    root = BASE / 'process_qualification' / datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    root.mkdir(parents=True, exist_ok=False)
    before = [l.pin(BASE/name) for name in ('owned_process.py','native_worker.py','launcher.py','lossless_stdout.py','qualify_process.py')]
    cases = [
        ('exit_zero', 'pass', {}, 'COMPLETE_PROCESS_AND_CAPTURE'),
        ('stdout_complete', "import sys; sys.stdout.write('owned synthetic stdout\\n'); sys.stdout.flush()", {}, 'COMPLETE_PROCESS_AND_CAPTURE'),
        ('nonzero_exit', "import sys; sys.stderr.write('controlled nonzero\\n'); sys.exit(7)", {}, 'UNKNOWN_TECHNICAL'),
        ('wall_timeout', 'import time; time.sleep(5)', {'wall_seconds':0.25}, 'UNKNOWN_RESOURCE'),
        ('file_cap', "from pathlib import Path; import time; Path('oversized.dat').write_bytes(b'x'*131072); time.sleep(5)", {'other_file_bytes':65536}, 'UNKNOWN_RESOURCE'),
        ('stdout_cap', "import sys,time; sys.stdout.buffer.write(b'x'*65536); sys.stdout.flush(); time.sleep(5)", {'raw_stdout_bytes':4096}, 'UNKNOWN_RESOURCE'),
        ('outer_owned_cleanup', 'import time; time.sleep(5)', {'wall_seconds':2}, 'UNKNOWN_INTEGRITY'),
    ]
    rows=[]
    for name,code,caps,expected in cases:
        folder=root/name;folder.mkdir();script=folder/'SYNTHETIC_INPUT.py';script.write_text(code+'\n')
        refs=before+[l.pin(script)]
        limits={'qualification_only':True,'wall_seconds':1,'raw_stdout_bytes':65536,
                'compressed_stdout_bytes':65536,'other_file_bytes':1048576,'aggregate_arm_bytes':4194304,**caps}
        context=patch.object(l,'PARENT_WATCHDOG_SECONDS',0.4) if name=='outer_owned_cleanup' else nullcontext()
        result=None
        try:
            with context:
                result=l.launch_native([sys.executable,'-c',code],folder/'arm',
                    (datetime.now(timezone.utc)+timedelta(minutes=10)).isoformat(),refs,limits)
            require(result['status']==expected, 'Unexpected status: '+str(result.get('status'))+' '+str(result.get('error')))
            require(result['qualification_only'] is True and result['native_called'] is False, 'Synthetic call became native evidence')
            require(not result['source_pin_errors_before'] and not result['source_pin_errors_after'], 'Source pin drift')
            require(result['parent_exact_wait4']['exact_child_reaped'], 'Worker exact wait4 not obtained')
            if name!='outer_owned_cleanup':
                worker=result['worker_receipt']
                require(result['global_stop'] is False and worker['scientific_JVM_executions']==0, 'Unexpected integrity/native result')
                require(worker['child_reaped'] and worker['process_group_contained'], 'Synthetic child lifecycle unconfirmed')
                require(worker['exact_child_wait4']['exact_child_reaped'], 'Missing synthetic child exact wait4')
                require(worker['final_group_observation']['basis']=='SUCCESSFUL_PROCESS_TABLE_NO_GROUP_MEMBERS', 'Missing final group absence')
                require(worker['peak_rss']['calculation']=='EXACT_NATIVE_CHILD_WAIT4_EXCLUDES_PROCESS_TABLE_HELPERS', 'Wrong RSS authority')
                require(not result['artifact_pin_errors'], 'Result artifact drift')
                if name=='stdout_complete':
                    require(gzip.decompress((folder/'arm/stdout.txt.gz').read_bytes())==b'owned synthetic stdout\n','Complete stdout differs')
                if name=='nonzero_exit':require(worker['returncode']==7,'Nonzero exit status changed')
                if name in ('wall_timeout','file_cap','stdout_cap'):
                    require(worker['resource_reasons'],'Expected resource cause missing')
                    require(any(e.get('sent') for e in worker['termination_events']),'Owned resource cleanup was not exercised')
            else:
                cleanup=result['cleanup_receipt']
                require(result['global_stop'] and cleanup['worker_stopped_identity_confirmed'], 'Outer cleanup stopped-parent identity unconfirmed')
                require(cleanup['native_group_signal_sent'] is True,'Owned synthetic child group was not contained')
                require(cleanup['remaining_worker_group_members']==[],'Worker group remains')
                require(cleanup.get('remaining_bound_native_group_members')==[],'Synthetic child group remains')
            rows.append({'name':name,'pass':True,'status':result['status'],'parent_receipt':l.pin(folder/'arm/PARENT_RECEIPT.json'),
                         'provided_child_called':result.get('provided_child_called'),'native_called':False,'JVM_calls':0,
                         'controlled_overrides':{'limits':limits,'parent_watchdog_seconds':0.4 if name=='outer_owned_cleanup' else l.PARENT_WATCHDOG_SECONDS},
                         'elapsed_seconds':result['elapsed_seconds']})
        except Exception as error:
            rows.append({'name':name,'pass':False,'error':repr(error),'parent_receipt':l.pin(folder/'arm/PARENT_RECEIPT.json') if (folder/'arm/PARENT_RECEIPT.json').exists() else None})
            # A failed containment control stops the actual-process qualification.
            break
    after_errors=l.pin_errors(before)
    report={'schema':'contained-recovery-real-python-qualification-v1','status':'PASS' if len(rows)==len(cases) and all(r['pass'] for r in rows) and not after_errors else 'FAIL',
            'created_utc':datetime.now(timezone.utc).isoformat(),'passed':sum(r['pass'] for r in rows),'total_planned':len(cases),'rows':rows,
            'actual_native_calls':0,'actual_JVM_calls':0,'only_owned_synthetic_python_children_and_process_table_helpers':True,
            'root_authorization':'Small real-process qualification requested before freeze; no scientific run authorized by this script.',
            'source_pins':before,'source_pin_errors_after':after_errors,'full_reset_uses':0,
            'scope':'Actual OS exit/capture/caps/owned cleanup plus existing mock-only EPERM/ECHILD negative controls. Old stopped runs remain unchanged.'}
    l.save(BASE/'PROCESS_QUALIFICATION.json',report)
    print(json.dumps({'status':report['status'],'passed':report['passed'],'total_planned':len(cases),'failures':[r for r in rows if not r['pass']],'native_calls':0,'JVM_calls':0},indent=2),flush=True)
    return 0 if report['status']=='PASS' else 1


if __name__=='__main__':raise SystemExit(run())
