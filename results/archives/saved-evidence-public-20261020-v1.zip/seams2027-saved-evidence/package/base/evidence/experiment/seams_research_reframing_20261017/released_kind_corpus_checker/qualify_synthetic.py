"""Clearly synthetic helper-free and mutation controls, all native invocation counts zero."""
from pathlib import Path
import copy,hashlib,json,sys
sys.dont_write_bytecode=True
import certify as c
from qualify import build_ref,writebdd,H,OLD
D=H/'synthetic_qualification';D.mkdir(exist_ok=True)

def file_ref(p):return {'file':p.name,'bytes':p.stat().st_size,'sha256':c.sha(p)}
def print_graph(g):
 out=[]
 for n in g['nodes']:
  n['native_bdd_text']='<'+', '.join(k+':'+v for k,v in n['valuation'].items())+'>'
  out += [('Initial ' if n['initial'] else '')+'State '+n['id']+' '+n['native_bdd_text'],'\tWith successors : '+', '.join(n['successors']) if n['successors'] else '\tWith no successors.']
 return '\n'.join(out)+'\n'
def savejob(jd,m,r,g):
 c.save(jd/'model.json',m);g['model_sha256']=c.sha(jd/'model.json')
 (jd/'controller.txt').write_text(print_graph(g));c.save(jd/'controller.json',g)
 r['model_export']=file_ref(jd/'model.json');r['controller_export']=file_ref(jd/'controller.json');r['printed_controller']=file_ref(jd/'controller.txt')
 r['controller_before_print_sha256']=r['controller_after_print_sha256']=c.sha(jd/'controller.json');c.save(jd/'result.json',r)
def main():
 case='synthetic_no_helper';src=D/'synthetic_source.spectra';src.write_text('''spec synthetic_no_helper\nenv boolean e;\nsys boolean p;\n// AUX q and equations below are explicit checker qualification data, not translator output.\n''')
 source={'path':str(src.resolve()),'bytes':src.stat().st_size,'sha256':c.sha(src)}
 fields=[{'name':n,'owner':o,'role':r,'domain':['false','true']} for n,o,r in [('e','ENV','ENV'),('p','SYS','SYS'),('q','SYS','AUX')]]
 p={'fixture_id':case,'case_id':case,'variant':'initializers','source':source,'expected_fields_in_native_order':fields,'formulas':{'thetaE':True,'thetaS':True,'rhoE':True,'rhoS':['and',['iff',['var','p',True],['var','e',True]],['iff',['var','q',True],['var','p',True]]]},'justices':{'ENV':[['var','e',False]],'SYS':[['var','p',False],True]}}
 template=c.read_json(OLD/'runs/justice/model.json');inv=copy.deepcopy(template['source_inventory'])
 for role in ('ENV','SYS','AUX'):
  inv['parsed'][role].update(variables=[{'name':f['name']} for f in fields if f['role']==role],constraints=[],patterns=[])
 template['source_inventory']=inv
 od=D/'original';jd=D/'job';om=build_ref(case,p,template,od,permute=True,invert=True);jm=build_ref(case,p,template,jd,permute=False,invert=False)
 job=c.base.Context(jd,p,jm)
 r=copy.deepcopy(c.read_json(OLD/'runs/justice/result.json'))
 r.update(fixture_id=case,case_id=case,variant='initializers',input_sha256=source['sha256'],helper_added=False,helper_is_native_nonaux_ENV=False,preconstructor_justices=jm['original_justices'],solver_justices=jm['original_justices'],native_memory_identity=91,qualification_only=True)
 nodes=[]
 for i,(e,pv,q,rank,initial) in enumerate([(False,False,False,0,True),(True,False,False,0,True),(True,True,True,0,False),(False,False,False,1,False)]):
  val=dict(zip(('e','p','q'),['true' if z else 'false' for z in (e,pv,q)]))
  nodes.append({'id':str(i),'native_id':i,'initial':initial,'rank':rank,'rank_class':'tau.smlab.syntech.games.gr1.GR1RankInfo','rank_info':'System Justice '+str(rank),'valuation':val,'bits':{str(k):v for k,v in job.bits(val).items()},'successors':['3','2']})
 g={'schema':'released-kind-complete-native-controller-v1','complete':True,'native_memory_identity':91,'rank_domain_size':2,'api_state_count':4,'api_transition_count':8,'nodes':nodes,'edges':[[n['id'],j] for n in nodes for j in n['successors']]}
 savejob(jd,jm,r,g)
 results=[]
 def assess(label,odx,jdx,expect):
  out=D/'results'/label;z=c.check(odx,jdx,case,out,p);c.save(out/'certificate.json',z)
  results.append({'label':label,'expected':expect,'actual':z['status'],'pass':z['status']==expect,'error':z.get('mapping_error') or z.get('controller_defect')})
  return z
 z=assess('no_helper_valid_permuted_encoding',od,jd,'COMPLETE_DERIVED_ORIGINAL_CERTIFICATE');assert z['derived_fairness']['nonconflicting']['pass'] and z['derived_fairness']['strict_liveness']['pass']
 assert z['original_view_mapping']['states']==4,'Do not merge valuation-identical different rank states'
 import shutil
 for label in ['missing_response','duplicate_initial_env','wrong_initial_rank','no_initial','duplicate_valuation_rank','wrong_rank_text','missing_AUX','changed_original_relation']:
  target=D/label
  if target.exists():shutil.rmtree(target)
  shutil.copytree(jd,target);mx=copy.deepcopy(jm);rx=copy.deepcopy(r);gx=copy.deepcopy(g)
  expected='COMPLETE_CONTROLLER_DEFECT'
  if label=='missing_response':gx['nodes'][0]['successors']=['2']
  elif label=='duplicate_initial_env':gx['nodes'][2]['initial']=True
  elif label=='wrong_initial_rank':gx['nodes'][0]['rank']=1;gx['nodes'][0]['rank_info']='System Justice 1';gx['nodes'][3]['rank']=0;gx['nodes'][3]['rank_info']='System Justice 0'
  elif label=='no_initial':
   for n in gx['nodes']:n['initial']=False
  elif label=='duplicate_valuation_rank':gx['nodes'][3]['rank']=0;gx['nodes'][3]['rank_info']='System Justice 0';expected='UNKNOWN_ORIGINAL_MAPPING'
  elif label=='wrong_rank_text':gx['nodes'][0]['rank_info']='System Justice 1';expected='UNKNOWN_ORIGINAL_MAPPING'
  elif label=='missing_AUX':mx['fields']=[f for f in mx['fields'] if f['name']!='q'];expected='UNKNOWN_ORIGINAL_MAPPING'
  elif label=='changed_original_relation':mx['original_bdds']['rhoS']=writebdd(target,c.BDD(mx['bdd_variable_count']),1,'changed_rhoS');expected='UNKNOWN_ORIGINAL_MAPPING'
  gx['edges']=[[n['id'],j] for n in gx['nodes'] for j in n['successors']];gx['api_transition_count']=len(gx['edges']);savejob(target,mx,rx,gx)
  assess(label,od,target,expected)
 # Both matched models have empty ENV initials: count separately, never fairness PASS.
 empty_p=copy.deepcopy(p);empty_p['formulas']['thetaE']=False
 eo=D/'empty_original';ej=D/'empty_job';em=build_ref(case,empty_p,template,eo,True,True);jm2=build_ref(case,empty_p,template,ej)
 rr=copy.deepcopy(r);gg=copy.deepcopy(g);rr['preconstructor_justices']=rr['solver_justices']=jm2['original_justices'];savejob(ej,jm2,rr,gg)
 assess('empty_ENV_initials',eo,ej,'COMPLETE_VACUOUS_ENV_INITIALS')
 summary={'status':'PASS' if all(x['pass'] for x in results) else 'FAIL','all_synthetic':True,'native_runs':0,'tests':results}
 c.save(H/'QUALIFICATION_SYNTHETIC.json',summary);print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
