from pathlib import Path
import datetime,hashlib,json
H=Path(__file__).resolve().parent

def pin(p):return {'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def main():
 assert not (H/'FREEZE.json').exists(),'Do not rewrite a published freeze'
 names=['certify.py','generic_base.py','SOURCE_FREEZE.json','PROTOCOL_JA.txt','qualify.py','qualify_synthetic.py','freeze.py','IMPLEMENTATION_REVIEW_JA.txt','QUALIFICATION_EXISTING_FOUR.json','QUALIFICATION_SYNTHETIC.json','vendor/bdd_core.py','vendor/graph_fairness.py']
 files=[{'file':n,**pin(H/n)} for n in names]
 qualification_inputs=[pin(p) for d in ('qualification_refs','synthetic_qualification') for p in sorted((H/d).rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
 old=H.parent.parent/'seams_submission_push_20261016/released_kind_pipeline_feasibility'
 references=[pin(old/'ORIGINAL_PROFILES.json'),pin(old/'checker/certify.py')]
 for p in sorted((old/'runs').rglob('*')):
  if p.is_file() and (p.name in ('result.json','model.json','controller.json','controller.txt') or p.suffix=='.bdd'):references.append(pin(p))
 out={'schema':'released-kind-corpus-checker-freeze-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'qualification_input_pins':qualification_inputs,'existing_reference_pins':references,'qualification_native_runs':0,'scientific_native_runs':0,'full_reset_uses':0,'BDD_core_unchanged':pin(H/'vendor/bdd_core.py')['sha256']==pin(old/'checker/bdd_core.py')['sha256'],'SCC_core_unchanged':pin(H/'vendor/graph_fairness.py')['sha256']==pin(old/'checker/graph_fairness.py')['sha256'],'source_to_BDD_independent_compilation':False,'production_outputs_excluded':['runs','qualification/native']}
 assert out['BDD_core_unchanged'] and out['SCC_core_unchanged']
 (H/'FREEZE.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'freeze':pin(H/'FREEZE.json'),'fixed_files':len(files),'qualification_input_pins':len(qualification_inputs),'reference_pins':len(references)}))
if __name__=='__main__':main()
