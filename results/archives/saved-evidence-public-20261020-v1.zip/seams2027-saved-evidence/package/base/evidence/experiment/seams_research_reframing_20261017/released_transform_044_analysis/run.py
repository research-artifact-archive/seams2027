"""One saved044 worker, only after exact Root freeze review; no native dispatch."""
from datetime import datetime,timezone
from pathlib import Path
import argparse,importlib.util,json,os,sys,time
sys.dont_write_bytecode=True
from evidence import B,C,H,M,L,S,CHECK,STAGE,ID,read,save,pin,pins_in,unique,verify,require,now,select,authorization
CODE=('evidence.py','decomposition.py','import_original.py','imports.py','regions.py','reporting.py','measure.py','run.py','qualify_math.py','qualify_adapters.py','qualify_authority.py','PROTOCOL_JA.txt','REUSE_AUDIT.json','MATH_QUALIFICATION.json','ADAPTER_QUALIFICATION.json','AUTHORITY_QUALIFICATION.json')
MIN_START_SECONDS=75

def prepare():
    require(not (B/'FROZEN.json').exists() and not (B/'RUN_STARTED.json').exists(),'No frozen overwrite')
    if not (B/'SELECTION.json').exists():save(B/'SELECTION.json',select())
    selected=read(B/'SELECTION.json');verify(selected['input_pins'])
    for name in ('MATH_QUALIFICATION.json','ADAPTER_QUALIFICATION.json','AUTHORITY_QUALIFICATION.json'):
        q=read(B/name);require(q['status']=='PASS' and q['corpus_BDD_computations']==0 and q['native_runs']==0,'Synthetic-only qualification');verify(q['source_pins'])
    verify(read(B/'REUSE_AUDIT.json')['source_pins'])
    code=[pin(B/name) for name in CODE]+[pin(C/n) for n in ('FROZEN.json','decomposition.py','import_original.py','measure.py','qualify_math.py','MATH_QUALIFICATION.json')]
    code += [pin(M/'map_pair.py'),pin(M/'FROZEN.json'),pin(H/'map_pair.py'),pin(L/'loss.py'),pin(L/'FROZEN.json'),pin(L/'OFFLINE_QUALIFICATION.json')]
    code += [pin(S/name) for name in ('symbolic.py','check_case.py','vendor/bdd_core.py','vendor/finite_sets_v1.py')]+[pin(CHECK/name) for name in ('generic_base.py','vendor/bdd_core.py','SOURCE_FREEZE.json')]
    code += [pin(B.parent/'preservation_condition_public/condition.py'),pin(STAGE/'FROZEN.json')]+pins_in(read(STAGE/'FROZEN.json'))+[pin(Path(sys.executable).resolve())]
    code=unique(code);files=unique(code+selected['input_pins']+[pin(B/'SELECTION.json')]);verify(files)
    save(B/'FROZEN.json',{'schema':'fixed044-saved-analysis-freeze-v1','created_utc':now(),'files':files,'code_files':code,'python':pin(Path(sys.executable).resolve()),'selection':pin(B/'SELECTION.json'),
        'id':ID,'saved_BDD_worker_budget':1,'native_JVM_budget':0,'native_solver_budget':0,'controller_budget':0,
        'limits':{'native_and_common_variables':64,'nodes_per_BDD_manager':500000,'original_typed_carrier_cap':65536,'job_typed_carrier_cap':65536,'per_saved_BDD_bytes':8388608,'function_export_uncompressed_bytes':67108864,'case_wall_seconds':60,'minimum_start_seconds':75,'workers':1},
        'root_review_status':'AWAITING_ROOT_SAVED044_ANALYSIS_REVIEW','native_runs':0,'corpus_BDD_computations':0})
    print(json.dumps({'status':'PREPARED_FIXED044_NO_CORPUS_BDD','files':len(files),'freeze':pin(B/'FROZEN.json')}))

def validate(result,row,freeze,decision):
    require(result.get('schema')=='fixed044-saved-analysis-case-v1' and result.get('id')==ID and result.get('status') in ('PASS','FAIL_DECOMPOSITION','UNKNOWN_RESOURCE','UNKNOWN_INTEGRITY'),'Recognized exact044 result identity/status')
    require(result.get('root_authorization')==decision and result.get('closed_model_pair')==row['closed_main'] and result.get('parent_aborted') is True,'Exact current and prior authority')
    for key in ('new_native_JVM_calls','native_solver_calls','controller_calls','full_reset_uses'):require(type(result.get(key)) is int and result[key]==0,'No unauthorized calls '+key)
    require(result.get('direct_reference_objective')=='strict_GR1_on_actual_saved_transformed_arena' and result.get('compared_with_native_4fp_region') is False and result.get('returned_controller_conclusion') is None,'Saved strict objective only; no native4FP/controller conclusion')
    require(result.get('claim_is_cooperative_strategy_existence') is False and result.get('all_original_AUX_retained') is True and result.get('separate_outcome_informed_single_case') is True and result.get('folded_into_fixed14_cohort') is False,'No cooperative/controller or denominator transfer')
    require(result.get('independent_source_compiler') is False and result.get('shared_source_compiler') is True and result.get('common_BDD_and_GR1_engine_between_direct_and_decomposed') is True and result.get('synthetic_finite_set_oracle_independent_representation') is True,'Exact independence boundary')
    require(type(result.get('original_K_count')) is int and result['original_K_count']==0 and result.get('original_K_initial_verdict') is False and result.get('kind_initializer_false_rejection_conclusion') is None,'K0 boundary')
    require(result.get('original_initializers_retained_for_active_and_literal_quantification') is True and result.get('original_ordered_justices_retained') is True,'Original initial/justice semantics')
    if result['status'] in ('PASS','FAIL_DECOMPOSITION'):
        for name in ('original_model','job_model','pair_check','pair_check_process','independent_W_certificate','independent_W_process','independent_regions','prior_literal_loss_certificate','prior_literal_loss_process','prior_literal_loss_functions'):require(result[name]==row[name],'Exact closed source authority '+name)
        for name in ('original_W_exact_authority_equal','original_reachable_exact_authority_equal','original_initial_quantification_authority_equal','literal_initial_quantification_authority_equal'):require(result[name] is True,'Required correspondence '+name)
        expected=freeze['code_files']+row['input_pins']+[pin(B/'FROZEN.json'),pin(B/'SELECTION.json'),decision];require(result['input_pins']==expected,'Exact input/code/decision roster')
        ref=result['reference_details'];require(ref['fresh_literal_reference_correspondence'] is True and ref['recomputation_is_new_independent_case'] is False and ref['actual_W_F_to_literal_W_C_equality_is_observation'] is True and ref['original_reachability_reused_without_new_fixed_point'] is True,'Literal reference versus actual empirical result boundary')
        s=result['summary'];require(s['branch']=='ONE_WAY_HELPER' and s['helper_added'] is True and s['original_typed_carrier']==18816 and s['full_job_typed_carrier']==37632,'Exact full044 helper carrier')
        counts=s['counts'];require(set(counts)==set(s['canonical_sha256'])==set(s['state_witnesses']),'Complete root result roster')
        required={'D','W_original','U','F','C','W_F','W_direct_full','W_direct_0','W_direct_1','active_difference','trap_difference','U_missing','F_xor_C','F_missing','W_minus_F','W_loss','delayed_loss','actual_original_reachable_loss','actual_W_F_xor_literal_W_C','actual_loss_xor_literal_loss','original_W_authority_difference','independent_original_reachable','fresh_literal_W_C','prior_literal_W_C'}
        require(required<=set(counts) and counts['D']==18816 and all(type(n) is int and 0<=n<=37632 for n in counts.values()),'Required exact root cardinalities')
        require(all(type(v) is str and len(v)==64 and set(v)<=set('0123456789abcdef') for v in s['canonical_sha256'].values()),'Canonical digest shapes')
        fields={f['name'] for f in read(row['original_model']['path'])['fields']}
        for name,w in s['state_witnesses'].items():
            require((w is None)==(counts[name]==0),'Witness iff nonempty root')
            if w is not None:require(set(w['state'])==fields,'All fields/AUX in witness')
        checks=s['checks'];require(all(type(v) is bool for v in checks.values()),'Boolean helper checks')
        require(all(checks[k] is True for k in ('original_ENV_00_equal','original_SYS_00_equal','helper_ENV_10_impossible')),'Actual generalized helper structural premises')
        for name,root in (('active_decomposition_equal','active_difference'),('trap_decomposition_equal','trap_difference'),('U_equals_D','U_missing'),('F_equals_C','F_xor_C'),('F_equals_D','F_missing'),('W_subset_F','W_minus_F'),('original_full_region_preserved','W_loss'),('actual_W_F_equals_prior_literal_W_C','actual_W_F_xor_literal_W_C'),('actual_loss_equals_prior_literal_loss','actual_loss_xor_literal_loss')):require(checks[name]==(counts[root]==0),'Check/difference consistency '+name)
        require(counts['W_loss']==counts['W_minus_F']+counts['delayed_loss'] and counts['actual_original_reachable_loss']<=counts['W_loss'],'Actual exact loss partition/reachable subset')
        require(checks['original_W_exact_authority_equal'] is True and checks['original_reachable_exact_authority_equal'] is True and checks['fresh_literal_all_functions_authority_equal'] is True and checks['C_exact_literal_authority_equal'] is True and counts['original_W_authority_difference']==0,'Reference correspondence')
        require(set(s['initial_quantification'])=={'W_original','W_predicted','W_direct_active','actual_job','literal_W_C'},'Separate actual and literal quantifier roster')
        for q in s['initial_quantification'].values():require(type(q['value']) is bool and type(q['missing_initial_ENV_count']) is int and type(q['SYS_witness_count']) is int and q['missing_initial_ENV_count']>=0 and q['SYS_witness_count']>=0 and q['value']==(q['missing_initial_ENV_count']==0),'Exact initial missing-ENV semantics')
        equal=checks['active_decomposition_equal'] and checks['trap_decomposition_equal'] and checks['initial_quantification_equal'] and checks['subset_original'] and checks['full_preservation_iff_W_subset_F']
        require((result['status']=='PASS')==equal,'PASS exactly matches decomposition obligations; actual-literal comparison is not a gate')
        require(result['functions']==pin(B/'runs'/ID/'FUNCTIONS.json.gz'),'Actual functions exact pin')

def run(deadline):
    decision=authorization();d=read(decision['path']);require(d.get('deadline_utc')==deadline,'Exact Root authorized deadline')
    end=datetime.fromisoformat(deadline);require(end.tzinfo is not None,'Timezone-aware Root deadline')
    freeze=read(B/'FROZEN.json');selected=read(B/'SELECTION.json');row=selected['row'];verify(freeze['files']+[decision])
    require(freeze['python']==pin(Path(sys.executable).resolve()),'Frozen Python identity')
    require(selected['eligible_ids']==[ID] and selected['eligible_count']==1 and selected['separate_from_fixed14_helper_cohort'] is True,'Fixed one case distinct from helper cohort')
    require(not (B/'RUN_STARTED.json').exists() and not (B/'RUN_RECEIPT.json').exists() and not (B/'runs').exists(),'One analysis dispatch only; no retry/resume')
    save(B/'RUN_STARTED.json',{'started_utc':now(),'owner_pid':os.getpid(),'freeze':pin(B/'FROZEN.json'),'root_authorization':decision})
    spec=importlib.util.spec_from_file_location('analysis044_contained_stage',STAGE/'bounded_process.py');bounded=importlib.util.module_from_spec(spec);spec.loader.exec_module(bounded)
    value={'id':ID,'status':'UNKNOWN_NOT_ATTEMPTED','BDD_worker_started':False};refs=[decision,pin(B/'RUN_STARTED.json'),row['closed_main']];stop=False;reasons=[];start=time.monotonic();folder=B/'runs'/ID
    try:
        if (end-datetime.now(timezone.utc)).total_seconds()>=MIN_START_SECONDS:
            verify(freeze['code_files']+[decision])
            if (end-datetime.now(timezone.utc)).total_seconds()>=MIN_START_SECONDS:
                value['BDD_worker_started']=None
                process=bounded.run_bounded([sys.executable,'-B',str(B/'measure.py')],folder/'process',deadline,wall_seconds=60,file_bytes=67108864,watch_files=[folder/'RESULT.json',folder/'FUNCTIONS.json.gz'])
                require(process['process_started'] is None or type(process['process_started']) is bool,'Exact worker-start state')
                value.update(BDD_worker_started=process['process_started'],process=pin(folder/'process/PROCESS_RECEIPT.json'));refs += [value['process']]+pins_in(process)
                if process['status']=='PROCESS_COMPLETED' and type(process['exit_code']) is int and process['exit_code']==0 and (folder/'RESULT.json').is_file():
                    require(process['process_started'] is True and process['owned_child_reaped'] is True and process['final_group_observation']['state']=='ABSENT' and process['argv']==[sys.executable,'-B',str(B/'measure.py')],'Completed bounded worker authority')
                    value['status']='UNKNOWN_INTEGRITY';r=read(folder/'RESULT.json');validate(r,row,freeze,decision);value.update(status=r['status'],result=pin(folder/'RESULT.json'));refs += [value['result']]+pins_in(r)
                    if r['status'] in ('PASS','FAIL_DECOMPOSITION'):value['summary']=r['summary']
                else:value['status']='UNKNOWN_RESOURCE' if process['status']=='UNKNOWN_RESOURCE' else 'UNKNOWN_PROCESS'
                if value['status']!='PASS':stop=True;reasons.append(value['status'])
    except BaseException as ex:
        stop=True;reasons.append(repr(ex))
        if value['status']=='UNKNOWN_NOT_ATTEMPTED' and value['BDD_worker_started'] is not False:value['status']='UNKNOWN_RUNNER_FAILURE'
    for name in ('RESULT.json','FUNCTIONS.json.gz'):
        if (folder/name).is_file():refs.append(pin(folder/name))
    try:verify(freeze['files']+refs)
    except BaseException as ex:stop=True;reasons.append('FINAL_PIN_INTEGRITY:'+repr(ex))
    good=value['status']=='PASS' and not stop
    result={'schema':'fixed044-saved-analysis-run-v1','status':'PASS_FIXED044_ANALYSIS' if good else 'UNKNOWN_OR_FAILED','finished_utc':now(),'elapsed_seconds':time.monotonic()-start,
        'row':value,'global_stop':stop,'stop_reasons':reasons,'root_authorization':decision,'freeze':pin(B/'FROZEN.json'),'closed_model_pair':row['closed_main'],'output_pins':unique(refs),
        'BDD_worker_calls':{'confirmed':int(value['BDD_worker_started'] is True),'uncertain':int(value['BDD_worker_started'] is None),'not_called':int(value['BDD_worker_started'] is False)},
        'new_native_JVM_calls':0,'native_solver_calls':0,'controller_calls':0,'full_reset_uses':0,'unknown_is_negative':False,
        'separate_outcome_informed_single_case':True,'folded_into_fixed14_cohort':False,'compared_with_native_4fp_region':False,'returned_controller_conclusion':None,'kind_initializer_false_rejection_conclusion':None}
    save(B/'RUN_RECEIPT.json',result);print(json.dumps({k:result[k] for k in ('status','global_stop','BDD_worker_calls')}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('select','prepare','preflight','run'));p.add_argument('--deadline-utc');a=p.parse_args()
    if a.mode=='select':require(not (B/'SELECTION.json').exists(),'No selection overwrite');save(B/'SELECTION.json',select());print('Fixed044 closed evidence selected; no corpus BDD/native')
    elif a.mode=='prepare':prepare()
    elif a.mode=='preflight':verify(read(B/'FROZEN.json')['files']);print('Frozen044 analysis preparation PASS; no corpus BDD/native')
    else:require(a.deadline_utc is not None,'Root deadline required');run(a.deadline_utc)
