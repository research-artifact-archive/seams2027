"""Bounded parent launcher for the separate recovery study; no implicit run."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

from owned_process import ExactChild, GroupObserver, bounded_ps

BASE = Path(__file__).resolve().parent
START_RESERVE_SECONDS = 150
PARENT_WALL_SECONDS = 90
PARENT_CLEANUP_RESERVE_SECONDS = 8
PARENT_WATCHDOG_SECONDS = PARENT_WALL_SECONDS - PARENT_CLEANUP_RESERVE_SECONDS
OUTER_CAPTURE_BYTES = 16 * 1024 * 1024


def now():
    return datetime.now(timezone.utc).isoformat()


def pin(path):
    path = Path(path).resolve()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}


def save(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')
    temporary.replace(path)


def read(path, cap=1024 * 1024):
    path = Path(path)
    if path.stat().st_size > cap:
        raise ValueError('Receipt exceeds bounded read cap')
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('Duplicate JSON key')
            result[key] = value
        return result
    return json.loads(path.read_text(), object_pairs_hook=unique)


def canonical_pins(refs):
    if not isinstance(refs, list) or not refs:
        raise ValueError('Explicit nonempty arm-specific source pins required')
    values = {}
    for ref in refs:
        if set(ref) != {'path', 'bytes', 'sha256'} or str(Path(ref['path']).resolve()) != ref['path']:
            raise ValueError('Source pins must use canonical absolute paths')
        if ref['path'] in values and values[ref['path']] != ref:
            raise ValueError('Conflicting source pins')
        values[ref['path']] = ref
    return [values[path] for path in sorted(values)]


def pin_errors(refs):
    errors = []
    for ref in refs:
        try:
            if pin(ref['path']) != ref:
                errors.append({'path': ref['path'], 'reason': 'PIN_CHANGED'})
        except Exception as error:
            errors.append({'path': ref['path'], 'reason': repr(error)})
    return errors


def reserve_reason(deadline):
    if (deadline - datetime.now(timezone.utc)).total_seconds() < START_RESERVE_SECONDS:
        return 'DEADLINE_START_RESERVE'
    return None


def worker_binding(worker, worker_pid, command, arm):
    return (isinstance(worker, dict) and worker.get('schema') == 'contained-native-worker-receipt-v1'
            and worker.get('worker_pid') == worker_pid and worker.get('command') == command
            and worker.get('arm_dir') == str(arm) and worker.get('parent_aborted') is True
            and type(worker.get('worker_spawned_children')) is int
            and worker['worker_spawned_children'] in (0, 1)
            and type(worker.get('scientific_JVM_executions')) is int
            and worker['scientific_JVM_executions'] == (0 if worker.get('qualification_only') is True else worker['worker_spawned_children']))


def identity_binding(identity, worker_pid, command):
    pid = identity.get('child_pid')
    return (identity.get('schema') == 'contained-native-child-identity-v1'
            and identity.get('worker_pid') == worker_pid and type(pid) is int and pid > 0 and pid != worker_pid
            and identity.get('process_group_id') == pid and identity.get('command') == command
            and identity.get('command_sha256') == hashlib.sha256(json.dumps(command, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest())


def process_table():
    checked = bounded_ps('pid=,ppid=,pgid=,uid=,stat=')
    if checked['status'] != 'COMPLETE' or checked.get('returncode') != 0 or len(checked['stdout'].encode()) > 1024 * 1024:
        raise ValueError('Process table failed or exceeded observation cap')
    rows = {}
    for line in checked['stdout'].splitlines():
        fields = line.split()
        if len(fields) != 5 or any(not item.isdecimal() for item in fields[:4]):
            raise ValueError('Malformed process table')
        pid, ppid, pgid, uid = map(int, fields[:4])
        if pid <= 0 or pid in rows:
            raise ValueError('Duplicate process-table PID')
        rows[pid] = {'pid': pid, 'ppid': ppid, 'pgid': pgid, 'uid': uid, 'stat': fields[4]}
    if os.getpid() not in rows or rows[os.getpid()]['uid'] != os.getuid():
        raise ValueError('Observer missing from complete process table')
    return rows, {k: v for k, v in checked.items() if k not in ('stdout', 'stderr')}


def contain_after_parent_stop(worker, arm, command, cleanup_deadline=None):
    """Always UNKNOWN. Pause only the owned worker before checking its child.

    A confirmed stopped parent cannot reap/recycle the validated native PID
    between the live-ancestry observation and the native-group signal.
    """
    value = {'status': 'UNKNOWN_OUTER_SUPERVISOR_STOP', 'global_stop': True,
             'started_utc': now(), 'events': [], 'native_group_signal_sent': False}
    cleanup_deadline = min(time.monotonic() + PARENT_CLEANUP_RESERVE_SECONDS,
                           cleanup_deadline if cleanup_deadline is not None else float('inf'))
    def bounded_table():
        if time.monotonic() + 1 > cleanup_deadline:
            raise TimeoutError('Insufficient cleanup budget for bounded process-table helper')
        return process_table()
    try:
        if worker.poll() is None:
            event = worker.signal_owned_group(signal.SIGSTOP)
            value['events'].append(event)
            rows, helper_receipt = bounded_table()
            value['before_signal_process_table_helper'] = helper_receipt
            observed_worker = rows.get(worker.pid)
            stopped = bool(event.get('sent') and observed_worker and 'T' in observed_worker['stat']
                           and observed_worker['ppid'] == os.getpid() and observed_worker['uid'] == os.getuid()
                           and observed_worker['pgid'] == worker.pid)
            value['worker_stopped_identity_confirmed'] = stopped
            if stopped:
                identity = read(arm / 'NATIVE_CHILD_IDENTITY.json', 256 * 1024)
                if not identity_binding(identity, worker.pid, command):
                    raise ValueError('Native child identity is not bound to this request')
                child = rows.get(identity['child_pid'])
                value['native_child_row'] = child
                if child and child['ppid'] == worker.pid and child['pgid'] == child['pid'] and child['uid'] == os.getuid():
                    os.killpg(child['pid'], signal.SIGKILL)
                    value['native_group_signal_sent'] = True
                elif child is None:
                    value['events'].append({'reason': 'NO_NATIVE_PID_IN_COMPLETE_STOPPED_PARENT_SNAPSHOT'})
                else:
                    raise ValueError('Native live ancestry/group/uid not confirmed')
    except Exception as error:
        value['events'].append({'containment_unconfirmed': repr(error)})
    finally:
        try:
            if worker.poll() is None:
                value['events'].append(worker.signal_owned_group(signal.SIGKILL))
        except Exception as error:
            value['events'].append({'own_worker_signal_unconfirmed': repr(error)})
        until = min(time.monotonic() + 3, cleanup_deadline)
        while not worker.exact_reaped and time.monotonic() < until:
            try:
                worker.poll()
            except Exception as error:
                value['events'].append({'exact_worker_reap_error': repr(error)})
                break
            if not worker.exact_reaped:
                time.sleep(0.05)
        value['exact_worker_wait4'] = worker.evidence()
        try:
            rows, helper_receipt = bounded_table()
            value['final_process_table_helper'] = helper_receipt
            value['remaining_worker_group_members'] = [r for r in rows.values() if r['pgid'] == worker.pid]
            identity_path = arm / 'NATIVE_CHILD_IDENTITY.json'
            if identity_path.exists():
                identity = read(identity_path, 256 * 1024)
                if identity_binding(identity, worker.pid, command):
                    value['remaining_bound_native_group_members'] = [r for r in rows.values() if r['pgid'] == identity['child_pid']]
        except Exception as error:
            value['final_process_table_error'] = repr(error)
    value['finished_utc'] = now()
    return value


def launch_native(command, arm_dir, deadline_utc, source_pins, limits=None):
    """Run one separate-study worker; caller certifies scientific semantics.

    Existing arm or sibling .parent directories are rejected. Every technical
    result needs global_stop=False plus empty pin errors before it is adopted.
    This function grants no retry, cohort change, or modification of old runs.
    """
    started = time.monotonic()
    arm = Path(arm_dir).resolve()
    control = arm.with_name(arm.name + '.parent')
    if arm.exists() or control.exists():
        raise FileExistsError('Refusing duplicate arm/control directory')
    deadline = datetime.fromisoformat(deadline_utc)
    if deadline.tzinfo is None:
        raise ValueError('Timezone-aware deadline required')
    if not isinstance(command, list) or not command or any(not isinstance(x, str) or '\0' in x for x in command):
        raise ValueError('Nonempty string argv required')
    qualification = (limits or {}).get('qualification_only', False)
    if type(qualification) is not bool:
        raise ValueError('qualification_only must be boolean')
    if qualification and not (len(command) == 3 and Path(command[0]).resolve() == Path(sys.executable).resolve() and command[1] == '-c'):
        raise ValueError('Qualification permits only the provided synthetic Python -c child')
    refs = canonical_pins(source_pins + [pin(BASE / name) for name in ('launcher.py', 'native_worker.py', 'owned_process.py', 'lossless_stdout.py')]
                          + [pin('/bin/ps'), pin(Path(sys.executable).resolve())])
    arm.mkdir(parents=True, exist_ok=False)
    control.mkdir(parents=True, exist_ok=False)
    value = {'schema': 'contained-parent-run-v1', 'parent_aborted': True,
             'study_scope': 'SEPARATE_RECOVERY_OLD_RECEIPTS_UNCHANGED', 'started_utc': now(),
             'status': 'UNKNOWN_NOT_ATTEMPTED', 'global_stop': False, 'native_called': False,
             'qualification_only': qualification, 'provided_child_called': False,
             'worker_started': False, 'parent_exact_wait4': None, 'worker_receipt': None,
             'parent_worker_group_observation': None,
             'worker_receipt_pin': None, 'child_identity_pin': None, 'cleanup_receipt': None,
             'source_pin_errors_before': [], 'source_pin_errors_after': [], 'artifact_pin_errors': [],
             'source_pins': refs, 'command': command, 'arm_dir': str(arm), 'deadline_utc': deadline_utc,
             'start_reserve_seconds': START_RESERVE_SECONDS, 'parent_wall_seconds': PARENT_WALL_SECONDS,
             'parent_watchdog_seconds': PARENT_WATCHDOG_SECONDS, 'parent_cleanup_reserve_seconds': PARENT_CLEANUP_RESERVE_SECONDS,
             'full_reset_uses': 0, 'retries': 0}
    worker = None; parent_total_deadline = None
    try:
        reason = reserve_reason(deadline)
        if reason:
            value['reason'] = reason
            return value
        value['source_pin_errors_before'] = pin_errors(refs)
        if value['source_pin_errors_before']:
            value.update(status='UNKNOWN_INTEGRITY', global_stop=True, reason='SOURCE_PIN_BEFORE')
            return value
        reason = reserve_reason(deadline)
        if reason:
            value['reason'] = reason
            return value
        request = {'command': command, 'arm_dir': str(arm), 'deadline_utc': deadline_utc,
                   'limits': limits or {}, 'source_pins': refs}
        save(arm / 'REQUEST.json', request)
        reason = reserve_reason(deadline)
        if reason:
            value['reason'] = reason
            return value
        if signal.getsignal(signal.SIGCHLD) != signal.SIG_DFL:
            raise ValueError('Default SIGCHLD disposition required for exact worker wait4')
        out_path, err_path = control / 'worker.stdout', control / 'worker.stderr'
        with out_path.open('xb', buffering=0) as out, err_path.open('xb', buffering=0) as err:
            worker = ExactChild(subprocess.Popen([sys.executable, '-B', str(BASE / 'native_worker.py'), str(arm / 'REQUEST.json')],
                stdin=subprocess.DEVNULL, stdout=out, stderr=err, start_new_session=True))
            value.update(worker_started=True, native_called=False if qualification else None,
                         provided_child_called=None, worker_pid=worker.pid)
            parent_total_deadline = time.monotonic() + PARENT_WALL_SECONDS
            wall_deadline = time.monotonic() + PARENT_WATCHDOG_SECONDS
            while worker.poll() is None:
                if time.monotonic() >= wall_deadline or datetime.now(timezone.utc) >= deadline:
                    value['reason'] = 'OUTER_WORKER_TIMEOUT'
                    break
                if out_path.stat().st_size > OUTER_CAPTURE_BYTES or err_path.stat().st_size > OUTER_CAPTURE_BYTES:
                    value['reason'] = 'OUTER_WORKER_CAPTURE_CAP'
                    break
                time.sleep(0.05)
            if not worker.exact_reaped:
                value['cleanup_receipt'] = contain_after_parent_stop(worker, arm, command, parent_total_deadline)
                value.update(status='UNKNOWN_INTEGRITY', global_stop=True)
            value['parent_exact_wait4'] = worker.evidence()
        if out_path.stat().st_size > OUTER_CAPTURE_BYTES or err_path.stat().st_size > OUTER_CAPTURE_BYTES:
            value.update(status='UNKNOWN_INTEGRITY', global_stop=True, reason='OUTER_WORKER_CAPTURE_CAP')
        if worker.exact_reaped and value['cleanup_receipt'] is None:
            group = GroupObserver().observe(worker, final=True)
            value['parent_worker_group_observation'] = group
            if group['state'] != 'ABSENT' or group.get('basis') != 'SUCCESSFUL_PROCESS_TABLE_NO_GROUP_MEMBERS':
                value.update(status='UNKNOWN_INTEGRITY', global_stop=True, reason='PARENT_WORKER_GROUP_UNCONFIRMED')
        value['worker_stdout'], value['worker_stderr'] = pin(out_path), pin(err_path)
        receipt_path = arm / 'NATIVE_WORKER_RECEIPT.json'
        receipt = read(receipt_path)
        value['worker_receipt'], value['worker_receipt_pin'] = receipt, pin(receipt_path)
        if not worker_binding(receipt, worker.pid, command, arm):
            raise ValueError('Worker receipt not bound to launched worker/request')
        if receipt.get('qualification_only') is not qualification:
            raise ValueError('Worker qualification mode differs from request')
        if receipt['worker_spawned_children'] == 0:
            value['native_called'] = False; value['provided_child_called'] = False
        if receipt['source_pins'] != refs:
            raise ValueError('Worker source-pin roster differs from request')
        if receipt['worker_spawned_children'] == 1:
            identity_path = arm / 'NATIVE_CHILD_IDENTITY.json'
            identity = read(identity_path, 256 * 1024)
            if not identity_binding(identity, worker.pid, command) or receipt.get('child_pid') != identity['child_pid']:
                raise ValueError('Worker/native child identity mismatch')
            value['child_identity_pin'] = pin(identity_path)
            if receipt.get('native_child_identity') != value['child_identity_pin']:
                raise ValueError('Worker child identity pin mismatch')
            value['native_called'] = not qualification; value['provided_child_called'] = True
            exact = receipt.get('exact_child_wait4') or {}
            if receipt.get('child_reaped') is True and not (
                    exact.get('exact_child_reaped') is True and exact.get('pid') == identity['child_pid']
                    and exact.get('authority_lost') is False and type(exact.get('wait_status')) is int
                    and exact.get('returncode') == receipt.get('returncode')
                    and os.waitstatus_to_exitcode(exact['wait_status']) == receipt.get('returncode')
                    and isinstance(exact.get('exact_child_rusage'), dict)):
                raise ValueError('Native exact wait4 evidence inconsistent')
        for key in ('source_pin_errors_before', 'source_pin_errors_after', 'worker_source_pin_errors_after', 'result_pin_errors_after'):
            if receipt.get(key) != []:
                raise ValueError('Worker integrity check missing or failed: ' + key)
        value['artifact_pin_errors'] = pin_errors(list(receipt['artifacts'].values()))
        if value['artifact_pin_errors']:
            raise ValueError('Worker result artifact pins changed')
        contained = (receipt.get('child_reaped') is True and receipt.get('process_group_contained') is True
                     and (receipt.get('final_group_observation') or {}).get('state') == 'ABSENT'
                     and (receipt.get('final_group_observation') or {}).get('basis') == 'SUCCESSFUL_PROCESS_TABLE_NO_GROUP_MEMBERS')
        mapping = {'PROCESS_COMPLETED': ('COMPLETE_PROCESS_AND_CAPTURE', 0),
                   'TECHNICAL_RESOURCE_REFUSAL': ('UNKNOWN_RESOURCE', 1),
                   'TECHNICAL_NATIVE_REFUSAL': ('UNKNOWN_TECHNICAL', 1)}
        expected = mapping.get(receipt.get('status'))
        if not value['global_stop'] and value['cleanup_receipt'] is None and expected and contained and worker.exact_reaped and worker.returncode == expected[1]:
            value['status'] = expected[0]
        else:
            value.update(status='UNKNOWN_INTEGRITY', global_stop=True, reason=value.get('reason', 'WORKER_STATUS_OR_CONTAINMENT'))
    except Exception as error:
        value.update(status='UNKNOWN_INTEGRITY', global_stop=True, error=repr(error))
        if worker is not None and not worker.exact_reaped and value['cleanup_receipt'] is None:
            value['cleanup_receipt'] = contain_after_parent_stop(worker, arm, command, parent_total_deadline)
        if worker is not None:
            value['parent_exact_wait4'] = worker.evidence()
    finally:
        value['source_pin_errors_after'] = pin_errors(refs)
        if value['source_pin_errors_after']:
            value.update(status='UNKNOWN_INTEGRITY', global_stop=True, reason='SOURCE_PIN_AFTER')
        value['finished_utc'] = now()
        value['elapsed_seconds'] = time.monotonic() - started
        save(arm / 'PARENT_RECEIPT.json', value)
    return value
