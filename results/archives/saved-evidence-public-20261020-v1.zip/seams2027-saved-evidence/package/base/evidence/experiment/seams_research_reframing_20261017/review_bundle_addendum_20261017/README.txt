Review-bundle addendum — PREPARE ONLY

ADDENDUM.json contains four claim/evidence entries, workspace-relative file names,
current byte counts/SHA-256 pins, provenance and semantic limits. It is an index
of minimum reviewer entry points, not a copied or self-contained replay bundle.
The referenced RESULT/RUN_RECEIPT/FROZEN files retain deeper input/runtime pins.
Expand that closure only during a separately scoped packaging stage. File-byte
hashes are distinct from canonical Boolean-function fingerprints.

1. Released 044 actual pair + decomposition: read the main CHECK.json and its
FUNCTIONS.json.gz, then analysis RESULT.json and FUNCTIONS.json.gz. The original
source, typed pair, original/literal authorities, selection and process indexes
are listed. The closed result gives D=U=18816, W=2387, F=C=1211, W_F=0; active
and trap slices equal W_F and U. Strict loss is 1176 immediate + 1211 delayed.
The typed initial verdict changes true to false (8 missing ENV inputs). This
outcome-informed extra case does not enter the existing 14/13 cohort counts.
It concerns the saved transformed model; it is not a native 4FP/controller or
cooperative-positive result. The complete relation matches neither template.

2. PCar 058 source proof: original PcarLTL_464_PCar_fixed.spectra (including its
inline pattern), ROOT_CANDIDATE.txt and SOURCE_PIN.json suffice to enter the
written argument. It defeats arbitrary-memory strict cooperative strategies
from the declared initializer. The optional all-carrier extension is unadopted.
This is separate from extracted-controller graph failure and needs no K root.

3. All ten fixed condition-violating inputs: TEN_INITIAL_WV_AUDIT.json plus the
per-case closed RESULT, canonical DERIVED_REGIONS, original model/initializers,
saved quantifier roots and process pins are indexed. Every I_M(W_V) is false;
some W_V are nonempty. A strict cooperative strategy remains in V and wins
there, hence initial W_V infeasibility excludes initial cooperation without M5.
This is not all-state K emptiness, absence of cooperative loss, or a negative
interpretation of the still resource-unknown exact-loss case.

4. M5 bridge: the original written derivation, exact primary equations,
symbolic.py, primary Appendix B.1 union clarification and pin receipts are
indexed. Status is ADOPTED_WRITTEN_PROOF_WITH_STATED_PREMISES after completed
review and Root adoption. Historical candidate filenames remain unchanged.
The proof concerns finite total arenas, Q0-only labels, and final fixed-point
values. It does not match all inner approximants or validate extracted ranks.
The main/round-bridge/formal-core/supplement pins are adoption-time snapshots;
later manuscript edits require their own new snapshot, not a kernel refreeze.

RESEARCH_HISTORY.json separates Root/C/Fable10 and completed Fable11 reviews
from scientific evidence. Its early Root assessment's union follow-up was
closed by the indexed primary-text clarification and subsequent adoption.
AI review is research history, not proof or a machine-checked theorem.
No manuscript, source evidence, or current Stage1 manifest was changed. No
evidence was bulk-copied, no public/native/BDD computation was run, and no reset
was used. Source/doc/license redistribution decisions remain outside this index.
