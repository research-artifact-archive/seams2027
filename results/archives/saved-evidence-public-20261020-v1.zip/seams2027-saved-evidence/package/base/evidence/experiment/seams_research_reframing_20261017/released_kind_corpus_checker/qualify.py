"""Offline qualification only; synthetic source-profile refs are not native runs."""
from pathlib import Path
import copy,hashlib,json,math,sys
sys.dont_write_bytecode=True
import certify as c
H=Path(__file__).resolve().parent
OLD=H.parent.parent/'seams_submission_push_20261016/released_kind_pipeline_feasibility'
P=json.loads((OLD/'ORIGINAL_PROFILES.json').read_text())['profiles']

def writebdd(d,b,u,name):
 if u<2:raw=f'0 {u}\n'.encode();n=0
 else:
  order=[];seen=set()
  def visit(x):
   if x<2 or x in seen:return
   seen.add(x);v,lo,hi=b.nodes[x];visit(lo);visit(hi);order.append(x)
  visit(u);rows=[str(b.n),' '.join(map(str,range(b.n)))]+[' '.join(map(str,(x,*b.nodes[x]))) for x in order]
  raw=('\n'.join(rows)+'\n').encode();n=len(order)
 p=d/(name+'.bdd');p.write_bytes(raw)
 return {'file':p.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'node_count':n,'support':sorted(b.support(u)),'zero':u==0,'one':u==1}

def build_ref(case,profile,template,d,permute=False,invert=False):
 d.mkdir(parents=True,exist_ok=True);m=copy.deepcopy(template);m.update(fixture_id=case,case_id=case,variant='initializers')
 fields=[];nextbit=0
 for f in profile['expected_fields_in_native_order']:
  vals=sorted(f['domain']);width=max(1,math.ceil(math.log2(len(vals))));cb=list(range(nextbit,nextbit+2*width,2));nb=[v+1 for v in cb];nextbit+=2*width
  enc={}
  for i,v in enumerate(vals):
   bits=[bool((i>>j)&1)^invert for j in range(width)];enc[v]={'current':{str(k):x for k,x in zip(cb,bits)},'next':{str(k):x for k,x in zip(nb,bits)}}
  fields.append({'name':f['name'],'owner':f['owner'],'role':f['role'],'values':vals,'domain_size':len(vals),'current_bits':cb,'next_bits':nb,'encoding':enc})
 if permute:
  mapping={i:nextbit-1-i for i in range(nextbit)}
  for f in fields:
   f['current_bits']=[mapping[v] for v in f['current_bits']];f['next_bits']=[mapping[v] for v in f['next_bits']]
   for e in f['encoding'].values():
    for k in ('current','next'):e[k]={str(mapping[int(v)]):x for v,x in e[k].items()}
 m['fields']=fields;m['bdd_variable_count']=nextbit;m['bdd_variable_order']=list(range(nextbit));m['all_current_bits']=[v for f in fields for v in f['current_bits']];m['all_next_bits']=[v for f in fields for v in f['next_bits']];m['public_fields']={o:[f['name'] for f in fields if f['role']==o] for o in ('ENV','SYS')}
 m['input']={'path':str(Path(profile['source']['path']).resolve()),'sha256':profile['source']['sha256'],'bytes':profile['source']['bytes']}
 b=c.BDD(nextbit);by={f['name']:f for f in fields}
 def lit(n,v,pr):return b.cube({int(k):x for k,x in by[n]['encoding'][v]['next' if pr else 'current'].items()})
 def comp(a):
  if type(a) is bool:return int(a)
  op=a[0]
  if op=='var':return lit(a[1],'true',a[2])
  if op=='eq':return lit(a[1],a[2],a[3])
  args=[comp(x) for x in a[1:]]
  if op=='not':return b.neg(args[0])
  return {'and':b.conj,'or':b.disj,'implies':b.implies,'iff':b.iff}[op](*args)
 def dom(fs,prime):return b.conj(*(b.disj(*(lit(f['name'],v,prime) for v in f['values'])) for f in fs))
 fs={k:comp(v) for k,v in profile['formulas'].items()};fs.update(domain=dom(fields,False),domain_ENV_next=dom([f for f in fields if f['owner']=='ENV'],True),domain_SYS_next=dom([f for f in fields if f['owner']=='SYS'],True))
 m['original_bdds']={k:writebdd(d,b,u,k) for k,u in fs.items()};m['original_justices']={o:[writebdd(d,b,comp(a),o+'_justice_'+str(i)) for i,a in enumerate(profile['justices'][o])] for o in ('ENV','SYS')}
 inv=copy.deepcopy(m['source_inventory']);inv['translated']=copy.deepcopy(inv['parsed'])
 for role in ('ENV','SYS','AUX'):
  inv['translated'][role]['variables']=[{'name':f['name'],'trace_id':-999,'type':'QUALIFICATION_PROFILE_TYPED'} for f in fields if f['role']==role]
 inv['native_behaviors']['env_justice_count']=len(profile['justices']['ENV']);inv['native_behaviors']['sys_justice_count']=len(profile['justices']['SYS']);m['source_inventory']=inv
 m['qualification_only']={'synthetic_reference_from_existing_independent_profile':True,'profile_file':c.pin(OLD/'ORIGINAL_PROFILES.json'),'native_invocations':0,'permuted_bits':permute,'inverted_encoding':invert}
 c.save(d/'model.json',m);return m

def run():
 results=[]
 for case,p in P.items():
  od=H/'qualification_refs'/case;jd=OLD/'runs'/case;template=c.read_json(jd/'model.json')
  build_ref(case,p,template,od,permute=True,invert=True)
  out=H/'qualification'/case;r=c.check(od,jd,case,out,p);c.save(out/'certificate.json',r)
  expected='COMPLETE_NO_CONTROLLER' if case=='guard' else 'COMPLETE_DERIVED_ORIGINAL_CERTIFICATE'
  ok=r['status']==expected
  if expected.endswith('CERTIFICATE') and ok:
   f=r['derived_fairness'];ok= f['strict_liveness']['pass'] is True and f['nonconflicting']['pass']==(case!='justice')
  results.append({'case':case,'expected':expected,'actual':r['status'],'pass':ok,'error':r.get('mapping_error')})
 c.save(H/'QUALIFICATION_EXISTING_FOUR.json',{'status':'PASS' if all(r['pass'] for r in results) else 'FAIL','native_runs':0,'profile_derived_synthetic_references':True,'results':results})
 print(json.dumps(results,indent=2))
if __name__=='__main__':run()
