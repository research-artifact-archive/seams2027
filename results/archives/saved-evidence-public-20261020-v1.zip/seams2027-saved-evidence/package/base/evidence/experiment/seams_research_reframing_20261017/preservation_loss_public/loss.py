"""Exact complete-semantic literal-helper loss using the frozen strict solver."""
from pathlib import Path
import gzip,importlib.util,json,sys
sys.dont_write_bytecode=True
E=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('loss_frozen_condition',E/'preservation_condition_public/condition.py')
condition=importlib.util.module_from_spec(spec);spec.loader.exec_module(condition)
engine=condition.engine
from symbolic import Operations,gr1_three,initial_quantification,count,root_digest
BDD,require,ResourceRefusal=engine.BDD,engine.require,engine.ResourceRefusal


def compute(b,q,de,rhoe,rhos,den,dsn,current,en,sn,prime,assumptions,guarantees,thetae,thetas,w,reachable):
    """W_C = C intersect Win(Q, rhoE, C and rhoS and C').

    The outer C is essential: a current state outside C with no legal ENV
    input otherwise remains vacuously strict-winning in the guarded game.
    Original reachability is an imported independently certified relation fact.
    """
    current,en,sn=tuple(current),tuple(en),tuple(sn)
    require(set(prime)==set(current) and set(prime.values())==set(en+sn),'Complete current/next bijection')
    require(len(set(prime.values()))==len(prime),'Injective prime mapping')
    require(b.support(reachable)<=set(current) and b.conj(reachable,b.neg(q))==0,'Typed original reachable set')
    require(b.support(thetae)<=set(x for x in current if prime[x] in set(en)),'Original ENV initializer support')
    require(b.support(thetas)<=set(current),'Original SYS initializer support')
    roots=condition.compute(b,q,rhos,den,dsn,current,en,sn,w)
    c=roots['C'];guarded=b.conj(c,rhos,b.rename(c,prime))
    ops=Operations(b,q,rhoe,guarded,den,dsn,current,en,sn,prime)
    log={}
    raw=gr1_three(b,q,assumptions,guarantees,ops.cpre,log)
    wc=b.conj(c,raw)
    require(b.conj(wc,b.neg(w))==0,'C-invariant winning region outside authoritative original W')
    loss=b.conj(w,b.neg(wc));reach_loss=b.conj(reachable,loss)
    require(b.conj(roots['W_minus_C'],b.neg(loss))==0,'Immediate violation not included in exact loss')
    require((loss==0)==(roots['W_minus_C']==0),'Full-region preservation theorem consistency')
    roots.update(W_C=wc,W_minus_W_C=loss,original_reachable=reachable,
        original_reachable_loss=reach_loss,delayed_loss=b.conj(loss,c),
        original_initialized=b.conj(q,thetae,thetas))
    sys_current=tuple(x for x in current if prime[x] in set(sn))
    quant={name:initial_quantification(b,de,thetae,thetas,roots[name],sys_current) for name in ('W','W_C')}
    require(not quant['W_C']['value'] or quant['W']['value'],'Strengthening cannot repair negative initial feasibility')
    for name,item in quant.items():
        roots['initial_SYS_witness_'+name]=item['system_witness']
        roots['missing_initial_ENV_'+name]=item['missing_environment_initials']
    return roots,quant,log


def load_independent(model,path,proof,names=('W','reachable')):
    with gzip.open(path,'rb') as f:raw=f.read(64*1024*1024+1)
    if len(raw)>64*1024*1024:raise ResourceRefusal('Independent region uncompressed byte cap')
    payload=json.loads(raw,object_pairs_hook=engine.unique)
    roots={}
    for name in names:
        require(name in payload['roots'],'Missing authoritative independent region '+name)
        view={**payload,'roots':{'W':payload['roots'][name]}}
        root=condition.import_w(model.b,view,model.fields)
        require(model.b.support(root)<=set(model.current),'Original region current support '+name)
        require(model.b.conj(root,model.b.neg(model.q))==0,'Original region typed domain '+name)
        require(proof['comparisons'][name]['equal'] is True,'Independent region not certified '+name)
        require(count(model.b,root,model.current)==proof['counts'][name]==proof['comparisons'][name]['independent_count'],'Independent region count '+name)
        require(root_digest(model.b,root)==proof['comparisons'][name]['canonical_sha256'],'Independent region digest '+name)
        roots[name]=root
    return roots


def summarize(model,roots,quant):
    b=model.b
    state_names=('C','W','W_C','W_minus_C','W_minus_W_C','delayed_loss','original_reachable','original_reachable_loss','original_initialized')
    out={'counts':{name:count(b,roots[name],model.current) for name in state_names},
        'canonical_sha256':{name:root_digest(b,root) for name,root in roots.items()},
        'W_subset_C':roots['W_minus_C']==0,'full_region_preserved':roots['W_minus_W_C']==0,
        'original_reachable_loss_nonempty':roots['original_reachable_loss']!=0,
        'initial_quantification':{},'state_witnesses':{},'missing_initial_ENV_witnesses':{}}
    for name,item in quant.items():
        out['initial_quantification'][name]={'value':item['value'],
            'missing_environment_initial_count':count(b,item['missing_environment_initials'],model.ec),
            'system_witness_count':count(b,item['system_witness'],model.current)}
        root=item['missing_environment_initials']
        if root:
            bits=b.satone(root,model.ec)
            out['missing_initial_ENV_witnesses'][name]={'ENV':condition.typed_values(model.fields,bits,'current','ENV'),'bits':bits}
        else:out['missing_initial_ENV_witnesses'][name]=None
    out['initial_verdict_changed']=quant['W']['value']!=quant['W_C']['value']
    out['initial_ENV_choice_count']=count(b,b.conj(model.de,model.forms['thetaE']),model.ec)
    out['initial_ENV_nonempty']=out['initial_ENV_choice_count']>0
    for name in ('W_minus_C','W_minus_W_C','delayed_loss','original_reachable_loss'):
        if roots[name]:
            bits=b.satone(roots[name],model.current)
            require(b.evaluate(roots[name],bits),'State witness membership')
            out['state_witnesses'][name]={'state':condition.typed_values(model.fields,bits,'current'),'bits':bits}
        else:out['state_witnesses'][name]=None
    return out


def export(path,model,roots):
    seen=set();todo=list(roots.values())
    while todo:
        u=todo.pop()
        if u<2 or u in seen:continue
        seen.add(u);todo.extend(model.b.nodes[u][1:])
    payload={'schema':'complete-semantic-preservation-loss-robdd-v1','variable_count':model.b.n,
        'canonical_variable_order':list(range(model.b.n)),'fields':model.fields,
        'current_bits':model.current,'ENV_current_bits':model.ec,'SYS_and_AUX_current_bits':model.sc,
        'ENV_next_bits':model.en,'SYS_and_AUX_next_bits':model.sn,'roots':roots,
        'nodes':[[u,*model.b.nodes[u]] for u in sorted(seen)]}
    with gzip.GzipFile(filename=str(path),mode='wb',mtime=0) as f:
        f.write(json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode())
