"""Unchanged qualified solver/lift; build uses the already frozen044 typed map."""
import sys
sys.dont_write_bytecode=True
from evidence import C,M,load_module
frozen=load_module('analysis044_frozen_decomposition',C/'decomposition.py')
solve,lifted_inputs,count,digest,BDD,ResourceRefusal,pair_module,symbolic=(getattr(frozen,n) for n in
    ('solve','lifted_inputs','count','digest','BDD','ResourceRefusal','pair_module','symbolic'))
admitted_pair=load_module('analysis044_frozen_admitted_pair',M/'map_pair.py')
build=admitted_pair.build
MapResourceRefusal=admitted_pair.ResourceRefusal
