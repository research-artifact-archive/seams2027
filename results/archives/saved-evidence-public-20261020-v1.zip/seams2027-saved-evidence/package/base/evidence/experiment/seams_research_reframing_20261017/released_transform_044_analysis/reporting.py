"""Unchanged qualified decomposition state summaries and canonical exports."""
import gzip,json
from evidence import require
from decomposition import count,digest,ResourceRefusal

def decode(fields,bits):
    out={}
    for f in fields:
        matches=[v for v in f['values'] if all(bits[int(k)]==value for k,value in f['encoding'][v]['current'].items())]
        require(len(matches)==1,'Typed state witness bijection');out[f['name']]=matches[0]
    return out

def summarize(pair,out):
    b=pair['common'];o=pair['original'];cur=tuple(o.current);helper=pair['helper_added'];h=pair['helper_current_bit'];hcur=cur+((h,) if helper else ())
    full_names={'W_direct_full','job_initial_SYS_witness','job_missing_initial_ENV'}
    counts={};witnesses={};digests={}
    for name,u in out['roots'].items():
        vs=hcur if name in full_names else cur
        counts[name]=count(b,u,vs);digests[name]=digest(b,u);witnesses[name]=None
        if u:
            bits=b.satone(u,vs);require(b.evaluate(u,bits),'State witness membership')
            witnesses[name]={'state':decode(pair['original_fields'],bits),'bits':bits,'helper_current':bits[h] if helper and h in bits else None}
    quant={name:{'value':q['value'],'missing_initial_ENV_count':count(b,q['missing_environment_initials'],o.current_env),'SYS_witness_count':count(b,q['system_witness'],cur)} for name,q in out['quant'].items()}
    jq=out['actual_job_quant'];quant['actual_job']={'value':jq['value'],'missing_initial_ENV_count':count(b,jq['missing_environment_initials'],tuple(o.current_env)+((h,) if helper else ())),
        'SYS_witness_count':count(b,jq['system_witness'],hcur)}
    return {'branch':out['branch'],'helper_added':helper,'counts':counts,'canonical_sha256':digests,'state_witnesses':witnesses,'checks':out['checks'],'initial_quantification':quant,
        'original_typed_carrier':o.carrier,'full_job_typed_carrier':o.carrier*(2 if helper else 1),
        'initial_ENV_choice_count':count(b,b.conj(b.exists(out['roots']['D'],o.current_sys),pair['original_roots']['thetaE']),o.current_env)}

def export(path,pair,roots):
    b=pair['common'];seen=set();todo=list(roots.values())
    while todo:
        u=todo.pop()
        if u<2 or u in seen:continue
        seen.add(u);todo.extend(b.nodes[u][1:])
    payload={'schema':'helper-decomposition-canonical-functions-v1','variable_count':b.n,'canonical_variable_order':list(range(b.n)),
        'original_fields':pair['original_fields'],'original_current_bits':pair['original_current_bits'],'original_next_bits':pair['original_next_bits'],
        'helper_current_bit':pair['helper_current_bit'],'helper_next_bit':pair['helper_next_bit'],'roots':roots,'nodes':[[u,*b.nodes[u]] for u in sorted(seen)]}
    raw=json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode()
    if len(raw)>64*1024*1024:raise ResourceRefusal('Canonical function export cap64MiB')
    with gzip.GzipFile(filename=str(path),mode='wb',mtime=0) as f:f.write(raw)
