"""Separate bounded three-arm study after a preserved corpus integrity stop.

All scientific producers and checkers are unchanged. This file owns only the
new selection, process invocation, and receipts. No old receipt is rewritten.
"""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import argparse, hashlib, importlib.util, json, math, os, sys, time
sys.dont_write_bytecode = True
B = Path(__file__).resolve().parent
E = B.parent
OLD = E/'kind_corpus'
RLE = E/'kind_corpus_rle'
INITIAL = E/'initial_graph_native'
PUBLIC = E/'released_kind_corpus_native'
JOB = E.parent/'seams_submission_push_20261016/released_kind_pipeline_feasibility'
RECOVERY = E/'contained_recovery'
STAGE_PROCESS = E/'contained_stage_process'
CHECK = E/'initial_graph_checker'
PCHECK = E/'released_kind_corpus_checker'
DEADLINE = '2026-10-17T01:00:00+00:00'
MIN_START_SECONDS = 240  # Native supervisor + graph checker + canonical join.
NATIVE_DEADLINE = (datetime.fromisoformat(DEADLINE)-timedelta(seconds=90)).isoformat()
ARMS = [('v_restricted_strict','3fp'),('normalized_kind','4fp'),('released_kind',None)]
QUALS = [('corpus002__original','v_restricted_strict','3fp'),
         ('corpus002__original','normalized_kind','4fp'),
         ('corpus002__original','released_kind',None),
         ('corpus093__original','released_kind',None)]

def require(ok, text):
    if not ok: raise ValueError(text)

def read(p): return json.loads(Path(p).read_text())
def now(): return datetime.now(timezone.utc).isoformat()
def save(p, value):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

def pin(p):
    p=Path(p).resolve();h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}

def unique(refs):
    result={}
    for ref in refs:
        require(set(ref)>={'path','bytes','sha256'},'Malformed pin')
        ref={k:ref[k] for k in ('path','bytes','sha256')}
        require(ref['path'] not in result or result[ref['path']]==ref,'Conflicting pins')
        result[ref['path']]=ref
    return list(result.values())

def errors(refs):
    bad=[]
    for ref in refs:
        try:
            if pin(ref['path'])!=ref:bad.append({'path':ref['path'],'reason':'CHANGED'})
        except Exception as ex:bad.append({'path':ref['path'],'reason':repr(ex)})
    return bad

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def seconds_left():
    return (datetime.fromisoformat(DEADLINE)-datetime.now(timezone.utc)).total_seconds()

def model_refs(folder):
    model=read(folder/'model.json');refs=[pin(folder/'model.json')]
    for item in list(model['original_bdds'].values())+[x for v in model['original_justices'].values() for x in v]:
        require(Path(item['file']).name==item['file'],'Original BDD basename')
        value=pin(folder/item['file'])
        require(value['bytes']==item['bytes'] and value['sha256']==item['sha256'],'Original model BDD pin')
        refs.append(value)
    return refs

def selection():
    """Use all saved models, then prove the same small cohort in the first run."""
    roster=read(OLD/'ROSTER.json')['unique_inputs']
    require(len(roster)==425 and len({r['id'] for r in roster})==425,'Source denominator')
    rows=[];first_ids=[];selected=[];refs=[]
    for row in roster:
        ident=row['id'];a=OLD/'runs'/ident/'model.json';z=RLE/'runs'/ident/'model.json'
        item={'id':ident,'source':row['path'],'eligible':False}
        if a.exists():
            am=read(a);an=math.prod(f['domain_size'] for f in am['fields'])
            require(am['input']['sha256']==row['sha256'],'First model/source identity')
            refs.append(pin(a))
            if an<=4096:first_ids.append(ident)
        chosen=z if z.exists() else a
        if chosen.exists():
            m=read(chosen);size=math.prod(f['domain_size'] for f in m['fields'])
            require(m['input']['sha256']==row['sha256'] and m['fixture_id']==ident,'Selection identity')
            item.update(typed_carrier=size,model=pin(chosen),eligible=size<=4096,
                        reason='ELIGIBLE' if size<=4096 else 'CARRIER_ABOVE_4096')
            refs.append(pin(chosen))
            if item['eligible']:
                require(chosen==z,'Every eligible case requires the saved RLE model')
                folder=z.parent;worker=read(folder/'NATIVE_WORKER_RECEIPT.json')
                outcome=read(folder/'OUTCOME.json');result=read(folder/'result.json')
                require(worker['status']=='PROCESS_COMPLETED' and worker['returncode']==0
                        and worker['child_reaped'] is True and worker['process_group_contained'] is True,
                        'Selected case has no successful process lifecycle')
                require(outcome['outcome']=='COMPLETE_SYMBOLIC_INDEPENDENT_PENDING'
                        and result['status']=='COMPLETE_CORPUS_REGION_PROBE','Selected extraction incomplete')
                require(outcome['capture']['status']=='PASS' and not outcome['capture']['cap_reached'],'Selected capture incomplete')
                refs += model_refs(folder)
                refs += [pin(folder/n) for n in ('OUTCOME.json','result.json','NATIVE_WORKER_RECEIPT.json',
                         'NATIVE_CHILD_IDENTITY.json','RLE_CAPTURE_VERIFICATION.json','RLE_STDOUT_RECEIPT.json')]
                for ref in worker['artifacts'].values():
                    require(pin(ref['path'])==ref,'Selected worker artifact changed');refs.append(ref)
                selected.append(ident)
        else:item['reason']='NO_SAVED_ORIGINAL_MODEL'
        rows.append(item)
    require(first_ids==selected,'Interrupted run changed the small cohort')
    require(len(selected)==14,'Unexpected pre-reviewed cohort size')
    parent=read(RLE/'RUN_RECEIPT.json')
    require(parent['global_stop'] is True and parent['pin_errors']==[],'Preserved parent-stop identity')
    refs += [pin(OLD/'ROSTER.json'),pin(RLE/'RUN_RECEIPT.json'),pin(OLD/'RUN_RECEIPT.json')]
    return {'schema':'small-recovery-selection-v1','created_utc':now(),'total':425,
            'eligible_count':len(selected),'eligible_ids':selected,'rows':rows,
            'first_run_small_ids':first_ids,'same_small_cohort_before_interrupted_run':True,
            'parent_aborted':True,'parent_stop':pin(RLE/'RUN_RECEIPT.json'),
            'selection_uses_mathematical_or_graph_outcomes':False,
            'selected_existing_process_checks_are_evidence_admission_not_selection':True,
            'input_pins':unique(refs)}

def prepare():
    require(not (B/'FROZEN.json').exists(),'No duplicate freeze')
    chosen=read(B/'SELECTION.json');require(not errors(chosen['input_pins']),'Selection drift')
    refs=read(OLD/'FROZEN.json')['files']+chosen['input_pins']
    refs += [pin(B/n) for n in ('run.py','join_stage.py','PROTOCOL_JA.txt','SELECTION.json',
                               'qualify_accounting.py','OFFLINE_ACCOUNTING_QUALIFICATION.json',
                               'ROOT_PREFLIGHT_REVIEW.json')]
    refs += [pin(OLD/'FROZEN.json'),pin(RLE/'FROZEN.json')]
    refs += read(RLE/'FROZEN.json')['files']
    for q in (INITIAL,PUBLIC):
        refs += [pin(f) for sub in ('src','classes') for f in sorted((q/sub).glob('*')) if f.is_file()]
    refs += [pin(f) for f in sorted((RLE/'classes').glob('*.class'))]
    refs += [pin(RLE/n) for n in ('decode.py','semantic_qualification.py')]
    refs += [pin(JOB/n) for n in ('STATIC_SOURCE_AUDIT.json','SOURCE_ROUTE_TRACE.tsv','EXECUTION_FREEZE.json','src/ReleasedKindJobProducer.java')]
    refs += [pin(f) for f in sorted((JOB/'classes').glob('*.class'))]
    refs += [pin(CHECK/n) for n in ('initial_graph_checker.py','SOURCE_FREEZE.json','QUALIFICATION.json','SUMMARY.json')]
    refs += [pin(f) for f in sorted((CHECK/'vendor').glob('*.py'))]
    refs += [pin(PCHECK/'PRODUCTION_SOURCE_FREEZE.json')]+read(PCHECK/'PRODUCTION_SOURCE_FREEZE.json')['files']
    refs += [pin(E/'corpus_comparison/FROZEN.json'),pin(E/'corpus_comparison/DEPENDENCY_FREEZE.json')]
    refs += read(E/'corpus_comparison/FROZEN.json')['files']+read(E/'corpus_comparison/DEPENDENCY_FREEZE.json')['files']
    refs += [pin(INITIAL/'run.py')]
    refs += [pin(RECOVERY/'FROZEN.json')]+read(RECOVERY/'FROZEN.json')['files']
    refs += [pin(STAGE_PROCESS/'FROZEN.json')]+read(STAGE_PROCESS/'FROZEN.json')['files']
    refs=unique(refs);bad=errors(refs);require(not bad,'Freeze dependencies changed: '+repr(bad))
    save(B/'FROZEN.json',{'created_utc':now(),'files':refs,'python':pin(Path(sys.executable).resolve()),
         'parent_aborted':True,'cohort':pin(B/'SELECTION.json'),'deadline_utc':DEADLINE,'workers':1,
         'unchanged_scientific_producers':True,'arms':ARMS,'qualifications':QUALS,'native_calls':0})
    print(json.dumps({'status':'PREPARED','files':len(refs),'eligible':len(chosen['eligible_ids']),'native_calls':0}))

class Runner:
    def __init__(self):
        package=read(B/'FROZEN.json');self.refs=package['files']+[pin(B/'FROZEN.json')]
        self.source_refs=list(self.refs)
        require(package['python']==pin(Path(sys.executable).resolve()),'Python identity')
        self.selected=read(B/'SELECTION.json')['eligible_ids']
        self.roster={r['id']:r for r in read(OLD/'ROSTER.json')['unique_inputs']}
        self.rows=[];self.qual=[];self.stop=False;self.reasons=[];self.pin_errors=[]
        self.stage='QUALIFICATION';self.start=time.monotonic();self.attempts={}
        sys.path.insert(0,str(RECOVERY));sys.path.insert(0,str(RLE))
        self.launch=load('small_recovery_launcher',RECOVERY/'launcher.py').launch_native
        self.decode=load('small_recovery_decode',RLE/'decode.py').verify_stream
        self.bound=load('small_recovery_stage_bound',STAGE_PROCESS/'bounded_process.py').run_bounded
        self.plan=read(OLD/'FROZEN.json')
    def fail(self,reason):self.stop=True;self.reasons.append(reason)
    def audit(self,path):
        bad=errors(self.refs);self.pin_errors.extend(bad)
        save(path,{'created_utc':now(),'checked':len(self.refs),'errors':bad})
        if bad:self.fail('PIN_INTEGRITY')
        return not bad
    def close_arm(self,arm,value,extra=None):
        save(arm/'OUTCOME.json',value)
        folders=[arm,arm.with_name(arm.name+'.parent')]
        if extra is not None:folders.append(extra)
        for folder in folders:
            if folder.exists():self.refs=unique(self.refs+[pin(p) for p in sorted(folder.rglob('*')) if p.is_file()])
        return value
    def command(self,row,pipeline,solver,arm):
        start=[self.plan['java'],'-Xmx512m','-XX:MaxDirectMemorySize=128m','-Dbdd=jtlv','-Dbddver=default',
               '-Dbdd_table_size=10000','-Dbdd_cache_size=1000','-cp']
        if pipeline=='released_kind':
            cp=':'.join([str(PUBLIC/'classes'),str(RLE/'classes'),str(JOB/'classes'),self.plan['classpath']])
            rest=['ReleasedKindWithRle',row['id']]
        else:
            cp=':'.join([str(INITIAL/'classes'),str(RLE/'classes'),self.plan['classpath']])
            rest=['InitialGraphWithRle',row['id'],pipeline,solver]
        return start+[cp]+rest+[str(OLD/'original'/row['path']),str(arm/'result.json'),self.plan['origins']]
    def attempt(self,ident,pipeline,solver,phase):
        value={'id':ident,'pipeline':pipeline,'phase':phase,'outcome':'UNKNOWN_NOT_ATTEMPTED',
               'native_called':False,'strict_controller_pass':None,'nonconflicting_pass':None}
        self.attempts[(phase,ident,pipeline)]=value
        if self.stop or seconds_left()<MIN_START_SECONDS:
            value['reason']='GLOBAL_STOP_OR_DEADLINE';return value
        row=self.roster[ident];arm=B/phase/ident/pipeline;arm.parent.mkdir(parents=True,exist_ok=True)
        require(self.audit(B/'audits'/phase/(ident+'__'+pipeline+'__before.json')),'Pins before native')
        if seconds_left()<MIN_START_SECONDS:
            value['reason']='DEADLINE_AFTER_PIN_AUDIT';return value
        command=self.command(row,pipeline,solver,arm)
        value['native_called']=None  # Until a bound worker receipt establishes it.
        parent=self.launch(command,arm,NATIVE_DEADLINE,self.source_refs)
        value.update(native_called=parent['native_called'],parent_receipt=pin(arm/'PARENT_RECEIPT.json'),parent_status=parent['status'])
        if parent['global_stop']:self.fail('PARENT_INTEGRITY')
        # Preserve the producer-time bytes before any decoder, checker or join
        # can consume them. Later pinning alone would not establish this link.
        native_refs=[value['parent_receipt']]
        native_refs += [parent[k] for k in ('worker_receipt_pin','child_identity_pin','worker_stdout','worker_stderr') if parent.get(k)]
        native_refs += list((parent.get('worker_receipt') or {}).get('artifacts',{}).values())
        self.refs=unique(self.refs+native_refs)
        require(self.audit(B/'audits'/phase/(ident+'__'+pipeline+'__native_binding.json')),'Producer-time artifact pins changed')
        if parent['status']!='COMPLETE_PROCESS_AND_CAPTURE':
            value['outcome']=parent['status'];return self.close_arm(arm,value)
        result=read(arm/'result.json');capture=self.decode(arm/'stdout.txt.gz');end=read(arm/'RLE_STDOUT_RECEIPT.json')
        require(all(capture[k]==end[k] for k in ('raw_bytes','raw_sha256','repeated_lines','data_records','cap_reached')),'Decoded native RLE receipt')
        save(arm/'RLE_CAPTURE_VERIFICATION.json',capture)
        if capture['status']!='PASS' or capture['cap_reached']:
            value['outcome']='UNKNOWN_NATIVE_CAPTURE';self.fail('NATIVE_CAPTURE');return self.close_arm(arm,value)
        require(self.audit(B/'audits'/phase/(ident+'__'+pipeline+'__after_native.json')),'Pins after native')
        value.update(native_status=result.get('status'),native_initial_verdict=result.get('native_initial_verdict'),
                     helper_added=result.get('helper_added'),initial_in_region=result.get('initial_in_region'))
        scientific_complete=result.get('teardown')=='COMPLETED' and (
            result.get('status','').startswith('JOB_') if pipeline=='released_kind' else result.get('status','').startswith('COMPLETE_'))
        if not scientific_complete:
            value['outcome']='UNKNOWN_NATIVE_TECHNICAL';return self.close_arm(arm,value)
        certpath=arm/'certificate.json';dest=None
        if pipeline=='released_kind':
            dest=PCHECK/'small_recovery'/phase/ident;dest.mkdir(parents=True,exist_ok=False)
            checkcmd=[sys.executable,'-B',str(PCHECK/'certify.py'),'--original-dir',str(RLE/'runs'/ident),
                      '--job-dir',str(arm),'--case-id',ident,'--output-dir',str(dest)]
            certpath=dest/'certificate.json'
        else:checkcmd=[sys.executable,'-B',str(CHECK/'initial_graph_checker.py'),str(arm),ident,pipeline]
        checked=self.bound(checkcmd,arm/'checker',DEADLINE,wall_seconds=60,file_bytes=64*1024*1024,watch_files=[certpath])
        value['checker_process']=pin(arm/'checker/PROCESS_RECEIPT.json')
        allowed_codes=(0,) if pipeline=='released_kind' else (0,2)
        if checked['status']!='PROCESS_COMPLETED' or checked['exit_code'] not in allowed_codes:
            value['outcome']='UNKNOWN_CHECKER_RESOURCE' if checked['status']=='UNKNOWN_RESOURCE' else 'UNKNOWN_CHECKER_PROCESS'
            if checked['status'].startswith('FATAL_'):self.fail('CHECKER_PROCESS_INTEGRITY')
        else:
            if pipeline!='released_kind':save(certpath,read(arm/'checker/stdout.txt'))
            cert=read(certpath);status=cert['status'];value.update(certificate=pin(certpath),certificate_status=status)
            if pipeline=='released_kind':
                categories={'COMPLETE_DERIVED_ORIGINAL_CERTIFICATE':'COMPLETE_ORIGINAL_VIEW_GRAPH_CHECKED',
                     'COMPLETE_NO_CONTROLLER':'COMPLETE_NATIVE_NO_CONTROLLER','COMPLETE_VACUOUS_ENV_INITIALS':'COMPLETE_VACUOUS_INITIALIZER',
                     'COMPLETE_CONTROLLER_DEFECT':'COMPLETE_CONTROLLER_CONTRACT_FAILURE','UNKNOWN_RESOURCE':'UNKNOWN_CHECKER_RESOURCE',
                     'UNKNOWN_CAPTURE_OR_FREEZE_INTEGRITY':'UNKNOWN_CHECKER_INTEGRITY'}
                value['outcome']=categories.get(status,'UNKNOWN_ORIGINAL_MAPPING')
                fair=cert.get('derived_fairness') or {}
                value.update(strict_controller_pass=fair.get('strict_liveness',{}).get('pass'),
                             nonconflicting_pass=fair.get('nonconflicting',{}).get('pass'),
                             controller_defect=cert.get('controller_defect'),mapping_error=cert.get('mapping_error'))
            else:
                expected_exit=0 if status in ('VALID_EXPORT_CERTIFICATE','VALID_SEMANTIC_REFUSAL','VALID_VACUOUS_INITIALIZER') else 2
                require(checked['exit_code']==expected_exit,'Checker exit/status authority')
                categories={'VALID_EXPORT_CERTIFICATE':'COMPLETE_GRAPH_CHECKED',
                     'VALID_SEMANTIC_REFUSAL':'COMPLETE_NATIVE_REGION_REFUSAL','VALID_VACUOUS_INITIALIZER':'COMPLETE_VACUOUS_INITIALIZER',
                     'RESOURCE_REFUSAL':'UNKNOWN_CHECKER_RESOURCE'}
                value['outcome']=categories.get(status, 'COMPLETE_CONTROLLER_CONTRACT_FAILURE' if cert.get('refusal_scope')=='CANDIDATE_CONTROLLER'
                     else 'UNKNOWN_EXTRACTION_OR_EXPORT' if cert.get('refusal_scope')=='CANDIDATE_TECHNICAL' else 'UNKNOWN_CHECKER_INTEGRITY')
                value.update(strict_controller_pass=cert.get('strict_controller_pass'),nonconflicting_pass=cert.get('nonconflicting_pass'),
                             kind_controller_pass=cert.get('kind_controller_pass'))
            if value['outcome']=='UNKNOWN_CHECKER_INTEGRITY':self.fail('CHECKER_INTEGRITY')
        require(self.audit(B/'audits'/phase/(ident+'__'+pipeline+'__after_checker.json')),'Pins after checker')
        if pipeline!='released_kind' and (arm/'model.json').exists() and not self.stop:
            command=[sys.executable,'-B',str(B/'join_stage.py'),ident,pipeline,str(arm)]
            joined=self.bound(command,arm/'join',DEADLINE,wall_seconds=60,file_bytes=64*1024*1024,watch_files=[arm/'MODEL_JOIN.json'])
            value['join_process']=pin(arm/'join/PROCESS_RECEIPT.json')
            if joined['status']=='PROCESS_COMPLETED' and joined['exit_code']==0 and (arm/'MODEL_JOIN.json').exists():
                value['model_join']=pin(arm/'MODEL_JOIN.json')
                j=read(arm/'MODEL_JOIN.json');value['original_arena_equal']=j.get('original_arena',{}).get('status')=='EXACT_ORIGINAL_ARENA_MATCH'
                value['region_equal']=j.get('region_comparison',{}).get('exact_function_equal')
                value['independent_region_authority']=j.get('region_comparison',{}).get('phase1_independently_certified')
            else:value['model_join_status']='UNKNOWN_INCOMPLETE_JOIN'
            if joined['status'].startswith('FATAL_'):self.fail('JOIN_PROCESS_INTEGRITY')
        require(self.audit(B/'audits'/phase/(ident+'__'+pipeline+'__after.json')),'Pins after arm')
        self.close_arm(arm,value,dest)
        with (B/'ACTIVITY.jsonl').open('a') as f:f.write(json.dumps(value,ensure_ascii=False)+'\n')
        print(json.dumps({k:value.get(k) for k in ['id','pipeline','phase','outcome','strict_controller_pass','nonconflicting_pass','region_equal']}),flush=True)
        return value
    def execute(self):
        for ident,pipeline,solver in QUALS:
            value=self.attempt(ident,pipeline,solver,'qualification');self.qual.append(value)
            if pipeline=='released_kind':
                ok=value['outcome'] in ('COMPLETE_ORIGINAL_VIEW_GRAPH_CHECKED','COMPLETE_NATIVE_NO_CONTROLLER','COMPLETE_CONTROLLER_CONTRACT_FAILURE')
                ok=ok and value.get('helper_added') is (ident=='corpus093__original')
            else:ok=value['outcome']=='COMPLETE_GRAPH_CHECKED' and value.get('original_arena_equal') is True and value.get('region_equal') is True
            if not ok:self.fail('QUALIFICATION_INTEGRATION_FAILED')
        save(B/'QUALIFICATION.json',{'status':'PASS' if not self.stop else 'FAIL','rows':self.qual,'new_scientific_sources':0})
        self.stage='MAIN_COHORT'
        for ident in self.selected:
            for pipeline,solver in ARMS:self.rows.append(self.attempt(ident,pipeline,solver,'runs'))
        self.stage='COMPLETE'
    def finish(self):
        for value in self.attempts.values():
            if value.get('native_called') is not False and value.get('outcome')=='UNKNOWN_NOT_ATTEMPTED':
                value.update(outcome='UNKNOWN_RUNNER_FAILURE',reason='Invocation began but attempt did not return')
        qualified={(r['id'],r['pipeline']) for r in self.qual}
        for (phase,ident,pipeline),value in self.attempts.items():
            if phase=='qualification' and (ident,pipeline) not in qualified:
                self.qual.append(value);qualified.add((ident,pipeline))
        self.qual += [{'id':ident,'pipeline':pipeline,'phase':'qualification','outcome':'UNKNOWN_NOT_ATTEMPTED','native_called':False}
                      for ident,pipeline,_ in QUALS if (ident,pipeline) not in qualified]
        known={(r['id'],r['pipeline']) for r in self.rows}
        for (phase,ident,pipeline),value in self.attempts.items():
            if phase=='runs' and (ident,pipeline) not in known:self.rows.append(value);known.add((ident,pipeline))
        self.rows += [{'id':ident,'pipeline':pipeline,'phase':'runs','outcome':'UNKNOWN_NOT_ATTEMPTED','native_called':False}
                      for ident in self.selected for pipeline,_ in ARMS if (ident,pipeline) not in known]
        self.audit(B/'FINAL_PIN_AUDIT.json')
        def counts(rows):
            return {'confirmed':sum(x.get('native_called') is True for x in rows),
                    'uncertain':sum(x.get('native_called') is None for x in rows)}
        receipt={'schema':'small-native-recovery-v1','finished_utc':now(),'elapsed_seconds':time.monotonic()-self.start,
                 'parent_aborted':True,'preserved_parent_receipt':pin(RLE/'RUN_RECEIPT.json'),
                 'global_stop':self.stop,'stop_reasons':self.reasons,'pin_errors':self.pin_errors,'stage':self.stage,
                 'source_denominator':425,'eligible_count':len(self.selected),'rows':self.rows,'qualification_rows':self.qual,
                 'main_native_calls':counts(self.rows),'qualification_native_calls':counts(self.qual),'workers':1,
                 'native_call_count_scope':'Confirmed JVM executions; internal solver calls are recorded by each scientific producer',
                 'full_reset_uses':0,'unknown_is_negative':False,'performance_comparison':False}
        save(B/'RUN_RECEIPT.json',receipt);print(json.dumps({k:receipt[k] for k in ['global_stop','stage','main_native_calls','qualification_native_calls']}))
        save(B/'RESULT_FILES.json',{'files':[pin(p) for p in sorted(B.rglob('*')) if p.is_file()
              and p.name!='RESULT_FILES.json' and '__pycache__' not in p.parts]})

def main():
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['select','prepare','preflight','run']);a=ap.parse_args()
    if a.mode=='select':
        require(not (B/'SELECTION.json').exists(),'No selection overwrite');save(B/'SELECTION.json',selection());print('Selected all 14 small inputs; native=0');return
    if a.mode=='prepare':prepare();return
    f=read(B/'FROZEN.json');require(not errors(f['files']),'Frozen dependency changed')
    if a.mode=='preflight':print(json.dumps({'status':'PASS_SOURCE_FREEZE','native_calls':0}));return
    require(not (B/'RUN_STARTED.json').exists() and not (B/'RUN_RECEIPT.json').exists(),'No duplicate study')
    require(read(B/'ROOT_START_DECISION.json').get('start_authorized') is True,'Explicit root review decision required')
    with (B/'RUN_STARTED.json').open('x') as out:json.dump({'started_utc':now(),'owner_pid':os.getpid(),'freeze':pin(B/'FROZEN.json')},out)
    runner=Runner()
    try:runner.execute()
    except BaseException as ex:runner.fail('RUNNER_EXCEPTION:'+repr(ex))
    finally:runner.finish()

if __name__=='__main__':main()
