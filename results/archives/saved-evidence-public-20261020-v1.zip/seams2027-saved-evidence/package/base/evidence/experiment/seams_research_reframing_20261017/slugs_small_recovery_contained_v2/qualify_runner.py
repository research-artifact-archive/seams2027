"""Offline dependency-gate tests only. No child, solver, or BDD computation."""
from pathlib import Path
import ast,copy,json,sys,tempfile
from unittest.mock import patch
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;sys.path.insert(0,str(B))
import run as runner
from bounded_process import pin,save,now

tests=[]
def require(ok):
    if not ok:raise AssertionError('Qualification expectation failed')
def test(name,fn):
    try:fn();tests.append({'name':name,'pass':True})
    except Exception as ex:tests.append({'name':name,'pass':False,'error':repr(ex)})
def rejects(fn):
    try:fn()
    except (ValueError,KeyError,TypeError):return
    raise AssertionError('Expected integrity rejection')
def read(p):return json.loads(Path(p).read_text())

old=B.parent/'slugs_corpus_native'
baseline=read(B/'BASELINE_SOURCE.json');parent_pin=baseline['original_parent_phase1_stop_receipt']
test('old_source_and_parent_stop_pins_unchanged',lambda:require(not runner.pin_errors(baseline['files']+[parent_pin])))
test('old_parent_integrity_stop_is_preserved',lambda:runner.validate_parent(read(parent_pin['path'])))
for name in ('stage.py',):
    test('byte_identical_'+name,lambda name=name:require((B/name).read_bytes()==(old/name).read_bytes()))
def scientific_functions_unchanged():
    trees=[ast.parse((p/'run.py').read_text()) for p in (old,B)]
    def selected(tree):
        result={n.name:ast.dump(n,include_attributes=False) for n in tree.body
                if isinstance(n,ast.FunctionDef) and n.name in ('classify_certificate','native_status')}
        return result
    require(selected(trees[0])==selected(trees[1]))
test('unchanged_native_verdict_and_certificate_classifiers',scientific_functions_unchanged)
def contained_supervisor():
    location=B.parent/'contained_stage_process'
    require(Path(runner.run_bounded.__code__.co_filename).resolve()==location/'bounded_process.py')
    integration=read(location/'ROOT_INTEGRATION.json')
    require(not runner.pin_errors(integration['source_pins']))
    for filename,wanted in [('OFFLINE_QUALIFICATION.json',24),('PROCESS_QUALIFICATION.json',7)]:
        q=read(location/filename);require(q['status']=='PASS' and q['passed']==q.get('total',q.get('total_planned'))==wanted)
        require(not runner.pin_errors(q['source_pins']))
    require(not runner.pin_errors(read(location/'FROZEN.json')['files']))
test('new_exact_child_supervisor_is_selected_and_qualified',contained_supervisor)
prior_q=read(old/'OFFLINE_QUALIFICATION.json')
test('preserved_ancestor_scientific_qualification_and_provenance',lambda:require(
    prior_q['status']=='PASS' and prior_q['passed']==prior_q['total']==33 and not runner.pin_errors(prior_q['source_pins'])))

roster=read(B.parent/'kind_corpus/ROSTER.json')['unique_inputs']
ids=list(dict.fromkeys(runner.QUAL_IDS+[r['id'] for r in roster]))[:runner.COHORT_SIZE]
ids=[r['id'] for r in roster if r['id'] in ids]
selection={'total':425,'eligible_count':14,'eligible_ids':ids,'first_run_small_ids':ids,
    'parent_aborted':True,'same_small_cohort_before_interrupted_run':True,
    'selection_uses_mathematical_or_graph_outcomes':False,
    'rows':[dict(id=r['id'],source=r['path'],eligible=r['id'] in ids,typed_carrier=1 if r['id'] in ids else 4097,
                 model={'path':str(runner.PHASE1/'runs'/r['id']/'model.json')}) for r in roster]}
test('all_and_only_small_models_in_roster_order',lambda:require([r['id'] for r in runner.choose(selection,roster)[0]]==ids))
def mutate_selection(name):
    changed=copy.deepcopy(selection);chosen=next(r for r in changed['rows'] if r['eligible'])
    if name=='duplicate':changed['rows'][1]['id']=changed['rows'][0]['id']
    elif name=='missing_row':changed['rows'].pop()
    elif name=='non_boolean':chosen['eligible']=1
    elif name=='source_identity':chosen['source']='different/source'
    elif name=='v1_model':chosen['model']['path']='/tmp/older-model.json'
    elif name=='carrier_boolean':chosen['typed_carrier']=True
    elif name=='carrier_zero':chosen['typed_carrier']=0
    elif name=='carrier_above_cap':chosen['typed_carrier']=4097
    elif name=='hide_small_model':next(r for r in changed['rows'] if not r['eligible'])['typed_carrier']=1
    elif name=='wrong_count':changed['eligible_count']=13
    elif name=='reordered_ids':changed['eligible_ids']=ids[::-1]
    elif name=='changed_preinterruption_cohort':changed['first_run_small_ids']=ids[::-1]
    elif name=='aborted_provenance_lost':changed['parent_aborted']=False
    elif name=='outcome_selection':changed['selection_uses_mathematical_or_graph_outcomes']=True
    rejects(lambda:runner.choose(changed,roster))
for name in ('duplicate','missing_row','non_boolean','source_identity','v1_model','carrier_boolean','carrier_zero',
             'carrier_above_cap','hide_small_model','wrong_count','reordered_ids','changed_preinterruption_cohort',
             'aborted_provenance_lost','outcome_selection'):
    test('reject_selection_'+name,lambda name=name:mutate_selection(name))
def outcomes_independent():
    changed=copy.deepcopy(selection)
    for r in changed['rows']:r.update(native_status='UNREALIZABLE',strict_controller_pass=False,nonconflicting_pass=False)
    require(runner.choose(changed,roster)[0]==runner.choose(selection,roster)[0])
test('selection_ignores_negative_and_unknown_results',outcomes_independent)

receipt={'global_stop':False,'pin_errors':[],'stage':'COMPLETE','parent_aborted':True,
    'preserved_parent_receipt':parent_pin,'finished_utc':'2026-10-17T00:00:00+00:00',
    'source_denominator':425,'eligible_count':14,
    'rows':[{'id':ident,'pipeline':arm,'outcome':'UNKNOWN_NATIVE_RESOURCE'} for ident in ids for arm in runner.PRIOR_ARMS]}
test('all_42_rows_allow_per_case_unknown',lambda:runner.validate_prior(receipt,ids,parent_pin))
def mutate_prior(name):
    changed=copy.deepcopy(receipt)
    if name=='global_stop':changed['global_stop']=True
    elif name=='pin_error':changed['pin_errors']=['changed']
    elif name=='incomplete_stage':changed['stage']='MAIN_COHORT'
    elif name=='aborted_provenance_lost':changed['parent_aborted']=False
    elif name=='parent_receipt_change':changed['preserved_parent_receipt']['sha256']='0'*64
    elif name=='naive_timestamp':changed['finished_utc']='2026-10-17T00:00:00'
    elif name=='missing_arm':changed['rows'].pop()
    elif name=='duplicate_arm':changed['rows'][-1]=changed['rows'][0]
    elif name=='unknown_pipeline':changed['rows'][-1]['pipeline']='other'
    elif name=='foreign_source':changed['rows'][-1]['id']='not-selected'
    rejects(lambda:runner.validate_prior(changed,ids,parent_pin))
for name in ('global_stop','pin_error','incomplete_stage','aborted_provenance_lost','parent_receipt_change',
             'naive_timestamp','missing_arm','duplicate_arm','unknown_pipeline','foreign_source'):
    test('reject_prior_'+name,lambda name=name:mutate_prior(name))
def deadline_wait_no_spawn():
    with tempfile.TemporaryDirectory(prefix='slugs-gate-offline-') as d:
        root=Path(d);save(root/'PRODUCTION_SOURCE_FREEZE.json',{})
        with patch.object(runner,'B',root),patch.object(runner,'SMALL',root/'absent'),patch.object(runner,'seconds_left',return_value=-1),patch.object(runner,'run_bounded',side_effect=AssertionError('No process allowed')):
            r=runner.Runner({'files':[]});r.wait_and_select()
            require(r.stop and r.reasons==['DEADLINE_WAITING_SMALL_NATIVE_RECOVERY'] and not r.eligible)
test('deadline_while_waiting_never_starts_process',deadline_wait_no_spawn)
def pin_change():
    with tempfile.TemporaryDirectory(prefix='slugs-pin-offline-') as d:
        p=Path(d)/'fixture.txt';p.write_text('before');ref=pin(p)
        require(not runner.pin_errors([ref]));p.write_text('after');require(bool(runner.pin_errors([ref])))
test('changed_dependency_detected',pin_change)

actual_selection_path=runner.SMALL/'SELECTION.json'
actual_selection=read(actual_selection_path)
test('actual_root_cohort_has_14_size_selected_models',lambda:require(
    [r['id'] for r in runner.choose(actual_selection,roster)[0]]==actual_selection['eligible_ids']))
def complete_gate_with_real_models():
    with tempfile.TemporaryDirectory(prefix='slugs-recovery-gate-offline-') as d:
        root=Path(d);slugs=root/'slugs';small=root/'native'
        save(slugs/'PRODUCTION_SOURCE_FREEZE.json',{})
        save(slugs/'BASELINE_SOURCE.json',baseline)
        save(small/'SELECTION.json',actual_selection)
        fake=copy.deepcopy(receipt)
        fake['rows']=[{'id':ident,'pipeline':arm,'outcome':'UNKNOWN_NATIVE_RESOURCE'}
            for ident in actual_selection['eligible_ids'] for arm in runner.PRIOR_ARMS]
        save(small/'RUN_RECEIPT.json',fake)
        save(small/'FROZEN.json',{'files':actual_selection['input_pins'],'parent_aborted':True,
                                'cohort':pin(small/'SELECTION.json')})
        with patch.object(runner,'B',slugs),patch.object(runner,'SMALL',small),patch.object(runner,'seconds_left',return_value=1000),patch.object(runner,'run_bounded',side_effect=AssertionError('No process allowed')):
            r=runner.Runner({'files':[]});r.wait_and_select()
            selected=read(slugs/'SELECTION.json')
            require(not r.stop and r.stage=='FRESH_V2_EXPORT' and len(r.eligible)==14)
            require(selected['parent_aborted'] is True and selected['parent_global_stop'] is True)
            require(selected['preserved_parent_receipt']==parent_pin and not runner.pin_errors(r.files))
test('end_to_end_gate_uses_real_models_and_synthetic_42_unknown_rows_without_spawn',complete_gate_with_real_models)

def interrupted_call(phase,confirmed):
    with tempfile.TemporaryDirectory(prefix='slugs-interruption-offline-') as d:
        root=Path(d);ident=runner.QUAL_IDS[0]
        save(root/'PRODUCTION_SOURCE_FREEZE.json',{});save(root/'BASELINE_SOURCE.json',baseline);save(root/'SELECTION.json',{})
        save(root/'exports'/ident/'EXPORT_CERTIFICATE.json',{})
        def simulated(command,folder,*args,**kwargs):
            if not confirmed:raise RuntimeError('Synthetic exception while native start is uncertain')
            Path(folder).mkdir();(Path(folder)/'stderr.txt').write_text('synthetic only')
            return {'process_started':True}
        with patch.object(runner,'B',root),patch.object(runner,'seconds_left',return_value=1000),patch.object(runner,'run_bounded',side_effect=simulated),patch.object(runner,'native_status',side_effect=RuntimeError('Synthetic interruption after confirmed start')):
            r=runner.Runner({'files':[]});r.eligible=[row for row in roster if row['id'] in actual_selection['eligible_ids']]
            r.exports={ident:{'status':'PASS'}}
            with patch.object(r,'audit',return_value=True):
                try:r.attempt(next(x for x in r.eligible if x['id']==ident),phase)
                except RuntimeError:r.fail('SYNTHETIC_RUNNER_EXCEPTION')
                else:raise AssertionError('Interruption was not reached')
            final=r.finish();target=final['qualification_rows'] if phase=='qualification' else final['rows']
            value=next(x for x in target if x['id']==ident)
            require(value['outcome']=='UNKNOWN_RUNNER_FAILURE' and value['native_called'] is (True if confirmed else None))
            require(len(final['qualification_rows'])==3 and len(final['rows'])==14)
            require(len({x['id'] for x in final['qualification_rows']})==3 and len({x['id'] for x in final['rows']})==14)
            key='qualification_native_calls' if phase=='qualification' else 'main_native_calls'
            require(final[key]=={'confirmed':int(confirmed),'uncertain':int(not confirmed)})
            other='main_native_calls' if phase=='qualification' else 'qualification_native_calls'
            require(final[other]=={'confirmed':0,'uncertain':0} and final['global_stop'])
for phase in ('qualification','main'):
    for confirmed in (False,True):
        test('interrupted_'+phase+('_confirmed' if confirmed else '_uncertain'),lambda phase=phase,confirmed=confirmed:interrupted_call(phase,confirmed))

def reserve_after_audit(operation):
    with tempfile.TemporaryDirectory(prefix='slugs-reserve-offline-') as d:
        root=Path(d);ident=runner.QUAL_IDS[0];calls={'clock':0}
        save(root/'PRODUCTION_SOURCE_FREEZE.json',{});save(root/'BASELINE_SOURCE.json',baseline);save(root/'SELECTION.json',{})
        save(root/'exports'/ident/'EXPORT_CERTIFICATE.json',{})
        def clock():
            calls['clock']+=1;return 1000 if calls['clock']==1 else 0
        with patch.object(runner,'B',root),patch.object(runner,'seconds_left',side_effect=clock),patch.object(runner,'run_bounded',side_effect=AssertionError('No spawn after audit consumes reserve')):
            r=runner.Runner({'files':[]});r.eligible=[next(row for row in roster if row['id']==ident)];r.exports={ident:{'status':'PASS'}}
            with patch.object(r,'audit',return_value=True):
                if operation=='export':
                    r.export_all();require(r.exports[ident]=={'status':'UNKNOWN_NOT_EXPORTED','reason':'DEADLINE_AFTER_PIN_AUDIT'})
                else:
                    value=r.attempt(r.eligible[0],'main')
                    require(value['native_called'] is False and value['outcome']=='UNKNOWN_NOT_ATTEMPTED' and value['reason']=='DEADLINE_AFTER_PIN_AUDIT')
test('export_reserve_rechecked_after_pin_audit',lambda:reserve_after_audit('export'))
test('native_reserve_rechecked_after_pin_audit',lambda:reserve_after_audit('native'))

require(not (B/'PRODUCTION_SOURCE_FREEZE.json').exists() and not (B/'RUN_STARTED.json').exists())
result={'schema':'slugs-small-recovery-offline-qualification-v1','created_utc':now(),
    'status':'PASS' if all(t['pass'] for t in tests) else 'FAIL','tests':tests,
    'passed':sum(t['pass'] for t in tests),'total':len(tests),
    'slugs_binary_launches':0,'native_scientific_synthesis_calls':0,'bdd_computations':0,'child_processes':0,
    'actual_selection_at_qualification':pin(actual_selection_path),
    'inherited_qualification':pin(old/'OFFLINE_QUALIFICATION.json'),
    'source_pins':[pin(B/n) for n in ('run.py','stage.py','bounded_process.py','prepare.py','qualify_runner.py','PROTOCOL_JA.txt','BASELINE_SOURCE.json')]}
save(B/'OFFLINE_QUALIFICATION.json',result)
print(json.dumps({k:result[k] for k in ('status','passed','total','slugs_binary_launches','bdd_computations')}))
require(result['status']=='PASS')
