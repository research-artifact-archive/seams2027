"""Prepare/freeze before an explicitly authorized contained all-eleven run."""
import argparse,importlib.util,json,os,sys,time
from pathlib import Path
from datetime import datetime,timezone
sys.dont_write_bytecode=True
from evidence import B,E,CHECKER,STAGE,select,read,save,pin,pins_in,unique,verify,require,now
MIN_START_SECONDS=75

def preserve_interrupted_attempt(value):
    if value.get('status')=='UNKNOWN_NOT_ATTEMPTED' and value.get('BDD_worker_started') is not False:
        value.update(status='UNKNOWN_RUNNER_FAILURE',reason='Worker start confirmed or uncertain before runner interruption')
    return value

def authorization():
    p=pin(B/'ROOT_START_DECISION.json');d=read(p['path'])
    require(d.get('start_authorized') is True and d.get('freeze')==pin(B/'FROZEN.json'),'Exact root review authorization required')
    verify([p]);return p

def prepare():
    require(not (B/'FROZEN.json').exists() and not (B/'RUN_STARTED.json').exists(),'No frozen overwrite')
    if not (B/'SELECTION.json').exists():save(B/'SELECTION.json',select())
    selection=read(B/'SELECTION.json');verify(selection['input_pins'])
    rebuilt=select();strip=lambda d:{k:v for k,v in d.items() if k!='created_utc'}
    require(strip(selection)==strip(rebuilt),'Exact fixed all11 selection reconstruction')
    q=read(B/'OFFLINE_QUALIFICATION.json')
    require(q['status']=='PASS' and q['reconstructed_BDD_computations']==0 and q['new_fixed_point_runs']==0,'Synthetic-only qualification')
    verify(q['source_pins'])
    code=[pin(B/n) for n in ('evidence.py','adapter.py','measure.py','run.py','qualify.py','PROTOCOL_JA.txt','OFFLINE_QUALIFICATION.json')]
    code += [pin(p) for p in CHECKER.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    code += [pin(STAGE/'FROZEN.json')]+pins_in(read(STAGE/'FROZEN.json'))+[pin(Path(sys.executable).resolve())]
    code=unique(code);files=unique(code+selection['input_pins']+[pin(B/'SELECTION.json')]);verify(files)
    save(B/'FROZEN.json',{'schema':'repair-preservation-condition-freeze-v1','created_utc':now(),'files':files,'code_files':code,
        'python':pin(Path(sys.executable).resolve()),'selection':pin(B/'SELECTION.json'),'denominator':11,
        'limits':{'variables':64,'BDD_nodes_including_terminals':500000,'wall_seconds_per_case':60,'workers':1,
            'native_BDD_bytes':8*1024*1024,'export_expanded_bytes':64*1024*1024},
        'native_runs':0,'new_fixed_point_runs':0,'reconstructed_BDD_computations':0,'root_review_status':'AWAITING_ROOT_REVIEW_NO_DATA_DISPATCH'})
    print(json.dumps({'status':'PREPARED_NOT_STARTED','eligible':11,'files':len(files),'native_runs':0,'new_fixed_point_runs':0}))

def admit_pass(result,ident,row,freeze,decision):
    require(result['id']==ident and result.get('schema')=='repair-preservation-condition-case-v1','Case identity')
    require(result.get('status') in ('PASS','UNKNOWN_RESOURCE','UNKNOWN_INTEGRITY'),'Child status whitelist')
    require(result.get('root_authorization')==decision,'Root authorization provenance')
    require(all(type(result.get(k)) is int and result[k]==0 for k in ('native_runs','new_fixed_point_runs','full_reset_uses')),'No native, FP or reset')
    require(result.get('complete_semantic_literal_only') is True,'Complete semantic literal scope')
    require(all(result.get(k) is False for k in ('new_repaired_or_deployed_episode','exact_W_C_or_K_loss_computed','original_W_secondary_computed')),'No transferred studies')
    require(result.get('released_syntactic_loss_conclusion') is None and result.get('runtime_or_controller_defect_conclusion') is None,'No transferred conclusions')
    if result['status']!='PASS':return
    counts=result['counts'];require(set(counts)=={'C','K','K_minus_C'} and all(type(v) is int and 0<=v<=row['carrier'] for v in counts.values()),'Exact typed counts')
    require(counts['K']==row['existing_counts']['K'] and counts['K_minus_C']<=counts['K'],'Authoritative K count')
    require(result.get('carrier')==row['carrier'] and result.get('variable_count')==row['variable_count'],'Original domain and encoding')
    require(type(result.get('K_subset_C')) is bool and type(result.get('W_V_subset_C')) is bool and result['K_subset_C']==result['W_V_subset_C']==(counts['K_minus_C']==0),'Exact Boolean/count result')
    require(result.get('exact_saved_W_V_equals_complete_typed_K') is True,'Complete W_V/K Boolean equality')
    require(set(result['canonical_sha256'])=={'C','K','K_minus_C','bad_ENV_next'} and all(isinstance(v,str) and len(v)==64 for v in result['canonical_sha256'].values()),'Canonical function digests')
    require(result['native_W_V_canonical_sha256']==result['canonical_sha256']['K'],'Native W_V and K function identity')
    require((result['K_minus_C_witness'] is None)==(counts['K_minus_C']==0),'Counterexample existence')
    if counts['K_minus_C']:
        w=result['K_minus_C_witness']
        require(all(w.get(k) is True for k in ('all_logical_AUX_retained','no_typed_SYS_and_all_AUX_response','not_a_strategy_or_runtime_trace')),'Witness typed/AUX scope')
        require(w.get('requires_ENV_move_legal_under_rhoE') is False,'No hidden ENV-assumption filter')
    require((result['C_state_witness'] is None)==(counts['C']==0),'C witness existence')
    for key in ('original_model','saved_W_V_region','complete_K_valuations','existing_full_region_equality','existing_certificate','original_initial_formulas','prior_native_initial_result'):
        require(result[key]==row[key],'Exact authority '+key)
    require(result['original_initial_recomputed'] is False and result['source_formula_audit']=='EXACT_ORIGINAL_BDD_TO_FROZEN_SOURCE_PROFILE','Original formula boundary')
    expected=freeze['code_files']+row['input_pins']+[pin(B/'FROZEN.json'),pin(B/'SELECTION.json'),decision]
    require(result['input_pins']==expected,'Exact source/code/decision pins');verify([result['functions']])

def run(deadline):
    decision=authorization();end=datetime.fromisoformat(deadline);require(end.tzinfo is not None,'Timezone-aware deadline')
    freeze=read(B/'FROZEN.json');verify(freeze['files']);require(freeze['python']==pin(Path(sys.executable).resolve()),'Frozen Python identity')
    selection=read(B/'SELECTION.json');require(selection['eligible_count']==len(selection['rows'])==11,'Fixed all-eleven cohort')
    byid={r['id']:r for r in selection['rows']};require(list(byid)==selection['eligible_ids'],'All11 fixed order')
    require(not (B/'RUN_STARTED.json').exists() and not (B/'RUN_RECEIPT.json').exists(),'One dispatch only')
    spec=importlib.util.spec_from_file_location('repair_condition_contained_stage',STAGE/'bounded_process.py')
    bounded=importlib.util.module_from_spec(spec);spec.loader.exec_module(bounded)
    with (B/'RUN_STARTED.json').open('x') as f:json.dump({'started_utc':now(),'owner_pid':os.getpid(),'freeze':pin(B/'FROZEN.json'),'root_authorization':decision},f)
    outputs={};output_refs=[decision];stop=False;reasons=[];started=time.monotonic()
    try:
        for ident in selection['eligible_ids']:
            value={'id':ident,'status':'UNKNOWN_NOT_ATTEMPTED','BDD_worker_started':False};outputs[ident]=value
            if stop or (end-datetime.now(timezone.utc)).total_seconds()<MIN_START_SECONDS:continue
            verify(freeze['code_files']+[decision])
            if (end-datetime.now(timezone.utc)).total_seconds()<MIN_START_SECONDS:continue
            value['BDD_worker_started']=None;folder=B/'runs'/ident
            process=bounded.run_bounded([sys.executable,'-B',str(B/'measure.py'),ident],folder/'process',deadline,
                wall_seconds=60,file_bytes=64*1024*1024,watch_files=[folder/'RESULT.json',folder/'FUNCTIONS.json.gz'])
            value.update(BDD_worker_started=process['process_started'],process=pin(folder/'process/PROCESS_RECEIPT.json'));output_refs.append(value['process'])
            if process['status']=='PROCESS_COMPLETED' and process['exit_code']==0 and (folder/'RESULT.json').exists():
                value['status']='UNKNOWN_INTEGRITY';result=read(folder/'RESULT.json');admit_pass(result,ident,byid[ident],freeze,decision)
                value.update(status=result['status'],result=pin(folder/'RESULT.json'));output_refs += [value['result']]+pins_in(result)
                if result['status']=='PASS':value.update(counts=result['counts'],K_subset_C=result['K_subset_C'],W_V_subset_C=result['W_V_subset_C'])
                elif result['status']=='UNKNOWN_INTEGRITY':stop=True;reasons.append('CASE_INTEGRITY')
            else:
                value['status']='UNKNOWN_RESOURCE' if process['status']=='UNKNOWN_RESOURCE' else 'UNKNOWN_PROCESS'
                if value['status']=='UNKNOWN_PROCESS':stop=True;reasons.append('UNEXPECTED_WORKER_EXIT_OR_MISSING_RESULT')
            if process['status'].startswith('FATAL_'):stop=True;reasons.append('PROCESS_INTEGRITY')
            verify([decision]);save(B/'PROGRESS.json',{'finished':False,'rows':list(outputs.values()),'native_runs':0,'new_fixed_point_runs':0})
    except BaseException as ex:stop=True;reasons.append(repr(ex))
    try:verify(freeze['files']+output_refs)
    except BaseException as ex:stop=True;reasons.append('FINAL_PIN_INTEGRITY:'+repr(ex))
    for v in outputs.values():preserve_interrupted_attempt(v)
    rows=[outputs.get(r['id'],{'id':r['id'],'status':'UNKNOWN_NOT_ATTEMPTED','BDD_worker_started':False}) for r in selection['rows']]
    receipt={'schema':'repair-preservation-condition-run-v1','finished_utc':now(),'elapsed_seconds':time.monotonic()-started,
        'denominator':11,'rows':rows,'global_stop':stop,'stop_reasons':reasons,'root_authorization':decision,'unknown_is_negative':False,
        'native_runs':0,'new_fixed_point_runs':0,'full_reset_uses':0,'complete_semantic_literal_only':True,
        'released_syntactic_loss_conclusion':None,'runtime_or_controller_defect_conclusion':None,'new_repaired_or_deployed_episode':False,
        'exact_W_C_or_K_loss_computed':False,'original_W_secondary_computed':False,
        'BDD_worker_calls':{'confirmed':sum(v.get('BDD_worker_started') is True for v in rows),'uncertain':sum(v.get('BDD_worker_started') is None for v in rows)}}
    save(B/'RUN_RECEIPT.json',receipt)
    save(B/'RESULT_FILES.json',{'files':[pin(p) for p in sorted(B.rglob('*')) if p.is_file() and p.name!='RESULT_FILES.json']})
    print(json.dumps({'global_stop':stop,'BDD_worker_calls':receipt['BDD_worker_calls']}))

def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('select','prepare','preflight','run'));p.add_argument('--deadline-utc');args=p.parse_args()
    if args.mode=='select':
        require(not (B/'SELECTION.json').exists(),'No selection overwrite');save(B/'SELECTION.json',select());print('Selected all eleven; reconstructed BDD=0');return
    if args.mode=='prepare':prepare();return
    frozen=read(B/'FROZEN.json');verify(frozen['files'])
    if args.mode=='preflight':print(json.dumps({'status':'PASS_SOURCE_FREEZE','native_runs':0,'new_fixed_point_runs':0,'reconstructed_BDD_computations':0}));return
    require(args.deadline_utc is not None,'Root-specified absolute deadline required');run(args.deadline_utc)
if __name__=='__main__':main()
