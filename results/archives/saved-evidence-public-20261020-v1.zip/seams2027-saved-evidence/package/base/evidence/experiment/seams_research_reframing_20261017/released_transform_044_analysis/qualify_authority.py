"""Fresh authorization and whole-one-worker mocks; no real child process/native/BDD."""
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch
from datetime import datetime,timezone,timedelta
import ast,json,sys
sys.dont_write_bytecode=True
from evidence import B,ID,read,save,pin,require,now
import evidence,run

def rejected(fn):
    try:fn()
    except (ValueError,KeyError,TypeError,FileNotFoundError):return
    raise AssertionError('Malformed authority accepted')

def qualify():
    require(not (B/'FROZEN.json').exists() and not (B/'AUTHORITY_QUALIFICATION.json').exists(),'Authority qualification before freeze only')
    tests=[]
    def test(name,fn):fn();tests.append({'name':name,'status':'PASS'})
    def auth(kind):
        with TemporaryDirectory(prefix='saved044_authority_mock_') as tmp:
            root=Path(tmp);m=root/'main';m.mkdir();save(m/'RUN_RECEIPT.json',{'synthetic':True});save(root/'FROZEN.json',{'synthetic':True});closed=pin(m/'RUN_RECEIPT.json')
            save(root/'SELECTION.json',{'row':{'closed_main':closed}})
            d={'start_authorized':True,'scope':'SAVED_044_DECOMPOSITION_ONLY','freeze':pin(root/'FROZEN.json'),'closed_model_pair':closed,'saved_BDD_worker_budget':1,'native_JVM_budget':0,'native_solver_budget':0,'controller_budget':0}
            if kind=='no_authority':d['start_authorized']=False
            if kind=='wrong_scope':d['scope']='MODEL_ONLY_044_PAIR'
            if kind=='wrong_freeze':d['freeze']={**d['freeze'],'sha256':'0'*64}
            if kind=='wrong_closed_pair':d['closed_model_pair']={**closed,'sha256':'0'*64}
            if kind=='two_workers':d['saved_BDD_worker_budget']=2
            if kind=='bool_zero':d['native_solver_budget']=False
            if kind=='native_budget':d['native_JVM_budget']=1
            save(root/'ROOT_START_DECISION.json',d);calls=[]
            with patch.object(evidence,'B',root),patch.object(evidence,'M',m),patch.object(evidence,'closed_main',side_effect=lambda:calls.append(True)):
                if kind=='pass':require(evidence.authorization()==pin(root/'ROOT_START_DECISION.json') and calls==[True],'Fresh saved044 gate binds closed main')
                else:rejected(evidence.authorization);require(not calls,'Reject before main read/worker scheduling')
    for kind in ('pass','no_authority','wrong_scope','wrong_freeze','wrong_closed_pair','two_workers','bool_zero','native_budget'):test('fresh_root_gate_'+kind,lambda kind=kind:auth(kind))
    def process_identity(kind):
        with TemporaryDirectory(prefix='saved044_process_identity_') as tmp:
            root=Path(tmp);exe=root/'python.actual';exe.write_bytes(b'synthetic-executable');alias=root/'python';alias.symlink_to(exe);other=root/'other';other.write_bytes(b'other')
            expected=[str(exe),'-B','/synthetic/measure.py'];actual=[str(alias),'-B','/synthetic/measure.py']
            if kind=='wrong_executable':actual[0]=str(other)
            if kind=='wrong_tail':actual[-1]='/synthetic/other.py'
            p={'schema':'contained-stage-process-v1','status':'PROCESS_COMPLETED','exit_code':0,'process_started':True,'owned_child_reaped':True,'final_group_observation':{'state':'ABSENT'},'argv':actual}
            if kind=='bool_exit':p['exit_code']=False
            save(root/'PROCESS.json',p)
            if kind=='pass':require(evidence.complete_process(pin(root/'PROCESS.json'),expected)==p,'Symlink name preserves exact executable identity and argv tail')
            else:rejected(lambda:evidence.complete_process(pin(root/'PROCESS.json'),expected))
    for kind in ('pass','wrong_executable','wrong_tail','bool_exit'):test('prior_process_executable_identity_'+kind,lambda kind=kind:process_identity(kind))
    def source_identity(kind):
        case={'source':{'path':'/synthetic/extracted/source.spectra','bytes':8,'sha256':'a'*64},'public_roster_row':{'path':'artifact/specs/source.spectra'}}
        ref={**case['source'],'path':case['public_roster_row']['path']}
        if kind=='wrong_hash':ref['sha256']='b'*64
        if kind=='wrong_path':ref['path']='artifact/other.spectra'
        if kind=='pass':require(evidence.source_aware_pins({'source':ref},case)==[case['source']],'Only exact known archive-relative source resolves')
        else:rejected(lambda:evidence.source_aware_pins({'source':ref},case))
    for kind in ('pass','wrong_hash','wrong_path'):test('prior_archive_source_reference_'+kind,lambda kind=kind:source_identity(kind))
    def parent(kind):
        with TemporaryDirectory(prefix='saved044_parent_mock_') as tmp:
            root=Path(tmp);fp=root/'FROZEN.json';sp=root/'SELECTION.json';dp=root/'ROOT_START_DECISION.json';model=root/'model.json';save(model,{'fields':[{'name':n} for n in ('mode','memory')]});save(root/'prior.json',{'synthetic':True});prior=pin(root/'prior.json')
            end=(datetime.now(timezone.utc)+timedelta(seconds=0 if kind=='deadline' else 600)).isoformat();save(dp,{'deadline_utc':end});decision=pin(dp)
            freeze={'files':[],'code_files':[],'python':pin(Path(sys.executable).resolve())};save(fp,freeze)
            names=('job_model','pair_check','pair_check_process','independent_W_certificate','independent_W_process','independent_regions','prior_literal_loss_certificate','prior_literal_loss_process','prior_literal_loss_functions')
            row={name:prior for name in names};row.update(id=ID,original_model=pin(model),input_pins=[],closed_main=prior)
            selected={'eligible_ids':[ID],'eligible_count':1,'separate_from_fixed14_helper_cohort':True,'row':row};save(sp,selected);calls=[]
            def bounded(argv,folder,deadline,**kwargs):
                folder=Path(folder);folder.mkdir(parents=True);calls.append(argv)
                if kind=='uncertain_start':raise RuntimeError('Synthetic interruption after possible child start')
                process={'status':'UNKNOWN_RESOURCE' if kind=='resource' else 'PROCESS_COMPLETED','exit_code':1 if kind=='nonzero' else 0,'process_started':1 if kind=='bad_start_type' else True,'owned_child_reaped':kind!='unreaped','final_group_observation':{'state':'UNKNOWN' if kind=='unknown_group' else 'ABSENT'},'argv':argv}
                if kind=='bool_exit':process['exit_code']=False
                save(folder/'PROCESS_RECEIPT.json',process)
                if kind=='missing_result':return process
                artifact=folder.parent/'FUNCTIONS.json.gz';artifact.write_bytes(b'SYNTHETIC_FUNCTIONS')
                counts={'D':18816,'W_original':100,'U':18816,'F':100,'C':120,'W_F':60,'W_direct_full':18876,'W_direct_0':60,'W_direct_1':18816,'active_difference':0,'trap_difference':0,'U_missing':0,'F_xor_C':20,'F_missing':18716,'W_minus_F':20,'W_loss':40,'delayed_loss':20,'actual_original_reachable_loss':30,'actual_W_F_xor_literal_W_C':10,'actual_loss_xor_literal_loss':10,'original_W_authority_difference':0,'independent_original_reachable':1000,'fresh_literal_W_C':50,'prior_literal_W_C':50}
                checks={name:True for name in ('original_ENV_00_equal','original_SYS_00_equal','helper_ENV_10_impossible','active_decomposition_equal','trap_decomposition_equal','U_equals_D','initial_quantification_equal','subset_original','full_preservation_iff_W_subset_F','original_W_exact_authority_equal','original_reachable_exact_authority_equal','fresh_literal_all_functions_authority_equal','C_exact_literal_authority_equal')}
                checks.update({name:False for name in ('F_equals_C','F_equals_D','W_subset_F','original_full_region_preserved','actual_W_F_equals_prior_literal_W_C','actual_loss_equals_prior_literal_loss')})
                if kind=='decomposition_failure':counts['active_difference']=1;checks['active_decomposition_equal']=False
                if kind=='bad_count':counts['W_loss']=True
                if kind=='bad_00':checks['original_SYS_00_equal']=False
                if kind=='bad_partition':counts['delayed_loss']=19
                summary={'branch':'ONE_WAY_HELPER','helper_added':True,'original_typed_carrier':18816,'full_job_typed_carrier':37632,'counts':counts,'checks':checks,
                    'canonical_sha256':{name:'a'*64 for name in counts},'state_witnesses':{name:{'state':{'mode':'synthetic','memory':'synthetic'},'bits':{},'helper_current':None} if n else None for name,n in counts.items()},
                    'initial_quantification':{name:{'value':name=='W_original','missing_initial_ENV_count':0 if name=='W_original' else 1,'SYS_witness_count':10} for name in ('W_original','W_predicted','W_direct_active','actual_job','literal_W_C')}}
                result={'schema':'fixed044-saved-analysis-case-v1','id':ID,'status':'FAIL_DECOMPOSITION' if kind=='decomposition_failure' else 'PASS','root_authorization':decision,'parent_aborted':True,'closed_model_pair':prior,
                    'new_native_JVM_calls':0,'native_solver_calls':0,'controller_calls':0,'full_reset_uses':0,'direct_reference_objective':'strict_GR1_on_actual_saved_transformed_arena','compared_with_native_4fp_region':False,'returned_controller_conclusion':None,
                    'claim_is_cooperative_strategy_existence':False,'all_original_AUX_retained':True,'separate_outcome_informed_single_case':True,'folded_into_fixed14_cohort':False,'independent_source_compiler':False,'shared_source_compiler':True,'common_BDD_and_GR1_engine_between_direct_and_decomposed':True,'synthetic_finite_set_oracle_independent_representation':True,
                    'original_K_count':0,'original_K_initial_verdict':False,'kind_initializer_false_rejection_conclusion':None,'original_initializers_retained_for_active_and_literal_quantification':True,'original_ordered_justices_retained':True,
                    'original_model':row['original_model'],**{name:row[name] for name in names},'original_W_exact_authority_equal':True,'original_reachable_exact_authority_equal':True,'original_initial_quantification_authority_equal':True,'literal_initial_quantification_authority_equal':True,
                    'input_pins':[pin(fp),pin(sp),decision],'reference_details':{'fresh_literal_reference_correspondence':True,'recomputation_is_new_independent_case':False,'actual_W_F_to_literal_W_C_equality_is_observation':True,'original_reachability_reused_without_new_fixed_point':True},'summary':summary,'functions':pin(artifact)}
                if kind=='wrong_closed_pair':result['closed_model_pair']={**prior,'sha256':'0'*64}
                if kind=='native_bool':result['new_native_JVM_calls']=False
                if kind=='bad_schema':result['schema']='unknown'
                if kind=='missing_functions':artifact.unlink()
                save(folder.parent/'RESULT.json',result);return process
            def spec(name,path):return SimpleNamespace(loader=SimpleNamespace(exec_module=lambda m:setattr(m,'run_bounded',bounded)))
            with patch.object(run,'B',root),patch.object(run,'authorization',return_value=decision),patch.object(run,'verify',lambda refs:None),patch.object(run.importlib.util,'spec_from_file_location',side_effect=spec),patch.object(run.importlib.util,'module_from_spec',return_value=SimpleNamespace()):run.run(end)
            receipt=read(root/'RUN_RECEIPT.json');value=receipt['row']
            if kind=='pass':require(receipt['status']=='PASS_FIXED044_ANALYSIS' and len(calls)==1 and value['summary']['checks']['actual_W_F_equals_prior_literal_W_C'] is False,'One saved worker; actual-literal inequality remains a valid observation')
            elif kind=='deadline':require(not calls and receipt['BDD_worker_calls']=={'confirmed':0,'uncertain':0,'not_called':1},'Deadline reserve prevents dispatch')
            else:
                require(receipt['global_stop'] is True and len(calls)==1,'Failures stop without retry')
                if kind in ('uncertain_start','bad_start_type'):require(receipt['BDD_worker_calls']['uncertain']==1,'Unknown start not counted as uncalled')
                if kind=='resource':require(value['status']=='UNKNOWN_RESOURCE','Resource status precedes valid-looking result')
                if kind=='decomposition_failure':require(value['status']=='FAIL_DECOMPOSITION','Scientific disagreement retained distinctly')
            require(receipt['new_native_JVM_calls']==receipt['native_solver_calls']==receipt['controller_calls']==0 and receipt['folded_into_fixed14_cohort'] is False,'Fixed scope preserved')
    for kind in ('pass','deadline','resource','nonzero','missing_result','uncertain_start','bad_start_type','bool_exit','unreaped','unknown_group','bad_count','bad_00','bad_partition','wrong_closed_pair','native_bool','bad_schema','missing_functions','decomposition_failure'):test('whole_parent_mock_'+kind,lambda kind=kind:parent(kind))
    for p in B.glob('*.py'):ast.parse(p.read_text())
    sources=[pin(B/name) for name in ('evidence.py','measure.py','run.py','qualify_authority.py','ADAPTER_QUALIFICATION.json','REUSE_AUDIT.json','MATH_QUALIFICATION.json')]
    save(B/'AUTHORITY_QUALIFICATION.json',{'schema':'fixed044-analysis-authority-qualification-v1','status':'PASS','created_utc':now(),'count':len(tests),'tests':tests,'source_pins':sources,'corpus_BDD_computations':0,'native_runs':0,'actual_child_processes':0})
    print(json.dumps({'status':'PASS','checks':len(tests),'actual_child_processes':0,'corpus_BDD_computations':0}))

if __name__=='__main__':qualify()
