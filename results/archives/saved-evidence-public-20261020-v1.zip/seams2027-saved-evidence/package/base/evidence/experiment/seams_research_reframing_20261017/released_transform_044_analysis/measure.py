"""One authorized bounded fixed044 saved-arena analysis; no native execution."""
import json,signal,sys,time,traceback
sys.dont_write_bytecode=True
from evidence import B,ID,read,save,pin,verify,require,now,authorization
from decomposition import build,lifted_inputs,solve,ResourceRefusal,MapResourceRefusal
from imports import load_original_regions,load_loss,ImportResourceRefusal
from regions import add_references,LiteralResourceRefusal
from reporting import summarize,export

def main():
    decision=authorization();freeze=read(B/'FROZEN.json');selection=read(B/'SELECTION.json');row=selection['row'];folder=B/'runs'/ID;folder.mkdir(parents=True,exist_ok=True)
    require(not (folder/'RESULT.json').exists() and not (folder/'FUNCTIONS.json.gz').exists(),'No duplicate fixed044 analysis')
    refs=freeze['code_files']+row['input_pins']+[pin(B/'FROZEN.json'),pin(B/'SELECTION.json'),decision]
    result={'schema':'fixed044-saved-analysis-case-v1','id':ID,'status':'UNKNOWN_INCOMPLETE','created_utc':now(),'root_authorization':decision,'parent_aborted':True,
        'closed_model_pair':row['closed_main'],'new_native_JVM_calls':0,'native_solver_calls':0,'controller_calls':0,'full_reset_uses':0,
        'direct_reference_objective':'strict_GR1_on_actual_saved_transformed_arena','compared_with_native_4fp_region':False,'returned_controller_conclusion':None,
        'claim_is_cooperative_strategy_existence':False,'independent_source_compiler':False,'shared_source_compiler':True,
        'common_BDD_and_GR1_engine_between_direct_and_decomposed':True,'synthetic_finite_set_oracle_independent_representation':True,
        'all_original_AUX_retained':True,'separate_outcome_informed_single_case':True,'folded_into_fixed14_cohort':False,
        'original_K_count':0,'original_K_initial_verdict':False,'kind_initializer_false_rejection_conclusion':None,
        'strict_deadend_convention':'No legal ENV move is vacuously winning; a legal ENV move with no legal SYS reply is losing. Outer F and outer C remain required.',
        'original_initializers_retained_for_active_and_literal_quantification':True,'original_ordered_justices_retained':True}
    start=time.monotonic();pair=None
    def alarm(*_):raise TimeoutError('Fixed044 saved analysis60s')
    try:
        signal.signal(signal.SIGALRM,alarm);signal.alarm(60);verify(refs)
        profile={'fixture_id':ID,'case_id':'corpus044','variant':'original','source':row['source'],
            'bindings':{'original_model':row['original_model'],'released_model':row['job_model'],'closed_model_pair':row['closed_main'],'pair_check':row['pair_check']}}
        pair=build(row['original_directory'],row['job_directory'],ID,profile)
        require(pair['helper_added'] is True and pair['original'].carrier==18816 and pair['job'].carrier==37632 and [f['name'] for f in pair['original_fields'] if f['role']=='AUX']==['PREV_aux_0','PREV_aux_1'],'Fixed complete044 pair and all original AUX')
        args=lifted_inputs(pair);out=solve(**args)
        independent=read(row['independent_W_certificate']['path']);saved,import_audit=load_original_regions(pair,row['independent_regions']['path'],independent)
        prior_certificate=read(row['prior_literal_loss_certificate']['path']);prior,prior_audit=load_loss(pair,row['prior_literal_loss_functions']['path'],prior_certificate)
        reference_details=add_references(out,args,saved,prior)
        summary=summarize(pair,out);qi=summary['initial_quantification']['W_original'];oldq=independent['initial_quantification']['W']
        require(qi['value']==oldq['value'] and qi['missing_initial_ENV_count']==oldq['missing_environment_initial_count'] and qi['SYS_witness_count']==oldq['system_witness_count'] and summary['initial_ENV_choice_count']==independent['initialized_ENV_count'],'Original initializer bound to independent authority')
        ql=summary['initial_quantification']['literal_W_C'];oldl=prior_certificate['initial_quantification']['W_C']
        require(ql['value']==oldl['value'] and ql['missing_initial_ENV_count']==oldl['missing_environment_initial_count'] and ql['SYS_witness_count']==oldl['system_witness_count'],'Fresh literal initializer correspondence with prior certificate')
        export(folder/'FUNCTIONS.json.gz',pair,out['roots'])
        result.update(summary=summary,iteration_logs=out['logs'],functions=pin(folder/'FUNCTIONS.json.gz'),input_pins=refs,
            original_model=row['original_model'],job_model=row['job_model'],pair_check=row['pair_check'],pair_check_process=row['pair_check_process'],
            independent_W_certificate=row['independent_W_certificate'],independent_W_process=row['independent_W_process'],independent_regions=row['independent_regions'],
            independent_original_regions_lift=import_audit,original_W_exact_authority_equal=True,original_reachable_exact_authority_equal=True,original_initial_quantification_authority_equal=True,
            prior_literal_loss_certificate=row['prior_literal_loss_certificate'],prior_literal_loss_process=row['prior_literal_loss_process'],prior_literal_loss_functions=row['prior_literal_loss_functions'],
            prior_literal_functions_lift=prior_audit,literal_initial_quantification_authority_equal=True,reference_details=reference_details,
            original_model_audit=pair['original_audit'],job_model_audit=pair['job_audit'],source_bindings=pair['source_bindings'])
        checks=summary['checks'];equal=checks['active_decomposition_equal'] and checks['trap_decomposition_equal'] and checks['initial_quantification_equal'] and checks['subset_original'] and checks['full_preservation_iff_W_subset_F']
        verify(refs);result['status']='PASS' if equal else 'FAIL_DECOMPOSITION'
    except (TimeoutError,ResourceRefusal,MapResourceRefusal,ImportResourceRefusal,LiteralResourceRefusal,MemoryError) as error:result.update(status='UNKNOWN_RESOURCE',reason=repr(error))
    except BaseException as error:result.update(status='UNKNOWN_INTEGRITY',reason=repr(error),traceback=traceback.format_exc())
    finally:
        signal.alarm(0);result.update(finished_utc=now(),elapsed_seconds=time.monotonic()-start,allocated_common_BDD_nodes=len(pair['common'].nodes) if pair else None);save(folder/'RESULT.json',result)
    print(json.dumps({k:result.get(k) for k in ('id','status','reason')}),flush=True)

if __name__=='__main__':main()
