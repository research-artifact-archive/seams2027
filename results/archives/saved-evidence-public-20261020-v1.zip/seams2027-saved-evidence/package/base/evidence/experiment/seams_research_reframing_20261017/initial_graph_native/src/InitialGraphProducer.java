import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.io.*;
import java.time.Instant;
import java.util.*;
import net.sf.javabdd.*;
import org.apache.log4j.*;
import org.apache.log4j.spi.LoggingEvent;
import tau.smlab.syntech.jtlv.env.module.ModuleBDDField;
import tau.smlab.syntech.spectragameinput.SpectraInputProviderNoIDE;
import tau.smlab.syntech.gameinputtrans.TranslationProvider;
import tau.smlab.syntech.gameinput.model.*;
import tau.smlab.syntech.gameinput.spec.*;
import tau.smlab.syntech.bddgenerator.BDDGenerator;
import tau.smlab.syntech.bddgenerator.BDDGenerator.TraceInfo;
import tau.smlab.syntech.gamemodel.*;
import tau.smlab.syntech.games.gr1.*;
import tau.smlab.syntech.games.controller.enumerate.*;
import tau.smlab.syntech.gameinput.kind.PitermanSyntacticReduction;
import tau.smlab.syntech.gamemodel.util.PitermanSemanticReduction;
import tau.smlab.syntech.jtlv.*;

/** Original multi-initializer public-source graph probe, one arm per fresh JVM. */
public final class InitialGraphProducer {
  static final Map<String,Object> out = new LinkedHashMap<>();
  static Path receipt;
  static volatile String stage = "START";
  static long start;
  static String fixtureId,caseId,variant,pipeline,selectedSolver;
  static java.math.BigInteger carrierSize=java.math.BigInteger.ONE;
  static final List<Object> stageEvents=new ArrayList<>();
  static final Map<String,Long> sampledPeakHeap=new LinkedHashMap<>();
  static Timer heapSampler;
  static void sampleHeap(){long used=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();synchronized(sampledPeakHeap){sampledPeakHeap.put(stage,Math.max(sampledPeakHeap.getOrDefault(stage,0L),used));}}
  static void startHeapSampler(){heapSampler=new Timer("k7-heap-sampler",true);heapSampler.scheduleAtFixedRate(new TimerTask(){public void run(){sampleHeap();}},0,20);}

  static Map<String,Object> m(Object... kv) {
    Map<String,Object> x = new LinkedHashMap<>();
    for(int i=0;i<kv.length;i+=2) x.put((String)kv[i],kv[i+1]);
    return x;
  }
  static String q(String s) {
    StringBuilder b=new StringBuilder("\"");
    for(char c:s.toCharArray()) switch(c) {
      case '"': b.append("\\\""); break;
      case '\\': b.append("\\\\"); break;
      case '\n': b.append("\\n"); break;
      case '\r': b.append("\\r"); break;
      case '\t': b.append("\\t"); break;
      default: if(c<32) b.append(String.format("\\u%04x",(int)c)); else b.append(c);
    }
    return b.append('"').toString();
  }
  static String json(Object x) {
    if(x==null) return "null";
    if(x instanceof Boolean || x instanceof Number) return x.toString();
    if(x instanceof Map) {
      List<String> z=new ArrayList<>();
      for(Object e0:((Map<?,?>)x).entrySet()) {
        Map.Entry<?,?> e=(Map.Entry<?,?>)e0; z.add(q(String.valueOf(e.getKey()))+":"+json(e.getValue()));
      }
      return "{"+String.join(",",z)+"}";
    }
    if(x instanceof Iterable) {
      List<String> z=new ArrayList<>(); for(Object v:(Iterable<?>)x) z.add(json(v));
      return "["+String.join(",",z)+"]";
    }
    return q(String.valueOf(x));
  }
  static String sha(byte[] b) throws Exception {
    byte[] h=MessageDigest.getInstance("SHA-256").digest(b);
    StringBuilder s=new StringBuilder(); for(byte x:h) s.append(String.format("%02x",x&255)); return s.toString();
  }
  static void checkpoint(String s) throws Exception {
    sampleHeap();long elapsed=(System.nanoTime()-start)/1000000;
    Runtime rt=Runtime.getRuntime();
    stageEvents.add(m("stage",s,"elapsed_ms",elapsed,"heap_used_bytes",rt.totalMemory()-rt.freeMemory(),"heap_committed_bytes",rt.totalMemory(),"heap_max_bytes",rt.maxMemory()));
    stage=s; out.put("stage",stage); out.put("elapsed_ms",elapsed);out.put("stage_events",stageEvents);
    synchronized(sampledPeakHeap){out.put("sampled_peak_heap_by_stage",new LinkedHashMap<>(sampledPeakHeap));}
    out.put("heap_measurement",m("period_ms",20,"scope","sampled JVM heap used, excludes direct memory and OS RSS"));
    Path t=receipt.resolveSibling(receipt.getFileName()+".tmp");
    Files.writeString(t,json(out)+"\n",StandardCharsets.UTF_8);
    Files.move(t,receipt,StandardCopyOption.REPLACE_EXISTING);
  }
  static Object identity(Class<?> c) throws Exception {
    String r="/"+c.getName().replace('.','/')+".class";
    try(InputStream in=c.getResourceAsStream(r)) {
      return m("class",c.getName(),"code_source",String.valueOf(c.getProtectionDomain().getCodeSource()),"class_sha256",sha(in.readAllBytes()));
    }
  }
  static Object constraint(Constraint c) {
    return m("name",c.getName(),"kind",String.valueOf(c.getKind()),"trace_id",c.getTraceId(),"spec",String.valueOf(c.getSpec()),"spec_ast",specTree(c.getSpec()),"text",c.toString());
  }
  static Object player(Player p) {
    List<Object> vars=new ArrayList<>(), cons=new ArrayList<>(), pats=new ArrayList<>(), triggers=new ArrayList<>();
    for(Variable v:p.getVars()) vars.add(m("name",v.getName(),"type",String.valueOf(v.getType()),"trace_id",v.getTraceId()));
    for(Constraint c:p.getConstraints()) cons.add(constraint(c));
    for(PatternConstraint c:p.getPatterns()) pats.add(m("name",c.getName(),"trace_id",c.getTraceId(),"pattern",String.valueOf(c.getPattern()),"actuals",String.valueOf(c.getParameters()),"actuals_ast",specTrees(c.getParameters()),"text",c.toString()));
    for(TriggerConstraint c:p.getTriggers()) triggers.add(constraint(c));
    return m("variables",vars,"constraints",cons,"patterns",pats,"triggers",triggers,"existential_count",p.getExistentialConstraints().size());
  }
  static Object inventory(GameInput gi) { return m("ENV",player(gi.getEnv()),"SYS",player(gi.getSys()),"AUX",player(gi.getAux())); }
  static Object behaviors(List<BehaviorInfo> bs) {
    List<Object> a=new ArrayList<>();
    for(BehaviorInfo b:bs) a.add(m("trace_id",b.traceId,"aux",b.aux,"initial",b.isInitial(),"safety",b.isSafety(),"justice",b.isJustice(),"existential",b.isExistential()));
    return a;
  }
  static Object modelInventory(GameModel gm) {
    return m("ENV",behaviors(gm.getEnvBehaviorInfo()),"SYS",behaviors(gm.getSysBehaviorInfo()),"AUX",behaviors(gm.getAuxBehaviorInfo()),"env_fields",gm.getEnv().getAllFields().toString(),"sys_fields",gm.getSys().getAllFields().toString(),"env_justice_count",gm.getEnv().justiceNum(),"sys_justice_count",gm.getSys().justiceNum(),"env_initial_false",gm.getEnv().initial().isZero(),"sys_initial_false",gm.getSys().initial().isZero());
  }
  static String backend() {
    BDD t=Env.TRUE(); String c=t.getFactory().getClass().getName(); t.free();
    if(!c.equals("net.sf.javabdd.JTLVJavaFactory")) throw new IllegalStateException("Unexpected BDD backend: "+c);
    return c;
  }
  static final List<String> validatorErrors = Collections.synchronizedList(new ArrayList<>());
  static final class ValidationLogWatch extends AppenderSkeleton {
    protected void append(LoggingEvent e) {
      String n=e.getLoggerName();
      if(n!=null && n.contains("validation") && e.getLevel().isGreaterOrEqual(Level.ERROR)) {
        validatorErrors.add(n+": "+e.getRenderedMessage());
      }
    }
    public void close() {} public boolean requiresLayout() { return false; }
  }
  static void validationHealthy() {
    if(!validatorErrors.isEmpty()) throw new IllegalStateException("VALIDATOR_ERROR_LOG: "+validatorErrors);
  }
  static final class UnsupportedDomain extends RuntimeException {
    UnsupportedDomain(String message) { super(message); }
  }
  static void auditSpec(Spec s,boolean prime,boolean initial,Set<String> sys,List<String> violations) {
    if(s instanceof SpecExp) {
      SpecExp e=(SpecExp)s;
      for(Spec child:e.getChildren())auditSpec(child,prime||e.getOperator()==Operator.PRIME,initial,sys,violations);
    } else if(s instanceof VariableReference) {
      VariableReference r=(VariableReference)s;
      String n=r.getVariable().getName();
      boolean p=prime||r.getReferenceName().endsWith("'");
      if(sys.contains(n)&&(p||initial))violations.add((initial?"ENV initial references SYS ":"ENV next references SYS ")+n);
      if(r.getIndexSpecs()!=null)for(Spec idx:r.getIndexSpecs())auditSpec(idx,prime,initial,sys,violations);
    } else if(!(s instanceof PrimitiveValue)) {
      violations.add("Unsupported translated ENV expression class: "+s.getClass().getName());
    }
  }
  static void auditTranslated(GameInput gi) {
    Set<String> sys=new HashSet<>();
    for(Variable v:gi.getSys().getVars())sys.add(v.getName());
    for(Variable v:gi.getAux().getVars())sys.add(v.getName());
    List<String> violations=new ArrayList<>();
    for(Constraint c:gi.getEnv().getConstraints()) {
      if(c.getKind()==Constraint.Kind.INI||c.getKind()==Constraint.Kind.SAFETY)
        auditSpec(c.getSpec(),false,c.getKind()==Constraint.Kind.INI,sys,violations);
    }
    out.put("translated_turn_audit",m("SYS_and_AUX_names",sys,"violations",violations));
    if(!violations.isEmpty())throw new UnsupportedDomain(String.join("; ",violations));
  }
  static List<Integer> ints(int[] xs) { List<Integer> a=new ArrayList<>(); for(int x:xs)a.add(x); return a; }
  static List<Integer> support(BDD b) { BDDVarSet s=b.support(); List<Integer> r=ints(s.toArray()); s.free(); return r; }
  static void currentOnly(String name,BDD b) {
    if(Env.containPrimeVars(b)) throw new IllegalStateException(name+" contains next-state support: "+support(b));
  }
  static boolean subset(BDD a,BDD b) { BDD n=b.not(),x=a.and(n);boolean ok=x.isZero();x.free();n.free();return ok; }
  static Map<String,Object> snapshot(String name,BDD b) throws Exception {
    Path f=receipt.getParent().resolve(name+".bdd");Env.saveBDD(f.toString(),b,false);
    return m("file",f.getFileName().toString(),"bytes",Files.size(f),"sha256",sha(Files.readAllBytes(f)),"node_count",b.nodeCount(),"zero",b.isZero(),"one",b.isOne(),"support",support(b));
  }
  static BDD domain(PlayerModule pm,boolean next) {
    BDD d=Env.TRUE();
    for(ModuleBDDField f:pm.getAllFields()) d.andWith((next?f.other():f).getDomain().domain());
    return d;
  }
  static Object fields(PlayerModule pm) {
    List<Object> a=new ArrayList<>();
    for(ModuleBDDField f:pm.getAllFields()) a.add(m("field",f.toString(),"domain_size",f.getDomain().size().toString(),"current_bits",ints(f.getDomain().vars()),"next_bits",ints(f.other().getDomain().vars())));
    return a;
  }
  static boolean initialDecision(GameModel gm,BDD thetaE,BDD thetaS,BDD region,String prefix) throws Exception {
    currentOnly(prefix+"_region",region);
    BDD witness=thetaS.and(region), has=witness.exist(gm.getSys().moduleUnprimeVars());
    BDD nh=has.not(),missing=thetaE.and(nh);
    BDDVarSet es=gm.getEnv().moduleUnprimeVars();
    BDD residual=missing.exist(es);
    if(!residual.isZero()&&!residual.isOne())throw new IllegalStateException("Initial quantification retains variables: "+support(residual));
    out.put(prefix+"_initial_quantification",m("rule","forall model initial ENV x: theta_e(x) => exists SYS+aux y: theta_s(x,y) AND region(x,y)","sys_quantified_bits",ints(gm.getSys().moduleUnprimeVars().toArray()),"env_quantified_bits",ints(es.toArray()),"system_witness",snapshot(prefix+"_initial_witness",witness),"missing_environment_initials",snapshot(prefix+"_missing_initials",missing),"verdict",missing.isZero()));
    boolean answer=missing.isZero();witness.free();has.free();nh.free();missing.free();residual.free();return answer;
  }
  static void checkOrigins(Path file)throws Exception{Properties ps=new Properties();try(Reader r=Files.newBufferedReader(file)){ps.load(r);}require(ps.size()==22,"origin roster count");List<Object> ids=new ArrayList<>();for(String n:new TreeSet<>(ps.stringPropertyNames())){Class<?> c=Class.forName(n,false,ClassLoader.getSystemClassLoader());Path a=Paths.get(c.getProtectionDomain().getCodeSource().getLocation().toURI());require(Files.isSameFile(a,Paths.get(ps.getProperty(n))),"wrong class origin "+n);ids.add(identity(c));}out.put("class_identities",ids);}
  static BDD viability(GameModel gm,BDD allDomain) throws Exception {
    BDD alive=gm.getEnv().trans().exist(gm.getEnv().modulePrimeVars());currentOnly("Alive",alive);
    out.put("alive",snapshot("alive",alive));
    BDD v=allDomain.id();List<Object> iterations=new ArrayList<>();int i=0;
    while(true) {
      require(java.math.BigInteger.valueOf(i).compareTo(carrierSize)<=0,"V mathematical carrier iteration bound");
      // Exact native ENV-first CPre. Never use pred(), which is cooperative.
      BDD cp=gm.getEnv().yieldStatesOrig(gm.getSys(),v);
      BDD target=Env.prime(v), response=gm.getSys().trans().and(target), ex=response.exist(gm.getSys().modulePrimeVars()), impl=gm.getEnv().trans().imp(ex), direct=impl.forAll(gm.getEnv().modulePrimeVars());
      equality("V_CPre_direct_"+i,cp,direct);target.free();response.free();ex.free();impl.free();
      currentOnly("CPre(V)",cp);
      BDD next=alive.and(cp); next.andWith(allDomain.id());cp.free();
      boolean desc=subset(next,v),eq=next.equals(v);
      iterations.add(m("iteration",i++,"before",snapshot("V_iteration_"+i+"_before",v),"after",snapshot("V_iteration_"+i+"_after",next),"before_nodes",v.nodeCount(),"after_nodes",next.nodeCount(),"descending",desc,"equal",eq));
      if(!desc) throw new IllegalStateException("V iteration is not descending");
      v.free();v=next;
      if(eq)break;
    }
    BDD cp=gm.getEnv().yieldStatesOrig(gm.getSys(),v);
    boolean insideAlive=subset(v,alive),closed=subset(v,cp);
    BDD tv=alive.and(cp);tv.andWith(allDomain.id());boolean fixed=tv.equals(v);
    out.put("viability_iterations",iterations);
    out.put("viability_obligations",m("V_subset_Alive",insideAlive,"V_subset_CPre_V",closed,"V_equals_T_V",fixed,"V_current_only",!Env.containPrimeVars(v)));
    if(!insideAlive||!closed||!fixed)throw new IllegalStateException("Viability proof obligation failed");
    out.put("V",snapshot("V",v));alive.free();cp.free();tv.free();return v;
  }
  static final class InvariantMismatch extends RuntimeException{InvariantMismatch(String s){super(s);}}
  static void require(boolean b,String s){if(!b)throw new InvariantMismatch(s);}
  static Object specTree(Spec s){
    if(s==null)return null;
    if(s instanceof SpecExp){SpecExp e=(SpecExp)s;List<Object>children=new ArrayList<>();for(Spec c:e.getChildren())children.add(specTree(c));return m("kind","operator","operator",e.getOperator().toString(),"children",children);}
    if(s instanceof VariableReference){VariableReference v=(VariableReference)s;return m("kind","variable","name",v.getVariable().getName(),"reference_name",v.getReferenceName(),"trace_id",v.getVariable().getTraceId());}
    if(s instanceof PrimitiveValue)return m("kind","primitive","value",((PrimitiveValue)s).getValue());
    return m("kind","other","class",s.getClass().getName(),"text",s.toString());
  }
  static List<Object>specTrees(Iterable<Spec> xs){List<Object>r=new ArrayList<>();for(Spec x:xs)r.add(specTree(x));return r;}
  static Map<String,Object> filePin(Path p)throws Exception{return m("file",p.getFileName().toString(),"bytes",Files.size(p),"sha256",sha(Files.readAllBytes(p)));}
  static Map<String,Object> writeJson(String file,Map<String,Object> data)throws Exception{Path p=receipt.getParent().resolve(file);Files.writeString(p,json(data)+"\n",StandardCharsets.UTF_8);return filePin(p);}
  static Map<String,Object> identityFields(){return m("fixture_id",fixtureId,"case_id",caseId,"variant",variant);}
  static void equality(String label,BDD actual,BDD expected)throws Exception{BDD diff=actual.xor(expected);out.put(label,m("equal",diff.isZero(),"actual",snapshot(label+"_actual",actual),"expected",snapshot(label+"_expected",expected),"xor",snapshot(label+"_xor",diff)));boolean ok=diff.isZero();diff.free();expected.free();require(ok,label+" BDD equality failed");}
  static List<ModuleBDDField> allFields(GameModel gm){List<ModuleBDDField>x=new ArrayList<>();x.addAll(gm.getEnv().getAllFields());x.addAll(gm.getSys().getAllFields());return x;}
  static Map<String,Object> fixedBits(BDD b,int[]indices){Map<String,Object>r=new TreeMap<>();for(int bit:indices){BDD yes=b.getFactory().ithVar(bit),no=b.getFactory().nithVar(bit);boolean y=subset(b,yes),n=subset(b,no);yes.free();no.free();require(y!=n,"Incomplete or empty bit assignment "+bit);r.put(String.valueOf(bit),y);}return r;}
  static Map<String,Object> stateBits(BDD b,GameModel gm){BDDVarSet vars=gm.getEnv().moduleUnprimeVars().union(gm.getSys().moduleUnprimeVars());Map<String,Object>r=fixedBits(b,vars.toArray());vars.free();return r;}
  static Map<String,Object> singletonValuation(BDD b,GameModel gm){
    currentOnly("complete valuation",b);if(b.isZero())return null;Map<String,Object>r=new LinkedHashMap<>();BDD cube=Env.TRUE();
    for(ModuleBDDField field:allFields(gm)){String name=field.getName(),chosen=null;List<String>values=Env.getValueNames(name);int count=0;
      for(String value:values){BDD literal=Env.getBDDValue(name,value);require(literal!=null,"Missing native domain value");if(subset(b,literal)){chosen=value;count++;}}
      if(count!=1){cube.free();return null;}r.put(name,chosen);cube.andWith(Env.getBDDValue(name,chosen).id());
    }
    boolean full=b.equals(cube);cube.free();return full?r:null;
  }
  static List<Object> modelFields(GameModel gm,Set<String>publicEnv,Set<String>publicSys){
    List<Object>r=new ArrayList<>();Set<String>seen=new HashSet<>();Set<Integer>bits=new HashSet<>();carrierSize=java.math.BigInteger.ONE;
    for(ModuleBDDField f:allFields(gm)){String name=f.getName();require(seen.add(name),"Duplicate native field");List<String>values=Env.getValueNames(name);Collections.sort(values);require(java.math.BigInteger.valueOf(values.size()).equals(f.getDomain().size()),"Native value roster/domain mismatch");Map<String,Object>enc=new LinkedHashMap<>();
      for(int bit:f.getDomain().vars())require(bits.add(bit),"Duplicate current field bit");for(int bit:f.other().getDomain().vars())require(bits.add(bit),"Duplicate next field bit");
      for(String value:values){BDD lit=Env.getBDDValue(name,value);require(lit!=null&&!lit.isZero(),"Native field encoding missing");BDD prime=Env.prime(lit);enc.put(value,m("current",fixedBits(lit,f.getDomain().vars()),"next",fixedBits(prime,f.other().getDomain().vars())));prime.free();}
      String owner=gm.getEnv().getAllFields().contains(f)?"ENV":"SYS";String role=publicEnv.contains(name)?"ENV":publicSys.contains(name)?"SYS":"AUX";require(!owner.equals("ENV")||role.equals("ENV"),"Unexpected ENV auxiliary ownership");
      r.add(m("name",name,"owner",owner,"role",role,"domain_size",f.getDomain().size().intValueExact(),"values",values,"current_bits",ints(f.getDomain().vars()),"next_bits",ints(f.other().getDomain().vars()),"encoding",enc));carrierSize=carrierSize.multiply(f.getDomain().size());
    }return r;
  }
  static List<Object> justiceSnapshots(PlayerModule module,String prefix)throws Exception{List<Object>x=new ArrayList<>();for(int i=0;i<module.justiceNum();i++){currentOnly(prefix,module.justiceAt(i));x.add(snapshot(prefix+"_"+i,module.justiceAt(i)));}return x;}
  static Map<String,Object> modelExport(GameModel gm,Set<String>pe,Set<String>ps,Object parsed,Object translated,Path input)throws Exception{
    Map<String,Object>r=identityFields();r.put("schema","k7-native-model-export-v1");r.put("input",m("path",input.toString(),"bytes",Files.size(input),"sha256",sha(Files.readAllBytes(input))));r.put("fields",modelFields(gm,pe,ps));r.put("public_fields",m("ENV",pe,"SYS",ps));
    BDDVarSet curr=gm.getEnv().moduleUnprimeVars().union(gm.getSys().moduleUnprimeVars()),next=gm.getEnv().modulePrimeVars().union(gm.getSys().modulePrimeVars());r.put("all_current_bits",ints(curr.toArray()));r.put("all_next_bits",ints(next.toArray()));curr.free();next.free();
    BDD de=domain(gm.getEnv(),false),ds=domain(gm.getSys(),false),dep=domain(gm.getEnv(),true),dsp=domain(gm.getSys(),true),d=de.and(ds);
    r.put("bdd_variable_count",d.getFactory().varNum());List<Integer>varOrder=new ArrayList<>();for(int level=0;level<d.getFactory().varNum();level++)varOrder.add(d.getFactory().level2Var(level));r.put("bdd_variable_order",varOrder);r.put("original_bdds",m("thetaE",snapshot("original_thetaE",gm.getEnv().initial()),"thetaS",snapshot("original_thetaS",gm.getSys().initial()),"rhoE",snapshot("original_rhoE",gm.getEnv().trans()),"rhoS",snapshot("original_rhoS",gm.getSys().trans()),"domain",snapshot("domain",d),"domain_ENV_next",snapshot("domain_ENV_next",dep),"domain_SYS_next",snapshot("domain_SYS_next",dsp)));
    r.put("original_justices",m("ENV",justiceSnapshots(gm.getEnv(),"original_ENV_justice"),"SYS",justiceSnapshots(gm.getSys(),"original_SYS_justice")));r.put("source_inventory",m("parsed",parsed,"translated",translated,"native_behaviors",modelInventory(gm)));de.free();ds.free();dep.free();dsp.free();d.free();return r;
  }
  static List<Map<String,String>> readTrace(Path path,Set<String>publicNames)throws Exception{
    List<String>lines=Files.readAllLines(path,StandardCharsets.UTF_8);require(lines.size()>=2,"Trace has no observations");String[]names=lines.get(0).split("\t",-1);Set<String>unique=new HashSet<>(Arrays.asList(names));require(unique.size()==names.length&&unique.equals(publicNames),"Trace header differs from exact original public variables");List<Map<String,String>>rows=new ArrayList<>();
    for(int i=1;i<lines.size();i++){String[]cells=lines.get(i).split("\t",-1);require(cells.length==names.length,"Trace row width");Map<String,String>row=new LinkedHashMap<>();for(int j=0;j<names.length;j++){require(Env.getBDDValue(names[j],cells[j])!=null,"Unknown typed trace value");row.put(names[j],cells[j]);}rows.add(row);}return rows;
  }
  static BDD observation(Map<String,String>row){BDD cube=Env.TRUE();for(Map.Entry<String,String>e:row.entrySet()){ModuleBDDField field=Env.getVar(e.getKey());require(field!=null&&!field.isPrime(),"Trace field not current");BDD lit=Env.getBDDValue(e.getKey(),e.getValue());require(lit!=null&&!lit.isZero(),"Invalid typed observation");cube.andWith(lit.id());}currentOnly("observed public cube",cube);return cube;}
  static BDD replay(GameModel gm,BDD d,Path trace,Set<String>publicNames)throws Exception{
    List<Map<String,String>>obs=readTrace(trace,publicNames);BDD endpoint=gm.getEnv().initial().and(gm.getSys().initial());endpoint.andWith(observation(obs.get(0)));require(subset(endpoint,d),"Replay initial outside domain");BDDVarSet curr=gm.getEnv().moduleUnprimeVars().union(gm.getSys().moduleUnprimeVars());List<Object>states=new ArrayList<>(),edges=new ArrayList<>();states.add(m("observation_index",0,"states",snapshot("replay_state_0",endpoint)));
    for(int i=0;i+1<obs.size();i++){BDD nextObs=observation(obs.get(i+1)),primeObs=Env.prime(nextObs);nextObs.free();BDD rel=endpoint.and(gm.getEnv().trans());rel.andWith(gm.getSys().trans().id());rel.andWith(primeObs);BDD nextPrime=rel.exist(curr);require(!Env.containUnprimeVars(nextPrime),"Replay retained current bits");BDD next=Env.unprime(nextPrime);currentOnly("replay successor",next);require(subset(next,d),"Replay successor outside domain");edges.add(m("edge_index",i,"relation",snapshot("replay_edge_"+i,rel),"successor_before_unprime",snapshot("replay_next_prime_"+i,nextPrime)));states.add(m("observation_index",i+1,"states",snapshot("replay_state_"+(i+1),next)));endpoint.free();endpoint=next;rel.free();nextPrime.free();}
    curr.free();Map<String,Object>values=singletonValuation(endpoint,gm),r=identityFields();r.put("schema","k7-original-prefix-replay-v1");r.put("trace_input",m("path",trace.toString(),"bytes",Files.size(trace),"sha256",sha(Files.readAllBytes(trace))));r.put("public_field_order",new ArrayList<>(obs.get(0).keySet()));r.put("observations",obs);r.put("states",states);r.put("edges",edges);r.put("endpoint",snapshot("replay_endpoint",endpoint));r.put("endpoint_status",endpoint.isZero()?"EMPTY":values==null?"AMBIGUOUS":"SINGLETON");r.put("entry_valuation",values);r.put("entry_bits",values==null?null:stateBits(endpoint,gm));r.put("original_initializers_applied_once",true);r.put("manual_monitor_initialization",false);r.put("unobserved_outgoing_endpoint_edge_processed",false);r.put("rule","E0=candidate original thetaE AND thetaS AND Obs0; Ei+1=unprime(exists all current bits [Ei AND candidate original rhoE AND rhoS AND prime(Obsi+1)])");out.put("replay_export",writeJson("replay.json",r));return endpoint;
  }
  static void extractionOrigins()throws Exception{
    Class<?>[] cs={GR1ConceteControllerConstructionSkip.class,GR1RankInfo.class,EnumStrategyImpl.class,EnumStateI.class,AbstractRankInfo.class};List<Object>ids=new ArrayList<>();
    for(Class<?>c:cs){Class<?>anchor=c.getName().contains(".gr1.")?GR1Game.class:tau.smlab.syntech.games.GameMemory.class;Path actual=Paths.get(c.getProtectionDomain().getCodeSource().getLocation().toURI()),expected=Paths.get(anchor.getProtectionDomain().getCodeSource().getLocation().toURI());require(Files.isSameFile(actual,expected),"Extractor class origin mismatch "+c.getName());ids.add(identity(c));}out.put("extractor_class_identities",ids);
  }
  static void exportController(EnumStrategyI controller,GameModel gm)throws Exception{
    Vector<? extends EnumStateI>states=controller.enumController();require(states.size()<=4096,"Controller state export resource cap");List<Object>nodes=new ArrayList<>(),edges=new ArrayList<>();List<String>order=new ArrayList<>();Set<Integer>ids=new HashSet<>();for(EnumStateI st:states){require(ids.add(st.getStateId()),"Duplicate native state ID");order.add(String.valueOf(st.getStateId()));}
    for(EnumStateI st:states){List<String>succ=new ArrayList<>();String from=String.valueOf(st.getStateId());for(EnumStateI to:st.getSuccessors()){require(ids.contains(to.getStateId()),"Edge to missing native ID");String target=String.valueOf(to.getStateId());succ.add(target);edges.add(Arrays.asList(from,target));require(edges.size()<=65536,"Controller edge export resource cap");}AbstractRankInfo rank=st.get_rank_info();require(rank instanceof GR1RankInfo,"Unexpected rank class");Map<String,Object>values=singletonValuation(st.getData(),gm);require(values!=null,"Non-singleton/empty emitted state");nodes.add(m("id",from,"native_id",st.getStateId(),"rank",rank.memVal(),"rank_class",rank.getClass().getName(),"rank_info",rank.rankInfoString(),"initial",st.isInitial(),"valuation",values,"bits",stateBits(st.getData(),gm),"successors",succ));}
    Map<String,Object>r=identityFields();r.put("schema","released-concrete-controller-export-v2");r.put("pipeline",pipeline);r.put("solver",selectedSolver);r.put("complete",true);r.put("model_sha256",sha(Files.readAllBytes(receipt.getParent().resolve("model.json"))));r.put("replay_sha256",null);r.put("entry_mode","original_initializer");r.put("entry_valuation",null);r.put("entry_bits",null);r.put("initialization",m("quantifier","forall_ENV_exists_SYS_AUX","source_initializers_preserved",true,"private_memory_policy","rank0"));r.put("handoff",m("policy","new_controller_rank0","rank",0));r.put("rank_domain_size",gm.getSys().justiceNum());r.put("api_state_count",states.size());r.put("api_transition_count",controller.numOfTransitions());r.put("exported_edge_count",edges.size());r.put("api_state_order",order);r.put("nodes",nodes);r.put("edges",edges);r.put("controller_certified",false);Map<String,Object>pin=writeJson("controller.json",r);pin.putAll(m("complete",true,"api_state_count",states.size(),"api_transition_count",controller.numOfTransitions(),"exported_edge_count",edges.size()));out.put("controller_export",pin);
  }
  public static void main(String[]args)throws Exception{
    if(args.length!=6)throw new IllegalArgumentException("fixture_id pipeline solver input result origins");
    fixtureId=args[0];String[]fv=fixtureId.split("__",-1);require(fv.length==2,"Fixture ID format");caseId=fv[0];variant=fv[1];pipeline=args[1];selectedSolver=args[2];
    require((pipeline.equals("v_restricted_strict")&&selectedSolver.equals("3fp"))||(pipeline.equals("normalized_kind")&&selectedSolver.equals("4fp")),"Pipeline/solver mismatch");
    receipt=Paths.get(args[4]).toAbsolutePath();start=System.nanoTime();startHeapSampler();int exit=0;BDDFactory factory=null;GR1Game game=null;GameModel gm=null;
    out.putAll(identityFields());out.put("schema","k7-native-admission-production-v1");out.put("pipeline",pipeline);out.put("solver",selectedSolver);out.put("status","RUNNING");out.put("native_solver_called",false);out.put("controller_extraction_called",false);out.put("controller_certified",false);out.put("controller_export",null);
    out.put("entry_mode","original_initializer");out.put("entry_valuation",null);out.put("entry_bits",null);out.put("replay_export",null);out.put("replay_sha256",null);out.put("trace_sha256",null);out.put("initialization",m("quantifier","forall_ENV_exists_SYS_AUX","source_initializers_preserved",true,"private_memory_policy","rank0"));
    out.put("runtime",m("java_version",System.getProperty("java.version"),"java_vendor",System.getProperty("java.vendor"),"java_home",System.getProperty("java.home"),"os_arch",System.getProperty("os.arch")));out.put("options",m("release","1.0.0.202402072123","backend","JTLVJavaFactory","trans_func","SINGLE_FUNC","SCA",false,"TEST_MODE",false,"group_vars",true));Logger.getRootLogger().addAppender(new ValidationLogWatch());
    try{
      checkOrigins(Paths.get(args[5]));extractionOrigins();Path input=Paths.get(args[3]).toRealPath();out.put("input",input.toString());out.put("input_sha256",sha(Files.readAllBytes(input)));
      checkpoint("PARSE_VALIDATE");GameInput gi=new SpectraInputProviderNoIDE().getGameInput(input.toString());validationHealthy();Object parsed=inventory(gi);out.put("parsed_inventory",parsed);Set<String>pe=new LinkedHashSet<>(),ps=new LinkedHashSet<>();for(Variable v:gi.getEnv().getVars())pe.add(v.getName());for(Variable v:gi.getSys().getVars())ps.add(v.getName());
      checkpoint("DEFAULT_TRANSLATORS");TranslationProvider.translate(gi,tau.smlab.syntech.gameinputtrans.translator.DefaultTranslators.getDefaultTranslators());validationHealthy();Object translated=inventory(gi);out.put("translated_inventory",translated);auditTranslated(gi);
      checkpoint("JTLV_BACKEND");BDDPackage.setCurrPackage(BDDPackage.JTLV,BDDPackage.BBDPackageVersion.DEFAULT);BDD one=Env.TRUE();factory=one.getFactory();one.free();out.put("observed_backend",backend());
      checkpoint("ORIGINAL_BDD_MODEL");gm=BDDGenerator.generateGameModel(gi,TraceInfo.ALL,true,PlayerModule.TransFuncType.SINGLE_FUNC,false);gm.getEnv().setSCA(false);gm.getSys().setSCA(false);PlayerModule.TEST_MODE=false;validationHealthy();out.put("model_export",writeJson("model.json",modelExport(gm,pe,ps,parsed,translated,input)));
      if(carrierSize.compareTo(java.math.BigInteger.valueOf(4096))>0)throw new UnsupportedDomain("PHASE2_CARRIER_RESOURCE_LIMIT_4096");
      BDD de=domain(gm.getEnv(),false),ds=domain(gm.getSys(),false),dep=domain(gm.getEnv(),true),dsp=domain(gm.getSys(),true),d=de.and(ds);currentOnly("original thetaE",gm.getEnv().initial());currentOnly("original thetaS",gm.getSys().initial());boolean eis=Env.hasVars(gm.getEnv().initial(),gm.getSys().moduleUnprimeVars()),ens=Env.hasVars(gm.getEnv().trans(),gm.getSys().modulePrimeVars()),ed=subset(gm.getEnv().trans(),dep),sd=subset(gm.getSys().trans(),dsp);out.put("support_audit",m("env_initial_has_SYS",eis,"env_relation_has_next_SYS",ens,"env_relation_in_next_ENV_domain",ed,"sys_relation_in_next_SYS_domain",sd));require(!eis&&!ens&&ed&&sd,"Original turn/domain support mismatch");de.free();ds.free();dep.free();dsp.free();out.put("relations_validated_before_solver",true);
      BDD thetaE=gm.getEnv().initial().id(),thetaS=gm.getSys().initial().id(),joint=thetaE.and(thetaS);
      out.put("initial_ENV_empty",thetaE.isZero());out.put("initial_joint_empty",joint.isZero());joint.free();
      if(thetaE.isZero()){
        out.put("status","COMPLETE_VACUOUS_INITIALIZER");out.put("initial_in_region",true);
      }else{
        checkpoint("VIABILITY_FIXED_POINT");BDD v=viability(gm,d);gm.getSys().conjunctTrans(v.id());gm.getSys().conjunctTrans(Env.prime(v));
        int copies=0;if(pipeline.equals("normalized_kind")){copies=gm.getEnv().justiceNum();for(int j=0;j<copies;j++)gm.getSys().addJustice(gm.getEnv().justiceAt(j).id());}
        out.put("normalization",m("V_restriction",true,"ENV_justice_copies",copies,"helper_added",false,"justice_policy",pipeline.equals("v_restricted_strict")?"original_rosters_constructor_TRUE_padding_only":"original_SYS_then_original_ENV_constructor_TRUE_padding_only","restricted_rhoS",snapshot("restricted_rhoS",gm.getSys().trans())));
        gm.getSys().conjunctInitial(v.id());out.put("residual_thetaE",snapshot("residual_thetaE",gm.getEnv().initial()));out.put("residual_thetaS",snapshot("residual_thetaS",gm.getSys().initial()));out.put("preconstructor_justices",m("ENV",justiceSnapshots(gm.getEnv(),"preconstructor_ENV_justice"),"SYS",justiceSnapshots(gm.getSys(),"preconstructor_SYS_justice")));
        if(v.isZero()){
          BDD zero=Env.FALSE();out.put("status","COMPLETE_EMPTY_V_REJECTION");out.put("final_region",snapshot("final_region",zero));boolean verdict=initialDecision(gm,thetaE,gm.getSys().initial(),zero,"original");out.put("initial_in_region",verdict);zero.free();
        }else{
          checkpoint("SOLVER_CONSTRUCTION");game=selectedSolver.equals("3fp")?new GR1Game(gm):new GR1SeparatedGame(gm);out.put("solver_class",game.getClass().getName());out.put("solver_class_identity",identity(game.getClass()));out.put("solver_input_justices",m("ENV",justiceSnapshots(gm.getEnv(),"solver_ENV_justice"),"SYS",justiceSnapshots(gm.getSys(),"solver_SYS_justice")));out.put("native_solver_called",true);
          checkpoint("NATIVE_SOLVER_CALL");boolean answer=game.checkRealizability();BDD w=game.sysWinningStates().id(),region=w.and(v);currentOnly("native W",w);currentOnly("final region",region);out.put("native_W",snapshot("native_W",w));out.put("final_region",snapshot("final_region",region));
          boolean member=initialDecision(gm,thetaE,gm.getSys().initial(),region,"original");require(answer==member,"Original initializer quantified verdict mismatch");out.put("native_residual_initial_verdict",answer);out.put("initial_in_region",member);
          if(!answer)out.put("status","COMPLETE_REGION_REJECTION");else{
            out.put("controller_extraction_called",true);out.put("extractor",m("class",GR1ConceteControllerConstructionSkip.class.getName(),"default_priority","ZYX","same_game_memory_identity",System.identityHashCode(game.getMem()),"same_game_model_identity",System.identityHashCode(gm),"fallback_used",false));checkpoint("CONCRETE_EXTRACTION");
            try{GR1ConceteControllerConstructionSkip extractor=new GR1ConceteControllerConstructionSkip(game.getMem(),gm);EnumStrategyI controller=extractor.calculateConcreteController();require(controller!=null,"Null emitted controller");checkpoint("CONTROLLER_EXPORT");exportController(controller,gm);out.put("status","COMPLETE_CONTROLLER_EXPORTED");}
            catch(Throwable e){out.put("status","COMPLETE_EXTRACTION_OR_EXPORT_FAILURE");out.put("extraction_failed_stage",stage);out.put("extraction_exception",e.toString());StringWriter sw=new StringWriter();e.printStackTrace(new PrintWriter(sw));out.put("extraction_stacktrace",sw.toString());}
          }
          region.free();w.free();
        }
        v.free();
      }
      thetaE.free();thetaS.free();d.free();checkOrigins(Paths.get(args[5]));extractionOrigins();validationHealthy();checkpoint("COMPLETE");
    }catch(Throwable e){exit=2;out.put("failed_stage",stage);out.put("status","ERROR");out.put("exception_class",e.getClass().getName());out.put("exception",e.toString());StringWriter sw=new StringWriter();e.printStackTrace(new PrintWriter(sw));out.put("stacktrace",sw.toString());checkpoint("ERROR");}
    finally{checkpoint("TEARDOWN");try{if(game!=null)game.free();if(gm!=null)gm.free();if(factory!=null)factory.done();out.put("teardown","COMPLETED");}catch(Throwable t){exit=3;out.put("status","ERROR");out.put("teardown","FAILED");out.put("teardown_error",t.toString());}if(heapSampler!=null)heapSampler.cancel();checkpoint("PROCESS_FINISHED");}System.exit(exit);
  }
}
