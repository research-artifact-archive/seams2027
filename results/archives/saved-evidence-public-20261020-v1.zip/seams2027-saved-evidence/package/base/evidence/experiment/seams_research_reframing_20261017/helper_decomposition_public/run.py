"""Prepare-only default; a run requires Root's exact reviewed freeze."""
import argparse,importlib.util,json,os,sys,time
from pathlib import Path
from datetime import datetime,timezone
sys.dont_write_bytecode=True
from evidence import B,H,S,CHECK,STAGE,select,read,save,pin,pins_in,unique,verify,require,now
MIN_START_SECONDS=75
CODE=('evidence.py','decomposition.py','import_original.py','measure.py','run.py','qualify_math.py','qualify_authority.py','PROTOCOL_JA.txt','MATH_QUALIFICATION.json','AUTHORITY_QUALIFICATION.json')

def preserve_interrupted_attempt(value):
    if value.get('status')=='UNKNOWN_NOT_ATTEMPTED' and value.get('BDD_worker_started') is not False:value.update(status='UNKNOWN_RUNNER_FAILURE',reason='Worker start confirmed or uncertain before runner interruption')
    return value

def prepare():
    require(not (B/'FROZEN.json').exists() and not (B/'RUN_STARTED.json').exists(),'No frozen overwrite')
    if not (B/'SELECTION.json').exists():save(B/'SELECTION.json',select())
    selection=read(B/'SELECTION.json');verify(selection['input_pins'])
    for name in ('MATH_QUALIFICATION.json','AUTHORITY_QUALIFICATION.json'):
        q=read(B/name);require(q['status']=='PASS' and q['corpus_BDD_computations']==0 and q['native_runs']==0,'Synthetic qualification only');verify(q['source_pins'])
    code=[pin(B/name) for name in CODE]+[pin(H/'map_pair.py')]+[pin(S/name) for name in ('symbolic.py','check_case.py','vendor/bdd_core.py','vendor/finite_sets_v1.py')]+[pin(CHECK/name) for name in ('generic_base.py','vendor/bdd_core.py','SOURCE_FREEZE.json')]
    code+=[pin(B.parent/'preservation_condition_public/condition.py'),pin(STAGE/'FROZEN.json')]+pins_in(read(STAGE/'FROZEN.json'))+[pin(Path(sys.executable).resolve())]
    code=unique(code);files=unique(code+selection['input_pins']+[pin(B/'SELECTION.json'),pin(B/'PEER_REVIEW.json')]+[p for row in selection['rows'] for p in row.get('input_pins',[])])
    verify(files)
    save(B/'FROZEN.json',{'schema':'helper-decomposition-freeze-v1','created_utc':now(),'files':files,'code_files':code,'python':pin(Path(sys.executable).resolve()),'selection':pin(B/'SELECTION.json'),
        'limits':{'native_and_common_variables':64,'nodes_per_BDD_manager':500000,'original_typed_carrier':4096,'job_typed_carrier':8192,'per_saved_BDD_bytes':8388608,'function_export_uncompressed_bytes':67108864,'case_wall_seconds':60,'workers':1},
        'parent_aborted':True,'root_review_status':'AWAITING_ROOT_REVIEW_NO_CORPUS_BDD_DISPATCH','native_runs':0,'corpus_BDD_computations':0})
    print(json.dumps({'status':'PREPARED_NO_CORPUS_BDD','fixed_cohort':14,'eligible':selection['eligible_count'],'files':len(files)}))

def validate_result(result,ident,row,freeze,decision):
    require(result.get('schema')=='helper-decomposition-case-v1' and result.get('id')==ident,'Case result identity')
    require(result.get('status') in ('PASS','FAIL_DECOMPOSITION','UNKNOWN_RESOURCE','UNKNOWN_INTEGRITY'),'Recognized case status')
    require(result.get('root_authorization')==decision and result.get('parent_aborted') is True,'Child exact authorization scope')
    require(result.get('native_runs')==0 and result.get('full_reset_uses')==0 and result.get('direct_reference_objective')=='strict_GR1_on_actual_saved_transformed_arena' and result.get('compared_with_native_4fp_region') is False,'Strict reference, not native 4FP region')
    require(result.get('claim_is_cooperative_strategy_existence') is False and result.get('released_10_condition_negative_cases_inference') is False and result.get('all_original_AUX_retained') is True,'No unsupported cooperative/other-cohort inference')
    require(result.get('independent_source_compiler') is False and result.get('shared_source_compiler') is True and result.get('common_BDD_and_GR1_engine_between_direct_and_decomposed') is True and result.get('synthetic_finite_set_oracle_independent_representation') is True,'Independence boundary')
    if result['status'] in ('PASS','FAIL_DECOMPOSITION'):
        require(result['original_model']==row['original_model'] and result['job_model']==row['job_model'] and result['native_result']==row['native_result'] and result['enclosing_native_parent']==row['parent_receipt'],'Exact prior model/native authority')
        require(result['independent_W_certificate']==row['independent_W_certificate'] and result['independent_W_process']==row['independent_W_process'] and result['independent_regions']==row['independent_regions'] and result['original_W_exact_authority_equal'] is True and result['original_initial_quantification_authority_equal'] is True,'Exact original W and initializer authority')
        require(result['prior_quadrant_result']==row['quadrant_result'] and result['prior_quadrant_process']==row['quadrant_process'],'Exact relation authority')
        expected=freeze['code_files']+row['input_pins']+[pin(B/'FROZEN.json'),pin(B/'SELECTION.json'),decision]
        require(result['input_pins']==expected,'Exact current input/code/decision pins')
        s=result['summary'];require(type(s['helper_added']) is bool and s['branch']==('ONE_WAY_HELPER' if s['helper_added'] else 'NO_HELPER_IDENTITY'),'Helper branch identity')
        carrier=s['original_typed_carrier'];require(type(carrier) is int and carrier>0 and s['full_job_typed_carrier']==carrier*(2 if s['helper_added'] else 1),'Full typed carrier')
        counts=s['counts'];require(set(counts)==set(s['canonical_sha256'])==set(s['state_witnesses']),'Complete root result roster')
        require(all(type(n) is int and 0<=n<=2*carrier for n in counts.values()),'Exact root cardinalities')
        require(counts['D']==carrier,'Original whole domain cardinality')
        require(all(type(v) is str and len(v)==64 and set(v)<=set('0123456789abcdef') for v in s['canonical_sha256'].values()),'Canonical digest shapes')
        fields={f['name'] for f in read(row['original_model']['path'])['fields']}
        for name,w in s['state_witnesses'].items():
            require((w is None)==(counts[name]==0),'Witness iff nonempty root')
            if w is not None:require(set(w['state'])==fields,'Witness retains all original typed fields and AUX')
        checks=s['checks'];require(all(v is None or type(v) is bool for v in checks.values()),'Boolean/nullable checks')
        require(checks['active_decomposition_equal']==(counts['active_difference']==0),'Active equality/difference consistency')
        if s['helper_added']:
            require(checks['trap_decomposition_equal']==(counts['trap_difference']==0) and checks['U_equals_D']==(counts['U_missing']==0) and checks['F_equals_C']==(counts['F_xor_C']==0) and checks['F_equals_D']==(counts['F_missing']==0),'Trap/U/F Boolean consistency')
            require(checks['W_subset_F']==(counts['W_minus_F']==0),'W subset F Boolean consistency')
            require(counts['W_loss']>=counts['W_minus_F'] and counts['W_loss']==counts['W_minus_F']+counts['delayed_loss'],'Immediate versus delayed exact loss partition')
        require(checks['original_full_region_preserved']==(counts['W_loss']==0),'Preservation/exact loss consistency')
        require(set(s['initial_quantification'])=={'W_original','W_predicted','W_direct_active','actual_job'},'Initial quantifier roster')
        for q in s['initial_quantification'].values():require(type(q['value']) is bool and type(q['missing_initial_ENV_count']) is int and type(q['SYS_witness_count']) is int and q['value']==(q['missing_initial_ENV_count']==0),'Initial missing-ENV semantics')
        equal=checks['active_decomposition_equal'] and (checks['trap_decomposition_equal'] is not False) and checks['initial_quantification_equal'] and checks['subset_original'] and checks['full_preservation_iff_W_subset_F'] is not False
        require((result['status']=='PASS')==equal,'Scientific PASS exactly matches decomposition obligations')
        verify([result['functions']])

def run(deadline):
    from measure import authorization
    decision=authorization();end=datetime.fromisoformat(deadline);require(end.tzinfo is not None,'Timezone-aware Root deadline')
    freeze=read(B/'FROZEN.json');verify(freeze['files']);require(freeze['python']==pin(Path(sys.executable).resolve()),'Frozen Python identity')
    selection=read(B/'SELECTION.json');require(selection['source_denominator']==425 and selection['fixed_small_cohort_count']==14 and selection['eligible_count']==13,'Fixed all13 saved-output denominator')
    byid={row['id']:row for row in selection['rows']};require(not (B/'RUN_STARTED.json').exists() and not (B/'RUN_RECEIPT.json').exists(),'One dispatch only, no retries')
    sys.path.insert(0,str(STAGE));spec=importlib.util.spec_from_file_location('decomposition_contained_stage',STAGE/'bounded_process.py');bounded=importlib.util.module_from_spec(spec);spec.loader.exec_module(bounded)
    with (B/'RUN_STARTED.json').open('x') as f:json.dump({'started_utc':now(),'owner_pid':os.getpid(),'freeze':pin(B/'FROZEN.json'),'root_authorization':decision},f)
    outputs={};outputrefs=[decision];stop=False;reasons=[];started=time.monotonic()
    try:
        for ident in selection['eligible_ids']:
            value={'id':ident,'status':'UNKNOWN_NOT_ATTEMPTED','BDD_worker_started':False};outputs[ident]=value
            if stop or (end-datetime.now(timezone.utc)).total_seconds()<MIN_START_SECONDS:continue
            verify(freeze['code_files']+[decision])
            if (end-datetime.now(timezone.utc)).total_seconds()<MIN_START_SECONDS:continue
            value['BDD_worker_started']=None;folder=B/'runs'/ident
            process=bounded.run_bounded([sys.executable,'-B',str(B/'measure.py'),ident],folder/'process',deadline,wall_seconds=60,file_bytes=67108864,watch_files=[folder/'RESULT.json',folder/'FUNCTIONS.json.gz'])
            value.update(BDD_worker_started=process['process_started'],process=pin(folder/'process/PROCESS_RECEIPT.json'));outputrefs.append(value['process'])
            if process['status']=='PROCESS_COMPLETED' and process['exit_code']==0 and (folder/'RESULT.json').exists():
                value['status']='UNKNOWN_INTEGRITY';result=read(folder/'RESULT.json');validate_result(result,ident,byid[ident],freeze,decision)
                value.update(status=result['status'],result=pin(folder/'RESULT.json'));outputrefs+=[value['result']]+pins_in(result)
                if result['status'] in ('PASS','FAIL_DECOMPOSITION'):value.update(summary=result['summary'])
                if result['status'] in ('UNKNOWN_INTEGRITY','FAIL_DECOMPOSITION'):stop=True;reasons.append(result['status'])
            else:
                value['status']='UNKNOWN_RESOURCE' if process['status']=='UNKNOWN_RESOURCE' else 'UNKNOWN_PROCESS'
                if value['status']=='UNKNOWN_PROCESS':stop=True;reasons.append('UNEXPECTED_WORKER_EXIT_OR_MISSING_RESULT')
            if process['status'].startswith('FATAL_'):stop=True;reasons.append('PROCESS_INTEGRITY')
            verify([decision]);save(B/'PROGRESS.json',{'finished':False,'rows':list(outputs.values()),'native_runs':0})
    except BaseException as error:stop=True;reasons.append(repr(error))
    try:verify(freeze['files']+outputrefs)
    except BaseException as error:stop=True;reasons.append('FINAL_PIN_INTEGRITY:'+repr(error))
    for value in outputs.values():preserve_interrupted_attempt(value)
    rows=[outputs.get(row['id'],{'id':row['id'],'status':'UNKNOWN_NOT_ATTEMPTED' if row['eligible'] else row['prior_status'],'BDD_worker_started':False,'in_fixed_small_cohort':row['in_fixed_small_cohort']}) for row in selection['rows']]
    receipt={'schema':'helper-decomposition-run-v1','finished_utc':now(),'elapsed_seconds':time.monotonic()-started,'source_denominator':425,'fixed_small_cohort_count':14,'eligible_count':13,'condition_context_without_selection':selection['condition_context_without_selection'],'rows':rows,
        'global_stop':stop,'stop_reasons':reasons,'root_authorization':decision,'parent_aborted':True,'unknown_is_negative':False,'native_runs':0,'full_reset_uses':0,
        'direct_reference_objective':'strict_GR1_on_actual_saved_transformed_arena','compared_with_native_4fp_region':False,'released_10_condition_negative_cases_inference':False,
        'BDD_worker_calls':{'confirmed':sum(v.get('BDD_worker_started') is True for v in rows),'uncertain':sum(v.get('BDD_worker_started') is None for v in rows)}}
    save(B/'RUN_RECEIPT.json',receipt);save(B/'RESULT_FILES.json',{'files':[pin(p) for p in sorted(B.rglob('*')) if p.is_file() and p.name!='RESULT_FILES.json']});print(json.dumps({'global_stop':stop,'BDD_worker_calls':receipt['BDD_worker_calls']}))

def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('select','prepare','preflight','run'));p.add_argument('--deadline-utc');args=p.parse_args()
    if args.mode=='select':require(not (B/'SELECTION.json').exists(),'No selection overwrite');save(B/'SELECTION.json',select());print('Selected closed fixed cohort; corpus BDD=0');return
    if args.mode=='prepare':prepare();return
    frozen=read(B/'FROZEN.json');verify(frozen['files'])
    if args.mode=='preflight':print(json.dumps({'status':'PASS_SOURCE_FREEZE','corpus_BDD_computations':0,'native_runs':0}));return
    require(args.deadline_utc is not None,'Root-specified deadline required');run(args.deadline_utc)
if __name__=='__main__':main()
