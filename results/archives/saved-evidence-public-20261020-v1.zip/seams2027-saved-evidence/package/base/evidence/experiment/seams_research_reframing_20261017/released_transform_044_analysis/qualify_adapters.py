"""Synthetic semantic-import and actual-versus-literal controls; corpus computations0."""
from pathlib import Path
from types import SimpleNamespace
from tempfile import TemporaryDirectory
from copy import deepcopy
import ast,gzip,json,sys
sys.dont_write_bytecode=True
from evidence import B,C,H,M,L,S,read,save,pin,verify,require,now
from decomposition import BDD,count,digest,solve,pair_module,frozen,build,admitted_pair
from imports import import_loss_payload,load_loss,load_original_regions,NAMES
from regions import add_references,literal_module

def qualify():
    require(not (B/'FROZEN.json').exists() and not (B/'ADAPTER_QUALIFICATION.json').exists(),'Qualify before freeze without overwrite')
    tests=[]
    def test(name,fn):fn();tests.append({'name':name,'status':'PASS'})
    def rejects(fn):
        try:fn()
        except (ValueError,KeyError,TypeError):return
        raise AssertionError('Malformed synthetic evidence accepted')
    def reuse():
        require((B/'import_original.py').read_bytes()==(C/'import_original.py').read_bytes() and (B/'qualify_math.py').read_bytes()==(C/'qualify_math.py').read_bytes(),'Exact qualified importer and finite oracle controls')
        require(solve is frozen.solve and solve.__code__.co_filename==str(C/'decomposition.py') and build is admitted_pair.build and build.__code__.co_filename==str(M/'map_pair.py'),'Exact qualified solver plus already-qualified larger-cap builder')
        require(literal_module.compute.__code__.co_filename==str(L/'loss.py'),'Exact qualified literal compute function')
        def fns(path):return {x.name:ast.dump(x,include_attributes=False) for x in ast.parse(path.read_text()).body if isinstance(x,ast.FunctionDef)}
        old=fns(C/'measure.py');new=fns(B/'reporting.py');require(set(new)=={'decode','summarize','export'} and all(new[k]==old[k] for k in new),'Unchanged reporting function ASTs')
        for directory,names in ((C,('decomposition.py','import_original.py','measure.py','qualify_math.py','MATH_QUALIFICATION.json')),(M,('map_pair.py',)),(L,('loss.py','OFFLINE_QUALIFICATION.json'))):
            prior=read(directory/'FROZEN.json')
            for name in names:require(pin(directory/name) in prior['files'],'Previously frozen exact reused source '+name)
    test('exact_qualified_solver_importer_controls_reporting_and_builder_reuse',reuse)
    def field(name,owner,role,cb,nb,values,codes):
        return {'name':name,'owner':owner,'role':role,'domain_size':len(values),'values':values,'current_bits':cb,'next_bits':nb,'encoding':{v:{'current':{str(k):bool(c[i]) for i,k in enumerate(cb)},'next':{str(k):bool(c[i]) for i,k in enumerate(nb)}} for v,c in zip(values,codes)}}
    sf=[field('mode','ENV','ENV',[0,1],[2,3],['a','b','c'],[(0,0),(1,0),(1,1)]),field('y','SYS','SYS',[4],[5],['f','t'],[(0,),(1,)]),field('memory','SYS','AUX',[6],[7],['f','t'],[(0,),(1,)])]
    df=[field('memory','SYS','AUX',[2],[3],['t','f'],[(0,),(1,)]),field('mode','ENV','ENV',[0,4,6],[1,5,7],['c','a','b'],[(1,1,0),(1,0,1),(0,1,0)]),field('y','SYS','SYS',[8],[9],['t','f'],[(0,),(1,)])]
    sb,db,common=BDD(8),BDD(10),BDD(12)
    def literal(b,fields,name,value,nxt=False):return b.cube({int(k):v for k,v in next(f for f in fields if f['name']==name)['encoding'][value]['next' if nxt else 'current'].items()})
    def domain(b,fields):return b.conj(*(b.disj(*(literal(b,fields,f['name'],v) for v in f['values'])) for f in fields))
    def roots_for(b,fields):
        w=domain(b,fields);c=b.conj(w,b.disj(literal(b,fields,'mode','b'),literal(b,fields,'memory','f')));wc=b.conj(w,literal(b,fields,'mode','b'),literal(b,fields,'memory','f'))
        reachable=b.conj(w,b.disj(literal(b,fields,'mode','a'),literal(b,fields,'y','t')));loss=b.conj(w,b.neg(wc))
        return dict(W=w,C=c,W_C=wc,W_minus_C=b.conj(w,b.neg(c)),W_minus_W_C=loss,delayed_loss=b.conj(loss,c),original_reachable=reachable,original_reachable_loss=b.conj(reachable,loss))
    current=[v for f in df for v in f['current_bits']];scur=[v for f in sf for v in f['current_bits']]
    original=SimpleNamespace(b=db,by_name={f['name']:f for f in df},fields=df,carrier=12,current=current,domain=domain(db,df),literal=lambda n,v,p=False:literal(db,df,n,v,p))
    pair={'common':common,'original':original};sr=roots_for(sb,sf);expected=roots_for(common,df)
    payload={'schema':'complete-semantic-preservation-loss-robdd-v1','variable_count':8,'canonical_variable_order':list(range(8)),'fields':sf,'roots':sr,'nodes':[[u,*row] for u,row in enumerate(sb.nodes) if u>1],
        'current_bits':scur,'ENV_current_bits':[0,1],'SYS_and_AUX_current_bits':[4,6],'ENV_next_bits':[2,3],'SYS_and_AUX_next_bits':[5,7]}
    proof={'counts':{name:count(sb,u,scur) for name,u in sr.items()},'canonical_sha256':{name:digest(sb,u) for name,u in sr.items()}}
    def loss_positive():
        got,audit=import_loss_payload(pair,payload,proof);require(got==expected and audit['all_original_AUX_retained'] is True,'All eight named roots lifted semantically across width/order/code/AUX changes')
    test('all_named_literal_roots_semantic_lift_with_ternary_AUX_and_recoding',loss_positive)
    for kind in ('wrong_digest','wrong_count','bool_count','omitted_AUX','wrong_ENV_roster','wrong_SYS_roster','wrong_schema'):
        def corrupt(kind=kind):
            x,p=deepcopy(payload),deepcopy(proof)
            if kind=='wrong_digest':p['canonical_sha256']['W_C']='0'*64
            if kind=='wrong_count':p['counts']['W_C']+=1
            if kind=='bool_count':p['counts']['W_C']=True
            if kind=='omitted_AUX':x['fields']=x['fields'][:-1]
            if kind=='wrong_ENV_roster':x['ENV_current_bits'].append(4)
            if kind=='wrong_SYS_roster':x['SYS_and_AUX_next_bits']=[5]
            if kind=='wrong_schema':x['schema']='unknown'
            rejects(lambda:import_loss_payload(pair,x,p))
        test('literal_import_reject_'+kind,corrupt)
    independent_payload={**payload,'schema':'independent-canonical-robdd-region-set-v1','roots':{'W':sr['W'],'reachable':sr['original_reachable']}}
    independent_proof={'counts':{'W':proof['counts']['W'],'reachable':proof['counts']['original_reachable']},'comparisons':{name:{'equal':True,'independent_count':proof['counts'][source],'canonical_sha256':proof['canonical_sha256'][source]} for name,source in [('W','W'),('reachable','original_reachable')]}}
    def independent(kind):
        pr=deepcopy(independent_proof)
        if kind=='wrong_reachable_digest':pr['comparisons']['reachable']['canonical_sha256']='0'*64
        if kind=='uncertified_reachable':pr['comparisons']['reachable']['equal']=False
        if kind=='bool_count':pr['counts']['reachable']=True
        with TemporaryDirectory(prefix='analysis044_import_mock_') as tmp:
            path=Path(tmp)/'regions.json.gz'
            with gzip.open(path,'wt') as f:json.dump(independent_payload,f)
            if kind=='pass':
                got,audit=load_original_regions(pair,path,pr);require(got=={'W':expected['W'],'reachable':expected['original_reachable']} and audit['all_original_AUX_retained'] is True,'Independent W/reachable exact semantic import')
                with gzip.open(path,'wt') as f:json.dump(payload,f)
                got,_=load_loss(pair,path,proof);require(got==expected,'Compressed named-root loader exact semantics')
            else:rejects(lambda:load_original_regions(pair,path,pr))
    for kind in ('pass','wrong_reachable_digest','uncertified_reachable','bool_count'):test('independent_W_reachable_loader_'+kind,lambda kind=kind:independent(kind))
    def different_actual_literal():
        b=BDD(4);y,yp,h,hp=(b.var(i) for i in range(4));je=b.disj(b.neg(h),hp)
        js=b.ite(h,b.ite(hp,b.conj(y,yp),1),b.ite(hp,b.neg(yp),1))
        args=dict(b=b,q=1,de=1,den=1,dsn=1,current=[0],en=[],sn=[1],prime={0:1},oe=1,os=1,oa=[],og=[],te=1,ts=1,je=je,js=js,ja=[b.neg(h)],jg=[],jte=b.neg(h),jts=1,h=2,hp=3)
        out=solve(**args);prior,_,_=literal_module.compute(b,1,1,1,1,1,1,[0],[],[1],{0:1},[],[],1,1,1,1)
        info=add_references(out,args,{'W':1,'reachable':1},{name:prior[name] for name in NAMES})
        require(out['roots']['U']==y and out['roots']['F']==out['roots']['W_F']==out['roots']['W_direct_0']==0 and out['roots']['W_direct_1']==y,'Actual arbitrary trap/flip equations retained')
        require(out['roots']['fresh_literal_W_C']==1 and out['roots']['actual_W_F_xor_literal_W_C']==1 and out['checks']['actual_W_F_equals_prior_literal_W_C'] is False,'Actual WF cannot silently become literal WC')
        require(out['quant']['W_predicted']['value'] is False and out['quant']['literal_W_C']['value'] is True and out['roots']['W_loss']==out['roots']['actual_original_reachable_loss']==1 and out['roots']['delayed_loss']==0,'Separate initial and exact/reachable loss observations')
        require(info['recomputation_is_new_independent_case'] is False,'Fresh literal check not new evidence count')
        altered={name:prior[name] for name in NAMES};altered['W_C']=0
        rejects(lambda:add_references(solve(**args),args,{'W':1,'reachable':1},altered))
    test('actual_WF_differs_from_literal_WC_and_initializer_with_strict_separate_authority',different_actual_literal)
    for p in B.glob('*.py'):ast.parse(p.read_text())
    source=[pin(B/n) for n in ('evidence.py','decomposition.py','import_original.py','imports.py','regions.py','reporting.py','measure.py','run.py','qualify_adapters.py')]+[pin(C/n) for n in ('FROZEN.json','decomposition.py','import_original.py','measure.py','qualify_math.py','MATH_QUALIFICATION.json')]+[pin(M/'map_pair.py'),pin(M/'FROZEN.json'),pin(L/'loss.py'),pin(L/'FROZEN.json')]
    save(B/'REUSE_AUDIT.json',{'schema':'fixed044-analysis-reuse-audit-v1','status':'PASS','created_utc':now(),'source_pins':source,
        'decomposition_solve_and_lifted_inputs':'Unchanged function objects loaded from frozen helper_decomposition_public/decomposition.py',
        'build':'Unchanged already qualified/frozen released_transform_044_main/map_pair.py; exactly two inherited carrier admission cap changes from original helper map',
        'original_import_and_finite_oracle_controls':'Exact byte copies of previously frozen sources',
        'literal_compute':'Unchanged function object from frozen preservation_loss_public/loss.py; representation/correspondence crosscheck only',
        'reporting':'Exact decode/summarize/export function ASTs from frozen helper decomposition measure.py','new_adapters':['imports.py named region loading','regions.py separate exact loss/reference correspondence','fixed one-case authority/runner'],
        'corpus_BDD_computations':0,'native_runs':0})
    save(B/'ADAPTER_QUALIFICATION.json',{'schema':'fixed044-analysis-adapter-qualification-v1','status':'PASS','created_utc':now(),'count':len(tests),'tests':tests,'source_pins':source,'corpus_BDD_computations':0,'native_runs':0,'actual_child_processes':0})
    print(json.dumps({'status':'PASS','checks':len(tests),'corpus_BDD_computations':0,'native_runs':0}))

if __name__=='__main__':qualify()
