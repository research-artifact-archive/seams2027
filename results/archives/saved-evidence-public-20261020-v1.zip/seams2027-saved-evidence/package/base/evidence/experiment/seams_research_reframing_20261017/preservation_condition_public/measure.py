"""One root-authorized bounded symbolic consequence calculation; no native solver."""
import gzip,json,signal,sys,time,traceback
from pathlib import Path
sys.dont_write_bytecode=True
from evidence import B,N,read,save,pin,verify,require,now
from condition import engine,ResourceRefusal,compute,load_w,summarize

def authorization():
    decision_pin=pin(B/'ROOT_START_DECISION.json');decision=read(decision_pin['path'])
    require(decision.get('start_authorized') is True and decision.get('freeze')==pin(B/'FROZEN.json'),'Exact root review authorization required')
    verify([decision_pin]);return decision_pin

def export(path,model,roots):
    seen=set();todo=list(roots.values())
    while todo:
        u=todo.pop()
        if u<2 or u in seen:continue
        seen.add(u);todo.extend(model.b.nodes[u][1:])
    value={'schema':'complete-semantic-preservation-robdd-set-v1','variable_count':model.b.n,
        'canonical_variable_order':list(range(model.b.n)),'fields':model.fields,
        'current_bits':model.current,'ENV_next_bits':model.en,'SYS_and_AUX_next_bits':model.sn,
        'roots':roots,'nodes':[[u,*model.b.nodes[u]] for u in sorted(seen)]}
    with gzip.GzipFile(filename=str(path),mode='wb',mtime=0) as f:
        f.write(json.dumps(value,ensure_ascii=False,separators=(',',':')).encode())

def main(ident):
    decision_pin=authorization();freeze=read(B/'FROZEN.json');selection=read(B/'SELECTION.json')
    row=next(r for r in selection['rows'] if r['id']==ident and r['eligible'])
    directory=B/'runs'/ident;directory.mkdir(parents=True,exist_ok=True)
    require(not (directory/'RESULT.json').exists(),'No duplicate case calculation')
    refs=freeze['code_files']+row['input_pins']+[pin(B/'FROZEN.json'),pin(B/'SELECTION.json'),decision_pin]
    result={'schema':'preservation-condition-case-v1','id':ident,'status':'UNKNOWN_INCOMPLETE','created_utc':now(),'parent_aborted':True,
        'root_authorization':decision_pin,
        'native_runs':0,'full_reset_uses':0,'initial_feasibility_conclusion':None,
        'released_route_loss_conclusion':None,'W_minus_C_is_exact_lost_region':False}
    start=time.monotonic();model=None
    def timeout(*_):raise TimeoutError('60 second symbolic case budget')
    try:
        signal.signal(signal.SIGALRM,timeout);signal.alarm(60)
        verify(refs);proof=read(row['proof']['path']);metadata=read(row['model']['path'])
        model=engine.Model(N/'runs'/ident,metadata)
        w=load_w(model,row['independent_regions']['path'],proof)
        roots=compute(model.b,model.q,model.forms['rhoS'],model.den,model.dsn,model.current,model.en,model.sn,w)
        result.update(summarize(model,roots));export(directory/'FUNCTIONS.json.gz',model,roots)
        result.update(functions=pin(directory/'FUNCTIONS.json.gz'),carrier=model.carrier,
            variable_count=model.b.n,quantifier='forall typed ENV_next exists typed SYS_next and all AUX_next rhoS',
            interpretation='Exact complete-semantic preservation condition W subset C; W_minus_C is only the immediate totality violation subset.',
            input_pins=refs,independent_W_certificate=row['proof'],independent_process=row['process'])
        verify(refs);result['status']='PASS'
    except (TimeoutError,ResourceRefusal,MemoryError) as ex:
        result.update(status='UNKNOWN_RESOURCE',reason=repr(ex))
    except BaseException as ex:
        result.update(status='UNKNOWN_INTEGRITY',reason=repr(ex),traceback=traceback.format_exc())
    finally:
        signal.alarm(0)
        result.update(finished_utc=now(),elapsed_seconds=time.monotonic()-start,
            allocated_BDD_nodes=len(model.b.nodes) if model is not None else None)
        save(directory/'RESULT.json',result)
    print(json.dumps({k:result.get(k) for k in ('id','status','W_subset_C','counts','reason')}),flush=True)

if __name__=='__main__':main(sys.argv[1])
