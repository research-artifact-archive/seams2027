"""One authorized saved-data exact-loss calculation; no native synthesis."""
import json,signal,sys,time,traceback
from pathlib import Path
sys.dont_write_bytecode=True
from evidence import B,N,read,save,pin,verify,require,now
from loss import engine,condition,ResourceRefusal,compute,load_independent,summarize,export,count,root_digest


def authorization():
    p=pin(B/'ROOT_START_DECISION.json');d=read(p['path'])
    require(d.get('start_authorized') is True and d.get('freeze')==pin(B/'FROZEN.json'),'Exact root review authorization required')
    verify([p]);return p


def main(ident):
    decision_pin=authorization();freeze=read(B/'FROZEN.json');selection=read(B/'SELECTION.json')
    row=next(r for r in selection['rows'] if r['id']==ident and r['eligible'])
    directory=B/'runs'/ident;directory.mkdir(parents=True,exist_ok=True)
    require(not (directory/'RESULT.json').exists(),'No duplicate case calculation')
    refs=freeze['code_files']+row['input_pins']+[pin(B/'FROZEN.json'),pin(B/'SELECTION.json'),decision_pin]
    result={'schema':'preservation-loss-case-v1','id':ident,'status':'UNKNOWN_INCOMPLETE','created_utc':now(),
        'parent_aborted':True,'root_authorization':decision_pin,'native_runs':0,'full_reset_uses':0,
        'complete_semantic_literal_only':True,'released_syntactic_loss_conclusion':None,
        'runtime_or_controller_reachability_conclusion':None,'corpus_selection':'ALL_TEN_PREVIOUS_CONDITION_FALSE'}
    start=time.monotonic();model=None
    def timeout(*_):raise TimeoutError('60 second exact-loss case budget')
    try:
        signal.signal(signal.SIGALRM,timeout);signal.alarm(60)
        verify(refs);proof=read(row['proof']['path']);cproof=read(row['condition_proof']['path'])
        model=engine.Model(N/'runs'/ident,read(row['model']['path']))
        old=load_independent(model,row['independent_regions']['path'],proof)
        b=model.b;f=model.forms
        roots,quant,log=compute(b,model.q,model.de,f['rhoE'],f['rhoS'],model.den,model.dsn,
            model.current,model.en,model.sn,model.prime,model.justices['ENV'],model.justices['SYS'],
            f['thetaE'],f['thetaS'],old['W'],old['reachable'])
        for name in ('C','W','W_minus_C'):
            require(count(b,roots[name],model.current)==cproof['counts'][name],'Prior condition count '+name)
            require(root_digest(b,roots[name])==cproof['canonical_sha256'][name],'Prior condition function '+name)
        require(root_digest(b,roots['bad_ENV_next'])==cproof['canonical_sha256']['bad_ENV_next'],'Prior complete totality quantifier function')
        require(roots['W_minus_C']!=0 and cproof['W_subset_C'] is False,'Selected condition-false identity')
        summary=summarize(model,roots,quant)
        require(summary['initial_quantification']['W']==proof['initial_quantification']['W'],'Original initializer agrees with prior independent authority')
        export(directory/'FUNCTIONS.json.gz',model,roots)
        result.update(summary,functions=pin(directory/'FUNCTIONS.json.gz'),fixed_point_iterations=log,
            variable_count=b.n,carrier=model.carrier,input_pins=refs,
            original_independent_proof=row['proof'],original_independent_process=row['process'],
            condition_proof=row['condition_proof'],condition_process=row['condition_process'],
            exact_region_definition='W_C = C intersect Win(original rhoE, C(current) and rhoS and C(next)); all original justices retained',
            initial_quantifier='forall typed original ENV satisfying thetaE exists typed original SYS and every logical AUX satisfying thetaS and region',
            reachable_definition='Existential finite paths from every original thetaE and thetaS joint state using original rhoE and rhoS; not winning-policy or runtime reachability',
            original_reachability_reused_without_new_fixed_point=True,
            compiler_trust_boundary='Original BDDs share the Spectra parser/translator; independent Boolean calculations do not certify the compiler')
        verify(refs);result['status']='PASS'
    except (TimeoutError,ResourceRefusal,MemoryError) as ex:
        result.update(status='UNKNOWN_RESOURCE',reason=repr(ex))
    except BaseException as ex:
        result.update(status='UNKNOWN_INTEGRITY',reason=repr(ex),traceback=traceback.format_exc())
    finally:
        signal.alarm(0)
        result.update(finished_utc=now(),elapsed_seconds=time.monotonic()-start,
            allocated_BDD_nodes=len(model.b.nodes) if model is not None else None)
        save(directory/'RESULT.json',result)
    print(json.dumps({k:result.get(k) for k in ('id','status','initial_verdict_changed','counts','reason')}),flush=True)


if __name__=='__main__':main(sys.argv[1])
