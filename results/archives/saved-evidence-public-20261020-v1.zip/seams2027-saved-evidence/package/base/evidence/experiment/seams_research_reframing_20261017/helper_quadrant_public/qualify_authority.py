"""Mock-only full-driver fault tests. All real process operations forbidden."""
from contextlib import ExitStack,redirect_stdout
from datetime import datetime,timezone,timedelta
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import copy,io,json,os,subprocess,sys,tempfile
sys.dont_write_bytecode=True
from evidence import B,save,pin,require,now
import run as runner
import measure
from map_pair import BDD
from relations import compare

def fixture_summary(helper):
    b=BDD(2 if helper else 0)
    if helper:
        hb,hp=b.var(0),b.var(1);return compare(b,1,1,0,b.disj(b.neg(hb),hp),hb,0,1,(),(),[])[0]
    return compare(b,1,1,1,1,1,None,None,(),(),[])[0]

def run_case(mode):
    with tempfile.TemporaryDirectory(prefix='quadrant-authority-mock-') as tmp:
        folder=Path(tmp);saved={};calls=[];verifies=[]
        def fakepin(p):return {'path':str(Path(p).resolve()),'bytes':1,'sha256':'a'*64}
        decision=fakepin(folder/'ROOT_START_DECISION.json');eligible=[f'mock{i:03d}' for i in range(13)]
        allrows=[{'id':i,'eligible':True,'in_fixed_small_cohort':True,'prior_status':'PENDING_RELATION_AUDIT','input_pins':[],
            'original_model':fakepin(folder/(i+'.original')),'job_model':fakepin(folder/(i+'.job')),'native_result':fakepin(folder/(i+'.native')),'parent_receipt':fakepin(folder/(i+'.parent'))} for i in eligible]
        allrows.append({'id':'resource-original','eligible':False,'in_fixed_small_cohort':True,'prior_status':'UNKNOWN_NATIVE_RESOURCE'})
        allrows += [{'id':f'outside{i:03d}','eligible':False,'in_fixed_small_cohort':False,'prior_status':'UNKNOWN_OUTSIDE_PRESPECIFIED_SMALL_COHORT'} for i in range(411)]
        rows={r['id']:r for r in allrows};selection={'source_denominator':425,'fixed_small_cohort_count':14,'eligible_count':13,'eligible_ids':eligible,'rows':allrows,'condition_context_without_selection':{'selection_uses_condition_truth':False}}
        freeze={'files':[],'code_files':[],'python':fakepin(Path(sys.executable).resolve())};results={}
        def read(p):
            p=Path(p)
            if p.name=='FROZEN.json':return copy.deepcopy(freeze)
            if p.name=='SELECTION.json':return copy.deepcopy(selection)
            if p.name=='RESULT.json':return copy.deepcopy(results[p.parent.name])
            raise AssertionError('Unplanned mock read '+str(p))
        def verify(refs):
            verifies.append(refs)
            if mode=='source_drift_before_spawn' and len(verifies)==2:raise ValueError('Controlled frozen source drift')
        def execute(argv,process_folder,*args,**kwargs):
            ident=argv[-1];calls.append(ident);row=rows[ident]
            if mode=='wrapper_exception':raise RuntimeError('Controlled wrapper exception before return')
            if mode=='resource_local':return {'status':'UNKNOWN_RESOURCE','process_started':True,'exit_code':-15}
            if mode!='missing_result':
                result_path=Path(process_folder).parent/'RESULT.json';result_path.parent.mkdir(parents=True);result_path.write_text('{}')
            result={'schema':'helper-quadrant-case-v1','id':ident,'status':'PASS','root_authorization':decision,'parent_aborted':True,
                'native_runs':0,'full_reset_uses':0,'winning_regions_computed':False,'released_route_loss_conclusion':None,'AUX_causal_attribution':'UNKNOWN_NO_PER_CONSTRAINT_SEMANTIC_PROOF',
                **{k:row[k] for k in ('original_model','job_model','native_result')},'enclosing_native_parent':row['parent_receipt'],
                'input_pins':[fakepin(folder/'FROZEN.json'),fakepin(folder/'SELECTION.json'),decision],
                'comparison':fixture_summary(mode=='valid_helper'),'supplemental_full_current_checks':{'all_equal':True},'all_original_AUX_retained':True,'typed_original_state_carrier':1,'functions':fakepin(folder/(ident+'.functions'))}
            if mode=='unknown_child_status':result['status']='UNEXPECTED_SUCCESS'
            if mode=='child_integrity':result['status']='UNKNOWN_INTEGRITY'
            if mode=='malformed_pass':result.pop('comparison')
            if mode=='wrong_authorization':result['root_authorization']=fakepin(folder/'wrong-decision')
            if mode=='wrong_input_pins':result['input_pins']=[]
            if mode=='wrong_count':result['comparison']['identity']['ENV_identity']['counts']['difference']=1
            results[ident]=result
            return {'status':'PROCESS_COMPLETED','process_started':True,'exit_code':7 if mode=='nonzero_exit' else 0}
        fake_spec=SimpleNamespace(loader=SimpleNamespace(exec_module=lambda m:None))
        with ExitStack() as stack:
            stack.enter_context(patch.object(runner,'B',folder));stack.enter_context(patch.object(runner,'pin',side_effect=fakepin));stack.enter_context(patch.object(runner,'read',side_effect=read));stack.enter_context(patch.object(runner,'verify',side_effect=verify))
            stack.enter_context(patch.object(runner,'save',side_effect=lambda p,x:saved.__setitem__(Path(p).name,copy.deepcopy(x))))
            stack.enter_context(patch.dict(sys.modules,{'measure':SimpleNamespace(authorization=lambda:decision)}))
            stack.enter_context(patch.object(runner.importlib.util,'spec_from_file_location',return_value=fake_spec));stack.enter_context(patch.object(runner.importlib.util,'module_from_spec',return_value=SimpleNamespace(run_bounded=execute)))
            for obj,name in ((subprocess,'Popen'),(os,'kill'),(os,'killpg'),(os,'wait4')):stack.enter_context(patch.object(obj,name,side_effect=AssertionError('Actual process operation forbidden')))
            deadline=datetime.now(timezone.utc)+timedelta(seconds=20 if mode=='deadline_reserve' else 600)
            with redirect_stdout(io.StringIO()):runner.run(deadline.isoformat())
        receipt=saved['RUN_RECEIPT.json'];out=receipt['rows'];require(len(out)==425 and out[13]['status']=='UNKNOWN_NATIVE_RESOURCE' and all(r['status']=='UNKNOWN_OUTSIDE_PRESPECIFIED_SMALL_COHORT' for r in out[14:]),'Fixed 425/14/13 row accounting')
        if mode in ('valid_nohelper','valid_helper','resource_local'):
            require(not receipt['global_stop'] and len(calls)==13 and all(r['status']==('UNKNOWN_RESOURCE' if mode=='resource_local' else 'PASS') for r in out[:13]),'Legitimate case-local continuation')
        elif mode=='deadline_reserve':require(not receipt['global_stop'] and not calls and all(r['status']=='UNKNOWN_NOT_ATTEMPTED' for r in out[:13]),'Deadline reserve refusal')
        elif mode=='source_drift_before_spawn':require(receipt['global_stop'] and not calls and all(r['BDD_worker_started'] is False for r in out[:13]),'Source drift before any spawn')
        else:
            require(receipt['global_stop'] and len(calls)==1 and out[0]['status']!='PASS' and all(r['status']=='UNKNOWN_NOT_ATTEMPTED' for r in out[1:13]),'Unexpected child result must stop globally')
            if mode=='wrapper_exception':require(out[0]['status']=='UNKNOWN_RUNNER_FAILURE' and receipt['BDD_worker_calls']=={'confirmed':0,'uncertain':1},'Uncertain attempt accounting')
        require(receipt['root_authorization']==decision,'Start decision missing from receipt')
        return {'name':mode,'pass':True,'global_stop':receipt['global_stop'],'mock_child_calls':len(calls),'first_status':out[0]['status'],'BDD_worker_calls':receipt['BDD_worker_calls']}

def authorization_negative():
    with tempfile.TemporaryDirectory(prefix='quadrant-gate-mock-') as tmp:
        folder=Path(tmp);(folder/'FROZEN.json').write_text('{}');correct=pin(folder/'FROZEN.json')
        for decision in ({'start_authorized':False,'freeze':correct},{'start_authorized':True,'freeze':{'path':'wrong','bytes':0,'sha256':'0'*64}}):
            (folder/'ROOT_START_DECISION.json').write_text(json.dumps(decision))
            with patch.object(measure,'B',folder):
                try:measure.authorization()
                except ValueError:pass
                else:raise AssertionError('Unreviewed start authorized')
        (folder/'ROOT_START_DECISION.json').write_text(json.dumps({'start_authorized':True,'freeze':correct}))
        with patch.object(measure,'B',folder):require(measure.authorization()==pin(folder/'ROOT_START_DECISION.json'),'Valid gate exact decision pin')
    return {'name':'false_or_wrong_freeze_authorization_rejected','pass':True}

require(not (B/'FROZEN.json').exists() and not (B/'RUN_STARTED.json').exists(),'Qualifications before freeze only')
results=[]
for mode in ('valid_nohelper','valid_helper','resource_local','deadline_reserve','source_drift_before_spawn','nonzero_exit','missing_result','unknown_child_status','malformed_pass','wrong_authorization','wrong_input_pins','wrong_count','child_integrity','wrapper_exception'):
    try:results.append(run_case(mode))
    except Exception as error:results.append({'name':mode,'pass':False,'error':repr(error)})
try:results.append(authorization_negative())
except Exception as error:results.append({'name':'authorization_negative','pass':False,'error':repr(error)})
report={'schema':'helper-quadrant-authority-qualification-v1','created_utc':now(),'status':'PASS' if all(r['pass'] for r in results) else 'FAIL','passed':sum(r['pass'] for r in results),'total':len(results),'rows':results,
    'source_pins':[pin(B/n) for n in ('evidence.py','map_pair.py','relations.py','measure.py','run.py','qualify_authority.py','PROTOCOL_JA.txt')],
    'actual_child_processes':0,'actual_signals':0,'corpus_BDD_computations':0,'native_runs':0,'full_reset_uses':0}
save(B/'AUTHORITY_QUALIFICATION.json',report);print(json.dumps({'status':report['status'],'passed':report['passed'],'total':report['total'],'failures':[r for r in results if not r['pass']]},indent=2));require(report['status']=='PASS','Authority qualification failed')
