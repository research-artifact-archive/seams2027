"""Freeze protocol, implementation, source population, and all finite PASS gates."""
from datetime import datetime, timezone
from pathlib import Path
import sys
sys.dont_write_bytecode = True
from check_case import HERE, BASE, CORPUS, read, save, pin, require


def main():
    require(not (HERE / 'FROZEN.json').exists(), 'freeze already exists')
    checker = sorted(HERE.glob('*.py')) + sorted(HERE.glob('*_JA.txt')) + sorted((HERE / 'vendor').glob('*.py'))
    roster = read(CORPUS / 'ROSTER.json')
    rows = sorted(roster['unique_inputs'], key=lambda x: x['id'])
    require(len(rows) == 425 and len({r['id'] for r in rows}) == 425, 'fixed425 population')
    finite_root = BASE / 'kind_corpus_independent'
    finite_inputs = {}
    for p in sorted((finite_root / 'runs').glob('*/RESULT.json')):
        if read(p).get('status') == 'PASS':
            finite_inputs[p.parent.name] = [pin(p.parent / n) for n in ('RESULT.json', 'REGIONS.json', 'TYPED_MODEL.json')]
    require(len(finite_inputs) == 12, 'expected full finite PASS12 qualification population')
    origin = BASE.parent / 'seams_establishment_20261013/k7_controller_independent_preparation/bdd_core.py'
    finite_origin = finite_root / 'vendor/finite_sets_v1.py'
    require(origin.read_bytes() == (HERE / 'vendor/bdd_core.py').read_bytes(), 'ROBDD vendor not identical')
    require(finite_origin.read_bytes() == (HERE / 'vendor/finite_sets_v1.py').read_bytes(), 'finite oracle vendor not identical')
    deps = [origin, finite_origin, finite_root / 'check_case.py', finite_root / 'FREEZE.json',
            CORPUS / 'ROSTER.json', CORPUS / 'FROZEN.json', CORPUS / 'RUN_RECEIPT.json',
            CORPUS / 'src/PublicCorpusProbe.java', BASE / 'kind_corpus_rle/FROZEN.json']
    sources = [pin(CORPUS / 'original' / row['path']) for row in roster['all_paths']]
    for row, p in zip(roster['all_paths'], sources):
        require(p['sha256'] == row['sha256'] and p['bytes'] == row['bytes'], 'source changed before freeze')
    archive = read(finite_root / 'FREEZE.json')['public_archive']
    require(pin(archive['path']) == archive, 'public archive changed')
    data = {'created_utc': datetime.now(timezone.utc).isoformat(), 'deadline_utc': '2026-10-16T23:00:00+00:00',
            'checker_files': [pin(p) for p in checker], 'dependency_files': [pin(p) for p in deps],
            'public_archive': archive, 'source_files': sources, 'roster': rows,
            'finite_PASS_inputs': finite_inputs,
            'preserved_prior_freezes': [pin(p) for p in sorted((HERE / 'attempts').glob('*/FROZEN.json'))],
            'limits': {'variables': 64, 'BDD_nodes_including_terminals': 500000, 'saved_BDD_bytes': 8388608,
                       'seconds_per_case_process': 60, 'active_BDD_workers': 1},
            'native_runs': 0, 'full_resets': 0}
    save(HERE / 'FROZEN.json', data)
    print({'frozen': str(HERE / 'FROZEN.json'), 'checker_files': len(checker), 'source_paths': len(sources),
           'roster': len(rows), 'finite_PASS_cases': len(finite_inputs)})


if __name__ == '__main__':
    main()
