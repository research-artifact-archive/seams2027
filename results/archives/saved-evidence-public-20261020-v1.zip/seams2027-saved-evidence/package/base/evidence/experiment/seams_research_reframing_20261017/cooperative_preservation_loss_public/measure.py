"""One root-authorized saved K/loss intersection; no new fixed points/native."""
import json,signal,sys,time,traceback
sys.dont_write_bytecode=True
from evidence import B,N,read,save,pin,verify,require,now
from intersection import engine,ResourceRefusal,load_k,load_loss,compute,summarize,export,count,root_digest


def authorization():
    p=pin(B/'ROOT_START_DECISION.json');d=read(p['path'])
    require(d.get('start_authorized') is True and d.get('freeze')==pin(B/'FROZEN.json'),'Exact root review authorization required')
    verify([p]);return p


def main(ident):
    decision_pin=authorization();freeze=read(B/'FROZEN.json');selection=read(B/'SELECTION.json')
    row=next(r for r in selection['rows'] if r['id']==ident and r['eligible'])
    directory=B/'runs'/ident;directory.mkdir(parents=True,exist_ok=True)
    require(not (directory/'RESULT.json').exists(),'No duplicate case calculation')
    refs=freeze['code_files']+row['input_pins']+[pin(B/'FROZEN.json'),pin(B/'SELECTION.json'),decision_pin]
    result={'schema':'cooperative-preservation-loss-case-v1','id':ident,'status':'UNKNOWN_INCOMPLETE','created_utc':now(),
        'parent_aborted':True,'root_authorization':decision_pin,'native_runs':0,'new_fixed_point_runs':0,'full_reset_uses':0,
        'complete_semantic_literal_only':True,'released_syntactic_loss_conclusion':None,
        'runtime_or_controller_reachability_conclusion':None,'cooperative_initializer_false_rejection_conclusion':None,
        'corpus_selection':'ALL_NINE_PRIOR_EXACT_LOSS_PASS'}
    started=time.monotonic();model=None
    def timeout(*_):raise TimeoutError('60 second saved-intersection case budget')
    try:
        signal.signal(signal.SIGALRM,timeout);signal.alarm(60)
        verify(refs);proof=read(row['proof']['path']);loss_proof=read(row['loss_proof']['path'])
        model=engine.Model(N/'runs'/ident,read(row['model']['path']))
        k=load_k(model,row['independent_regions']['path'],proof)
        old=load_loss(model,row['loss_functions']['path'],loss_proof)
        roots=compute(model.b,model.q,model.current,k,old['W_minus_W_C'],old['original_reachable'])
        summary=summarize(model,roots)
        require(summary['counts']['K']==proof['counts']['K'],'Original canonical K count retained')
        require(summary['counts']['exact_loss']==loss_proof['counts']['W_minus_W_C'],'Exact loss count retained')
        require(summary['counts']['original_reachable']==loss_proof['counts']['original_reachable'],'Original reachable count retained')
        export(directory/'FUNCTIONS.json.gz',model,roots)
        result.update(summary,functions=pin(directory/'FUNCTIONS.json.gz'),input_pins=refs,
            variable_count=model.b.n,carrier=model.carrier,original_independent_proof=row['proof'],original_independent_process=row['process'],
            exact_loss_proof=row['loss_proof'],exact_loss_process=row['loss_process'],
            original_K_initial_quantification=proof['initial_quantification']['K'],original_K_initial_recomputed=False,
            intersection_definition='K intersect (W minus W_C), using saved authoritative functions in the complete common typed encoding',
            reachable_definition='Original existential finite-path reachability intersect K intersect (W minus W_C); not winning-policy or runtime reachability',
            compiler_trust_boundary='Shared Spectra parser/translator; no independent source compiler, strategy extraction, or new fixed-point calculation')
        verify(refs);result['status']='PASS'
    except (TimeoutError,ResourceRefusal,MemoryError) as ex:result.update(status='UNKNOWN_RESOURCE',reason=repr(ex))
    except BaseException as ex:result.update(status='UNKNOWN_INTEGRITY',reason=repr(ex),traceback=traceback.format_exc())
    finally:
        signal.alarm(0)
        result.update(finished_utc=now(),elapsed_seconds=time.monotonic()-started,allocated_BDD_nodes=len(model.b.nodes) if model else None)
        save(directory/'RESULT.json',result)
    print(json.dumps({k:result.get(k) for k in ('id','status','counts','reason')}),flush=True)


if __name__=='__main__':main(sys.argv[1])
