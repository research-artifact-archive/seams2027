"""Exhaustive small truth arenas, typed masks, and adversarial admission tests."""
import copy,gzip,hashlib,importlib.util,itertools,json,signal,sys,tempfile
from pathlib import Path
from datetime import datetime,timedelta,timezone
from unittest.mock import patch
from types import SimpleNamespace
sys.dont_write_bytecode=True
from evidence import B,read,save,pin,require,now
from adapter import BDD,checker,compute,count,digest,summarize,import_complete_k,export

tests=[];truth_arenas=0;parent_mock_runs=0
spec=importlib.util.spec_from_file_location("repair_condition_qualification_runner",B/"run.py")
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
def test(name,fn):
    try:fn();tests.append({'name':name,'pass':True})
    except Exception as ex:tests.append({'name':name,'pass':False,'error':repr(ex)})
def rejects(fn):
    try:fn()
    except (ValueError,KeyError,TypeError):return
    raise AssertionError('Expected invalid input rejection')
def bits(variables,value):return {v:bool(value>>i&1) for i,v in enumerate(variables)}

def exhaustive_binary():
    global truth_arenas
    triples=list(itertools.product(range(2),repeat=3))
    for mask in range(1<<len(triples)):
        b=BDD(3);relation={t for i,t in enumerate(triples) if mask>>i&1}
        rho=b.disj(*(b.cube({0:bool(s),1:bool(e),2:bool(y)}) for s,e,y in relation))
        expected={s for s in range(2) if all(any((s,e,y) in relation for y in range(2)) for e in range(2))}
        for wm in range(4):
            selected={s for s in range(2) if wm>>s&1};w=b.disj(*(b.cube({0:bool(s)}) for s in selected))
            result=compute(b,1,rho,1,1,(0,),(1,),(2,),w)
            require({s for s in range(2) if b.evaluate(result['C'],{0:bool(s)})}==expected,'Exhaustive quantifier mismatch')
            require(count(b,result['K_minus_C'],(0,))==len(selected-expected),'Exhaustive W difference mismatch')
        truth_arenas+=1
test('all_256_binary_safety_relations_and_all_4_K_sets',exhaustive_binary)

def exhaustive_typed_masks():
    global truth_arenas
    pairs=list(itertools.product(range(3),repeat=2))
    for mask in range(1<<len(pairs)):
        b=BDD(4);den=b.disj(*(b.cube(bits((0,1),e)) for e in range(3)));dsn=b.disj(*(b.cube(bits((2,3),y)) for y in range(3)))
        relation={t for i,t in enumerate(pairs) if mask>>i&1}
        legal=b.disj(*(b.cube({**bits((0,1),e),**bits((2,3),y)}) for e,y in relation))
        expected=all(any((e,y) in relation for y in range(3)) for e in range(3))
        for garbage in (0,b.cube(bits((2,3),3))):
            result=compute(b,1,b.disj(legal,garbage),den,dsn,(),(0,1),(2,3),1)
            require(bool(result['C'])==expected,'Typed domain quantifier mismatch')
            require(result['K_minus_C']==int(not expected),'Typed domain W difference mismatch')
        truth_arenas+=1
test('all_512_ternary_typed_relations_with_invalid_SYS_encodings',exhaustive_typed_masks)

def quantifier_order():
    b=BDD(2);rho=b.iff(b.var(0),b.var(1))
    c=compute(b,1,rho,1,1,(),(0,),(1,),1)['C']
    require(c==1 and b.exists(b.forall(rho,(0,)),(1,))==0,'forall ENV exists SYS order')
test('ENV_before_SYS_quantifier_order',quantifier_order)
def invalid_env():
    b=BDD(3);den=b.neg(b.conj(b.var(0),b.var(1)));rho=den
    result=compute(b,1,rho,den,1,(),(0,1),(2,),1)
    require(result['C']==1 and b.forall(b.exists(rho,(2,)),(0,1))==0,'Invalid ENV encodings must be masked')
test('invalid_ENV_encoding_is_not_a_missing_response',invalid_env)
def typed_current():
    b=BDD(4);q=b.neg(b.conj(b.var(0),b.var(1)))
    r=compute(b,q,1,1,1,(0,1),(2,),(3,),q)
    require(r['C']==q and count(b,r['C'],(0,1))==3,'C remains inside typed current domain')
test('C_is_masked_to_typed_current_states',typed_current)
def total_not_rhoe_relative():
    b=BDD(2);rho=b.neg(b.var(0));r=compute(b,1,rho,1,1,(),(0,),(1,),1)
    require(r['C']==0,'Complete semantic guard must include an ENV move forbidden by rhoE')
test('complete_ENV_semantics_does_not_filter_by_rhoE',total_not_rhoe_relative)
def empty_owners():
    for en,sn in (((),()),((0,),()),((),(0,))):
        b=BDD(len(en+sn));r=compute(b,1,1,1,1,(),en,sn,0)
        require(r['C']==1 and r['K_minus_C']==0,'Empty owner variables or empty W')
test('empty_owner_bit_rosters_and_empty_K',empty_owners)

def field(name,owner,role,current,nxt):
    return {'name':name,'owner':owner,'role':role,'domain_size':2,'values':['false','true'],
        'current_bits':[current],'next_bits':[nxt],
        'encoding':{v:{'current':{str(current):bool(i)},'next':{str(nxt):bool(i)}} for i,v in enumerate(('false','true'))}}
def witnesses():
    fields=[field('e','ENV','ENV',0,2),field('y','SYS','SYS',1,3),field('memory','SYS','AUX',4,5)]
    for rho_good in (False,True):
        b=BDD(6);rho=b.iff(b.var(3),b.var(2)) if rho_good else b.neg(b.var(2))
        m=SimpleNamespace(b=b,fields=fields,current=[0,1,4],env_next=[2],sys_next=[3,5],domain_sn=1,formulas={'rhoS':rho})
        r=compute(b,1,rho,1,1,m.current,m.env_next,m.sys_next,1);out=summarize(m,r)
        require(out['K_subset_C']==rho_good,'Witness criterion')
        witness=out['C_state_witness'] if rho_good else out['K_minus_C_witness']
        require(set(witness['state'])=={'e','y','memory'},'All typed state and AUX values retained')
        if not rho_good:require(witness['ENV_next']=={'e':'true'} and witness['no_typed_SYS_and_all_AUX_response'],'Bad ENV witness')
    b=BDD(6);rho=b.var(5)
    require(compute(b,1,rho,1,1,(0,1,4),(2,),(3,5),1)['C']==1,'AUX next must be existentially quantified')
test('typed_state_ENV_counterexample_and_existential_all_AUX',witnesses)

def synthetic_context(directory,variant=0):
    def make(name,owner,role,cb,nb,values,codes):
        return {'name':name,'owner':owner,'role':role,'domain_size':len(values),'values':values,'current_bits':cb,'next_bits':nb,
            'encoding':{value:{'current':{str(k):bool(code>>i&1) for i,k in enumerate(cb)},
                'next':{str(k):bool(code>>i&1) for i,k in enumerate(nb)}} for value,code in zip(values,codes)}}
    # Both semantic values and arbitrary native bit placements are exercised.
    if variant==0:
        fields=[make('e','ENV','ENV',[0],[1],['false','true'],[0,1]),make('memory','SYS','AUX',[4,2],[5,3],['A','B','C'],[2,0,1])]
    else:
        fields=[make('memory','SYS','AUX',[0,2],[1,3],['A','B','C'],[1,3,0]),make('e','ENV','ENV',[4],[5],['false','true'],[1,0])]
    identity={'fixture_id':'synthetic','case_id':'synthetic','variant':'test'}
    p={**identity,'source':{'sha256':'0'*64,'bytes':0},'public_ENV':['e'],'public_SYS':[],
        'expected_fields_in_native_order':[{'name':f['name'],'owner':f['owner'],'role':f['role'],'domain':f['values']} for f in fields],
        'formulas':{'thetaE':True,'thetaS':True,'rhoE':True,'rhoS':['or',*(["eq","memory",v,True] for v in ['A','B','C'])]},
        'justices':{'ENV':[],'SYS':[]}}
    m={**identity,'schema':'k7-native-model-export-v1','bdd_variable_count':6,'bdd_variable_order':list(range(6)),
        'fields':fields,'all_current_bits':[k for f in fields for k in f['current_bits']],
        'all_next_bits':[k for f in fields for k in f['next_bits']],'public_fields':{'ENV':['e'],'SYS':[]},'input':p['source']}
    inventory={owner:{'constraints':[],'patterns':[],'variables':[{'name':'e'}] if owner=='ENV' else []} for owner in ('ENV','SYS','AUX')}
    m['source_inventory']={'parsed':copy.deepcopy(inventory),'translated':copy.deepcopy(inventory),'native_behaviors':{'env_justice_count':0,'sys_justice_count':0}}
    return checker.Context(directory,p,m)

def save_native(c,root,path):
    seen=set();rows=[]
    def visit(u):
        if u<2 or u in seen:return
        seen.add(u);v,lo,hi=c.b.nodes[u];visit(lo);visit(hi);rows.append(f'{u} {v} {lo} {hi}')
    visit(root)
    raw=(f'0 {root}\n' if root<2 else str(c.b.n)+'\n'+' '.join(map(str,range(c.b.n)))+'\n'+'\n'.join(rows)+'\n').encode()
    path.write_bytes(raw)
    return {'file':path.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
        'support':sorted(c.b.support(root)),'node_count':len(rows),'zero':root==0,'one':root==1}

def source_context_and_import():
    for variant in (0,1):
        with tempfile.TemporaryDirectory(dir=B,prefix='qualification-model-') as td:
            d=Path(td);c=synthetic_context(d,variant);b=c.b
            forms=dict(c.formulas,domain=c.domain,domain_ENV_next=c.domain_en,domain_SYS_next=c.domain_sn)
            c.model['original_bdds']={n:save_native(c,u,d/(n+'.bdd')) for n,u in forms.items()}
            c.model['original_justices']={'ENV':[],'SYS':[]};c.audit_model()
            vals=[{'e':'false','memory':'A'},{'memory':'C','e':'true'}]
            root=b.disj(*(c.cube(v) for v in vals))
            ref=save_native(c,root,d/'final_region.bdd');wv=c.read_bdd(ref,c.current)
            p={'field_order':['memory','e'],'carrier':6,'K':2,'K_valuations':vals}
            require(import_complete_k(c,p,wv,2)==root,'Complete named typed/AUX import under alternative encodings')
            for mutation in ('same_count_wrong_function','missing_AUX','extra_field','bad_value','duplicate','bad_field_roster','wrong_carrier','wrong_K_count','next_support','invalid_current'):
                bad=copy.deepcopy(p);native=wv
                if mutation=='same_count_wrong_function':bad['K_valuations'][0]['memory']='B'
                elif mutation=='missing_AUX':del bad['K_valuations'][0]['memory']
                elif mutation=='extra_field':bad['K_valuations'][0]['unselected']='true'
                elif mutation=='bad_value':bad['K_valuations'][0]['memory']='D'
                elif mutation=='duplicate':bad['K_valuations'][1]=copy.deepcopy(bad['K_valuations'][0])
                elif mutation=='bad_field_roster':bad['field_order']=['e','e']
                elif mutation=='wrong_carrier':bad['carrier']=8
                elif mutation=='wrong_K_count':bad['K']=3
                elif mutation=='next_support':native=b.var(c.env_next[0])
                elif mutation=='invalid_current':native=b.neg(c.domain)
                rejects(lambda:import_complete_k(c,bad,native,2))
            require(import_complete_k(c,{**p,'K':0,'K_valuations':[]},0,0)==0,'Empty K preserved')
            # Deliberately false C, with an ENV counterexample under two different encodings.
            c.formulas['rhoS']=b.conj(c.domain_sn,c.literal('e','false',True))
            roots=compute(b,c.domain,c.formulas['rhoS'],c.domain_en,c.domain_sn,c.current,c.env_next,c.sys_next,root)
            out=summarize(c,roots);require(out['counts']=={'C':0,'K':2,'K_minus_C':2},'Typed/AUX diagnostic counts')
            require(set(out['K_minus_C_witness']['state'])=={'e','memory'} and out['K_minus_C_witness']['ENV_next']=={'e':'true'},'Full typed counterexample')
            export(d/'out.gz',c,roots)
            with gzip.open(d/'out.gz','rb') as f:saved=json.load(f)
            require(saved['fields']==c.fields and saved['SYS_and_AUX_next_bits']==c.sys_next,'Export complete encoding')
            fresh=BDD(6);imported={0:0,1:1}
            for u,v,lo,hi in saved['nodes']:imported[u]=fresh.mk(v,imported[lo],imported[hi])
            require(all(digest(fresh,imported[saved['roots'][n]])==out['canonical_sha256'][n] for n in roots),'All exported roots exact roundtrip')
            c.model['original_bdds']['rhoS']=save_native(c,0,d/'bad_rhoS.bdd');rejects(c.audit_model)
    # Whole Context rejects field owner, role, encoding and incomplete next/current rosters.
    with tempfile.TemporaryDirectory(dir=B,prefix='qualification-context-') as td:
        c=synthetic_context(Path(td));
        for mutate in ('owner','role','encoding','bits'):
            model=copy.deepcopy(c.model)
            if mutate=='owner':model['fields'][1]['owner']='ENV'
            elif mutate=='role':model['fields'][1]['role']='SYS'
            elif mutate=='encoding':model['fields'][1]['encoding']['A']=copy.deepcopy(model['fields'][1]['encoding']['B'])
            else:model['all_next_bits'].pop()
            rejects(lambda:checker.Context(Path(td),c.profile,model))
test('source_audited_native_import_complete_K_boolean_identity_and_AUX_encoding_mutations',source_context_and_import)

def child_admission():
    for started in (False,True,None):
        v={'status':'UNKNOWN_NOT_ATTEMPTED','BDD_worker_started':started}
        require(runner.preserve_interrupted_attempt(v)['status']==('UNKNOWN_NOT_ATTEMPTED' if started is False else 'UNKNOWN_RUNNER_FAILURE'),'Interrupted accounting')
    p={'path':'synthetic','bytes':0,'sha256':'0'*64};decision={**p,'path':'decision'}
    names=('original_model','saved_W_V_region','complete_K_valuations','existing_full_region_equality','existing_certificate','original_initial_formulas','prior_native_initial_result')
    row={n:p for n in names};row.update(carrier=6,variable_count=6,existing_counts={'K':2},input_pins=[])
    base={'id':'synthetic','schema':'repair-preservation-condition-case-v1','status':'PASS','root_authorization':decision,
        'native_runs':0,'new_fixed_point_runs':0,'full_reset_uses':0,'complete_semantic_literal_only':True,
        'released_syntactic_loss_conclusion':None,'runtime_or_controller_defect_conclusion':None,
        'new_repaired_or_deployed_episode':False,'exact_W_C_or_K_loss_computed':False,'original_W_secondary_computed':False,
        'counts':{'C':1,'K':2,'K_minus_C':1},'carrier':6,'variable_count':6,'K_subset_C':False,'W_V_subset_C':False,
        'exact_saved_W_V_equals_complete_typed_K':True,'canonical_sha256':{n:str(i)*64 for i,n in enumerate(('C','K','K_minus_C','bad_ENV_next'))},
        'native_W_V_canonical_sha256':'1'*64,'K_minus_C_witness':{'all_logical_AUX_retained':True,'no_typed_SYS_and_all_AUX_response':True,
            'not_a_strategy_or_runtime_trace':True,'requires_ENV_move_legal_under_rhoE':False},'C_state_witness':{},
        'original_initial_recomputed':False,'source_formula_audit':'EXACT_ORIGINAL_BDD_TO_FROZEN_SOURCE_PROFILE',
        'input_pins':[p,p,decision],'functions':p,**{n:p for n in names}}
    with patch.object(runner,'pin',return_value=p),patch.object(runner,'verify',return_value=None):
        runner.admit_pass(base,'synthetic',row,{'code_files':[]},decision)
        for mutation in ('status','count','bool','identity','digest','witness','initial','pins','scope','counter_boolean'):
            bad=copy.deepcopy(base)
            if mutation=='status':bad['status']='UNKNOWN_INCOMPLETE'
            elif mutation=='count':bad['counts']['K_minus_C']=3
            elif mutation=='bool':bad['K_subset_C']=True
            elif mutation=='identity':bad['exact_saved_W_V_equals_complete_typed_K']=False
            elif mutation=='digest':bad['native_W_V_canonical_sha256']='0'*64
            elif mutation=='witness':bad['K_minus_C_witness']=None
            elif mutation=='initial':bad['original_initial_recomputed']=True
            elif mutation=='pins':bad['input_pins']=[]
            elif mutation=='counter_boolean':bad['native_runs']=False
            else:bad['exact_W_C_or_K_loss_computed']=True
            rejects(lambda:runner.admit_pass(bad,'synthetic',row,{'code_files':[]},decision))
test('child_authority_count_witness_scope_and_start_accounting',child_admission)

MOCK_STAGE='''import json,hashlib
from pathlib import Path
def run_bounded(argv,directory,deadline,**kwargs):
    root=Path(directory).parents[2];mode=(root/'MODE.txt').read_text()
    if mode=='wrapper_exception':raise RuntimeError('mock uncertain start')
    p=Path(directory);p.mkdir(parents=True);ident=argv[-1]
    process={'process_started':True,'status':'UNKNOWN_RESOURCE' if mode=='resource' else 'PROCESS_COMPLETED','exit_code':7 if mode=='nonzero' else 0}
    (p/'PROCESS_RECEIPT.json').write_text(json.dumps(process))
    dp=root/'ROOT_START_DECISION.json';raw=dp.read_bytes();decision={'path':str(dp),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    status={'unknown_status':'UNRECOGNIZED','integrity':'UNKNOWN_INTEGRITY','bad_pass':'PASS'}.get(mode,'UNKNOWN_RESOURCE')
    result={'id':ident,'schema':'repair-preservation-condition-case-v1','status':status,'root_authorization':decision,
      'native_runs':0,'new_fixed_point_runs':0,'full_reset_uses':0,'complete_semantic_literal_only':True,
      'released_syntactic_loss_conclusion':None,'runtime_or_controller_defect_conclusion':None,
      'new_repaired_or_deployed_episode':False,'exact_W_C_or_K_loss_computed':False,'original_W_secondary_computed':False}
    if mode!='missing_result':(p.parent/'RESULT.json').write_text('broken' if mode=='broken_result' else json.dumps(result))
    if mode=='decision_changed':dp.write_text('{}')
    return process
'''
def parent_case(mode):
    global parent_mock_runs
    with tempfile.TemporaryDirectory(dir=B,prefix='qualification-parent-') as td:
        root=Path(td);stage=root/'stage';stage.mkdir();(stage/'bounded_process.py').write_text(MOCK_STAGE);(root/'MODE.txt').write_text(mode)
        ids=['synthetic%02d'%i for i in range(11)];rows=[{'id':ident,'eligible':True} for ident in ids]
        save(root/'SELECTION.json',{'eligible_count':11,'eligible_ids':ids,'rows':rows})
        save(root/'FROZEN.json',{'files':[],'code_files':[],'python':pin(Path(sys.executable).resolve())})
        save(root/'ROOT_START_DECISION.json',{'start_authorized':True,'freeze':pin(root/'FROZEN.json')})
        end=datetime.now(timezone.utc)+timedelta(hours=1)
        class AuditClock:
            calls=0
            fromisoformat=staticmethod(datetime.fromisoformat)
            @classmethod
            def now(cls,tz):
                cls.calls+=1
                return end-timedelta(seconds=100) if cls.calls==1 else end
        with patch.object(runner,'B',root),patch.object(runner,'STAGE',stage):
            if mode=='post_audit_deadline':
                with patch.object(runner,'datetime',AuditClock):runner.run(end.isoformat())
            else:runner.run(end.isoformat())
        result=read(root/'RUN_RECEIPT.json');allrows=result['rows']
        require(len(allrows)==result['denominator']==11 and [r['id'] for r in allrows]==ids,'All eleven retained under interruption')
        if mode=='post_audit_deadline':
            require(not result['global_stop'] and result['BDD_worker_calls']=={'confirmed':0,'uncertain':0},'Post-audit deadline prevents dispatch')
            require(all(r['status']=='UNKNOWN_NOT_ATTEMPTED' for r in allrows),'No start after reserve failure')
        elif mode=='resource':
            require(not result['global_stop'] and result['BDD_worker_calls']=={'confirmed':11,'uncertain':0},'Resource failures remain per-case unknown')
            require(all(r['status']=='UNKNOWN_RESOURCE' for r in allrows),'All resource attempts preserved')
        else:
            require(result['global_stop'] and result['BDD_worker_calls']==({'confirmed':0,'uncertain':1} if mode=='wrapper_exception' else {'confirmed':1,'uncertain':0}),'Exact fatal call accounting')
            require(allrows[0]['status']!='UNKNOWN_NOT_ATTEMPTED' and all(r['status']=='UNKNOWN_NOT_ATTEMPTED' for r in allrows[1:]),'Started failure cannot become not attempted')
        require(result['native_runs']==result['new_fixed_point_runs']==result['full_reset_uses']==0,'No native/FP/reset')
        parent_mock_runs+=1

require(not (B/'FROZEN.json').exists() and not (B/'RUN_STARTED.json').exists(),'Qualification before freeze')
for mode in ('nonzero','missing_result','unknown_status','integrity','bad_pass','wrapper_exception','broken_result','decision_changed','resource','post_audit_deadline'):
    test('whole_parent_mock_'+mode,lambda mode=mode:parent_case(mode))
result={'schema':'repair-preservation-condition-offline-qualification-v1','created_utc':now(),
    'status':'PASS' if all(t['pass'] for t in tests) else 'FAIL','tests':tests,'passed':sum(t['pass'] for t in tests),'total':len(tests),
    'exhaustive_truth_arenas':truth_arenas,'whole_parent_mock_runs':parent_mock_runs,
    'reconstructed_BDD_computations':0,'new_fixed_point_runs':0,'actual_child_processes':0,'native_runs':0,'full_reset_uses':0,
    'oracle':'Exhaustive independent finite truth sets, typed/AUX import and same-count Boolean mismatch mutations, all roots roundtrip, mocked parent failure/reserve admission.',
    'source_pins':[pin(B/n) for n in ('evidence.py','adapter.py','measure.py','run.py','qualify.py','PROTOCOL_JA.txt')]}
save(B/'OFFLINE_QUALIFICATION.json',result)
print(json.dumps({k:result[k] for k in ('status','passed','total','exhaustive_truth_arenas','whole_parent_mock_runs','reconstructed_BDD_computations')}))
require(result['status']=='PASS','Synthetic qualification failed')
