"""Mock-only full-driver fault tests. All real process operations forbidden."""
from contextlib import ExitStack,redirect_stdout
from datetime import datetime,timezone,timedelta
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import copy,io,json,os,subprocess,sys,tempfile
sys.dont_write_bytecode=True
from evidence import B,save,pin,require,now
import run as runner
import measure
from decomposition import BDD,solve

def fixture_summary(helper):
    b=BDD(2 if helper else 0)
    args=dict(b=b,q=1,de=1,den=1,dsn=1,current=(),en=(),sn=(),prime={},oe=1,os=1,oa=[],og=[],te=1,ts=1,je=b.disj(b.neg(b.var(0)),b.var(1)) if helper else 1,js=1,ja=[b.neg(b.var(0))] if helper else [],jg=[],jte=b.neg(b.var(0)) if helper else 1,jts=1,h=0 if helper else None,hp=1 if helper else None)
    out=solve(**args)
    pair={'common':b,'original':SimpleNamespace(current=(),current_sys=(),current_env=(),carrier=1),'helper_added':helper,'helper_current_bit':0 if helper else None,'original_fields':[], 'original_roots':{'thetaE':args['te']}}
    return measure.summarize(pair,out)

def run_case(mode):
    with tempfile.TemporaryDirectory(prefix='quadrant-authority-mock-') as tmp:
        folder=Path(tmp);saved={};calls=[];verifies=[]
        def fakepin(p):return {'path':str(Path(p).resolve()),'bytes':1,'sha256':'a'*64}
        decision=fakepin(folder/'ROOT_START_DECISION.json');eligible=[f'mock{i:03d}' for i in range(13)]
        allrows=[{'id':i,'eligible':True,'in_fixed_small_cohort':True,'prior_status':'PENDING_RELATION_AUDIT','input_pins':[],
            'original_model':fakepin(folder/(i+'.original')),'job_model':fakepin(folder/(i+'.job')),'native_result':fakepin(folder/(i+'.native')),'parent_receipt':fakepin(folder/(i+'.parent')),'quadrant_result':fakepin(folder/(i+'.quad')),'quadrant_process':fakepin(folder/(i+'.quadprocess')),'independent_W_certificate':fakepin(folder/(i+'.independent')),'independent_W_process':fakepin(folder/(i+'.iprocess')),'independent_regions':fakepin(folder/(i+'.regions'))} for i in eligible]
        allrows.append({'id':'resource-original','eligible':False,'in_fixed_small_cohort':True,'prior_status':'UNKNOWN_NATIVE_RESOURCE'})
        allrows += [{'id':f'outside{i:03d}','eligible':False,'in_fixed_small_cohort':False,'prior_status':'UNKNOWN_OUTSIDE_PRESPECIFIED_SMALL_COHORT'} for i in range(411)]
        rows={r['id']:r for r in allrows};selection={'source_denominator':425,'fixed_small_cohort_count':14,'eligible_count':13,'eligible_ids':eligible,'rows':allrows,'condition_context_without_selection':{'selection_uses_condition_truth':False}}
        freeze={'files':[],'code_files':[],'python':fakepin(Path(sys.executable).resolve())};results={}
        def read(p):
            p=Path(p)
            if p.name=='FROZEN.json':return copy.deepcopy(freeze)
            if p.name=='SELECTION.json':return copy.deepcopy(selection)
            if p.name=='RESULT.json':return copy.deepcopy(results[p.parent.name])
            if p.name.endswith('.original'):return {'fields':[]}
            raise AssertionError('Unplanned mock read '+str(p))
        def verify(refs):
            verifies.append(refs)
            if mode=='source_drift_before_spawn' and len(verifies)==2:raise ValueError('Controlled frozen source drift')
        def execute(argv,process_folder,*args,**kwargs):
            ident=argv[-1];calls.append(ident);row=rows[ident]
            if mode=='wrapper_exception':raise RuntimeError('Controlled wrapper exception before return')
            if mode=='resource_local':return {'status':'UNKNOWN_RESOURCE','process_started':True,'exit_code':-15}
            if mode!='missing_result':
                result_path=Path(process_folder).parent/'RESULT.json';result_path.parent.mkdir(parents=True);result_path.write_text('{}')
            result={'schema':'helper-decomposition-case-v1','id':ident,'status':'PASS','root_authorization':decision,'parent_aborted':True,
                'native_runs':0,'full_reset_uses':0,'direct_reference_objective':'strict_GR1_on_actual_saved_transformed_arena','compared_with_native_4fp_region':False,'claim_is_cooperative_strategy_existence':False,'released_10_condition_negative_cases_inference':False,'independent_source_compiler':False,'shared_source_compiler':True,'common_BDD_and_GR1_engine_between_direct_and_decomposed':True,'synthetic_finite_set_oracle_independent_representation':True,
                **{k:row[k] for k in ('original_model','job_model','native_result')},'enclosing_native_parent':row['parent_receipt'],
                'input_pins':[fakepin(folder/'FROZEN.json'),fakepin(folder/'SELECTION.json'),decision],
                'summary':fixture_summary(mode=='valid_helper'),'all_original_AUX_retained':True,'prior_quadrant_result':row['quadrant_result'],'prior_quadrant_process':row['quadrant_process'],'independent_W_certificate':row['independent_W_certificate'],'independent_W_process':row['independent_W_process'],'independent_regions':row['independent_regions'],'original_W_exact_authority_equal':True,'original_initial_quantification_authority_equal':True,'functions':fakepin(folder/(ident+'.functions'))}
            if mode=='unknown_child_status':result['status']='UNEXPECTED_SUCCESS'
            if mode=='child_integrity':result['status']='UNKNOWN_INTEGRITY'
            if mode=='scientific_mismatch':
                result['status']='FAIL_DECOMPOSITION';summary=result['summary'];summary['checks']['active_decomposition_equal']=False;summary['counts']['active_difference']=1;summary['state_witnesses']['active_difference']={'state':{},'bits':{},'helper_current':None}
            if mode=='wrong_original_W_authority':result['original_W_exact_authority_equal']=False
            if mode=='wrong_initial_authority':result['original_initial_quantification_authority_equal']=False
            if mode=='malformed_pass':result.pop('summary')
            if mode=='wrong_authorization':result['root_authorization']=fakepin(folder/'wrong-decision')
            if mode=='wrong_input_pins':result['input_pins']=[]
            if mode=='wrong_count':result['summary']['counts']['active_difference']=1
            results[ident]=result
            return {'status':'PROCESS_COMPLETED','process_started':True,'exit_code':7 if mode=='nonzero_exit' else 0}
        fake_spec=SimpleNamespace(loader=SimpleNamespace(exec_module=lambda m:None))
        with ExitStack() as stack:
            stack.enter_context(patch.object(runner,'B',folder));stack.enter_context(patch.object(runner,'pin',side_effect=fakepin));stack.enter_context(patch.object(runner,'read',side_effect=read));stack.enter_context(patch.object(runner,'verify',side_effect=verify))
            stack.enter_context(patch.object(runner,'save',side_effect=lambda p,x:saved.__setitem__(Path(p).name,copy.deepcopy(x))))
            stack.enter_context(patch.dict(sys.modules,{'measure':SimpleNamespace(authorization=lambda:decision)}))
            stack.enter_context(patch.object(runner.importlib.util,'spec_from_file_location',return_value=fake_spec));stack.enter_context(patch.object(runner.importlib.util,'module_from_spec',return_value=SimpleNamespace(run_bounded=execute)))
            for obj,name in ((subprocess,'Popen'),(os,'kill'),(os,'killpg'),(os,'wait4')):stack.enter_context(patch.object(obj,name,side_effect=AssertionError('Actual process operation forbidden')))
            deadline=datetime.now(timezone.utc)+timedelta(seconds=20 if mode=='deadline_reserve' else 600)
            with redirect_stdout(io.StringIO()):runner.run(deadline.isoformat())
        receipt=saved['RUN_RECEIPT.json'];out=receipt['rows'];require(len(out)==425 and out[13]['status']=='UNKNOWN_NATIVE_RESOURCE' and all(r['status']=='UNKNOWN_OUTSIDE_PRESPECIFIED_SMALL_COHORT' for r in out[14:]),'Fixed 425/14/13 row accounting')
        if mode in ('valid_nohelper','valid_helper','resource_local'):
            require(not receipt['global_stop'] and len(calls)==13 and all(r['status']==('UNKNOWN_RESOURCE' if mode=='resource_local' else 'PASS') for r in out[:13]),'Legitimate case-local continuation')
        elif mode=='deadline_reserve':require(not receipt['global_stop'] and not calls and all(r['status']=='UNKNOWN_NOT_ATTEMPTED' for r in out[:13]),'Deadline reserve refusal')
        elif mode=='source_drift_before_spawn':require(receipt['global_stop'] and not calls and all(r['BDD_worker_started'] is False for r in out[:13]),'Source drift before any spawn')
        else:
            require(receipt['global_stop'] and len(calls)==1 and out[0]['status']!='PASS' and all(r['status']=='UNKNOWN_NOT_ATTEMPTED' for r in out[1:13]),'Unexpected child result must stop globally')
            if mode=='scientific_mismatch':require(out[0]['status']=='FAIL_DECOMPOSITION' and 'FAIL_DECOMPOSITION' in receipt['stop_reasons'],'Scientific counterexample retained, not UNKNOWN')
            if mode=='wrapper_exception':require(out[0]['status']=='UNKNOWN_RUNNER_FAILURE' and receipt['BDD_worker_calls']=={'confirmed':0,'uncertain':1},'Uncertain attempt accounting')
        require(receipt['root_authorization']==decision,'Start decision missing from receipt')
        return {'name':mode,'pass':True,'global_stop':receipt['global_stop'],'mock_child_calls':len(calls),'first_status':out[0]['status'],'BDD_worker_calls':receipt['BDD_worker_calls']}

def authorization_negative():
    with tempfile.TemporaryDirectory(prefix='quadrant-gate-mock-') as tmp:
        folder=Path(tmp);(folder/'FROZEN.json').write_text('{}');correct=pin(folder/'FROZEN.json')
        for decision in ({'start_authorized':False,'freeze':correct},{'start_authorized':True,'freeze':{'path':'wrong','bytes':0,'sha256':'0'*64}}):
            (folder/'ROOT_START_DECISION.json').write_text(json.dumps(decision))
            with patch.object(measure,'B',folder):
                try:measure.authorization()
                except ValueError:pass
                else:raise AssertionError('Unreviewed start authorized')
        (folder/'ROOT_START_DECISION.json').write_text(json.dumps({'start_authorized':True,'freeze':correct}))
        with patch.object(measure,'B',folder):require(measure.authorization()==pin(folder/'ROOT_START_DECISION.json'),'Valid gate exact decision pin')
    return {'name':'false_or_wrong_freeze_authorization_rejected','pass':True}

require(not (B/'FROZEN.json').exists() and not (B/'RUN_STARTED.json').exists(),'Qualifications before freeze only')
results=[]
for mode in ('valid_nohelper','valid_helper','resource_local','deadline_reserve','source_drift_before_spawn','nonzero_exit','missing_result','unknown_child_status','malformed_pass','wrong_authorization','wrong_input_pins','wrong_count','scientific_mismatch','wrong_original_W_authority','wrong_initial_authority','child_integrity','wrapper_exception'):
    try:results.append(run_case(mode))
    except Exception as error:results.append({'name':mode,'pass':False,'error':repr(error)})
try:results.append(authorization_negative())
except Exception as error:results.append({'name':'authorization_negative','pass':False,'error':repr(error)})
report={'schema':'helper-decomposition-authority-qualification-v1','created_utc':now(),'status':'PASS' if all(r['pass'] for r in results) else 'FAIL','passed':sum(r['pass'] for r in results),'total':len(results),'rows':results,
    'source_pins':[pin(B/n) for n in ('evidence.py','decomposition.py','import_original.py','measure.py','run.py','qualify_authority.py','PROTOCOL_JA.txt')],
    'actual_child_processes':0,'actual_signals':0,'corpus_BDD_computations':0,'native_runs':0,'full_reset_uses':0}
save(B/'AUTHORITY_QUALIFICATION.json',report);print(json.dumps({'status':report['status'],'passed':report['passed'],'total':report['total'],'failures':[r for r in results if not r['pass']]},indent=2));require(report['status']=='PASS','Authority qualification failed')
