"""Offline mathematical fixtures plus comparison against all frozen finite PASS cases."""
from pathlib import Path
import importlib.util, json, random, signal, sys, time, traceback
sys.dont_write_bytecode = True
from check_case import HERE, read, save, pin, verify_pin, alarm
from symbolic import BDD, calculate, require

spec = importlib.util.spec_from_file_location('qualification_finite_sets', HERE / 'vendor/finite_sets_v1.py')
finite = importlib.util.module_from_spec(spec); spec.loader.exec_module(finite)


def fixture(name, ne, ns, erel, srel, assumptions, guarantees, env_init=None, sys_init=None):
    """Tiny explicit data ONLY for qualification, never the corpus engine."""
    eb, sb = max(1, (max(ne, 1) - 1).bit_length()), max(1, (max(ns, 1) - 1).bit_length())
    ec = [2 * i for i in range(eb)]; en = [i + 1 for i in ec]
    sc = [2 * (eb + i) for i in range(sb)]; sn = [i + 1 for i in sc]
    cb, nb = ec + sc, en + sn
    b = BDD(len(cb + nb))
    code = lambda x, bits: {v: bool((x >> j) & 1) for j, v in enumerate(bits)}
    ed = lambda xs, bits: b.disj(*(b.cube(code(x, bits)) for x in xs))
    de, ds = ed(range(ne), ec), ed(range(ns), sc)
    den, dsn = ed(range(ne), en), ed(range(ns), sn)
    vals = [(e, s) for e in range(ne) for s in range(ns)]
    Q = set(range(len(vals)))
    cubes = {i: b.cube(code(e, ec) | code(s, sc)) for i, (e, s) in enumerate(vals)}
    region = lambda x: b.disj(*(cubes[i] for i in x))
    q = b.conj(de, ds)
    rhoe = b.disj(*(b.conj(cubes[i], b.cube(code(e, en))) for i, e in erel))
    rhos = b.disj(*(b.conj(cubes[i], b.cube(code(e, en) | code(s, sn))) for i, e, s in srel))
    env_init = set(range(ne)) if env_init is None else set(env_init)
    sys_init = Q.copy() if sys_init is None else set(sys_init)
    thetae, thetas = ed(env_init, ec), region(sys_init)
    inputs = {i: {e for j, e in erel if j == i} for i in Q}
    replies = {(i, e): {t for t, (te, ts) in enumerate(vals) if te == e and (i, e, ts) in srel}
               for i in Q for e in inputs[i]}
    A, G = [set(x) for x in assumptions] or [Q.copy()], [set(x) for x in guarantees] or [Q.copy()]
    pre = lambda x: {i for i in Q if all(replies[i, e] & x for e in inputs[i])}
    alive = {i for i in Q if inputs[i]}
    V = finite.fixed(Q, lambda x: alive & pre(x), True, 'V', [])
    W = finite.gr1_three(Q, A, G, pre, [])
    vp = lambda x: {i for i in V if all(replies[i, e] & x & V for e in inputs[i])}
    WV = finite.gr1_three(V, [a & V for a in A], [g & V for g in G], vp, []) if V else set()
    if V:
        _, aq, aa, gg, owners, succ = finite.make_arena(Q, inputs, replies, A, G + A, V)
        require(not any(x.startswith(('win_', 'lose_')) for x in aq), 'qualification V totality')
        cp = lambda x: {i for i in aq if (succ[i] <= x if owners[i] == 'ENV' else bool(succ[i] & x))}
        ep = lambda x: {i for i in aq if succ[i] & x}
        kv = finite.four_fp(aq, aa, gg, cp, ep, [])
        K = {i for i in V if 'e' + str(i) in kv}
    else:
        K = set()
    wsreplies = {(i, e): {t for t, (te, _) in enumerate(vals) if te == e} for i in Q for e in inputs[i]}
    wsp = lambda x: {i for i in Q if all(wsreplies[i, e] & x for e in inputs[i])}
    NWS = finite.gr1_three(Q, A, [set()], wsp, [])
    initial = {i for i, (e, _) in enumerate(vals) if e in env_init and i in sys_init}
    wsinitial = {i for i, (e, _) in enumerate(vals) if e in env_init}
    def reach(initial, replies):
        return finite.fixed(initial, lambda x: x | set().union(*(replies[i, e] for i in x for e in inputs[i])), False, 'R', [])
    R, WR = reach(initial, replies), reach(wsinitial, wsreplies)
    expected = {'original_initialized': initial, 'alive': alive, 'W': W, 'V': V, 'WV': WV, 'K': K,
        'WV_minus_K': WV - K, 'K_minus_WV': K - WV, 'W_intersect_V_minus_K': (W & V) - K,
        'reachable': R, 'reachable_delta': R & ((W & V) - K), 'reachable_WV_minus_K': R & (WV - K),
        'reachable_WV': R & WV, 'reachable_K': R & K, 'WS_NWS_region': NWS, 'WS_definition_reach': WR,
        'WS_definition_reachable_NWS': WR & NWS, 'WS_original_reachable_NWS': R & NWS,
        'WS_original_reachable_NWS_and_K': R & NWS & K}
    got, quant, _ = calculate(b, q, de, rhoe, rhos, den, dsn, cb, en, sn, dict(zip(cb, nb)),
        [region(x) for x in assumptions], [region(x) for x in guarantees], thetae, thetas, thetae, ds, rhoe, dsn)
    checks = {key: got[key] == region(value) for key, value in expected.items()}
    qchecks = {}
    for key in ('W', 'V', 'WV', 'K'):
        want = all(any(i in sys_init and i in expected[key] and vals[i][0] == e for i in Q) for e in env_init)
        qchecks[key] = quant[key]['value'] == want
    return {'name': name, 'scientific_corpus_example': False,
        'status': 'PASS' if all(checks.values()) and all(qchecks.values()) else 'FAIL',
        'checks': checks, 'initial_checks': qchecks,
        'input': {'ENV_size': ne, 'SYS_size': ns, 'ENV_relation': sorted(erel), 'SYS_relation': sorted(srel),
                  'assumptions': [sorted(x) for x in assumptions], 'guarantees': [sorted(x) for x in guarantees],
                  'initial_ENV_values': sorted(env_init), 'initial_SYS_state_ids': sorted(sys_init)},
        'finite_counts': {k: len(v) for k, v in expected.items()}, 'BDD_nodes': len(b.nodes)}


def boundary():
    frozen = read(HERE / 'FROZEN.json')
    for p in frozen['checker_files']:
        verify_pin(p)
    q = set(range(4)); er = {(i, e) for i in q for e in range(2)}
    sr = {(i, e, s) for i in q for e in range(2) for s in range(2)}
    cases = [fixture('zero_justice_total', 2, 2, er, sr, [], []),
             fixture('multiple_justice_total', 2, 2, er, sr, [{0, 1}, {2, 3}], [{0, 2}, {1, 3}]),
             fixture('ENV_dead', 2, 2, set(), sr, [], []),
             fixture('SYS_dead', 2, 2, er, set(), [], []),
             fixture('empty_ENV_initializer', 2, 2, er, sr, [], [], env_init=[]),
             fixture('empty_SYS_initializer', 2, 2, er, sr, [], [], sys_init=[]),
             fixture('empty_ENV_domain', 0, 2, set(), set(), [], []),
             fixture('empty_SYS_domain', 2, 0, set(), set(), [], []),
             fixture('empty_both_domains', 0, 0, set(), set(), [], [])]
    q6 = set(range(6))
    cases.append(fixture('non_power_of_two_ENV_domain', 3, 2,
        {(i, e) for i in q6 for e in range(3)}, {(i, e, s) for i in q6 for e in range(3) for s in range(2)},
        [{0, 2, 4}], [{1, 3, 5}]))
    rng = random.Random(20261017)
    for index in range(32):
        rE = {x for x in sorted(er) if rng.random() < 0.8}
        rS = {x for x in sorted(sr) if rng.random() < 0.65}
        aa = [{i for i in sorted(q) if rng.random() < 0.5} for _ in range(index % 3)]
        gg = [{i for i in sorted(q) if rng.random() < 0.5} for _ in range((index // 3) % 3)]
        cases.append(fixture(f'fixed_seed_small_game_{index:02}', 2, 2, rE, rS, aa, gg))
    out = {'schema': 'offline-symbolic-qualification-v1', 'status': 'PASS' if all(x['status'] == 'PASS' for x in cases) else 'FAIL',
           'fixture_count': len(cases), 'native_runs': 0, 'scientific_inputs_added': 0,
           'meaning': 'Symbolic round Eq15 compared with independent finite alternating-halfstep Eq15 oracle.',
           'freeze': pin(HERE / 'FROZEN.json'), 'cases': cases}
    save(HERE / 'qualification/BOUNDARY.json', out)
    print(json.dumps({k: out[k] for k in ('status', 'fixture_count', 'native_runs', 'scientific_inputs_added')}), flush=True)
    return out


if __name__ == '__main__':
    signal.signal(signal.SIGALRM, alarm); signal.alarm(60)
    try:
        result = boundary()
    finally:
        signal.alarm(0)
    sys.exit(0 if result['status'] == 'PASS' else 1)
