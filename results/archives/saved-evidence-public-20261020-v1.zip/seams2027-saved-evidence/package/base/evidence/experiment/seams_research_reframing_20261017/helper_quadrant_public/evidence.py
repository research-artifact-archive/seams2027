"""Closed saved-output admission. Metadata and hashes only; no BDD/native call."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;E=B.parent;SMALL=E/'small_native_recovery';CHECK=E/'released_kind_corpus_checker';STAGE=E/'contained_stage_process'
def require(ok,text):
    if not ok:raise ValueError(text)
def unique_json(pairs):
    out={}
    for k,v in pairs:require(k not in out,'Duplicate JSON key');out[k]=v
    return out
def read(p):return json.loads(Path(p).read_text(),object_pairs_hook=unique_json)
def now():return datetime.now(timezone.utc).isoformat()
def save(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.tmp');tmp.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n');tmp.replace(p)
def pin(p):
    p=Path(p).resolve();h=hashlib.sha256();size=0
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk);size+=len(chunk)
    return {'path':str(p),'bytes':size,'sha256':h.hexdigest()}
def pins_in(x):
    if isinstance(x,dict):
        if set(x)>={'path','bytes','sha256'}:return [{k:x[k] for k in ('path','bytes','sha256')}] if Path(x['path']).is_absolute() else []
        return [p for v in x.values() for p in pins_in(v)]
    return [p for v in x for p in pins_in(v)] if isinstance(x,list) else []
def unique(refs):
    out={}
    for p in refs:
        require(str(Path(p['path']).resolve())==p['path'],'Canonical absolute evidence pin')
        require(p['path'] not in out or out[p['path']]==p,'Conflicting evidence pin');out[p['path']]=p
    return list(out.values())
def verify(refs):
    for p in unique(refs):require(pin(p['path'])==p,'Pinned evidence changed: '+p['path'])

def select():
    closed=read(SMALL/'RUN_RECEIPT.json');cohort=read(SMALL/'SELECTION.json');freeze=read(SMALL/'FROZEN.json');files=read(SMALL/'RESULT_FILES.json');final=read(SMALL/'FINAL_PIN_AUDIT.json')
    require(final.get('errors')==[] and type(final.get('checked')) is int and final['checked']>0,'Closed small-cohort final pin audit')
    require(closed['schema']=='small-native-recovery-v1' and closed['stage']=='COMPLETE' and closed['global_stop'] is False and closed['pin_errors']==[],'Closed small-cohort authority')
    require(closed['source_denominator']==425 and closed['eligible_count']==cohort['eligible_count']==14 and len(cohort['rows'])==425,'Fixed original population and small cohort')
    ids=cohort['eligible_ids'];require(len(ids)==len(set(ids))==14,'Exact 14 cohort IDs')
    released=[r for r in closed['rows'] if r['pipeline']=='released_kind' and r['phase']=='runs'];byid={r['id']:r for r in released}
    require(len(released)==14 and set(byid)==set(ids),'Every fixed released arm retained')
    global_refs=unique([pin(SMALL/n) for n in ('RUN_RECEIPT.json','SELECTION.json','FROZEN.json','RESULT_FILES.json','FINAL_PIN_AUDIT.json')]+pins_in(freeze)+pins_in(files)+cohort['input_pins'])
    condition_dir=E/'preservation_condition_public';condition=read(condition_dir/'RUN_RECEIPT.json')
    require(condition['global_stop'] is False and condition['source_denominator']==425 and condition['eligible_count']==59,'Closed C-condition context authority')
    condition_rows={r['id']:r for r in condition['rows']}
    negative_ids=[r['id'] for r in condition['rows'] if r['status']=='PASS' and r.get('W_subset_C') is False]
    cohort_condition=[{'id':ident,'status':condition_rows[ident]['status'],'W_subset_C':condition_rows[ident].get('W_subset_C')} for ident in ids]
    require(all(r['status']=='PASS' and r['W_subset_C'] is True for r in cohort_condition) and not set(ids)&set(negative_ids),'Verified disjoint fixed-cohort versus condition-negative context')
    context={'closed_condition_receipt':pin(condition_dir/'RUN_RECEIPT.json'),'fixed_cohort_condition_rows':cohort_condition,'condition_negative_ids':negative_ids,
        'fixed_cohort_intersection_condition_negative':sorted(set(ids)&set(negative_ids)),
        'selection_uses_condition_truth':False,'inference_limit':'This fixed 14-case cohort is separate from the condition-negative cases. Correspondence on its completed released outputs cannot transfer negative-case conclusions to the released route.'}
    global_refs=unique(global_refs+[pin(condition_dir/'RUN_RECEIPT.json'),pin(condition_dir/'FROZEN.json'),pin(condition_dir/'ROOT_START_DECISION.json')]+pins_in(condition))
    # The closed manifest is checked before selecting any relation result.
    verify(global_refs);rows=[]
    for old in cohort['rows']:
        ident=old['id'];row={'id':ident,'source':old['source'],'in_fixed_small_cohort':ident in byid,'eligible':False,'prior_status':'UNKNOWN_OUTSIDE_PRESPECIFIED_SMALL_COHORT'}
        if ident in byid:
            arm=byid[ident];folder=SMALL/'runs'/ident/'released_kind';parent=read(arm['parent_receipt']['path'])
            require(arm['parent_receipt']==pin(folder/'PARENT_RECEIPT.json'),'Enclosing arm identity')
            row.update(prior_status='UNKNOWN_NATIVE_RESOURCE' if parent['status']=='UNKNOWN_RESOURCE' else 'UNKNOWN_NATIVE_PROCESS',parent_receipt=arm['parent_receipt'],prior_parent_status=parent['status'])
            # Admission is process/capture/model availability only, never controller outcome or relation sign.
            if parent['status']=='COMPLETE_PROCESS_AND_CAPTURE':
                worker=read(folder/'NATIVE_WORKER_RECEIPT.json');capture=read(folder/'STDOUT_CAPTURE.json');native=read(folder/'result.json');model=read(folder/'model.json')
                require(parent['global_stop'] is False and parent['native_called'] is True and parent['qualification_only'] is False,'Closed scientific parent scope')
                require(parent['source_pin_errors_before']==parent['source_pin_errors_after']==parent['artifact_pin_errors']==[],'Parent source/artifact authority')
                require(parent['parent_exact_wait4']['exact_child_reaped'] and not parent['parent_exact_wait4']['authority_lost'] and parent['parent_worker_group_observation']['state']=='ABSENT','Exact enclosing worker completion')
                require(parent['worker_receipt_pin']==pin(folder/'NATIVE_WORKER_RECEIPT.json') and parent['worker_receipt']==worker,'Exact worker receipt binding')
                require(worker['status']=='PROCESS_COMPLETED' and worker['returncode']==0 and worker['child_reaped'] and worker['process_group_contained'],'Scientific worker completed')
                require(worker['exact_child_wait4']['exact_child_reaped'] and not worker['exact_child_wait4']['authority_lost'] and worker['final_group_observation']['state']=='ABSENT','Exact native child completion')
                require(capture['capture_complete'] and capture['limits_passed'] and capture['roundtrip_verified'],'Complete lossless capture')
                require(native['fixture_id']==native['case_id']==model['fixture_id']==model['case_id']==ident and native['variant']==model['variant']=='initializers','Released case identity')
                require(native['pipeline']=='released_syntactic_kind_job_equivalent' and native['teardown']=='COMPLETED' and native['semantic_reduction_used'] is False and native['initializers_replaced'] is False,'Released syntactic pipeline identity')
                original=E/'kind_corpus_rle/runs'/ident/'model.json';require(old['model']==pin(original),'Selected original model identity')
                refs=unique(pins_in(parent)+[pin(f) for f in sorted(folder.rglob('*')) if f.is_file()]+[pin(original)]+([arm['certificate']]+pins_in(read(arm['certificate']['path'])) if arm.get('certificate') else []))
                verify(refs);row.update(eligible=True,prior_status='PENDING_RELATION_AUDIT',original_model=pin(original),job_model=pin(folder/'model.json'),native_result=pin(folder/'result.json'),input_pins=refs,prior_native_status=native.get('status'),helper_metadata=native.get('helper_added'),job_directory=str(folder))
            else:row['input_pins']=[arm['parent_receipt']]
        rows.append(row)
    return {'schema':'helper-quadrant-selection-v1','created_utc':now(),'source_denominator':425,'fixed_small_cohort_count':14,'fixed_small_cohort_ids':ids,
        'eligible_count':sum(r['eligible'] for r in rows),'eligible_ids':[r['id'] for r in rows if r['eligible']],'rows':rows,'input_pins':global_refs,
        'selection_rule':'All 14 prespecified released-arm slots; process/capture/model-complete arms only are calculable. No native Boolean, graph, region, helper, or relation-result filtering.',
        'condition_context_without_selection':context,'parent_aborted':True,'closed_small_receipt':pin(SMALL/'RUN_RECEIPT.json'),'old_stopped_parent_receipt':closed['preserved_parent_receipt'],'native_runs':0,'corpus_BDD_computations':0}
