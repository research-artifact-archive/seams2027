"""One bounded independent symbolic audit of a complete native export."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, gzip, hashlib, json, math, posixpath, re, signal, sys, time, traceback, zipfile
sys.dont_write_bytecode = True
from symbolic import (BDD, Invalid, ResourceRefusal, require, calculate, count, root_digest)

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
CORPUS = BASE / 'kind_corpus'
LIMITS = {'variables': 64, 'BDD_nodes_including_terminals': 500000,
          'saved_BDD_bytes': 8 * 1024 * 1024, 'wall_seconds_per_process': 60}


def unique(pairs):
    out = {}
    for k, v in pairs:
        require(k not in out, 'duplicate JSON key ' + k)
        out[k] = v
    return out


def read(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=unique)


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temp.replace(path)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def pin(path):
    path = Path(path).resolve()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def verify_pin(entry):
    require(pin(entry['path']) == entry, 'pinned file drift: ' + entry['path'])


def alarm(*_):
    raise TimeoutError('uniform 60-second process wall-time bound')


class Model:
    def __init__(self, directory, model):
        self.directory, self.model = Path(directory), model
        require(model.get('schema') == 'k7-native-model-export-v1', 'model schema')
        n = model['bdd_variable_count']
        if type(n) is not int or n < 0:
            raise Invalid('invalid variable count')
        if n > LIMITS['variables']:
            raise ResourceRefusal('VARIABLES')
        self.b = BDD(n, node_limit=LIMITS['BDD_nodes_including_terminals'])
        self.fields = model['fields']
        require(isinstance(self.fields, list), 'field list')
        names, current, nxt, self.prime = set(), [], [], {}
        self.domains = {(o, p): 1 for o in ('ENV', 'SYS') for p in ('current', 'next')}
        self.bits = {(o, p): [] for o in ('ENV', 'SYS') for p in ('current', 'next')}
        for f in self.fields:
            require(isinstance(f, dict) and type(f['name']) is str and f['name'] not in names, 'field identity')
            names.add(f['name'])
            require(f['owner'] in ('ENV', 'SYS') and f['role'] in ('ENV', 'SYS', 'AUX'), 'field owner/role')
            require((f['role'] == 'ENV') == (f['owner'] == 'ENV'), 'unexpected ENV AUX/public role')
            values = f['values']
            require(isinstance(values, list) and all(type(x) is str for x in values)
                    and len(values) == len(set(values)) and type(f['domain_size']) is int
                    and len(values) == f['domain_size'] and set(values) == set(f['encoding']), 'typed values')
            cb, nb = f['current_bits'], f['next_bits']
            require(isinstance(cb, list) and isinstance(nb, list) and len(cb) == len(nb), 'bit pairing')
            for phase, bits in (('current', cb), ('next', nb)):
                require(all(type(x) is int and 0 <= x < n for x in bits) and len(set(bits)) == len(bits), 'field bit roster')
                codes, cubes = set(), []
                for value in values:
                    raw = f['encoding'][value][phase]
                    require(isinstance(raw, dict) and set(raw) == {str(x) for x in bits}
                            and all(type(x) is bool for x in raw.values()), 'encoding coverage/types')
                    code = tuple(raw[str(x)] for x in bits)
                    require(code not in codes, 'noninjective encoding')
                    codes.add(code)
                    cubes.append(self.b.cube({int(k): v for k, v in raw.items()}))
                key = (f['owner'], phase)
                self.domains[key] = self.b.conj(self.domains[key], self.b.disj(*cubes))
                self.bits[key].extend(bits)
            for value in values:
                require(tuple(f['encoding'][value]['current'][str(x)] for x in cb)
                        == tuple(f['encoding'][value]['next'][str(x)] for x in nb), 'current/next value encoding mismatch')
            current.extend(cb); nxt.extend(nb); self.prime.update(zip(cb, nb))
        require(len(set(current + nxt)) == len(current + nxt) and set(current + nxt) == set(range(n)), 'complete disjoint bit ownership')
        require(model['all_current_bits'] == sorted(current) and model['all_next_bits'] == sorted(nxt), 'model bit unions')
        require(len(model['bdd_variable_order']) == n and set(model['bdd_variable_order']) == set(range(n)), 'native variable order')
        require(model['public_fields'] == {'ENV': [f['name'] for f in self.fields if f['role'] == 'ENV'],
                'SYS': [f['name'] for f in self.fields if f['role'] == 'SYS']}, 'public field roster')
        self.current, self.next = tuple(sorted(current)), tuple(sorted(nxt))
        self.ec, self.sc = self.bits['ENV', 'current'], self.bits['SYS', 'current']
        self.en, self.sn = self.bits['ENV', 'next'], self.bits['SYS', 'next']
        self.de, self.ds = self.domains['ENV', 'current'], self.domains['SYS', 'current']
        self.den, self.dsn = self.domains['ENV', 'next'], self.domains['SYS', 'next']
        self.q = self.b.conj(self.de, self.ds)
        self.carrier = math.prod(f['domain_size'] for f in self.fields)
        require(count(self.b, self.q, self.current) == self.carrier, 'typed carrier cardinality')
        self.cache, self.refs, self.pins = {}, {}, {}
        required = {'thetaE', 'thetaS', 'rhoE', 'rhoS', 'domain', 'domain_ENV_next', 'domain_SYS_next'}
        require(set(model['original_bdds']) == required, 'original relation roster')
        self.forms = {k: self.load(ref) for k, ref in model['original_bdds'].items()}
        self.justices = {o: [self.load(ref) for ref in model['original_justices'][o]] for o in ('ENV', 'SYS')}
        b, f = self.b, self.forms
        require(f['domain'] == self.q and f['domain_ENV_next'] == self.den and f['domain_SYS_next'] == self.dsn,
                'saved domains differ from exact typed encodings')
        self.audit_relations(f)
        require(all(b.support(x) <= set(self.current) for js in self.justices.values() for x in js), 'justice next support')

    def audit_relations(self, forms):
        b = self.b
        require(b.support(forms['thetaE']) <= set(self.ec), 'ENV initializer uses non-ENV bits')
        require(b.support(forms['thetaS']) <= set(self.current), 'SYS initializer next bits')
        require(b.support(forms['rhoE']) <= set(self.current) | set(self.en), 'ENV next SYS dependency')
        require(b.support(forms['rhoS']) <= set(self.current) | set(self.next), 'SYS relation support')
        require(b.conj(forms['thetaE'], b.neg(self.de)) == 0, 'ENV initializer admits invalid typed ENV')
        require(b.conj(forms['thetaS'], b.neg(self.ds)) == 0, 'SYS initializer admits invalid typed SYS')
        require(b.conj(forms['rhoE'], b.neg(self.den)) == 0, 'ENV relation admits invalid next ENV')
        require(b.conj(forms['rhoS'], b.neg(self.dsn)) == 0, 'SYS relation admits invalid next SYS')

    def load(self, ref):
        require(isinstance(ref, dict) and type(ref.get('file')) is str, 'saved BDD ref')
        name = ref['file']
        require(Path(name).name == name and name.endswith('.bdd'), 'saved BDD basename')
        if name in self.cache:
            require(ref == self.refs[name], 'conflicting repeated BDD metadata')
            return self.cache[name]
        p = self.directory / name
        require(p.stat().st_size == ref['bytes'], 'saved BDD bytes')
        if p.stat().st_size > LIMITS['saved_BDD_bytes']:
            raise ResourceRefusal('SAVED_BDD_BYTES')
        raw = p.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == ref['sha256'], 'saved BDD hash')
        u, info = self.b.read_native(raw)
        require(info['order'] is None or info['order'] == self.model['bdd_variable_order'], 'saved model BDD order')
        require(info['node_count'] == ref['node_count'] and type(ref['zero']) is bool
                and type(ref['one']) is bool and (u == 0) == ref['zero'] and (u == 1) == ref['one'], 'saved BDD metadata')
        require(sorted(self.b.support(u)) == ref['support'], 'saved BDD support metadata')
        self.cache[name], self.refs[name], self.pins[name] = u, ref, pin(p)
        return u

    def state(self, ref):
        u = self.load(ref)
        require(self.b.support(u) <= set(self.current), 'saved region next dependencies')
        require(self.b.conj(u, self.b.neg(self.q)) == 0, 'saved region outside typed carrier')
        return u


def source_bindings(row, model, frozen):
    src = CORPUS / 'original' / row['path']
    require(Path(model['input']['path']).samefile(src), 'model source path')
    p = pin(src)
    require(p['sha256'] == row['sha256'] == model['input']['sha256'] and p['bytes'] == row['bytes'] == model['input']['bytes'], 'top source identity')
    archive = frozen['public_archive']
    verify_pin(archive)
    todo, seen, bindings = [row['path']], set(), []
    with zipfile.ZipFile(archive['path']) as z:
        while todo:
            name = todo.pop()
            require(not name.startswith('/') and not name.startswith('../'), 'source import path')
            if name in seen:
                continue
            seen.add(name)
            raw = z.read(name)
            copy = CORPUS / 'original' / name
            require(copy.read_bytes() == raw, 'source/import differs from public archive')
            bindings.append({'entry': name, 'copy': pin(copy)})
            clean = re.sub(r'/\*.*?\*/|//[^\n]*', '', raw.decode('utf-8-sig'), flags=re.S)
            for target in re.findall(r'\bimport\s+["\']([^"\']+)["\']', clean):
                todo.append(posixpath.normpath(posixpath.join(posixpath.dirname(name), target)))
    return {'roster_row': row, 'public_archive': archive, 'source_imports': bindings}


def export_regions(path, m, regions):
    seen, stack = set(), list(regions.values())
    while stack:
        u = stack.pop()
        if u < 2 or u in seen:
            continue
        seen.add(u)
        stack.extend(m.b.nodes[u][1:])
    payload = {'schema': 'independent-canonical-robdd-region-set-v1', 'variable_count': m.b.n,
               'canonical_variable_order': list(range(m.b.n)), 'fields': m.fields,
               'roots': regions, 'nodes': [[u, *m.b.nodes[u]] for u in sorted(seen)]}
    with gzip.GzipFile(filename=str(path), mode='wb', mtime=0) as f:
        f.write(json.dumps(payload, separators=(',', ':'), ensure_ascii=False).encode())


def finite_compare(case, m, regions, quant, expected):
    d = BASE / 'kind_corpus_independent/runs' / case
    pins = [pin(d / n) for n in ('RESULT.json', 'REGIONS.json', 'TYPED_MODEL.json')]
    require(pins == expected, 'finite qualification outputs changed')
    result, r, typed = read(d / 'RESULT.json'), read(d / 'REGIONS.json'), read(d / 'TYPED_MODEL.json')
    require(result['status'] == 'PASS' and typed['fields'] == m.fields, 'finite PASS/schema qualification')
    states = {x['id']: x for x in typed['states']}
    cubes = {i: m.b.cube({int(k): v for k, v in x['current_bits'].items()}) for i, x in states.items()}
    checks = {k: m.b.disj(*(cubes[i] for i in r['regions'][k])) == u for k, u in regions.items()}
    checks.update({k + '_initial': quant[k]['value'] == r['initial_quantification'][k]['value'] for k in ('W', 'V', 'WV', 'K')})
    return {'all_equal': all(checks.values()), 'checks': checks, 'pins': pins}


def audit(case, version, destination, finite=False):
    started = time.monotonic()
    destination = Path(destination).resolve()
    require(destination.is_relative_to(HERE), 'output outside independent directory')
    destination.mkdir(parents=True, exist_ok=False)
    result = {'id': case, 'version': version, 'status': 'STARTED', 'phase': 'INPUT',
              'limits': LIMITS, 'native_runs': 0, 'full_resets': 0,
              'started_utc': datetime.now(timezone.utc).isoformat()}
    m = None
    try:
        signal.signal(signal.SIGALRM, alarm); signal.alarm(60)
        frozen = read(HERE / 'FROZEN.json')
        for p in frozen['checker_files']:
            verify_pin(p)
        result['freeze'] = pin(HERE / 'FROZEN.json')
        require(version in ('v1', 'v2'), 'input version')
        directory = BASE / ('kind_corpus' if version == 'v1' else 'kind_corpus_rle') / 'runs' / case
        original_pins = [pin(directory / n) for n in ('model.json', 'result.json', 'OUTCOME.json')]
        model, native, outcome = [read(directory / n) for n in ('model.json', 'result.json', 'OUTCOME.json')]
        require(outcome.get('outcome') == 'COMPLETE_SYMBOLIC_INDEPENDENT_PENDING'
                and outcome.get('worker_status') == 'PROCESS_COMPLETED'
                and native.get('status') == 'COMPLETE_CORPUS_REGION_PROBE'
                and native.get('regions_complete') is True and native.get('well_separation_complete') is True,
                'native export incomplete')
        if version == 'v2':
            capture = outcome.get('capture', {})
            require(capture.get('status') == 'PASS' and capture.get('cap_reached') is False
                    and capture.get('all_raw_bytes_recoverable') is True, 'v2 capture not qualified')
        require(native['model_export']['sha256'] == original_pins[0]['sha256'], 'native model pin')
        row = next(x for x in frozen['roster'] if x['id'] == case)
        require(model['fixture_id'] == native['fixture_id'] == outcome['id'] == case, 'fixture identity')
        result['source_bindings'] = source_bindings(row, model, frozen)
        result['input_pins'] = original_pins
        result['phase'] = 'MODEL_AUDIT'
        m = Model(directory, model)
        b, f = m.b, m.forms
        result.update(variable_count=b.n, carrier=m.carrier)
        require(str(m.carrier) == native['carrier_size'], 'native carrier size')
        ws = {k: m.load(native['WS_definition_' + k]) for k in ('thetaE', 'thetaS', 'rhoE', 'rhoS')}
        m.audit_relations(ws)
        require(ws['thetaE'] == f['thetaE'] and ws['rhoE'] == f['rhoE'], 'WS changes ENV semantics')
        require(b.conj(f['thetaS'], b.neg(ws['thetaS'])) == 0 and b.conj(f['rhoS'], b.neg(ws['rhoS'])) == 0,
                'WS SYS rewrite is not a weakening')
        aa, gg = m.justices['ENV'], m.justices['SYS']
        result['justice_normalization'] = {'original_ENV_count': len(aa), 'original_SYS_count': len(gg),
            'empty_ENV_replaced_by_typed_true': not aa, 'empty_SYS_replaced_by_typed_true': not gg,
            'Kind_guarantees': 'effective original SYS list followed by effective original ENV list',
            'Kind_current_and_successor_carrier': 'independently computed V', 'helper_added': False}
        require(native['normalization'] == {'V_current_and_next_restriction': True,
                'ENV_justice_copies': len(aa) or 1, 'helper_added': False}, 'native normalization declaration')
        result['phase'] = 'INDEPENDENT_FIXED_POINTS'
        regions, quant, logs = calculate(b, m.q, m.de, f['rhoE'], f['rhoS'], m.den, m.dsn,
            m.current, m.en, m.sn, m.prime, aa, gg, f['thetaE'], f['thetaS'],
            ws['thetaE'], ws['thetaS'], ws['rhoE'], ws['rhoS'])
        result['phase'] = 'COMPARE_SAVED_REGIONS'
        comparisons = {}
        for name, root in regions.items():
            if name == 'alive':
                # The producer saves raw exists E' rhoE, before intersecting D.
                # Validate that raw predicate exactly; only its typed slice is
                # a region of the scientific carrier.
                raw_alive = m.load(native[name])
                require(b.support(raw_alive) <= set(m.current), 'alive current support')
                require(raw_alive == b.exists(f['rhoE'], m.en), 'raw Alive predicate mismatch')
                supplied = b.conj(m.q, raw_alive)
            else:
                supplied = m.state(native[name])
            minus, plus = b.conj(root, b.neg(supplied)), b.conj(supplied, b.neg(root))
            comparisons[name] = {'equal': supplied == root, 'independent_count': count(b, root, m.current),
                'native_count': count(b, supplied, m.current), 'canonical_sha256': root_digest(b, root),
                'independent_minus_native_count': count(b, minus, m.current),
                'native_minus_independent_count': count(b, plus, m.current)}
            if name == 'alive':
                comparisons[name]['raw_predicate_exactly_verified_before_typed_projection'] = True
        boolean_checks, quant_result = {}, {}
        for name in ('W', 'V', 'WV', 'K'):
            got, meta = quant[name], native[name + '_original_initial_quantification']
            witness, missing = m.load(meta['system_witness']), m.load(meta['missing_environment_initials'])
            require(b.support(witness) <= set(m.current) and b.support(missing) <= set(m.ec), 'initial quantification supports')
            boolean_checks[name + '_initial_verdict'] = got['value'] == native[name + '_original_initial_quantified']
            boolean_checks[name + '_system_witness'] = got['system_witness'] == witness
            boolean_checks[name + '_missing_initials'] = got['missing_environment_initials'] == missing
            quant_result[name] = {'value': got['value'],
                'missing_environment_initial_count': count(b, got['missing_environment_initials'], m.ec),
                'system_witness_count': count(b, got['system_witness'], m.current)}
        boolean_checks['W_native_initial_verdict'] = quant['W']['value'] == native['W_initial_verdict']
        boolean_checks['WS_native_initial_verdict'] = quant['WS']['value'] == native['WS_native_initial_verdict']
        boolean_checks['initial_ENV_empty'] = (b.conj(m.de, f['thetaE']) == 0) == native['initial_ENV_empty']
        boolean_checks['initial_joint_empty'] = (regions['original_initialized'] == 0) == native['initial_joint_empty']
        ws_meta = native['well_separation']
        boolean_checks['definition_global_well_separated'] = (regions['WS_definition_reachable_NWS'] == 0) == ws_meta['definition_global_well_separated']
        boolean_checks['original_joint_restricted_well_separated'] = (regions['WS_original_reachable_NWS'] == 0) == ws_meta['original_joint_restricted_well_separated']
        result['raw_native_initial_verdicts_diagnostic_only'] = {k: native.get(k) for k in ('WV_native_initial_verdict', 'K_initial_verdict')}
        if finite:
            result['phase'] = 'FINITE_QUALIFICATION'
            expected = frozen['finite_PASS_inputs'][case]
            result['finite_qualification'] = finite_compare(case, m, regions, quant, expected)
        result['phase'] = 'INPUT_STABILITY'
        stable = original_pins + list(m.pins.values()) + [x['copy'] for x in result['source_bindings']['source_imports']] + [result['freeze']]
        for p in stable:
            verify_pin(p)
        all_equal = all(v['equal'] for v in comparisons.values()) and all(boolean_checks.values())
        if finite:
            all_equal = all_equal and result['finite_qualification']['all_equal']
        result.update(status='PASS' if all_equal else 'REGION_MISMATCH', phase='COMPLETE',
            comparisons=comparisons, boolean_checks=boolean_checks,
            counts={k: v['independent_count'] for k, v in comparisons.items()},
            initial_quantification=quant_result, bdd_pins=list(m.pins.values()), fixed_point_iterations=logs,
            initialized_ENV_count=count(b, b.conj(m.de, f['thetaE']), m.ec),
            well_separation={'definition_global_well_separated': regions['WS_definition_reachable_NWS'] == 0,
                             'original_joint_restricted_well_separated': regions['WS_original_reachable_NWS'] == 0},
            limitations=['Source/parser-translated BDDs and typed encodings are shared inputs; no independent Spectra compiler.',
                'Modified-WS AUX rewrite predicates are saved native inputs, checked for ENV equality and SYS weakening, not reconstructed from individual AUX formulas.',
                'Set-region certificate only; no extracted controller, runtime activation, or strategy certificate.',
                'Native completion/capture status is inherited from pinned OUTCOME; stdout decoding is not repeated here.',
                'Concurrent native JVM load makes timings unsuitable for performance claims.'])
        export_regions(destination / 'DERIVED_REGIONS.json.gz', m, regions)
        result['derived_region_export'] = pin(destination / 'DERIVED_REGIONS.json.gz')
    except TimeoutError as e:
        result.update(status='UNKNOWN_RESOURCE_TIMEOUT', reason=str(e))
    except ResourceRefusal as e:
        result.update(status='UNKNOWN_RESOURCE', reason=str(e))
    except MemoryError:
        result.update(status='UNKNOWN_RESOURCE_MEMORY', reason='Python memory allocation refused')
    except BaseException as e:
        result.update(status='FAIL_INTEGRITY', reason=repr(e), traceback=traceback.format_exc())
    finally:
        signal.alarm(0)
        if m is not None:
            result['allocated_BDD_nodes'] = len(m.b.nodes)
        result['elapsed_seconds'] = time.monotonic() - started
        result['finished_utc'] = datetime.now(timezone.utc).isoformat()
        result['checker'] = pin(__file__)
        save(destination / 'RESULT.json', result)
    print(json.dumps({k: result[k] for k in ('id', 'version', 'status', 'phase', 'reason', 'variable_count', 'carrier', 'elapsed_seconds') if k in result}), flush=True)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('case'); parser.add_argument('--version', choices=('v1', 'v2'), required=True)
    parser.add_argument('--destination', required=True); parser.add_argument('--finite', action='store_true')
    args = parser.parse_args()
    audit(args.case, args.version, args.destination, args.finite)
