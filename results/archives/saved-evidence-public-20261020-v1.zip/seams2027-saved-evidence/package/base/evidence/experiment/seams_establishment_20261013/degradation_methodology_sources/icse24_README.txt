README file for artifact evaluation of ISCE'24 paper

"Kind Controllers and Fast Heuristics for Non-Well-Separated GR(1) Specifications"

===========================
	PURPOSE
===========================

The goal of this artifact is to allow the reproduction of the experiments presented in the paper and summarized in Tables 1-4. It can be used in two ways:

1.	Run script files (files with "bat" extension) that produce the csv files with the raw data obtained from the experiments (the tables in the paper summarize the data in these files).

2.	Directly run the included JAR file, artifact.jar, on the included Spectra specifications (folders of files with the ".spectra" extension), or any other Spectra specifications.

We apply for the available and reusable badges. 


===========================
	PROVENANCE
===========================

The artifact is made available with an open BSD 3-Clause License in https://doi.org/10.5281/zenodo.8312832.

A version of the paper with appendices that include proofs is also available in this link. 


===========================
	Data
===========================

The datasets provided in this artifact contain all benchmarks described and used in the paper. This includes the Spectra datasets SYN15, SYN17, SYN20, and SYN23, as well as the AMBA and GEN-BUF benchmarks. Additional custom specifications can be added as well - see below.

The zip file contains two folders:
1.	raw_results: this folder contains the results of the experiments we have conducted, which are summarized in tables 1-4 of the paper. The folder contains a subfolder for each of the six research questions, and each subfolder contains a CSV file with the results for each corpus (SYN15, SYN17, SYN20, AND SYN23). The contents of the CSV files are explained in part 7.
2.	experiments: this folder contains tools that can be used to reproduce our results:
	2.1.	First, it contains the directory "specs" which contains all the Spectra specifications that we used. It contains a subdirectory for each corpus. Custom Spectra specifications can be added here. 
	2.2.	It contains the executable "artifact.jar", which can repeat the experiments with specified specifications and paramters. 
	2.3.	It contains BAT executables for each of the six experiments (where each experiment corresponds to one of the research questions RQ1-RQ6). The BAT files execute the JAR executable with predefined paramters (the ones that we have used in our experiments).

Remarks:

1.	The running times generated in the result files are measured in nanoseconds. The results may vary on different computers.

2.	The package was only tested on the Windows 10 and 11 operating systems. On different operating systems the package may not work or have different running times. We use a BDD dll called cudd3, which requires Windows and the Microsoft Visual C++ 2015 Redistributable (x64). If cudd3 fails the run may fail or revert to a different (pure Java based) BDD engine, which is significantly slower. 

3.	Running scripts on folders with many files may take much time (hours and days) to complete. We recommend artifact evaluation by running executables only on folder "syn15" as input, which contains small specifications.


===========================
	Setup
===========================

Software environment requirements:

*	Windows 10/11 operating system

*	Java JDK 21 or newer, 64Bit

*	Microsoft Visual C++ 2015 Redistributable (x64) available here: https://www.microsoft.com/en-us/download/details.aspx?id=48145

Note that most Windows 10/11 versions already include Microsoft Visual C++ 2015 Redistributable (x64) and thus there is typically no need to install it.

After these requirements are satisfied, the artifact can be extracted into a directory and is ready for execution. The usage is described below.  


===========================
        USAGE
===========================

In order to run the executable, open a command-line terminal in the directory "experiments" and issue the following command:

	java -jar artifact.jar <MODE> <PATHS> <REPEATS>

The parameter MODE has to be one of the following six strings, depending on the desired experiment:

	1. REDUCTION_COVER
	2. REDUCTION_TIME
	3. HEURISTIC_COVER
	4. HEURISTIC_TIME
	5. HEURISTIC_CORE_TIME
	6. HEURISTIC_DISTRIBUTION

The paramter PATHS specifies the directories of specifications to be used for the experiment. It should be a comma-separated list of paths. For example, to run the experiment on SYN15, this parameter should be "specs/syn15", and to run the experiment on all the benchmarks, use "specs/syn15,specs/syn17,specs/syn20,specs/syn23". 

The parameter REPEATS should only be used in experiments that measure running times (i.e. when using one of the modes REDUCTION_TIME, HEURISTIC_TIME, or HEURISTIC_CORE_TIME). This parameter specifies the number of times to run each algorithm on each specification. We used a value of 10 for this parameter. 

Example execution:

	java -jar artifact.jar REDUCTION_TIME specs/example 2

This will run the experiment for RQ1 on the specifications in the folder example, while diagnosing each specification 2 times with each of the algorithms (3FP, 4FP, and R+4FP). 


The execution of the JAR creates a CSV file with the results in direcory specified in the PATHS paramter. The name of the created file is "_results_<MODE>.csv". For example, the above command will generate the file "_results_reduction_time.csv" in each of the directories specs/syn15 and specs/syn17. 

Note that when using one of the modes REDUCTION_COVER, HEURISTIC_COVER, or HEURISTIC_DISTRIBUTION, the generated file contains the results of only the non-well-separated specifications. 


Executing the BAT files:

There are six BAT files included - one for each of the six modes. When each of these files is executed, it runs the JAR file with the appropriate MODE on each of the following specification benchmarks: specs/syn15, specs/syn17, specs/syn20, and specs/syn23. When the REPEATS parameter is required, the used value is 10. For example, executing the file "experiment_heuristic_time.bat" is equivalent to executing the following cammand in the terminal:

	java -jar artifact.jar HEURISTIC_TIME specs/syn15,specs/syn17,specs/syn20,specs/syn23 10


Results format:


The format of the generated CSV depends on the mode of the experiment.

--------------------------------
    REDUCTION_COVER (RQ1)  
--------------------------------

The generated file has a row for each specification in the corpus, and has three columns. The first column contains the name of the specification. The second column shows the result of the 4FP algorithm on the specification: TRUE indicates that the specification is realizable (by 4FP) and FALSE indicates that it is not realizable. The third column shows the result of the R+4FP algorithm on the specification.


--------------------------------
    REDUCTION_TIME (RQ2)
--------------------------------

The file has a row for each specification in the corpus. The number of columns in the file is 1+REPEATS*3. The first column displays the name of the specification. The next REPEATS columns show the time in nanoseconds it took the 3FP algorithm to diagnose the specification: each of the REPEATS columns correspond to one execution. The next REPEATS columns correspond to the 4FP algorithm, and the final REPEATS columns correspond to the R+4FP algorithm. 


--------------------------------
    HEURISTIC_COVER (RQ3)
--------------------------------

This file contains two columns - the first is the name of the specification, and the second is whether the specificaion was detected as NWS by the heuristics. 


--------------------------------
    HEURISTIC_TIME (RQ4)
--------------------------------

This file contains 1+REPEATS*4 columns. The first column shows the name of the specifications. The next REPEATS columns show the time in nanoseconds it took the previous WS diagnosis tool (by reduction to realizability) to diagnose the specifications. Each of the REPEATS columns correspond to a single execution. The second REPEATS columns display the execution time of the previous WS diagnosis tool when guarantees were considered. The third REPEATS columns display the execution time of the heuristics, and the final REPEATS columns displays the execution time of heuristics when guarantees were considered. 


-----------------------------------
    HEURISTIC_CORE_TIME (RQ5)
-----------------------------------

The format of this results file is identical to that of the previous, except that the displayed running times correspond to the computation time of core localization, rather than NWS detection. 


---------------------------------------
    HEURISTIC_DISTRIBUTION (RQ6)
---------------------------------------

This file contains five columns, where the first as usual displays the names of specifications. The next four columns correspond to each of the heuristics T1, T2, T3(basic), and T3(full). The cell for each heuristics displays "1" if that heuristic detected the specification as NWS, and "0" otherwise. For example, the row "ColorSortLTL2TAG_789_ColorSort.spectra,1,1,0,0" means that the specification ColorSortLTL2TAG_789_ColorSort.spectra is detected as NWS by the heuristics T1 and T2. 




