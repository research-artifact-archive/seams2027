"""Preparation is read-only on upstream inputs. Run requires exact Root authorization."""
import argparse,importlib.util,json,os,sys,time
from pathlib import Path
from datetime import datetime,timezone
sys.dont_write_bytecode=True
from evidence import B,CHECK,STAGE,select,read,save,pin,pins_in,unique,verify,require,now
MIN_START_SECONDS=75
CODE=('evidence.py','map_pair.py','relations.py','measure.py','run.py','qualify_math.py','qualify_authority.py','PROTOCOL_JA.txt','MATH_QUALIFICATION.json','AUTHORITY_QUALIFICATION.json')

def preserve_interrupted_attempt(value):
    if value.get('status')=='UNKNOWN_NOT_ATTEMPTED' and value.get('BDD_worker_started') is not False:value.update(status='UNKNOWN_RUNNER_FAILURE',reason='Worker start confirmed or uncertain before runner interruption')
    return value

def prepare():
    require(not (B/'FROZEN.json').exists() and not (B/'RUN_STARTED.json').exists(),'No frozen overwrite')
    if not (B/'SELECTION.json').exists():save(B/'SELECTION.json',select())
    selection=read(B/'SELECTION.json');verify(selection['input_pins'])
    for name in ('MATH_QUALIFICATION.json','AUTHORITY_QUALIFICATION.json'):
        q=read(B/name);require(q['status']=='PASS' and q['corpus_BDD_computations']==0 and q['native_runs']==0,'Synthetic qualification only');verify(q['source_pins'])
    code=[pin(B/name) for name in CODE]+[pin(CHECK/name) for name in ('generic_base.py','vendor/bdd_core.py','SOURCE_FREEZE.json')]
    code+=[pin(STAGE/'FROZEN.json')]+pins_in(read(STAGE/'FROZEN.json'))+[pin(Path(sys.executable).resolve())]
    code=unique(code);files=unique(code+selection['input_pins']+[pin(B/'SELECTION.json'),pin(B/'PEER_REVIEW.json')]+[p for row in selection['rows'] for p in row.get('input_pins',[])])
    verify(files)
    save(B/'FROZEN.json',{'schema':'helper-quadrant-freeze-v1','created_utc':now(),'files':files,'code_files':code,'python':pin(Path(sys.executable).resolve()),'selection':pin(B/'SELECTION.json'),
        'limits':{'native_and_common_variables':64,'nodes_per_BDD_manager':500000,'original_typed_carrier':4096,'job_typed_carrier':8192,'per_saved_BDD_bytes':8388608,'function_export_uncompressed_bytes':67108864,'case_wall_seconds':60,'workers':1},
        'parent_aborted':True,'root_review_status':'AWAITING_ROOT_REVIEW_NO_CORPUS_BDD_DISPATCH','native_runs':0,'corpus_BDD_computations':0})
    print(json.dumps({'status':'PREPARED_NO_CORPUS_BDD','fixed_cohort':14,'eligible':selection['eligible_count'],'files':len(files)}))

def validate_check(check,domain):
    require(type(check.get('equal')) is bool,'Relation equality Boolean')
    counts=check['counts'];require(set(counts)=={'actual','expected','difference','actual_only','expected_only'} and all(type(n) is int and 0<=n<=domain for n in counts.values()),'Exact relation counts')
    require(counts['difference']==counts['actual_only']+counts['expected_only'] and counts['actual']-counts['actual_only']==counts['expected']-counts['expected_only']>=0 and check['equal']==(counts['difference']==0),'Relation count/equality consistency')
    digests=check['canonical_sha256'];require(set(digests)=={'actual','expected','difference'} and all(type(v) is str and len(v)==64 and set(v)<=set('0123456789abcdef') for v in digests.values()),'Canonical digest shape')
    witnesses=check['typed_witnesses'];require(set(witnesses)=={'difference','actual_only','expected_only'},'Difference witness roster')
    for key,witness in witnesses.items():
        require((witness is None)==(counts[key]==0),'Witness iff nonempty difference')
        if witness is not None:
            require(isinstance(witness.get('current'),dict) and isinstance(witness.get('next'),dict) and set(witness['current'])==set(witness['next']),'Complete typed current/next witness')
            require(type(witness.get('actual_relation_value')) is bool and type(witness.get('expected_relation_value')) is bool and witness['actual_relation_value']!=witness['expected_relation_value'],'Witness separates actual/expected')

def validate_result(result,ident,row,freeze,decision):
    require(result.get('schema')=='helper-quadrant-case-v1' and result.get('id')==ident,'Case result identity')
    require(result.get('status') in ('PASS','UNKNOWN_RESOURCE','UNKNOWN_INTEGRITY'),'Unknown child status')
    require(result.get('root_authorization')==decision and result.get('parent_aborted') is True,'Child authorization scope')
    require(result.get('native_runs')==0 and result.get('full_reset_uses')==0 and result.get('winning_regions_computed') is False and result.get('released_route_loss_conclusion') is None and result.get('AUX_causal_attribution')=='UNKNOWN_NO_PER_CONSTRAINT_SEMANTIC_PROOF','No unproved scientific promotion')
    if result['status']=='PASS':
        require(result['original_model']==row['original_model'] and result['job_model']==row['job_model'] and result['native_result']==row['native_result'] and result['enclosing_native_parent']==row['parent_receipt'],'Exact prior model/native authority')
        expected=freeze['code_files']+row['input_pins']+[pin(B/'FROZEN.json'),pin(B/'SELECTION.json'),decision]
        require(result['input_pins']==expected,'Exact input/source/decision pins')
        comp=result['comparison'];require(type(comp['helper_added']) is bool and result['all_original_AUX_retained'] is True,'Typed helper/AUX scope')
        if comp['helper_added']:require([q['quadrant'] for q in comp['quadrants']]==['00','01','10','11'] and type(comp['literal_complete_relation_equal']) is bool and type(comp['corrected_complete_relation_equal']) is bool,'Complete four-quadrant result')
        else:require(comp['quadrants']==[] and comp['literal_complete_relation_equal'] is None and comp['corrected_complete_relation_equal'] is None and type(comp['no_helper_identity_equal']) is bool,'Separate no-helper identity result')
        require(type(result['typed_original_state_carrier']) is int and result['typed_original_state_carrier']>0 and comp['typed_original_edge_domain_count']==result['typed_original_state_carrier']**2,'Full typed original pair domain')
        domain=comp['typed_original_edge_domain_count']
        if comp['helper_added']:
            for quad in comp['quadrants']:
                require(set(quad['checks'])=={'ENV_literal_and_corrected','SYS_literal','SYS_corrected','joint_legal_edges_literal','joint_legal_edges_corrected'},'Every component and joint relation check')
                for check in quad['checks'].values():validate_check(check,domain)
            require(comp['literal_complete_relation_equal']==all(q['checks']['ENV_literal_and_corrected']['equal'] and q['checks']['SYS_literal']['equal'] for q in comp['quadrants']),'Literal full relation summary consistency')
            require(comp['corrected_complete_relation_equal']==all(q['checks']['ENV_literal_and_corrected']['equal'] and q['checks']['SYS_corrected']['equal'] for q in comp['quadrants']),'Corrected full relation summary consistency')
        else:
            require(set(comp['identity'])=={'ENV_identity','SYS_identity','joint_legal_edge_identity'},'No-helper identity check roster')
            for check in comp['identity'].values():validate_check(check,domain)
            require(comp['no_helper_identity_equal']==all(c['equal'] for c in comp['identity'].values()),'No-helper identity summary consistency')
        require(type(result['supplemental_full_current_checks']['all_equal']) is bool,'Supplemental full current-domain checks')
        verify([result['functions']])

def run(deadline):
    from measure import authorization
    decision=authorization();end=datetime.fromisoformat(deadline);require(end.tzinfo is not None,'Timezone-aware Root deadline')
    freeze=read(B/'FROZEN.json');verify(freeze['files']);require(freeze['python']==pin(Path(sys.executable).resolve()),'Frozen Python identity')
    selection=read(B/'SELECTION.json');require(selection['source_denominator']==425 and selection['fixed_small_cohort_count']==14,'Fixed cohort denominator')
    byid={row['id']:row for row in selection['rows']}
    require(not (B/'RUN_STARTED.json').exists() and not (B/'RUN_RECEIPT.json').exists(),'One dispatch only, no retries')
    sys.path.insert(0,str(STAGE));spec=importlib.util.spec_from_file_location('helper_quadrant_contained_stage',STAGE/'bounded_process.py');bounded=importlib.util.module_from_spec(spec);spec.loader.exec_module(bounded)
    with (B/'RUN_STARTED.json').open('x') as f:json.dump({'started_utc':now(),'owner_pid':os.getpid(),'freeze':pin(B/'FROZEN.json'),'root_authorization':decision},f)
    outputs={};outputrefs=[decision];stop=False;reasons=[];started=time.monotonic()
    try:
        for ident in selection['eligible_ids']:
            value={'id':ident,'status':'UNKNOWN_NOT_ATTEMPTED','BDD_worker_started':False};outputs[ident]=value
            if stop or (end-datetime.now(timezone.utc)).total_seconds()<MIN_START_SECONDS:continue
            verify(freeze['code_files']+[decision])
            if (end-datetime.now(timezone.utc)).total_seconds()<MIN_START_SECONDS:continue
            value['BDD_worker_started']=None;folder=B/'runs'/ident
            process=bounded.run_bounded([sys.executable,'-B',str(B/'measure.py'),ident],folder/'process',deadline,wall_seconds=60,file_bytes=67108864,watch_files=[folder/'RESULT.json',folder/'FUNCTIONS.json.gz'])
            value.update(BDD_worker_started=process['process_started'],process=pin(folder/'process/PROCESS_RECEIPT.json'));outputrefs.append(value['process'])
            if process['status']=='PROCESS_COMPLETED' and process['exit_code']==0 and (folder/'RESULT.json').exists():
                value['status']='UNKNOWN_INTEGRITY';result=read(folder/'RESULT.json');validate_result(result,ident,byid[ident],freeze,decision)
                value.update(status=result['status'],result=pin(folder/'RESULT.json'));outputrefs+=[value['result']]+pins_in(result)
                if result['status']=='PASS':value.update(helper_added=result['comparison']['helper_added'],relation_comparison=result['comparison'],supplemental_full_current_checks=result['supplemental_full_current_checks'])
                elif result['status']=='UNKNOWN_INTEGRITY':stop=True;reasons.append('CASE_INTEGRITY')
            else:
                value['status']='UNKNOWN_RESOURCE' if process['status']=='UNKNOWN_RESOURCE' else 'UNKNOWN_PROCESS'
                if value['status']=='UNKNOWN_PROCESS':stop=True;reasons.append('UNEXPECTED_WORKER_EXIT_OR_MISSING_RESULT')
            if process['status'].startswith('FATAL_'):stop=True;reasons.append('PROCESS_INTEGRITY')
            verify([decision]);save(B/'PROGRESS.json',{'finished':False,'rows':list(outputs.values()),'native_runs':0})
    except BaseException as error:stop=True;reasons.append(repr(error))
    try:verify(freeze['files']+outputrefs)
    except BaseException as error:stop=True;reasons.append('FINAL_PIN_INTEGRITY:'+repr(error))
    for value in outputs.values():preserve_interrupted_attempt(value)
    rows=[outputs.get(row['id'],{'id':row['id'],'status':'UNKNOWN_NOT_ATTEMPTED' if row['eligible'] else row['prior_status'],'BDD_worker_started':False,'in_fixed_small_cohort':row['in_fixed_small_cohort']}) for row in selection['rows']]
    receipt={'schema':'helper-quadrant-run-v1','finished_utc':now(),'elapsed_seconds':time.monotonic()-started,'source_denominator':425,'fixed_small_cohort_count':14,'eligible_count':selection['eligible_count'],'condition_context_without_selection':selection['condition_context_without_selection'],'rows':rows,
        'global_stop':stop,'stop_reasons':reasons,'root_authorization':decision,'parent_aborted':True,'unknown_is_negative':False,'native_runs':0,'full_reset_uses':0,'winning_regions_computed':False,'released_route_loss_conclusion':None,
        'AUX_causal_attribution':'UNKNOWN_NO_PER_CONSTRAINT_SEMANTIC_PROOF','BDD_worker_calls':{'confirmed':sum(v.get('BDD_worker_started') is True for v in rows),'uncertain':sum(v.get('BDD_worker_started') is None for v in rows)}}
    save(B/'RUN_RECEIPT.json',receipt);save(B/'RESULT_FILES.json',{'files':[pin(p) for p in sorted(B.rglob('*')) if p.is_file() and p.name!='RESULT_FILES.json']});print(json.dumps({'global_stop':stop,'BDD_worker_calls':receipt['BDD_worker_calls']}))

def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('select','prepare','preflight','run'));p.add_argument('--deadline-utc');args=p.parse_args()
    if args.mode=='select':require(not (B/'SELECTION.json').exists(),'No selection overwrite');save(B/'SELECTION.json',select());print('Selected closed fixed cohort; corpus BDD=0');return
    if args.mode=='prepare':prepare();return
    frozen=read(B/'FROZEN.json');verify(frozen['files'])
    if args.mode=='preflight':print(json.dumps({'status':'PASS_SOURCE_FREEZE','corpus_BDD_computations':0,'native_runs':0}));return
    require(args.deadline_utc is not None,'Root-specified deadline required');run(args.deadline_utc)
if __name__=='__main__':main()
