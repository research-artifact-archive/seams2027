"""Exact actual loss and separate literal-reference correspondence, no implicit equality."""
from evidence import L,load_module,require
from decomposition import symbolic
from imports import NAMES
literal_module=load_module('analysis044_frozen_literal_loss',L/'loss.py')
LiteralResourceRefusal=literal_module.ResourceRefusal

def add_references(out,args,independent,prior):
    b=args['b'];roots=out['roots'];w=roots['W_original'];reachable=independent['reachable']
    require(w==independent['W']==prior['W'],'Recomputed original W equals both full typed independent authorities')
    require(reachable==prior['original_reachable'],'Original existential reachable equals both full typed prior authorities')
    literal,quant,log=literal_module.compute(b,args['q'],args['de'],args['oe'],args['os'],args['den'],args['dsn'],
        args['current'],args['en'],args['sn'],args['prime'],args['oa'],args['og'],args['te'],args['ts'],w,reachable)
    differences={name:b.apply('xor',literal[name],prior[name]) for name in NAMES}
    require(all(u==0 for u in differences.values()),'Fresh literal region functions differ from their previously certified exact functions')
    require(roots['C']==literal['C'],'Decomposition complete totality C equals literal reference C')
    for name in NAMES:
        roots['prior_literal_'+name]=prior[name];roots['fresh_literal_'+name]=literal[name];roots['literal_authority_difference_'+name]=differences[name]
    roots.update(independent_original_W=independent['W'],independent_original_reachable=reachable,
        original_W_authority_difference=b.apply('xor',w,independent['W']),
        actual_original_reachable_loss=b.conj(reachable,roots['W_loss']),
        actual_W_F_xor_literal_W_C=b.apply('xor',roots['W_F'],literal['W_C']),
        actual_loss_xor_literal_loss=b.apply('xor',roots['W_loss'],literal['W_minus_W_C']))
    out['quant']['literal_W_C']=quant['W_C']
    roots['literal_W_C_initial_SYS_witness']=quant['W_C']['system_witness'];roots['literal_W_C_missing_initial_ENV']=quant['W_C']['missing_environment_initials']
    out['logs']['fresh_literal_W_C_correspondence']=log
    out['checks'].update(original_W_exact_authority_equal=True,original_reachable_exact_authority_equal=True,
        fresh_literal_all_functions_authority_equal=True,C_exact_literal_authority_equal=True,
        actual_W_F_equals_prior_literal_W_C=roots['actual_W_F_xor_literal_W_C']==0,
        actual_loss_equals_prior_literal_loss=roots['actual_loss_xor_literal_loss']==0)
    require(b.conj(roots['W_minus_F'],b.neg(roots['W_loss']))==0,'Actual immediate violation included in actual exact loss')
    require(roots['W_loss']==b.disj(roots['W_minus_F'],roots['delayed_loss']) and b.conj(roots['W_minus_F'],roots['delayed_loss'])==0,'Actual immediate/delayed loss disjoint partition')
    return {'fresh_literal_reference_correspondence':True,'recomputation_is_new_independent_case':False,
        'actual_W_F_to_literal_W_C_equality_is_observation':True,
        'original_reachable_definition':'Existential finite paths from every original thetaE and thetaS joint state under original rhoE and rhoS; no controller/policy/runtime interpretation',
        'original_reachability_reused_without_new_fixed_point':True,
        'literal_reference_definition':'C intersect Win(original rhoE, C(current) and rhoS and C(next)); original ordered justices and initializers retained'}
