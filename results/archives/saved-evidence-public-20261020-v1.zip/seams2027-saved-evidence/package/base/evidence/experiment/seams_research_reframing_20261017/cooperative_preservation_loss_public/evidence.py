"""Admit every completed exact-loss case; retain the whole 425/59/10/9 funnel."""
from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;E=B.parent;L=E/'preservation_loss_public';C=E/'preservation_condition_public'
spec=importlib.util.spec_from_file_location('cooperative_loss_prior_evidence',L/'evidence.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
S,N,CORPUS=prior.S,prior.N,prior.CORPUS
read,save,pin,pins_in,unique,verify,require,now=(getattr(prior,n) for n in ('read','save','pin','pins_in','unique','verify','require','now'))


def prior_case(done,old,freeze,authorization):
    """Metadata admission only; no BDD import or mathematical calculation."""
    ident=old['id'];verify([done['result'],done['process']])
    result=read(done['result']['path']);process=read(done['process']['path'])
    require(result['schema']=='preservation-loss-case-v1' and result['id']==ident and result['status']==done['status'],'Prior exact-loss identity/status')
    require(result['root_authorization']==authorization and result['parent_aborted'] is True,'Prior root authorization')
    require(result['native_runs']==0 and result['full_reset_uses']==0 and result['complete_semantic_literal_only'] is True,'Prior semantic scope')
    require(result['released_syntactic_loss_conclusion'] is None and result['runtime_or_controller_reachability_conclusion'] is None,'No transferred claims')
    require(done['BDD_worker_started'] is True and process['schema']=='contained-stage-process-v1','Prior worker scope')
    require(process['status']=='PROCESS_COMPLETED' and process['exit_code']==0 and process['process_started'] is True,'Prior enclosing process completion')
    require(process['owned_child_reaped'] is True and process['final_group_observation']['state']=='ABSENT','Prior contained process completion')
    require(process['argv'][-2:]==[str(L/'measure.py'),ident],'Prior process exact case binding')
    if result['status']=='PASS':
        require(result['original_independent_proof']==old['proof'] and result['original_independent_process']==old['process'],'Original independent authority')
        require(result['condition_proof']==old['condition_proof'] and result['condition_process']==old['condition_process'],'Condition authority')
        expected=freeze['code_files']+old['input_pins']+[pin(L/'FROZEN.json'),pin(L/'SELECTION.json'),authorization]
        require(result['input_pins']==expected,'Exact prior source/code/authorization pins')
        require(result['counts']==done['counts'] and result['initial_quantification']==done['initial_quantification'],'Prior parent/child counts')
        require(result['W_subset_C'] is False and result['full_region_preserved'] is False,'Prior exact-loss target')
        for name in ('W_minus_W_C','original_reachable'):
            require(type(result['counts'][name]) is int and result['counts'][name]>=0,'Prior typed count')
            require(isinstance(result['canonical_sha256'][name],str) and len(result['canonical_sha256'][name])==64,'Prior canonical function digest')
        verify([result['functions']])
    else:require(result['status']=='UNKNOWN_RESOURCE','Only documented resource-unknown remains outside exact-loss cohort')
    refs=unique(old['input_pins']+[done['result'],done['process']]+pins_in(result)+pins_in(process));verify(refs)
    return result,refs


def select():
    frozen=read(L/'FROZEN.json');receipt=read(L/'RUN_RECEIPT.json');selection=read(L/'SELECTION.json')
    require(receipt['schema']=='preservation-loss-run-v1' and receipt['global_stop'] is False and receipt['stop_reasons']==[],'Closed exact-loss study required')
    require(receipt['source_denominator']==425 and receipt['authoritative_W_and_C_count']==59 and receipt['condition_targeted_count']==10,'Fixed 425/59/10 input funnel')
    require(receipt['BDD_worker_calls']=={'confirmed':10,'uncertain':0} and receipt['unknown_is_negative'] is False,'All ten prior attempts accounted')
    require(receipt['parent_aborted'] is True and receipt['native_runs']==0,'Preserved stopped-parent context')
    verify(frozen['files']+[receipt['root_authorization']])
    decision=read(receipt['root_authorization']['path'])
    require(decision['start_authorized'] is True and decision['freeze']==pin(L/'FROZEN.json'),'Exact-loss root decision binding')
    require(frozen['selection']==pin(L/'SELECTION.json'),'Exact-loss selection binding')
    rebuilt=prior.select()
    strip=lambda d:{k:v for k,v in d.items() if k!='created_utc'}
    require(strip(rebuilt)==strip(selection),'Reconstructed all-ten condition selection')
    allrows=receipt['rows'];oldrows=selection['rows'];roster=read(CORPUS/'ROSTER.json')['unique_inputs']
    require(len(roster)==len(allrows)==len(oldrows)==425,'Whole source denominator')
    require([r['id'] for r in roster]==[r['id'] for r in allrows]==[r['id'] for r in oldrows],'Exact source order')
    refs=frozen['files']+[pin(L/'FROZEN.json'),pin(L/'RUN_RECEIPT.json'),pin(L/'SELECTION.json'),receipt['root_authorization']]
    rows=[];selected=[];unknown=[];prior_k=[]
    for source,done,old in zip(roster,allrows,oldrows):
        ident=source['id'];item={'id':ident,'source':source['path'],'prior_status':old['prior_status'],
            'condition_status':old['condition_status'],'condition_W_subset_C':old.get('condition_W_subset_C'),
            'exact_loss_status':done['status'],'eligible':False,'not_selected_reason':old['not_selected_reason']}
        if old['eligible']:
            require(done['status'] in ('PASS','UNKNOWN_RESOURCE'),'All-ten prior outcome whitelist')
            result,case_refs=prior_case(done,old,frozen,receipt['root_authorization']);refs+=case_refs
            proof=read(old['proof']['path'])
            require(proof['status']=='PASS' and proof['id']==ident and proof['version']=='v2','Original independent K proof')
            comparison=proof['comparisons']['K']
            require(comparison['equal'] is True and proof['counts']['K']==comparison['independent_count'],'Authoritative K count/function')
            require(isinstance(comparison['canonical_sha256'],str) and len(comparison['canonical_sha256'])==64,'Canonical independent K digest')
            require(type(proof['initial_quantification']['K']['value']) is bool,'Original K initializer metadata')
            prior_k.append({'id':ident,'K_count':proof['counts']['K'],'original_K_initial_quantification':proof['initial_quantification']['K'],'exact_loss_status':done['status']})
            item.update({k:old[k] for k in ('model','proof','process','independent_regions','condition_proof','condition_process')})
            item.update(loss_proof=done['result'],loss_process=done['process'],input_pins=case_refs,
                original_K_count=proof['counts']['K'],original_K_initial_quantification=proof['initial_quantification']['K'])
            if done['status']=='PASS':
                selected.append(ident);item.update(eligible=True,not_selected_reason=None,loss_functions=result['functions'])
            else:unknown.append(ident);item['not_selected_reason']='UNKNOWN_EXACT_LOSS_RESOURCE'
        else:require(done['status']==old['not_selected_reason'],'Outside-cohort status preserved')
        rows.append(item)
    require(len(selected)==9 and unknown==['corpus159__original'],'All nine exact-loss PASS and preserved resource unknown')
    refs=unique(refs);verify(refs)
    return {'schema':'cooperative-preservation-loss-selection-v1','created_utc':now(),
        'source_denominator':425,'authoritative_region_count':59,'condition_true_count':49,'condition_targeted_count':10,
        'completed_exact_loss_count':9,'exact_loss_resource_unknown_count':1,'exact_loss_resource_unknown_ids':unknown,
        'eligible_count':9,'eligible_ids':selected,'rows':rows,'parent_aborted':True,
        'selection_rule':'Every completed PASS among the ten condition-targeted exact-loss cases; no K size, K-initializer, intersection sign, or reachability filtering.',
        'selection_uses_K_or_intersection_sign':False,'prior_K_metadata_all_ten':prior_k,
        'prior_K_metadata_is_not_new_initial_calculation':True,'prior_loss_run':pin(L/'RUN_RECEIPT.json'),
        'input_pins':refs,'native_runs':0,'new_fixed_point_runs':0,'corpus_BDD_computations':0}
