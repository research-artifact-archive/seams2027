"""Read-only model-export regression. Does not certify incomplete solver runs."""
import importlib.util,json,math,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('initial_checker',HERE/'initial_graph_checker.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
rows=[]
for p in sorted((HERE.parent/'kind_corpus/runs').glob('*/model.json')):
    model=c.read_json(p); carrier=math.prod(f['domain_size'] for f in model['fields'])
    if carrier>4096:continue
    start=time.monotonic();row={'fixture':p.parent.name,'model_path':str(p),'model_sha256':c.sha(p),'carrier':carrier}
    try:
        profile=c.load_profile(p.parent.name);ctx=c.Context(p.parent,profile,model)
        row['model_audit']=ctx.audit_model();v,alive,rounds=ctx.viability()
        row.update(status='PASS',V_empty=v==0,V_fixed_point_iterations=rounds,original_ENV_initializer_empty=ctx.formulas['thetaE']==0)
        c.require(c.sha(p)==row['model_sha256'],'Model changed during regression')
    except Exception as e:row.update(status='FAIL',error=repr(e))
    row['elapsed_seconds']=time.monotonic()-start;rows.append(row)
result={'status':'PASS' if all(r['status']=='PASS' for r in rows) else 'FAIL','native_runs':0,'model_exports':len(rows),
        'checker_sha256':c.sha(HERE/'initial_graph_checker.py'),'script_sha256':c.sha(Path(__file__)),
        'scope':'Saved complete model exports only; no claim that originating solver runs completed or graphs were exported.', 'cases':rows}
(HERE/'SAVED_MODEL_REGRESSION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
