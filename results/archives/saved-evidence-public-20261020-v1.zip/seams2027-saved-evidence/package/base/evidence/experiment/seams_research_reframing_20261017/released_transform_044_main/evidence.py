"""Fixed044 model-only main with an independently closed three-case qualification."""
from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;E=B.parent;P=E/'released_transform_probe_public';R=E/'released_transform_saved_recovery';Q=E/'released_transform_093_qualification';H=E/'helper_quadrant_public'
ID='corpus044__original';MODES=('original','released')
def load_module(name,path,evidence=None):
    prior=sys.modules.get('evidence')
    if evidence is not None:sys.modules['evidence']=evidence
    try:
        s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
    finally:
        if evidence is not None:
            if prior is None:sys.modules.pop('evidence',None)
            else:sys.modules['evidence']=prior
probe=load_module('main044_frozen_probe_evidence',P/'evidence.py')
recovery=load_module('main044_frozen_recovery_evidence',R/'evidence.py')
bridge=load_module('main044_frozen_trace_bridge',R/'trace_bridge.py',recovery)
qualification=load_module('main044_frozen_093_evidence',Q/'evidence.py')
read,save,pin,pins_in,unique,verify,require,now=(getattr(probe,n) for n in ('read','save','pin','pins_in','unique','verify','require','now'))
CORPUS,RLE,JOB,STAGE,RECOVERY,CHECK=probe.CORPUS,probe.RLE,probe.JOB,probe.STAGE,probe.RECOVERY,probe.CHECK

def closed_qualification():
    saved,srefs=qualification.closed_recovery();receipt=read(Q/'RUN_RECEIPT.json');joined=read(Q/'JOINED_QUALIFICATION.json');freeze=read(Q/'FROZEN.json')
    require(receipt['schema']=='fresh093-transform-qualification-run-v1' and receipt['status']=='PASS_093_MODEL_QUALIFICATION' and receipt['global_stop'] is False and not receipt['stop_reasons'],'Separate093 qualification closed PASS')
    calls=receipt['native_JVM_calls'];require(all(type(v) is int for v in calls.values()) and calls=={'confirmed':2,'uncertain':0,'not_called':0},'Exactly two completed093 model probes')
    require(len(receipt['rows'])==1 and receipt['rows'][0]['id']=='corpus093__original' and receipt['rows'][0]['status']=='PASS','Exact fixed093 closed row')
    require(receipt['freeze']==pin(Q/'FROZEN.json') and receipt['saved_recovery']==pin(R/'RUN_RECEIPT.json'),'Exact093 freeze and saved-recovery provenance')
    decision=receipt['root_authorization'];d=read(decision['path'])
    require(decision==pin(Q/'ROOT_START_DECISION.json') and d['start_authorized'] is True and d['scope']=='MODEL_ONLY_093_PAIR' and d['freeze']==pin(Q/'FROZEN.json'),'Exact093 root start decision')
    for k in ('solver_calls','controller_calls','full_reset_uses'):require(type(receipt[k]) is int and receipt[k]==0,'Qualification exact zero '+k)
    require(receipt['old_global_stop_preserved'] is True and receipt['v1_resumed'] is False and receipt['main044_authorized'] is False,'No inherited main authority')
    require(joined['schema']=='three-case-transform-qualification-join-v1' and joined['status']=='PASS_THREE_FIXED_QUALIFICATION_CASES' and joined['ids']==['guard','corpus032__original','corpus093__original'],'Exact three fixed qualifications')
    require(joined['guard_and032_saved_recovery']==pin(R/'RUN_RECEIPT.json') and joined['fresh093_qualification']==pin(Q/'RUN_RECEIPT.json'),'Join binds exact closed receipts')
    require(joined['old_global_stop_preserved'] is True and joined['old_qualification_relabelled'] is False and joined['main044_authorized'] is False,'Join does not reopen v1 or authorize main')
    refs=unique(srefs+freeze['files']+receipt['output_pins']+[pin(Q/n) for n in ('FROZEN.json','RUN_RECEIPT.json','JOINED_QUALIFICATION.json')]);verify(refs)
    return joined,refs

def select():
    joined,refs=closed_qualification();pf=read(P/'FROZEN.json');ps=read(P/'SELECTION.json');case=ps['cases'][ID]
    hf=read(H/'FROZEN.json');hm=read(H/'MATH_QUALIFICATION.json');require(hm['status']=='PASS','Prior qualified relation mathematics')
    for name in ('map_pair.py','relations.py','measure.py','qualify_math.py','MATH_QUALIFICATION.json'):require(pin(H/name) in hf['files'],'Exact previously frozen relation source '+name)
    verify(hf['files']+hm['source_pins']);refs=unique(refs+hf['files']+[pin(H/'FROZEN.json')])
    require(ps['main_ids']==[ID] and ps['selection_uses_prior_mathematical_outcome'] is True and ps['original_K_zero_is_scope_boundary_not_selection_filter'] is True,'Prior outcome-informed fixed044 selection; no reselection')
    flips=ps['prior_initial_flip_cases'];require([(r['id'],r['carrier']) for r in flips]==[('corpus044__original',18816),('corpus045__original',102400),('corpus046__original',301056)],'Three original initial-flip cases in original fixed order')
    K_boundary=[]
    for row in flips:
        ref=pin(E/'kind_corpus_symbolic_independent/runs/v2'/row['id']/'RESULT.json');proof=read(ref['path'])
        require(proof['id']==row['id'] and proof['status']=='PASS' and proof['carrier']==row['carrier'] and type(proof['counts']['K']) is int and proof['counts']['K']==0 and proof['initial_quantification']['K']['value'] is False,'Each previously selected initial flip has independently reported K0')
        require(ref in pf['files'],'Prior independent K proof already in original frozen evidence')
        K_boundary.append({'id':row['id'],'K_count':0,'K_initial_verdict':False,'proof':ref})
    require(case['released_reference_directory'] is None and case['original_K_count']==0 and case['original_K_initial_verdict'] is False,'No old released044 reference; K0 scope boundary')
    old=read(P/'QUALIFICATION.json');require(old['global_stop'] is True and not (P/'main').exists(),'Stopped v1 unchanged and main never started')
    scope=read(B/'SOURCE_SCOPE.json');require(scope['id']==ID and scope['status']=='PASS_SOURCE_METADATA_ONLY' and scope['corpus_BDD_computations']==0 and scope['new_native_JVM_calls']==0,'Specific044 closure/trace metadata preparation')
    refs=unique(refs+pf['files']+case['input_pins']+scope['input_pins']+[pin(P/'FROZEN.json'),pin(P/'QUALIFICATION.json'),pin(B/'SOURCE_SCOPE.json')]);verify(refs)
    return {'schema':'fixed044-transform-main-selection-v1','created_utc':now(),'id':ID,'case':case,'input_pins':refs,
        'joined_qualification':pin(Q/'JOINED_QUALIFICATION.json'),'fresh093_qualification':pin(Q/'RUN_RECEIPT.json'),'saved_recovery':pin(R/'RUN_RECEIPT.json'),'stopped_v1_qualification':pin(P/'QUALIFICATION.json'),
        'selection_rule':ps['selection_rule'],'prior_initial_flip_cases':flips,'prior_K_scope_boundary':K_boundary,'outcome_informed_fixed_selection':True,'reselection_performed':False,'original_K_zero_is_scope_boundary_not_selection_filter':True,
        'old_global_stop_preserved':True,'new_native_JVM_calls':0,'new_solver_calls':0,'new_controller_calls':0,
        'scope':'Fixed044 model-only original/released pair and exact relation audit; no U/F/direct strict-W or controller analysis.'}

def authorization():
    ref=pin(B/'ROOT_START_DECISION.json');d=read(ref['path']);selected=read(B/'SELECTION.json')
    require(d.get('start_authorized') is True and d.get('scope')=='MODEL_ONLY_044_PAIR' and d.get('freeze')==pin(B/'FROZEN.json'),'Separate exact044 model-only authorization')
    require(d.get('joined_qualification')==selected['joined_qualification']==pin(Q/'JOINED_QUALIFICATION.json'),'Successful joined three-case qualification prerequisite bound')
    require(type(d.get('native_JVM_budget')) is int and d['native_JVM_budget']==2 and type(d.get('solver_budget')) is int and d['solver_budget']==0,'Exactly two model-only JVMs; zero solver')
    verify([ref]);closed_qualification();return ref

def native_sources(freeze,case,decision):
    return unique(probe.native_sources(freeze,case,decision)+[pin(B/'FROZEN.json'),pin(Q/'JOINED_QUALIFICATION.json'),pin(Q/'RUN_RECEIPT.json')])

def native_refs(folder,case,mode,decision,freeze):
    refs=probe.native_receipt_refs(folder,case,mode,decision,freeze);parent=read(Path(folder)/'PARENT_RECEIPT.json')
    require(all(x in parent['source_pins'] for x in native_sources(freeze,case,decision)),'New044 freeze and qualification evidence included at producer launch')
    return refs

def old_checker():return load_module('main044_frozen_model_checker',P/'check_exports.py',probe)
def old_schedule():return load_module('main044_frozen_schedule',P/'run.py',probe).execute_cases
