"""Typed lifts of certified original W and prior complete-semantic loss functions."""
import gzip,importlib.util,json,sys
sys.dont_write_bytecode=True
from evidence import C,require
from decomposition import ResourceRefusal
import import_original as original
load_original_w=original.load;ImportResourceRefusal=original.ImportResourceRefusal
NAMES=('W','C','W_C','W_minus_C','W_minus_W_C','delayed_loss','original_reachable','original_reachable_loss')

def import_loss_payload(pair,payload,proof):
    require(payload['schema']=='complete-semantic-preservation-loss-robdd-v1','Prior complete-semantic loss schema')
    fields=payload['fields'];require(isinstance(fields,list),'Prior loss full typed field list')
    expected={
        'current_bits':[v for f in fields for v in f['current_bits']],
        'ENV_current_bits':[v for f in fields if f['owner']=='ENV' for v in f['current_bits']],
        'SYS_and_AUX_current_bits':[v for f in fields if f['owner']=='SYS' for v in f['current_bits']],
        'ENV_next_bits':[v for f in fields if f['owner']=='ENV' for v in f['next_bits']],
        'SYS_and_AUX_next_bits':[v for f in fields if f['owner']=='SYS' for v in f['next_bits']]}
    for key,values in expected.items():
        require(all(type(v) is int for v in payload[key]) and len(payload[key])==len(set(payload[key])) and set(payload[key])==set(values),'Complete loss phase/ownership metadata '+key)
    roots={};audits={}
    for name in NAMES:
        require(name in payload['roots'] and type(proof['counts'][name]) is int,'Closed loss root and count '+name)
        view={**payload,'schema':'independent-canonical-robdd-region-set-v1','roots':{'W':payload['roots'][name]}}
        authority={'counts':{'W':proof['counts'][name]},'comparisons':{'W':{'equal':True,
            'independent_count':proof['counts'][name],'canonical_sha256':proof['canonical_sha256'][name]}}}
        roots[name],audits[name]=original.import_payload(pair,view,authority)
    return roots,{'method':'Unchanged typed full-field importer applied to each prior exact-loss root after schema/ownership audit',
        'all_original_AUX_retained':True,'canonical_source_proof_checked_before_semantic_lift':True,'roots':audits}

def load_loss(pair,path,proof):
    with gzip.open(path,'rb') as f:raw=f.read(64*1024*1024+1)
    if len(raw)>64*1024*1024:raise ResourceRefusal('Prior exact-loss canonical export cap64MiB')
    return import_loss_payload(pair,json.loads(raw,object_pairs_hook=original.condition.engine.unique),proof)


def load_original_regions(pair,path,proof,names=('W','reachable')):
    with gzip.open(path,'rb') as f:raw=f.read(64*1024*1024+1)
    if len(raw)>64*1024*1024:raise ResourceRefusal('Independent region export cap64MiB')
    payload=json.loads(raw,object_pairs_hook=original.condition.engine.unique);roots={};audits={}
    for name in names:
        require(name in payload['roots'] and proof['comparisons'][name]['equal'] is True and type(proof['counts'][name]) is int and type(proof['comparisons'][name]['independent_count']) is int,'Certified original region/count '+name)
        view={**payload,'roots':{'W':payload['roots'][name]}}
        authority={'counts':{'W':proof['counts'][name]},'comparisons':{'W':proof['comparisons'][name]}}
        roots[name],audits[name]=original.import_payload(pair,view,authority)
    return roots,{'method':'Unchanged full-field typed importer for independently certified original W and existential reachable',
        'all_original_AUX_retained':True,'roots':audits}
