"""Read-only admission of the 59 previously authoritative independent cases."""
from pathlib import Path
import hashlib,json,sys
from datetime import datetime,timezone
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;E=B.parent
S=E/'kind_corpus_symbolic_independent';N=E/'kind_corpus_rle';CORPUS=E/'kind_corpus'
def require(ok,text):
    if not ok:raise ValueError(text)
def unique_json(pairs):
    out={}
    for k,v in pairs:require(k not in out,'Duplicate JSON key');out[k]=v
    return out
def read(p):return json.loads(Path(p).read_text(),object_pairs_hook=unique_json)
def now():return datetime.now(timezone.utc).isoformat()
def save(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_name(p.name+'.tmp')
    t.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n');t.replace(p)
def pin(p):
    p=Path(p).resolve();h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def pins_in(x):
    if isinstance(x,dict):
        if set(x)>={'path','bytes','sha256'}:
            return [{k:x[k] for k in ('path','bytes','sha256')}] if Path(x['path']).is_absolute() else []
        return [p for value in x.values() for p in pins_in(value)]
    return [p for value in x for p in pins_in(value)] if isinstance(x,list) else []
def unique(refs):
    out={}
    for p in refs:
        require(str(Path(p['path']).resolve())==p['path'],'Canonical absolute pin')
        require(p['path'] not in out or out[p['path']]==p,'Conflicting pin');out[p['path']]=p
    return list(out.values())
def verify(refs):
    for p in unique(refs):require(pin(p['path'])==p,'Changed pinned evidence: '+p['path'])

def select():
    audit=read(S/'STOP_CASE_FACTS_AUDIT.json');stop=read(S/'STOP_ACK.json');follow=read(S/'FOLLOW.json')
    require(audit['authoritative_completed_PASS_cases']==59 and audit['fixed_population']==425 and audit['root_global_stop'] is True,'Stopped audit identity')
    require(audit['stop_ack']==pin(S/'STOP_ACK.json') and audit['follow']==pin(S/'FOLLOW.json'),'Stopped audit binding')
    parent=read(N/'RUN_RECEIPT.json');require(parent['global_stop'] is True and parent['pin_errors']==[],'Preserved native parent stop')
    require(stop['root_receipt']==pin(N/'RUN_RECEIPT.json'),'Native parent receipt identity')
    roster=read(CORPUS/'ROSTER.json')['unique_inputs'];fr=follow['rows']
    require(len(roster)==len(fr)==425 and [r['id'] for r in roster]==[r['id'] for r in fr],'Fixed denominator/order')
    chosen=stop['authoritative_completed_PASS_cases'];byid={r['id']:r for r in chosen}
    require(len(chosen)==len(byid)==59 and set(byid)=={r['id'] for r in fr if r['status']=='PASS'},'All available authoritative certificates')
    audit_process={p['path']:p for p in audit['process_receipts']};rows=[];refs=[]
    for row,prior in zip(roster,fr):
        ident=row['id'];item={'id':ident,'source':row['path'],'eligible':ident in byid,'prior_status':prior['status']}
        if ident in byid:
            bound=byid[ident];proof=read(bound['child']['path']);process=read(bound['process']['path']);d=N/'runs'/ident
            model=read(d/'model.json');native=read(d/'result.json');worker=read(d/'NATIVE_WORKER_RECEIPT.json')
            require(audit_process.get(bound['process']['path'])==bound['process'],'Process missing from stopped case audit')
            require(proof['id']==process['id']==model['fixture_id']==native['fixture_id']==ident,'Case identity')
            require(proof['version']==process['version']=='v2' and proof['status']==process['status']=='PASS','Authoritative v2 PASS')
            require(process['hard_timeout'] is False and process['process_exit_code']==0 and process['child_result']==bound['child'],'Enclosing process authority')
            require(pin(d/'model.json') in proof['input_pins'] and pin(d/'result.json') in proof['input_pins'],'Certificate/model/native binding')
            require(proof['source_bindings']['roster_row']==row and model['input']['sha256']==row['sha256'],'Source roster identity')
            require(proof['comparisons']['W']['equal'] is True and proof['counts']['W']==proof['comparisons']['W']['independent_count'],'Certified independent W')
            require(worker['status']=='PROCESS_COMPLETED' and worker['returncode']==0 and worker['child_reaped'] is True and worker['process_group_contained'] is True,'Native process completed')
            for name in ('model.json','result.json'):
                require(worker['artifacts'][name]==pin(d/name),'Native worker artifact binding')
            case_refs=unique([bound['child'],bound['process']]+pins_in(proof)+pins_in(worker)+
                [pin(d/n) for n in ('NATIVE_WORKER_RECEIPT.json','NATIVE_CHILD_IDENTITY.json','RLE_CAPTURE_VERIFICATION.json','RLE_STDOUT_RECEIPT.json')])
            verify(case_refs);refs+=case_refs
            item.update(model=pin(d/'model.json'),proof=bound['child'],process=bound['process'],
                        independent_regions=proof['derived_region_export'],input_pins=case_refs)
        rows.append(item)
    refs += [pin(p) for p in (S/'STOP_CASE_FACTS_AUDIT.json',S/'STOP_ACK.json',S/'FOLLOW.json',N/'RUN_RECEIPT.json',CORPUS/'ROSTER.json')]
    for p in (S/'FROZEN.json',N/'FROZEN.json',CORPUS/'FROZEN.json'):
        refs += [pin(p)]+pins_in(read(p))
    refs=unique(refs);verify(refs)
    return {'schema':'preservation-condition-selection-v1','created_utc':now(),'source_denominator':425,
        'eligible_count':59,'eligible_ids':[r['id'] for r in rows if r['eligible']],'rows':rows,
        'selection_rule':'All 59 available authoritative independent v2 PASS certificates; no region sign or mathematical outcome filtering.',
        'selection_uses_region_size_or_sign':False,'parent_aborted':True,'parent_receipt':pin(N/'RUN_RECEIPT.json'),
        'input_pins':refs,'native_runs':0,'corpus_BDD_computations':0}
