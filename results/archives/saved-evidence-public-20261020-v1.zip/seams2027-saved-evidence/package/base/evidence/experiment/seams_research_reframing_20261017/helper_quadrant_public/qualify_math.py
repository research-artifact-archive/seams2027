"""Independent synthetic truth tables and typed-lift negative controls only."""
from itertools import product
from types import SimpleNamespace
from unittest.mock import patch
import copy,json
from evidence import B,save,pin,require,now
from map_pair import BDD,build,base
from relations import compare

tests=[];arenas=0
def test(name,fn):
    try:fn();tests.append({'name':name,'pass':True})
    except Exception as error:tests.append({'name':name,'pass':False,'error':repr(error)})
def field(name,owner,role,cb,nb,values=None,codes=None):
    values=values or ['false','true'];codes=codes or [(False,),(True,)]
    return {'name':name,'owner':owner,'role':role,'domain_size':len(values),'values':values,'current_bits':cb,'next_bits':nb,
        'encoding':{value:{'current':{str(bit):code[i] for i,bit in enumerate(cb)},'next':{str(bit):code[i] for i,bit in enumerate(nb)}} for value,code in zip(values,codes)}}
def table(b,variables,truth):
    return b.disj(*(b.cube(dict(zip(variables,values))) for values in product((False,True),repeat=len(variables)) if truth(dict(zip(variables,values)))))
F=[field('e','ENV','ENV',[0],[2]),field('y','SYS','SYS',[1],[3])]
def main_compare(b,oe,os,je,js,mask=1,fields=F,current=(0,1),nxt=(2,3),hb=4,hp=5):
    return compare(b,mask,oe,os,je,js,hb,hp,current,nxt,fields)[0]
def check_counts(summary,etruth,struth,jetruth,jstruth,valid=lambda a:True):
    assignments=[dict(zip(range(4),v)) for v in product((False,True),repeat=4)]
    for row in summary['quadrants']:
        bv,bp=row['helper_current'],row['helper_next']
        expected={name:[] for name in row['checks']}
        for a in assignments:
            if not valid(a):continue
            actuale=jetruth(a,bv,bp);actuals=jstruth(a,bv,bp)
            ee=(etruth(a) or bp) and (not bv or bp);sl=struth(a) or bv;sc=struth(a) or bv or bp
            pairs={'ENV_literal_and_corrected':(actuale,ee),'SYS_literal':(actuals,sl),'SYS_corrected':(actuals,sc),
                'joint_legal_edges_literal':(actuale and actuals,ee and sl),'joint_legal_edges_corrected':(actuale and actuals,ee and sc)}
            for name,pair in pairs.items():expected[name].append(pair)
        for name,pairs in expected.items():
            counts={'actual':sum(a for a,e in pairs),'expected':sum(e for a,e in pairs),'difference':sum(a!=e for a,e in pairs),
                    'actual_only':sum(a and not e for a,e in pairs),'expected_only':sum(e and not a for a,e in pairs)}
            require(row['checks'][name]['counts']==counts,'Independent enumerated counts differ '+row['quadrant']+' '+name)
            require(row['checks'][name]['equal']==(counts['difference']==0),'Equality/count discrepancy')
            for key in ('difference','actual_only','expected_only'):
                w=row['checks'][name]['typed_witnesses'][key]
                require((w is None)==(counts[key]==0),'Witness iff nonempty difference')
                if w:
                    require(set(w['current'])=={'e','y'} and set(w['next'])=={'e','y'},'Typed current/next witness omitted fields')
                    require(w['actual_relation_value']!=w['expected_relation_value'],'Witness values not different')

def exhaustive_reference_relations():
    global arenas
    for em,sm,corrected in product(range(16),range(16),(False,True)):
        e=lambda a:bool(em>>(int(a[0])*2+int(a[2]))&1)
        s=lambda a:bool(sm>>(int(a[1])*2+int(a[3]))&1)
        je=lambda a,b,p:(e(a) or p) and (not b or p)
        js=lambda a,b,p:s(a) or b or (p if corrected else False)
        b=BDD(6);oe=table(b,range(4),e);os=table(b,range(4),s)
        actuale=table(b,range(6),lambda a:je(a,a[4],a[5]));actuals=table(b,range(6),lambda a:js(a,a[4],a[5]))
        out=main_compare(b,oe,os,actuale,actuals);check_counts(out,e,s,je,js)
        require(out['corrected_complete_relation_equal'] if corrected else out['literal_complete_relation_equal'],'Known complete relation not identified')
        arenas+=1
test('all_16_ENV_by_16_SYS_small_relations_literal_and_corrected',exhaustive_reference_relations)

def arbitrary_job_quadrants():
    global arenas
    e=lambda a:a[0]==a[2];s=lambda a:a[1]!=a[3]
    for em,sm in product(range(16),repeat=2):
        je=lambda a,b,p:bool(em>>(int(b)*2+int(p))&1);js=lambda a,b,p:bool(sm>>(int(b)*2+int(p))&1)
        b=BDD(6);oe=table(b,range(4),e);os=table(b,range(4),s)
        out=main_compare(b,oe,os,table(b,range(6),lambda a:je(a,a[4],a[5])),table(b,range(6),lambda a:js(a,a[4],a[5])))
        check_counts(out,e,s,je,js);arenas+=1
test('all_256_arbitrary_constant_job_quadrant_pairs',arbitrary_job_quadrants)

def impossible_env_keeps_sys_difference():
    b=BDD(6);oe=1;os=b.var(3);hb=b.var(4);hp=b.var(5)
    je=b.disj(b.neg(hb),hp);js=b.conj(b.disj(os,hb),b.neg(b.conj(hb,b.neg(hp))))
    out=main_compare(b,oe,os,je,js)
    require(not out['literal_complete_relation_equal'] and out['literal_legal_joint_equal'],'Illegal-ENV quadrant SYS difference was hidden')
    q=next(x for x in out['quadrants'] if x['quadrant']=='10')
    require(q['checks']['SYS_literal']['counts']['difference']==16 and q['checks']['joint_legal_edges_literal']['equal'],'Quadrant10 semantics')
test('quadrant10_SYS_difference_separate_from_legal_joint_edges',impossible_env_keeps_sys_difference)

def typed_aux_domain():
    fields=[field('mode','ENV','ENV',[0,1],[4,5],['a','b','c'],[(False,False),(True,False),(False,True)]),field('y','SYS','SYS',[2],[6]),field('memory','SYS','AUX',[3],[7])]
    b=BDD(10);mask=b.conj(b.neg(b.conj(b.var(0),b.var(1))),b.neg(b.conj(b.var(4),b.var(5))))
    oe=1;os=b.iff(b.var(7),b.var(6));hb=b.var(8);hp=b.var(9)
    je=b.disj(b.neg(hb),hp);js=os
    out=compare(b,mask,oe,os,je,js,8,9,(0,1,2,3),(4,5,6,7),fields)[0]
    require(out['typed_original_edge_domain_count']==144,'Ternary typed edge count')
    require(out['AUX_causal_attribution']=='UNKNOWN_NO_PER_CONSTRAINT_SEMANTIC_PROOF','Unsupported AUX attribution')
    w=next(x for x in out['quadrants'] if x['quadrant']=='11')['checks']['SYS_literal']['typed_witnesses']['difference']
    require(w is not None and set(w['current'])==set(w['next'])=={'mode','y','memory'},'AUX witness was projected')
    require(w['current']['mode'] in ('a','b','c') and w['next']['mode'] in ('a','b','c'),'Invalid encoding escaped mask')
test('ternary_typed_masks_all_AUX_and_noncausal_difference_witness',typed_aux_domain)

def identity_branch():
    b=BDD(4);e=b.iff(b.var(0),b.var(2));s=b.iff(b.var(1),b.var(3))
    out=main_compare(b,e,s,e,s,hb=None,hp=None)
    require(out['quadrants']==[] and out['literal_complete_relation_equal'] is None and out['no_helper_identity_equal'],'No-helper confused with helper match')
    out=main_compare(b,e,s,e,b.neg(s),hb=None,hp=None)
    require(out['no_helper_identity_equal'] is False,'No-helper difference hidden')
test('nohelper_identity_has_no_four_quadrant_PASS',identity_branch)

class TinyContext:
    def __init__(self,fields,formulas,n):
        self.fields=fields;self.by_name={f['name']:f for f in fields};self.b=BDD(n);self.enc={};self.current=[];self.next=[];self.prime={};self.carrier=1
        for f in fields:
            self.current+=f['current_bits'];self.next+=f['next_bits'];self.prime.update(zip(f['current_bits'],f['next_bits']));self.carrier*=len(f['values'])
            self.enc[f['name']]={v:tuple({int(k):x for k,x in f['encoding'][v][phase].items()} for phase in ('current','next')) for v in f['values']}
        self.domain=self.b.conj(*(self.b.disj(*(self.literal(f['name'],v) for v in f['values'])) for f in fields))
        self.formulas=formulas(self);self.justices={'ENV':[],'SYS':[]}
    def literal(self,name,value,prime=False):return self.b.cube(self.enc[name][value][int(prime)])
    def audit_model(self):return {'status':'SYNTHETIC_MAPPING_FIXTURE'}

def typed_lift_permuted_bits_and_encodings():
    original_fields=[field('mode','ENV','ENV',[0,1],[3,4],['a','b','c'],[(False,False),(True,False),(False,True)]),field('memory','SYS','AUX',[2],[5])]
    job_fields=[field('mode','ENV','ENV',[5,2],[4,1],['a','b','c'],[(True,True),(False,True),(False,False)]),field('memory','SYS','AUX',[7],[3],codes=[(True,),(False,)]),field('~envHelp','ENV','ENV',[0],[6],codes=[(True,),(False,)])]
    def original_formula(c):return {'thetaE':1,'thetaS':1,'rhoE':c.literal('mode','b',True),'rhoS':c.literal('memory','true',True)}
    def job_formula(c):
        b=c.b;helper=c.literal('~envHelp','true');hp=c.literal('~envHelp','true',True)
        return {'thetaE':b.neg(helper),'thetaS':1,'rhoE':b.conj(b.disj(c.literal('mode','b',True),hp),b.disj(b.neg(helper),hp)),
            'rhoS':b.disj(c.literal('memory','true',True),helper)}
    original=TinyContext(original_fields,original_formula,6);job=TinyContext(job_fields,job_formula,8);job.justices['ENV']=[job.b.neg(job.literal('~envHelp','true'))]
    om={'fixture_id':'mock__original','case_id':'mock','variant':'original','bdd_variable_count':6,'input':{'sha256':'x','bytes':1},'source_inventory':{'parsed':{'ENV':{'constraints':[{'kind':'SAFETY'}]}}}}
    jm={'fixture_id':'mock__original','case_id':'mock__original','variant':'initializers','bdd_variable_count':8,'input':{'sha256':'x','bytes':1}}
    native={'fixture_id':'mock__original','case_id':'mock__original','variant':'initializers','input_sha256':'x','helper_added':True,'helper_is_native_nonaux_ENV':True}
    profile={'fixture_id':'mock__original','case_id':'mock','variant':'original','source':{'sha256':'x','bytes':1}}
    def read_mock(path):return native if path.name=='result.json' else om if path.parent.name=='original' else jm
    with patch.object(base,'read_json',side_effect=read_mock),patch.object(base,'Context',side_effect=[original,job]):pair=build(B/'synthetic-original/original',B/'synthetic-job/job','mock__original',profile)
    out=compare(pair['common'],pair['typed_edge_mask'],pair['original_roots']['rhoE'],pair['original_roots']['rhoS'],pair['job_roots']['rhoE'],pair['job_roots']['rhoS'],pair['helper_current_bit'],pair['helper_next_bit'],pair['original_current_bits'],pair['original_next_bits'],pair['original_fields'])[0]
    require(out['literal_complete_relation_equal'] and not out['corrected_complete_relation_equal'],'Typed permuted/inverted lift changed relation')
    require(out['typed_original_edge_domain_count']==36,'Ternary/AUX pair carrier')
    require(all(v['equal_full_typed_current_domain'] for v in pair['initial_full_domain'].values()),'Full initial lift')
    require(all(v['equal_identity_and_order_full_typed_current_domain'] for v in pair['justice_full_domain'].values()),'Full justice lift')
test('typed_permutation_value_recoding_helper_inversion_and_AUX_mapping',typed_lift_permuted_bits_and_encodings)

require(not (B/'FROZEN.json').exists() and not (B/'RUN_STARTED.json').exists(),'Qualification before freeze only')
report={'schema':'helper-quadrant-synthetic-math-qualification-v1','created_utc':now(),'status':'PASS' if all(t['pass'] for t in tests) else 'FAIL',
    'tests':tests,'passed':sum(t['pass'] for t in tests),'total':len(tests),'exhaustive_small_truth_arenas':arenas,
    'source_pins':[pin(B/n) for n in ('evidence.py','map_pair.py','relations.py','qualify_math.py')],
    'corpus_BDD_computations':0,'native_runs':0,'actual_child_processes':0,'full_reset_uses':0}
save(B/'MATH_QUALIFICATION.json',report);print(json.dumps({k:report[k] for k in ('status','passed','total','exhaustive_small_truth_arenas')},indent=2));require(report['status']=='PASS','Math/lift qualification failed')
