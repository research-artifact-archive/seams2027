"""One root-authorized repair condition diagnostic; no new fixed points/native."""
import json,signal,sys,time,traceback
sys.dont_write_bytecode=True
from evidence import B,read,save,pin,verify,require,now
from adapter import checker,ResourceRefusal,import_complete_k,compute,summarize,export,count,digest

def authorization():
    p=pin(B/'ROOT_START_DECISION.json');d=read(p['path'])
    require(d.get('start_authorized') is True and d.get('freeze')==pin(B/'FROZEN.json'),'Exact root review authorization required')
    verify([p]);return p

def main(ident):
    decision=authorization();freeze=read(B/'FROZEN.json');selection=read(B/'SELECTION.json')
    row=next(r for r in selection['rows'] if r['id']==ident and r['eligible'])
    directory=B/'runs'/ident;directory.mkdir(parents=True,exist_ok=True)
    require(not (directory/'RESULT.json').exists(),'No duplicate case calculation')
    refs=freeze['code_files']+row['input_pins']+[pin(B/'FROZEN.json'),pin(B/'SELECTION.json'),decision]
    result={'schema':'repair-preservation-condition-case-v1','id':ident,'status':'UNKNOWN_INCOMPLETE','created_utc':now(),
        'root_authorization':decision,'native_runs':0,'new_fixed_point_runs':0,'full_reset_uses':0,
        'complete_semantic_literal_only':True,'released_syntactic_loss_conclusion':None,
        'runtime_or_controller_defect_conclusion':None,'new_repaired_or_deployed_episode':False,
        'exact_W_C_or_K_loss_computed':False,'original_W_secondary_computed':False}
    started=time.monotonic();context=None
    def timeout(*_):raise TimeoutError('60 second repair condition diagnostic budget')
    try:
        signal.signal(signal.SIGALRM,timeout);signal.alarm(60)
        verify(refs);native=read(row['native_result']['path']);model=read(row['original_model']['path'])
        require(native['fixture_id']==model['fixture_id']==ident,'Exact model/result identity')
        profile=checker.load_profile(ident)
        context=checker.Context(__import__('pathlib').Path(row['original_model']['path']).parent,profile,model)
        require(all(f['owner']=='SYS' for f in context.fields if f['role']=='AUX'),'All logical AUX owned by SYS')
        context.audit_model()
        native_wv=context.read_bdd(native['final_region'],context.current)
        k=import_complete_k(context,read(row['complete_K_valuations']['path']),native_wv,row['existing_counts']['K'])
        roots=compute(context.b,context.domain,context.formulas['rhoS'],context.domain_en,context.domain_sn,
            context.current,context.env_next,context.sys_next,k)
        summary=summarize(context,roots)
        export(directory/'FUNCTIONS.json.gz',context,roots)
        result.update(summary,functions=pin(directory/'FUNCTIONS.json.gz'),input_pins=refs,variable_count=context.b.n,
            carrier=count(context.b,context.domain,context.current),exact_saved_W_V_equals_complete_typed_K=True,
            native_W_V_canonical_sha256=digest(context.b,native_wv),source_formula_audit='EXACT_ORIGINAL_BDD_TO_FROZEN_SOURCE_PROFILE',
            original_model=row['original_model'],saved_W_V_region=row['saved_W_V_region'],complete_K_valuations=row['complete_K_valuations'],
            existing_full_region_equality=row['existing_full_region_equality'],existing_certificate=row['existing_certificate'],
            original_initial_formulas=row['original_initial_formulas'],prior_native_initial_result=row['prior_native_initial_result'],
            original_initial_recomputed=False,
            condition_definition='C(s)=forall typed ENV-next exists typed SYS+all logical AUX-next rhoS, without restricting ENV-next by rhoE.',
            K_minus_C_scope='Immediate totality condition failure inside saved W_V=K; not the exact region K minus W_C.',
            compiler_trust_boundary='Existing shared Spectra parser/translator and frozen manually audited source profiles; no new independent compiler, strategy extraction or fixed points.')
        verify(refs);result['status']='PASS'
    except (TimeoutError,ResourceRefusal,MemoryError) as ex:result.update(status='UNKNOWN_RESOURCE',reason=repr(ex))
    except BaseException as ex:result.update(status='UNKNOWN_INTEGRITY',reason=repr(ex),traceback=traceback.format_exc())
    finally:
        signal.alarm(0);result.update(finished_utc=now(),elapsed_seconds=time.monotonic()-started,
            allocated_BDD_nodes=len(context.b.nodes) if context else None)
        save(directory/'RESULT.json',result)
    print(json.dumps({k:result.get(k) for k in ('id','status','counts','reason')}),flush=True)

if __name__=='__main__':main(sys.argv[1])
