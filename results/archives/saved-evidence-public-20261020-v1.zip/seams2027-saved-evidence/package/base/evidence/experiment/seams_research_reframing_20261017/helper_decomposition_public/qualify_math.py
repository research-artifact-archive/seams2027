"""Finite-set oracle on synthetic arbitrary one-way helper games; corpus BDD=0."""
from pathlib import Path
from itertools import product
from types import SimpleNamespace
import importlib.util,random,sys
sys.dont_write_bytecode=True
from evidence import B,S,H,save,pin,require,now
from decomposition import solve,BDD
spec=importlib.util.spec_from_file_location('decomposition_finite_oracle',S/'vendor/finite_sets_v1.py')
finite=importlib.util.module_from_spec(spec);spec.loader.exec_module(finite)
tests=[];fixtures=0

def test(name,fn):
    try:fn();tests.append({'name':name,'pass':True})
    except Exception as ex:tests.append({'name':name,'pass':False,'error':repr(ex)})

def fixture(ne,ns,ee,ss,aa=(),gg=(),ei=None,si=None,helper=True):
    global fixtures
    Q=set(range(ne*ns));vals=list(product(range(ne),range(ns)));eb,sb=(ne-1).bit_length(),(ns-1).bit_length()
    ec=list(range(0,2*eb,2));en=[v+1 for v in ec];sc=list(range(2*eb,2*(eb+sb),2));sn=[v+1 for v in sc];cur=ec+sc;prime=dict(zip(cur,en+sn));h=2*(eb+sb);hp=h+1;b=BDD(h+2 if helper else h)
    bits=lambda i,vs:{v:bool(i>>k&1) for k,v in enumerate(vs)}
    dom=lambda n,vs:b.disj(*(b.cube(bits(i,vs)) for i in range(n)))
    de,ds,den,dsn=dom(ne,ec),dom(ns,sc),dom(ne,en),dom(ns,sn);q=b.conj(de,ds)
    cubes={i:b.cube(bits(e,ec)|bits(y,sc)) for i,(e,y) in enumerate(vals)};reg=lambda states:b.disj(*(cubes[i] for i in states))
    er=lambda rel:b.disj(*(b.conj(cubes[i],b.cube(bits(e,en))) for i,e in rel))
    sr=lambda rel:b.disj(*(b.conj(cubes[i],b.cube(bits(e,en)|bits(y,sn))) for i,e,y in rel))
    E={key:er(rel) for key,rel in ee.items()};Srel={key:sr(rel) for key,rel in ss.items()}
    A=[set(a) for a in aa] or [Q.copy()];G=[set(g) for g in gg] or [Q.copy()]
    ei=set(range(ne)) if ei is None else set(ei);si=Q.copy() if si is None else set(si)
    te=b.disj(*(b.cube(bits(e,ec)) for e in ei));ts=reg(si)
    if helper:
        je=b.disj(*(b.conj(b.cube({h:bool(int(key[0])),hp:bool(int(key[1]))}),E[key]) for key in ee))
        js=b.disj(*(b.conj(b.cube({h:bool(int(key[0])),hp:bool(int(key[1]))}),Srel[key]) for key in ss))
        ja=[reg(a) for a in aa]+[b.neg(b.var(h))];jg=[reg(g) for g in gg];jte=b.conj(te,b.neg(b.var(h)))
    else:je,js,ja,jg,jte=E['00'],Srel['00'],[reg(a) for a in aa],[reg(g) for g in gg],te
    args=dict(b=b,q=q,de=de,den=den,dsn=dsn,current=cur,en=en,sn=sn,prime=prime,oe=E['00'],os=Srel['00'],oa=[reg(a) for a in aa],og=[reg(g) for g in gg],te=te,ts=ts,je=je,js=js,ja=ja,jg=jg,jte=jte,jts=ts,h=h if helper else None,hp=hp if helper else None)
    out=solve(**args)
    def pre(key,states):
        return {i for i in Q if all(any(j in states and jev==e and (i,e,jy) in ss[key] for j,(jev,jy) in enumerate(vals)) for ii,e in ee[key] if ii==i)}
    W=finite.gr1_three(Q,A,G,lambda x:pre('00',x),[])
    expected={'W_original':W}
    if helper:
        U=finite.fixed(Q,lambda x:pre('11',x),True,'U',[]);F=pre('01',U)
        fpre=lambda states:{i for i in Q if all(any(j in states&F and jev==e and i in F and (i,e,jy) in ss['00'] for j,(jev,jy) in enumerate(vals)) for ii,e in ee['00'] if ii==i)}
        WF=F&finite.gr1_three(Q,A,G,fpre,[])
        C={i for i in Q if all(any((i,e,y) in ss['00'] for y in range(ns)) for e in range(ne))}
        HQ=set(range(2*len(Q)));lift=lambda states:{i+k*len(Q) for k in (0,1) for i in states}
        hinputs={};hreplies={}
        for state in HQ:
            i=state%len(Q);hb=state//len(Q);hinputs[state]=set()
            for e,bnext in product(range(ne),(0,1)):
                key=str(hb)+str(bnext)
                if (i,e) in ee[key]:
                    hinputs[state].add((e,bnext));hreplies[state,(e,bnext)]={j+bnext*len(Q) for j,(je,jy) in enumerate(vals) if je==e and (i,e,jy) in ss[key]}
        hpre=lambda states:{i for i in HQ if all(hreplies[i,inp]&states for inp in hinputs[i])}
        HW=finite.gr1_three(HQ,[lift(a) for a in A]+[Q.copy()],[lift(g) for g in G],hpre,[])
        expected.update(U=U,F=F,C=C,W_F=WF,W_direct_0=HW&Q,W_direct_1={i-len(Q) for i in HW-Q},W_minus_F=W-F,W_loss=W-WF,delayed_loss=(W-WF)&F)
        require(HW&Q==WF and {i-len(Q) for i in HW-Q}==U,'Independent finite one-way theorem')
    else:WF=W;expected.update(W_F=W,W_direct_0=W,W_loss=set())
    require(all(out['roots'][name]==reg(states) for name,states in expected.items()),'BDD against independent finite region set')
    for name,states in [('W_original',W),('W_predicted',WF),('W_direct_active',WF)]:
        missing={e for e in ei if not any(i in si&states and je==e for i,(je,jy) in enumerate(vals))}
        require(out['quant'][name]['value']==(not missing),'Independent initial forall ENV exists SYS/AUX')
    require(out['checks']['active_decomposition_equal'] and out['checks']['initial_quantification_equal'],'Exact BDD equality including initial semantics')
    fixtures+=1
    return expected,out,args

def exhaustive_singleton():
    for em,sm,am,gm in product(range(8),range(8),range(2),range(2)):
        ee={key:({(0,0)} if em>>k&1 else set()) for k,key in enumerate(('00','01','11'))};ee['10']=set()
        ss={key:({(0,0,0)} if sm>>k&1 else set()) for k,key in enumerate(('00','01','11'))};ss['10']={(0,0,0)}
        fixture(1,1,ee,ss,[{0} if am else set()],[{0} if gm else set()])

def arbitrary_multistate():
    rng=random.Random(2026101707)
    for idx in range(640):
        ne,ns=(2,2) if idx<512 else (3,2)
        Q=set(range(ne*ns));er=list(product(Q,range(ne)));sr=list(product(Q,range(ne),range(ns)))
        ee={key:{edge for edge in er if rng.random()<0.7} for key in ('00','01','11')};ee['10']=set()
        ss={key:{edge for edge in sr if rng.random()<0.6} for key in ('00','01','10','11')}
        aa=[{i for i in Q if rng.random()<0.5} for _ in range(idx%3)];gg=[{i for i in Q if rng.random()<0.5} for _ in range((idx//3)%3)]
        fixture(ne,ns,ee,ss,aa,gg,ei=set() if idx%17==0 else None,si={i for i in Q if i%2==0} if idx%7==0 else None)

def named_examples():
    Q={0,1};er={(i,0) for i in Q};allS={(i,0,y) for i in Q for y in Q}
    ee={'00':er,'01':er,'10':set(),'11':er};ss={'00':allS,'01':allS,'10':set(),'11':{(0,0,0)}}
    got,_,_=fixture(1,2,ee,ss);require(got['U']=={0} and got['F']==Q and got['W_F']==Q,'Nontrivial trap can preserve')
    ss['01']={(i,0,1) for i in Q};got,_,_=fixture(1,2,ee,ss);require(got['F']==got['W_F']==set(),'One-step response must target U')
    ss['00']={(i,0,1) for i in Q};ss['01']={(1,0,0)};got,_,_=fixture(1,2,ee,ss);require(got['U']=={0} and got['F']==got['W_F']=={1},'F not required at trap target')
    ee={'00':set(),'01':{(0,0)},'10':set(),'11':{(0,0)}};ss={'00':set(),'01':set(),'10':set(),'11':{(0,0,0)}}
    got,_,_=fixture(1,1,ee,ss);require(got['W_original']=={0} and got['F']==got['W_F']==set(),'Outer F handles ENV deadend')

def nohelper():
    fixture(2,3,{'00':{(i,e) for i in range(6) for e in range(2)}},{'00':{(i,e,y) for i in range(6) for e in range(2) for y in range(3)}},[{0,2,4}],[{1,3,5}],helper=False)

def premise_controls():
    ee={key:{(0,0)} for key in ('00','01','11')};ee['10']=set();ss={key:{(0,0,0)} for key in ('00','01','10','11')}
    _,_,args=fixture(1,1,ee,ss);b=args['b']
    mutations=[{'je':1},{'ja':[1]},{'jg':[0]},{'jte':1},{'js':b.var(args['h'])}]
    for mutation in mutations:
        try:solve(**(args|mutation))
        except (ValueError,KeyError,TypeError):continue
        raise AssertionError('Failed to reject theorem premise mutation '+str(mutation))

def original_import_controls():
    import copy
    from import_original import import_payload
    from decomposition import count,digest,pair_module
    def field(name,owner,role,cb,nb,values,codes):
        return {'name':name,'owner':owner,'role':role,'domain_size':len(values),'values':values,'current_bits':cb,'next_bits':nb,'encoding':{v:{'current':{str(k):bool(c[i]) for i,k in enumerate(cb)},'next':{str(k):bool(c[i]) for i,k in enumerate(nb)}} for v,c in zip(values,codes)}}
    sf=[field('mode','ENV','ENV',[0,1],[2,3],['a','b','c'],[(0,0),(1,0),(1,1)]),field('y','SYS','SYS',[4],[5],['f','t'],[(0,),(1,)]),field('memory','SYS','AUX',[6],[7],['f','t'],[(0,),(1,)])]
    df=[field('memory','SYS','AUX',[2],[3],['t','f'],[(0,),(1,)]),field('mode','ENV','ENV',[0,4,6],[1,5,7],['c','a','b'],[(1,1,0),(1,0,1),(0,1,0)]),field('y','SYS','SYS',[8],[9],['t','f'],[(0,),(1,)])]
    sb,db,common=BDD(8),BDD(10),BDD(12)
    def literal(manager,fs,name,value,nxt=False):return manager.cube({int(k):v for k,v in next(f for f in fs if f['name']==name)['encoding'][value]['next' if nxt else 'current'].items()})
    def domain(manager,fs):return manager.conj(*(manager.disj(*(literal(manager,fs,f['name'],v) for v in f['values'])) for f in fs))
    sw=sb.conj(domain(sb,sf),sb.disj(sb.conj(literal(sb,sf,'mode','b'),literal(sb,sf,'y','t')),sb.conj(literal(sb,sf,'mode','c'),literal(sb,sf,'memory','f'))))
    current=[v for f in df for v in f['current_bits']]
    original=SimpleNamespace(b=db,by_name={f['name']:f for f in df},fields=df,carrier=12,current=current,domain=domain(db,df),literal=lambda n,v,p=False:literal(db,df,n,v,p))
    pair={'common':common,'original':original}
    payload={'schema':'independent-canonical-robdd-region-set-v1','variable_count':8,'canonical_variable_order':list(range(8)),'fields':sf,'roots':{'W':sw},'nodes':[[u,*row] for u,row in enumerate(sb.nodes) if u>1]}
    proof={'counts':{'W':count(sb,sw,[0,1,4,6])},'comparisons':{'W':{'equal':True,'independent_count':count(sb,sw,[0,1,4,6]),'canonical_sha256':digest(sb,sw)}}}
    actual,audit=import_payload(pair,payload,proof)
    expected=common.conj(domain(common,df),common.disj(common.conj(literal(common,df,'mode','b'),literal(common,df,'y','t')),common.conj(literal(common,df,'mode','c'),literal(common,df,'memory','f'))))
    require(actual==expected and count(common,actual,current)==4,'Different order/width/value codes and original AUX exact typed W lift')
    require(audit['source_variable_count']==8 and audit['destination_variable_count']==12 and audit['source_canonical_sha256']!=audit['lifted_original_layout_sha256'],'Different encodings must not require same digest')
    muts=[]
    x=copy.deepcopy(payload);x['fields']=x['fields'][:-1];muts.append((x,proof))
    x=copy.deepcopy(payload);x['fields'][2]['owner']='ENV';muts.append((x,proof))
    x=copy.deepcopy(payload);x['fields'][0]['encoding']['b']=x['fields'][0]['encoding']['a'];muts.append((x,proof))
    x=copy.deepcopy(payload);x['canonical_variable_order']=list(reversed(range(8)));muts.append((x,proof))
    x=copy.deepcopy(proof);x['comparisons']['W']['canonical_sha256']='0'*64;muts.append((payload,x))
    x=copy.deepcopy(proof);x['comparisons']['W']['equal']=False;muts.append((payload,x))
    for pl,pr in muts:
        try:import_payload(pair,pl,pr)
        except (ValueError,KeyError,TypeError):continue
        raise AssertionError('Corrupt typed original W authority accepted')

test('exhaustive_singleton_arbitrary_00_01_11_relations_and_justice',exhaustive_singleton)
test('640_seeded_arbitrary_typed_multistate_multiple_justice_games',arbitrary_multistate)
test('nontrivial_trap_target_F_scope_and_outer_F_examples',named_examples)
test('no_helper_identity_ternary_SYS_carrier',nohelper)
test('one_way_justice_initializer_and_00_negative_controls',premise_controls)
test('independent_W_typed_lift_across_order_width_codes_and_AUX',original_import_controls)
source=[pin(B/n) for n in ('decomposition.py','import_original.py','qualify_math.py','evidence.py')]+[pin(H/'map_pair.py'),pin(S/'symbolic.py'),pin(S/'vendor/finite_sets_v1.py'),pin(S/'vendor/bdd_core.py')]
result={'schema':'helper-decomposition-math-qualification-v1','created_utc':now(),'status':'PASS' if all(t['pass'] for t in tests) else 'FAIL','tests':tests,'synthetic_fixtures':fixtures,'corpus_BDD_computations':0,'native_runs':0,'source_pins':source}
save(B/'MATH_QUALIFICATION.json',result);print(result['status'],len(tests),fixtures)
if result['status']!='PASS':raise SystemExit(1)
