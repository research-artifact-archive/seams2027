"""Complete-semantic safety totality over every typed next ENV valuation."""
from pathlib import Path
import gzip,importlib.util,json,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent.parent/'kind_corpus_symbolic_independent'
sys.path.insert(0,str(S))
spec=importlib.util.spec_from_file_location('preservation_frozen_model',S/'check_case.py')
engine=importlib.util.module_from_spec(spec);spec.loader.exec_module(engine)
BDD=engine.BDD;require=engine.require;ResourceRefusal=engine.ResourceRefusal
count=engine.count;root_digest=engine.root_digest

def compute(b,q,rhos,den,dsn,current,en,sn,w):
    current,en,sn=tuple(current),tuple(en),tuple(sn)
    require(len(set(current+en+sn))==len(current+en+sn),'Disjoint current/next ownership')
    require(b.support(q)|b.support(w)<=set(current),'Current-state Q/W support')
    require(b.support(den)<=set(en) and b.support(dsn)<=set(sn),'Typed next domain support')
    require(b.support(rhos)<=set(current+en+sn),'SYS safety support')
    require(b.conj(w,b.neg(q))==0,'W outside typed state domain')
    response=b.exists(b.conj(rhos,dsn),sn)
    bad=b.conj(q,den,b.neg(response))
    c=b.conj(q,b.neg(b.exists(bad,en)))
    missing=b.conj(w,b.neg(c))
    require(b.support(c)<=set(current),'C must be a state predicate; all SYS/AUX next bits must be quantified')
    return {'C':c,'W':w,'W_minus_C':missing,'bad_ENV_next':bad}

def import_w(b,payload,fields):
    require(payload['schema']=='independent-canonical-robdd-region-set-v1' and payload['variable_count']==b.n,'Independent region schema')
    require(payload['canonical_variable_order']==list(range(b.n)) and payload['fields']==fields,'Independent region typed encoding')
    raw=payload['nodes']
    if len(raw)>500000:raise ResourceRefusal('Independent region node input cap')
    nodes={};triples=set()
    for row in raw:
        require(isinstance(row,list) and len(row)==4 and all(type(x) is int for x in row),'Independent region node record')
        ident,v,lo,hi=row
        require(ident>1 and ident not in nodes and 0<=v<b.n and lo!=hi,'Independent region node identity')
        require(all(x in (0,1) or x in nodes for x in (lo,hi)),'Independent region postorder')
        require(all(x<2 or nodes[x][0]>v for x in (lo,hi)),'Independent canonical variable order')
        require((v,lo,hi) not in triples,'Independent duplicate canonical node');triples.add((v,lo,hi));nodes[ident]=(v,lo,hi)
    root=payload['roots']['W'];require(type(root) is int and (root in (0,1) or root in nodes),'Independent W root')
    memo={0:0,1:1}
    def visit(u):
        if u not in memo:
            v,lo,hi=nodes[u];memo[u]=b.mk(v,visit(lo),visit(hi))
        return memo[u]
    return visit(root)

def load_w(model,path,proof):
    with gzip.open(path,'rb') as f:raw=f.read(64*1024*1024+1)
    if len(raw)>64*1024*1024:raise ResourceRefusal('Independent region uncompressed byte cap')
    payload=json.loads(raw,object_pairs_hook=engine.unique)
    w=import_w(model.b,payload,model.fields)
    require(model.b.support(w)<=set(model.current),'Independent W support')
    require(count(model.b,w,model.current)==proof['counts']['W'],'Independent W cardinality')
    require(root_digest(model.b,w)==proof['comparisons']['W']['canonical_sha256'],'Independent W Boolean function digest')
    return w

def typed_values(fields,bits,phase,owner=None):
    out={}
    for field in fields:
        if owner is not None and field['owner']!=owner:continue
        matches=[v for v in field['values'] if all(bits[int(k)]==value for k,value in field['encoding'][v][phase].items())]
        require(len(matches)==1,'Witness must decode to one typed value');out[field['name']]=matches[0]
    return out

def summarize(model,roots):
    b=model.b;result={'W_subset_C':roots['W_minus_C']==0,
        'counts':{name:count(b,roots[name],model.current) for name in ('C','W','W_minus_C')},
        'canonical_sha256':{name:root_digest(b,roots[name]) for name in roots},'C_member_witness':None,'W_minus_C_witness':None}
    if roots['C']:
        bits=b.satone(roots['C'],model.current)
        result['C_member_witness']={'state':typed_values(model.fields,bits,'current'),'current_bits':bits}
    bad=b.conj(roots['W'],roots['bad_ENV_next'])
    require((bad==0)==(roots['W_minus_C']==0),'Counterexample existence equivalence')
    if bad:
        bits=b.satone(bad,tuple(model.current)+tuple(model.en))
        response=b.exists(b.conj(model.forms['rhoS'],model.dsn),model.sn)
        require(b.evaluate(bad,bits) and not b.evaluate(response,bits),'No typed SYS/AUX response witness')
        result['W_minus_C_witness']={'state':typed_values(model.fields,bits,'current'),
            'ENV_next':typed_values(model.fields,bits,'next','ENV'),'bits':bits,
            'no_typed_SYS_and_all_AUX_response':True,'requires_ENV_move_legal_under_rhoE':False}
    return result
