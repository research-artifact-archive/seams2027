"""One explicitly authorized saved-output BDD reference computation."""
import gzip,json,signal,sys,time,traceback
from pathlib import Path
sys.dont_write_bytecode=True
from evidence import B,H,read,save,pin,verify,require,now
from decomposition import build,lifted_inputs,solve,count,digest,ResourceRefusal
from import_original import load as load_original_w,ImportResourceRefusal

def authorization():
    ref=pin(B/'ROOT_START_DECISION.json');decision=read(ref['path'])
    require(decision.get('start_authorized') is True and decision.get('freeze')==pin(B/'FROZEN.json'),'Exact Root freeze authorization required')
    verify([ref]);return ref

def decode(fields,bits):
    out={}
    for f in fields:
        matches=[v for v in f['values'] if all(bits[int(k)]==value for k,value in f['encoding'][v]['current'].items())]
        require(len(matches)==1,'Typed state witness bijection');out[f['name']]=matches[0]
    return out

def summarize(pair,out):
    b=pair['common'];o=pair['original'];cur=tuple(o.current);helper=pair['helper_added'];h=pair['helper_current_bit'];hcur=cur+((h,) if helper else ())
    full_names={'W_direct_full','job_initial_SYS_witness','job_missing_initial_ENV'}
    counts={};witnesses={};digests={}
    for name,u in out['roots'].items():
        vs=hcur if name in full_names else cur
        counts[name]=count(b,u,vs);digests[name]=digest(b,u);witnesses[name]=None
        if u:
            bits=b.satone(u,vs);require(b.evaluate(u,bits),'State witness membership')
            witnesses[name]={'state':decode(pair['original_fields'],bits),'bits':bits,'helper_current':bits[h] if helper and h in bits else None}
    quant={name:{'value':q['value'],'missing_initial_ENV_count':count(b,q['missing_environment_initials'],o.current_env),'SYS_witness_count':count(b,q['system_witness'],cur)} for name,q in out['quant'].items()}
    jq=out['actual_job_quant'];quant['actual_job']={'value':jq['value'],'missing_initial_ENV_count':count(b,jq['missing_environment_initials'],tuple(o.current_env)+((h,) if helper else ())),
        'SYS_witness_count':count(b,jq['system_witness'],hcur)}
    return {'branch':out['branch'],'helper_added':helper,'counts':counts,'canonical_sha256':digests,'state_witnesses':witnesses,'checks':out['checks'],'initial_quantification':quant,
        'original_typed_carrier':o.carrier,'full_job_typed_carrier':o.carrier*(2 if helper else 1),
        'initial_ENV_choice_count':count(b,b.conj(b.exists(out['roots']['D'],o.current_sys),pair['original_roots']['thetaE']),o.current_env)}

def export(path,pair,roots):
    b=pair['common'];seen=set();todo=list(roots.values())
    while todo:
        u=todo.pop()
        if u<2 or u in seen:continue
        seen.add(u);todo.extend(b.nodes[u][1:])
    payload={'schema':'helper-decomposition-canonical-functions-v1','variable_count':b.n,'canonical_variable_order':list(range(b.n)),
        'original_fields':pair['original_fields'],'original_current_bits':pair['original_current_bits'],'original_next_bits':pair['original_next_bits'],
        'helper_current_bit':pair['helper_current_bit'],'helper_next_bit':pair['helper_next_bit'],'roots':roots,'nodes':[[u,*b.nodes[u]] for u in sorted(seen)]}
    raw=json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode()
    if len(raw)>64*1024*1024:raise ResourceRefusal('Canonical function export cap64MiB')
    with gzip.GzipFile(filename=str(path),mode='wb',mtime=0) as f:f.write(raw)

def main(ident):
    decision=authorization();freeze=read(B/'FROZEN.json');selection=read(B/'SELECTION.json')
    row=next(r for r in selection['rows'] if r['id']==ident and r['eligible']);directory=B/'runs'/ident;directory.mkdir(parents=True,exist_ok=True)
    require(not (directory/'RESULT.json').exists(),'No duplicate computation/retry')
    refs=freeze['code_files']+row['input_pins']+[pin(B/'FROZEN.json'),pin(B/'SELECTION.json'),decision]
    result={'schema':'helper-decomposition-case-v1','id':ident,'status':'UNKNOWN_INCOMPLETE','created_utc':now(),'parent_aborted':True,'root_authorization':decision,
        'native_runs':0,'full_reset_uses':0,'direct_reference_objective':'strict_GR1_on_actual_saved_transformed_arena','compared_with_native_4fp_region':False,
        'claim_is_cooperative_strategy_existence':False,'released_10_condition_negative_cases_inference':False,'independent_source_compiler':False,'shared_source_compiler':True,
        'common_BDD_and_GR1_engine_between_direct_and_decomposed':True,'synthetic_finite_set_oracle_independent_representation':True,'all_original_AUX_retained':True}
    start=time.monotonic();pair=None
    def alarm(*_):raise TimeoutError('Saved-output decomposition wall60s')
    try:
        signal.signal(signal.SIGALRM,alarm);signal.alarm(60);verify(refs)
        pair=build(Path(row['original_model']['path']).parent,row['job_directory'],ident)
        args=lifted_inputs(pair);out=solve(**args)
        independent=read(row['independent_W_certificate']['path']);saved_w,lift_audit=load_original_w(pair,row['independent_regions']['path'],independent)
        out['roots']['independent_original_W_lifted']=saved_w;out['roots']['original_W_authority_difference']=pair['common'].apply('xor',saved_w,out['roots']['W_original'])
        require(out['roots']['original_W_authority_difference']==0,'Recomputed original W differs from exact typed independent W')
        summary=summarize(pair,out)
        qi=summary['initial_quantification']['W_original'];oldq=independent['initial_quantification']['W']
        require(qi['value']==oldq['value'] and qi['missing_initial_ENV_count']==oldq['missing_environment_initial_count'] and qi['SYS_witness_count']==oldq['system_witness_count'] and summary['initial_ENV_choice_count']==independent['initialized_ENV_count'],'Original initializer bound to independently certified W')
        result.update(independent_original_W_lift=lift_audit,independent_W_certificate=row['independent_W_certificate'],independent_W_process=row['independent_W_process'],independent_regions=row['independent_regions'],original_W_exact_authority_equal=True,original_initial_quantification_authority_equal=True)
        export(directory/'FUNCTIONS.json.gz',pair,out['roots'])
        result.update(summary=summary,iteration_logs=out['logs'],original_model=row['original_model'],job_model=row['job_model'],native_result=row['native_result'],enclosing_native_parent=row['parent_receipt'],
            prior_quadrant_result=row['quadrant_result'],prior_quadrant_process=row['quadrant_process'],functions=pin(directory/'FUNCTIONS.json.gz'),input_pins=refs,
            original_model_audit=pair['original_audit'],job_model_audit=pair['job_audit'],source_bindings=pair['source_bindings'])
        verdict=summary['checks'];equal=verdict['active_decomposition_equal'] and (verdict['trap_decomposition_equal'] is not False) and verdict['initial_quantification_equal'] and verdict['subset_original'] and verdict['full_preservation_iff_W_subset_F'] is not False
        verify(refs);result['status']='PASS' if equal else 'FAIL_DECOMPOSITION'
    except (TimeoutError,ResourceRefusal,ImportResourceRefusal,MemoryError) as error:result.update(status='UNKNOWN_RESOURCE',reason=repr(error))
    except BaseException as error:result.update(status='UNKNOWN_INTEGRITY',reason=repr(error),traceback=traceback.format_exc())
    finally:
        signal.alarm(0);result.update(finished_utc=now(),elapsed_seconds=time.monotonic()-start,allocated_common_BDD_nodes=len(pair['common'].nodes) if pair else None)
        save(directory/'RESULT.json',result)
    print(json.dumps({k:result.get(k) for k in ('id','status','reason')}),flush=True)
if __name__=='__main__':main(sys.argv[1])
