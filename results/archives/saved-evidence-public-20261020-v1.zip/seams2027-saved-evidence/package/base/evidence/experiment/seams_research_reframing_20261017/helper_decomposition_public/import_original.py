"""Canonical independent W -> original native-bit layout by typed values."""
import gzip,importlib.util,json,sys
sys.dont_write_bytecode=True
from evidence import E,require
from decomposition import BDD,ResourceRefusal,count,digest,pair_module
spec=importlib.util.spec_from_file_location('decomposition_frozen_condition_import',E/'preservation_condition_public/condition.py')
condition=importlib.util.module_from_spec(spec);spec.loader.exec_module(condition)
ImportResourceRefusal=condition.ResourceRefusal

def import_payload(pair,payload,proof):
    require(payload['schema']=='independent-canonical-robdd-region-set-v1','Independent canonical export schema')
    n=payload['variable_count'];require(type(n) is int and 0<=n<=64 and payload['canonical_variable_order']==list(range(n)),'Independent canonical bit order')
    fields=payload['fields'];require(isinstance(fields,list) and len(fields)<=32,'Independent full typed field roster')
    source=BDD(n,node_limit=500000);b=pair['common'];original=pair['original'];dest_fields=original.by_name
    names=[f['name'] for f in fields];require(len(set(names))==len(names) and set(names)==set(dest_fields),'Same complete original field names, no AUX loss')
    current=[];nxt=[];sc=[];domain=1;replacements={};seen=set();typed_carrier=1
    ot=pair_module.transfer(original.b,b,{v:b.var(v) for v in range(original.b.n)})
    for f in fields:
        name=f['name'];target=dest_fields[name];values=f['values'];cb,nb=f['current_bits'],f['next_bits']
        require(f['owner'] in ('ENV','SYS') and (f['owner'],f['role'],set(values))==(target['owner'],target['role'],set(target['values'])),'Same owner/role/value semantics '+name)
        require(len(values)==len(set(values))==f['domain_size']>0 and set(f['encoding'])==set(values),'Typed source value roster '+name)
        require(len(cb)==len(nb) and len(set(cb+nb))==len(cb+nb) and all(type(v) is int and 0<=v<n for v in cb+nb) and not seen&set(cb+nb),'Disjoint source field bits '+name)
        seen.update(cb+nb);current+=cb;nxt+=nb
        if f['owner']=='SYS':sc+=cb
        typed_carrier*=len(values);field_domain=0
        for phase,vs in (('current',cb),('next',nb)):
            codes=[]
            for value in values:
                code=f['encoding'][value][phase];require(set(code)=={str(v) for v in vs} and all(type(x) is bool for x in code.values()),'Complete exact Boolean typed encoding '+name)
                codes.append(tuple(code[str(v)] for v in vs))
                if phase=='current':field_domain=source.disj(field_domain,source.cube({v:code[str(v)] for v in vs}))
            require(len(set(codes))==len(values),'Bijective typed source encoding '+name)
        domain=source.conj(domain,field_domain)
        for v in cb:
            replacements[v]=b.disj(*(ot(original.literal(name,value,False)) for value in values if f['encoding'][value]['current'][str(v)]))
    require(seen==set(range(n)) and typed_carrier==original.carrier,'Full source/destination typed state carrier')
    w=condition.import_w(source,payload,fields)
    require(source.support(w)<=set(current) and source.conj(w,source.neg(domain))==0,'Independent W full typed current-state predicate')
    comp=proof['comparisons']['W'];require(comp['equal'] is True and count(source,w,current)==proof['counts']['W']==comp['independent_count'],'Independent original W cardinality authority')
    require(digest(source,w)==comp['canonical_sha256'],'Independent original W canonical digest authority')
    transfer=pair_module.transfer(source,b,replacements)
    lifted=b.conj(ot(original.domain),transfer(w))
    require(b.support(lifted)<=set(original.current) and count(b,lifted,original.current)==proof['counts']['W'],'Typed semantic W lift preserves cardinality')
    # Preserve both digests: different bit layouts need not have equal digests.
    return lifted,{'source_canonical_sha256':digest(source,w),'lifted_original_layout_sha256':digest(b,lifted),
        'typed_name_owner_role_value_bijection':True,'all_original_AUX_retained':True,'no_count_only_equality':True,
        'source_variable_count':n,'destination_variable_count':b.n,'source_fields':fields,'source_current_bits':current,'source_SYS_AUX_current_bits':sc}

def load(pair,path,proof):
    with gzip.open(path,'rb') as f:raw=f.read(64*1024*1024+1)
    if len(raw)>64*1024*1024:raise ResourceRefusal('Independent original W expanded bytes cap64MiB')
    return import_payload(pair,json.loads(raw,object_pairs_hook=condition.engine.unique),proof)
