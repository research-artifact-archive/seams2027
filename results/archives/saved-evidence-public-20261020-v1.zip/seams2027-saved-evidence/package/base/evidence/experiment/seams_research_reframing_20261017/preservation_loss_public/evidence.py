"""Ten condition-targeted mechanisms within the frozen 425/59 source funnel."""
from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;E=B.parent;C=E/'preservation_condition_public'
spec=importlib.util.spec_from_file_location('loss_prior_evidence',C/'evidence.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
S,N,CORPUS=prior.S,prior.N,prior.CORPUS
read,save,pin,pins_in,unique,verify,require,now=(getattr(prior,n) for n in ('read','save','pin','pins_in','unique','verify','require','now'))


def select():
    frozen=read(C/'FROZEN.json');receipt=read(C/'RUN_RECEIPT.json');selection=read(C/'SELECTION.json')
    require(receipt['schema']=='preservation-condition-run-v1' and receipt['global_stop'] is False and receipt['stop_reasons']==[],'Completed condition study required')
    require(receipt['source_denominator']==425 and receipt['eligible_count']==59 and receipt['BDD_worker_calls']=={'confirmed':59,'uncertain':0},'Fixed 425/59 condition funnel')
    require(receipt['parent_aborted'] is True and receipt['unknown_is_negative'] is False and receipt['native_runs']==0,'Preserved stopped-parent scope')
    verify(frozen['files']);verify([receipt['root_authorization']])
    decision=read(receipt['root_authorization']['path'])
    require(decision['start_authorized'] is True and decision['freeze']==pin(C/'FROZEN.json'),'Condition authorization binding')
    require(frozen['selection']==pin(C/'SELECTION.json'),'Condition selection binding')
    roster=read(CORPUS/'ROSTER.json')['unique_inputs'];allrows=receipt['rows'];oldrows=selection['rows']
    require(len(roster)==len(allrows)==len(oldrows)==425,'Whole source denominator')
    require([x['id'] for x in roster]==[x['id'] for x in allrows]==[x['id'] for x in oldrows],'Exact source order')
    refs=frozen['files']+[pin(C/'FROZEN.json'),pin(C/'RUN_RECEIPT.json'),pin(C/'SELECTION.json'),receipt['root_authorization']]
    rows=[];false_ids=[];true_count=0;authoritative=0
    for source,done,old in zip(roster,allrows,oldrows):
        ident=source['id'];item={'id':ident,'source':source['path'],'prior_status':old['prior_status'],
            'condition_status':done['status'],'eligible':False,'not_selected_reason':'UNKNOWN_NO_AUTHORITATIVE_INDEPENDENT_W'}
        if done['status']=='PASS':
            authoritative+=1;require(old['eligible'] is True,'Condition PASS lacks original independent authority')
            verify([done['result'],done['process']]);result=read(done['result']['path']);process=read(done['process']['path'])
            require(result['schema']=='preservation-condition-case-v1' and result['id']==ident and result['status']=='PASS','Condition result identity')
            require(result['root_authorization']==receipt['root_authorization'],'Condition child authorization')
            require(process['schema']=='contained-stage-process-v1' and process['status']=='PROCESS_COMPLETED' and process['exit_code']==0 and process['process_started'] is True,'Condition enclosing process authority')
            require(process['owned_child_reaped'] is True and process['final_group_observation']['state']=='ABSENT','Condition completion/containment')
            require(process['argv'][-2:]==[str(C/'measure.py'),ident],'Condition process exact case binding')
            require(result['independent_W_certificate']==old['proof'] and result['independent_process']==old['process'],'Independent W authority binding')
            require(type(result['W_subset_C']) is bool and result['W_subset_C']==done['W_subset_C'],'Condition Boolean binding')
            require(result['counts']==done['counts'] and result['W_subset_C']==(result['counts']['W_minus_C']==0),'Condition count binding')
            expected_refs=frozen['code_files']+old['input_pins']+[pin(C/'FROZEN.json'),pin(C/'SELECTION.json'),receipt['root_authorization']]
            require(result['input_pins']==expected_refs,'Exact condition/source/code evidence')
            case_refs=unique(old['input_pins']+[done['result'],done['process']]+pins_in(result)+pins_in(process))
            verify(case_refs);refs+=case_refs
            item.update(condition_W_subset_C=result['W_subset_C'],condition_proof=done['result'],condition_process=done['process'])
            if result['W_subset_C']:
                true_count+=1;item['not_selected_reason']='CONDITION_TRUE_NOT_SELECTED'
            else:
                false_ids.append(ident)
                item.update({key:old[key] for key in ('model','proof','process','independent_regions')})
                item.update(eligible=True,not_selected_reason=None,input_pins=case_refs,condition_functions=result['functions'])
        else:
            require(done['status']=='UNKNOWN_NO_AUTHORITATIVE_INDEPENDENT_W' and old['eligible'] is False,'Unexpected condition outcome')
        rows.append(item)
    require(authoritative==59 and true_count==49 and len(false_ids)==10,'All completed condition outcomes retained')
    refs=unique(refs);verify(refs)
    return {'schema':'preservation-loss-selection-v1','created_utc':now(),'source_denominator':425,
        'authoritative_W_and_C_count':59,'condition_true_count':49,'condition_false_count':10,
        'eligible_count':10,'eligible_ids':false_ids,'rows':rows,'parent_aborted':True,
        'selection_rule':'All ten W-not-subset-C cases from completed fixed 59; condition-targeted mechanism study, no initial/reachable/exact-loss filtering.',
        'selection_uses_completed_condition':True,'selection_uses_new_loss_or_initial_result':False,
        'condition_run':pin(C/'RUN_RECEIPT.json'),'input_pins':refs,'native_runs':0,'corpus_BDD_computations':0}
