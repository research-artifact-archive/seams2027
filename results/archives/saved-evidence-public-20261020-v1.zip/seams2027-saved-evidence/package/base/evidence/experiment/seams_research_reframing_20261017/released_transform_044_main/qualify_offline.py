"""Source/authority tests and mocked whole044 parent; no actual process/corpus BDD."""
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch
from datetime import datetime,timezone,timedelta
from copy import deepcopy
import ast,json,sys
sys.dont_write_bytecode=True
from evidence import B,P,R,Q,H,ID,read,save,pin,require,now,old_schedule
from scope import source_tokens
import evidence,run

def qualify():
    require(not (B/'FROZEN.json').exists() and not (B/'OFFLINE_QUALIFICATION.json').exists(),'No qualification overwrite')
    tests=[];schedule=old_schedule()
    def test(name,fn):fn();tests.append({'name':name,'status':'PASS'})
    test('all_three_comment_forms_removed',lambda:require(source_tokens('module X // weight\n-- import "bad"\n/* energy */ env boolean e;')==['module','X','env','boolean','e',';'],'Correct Spectra comment handling'))
    test('quoted_import_preserved',lambda:require(source_tokens('import "../patterns/DwyerPatterns.spectra" -- comment')==['import','"../patterns/DwyerPatterns.spectra"'],'Exact literal import'))
    test('real_weight_declaration_retained',lambda:require('weight' in source_tokens('-- not a weight\nweight x: 1;'),'Rejectable real weight token retained'))
    test('comment_markers_inside_string_preserved',lambda:require(source_tokens('import "a//b--c.spectra"')==['import','"a//b--c.spectra"'],'Comment markers in strings'))
    def adaptation():
        old=(H/'map_pair.py').read_text();new=(B/'map_pair.py').read_text()
        require(new==old.replace('base.MAX_CARRIER=8192','base.MAX_CARRIER=65536').replace("if original.carrier>4096:raise ResourceRefusal('Original typed carrier cap4096')","if original.carrier>65536:raise ResourceRefusal('Original typed carrier cap65536')"),'Exactly two reviewed admission cap edits')
        require((B/'relations.py').read_bytes()==(H/'relations.py').read_bytes() and (B/'qualify_math.py').read_bytes()==(H/'qualify_math.py').read_bytes(),'Unchanged qualified all-quadrant and synthetic mathematics')
        def functions(path):return {x.name:ast.dump(x,include_attributes=False) for x in ast.parse(path.read_text()).body if isinstance(x,ast.FunctionDef)}
        oldf=functions(H/'measure.py');newf=functions(B/'pair_support.py')
        require(set(newf)=={'supplemental','export'} and all(newf[k]==oldf[k] for k in newf),'Exact qualified supplemental/export function ASTs')
    test('qualified_quadrant_reuse_exact_except_two_admission_caps',adaptation)
    def auth(kind):
        with TemporaryDirectory(prefix='main044_auth_') as tmp:
            root=Path(tmp);q=root/'q';q.mkdir();save(q/'JOINED_QUALIFICATION.json',{'synthetic':True});save(root/'FROZEN.json',{'synthetic':True})
            joined=pin(q/'JOINED_QUALIFICATION.json');save(root/'SELECTION.json',{'joined_qualification':joined})
            d={'start_authorized':True,'scope':'MODEL_ONLY_044_PAIR','freeze':pin(root/'FROZEN.json'),'joined_qualification':joined,'native_JVM_budget':2,'solver_budget':0}
            if kind=='wrong_freeze':d['freeze']={**d['freeze'],'sha256':'0'*64}
            if kind=='wrong_join':d['joined_qualification']={**joined,'sha256':'0'*64}
            if kind=='no_authority':d['start_authorized']=False
            if kind=='wrong_scope':d['scope']='MODEL_ONLY_093_PAIR'
            if kind=='bool_budget':d['solver_budget']=False
            save(root/'ROOT_START_DECISION.json',d);called=[];failed=False
            def closed():called.append(True);return {},[]
            with patch.object(evidence,'B',root),patch.object(evidence,'Q',q),patch.object(evidence,'closed_qualification',side_effect=closed):
                try:evidence.authorization()
                except ValueError:failed=True
            require(failed==(kind!='pass') and bool(called)==(kind=='pass'),'Separate044 authority rejects malformed/wrong-stage evidence')
    for kind in ('pass','wrong_freeze','wrong_join','no_authority','wrong_scope','bool_budget'):test('root_authority_'+kind,lambda kind=kind:auth(kind))
    def parent(kind):
        with TemporaryDirectory(prefix='main044_mock_') as tmp:
            root=Path(tmp);fp=root/'FROZEN.json';sp=root/'SELECTION.json';dp=root/'ROOT_START_DECISION.json';join=root/'JOIN.json';save(join,{'status':'PASS_THREE_FIXED_QUALIFICATION_CASES'})
            end=(datetime.now(timezone.utc)+timedelta(seconds=0 if kind=='deadline' else 600)).isoformat();save(dp,{'deadline_utc':end});decision=pin(dp)
            freeze={'files':[],'code_files':[],'native_files':[],'python':pin(Path(sys.executable).resolve())}
            model={'path':'/synthetic/model','bytes':1,'sha256':'a'*64};proof={'path':'/synthetic/proof','bytes':1,'sha256':'b'*64}
            selected={'case':{'id':ID,'authoritative_original_model':model,'original_independent_proof':proof},'input_pins':[],'joined_qualification':pin(join),'stopped_v1_qualification':{'path':'/synthetic/stopped','bytes':1,'sha256':'a'*64}}
            save(fp,freeze);save(sp,selected);native=[];checks=[]
            def launch(argv,folder,deadline,refs):
                folder=Path(folder);folder.mkdir(parents=True);native.append(folder.name)
                if kind=='uncertain_native':raise RuntimeError('Synthetic loss of response after possible native start')
                status='UNKNOWN_RESOURCE' if kind=='native_resource' else 'COMPLETE_PROCESS_AND_CAPTURE'
                called=1 if kind=='bad_count_type' else True
                p={'status':status,'native_called':called,'global_stop':False,'worker_receipt':{'artifacts':{}}};save(folder/'PARENT_RECEIPT.json',p);return p
            def bounded(argv,folder,deadline,**kwargs):
                folder=Path(folder);folder.mkdir(parents=True);checks.append(ID)
                if kind=='uncertain_check':raise RuntimeError('Synthetic checker start uncertainty')
                process={'status':'UNKNOWN_RESOURCE' if kind=='check_resource' else 'PROCESS_COMPLETED','exit_code':1 if kind=='check_nonzero' else 0,'process_started':True};save(folder/'PROCESS_RECEIPT.json',process)
                if kind!='missing_check':
                    artifact=folder.parent/'FUNCTIONS.json.gz';artifact.write_bytes(b'SYNTHETIC_ONLY')
                    quadrants=[{'quadrant':q,'checks':{k:{'equal':q=='00'} for k in ('ENV_literal_and_corrected','SYS_literal','SYS_corrected')}} for q in ('00','01','10','11')]
                    result={'schema':'fixed044-model-main-check-v1','id':ID,'status':'PASS','root_authorization':decision,'joined_qualification':selected['joined_qualification'],
                        'checker_native_JVM_calls':0,'solver_calls':0,'controller_calls':0,'full_reset_uses':0,'old_global_stop_preserved':True,'v1_resumed':False,'U_F_direct_analysis_authorized':False,'winning_or_K_preservation_conclusion':None,
                        'input_pins':[pin(fp),pin(sp),decision],'comparisons':{'original':{'status':'PASS','source_inventory_fully_accounted_for':True,'source_inventory_bridge':{'status':'PASS'},'same_generator_configuration_claim':False}},
                        'native_exports':{'original':{},'released':{}},'released_old_reference_available':False,'pair_structure':{'status':'PASS','all_original_fields_and_AUX_retained':True,'helper_added':True,'original_carrier':18816,'released_carrier':37632},
                        'authoritative_original_model':model,'original_independent_proof':proof,'original_model_canonical_bound_to_independent_proof':True,
                        'all_quadrant_relations':{'quadrants':quadrants,'all_original_current_next_and_logical_AUX_retained':True,'projection_or_existential_elimination_of_original_AUX':False,'typed_original_edge_domain_count':18816**2},
                        'supplemental_full_current_checks':{'all_equal':True},'relation_classification_is_observation_not_theorem_assumption':True,'ready_for_separately_reviewed_U_F_and_direct_analysis':True,'canonical_functions':pin(artifact)}
                    if kind=='bad_result':result['solver_calls']=False
                    if kind=='wrong_join':result['joined_qualification']={**selected['joined_qualification'],'sha256':'0'*64}
                    if kind=='bad_00':quadrants[0]['checks']['SYS_literal']['equal']=False
                    if kind=='bad_initial':result['supplemental_full_current_checks']['all_equal']=False
                    if kind=='missing_quadrant':quadrants.pop()
                    if kind=='missing_functions':artifact.unlink()
                    save(folder.parent/'CHECK.json',result)
                return process
            def spec(name,path):
                setup=(lambda m:setattr(m,'launch_native',launch)) if str(path).endswith('/launcher.py') else (lambda m:setattr(m,'run_bounded',bounded))
                return SimpleNamespace(loader=SimpleNamespace(exec_module=setup))
            with patch.object(run,'B',root),patch.object(run,'authorization',return_value=decision),patch.object(run,'verify',lambda refs:None),patch.object(run,'native_sources',lambda *a:[]),patch.object(run,'native_refs',lambda *a:[]),patch.object(run.probe,'command',lambda *a:['/synthetic/java']),patch.object(run,'old_schedule',return_value=schedule),patch.object(run.importlib.util,'spec_from_file_location',side_effect=spec),patch.object(run.importlib.util,'module_from_spec',return_value=SimpleNamespace()):run.run(end)
            receipt=read(root/'RUN_RECEIPT.json')
            if kind=='pass':require(receipt['status']=='PASS_044_MODEL_PAIR' and native==['original','released'] and checks==[ID],'Exactly two fixed native arms and one checker; non00 inequality is accepted as observation')
            elif kind=='deadline':require(not native and not checks and receipt['native_JVM_calls']=={'confirmed':0,'uncertain':0,'not_called':2},'No native dispatch after insufficient reserve')
            else:
                require(receipt['global_stop'] is True and receipt['status']=='UNKNOWN_INCOMPLETE','Failure remains unknown and stops')
                if kind.startswith('native_') or kind in ('uncertain_native','bad_count_type'):require(len(native)==1 and not checks,'Native failure stops second arm/checker')
                if kind=='uncertain_native':require(receipt['native_JVM_calls']['uncertain']==1,'Preserve uncertain native attempt')
                if kind=='uncertain_check':require(receipt['rows'][0]['checker_started'] is None,'Preserve uncertain checker start')
                if kind=='check_resource':require(receipt['rows'][0]['status']=='UNKNOWN_RESOURCE','Resource dominates valid-looking child check')
            require(receipt['solver_calls']==receipt['controller_calls']==0 and receipt['U_F_direct_analysis_authorized'] is False,'No solver/controller/future scientific authority')
    for kind in ('pass','deadline','native_resource','uncertain_native','bad_count_type','check_resource','check_nonzero','missing_check','uncertain_check','bad_result','wrong_join','bad_00','bad_initial','missing_quadrant','missing_functions'):test('whole_parent_mock_'+kind,lambda kind=kind:parent(kind))
    for p in B.glob('*.py'):ast.parse(p.read_text())
    sources=[pin(B/n) for n in ('evidence.py','scope.py','check_pair.py','run.py','qualify_offline.py','map_pair.py','relations.py','pair_support.py','MATH_QUALIFICATION.json')]+[pin(P/'run.py'),pin(R/'trace_bridge.py'),pin(R/'OFFLINE_QUALIFICATION.json'),pin(Q/'evidence.py'),pin(H/'FROZEN.json')]
    save(B/'OFFLINE_QUALIFICATION.json',{'schema':'fixed044-offline-qualification-v1','status':'PASS','created_utc':now(),'count':len(tests),'tests':tests,'source_pins':sources,
        'corpus_BDD_computations':0,'new_native_JVM_calls':0,'new_solver_calls':0,'actual_child_processes':0,
        'inherited_metadata_bridge_qualification':pin(R/'OFFLINE_QUALIFICATION.json'),'all_quadrant_synthetic_qualification':pin(B/'MATH_QUALIFICATION.json')})
    print(json.dumps({'status':'PASS','checks':len(tests),'actual_child_processes':0,'new_native_JVM_calls':0}))

if __name__=='__main__':qualify()
