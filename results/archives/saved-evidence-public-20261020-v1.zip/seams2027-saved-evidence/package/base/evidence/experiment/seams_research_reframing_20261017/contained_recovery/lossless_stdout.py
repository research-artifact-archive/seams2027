"""Lossless bounded stdout capture only; never inspects or filters scientific output."""
import gzip
import hashlib
import os
import threading

RAW_CAP = 256 * 1024 * 1024
FILE_CAP = 16 * 1024 * 1024
CHUNK = 65536


class LosslessStdout:
    def __init__(self, source, target, raw_cap=RAW_CAP, file_cap=FILE_CAP):
        self.source = source
        self.target = target
        self.raw_cap = raw_cap
        self.file_cap = file_cap
        self.raw_bytes = 0
        self.raw_sha256 = None
        self.eof = False
        self.error = None
        self.cap_reasons = []
        self.alert = threading.Event()
        self.thread = threading.Thread(target=self._pump, daemon=True)

    def start(self):
        self.thread.start()

    def _pump(self):
        digest = hashlib.sha256()
        try:
            with self.target.open('wb', buffering=0) as backing:
                with gzip.GzipFile(filename='', mode='wb', compresslevel=1,
                                   fileobj=backing, mtime=0) as compressed:
                    while True:
                        block = os.read(self.source.fileno(), CHUNK)
                        if not block:
                            self.eof = True
                            break
                        # Every read byte is hashed and written, including all diagnostics.
                        digest.update(block)
                        compressed.write(block)
                        self.raw_bytes += len(block)
                        if self.raw_bytes > self.raw_cap:
                            if 'uncompressed_stdout_cap' not in self.cap_reasons:
                                self.cap_reasons.append('uncompressed_stdout_cap')
                            self.alert.set()
                        if backing.tell() > self.file_cap:
                            if 'compressed_stdout_cap' not in self.cap_reasons:
                                self.cap_reasons.append('compressed_stdout_cap')
                            self.alert.set()
                if backing.tell() > self.file_cap:
                    if 'compressed_stdout_cap' not in self.cap_reasons:
                        self.cap_reasons.append('compressed_stdout_cap')
                    self.alert.set()
        except BaseException as exc:
            self.error = repr(exc)
            self.alert.set()
        finally:
            self.raw_sha256 = digest.hexdigest()

    def finish(self):
        self.thread.join(timeout=3)
        alive = self.thread.is_alive()
        if alive:
            self.error = self.error or 'stdout reader did not reach EOF within 3 seconds'
        recovered_bytes = 0
        recovered_sha256 = None
        roundtrip = False
        if not alive and self.eof and self.error is None:
            try:
                recovered = hashlib.sha256()
                with gzip.open(self.target, 'rb') as compressed:
                    while True:
                        block = compressed.read(CHUNK)
                        if not block:
                            break
                        recovered_bytes += len(block)
                        recovered.update(block)
                        # Do not read beyond the amount actually captured.
                        if recovered_bytes > self.raw_bytes:
                            raise ValueError('decompression exceeded captured byte count')
                recovered_sha256 = recovered.hexdigest()
                roundtrip = (recovered_bytes == self.raw_bytes and
                             recovered_sha256 == self.raw_sha256)
            except BaseException as exc:
                self.error = 'roundtrip: ' + repr(exc)
        return {
            'schema': 'lossless-stdout-capture-v1',
            'encoding': 'gzip', 'compression_level': 1,
            'filtering_or_dropping': False,
            'raw_bytes': self.raw_bytes, 'raw_sha256': self.raw_sha256,
            'compressed_bytes': self.target.stat().st_size if self.target.exists() else None,
            'eof_seen': self.eof, 'reader_joined': not alive, 'error': self.error,
            'cap_reasons': self.cap_reasons,
            'roundtrip_bytes': recovered_bytes, 'roundtrip_sha256': recovered_sha256,
            'roundtrip_verified': roundtrip,
            'capture_complete': bool(not alive and self.eof and not self.error and roundtrip),
            'limits_passed': not self.cap_reasons,
        }
