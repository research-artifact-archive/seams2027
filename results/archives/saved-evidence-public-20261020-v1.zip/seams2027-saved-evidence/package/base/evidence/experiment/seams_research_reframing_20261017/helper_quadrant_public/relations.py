"""Exact four-helper-quadrant Boolean comparisons; no corpus dispatch on import."""
from functools import lru_cache
from hashlib import sha256
from evidence import require

def count(b,root,variables):
    variables=tuple(sorted(variables));where={v:i for i,v in enumerate(variables)}
    require(len(where)==len(variables) and b.support(root)<=set(variables),'Exact count support/roster')
    @lru_cache(None)
    def visit(u,pos):
        if u<2:return u << (len(variables)-pos)
        v,lo,hi=b.nodes[u];k=where[v]
        return (visit(lo,k+1)+visit(hi,k+1)) << (k-pos)
    return visit(root,0)
def digest(b,root):
    @lru_cache(None)
    def visit(u):
        if u<2:return sha256(str(u).encode()).hexdigest()
        v,lo,hi=b.nodes[u];return sha256(f'{v}:{visit(lo)}:{visit(hi)}'.encode()).hexdigest()
    return visit(root)
def decode(fields,bits,phase):
    out={}
    for f in fields:
        matches=[v for v in f['values'] if all(bits[int(k)]==value for k,value in f['encoding'][v][phase].items())]
        require(len(matches)==1,'Difference witness does not decode to exactly one typed value');out[f['name']]=matches[0]
    return out

def compare(b,typed_edge_mask,original_rhoE,original_rhoS,job_rhoE,job_rhoS,
            helper_current_bit,helper_next_bit,original_current_bits,original_next_bits,original_fields):
    variables=tuple(original_current_bits)+tuple(original_next_bits);orig=set(variables)
    require(len(orig)==len(variables),'Original current/next must be disjoint')
    require(all(b.support(u)<=orig for u in (typed_edge_mask,original_rhoE,original_rhoS)),'Original relation/mask support')
    helper=helper_current_bit is not None or helper_next_bit is not None
    if helper:
        require(type(helper_current_bit) is int and type(helper_next_bit) is int and helper_current_bit!=helper_next_bit and not {helper_current_bit,helper_next_bit}&orig,'Helper bit ownership')
        allowed=orig|{helper_current_bit,helper_next_bit}
    else:allowed=orig
    require(b.support(job_rhoE)|b.support(job_rhoS)<=allowed,'Lifted job relation support')
    roots={};rows=[]
    def one(label,actual,expected):
        actual=b.conj(typed_edge_mask,actual);expected=b.conj(typed_edge_mask,expected)
        delta=b.apply('xor',actual,expected);aonly=b.conj(actual,b.neg(expected));eonly=b.conj(expected,b.neg(actual))
        for k,u in [('actual',actual),('expected',expected),('difference',delta),('actual_only',aonly),('expected_only',eonly)]:roots[label+'__'+k]=u
        witnesses={}
        for k,u in [('difference',delta),('actual_only',aonly),('expected_only',eonly)]:
            witnesses[k]=None
            if u:
                bits=b.satone(u,variables);require(b.evaluate(u,bits),'Difference witness evaluation')
                witnesses[k]={'current':decode(original_fields,bits,'current'),'next':decode(original_fields,bits,'next'),'bits':bits,
                    'actual_relation_value':b.evaluate(actual,bits),'expected_relation_value':b.evaluate(expected,bits)}
        return {'equal':delta==0,'counts':{k:count(b,u,variables) for k,u in [('actual',actual),('expected',expected),('difference',delta),('actual_only',aonly),('expected_only',eonly)]},
            'canonical_sha256':{k:digest(b,u) for k,u in [('actual',actual),('expected',expected),('difference',delta)]},'typed_witnesses':witnesses}
    if not helper:
        checks={
            'ENV_identity':one('identity_ENV',job_rhoE,original_rhoE),
            'SYS_identity':one('identity_SYS',job_rhoS,original_rhoS),
            'joint_legal_edge_identity':one('identity_joint',b.conj(job_rhoE,job_rhoS),b.conj(original_rhoE,original_rhoS))}
        summary={'helper_added':False,'branch':'NO_HELPER_IDENTITY','quadrants':[],'identity':checks,
            'no_helper_identity_equal':all(v['equal'] for v in checks.values()),'literal_complete_relation_equal':None,'corrected_complete_relation_equal':None,
            'literal_legal_joint_equal':None,'corrected_legal_joint_equal':None}
    else:
        for current,nxt in ((0,0),(0,1),(1,0),(1,1)):
            cube=b.cube({helper_current_bit:bool(current),helper_next_bit:bool(nxt)})
            je=b.exists(b.conj(job_rhoE,cube),(helper_current_bit,helper_next_bit));js=b.exists(b.conj(job_rhoS,cube),(helper_current_bit,helper_next_bit))
            ee=original_rhoE if (current,nxt)==(0,0) else 0 if (current,nxt)==(1,0) else 1
            sl=original_rhoS if not current else 1
            sc=original_rhoS if not (current or nxt) else 1
            quad=str(current)+str(nxt)
            checks={'ENV_literal_and_corrected':one(quad+'_ENV',je,ee),
                'SYS_literal':one(quad+'_SYS_literal',js,sl),'SYS_corrected':one(quad+'_SYS_corrected',js,sc),
                'joint_legal_edges_literal':one(quad+'_joint_literal',b.conj(je,js),b.conj(ee,sl)),
                'joint_legal_edges_corrected':one(quad+'_joint_corrected',b.conj(je,js),b.conj(ee,sc))}
            rows.append({'quadrant':quad,'helper_current':bool(current),'helper_next':bool(nxt),'checks':checks,
                         'expected_ENV_relation_impossible':(current,nxt)==(1,0),'SYS_relation_compared_even_if_ENV_impossible':True})
        literal=all(r['checks']['ENV_literal_and_corrected']['equal'] and r['checks']['SYS_literal']['equal'] for r in rows)
        corrected=all(r['checks']['ENV_literal_and_corrected']['equal'] and r['checks']['SYS_corrected']['equal'] for r in rows)
        summary={'helper_added':True,'branch':'FOUR_HELPER_QUADRANTS','quadrants':rows,'identity':None,'no_helper_identity_equal':None,
            'literal_complete_relation_equal':literal,'corrected_complete_relation_equal':corrected,
            'literal_legal_joint_equal':all(r['checks']['joint_legal_edges_literal']['equal'] for r in rows),
            'corrected_legal_joint_equal':all(r['checks']['joint_legal_edges_corrected']['equal'] for r in rows),
            'relation_classification':'BOTH_LITERAL_AND_CORRECTED' if literal and corrected else 'LITERAL_ONLY' if literal else 'CORRECTED_ONLY' if corrected else 'NEITHER_LITERAL_NOR_CORRECTED'}
    summary.update(typed_original_edge_domain_count=count(b,typed_edge_mask,variables),
        all_original_current_next_and_logical_AUX_retained=True,projection_or_existential_elimination_of_original_AUX=False,
        AUX_causal_attribution='UNKNOWN_NO_PER_CONSTRAINT_SEMANTIC_PROOF',
        interpretation='Exact saved relation comparison only. Separate E/S equality is stronger than joint legal-edge equality. No winning-region loss or preservation-theorem application is inferred.')
    return summary,roots
