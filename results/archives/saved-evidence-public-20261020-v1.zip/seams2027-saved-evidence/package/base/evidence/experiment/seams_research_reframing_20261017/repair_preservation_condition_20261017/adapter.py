"""Source-audited original encoding, complete K import and totality diagnostic."""
from pathlib import Path
from functools import lru_cache
from hashlib import sha256
import gzip,importlib.util,json,sys
sys.dont_write_bytecode=True
from evidence import CHECKER,require
# Bind the inherited engine explicitly rather than resolving another bdd_core.
def module(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
core=module('repair_condition_frozen_bdd_core',CHECKER/'bdd_core.py')
old=sys.modules.get('bdd_core');sys.modules['bdd_core']=core
try:checker=module('repair_condition_source_checker',CHECKER/'admission_checker.py')
finally:
    if old is None:sys.modules.pop('bdd_core',None)
    else:sys.modules['bdd_core']=old
BDD=core.BDD;ResourceRefusal=core.ResourceRefusal

def count(b,root,variables):
    variables=tuple(sorted(variables));index={v:i for i,v in enumerate(variables)}
    require(b.support(root)<=set(variables),'State count support')
    @lru_cache(None)
    def visit(u,pos):
        if u<2:return u << (len(variables)-pos)
        v,lo,hi=b.nodes[u];k=index[v]
        return (visit(lo,k+1)+visit(hi,k+1)) << (k-pos)
    return visit(root,0)

def digest(b,root):
    @lru_cache(None)
    def visit(u):
        if u<2:return sha256(str(u).encode()).hexdigest()
        v,lo,hi=b.nodes[u];return sha256(f'{v}:{visit(lo)}:{visit(hi)}'.encode()).hexdigest()
    return visit(root)

def import_complete_k(context,payload,native_wv,expected):
    b=context.b;names=list(context.by_name)
    require(set(payload['field_order'])==set(names) and len(payload['field_order'])==len(names),'Complete typed field roster')
    require(payload['carrier']==count(b,context.domain,context.current),'Exact typed carrier')
    require(type(payload['K']) is int and payload['K']==expected and len(payload['K_valuations'])==expected,'Complete K list cardinality')
    require(b.support(native_wv)<=set(context.current) and b.conj(native_wv,b.neg(context.domain))==0,'Native W_V typed current state support')
    seen=set();root=0
    for val in payload['K_valuations']:
        context.valuation(val,'Complete K')
        key=tuple(val[n] for n in names);require(key not in seen,'Duplicate typed K valuation');seen.add(key)
        root=b.disj(root,context.cube(val))
    require(root==native_wv,'Exact Boolean equality of finite K and complete saved native W_V')
    require(count(b,root,context.current)==expected,'K state count')
    return root

def compute(b,q,rhos,den,dsn,current,en,sn,k):
    current,en,sn=tuple(current),tuple(en),tuple(sn)
    require(len(set(current+en+sn))==len(current+en+sn),'Disjoint current/next bit ownership')
    require(b.support(q)|b.support(k)<=set(current),'Current-state domain/K support')
    require(b.support(den)<=set(en) and b.support(dsn)<=set(sn),'Typed next ENV and SYS/AUX domains')
    require(b.support(rhos)<=set(current+en+sn),'Original SYS safety support')
    require(b.conj(k,b.neg(q))==0,'K outside complete typed current domain')
    response=b.exists(b.conj(rhos,dsn),sn)
    bad=b.conj(q,den,b.neg(response))
    c=b.conj(q,b.neg(b.exists(bad,en)))
    missing=b.conj(k,b.neg(c))
    require(b.support(c)<=set(current),'All SYS/AUX next bits quantified before ENV next')
    return {'C':c,'K':k,'K_minus_C':missing,'bad_ENV_next':bad}

def typed_values(fields,bits,phase,owner=None):
    out={}
    for f in fields:
        if owner is not None and f['owner']!=owner:continue
        values=[v for v in f['values'] if all(bits[int(k)]==x for k,x in f['encoding'][v][phase].items())]
        require(len(values)==1,'Typed witness decode');out[f['name']]=values[0]
    return out

def summarize(c,roots):
    b=c.b;out={'W_V_subset_C':roots['K_minus_C']==0,'K_subset_C':roots['K_minus_C']==0,
        'counts':{n:count(b,roots[n],c.current) for n in ('C','K','K_minus_C')},
        'canonical_sha256':{n:digest(b,u) for n,u in roots.items()},'C_state_witness':None,'K_minus_C_witness':None}
    if roots['C']:
        bits=b.satone(roots['C'],c.current);out['C_state_witness']={'state':typed_values(c.fields,bits,'current'),'bits':bits}
    bad=b.conj(roots['K'],roots['bad_ENV_next']);require((bad==0)==(roots['K_minus_C']==0),'Missing-state witness existence')
    if bad:
        bits=b.satone(bad,c.current+c.env_next)
        response=b.exists(b.conj(c.formulas['rhoS'],c.domain_sn),c.sys_next)
        require(b.evaluate(bad,bits) and not b.evaluate(response,bits),'No typed SYS/all AUX response witness')
        out['K_minus_C_witness']={'state':typed_values(c.fields,bits,'current'),
            'ENV_next':typed_values(c.fields,bits,'next','ENV'),'bits':bits,'all_logical_AUX_retained':True,
            'no_typed_SYS_and_all_AUX_response':True,'requires_ENV_move_legal_under_rhoE':False,
            'not_a_strategy_or_runtime_trace':True}
    return out

def export(path,c,roots):
    visited=set();nodes=[]
    def visit(u):
        if u<2 or u in visited:return
        visited.add(u);v,lo,hi=c.b.nodes[u];visit(lo);visit(hi);nodes.append([u,v,lo,hi])
    for u in roots.values():visit(u)
    payload={'schema':'repair-preservation-condition-robdd-v1','variable_count':c.b.n,
        'canonical_variable_order':list(range(c.b.n)),'fields':c.fields,'current_bits':c.current,
        'ENV_next_bits':c.env_next,'SYS_and_AUX_next_bits':c.sys_next,'roots':roots,'nodes':nodes}
    raw=json.dumps(payload,separators=(',',':')).encode()
    if len(raw)>64*1024*1024:raise ResourceRefusal('Expanded export byte cap')
    with gzip.open(path,'wb') as f:f.write(raw)
