"""Closed 425/14/13 saved-output admission; metadata and hashes only."""
from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;E=B.parent;H=E/'helper_quadrant_public';S=E/'kind_corpus_symbolic_independent'
spec=importlib.util.spec_from_file_location('decomposition_prior_evidence',H/'evidence.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
CHECK,STAGE=prior.CHECK,prior.STAGE
read,save,pin,pins_in,unique,verify,require,now=(getattr(prior,n) for n in ('read','save','pin','pins_in','unique','verify','require','now'))

def select():
    f=read(H/'FROZEN.json');s=read(H/'SELECTION.json');r=read(H/'RUN_RECEIPT.json')
    require(r['schema']=='helper-quadrant-run-v1' and r['global_stop'] is False and r['stop_reasons']==[],'Closed four-quadrant study')
    require(r['source_denominator']==425 and r['fixed_small_cohort_count']==14 and r['eligible_count']==13,'Fixed 425/14/13 funnel')
    require(r['BDD_worker_calls']=={'confirmed':13,'uncertain':0} and r['native_runs']==0,'Closed relation worker calls')
    require(r['root_authorization']==pin(H/'ROOT_START_DECISION.json'),'Prior Root decision identity')
    decision=read(H/'ROOT_START_DECISION.json');require(decision['start_authorized'] is True and decision['freeze']==pin(H/'FROZEN.json'),'Prior exact freeze authorization')
    require(f['selection']==pin(H/'SELECTION.json'),'Prior selection pin')
    require(len(s['rows'])==len(r['rows'])==425 and [x['id'] for x in s['rows']]==[x['id'] for x in r['rows']],'Full original source roster/order')
    C=E/'preservation_condition_public';cf=read(C/'FROZEN.json');cs=read(C/'SELECTION.json');cr=read(C/'RUN_RECEIPT.json')
    require(cr['global_stop'] is False and cr['source_denominator']==425 and cr['eligible_count']==59,'Closed independent original-W admission context')
    require(cf['selection']==pin(C/'SELECTION.json') and cr['root_authorization']==pin(C/'ROOT_START_DECISION.json'),'Original-W context pin binding')
    crows={x['id']:x for x in cs['rows']};cdone={x['id']:x for x in cr['rows']}
    refs=cf['files']+[pin(C/n) for n in ('FROZEN.json','SELECTION.json','RUN_RECEIPT.json','ROOT_START_DECISION.json')]+f['files']+[pin(H/n) for n in ('FROZEN.json','RUN_RECEIPT.json','SELECTION.json','ROOT_START_DECISION.json','RESULT_FILES.json')]
    rows=[]
    for old,done in zip(s['rows'],r['rows']):
        item=dict(old);item['prior_status']=done['status'];item['eligible']=False
        if old['eligible']:
            require(done['status']=='PASS','All 13 complete saved relations admitted, no result filtering')
            result=read(done['result']['path']);process=read(done['process']['path'])
            require(done['result']==pin(H/'runs'/old['id']/'RESULT.json') and done['process']==pin(H/'runs'/old['id']/'process/PROCESS_RECEIPT.json'),'Exact prior case path')
            require(result['schema']=='helper-quadrant-case-v1' and result['id']==old['id'] and result['status']=='PASS','Prior case identity')
            require(process['schema']=='contained-stage-process-v1' and process['status']=='PROCESS_COMPLETED' and process['exit_code']==0 and process['process_started'] is True and process['owned_child_reaped'] is True and process['final_group_observation']['state']=='ABSENT','Prior contained process authority')
            require(process['argv'][-2:]==[str(H/'measure.py'),old['id']],'Prior exact command binding')
            require(result['root_authorization']==r['root_authorization'] and result['original_model']==old['original_model'] and result['job_model']==old['job_model'],'Prior source/decision binding')
            expected=f['code_files']+old['input_pins']+[pin(H/'FROZEN.json'),pin(H/'SELECTION.json'),r['root_authorization']]
            require(result['input_pins']==expected,'Exact prior input pins')
            case_refs=unique(old['input_pins']+[done['result'],done['process']]+pins_in(result)+pins_in(process))
            cw=crows[old['id']];cd=cdone[old['id']]
            require(cw['eligible'] is True and cd['status']=='PASS' and cw['model']==old['original_model'],'Existing original independent W exact model authority')
            cp=read(cd['result']['path']);ip=read(cw['proof']['path']);iprocess=read(cw['process']['path'])
            require(cp['independent_W_certificate']==cw['proof'] and cp['independent_process']==cw['process'] and cp['status']=='PASS','Condition result binds independently certified W')
            require(ip['id']==old['id'] and ip['status']=='PASS' and ip['comparisons']['W']['equal'] is True and ip['derived_region_export']==cw['independent_regions'],'Independent W result and export identity')
            require(iprocess['id']==old['id'] and iprocess['status']=='PASS' and iprocess['process_exit_code']==0 and iprocess['hard_timeout'] is False and iprocess['child_result']==cw['proof'],'Original independent worker completion')
            case_refs=unique(case_refs+cw['input_pins']+[cd['result'],cd['process']]+pins_in(cp)+[cw['proof'],cw['process'],cw['independent_regions']]+pins_in(ip))
            verify(case_refs);refs+=case_refs
            item.update(independent_W_certificate=cw['proof'],independent_W_process=cw['process'],independent_regions=cw['independent_regions'])
            item.update(eligible=True,prior_status='PENDING_DECOMPOSITION',input_pins=case_refs,quadrant_result=done['result'],quadrant_process=done['process'])
        else:require(done['BDD_worker_started'] is False,'Ineligible prior case unexpectedly started')
        rows.append(item)
    require([x['id'] for x in rows if x['eligible']]==s['eligible_ids'],'No helper/relation/graph/initial outcome filtering')
    refs=unique(refs);verify(refs)
    return {'schema':'helper-decomposition-selection-v1','created_utc':now(),'source_denominator':425,'fixed_small_cohort_count':14,'eligible_count':13,
        'eligible_ids':s['eligible_ids'],'rows':rows,'input_pins':refs,'parent_aborted':True,'condition_context_without_selection':s['condition_context_without_selection'],
        'selection_rule':'Every process/capture/model-complete arm of the prespecified fixed 14, including all five no-helper arms. No new synthesis, no relation-sign filtering.',
        'native_runs':0,'corpus_BDD_computations':0}
