"""Saved-data generic released job certificates, conditional on shared compilation."""
from pathlib import Path
from itertools import product
from collections import defaultdict, deque
from functools import lru_cache
import argparse, copy, hashlib, importlib.util, json, math, re, sys, traceback
sys.dont_write_bytecode=True
import generic_base as base
base.MAX_CARRIER=8192
BDD,Invalid,ResourceRefusal,require=base.BDD,base.Invalid,base.ResourceRefusal,base.require
read_json,pinned_file,bit_map,sha=base.read_json,base.pinned_file,base.bit_map,base.sha
HERE=Path(__file__).resolve().parent
HELPER='~envHelp'

def save(p,x):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def pin(p):return {'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':sha(p)}
def reach(starts,edges):
 adj=defaultdict(list)
 for a,b in edges:adj[a].append(b)
 seen=set(starts);q=deque(starts)
 while q:
  for b in adj[q.popleft()]:
   if b not in seen:seen.add(b);q.append(b)
 return seen

class ControllerDefect(Invalid):pass

def obligation(ok,label):
 if not ok:raise ControllerDefect(label)

def shared_transfer(src,dst,replacements):
 @lru_cache(None)
 def tr(u):
  if u<2:return u
  v,lo,hi=src.nodes[u]
  require(v in replacements,'Typed bit lift is incomplete')
  return dst.ite(replacements[v],tr(hi),tr(lo))
 return tr

def audit_models(od,jd,case,r,c,qualification_profile=None):
 om=read_json(od/'model.json');jm=read_json(pinned_file(jd,r['model_export']))
 p=qualification_profile if qualification_profile is not None else base.load_profile(case)
 require(om['fixture_id']==case,'Original fixture binding')
 require(r['fixture_id']==case and r['case_id']==case and r['variant']=='initializers','Released job identity binding')
 require(jm['fixture_id']==case and jm['case_id']==case and jm['variant']=='initializers','Released model identity binding')
 op={**p,'fixture_id':om['fixture_id'],'case_id':om['case_id'],'variant':om['variant']}
 # Production original identity is not inferred from the job variant.
 if qualification_profile is None:
  require({k:om[k] for k in ('fixture_id','case_id','variant')}=={k:p[k] for k in ('fixture_id','case_id','variant')},'Frozen original identity')
 jp={**p,'fixture_id':case,'case_id':case,'variant':'initializers'}
 original=base.Context(od,op,om)
 if original.carrier>4096:raise ResourceRefusal('Original typed carrier >4096')
 job=base.Context(jd,jp,jm)
 c['original_model_audit']=original.audit_model();c['job_model_audit']=job.audit_model()
 require(r['input_sha256']==p['source']['sha256'],'Job/source hash binding')
 require(om['input']['sha256']==jm['input']['sha256'] and om['input']['bytes']==jm['input']['bytes'],'Original/job exact input pin')
 predicted=any(x['kind'] in ('SAFETY','STATE_INV') for x in om['source_inventory']['parsed']['ENV']['constraints'])
 helper=r.get('helper_added');require(type(helper) is bool and helper==predicted,'Helper branch matches pretranslation ENV safety')
 require(HELPER not in original.by_name,'Original helper-name collision')
 expected=set(original.by_name)|({HELPER} if helper else set())
 require(set(job.by_name)==expected,'Exact original fields plus optional helper; no missing logical AUX')
 for name,f in original.by_name.items():
  g=job.by_name[name]
  require((f['owner'],f['role'],set(f['values']))==(g['owner'],g['role'],set(g['values'])),'Typed field/owner/role/domain mismatch: '+name)
 if helper:
  h=job.by_name[HELPER];require((h['owner'],h['role'],set(h['values']))==('ENV','ENV',{'false','true'}),'ENV nonAUX boolean helper')
  require(r.get('helper_is_native_nonaux_ENV') is True,'Native helper ownership receipt')
 else:require(r.get('helper_is_native_nonaux_ENV') is False,'No-helper ownership receipt')
 # Both native encodings are pulled back to original bits plus two explicit helper bits.
 common=BDD(original.b.n+(2 if helper else 0))
 otr=shared_transfer(original.b,common,{i:common.var(i) for i in range(original.b.n)})
 rep={}
 for name,f in job.by_name.items():
  for prime,key in [(False,'current_bits'),(True,'next_bits')]:
   for v in f[key]:
    if name==HELPER:
     hvar=common.var(original.b.n+int(prime))
     a=job.enc[name]['false'][int(prime)][v];z=job.enc[name]['true'][int(prime)][v]
     rep[v]=common.ite(hvar,int(z),int(a))
    else:
     rep[v]=common.disj(*(otr(original.literal(name,value,prime)) for value in f['values'] if job.enc[name][value][int(prime)][v]))
 jtr=shared_transfer(job.b,common,rep)
 current=otr(original.domain);edge=common.conj(current,otr(original.b.rename(original.domain,original.prime)))
 if helper:
  current=common.conj(current,common.neg(common.var(original.b.n)))
  edge=common.conj(edge,common.neg(common.var(original.b.n)),common.neg(common.var(original.b.n+1)))
 equations=[]
 for key,u in original.formulas.items():
  mask=current if key.startswith('theta') else edge
  equal=common.conj(mask,common.apply('xor',otr(u),jtr(job.formulas[key])))==0
  equations.append({'equation':key,'entire_legal_typed_domain':True,'equal':equal})
  require(equal,'Full typed-domain original/job equivalence: '+key)
 justice={}
 for owner in ('ENV','SYS'):
  actual=job.justices[owner];filtered=list(actual);helper_index=None
  if helper and owner=='ENV':
   b0=job.literal(HELPER,'false')
   found=[i for i,u in enumerate(actual) if job.b.conj(job.domain,job.b.apply('xor',u,b0))==0]
   require(len(found)==1,'Unique inserted helper justice on whole job domain');helper_index=found[0];filtered.pop(helper_index)
  require(len(filtered)==len(original.justices[owner]),'Original justice count')
  for x,y in zip(original.justices[owner],filtered):
   require(common.conj(current,common.apply('xor',otr(x),jtr(y)))==0,'Original justice identity/order')
  pre=[job.read_bdd(ref,job.current) for ref in r['preconstructor_justices'][owner]]
  require(pre==actual,'Exact preconstructor justice identity/order')
  solver=[job.read_bdd(ref,job.current) for ref in r['solver_justices'][owner]]
  require(solver==(actual or [1]),'Native empty-owner TRUE padding only')
  justice[owner]={'original_count':len(filtered),'transformed_count':len(actual),'helper_justice_index':helper_index,'solver_count':len(solver),'TRUE_padding':not actual}
 c['source_bindings']=p.get('bindings',{'qualification_profile':True})
 c['original_job_identity_binding']={'original':{k:om[k] for k in ('fixture_id','case_id','variant')},'job':{k:jm[k] for k in ('fixture_id','case_id','variant')},'same_source':True}
 c['helper_mapping_equations']={'status':'PASS','helper_added':helper,'branch':'helper_false' if helper else 'no_helper_identity','full_domain_equivalences':equations,'justice_identity_order':justice,'field_mapping':'name/owner/role/domain/typed-value bijection; native bit positions may differ','all_original_fields_and_logical_AUX_retained':True,'arbitrary_source_AST_independently_compiled':False}
 c['original_model_pin']=pin(od/'model.json');c['job_model_pin']=pin(jd/'model.json')
 c['BDD_pins']={'original':[pin(od/name) for name,_ in original.refs],'job':[pin(jd/name) for name,_ in job.refs]}
 return original,job,helper

def parse_printed(text,nodes):
 lines=text.splitlines();require(len(lines)==2*len(nodes),'Native printer line count')
 for i,n in enumerate(nodes):
  mt=re.fullmatch(r'(Initial )?State ([0-9]+) (<[^<>]*>)',lines[2*i]);require(mt is not None,'Native printed state format')
  require((mt.group(1) is not None)==n['initial'] and int(mt.group(2))==i,'Printed initial/ID mismatch')
  pairs=[x.split(':') for x in mt.group(3)[1:-1].split(', ')] if mt.group(3)!='<>' else [];require(all(len(x)==2 for x in pairs),'Printed valuation syntax')
  require(len(dict(pairs))==len(pairs) and dict(pairs)==n['valuation'],'Printed complete valuation')
  require(mt.group(3)==n['native_bdd_text'],'Native BDD text receipt')
  expected='\tWith successors : '+', '.join(n['successors']) if n['successors'] else '\tWith no successors.'
  require(lines[2*i+1]==expected,'Printed complete successors')
 return {'status':'PASS','decoded_states':len(nodes),'all_variables_printed':True,'projection_by_printer':False,'same_graph_before_after_printer':True}

def certify_graph(jd,out,r,original,job,helper,c):
 g=read_json(pinned_file(jd,r['controller_export']))
 require(g.get('schema')=='released-kind-complete-native-controller-v1' and g.get('complete') is True,'Complete graph schema')
 require(g['model_sha256']==sha(jd/'model.json') and g['native_memory_identity']==r['native_memory_identity'],'Graph/model/memory identity')
 require(r['controller_before_print_sha256']==r['controller_after_print_sha256'],'Printer mutation guard')
 require(r.get('same_native_memory_passed_to_constructor') is True and r.get('same_native_model_passed_to_constructor') is True,'Same solver memory/model to public constructor')
 require(type(g['rank_domain_size']) is int and g['rank_domain_size']==len(r['solver_justices']['SYS']),'Native rank domain exactly solver SYS justice count')
 nodes=g['nodes'];require(isinstance(nodes,list) and len(nodes)==g['api_state_count'],'Complete node count')
 if len(nodes)>4096 or len(g['edges'])>65536:raise ResourceRefusal('Native graph node/edge technical cap')
 require(nodes,'Nonempty printed graph');index={};flat=[];native_memory_keys=set()
 for i,n in enumerate(nodes):
  sid=n['id'];require(sid==str(i) and type(n['native_id']) is int and n['native_id']==i and sid not in index,'Exact native state ID/order')
  require(type(n['initial']) is bool and type(n['rank']) is int and 0<=n['rank']<g['rank_domain_size'],'Native initial/rank type/range')
  require(n['rank_class']=='tau.smlab.syntech.games.gr1.GR1RankInfo','Native rank class')
  require(n['rank_info']=='System Justice '+str(n['rank']),'Native rank text identity')
  job.valuation(n['valuation'],'Full native node')
  memory_key=(tuple(n['valuation'][f['name']] for f in job.fields),n['rank'])
  require(memory_key not in native_memory_keys,'Duplicate native valuation/rank memory');native_memory_keys.add(memory_key)
  require(bit_map(n['bits'],job.current,'Native bits')==job.bits(n['valuation']),'Native bits/typed values')
  require(isinstance(n['successors'],list) and all(type(v) is str for v in n['successors']) and len(set(n['successors']))==len(n['successors']),'Unique native successors')
  index[sid]=n;flat.extend([[sid,j] for j in n['successors']])
 require(flat==g['edges'] and len(flat)==g['api_transition_count'] and all(j in index for _,j in flat),'Complete ordered edge export')
 printed=pinned_file(jd,r['printed_controller']);c['native_printer_mapping']=parse_printed(printed.read_text(),nodes)
 starts=[n['id'] for n in nodes if n['initial']]
 obligation(starts and all(index[i]['rank']==0 for i in starts),'Native nonempty rank-zero initial memory')
 require(reach(starts,flat)==set(index),'All raw nodes reachable from raw initials')
 if helper:obligation(all(index[i]['valuation'][HELPER]=='false' for i in starts),'Native initial helper=false')
 kept={i for i,n in index.items() if not helper or n['valuation'][HELPER]=='false'}
 zeroedges=[e for e in flat if e[0] in kept and e[1] in kept];reachable=reach(starts,zeroedges)
 edges=[e for e in zeroedges if e[0] in reachable];adj=defaultdict(list)
 for a,z in edges:adj[a].append(z)
 vals={i:{k:v for k,v in n['valuation'].items() if k!=HELPER} for i,n in index.items()}
 b=original.b;env=original.env
 inputs=[dict(zip(env,vs)) for vs in product(*[original.by_name[x]['values'] for x in env])]
 if len(inputs)*len(reachable)>4000000:raise ResourceRefusal('ENV input-check technical cap')
 legal_initial={tuple(inp[x] for x in env) for inp in inputs if b.evaluate(original.formulas['thetaE'],original.bits(inp))}
 c['native_graph']={'states':len(nodes),'edges':len(flat),'initial_states':len(starts),'controller_pin':pin(jd/'controller.json'),'printed_pin':pin(printed)}
 c['original_initial_ENV_choices']=len(legal_initial)
 if not legal_initial:
  c['status']='COMPLETE_VACUOUS_ENV_INITIALS';c['derived_fairness']=None;return
 actual_initial=defaultdict(list)
 for i in starts:
  bits=original.bits(vals[i]);obligation(b.evaluate(original.formulas['thetaE'],bits) and b.evaluate(original.formulas['thetaS'],bits),'Original initial safety response')
  actual_initial[tuple(vals[i][x] for x in env)].append(i)
 obligation(set(actual_initial)==legal_initial and all(len(v)==1 for v in actual_initial.values()),'Exact original initial ENV coverage and unique native response')
 checked=0
 for i in sorted(reachable):
  current=original.bits(vals[i]);expected=set();seen=defaultdict(list)
  for inp in inputs:
   checked+=1
   if b.evaluate(original.formulas['rhoE'],{**current,**original.bits(inp,True)}):expected.add(tuple(inp[x] for x in env))
  for j in adj[i]:
   bits={**current,**original.bits(vals[j],True)}
   obligation(b.evaluate(original.formulas['rhoE'],bits),'Retained edge violates original ENV')
   obligation(b.evaluate(original.formulas['rhoS'],bits),'Retained edge violates original SYS/AUX')
   seen[tuple(vals[j][x] for x in env)].append(j)
  obligation(set(seen)==expected,'Original legal ENV input coverage')
  obligation(all(len(v)==1 for v in seen.values()),'Original response/private-memory uniqueness')
 graph={'states':sorted(reachable),'starts':starts,'edges':edges,'env_justice':[],'sys_justice':[]}
 for owner,key in [('ENV','env_justice'),('SYS','sys_justice')]:
  graph[key]=[[i for i in sorted(reachable) if b.evaluate(j,original.bits(vals[i]))] for j in original.justices[owner]]
 save(out/'derived_original_graph.json',graph);fair=base.graph_analyzer()(graph);save(out/'derived_original_fairness.json',fair)
 c['original_view_mapping']={'status':'PASS','definition':'All-initial reachable native helper-false view' if helper else 'All-initial complete native graph with no helper','states':len(reachable),'edges':len(edges),'initial_states':len(starts),'original_legal_input_checks':checked,'original_initial_ENV_choices':len(legal_initial),'edge_or_memory_repair':False,'raw_native_ids_ranks_and_memory_retained':True,'all_logical_AUX_retained':True,'V_restriction_applied':False}
 c['derived_fairness']=fair;c['derived_original_graph_pin']=pin(out/'derived_original_graph.json');c['status']='COMPLETE_DERIVED_ORIGINAL_CERTIFICATE'

def check(od,jd,case,out,qualification_profile=None):
 c={'schema':'released-kind-corpus-certificate-v1','case_id':case,'status':'UNKNOWN_ORIGINAL_MAPPING','native_outcome':None,'derived_fairness':None,'native_runs':0,'full_reset_uses':0,'trust_boundary':'Original and job exports share parser/translator/exporter; no arbitrary source-AST independent compilation claim. Invocation depends on frozen producer provenance.'}
 try:
  r=read_json(jd/'result.json');c['native_outcome']=r.get('status');c['native_result_pin']=pin(jd/'result.json')
  require(r['pipeline']=='released_syntactic_kind_job_equivalent' and r['solver']=='4fp','Released pipeline binding')
  if r.get('status','').startswith('UNKNOWN_'):
   c['status']='UNKNOWN_NATIVE_PIPELINE';c['native_exception']=r.get('exception');return c
  require(r.get('initializers_replaced') is False and r.get('semantic_reduction_used') is False and r.get('ENV_justice_normalization_used') is False,'Released job scope')
  require(r.get('GUI_execution') is False and r['native_solver_calls']==1 and r['teardown']=='COMPLETED','Job calls/teardown')
  expected={'release':'1.0.0.202402072123','BDDPackage':'JTLV','BDDPackageVersion':'DEFAULT','synthesisMethod':'synthesisPitermanReduction','ConcreteControllerFormat':'JTLV','optChoice':'none','reorderChoice':'none','groupVars':False,'TraceInfo':'NONE','TransFuncType':'SINGLE_FUNC','extractor_strategy':'native_two_argument_default_ZYX'}
  require(r['configuration']==expected,'Frozen released job configuration')
  original,job,helper=audit_models(od,jd,case,r,c,qualification_profile)
  if r['status']=='JOB_UNREALIZABLE_NO_CONTROLLER':
   require(r['native_initial_verdict'] is False and r['memory_empty_guard_called'] is False,'False verdict gate')
   require(r['controller_extraction_calls']==0 and r['native_printer_calls']==0,'False verdict no extraction/printer')
   c['status']='COMPLETE_NO_CONTROLLER';c['original_view_mapping']={'status':'NOT_RETURNED'}
  elif r['status']=='JOB_EMPTY_MEMORY_NO_CONTROLLER':
   require(r['native_initial_verdict'] is True and r['memory_empty_guard_called'] is True and r['memory_empty'] is True,'Empty memory gate')
   require(r['controller_extraction_calls']==0 and r['native_printer_calls']==0,'Empty memory no extraction/printer')
   c['status']='COMPLETE_NO_CONTROLLER';c['original_view_mapping']={'status':'NOT_RETURNED'}
  elif r['status']=='JOB_CONTROLLER_PRINTED':
   require(r['native_initial_verdict'] is True and r['memory_empty_guard_called'] is True and r['memory_empty'] is False and r['memory_complete'] is True,'Released extraction gate')
   require(r['controller_extraction_calls']==1 and r['native_printer_calls']==1,'Exactly one extraction/printer')
   certify_graph(jd,out,r,original,job,helper,c)
  else:raise Invalid('Unsupported native outcome')
 except ControllerDefect as e:c.update(status='COMPLETE_CONTROLLER_DEFECT',controller_defect=str(e))
 except ResourceRefusal as e:c.update(status='UNKNOWN_RESOURCE',mapping_error=str(e))
 except (Invalid,OSError,UnicodeError,KeyError,ValueError,TypeError,IndexError,RecursionError) as e:c.update(status='UNKNOWN_ORIGINAL_MAPPING',mapping_error=type(e).__name__+': '+str(e),traceback=traceback.format_exc())
 return c

def capture_receipts(jd):
 verify=read_json(jd/'RLE_CAPTURE_VERIFICATION.json');side=read_json(jd/'RLE_STDOUT_RECEIPT.json')
 worker=read_json(jd/'NATIVE_WORKER_RECEIPT.json');outer=read_json(jd/'STDOUT_CAPTURE.json')
 require(verify.get('status')=='PASS' and verify.get('cap_reached') is False,'RLE transport incomplete/capped')
 for key in ('raw_bytes','raw_sha256','repeated_lines','data_records','cap_reached'):
  require(verify[key]==side[key],'RLE decoder/sidecar mismatch: '+key)
 require(worker.get('status')=='PROCESS_COMPLETED','Native worker did not complete')
 require(outer.get('capture_complete') is True and outer.get('limits_passed') is True and outer.get('roundtrip_verified') is True,'Encoded stdout outer capture incomplete')
 raw=jd/'stdout.txt.gz';require(sha(raw)==outer['compressed_sha256'] and raw.stat().st_size==outer['compressed_bytes'],'Captured transport byte binding')
 return {'status':'PASS','stream_decoded_independently_by_this_checker':False,'scope':'Pinned producer decoder verification, sidecar equality, worker completion and lossless outer capture; mathematical checker independently validates model and graph.', 'pins':[pin(jd/x) for x in ('RLE_CAPTURE_VERIFICATION.json','RLE_STDOUT_RECEIPT.json','NATIVE_WORKER_RECEIPT.json','STDOUT_CAPTURE.json','stdout.txt.gz')]}

def main():
 p=argparse.ArgumentParser();p.add_argument('--original-dir',required=True);p.add_argument('--job-dir',required=True);p.add_argument('--case-id',required=True);p.add_argument('--output-dir',required=True);a=p.parse_args()
 out=Path(a.output_dir).resolve();require(out.is_relative_to(HERE),'Checker output must remain in assigned checker directory')
 jd=Path(a.job_dir).resolve()
 try:
  freeze=read_json(HERE/'FREEZE.json')
  require(all(pin(HERE/x['file'])=={k:x[k] for k in ('path','bytes','sha256')} for x in freeze['files']),'Frozen checker drift')
  capture=capture_receipts(jd)
  c=check(Path(a.original_dir).resolve(),jd,a.case_id,out);c['capture_audit']=capture;c['checker_freeze_pin']=pin(HERE/'FREEZE.json')
  bound=[c.get(k) for k in ('native_result_pin','original_model_pin','job_model_pin') if c.get(k)]
  for group in c.get('BDD_pins',{}).values():bound.extend(group)
  bound.extend(capture['pins'])
  require(all(pin(Path(x['path']))==x for x in bound),'Input artifact changed during audit')
  c['bound_artifacts_unchanged_after_audit']=True
 except (Invalid,OSError,UnicodeError,KeyError,ValueError,TypeError,IndexError,ResourceRefusal) as e:
  c={'schema':'released-kind-corpus-certificate-v1','case_id':a.case_id,'status':'UNKNOWN_CAPTURE_OR_FREEZE_INTEGRITY','mapping_error':type(e).__name__+': '+str(e),'native_runs':0,'full_reset_uses':0}
 save(out/'certificate.json',c)
 print(json.dumps({k:c.get(k) for k in ('case_id','native_outcome','status','mapping_error','controller_defect')}))
if __name__=='__main__':main()
