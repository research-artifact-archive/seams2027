"""Mock-only recovery qualification. No process creation or signals allowed."""
from contextlib import ExitStack
from datetime import datetime, timezone, timedelta
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import errno
import gzip
import hashlib
import io
import json
import os
import signal
import subprocess
import sys

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import owned_process as o
import native_worker as w
import launcher as l

ROOT = BASE / 'offline' / datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
ROOT.mkdir(parents=True, exist_ok=False)
REPORT = []
FORBIDDEN = []
USAGE = SimpleNamespace(ru_maxrss=12345, ru_utime=0.1, ru_stime=0.2)
REAL_PID, REAL_UID = os.getpid(), os.getuid()


def require(value, message='Unexpected offline result'):
    if not value:
        raise AssertionError(message)


def forbidden(*args, **kwargs):
    FORBIDDEN.append(str(args))
    raise AssertionError('Actual spawn/signal/wait is forbidden in offline qualification')


def test(name, fn):
    try:
        detail = fn()
        REPORT.append({'name': name, 'pass': True, 'detail': detail})
    except Exception as error:
        REPORT.append({'name': name, 'pass': False, 'error': repr(error)})


def fixture(name):
    folder = ROOT / name
    folder.mkdir()
    source = folder / 'source.input'
    source.write_bytes(b'frozen source')
    return folder, source


class Clock:
    def __init__(self): self.value = 0
    def monotonic(self): return self.value
    def sleep(self, seconds): self.value += seconds


def raw(pid):
    return SimpleNamespace(pid=pid, stdout=io.BytesIO(), returncode=None)


def table_text(extra=''):
    return f'{REAL_PID} 1 {REAL_PID} {REAL_UID}\n' + extra


def ps_ok(extra=''):
    return {'status': 'COMPLETE', 'returncode': 0, 'stdout': table_text(extra), 'stderr': '',
            'exact_helper_wait4': {'exact_child_reaped': True, 'returncode': 0}}


def eperm(*args):
    raise PermissionError(errno.EPERM, 'synthetic denied')


def exact_wait(mode):
    child = o.ExactChild(raw(90001)); calls=[]
    def wait(pid, flags):
        calls.append((pid, flags))
        if mode == 'running': return 0, 0, USAGE
        if mode == 'ECHILD': raise ChildProcessError(errno.ECHILD, 'synthetic no child')
        if mode == 'EPERM': raise PermissionError(errno.EPERM, 'synthetic denied')
        return (90002 if mode == 'wrong_pid' else pid), (15 if mode == 'signal' else 0), USAGE
    with patch.object(o.os, 'wait4', wait):
        try: result=child.poll()
        except o.ChildAuthorityError:
            require(mode in ('ECHILD', 'EPERM', 'wrong_pid') and child.authority_lost and child.returncode is None)
            return child.evidence()
        if mode == 'running': require(result is None and not child.exact_reaped)
        else:
            require(child.exact_reaped and result == (-15 if mode == 'signal' else 0))
            require(child.poll() == result and len(calls) == 1)
            require(child.exact_usage['ru_maxrss'] == 12345)
        return child.evidence()


def owned_signal(mode):
    child=o.ExactChild(raw(90001));sent=[]
    wait_result=(90001,0,USAGE) if mode=='reaped' else (0,0,USAGE)
    with patch.object(o.os,'wait4',lambda *a:wait_result),patch.object(o.os,'getpgid',lambda pid:pid+1 if mode=='wrong_group' else pid),patch.object(o.os,'killpg',lambda pid,sig:sent.append((pid,int(sig)))):
        try:value=child.signal_owned_group(signal.SIGTERM)
        except o.ChildAuthorityError:
            require(mode=='wrong_group' and not sent);return {'signals':sent}
        require(sent==([(90001,15)] if mode=='live' else []));return value


def group_observation(mode):
    child=o.ExactChild(raw(90001));child.exact_reaped=mode not in ('live','wrong_uid')
    extra=''
    if mode=='live':extra=f'90001 {REAL_PID} 90001 {REAL_UID}\n'
    if mode=='wrong_uid':extra=f'90001 {REAL_PID} 90001 {REAL_UID+1}\n'
    if mode=='unexpected':extra=f'90002 1 90001 {REAL_UID}\n'
    answer=ps_ok(extra)
    if mode=='ps_fail':answer={'status':'UNKNOWN','returncode':1,'stdout':'','stderr':''}
    if mode=='malformed':answer=ps_ok('bad row\n')
    if mode=='missing_observer':answer={**ps_ok(),'stdout':'90002 1 90002 501\n'}
    observer=o.GroupObserver()
    with patch.object(o.os,'killpg',eperm),patch.object(o,'bounded_ps',lambda *a,**k:answer):
        value=observer.observe(child,final=mode not in ('live','wrong_uid'))
    if mode=='absent':require(value['state']=='ABSENT' and value['basis']=='SUCCESSFUL_PROCESS_TABLE_NO_GROUP_MEMBERS')
    elif mode=='live':require(value['state']=='PRESENT' and not value['unexpected_members'])
    elif mode=='unexpected':require(value['state']=='PRESENT' and value['unexpected_members'])
    elif mode=='wrong_uid':require(value['state']=='UNKNOWN' and value['unexpected_members'])
    else:require(value['state']=='UNKNOWN' and observer.integrity_errors)
    return value


def helper_control(mode):
    clock=Clock();killed=[False];sent=[]
    def spawn(command,**kwargs):
        require(command[0]=='/bin/ps')
        kwargs['stdout'].write(b'x'*(1024*1024+1) if mode=='fast_cap' else table_text().encode())
        return raw(90003)
    def wait(pid,flags):
        if mode in ('complete','fast_cap'):return pid,0,USAGE
        if killed[0] and mode!='unreaped':return pid,9,USAGE
        return 0,0,USAGE
    def kill(pid,sig):sent.append((pid,int(sig)));killed[0]=True
    with patch.object(o.subprocess,'Popen',spawn),patch.object(o.os,'wait4',wait),patch.object(o.os,'getpgid',lambda p:p),patch.object(o.os,'killpg',kill),patch.object(o.time,'monotonic',clock.monotonic),patch.object(o.time,'sleep',clock.sleep):
        value=o.bounded_ps('pid=,ppid=,pgid=,uid=')
    require(value['status']==('COMPLETE' if mode=='complete' else 'UNKNOWN'))
    require(clock.value<=1.02)
    if mode=='unreaped':require(not value['exact_helper_wait4']['exact_child_reaped'])
    if mode in ('timeout','unreaped'):require(sent==[(90003,9)])
    return {k:v for k,v in value.items() if k not in ('stdout','stderr')}


def worker_control(mode):
    folder,source=fixture('worker_'+mode);arm=folder/'arm';arm.mkdir();clock=Clock();ready=[mode!='resource'];signals=[]
    command=[sys.executable,'-c','pass'];refs=[w.pin(source)]
    class Capture:
        def __init__(self,stream,path,**kwargs):
            self.path=path;path.write_bytes(gzip.compress(b'synthetic output'));self.cap_reasons=[];self.error=None
            self.alert=SimpleNamespace(wait=lambda sec:clock.sleep(sec))
        def start(self):pass
        def finish(self):return {'reader_joined':True,'capture_complete':True,'eof_seen':True,'cap_reasons':[]}
    def spawn(argv,**kwargs):
        require(argv==command)
        (arm/'result.json').write_text('{"synthetic": true}\n')
        if mode=='resource':(arm/'large.dat').write_bytes(b'x'*70000)
        if mode=='source_mutation':source.write_bytes(b'changed')
        return raw(90004)
    def wait(pid,flags):
        if mode=='ECHILD':raise ChildProcessError(errno.ECHILD,'synthetic no child')
        return (pid,(15 if mode=='resource' else 0),USAGE) if ready[0] else (0,0,USAGE)
    def kill(pid,sig):
        if sig==0:raise PermissionError(errno.EPERM,'synthetic group probe denied')
        signals.append((pid,int(sig)));ready[0]=True
    answer=ps_ok() if mode!='observation_failure' else {'status':'UNKNOWN','returncode':None,'stdout':'','stderr':'','reason':'OBSERVATION_TIMEOUT'}
    with ExitStack() as stack:
        for obj,name,value in [(w,'_RUN_USED',False),(w,'LosslessStdout',Capture),(w,'child_usage',lambda:{'ru_maxrss':0,'ru_utime':0,'ru_stime':0}),
            (w.subprocess,'Popen',spawn),(o.os,'wait4',wait),(o.os,'killpg',kill),(o.os,'getpgid',lambda p:p),
            (o,'bounded_ps',lambda *a,**k:answer),(o.time,'monotonic',clock.monotonic),(o.time,'sleep',clock.sleep)]:stack.enter_context(patch.object(obj,name,value))
        result=w.run_native(command,str(arm), (datetime.now(timezone.utc)+timedelta(hours=1)).isoformat(),
                            {'qualification_only':True,'other_file_bytes':65536},refs)
    expected='PROCESS_COMPLETED' if mode=='complete' else ('TECHNICAL_RESOURCE_REFUSAL' if mode=='resource' else 'FATAL_INTEGRITY_FAILURE')
    require(result['status']==expected,repr((mode,result['status'],result['fatal_reasons'])))
    if mode in ('complete','resource'):
        require(result['child_reaped'] and result['process_group_contained'])
        require(result['peak_rss']['bytes']==12345 and result['peak_rss']['rusage_field']=='os.wait4(exact_native_pid).ru_maxrss')
    if mode=='ECHILD':require(result['returncode'] is None and not result['child_reaped'])
    if mode=='source_mutation':require(result['source_pin_errors_after'])
    if mode=='resource':require(signals==[(90004,15)])
    return {'status':result['status'],'signals':signals,'fatal_reasons':result['fatal_reasons'],'native_calls':0,'synthetic_fixture_receipt':str(arm/'NATIVE_WORKER_RECEIPT.json')}


def make_worker_receipt(request_path,worker_pid,status='PROCESS_COMPLETED',bad=None):
    request=l.read(request_path);arm=Path(request['arm_dir']);command=request['command'];native_pid=90006
    identity={'schema':'contained-native-child-identity-v1','worker_pid':worker_pid,'child_pid':native_pid,'process_group_id':native_pid,'command':command,
              'command_sha256':hashlib.sha256(json.dumps(command,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()}
    if bad=='identity':identity['worker_pid']+=1
    l.save(arm/'NATIVE_CHILD_IDENTITY.json',identity);(arm/'result.json').write_text('{"synthetic":true}')
    receipt={'schema':'contained-native-worker-receipt-v1','worker_pid':worker_pid,'command':command,'arm_dir':str(arm),'parent_aborted':True,
       'worker_spawned_children':1,'scientific_JVM_executions':1,'qualification_only':False,'source_pins':request['source_pins'],
       'child_pid':native_pid,'native_child_identity':l.pin(arm/'NATIVE_CHILD_IDENTITY.json'),'child_reaped':True,'returncode':0,
       'process_group_contained':True,'status':status,'final_group_observation':{'state':'ABSENT','basis':'SUCCESSFUL_PROCESS_TABLE_NO_GROUP_MEMBERS'},
       'exact_child_wait4':{'pid':native_pid,'exact_child_reaped':True,'returncode':0,'wait_status':0,'authority_lost':False,'exact_child_rusage':{'ru_maxrss':12345}},
       'source_pin_errors_before':[],'source_pin_errors_after':[],'worker_source_pin_errors_after':[],'result_pin_errors_after':[],
       'artifacts':{p.name:l.pin(p) for p in [request_path,arm/'NATIVE_CHILD_IDENTITY.json',arm/'result.json']}}
    if bad=='worker_pid':receipt['worker_pid']+=1
    if bad=='wait4':receipt['exact_child_wait4']['pid']+=1
    if bad=='artifact':(arm/'result.json').write_text('changed')
    l.save(arm/'NATIVE_WORKER_RECEIPT.json',receipt)


def parent_control(mode):
    folder,source=fixture('parent_'+mode);arm=folder/'arm';command=['java','Fixture'];clock=Clock();reaped=[False];signals=[]
    def spawn(argv,**kwargs):
        request_path=Path(argv[-1]);request=l.read(request_path)
        if mode not in ('missing','timeout','wrong_live_parent','wrong_identity'):
            status='TECHNICAL_RESOURCE_REFUSAL' if mode=='resource' else 'PROCESS_COMPLETED'
            make_worker_receipt(request_path,90005,status,bad=mode if mode in ('worker_pid','identity','wait4','artifact') else None)
        if mode in ('timeout','wrong_live_parent','wrong_identity'):
            identity={'schema':'contained-native-child-identity-v1','worker_pid':90005+(1 if mode=='wrong_identity' else 0),'child_pid':90006,'process_group_id':90006,
                 'command':command,'command_sha256':hashlib.sha256(json.dumps(command,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()}
            l.save(arm/'NATIVE_CHILD_IDENTITY.json',identity)
        if mode=='fast_cap':kwargs['stdout'].write(b'x'*129)
        if mode=='source_mutation':source.write_bytes(b'changed')
        return raw(90005)
    def wait(pid,flags):
        if mode in ('timeout','wrong_live_parent','wrong_identity') and not reaped[0]:return 0,0,USAGE
        return pid,256 if mode=='resource' else 0,USAGE
    def kill(pid,sig):
        if sig==0:raise ProcessLookupError(errno.ESRCH,'synthetic absent')
        signals.append((pid,int(sig)))
        if pid==90005 and sig==signal.SIGKILL:reaped[0]=True
    def table():
        rows={REAL_PID:{'pid':REAL_PID,'ppid':1,'pgid':REAL_PID,'uid':REAL_UID,'stat':'S'}}
        if not reaped[0]:
            rows[90005]={'pid':90005,'ppid':REAL_PID,'pgid':90005,'uid':REAL_UID,'stat':'T'}
            rows[90006]={'pid':90006,'ppid':90007 if mode=='wrong_live_parent' else 90005,'pgid':90006,'uid':REAL_UID,'stat':'S'}
        return rows,{'status':'COMPLETE','synthetic':True}
    with ExitStack() as stack:
        for obj,name,value in [(l.subprocess,'Popen',spawn),(o.os,'wait4',wait),(o.os,'getpgid',lambda p:p),(o.os,'killpg',kill),
             (o,'bounded_ps',lambda *a,**k:ps_ok()),(l,'process_table',table),(l,'PARENT_WATCHDOG_SECONDS',0.2),
             (l,'OUTER_CAPTURE_BYTES',128),(o.time,'monotonic',clock.monotonic),(o.time,'sleep',clock.sleep)]:stack.enter_context(patch.object(obj,name,value))
        result=l.launch_native(command,arm,(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat(),[l.pin(source)])
    if mode in ('complete','resource'):
        require(result['status']==('COMPLETE_PROCESS_AND_CAPTURE' if mode=='complete' else 'UNKNOWN_RESOURCE') and not result['global_stop'],repr(result))
        require(result['native_called'] is True)
    else:require(result['status']=='UNKNOWN_INTEGRITY' and result['global_stop'])
    if mode in ('missing','worker_pid','identity'):require(result['native_called'] is None)
    if mode=='timeout':require(signals==[(90005,int(signal.SIGSTOP)),(90006,9),(90005,9)],repr(signals))
    if mode in ('wrong_live_parent','wrong_identity'):require(signals==[(90005,int(signal.SIGSTOP)),(90005,9)],repr(signals))
    return {'status':result['status'],'global_stop':result['global_stop'],'native_called':result['native_called'],'synthetic_signals':signals,'receipt':str(arm/'PARENT_RECEIPT.json')}


def reserve_control(mode):
    folder,source=fixture('reserve_'+mode);arm=folder/'arm'
    deadline=datetime.now(timezone.utc)+timedelta(seconds=149 if mode=='entry' else 1000)
    if mode=='pre_spawn':
        with patch.object(l,'reserve_reason',side_effect=[None,None,'DEADLINE_START_RESERVE']):
            result=l.launch_native(['java','Fixture'],arm,deadline.isoformat(),[l.pin(source)])
    else:result=l.launch_native(['java','Fixture'],arm,deadline.isoformat(),[l.pin(source)])
    require(result['status']=='UNKNOWN_NOT_ATTEMPTED' and result['native_called'] is False and not result['worker_started']);return result['reason']


with patch.object(subprocess,'Popen',forbidden),patch.object(os,'killpg',forbidden),patch.object(os,'kill',forbidden),patch.object(os,'wait4',forbidden):
    for mode in ('running','exit','signal','ECHILD','EPERM','wrong_pid'):test('exact_wait4_'+mode,lambda mode=mode:exact_wait(mode))
    for mode in ('live','reaped','wrong_group'):test('owned_signal_'+mode,lambda mode=mode:owned_signal(mode))
    for mode in ('absent','live','wrong_uid','unexpected','ps_fail','malformed','missing_observer'):test('EPERM_group_'+mode,lambda mode=mode:group_observation(mode))
    for mode in ('complete','timeout','unreaped','fast_cap'):test('bounded_ps_'+mode,lambda mode=mode:helper_control(mode))
    for mode in ('complete','resource','ECHILD','source_mutation','observation_failure'):test('copied_worker_'+mode,lambda mode=mode:worker_control(mode))
    for mode in ('complete','resource','missing','worker_pid','identity','wait4','artifact','source_mutation','fast_cap','timeout','wrong_live_parent','wrong_identity'):test('parent_'+mode,lambda mode=mode:parent_control(mode))
    for mode in ('entry','pre_spawn'):test('reserve_'+mode,lambda mode=mode:reserve_control(mode))

require(not FORBIDDEN,'Forbidden real process/signal operation reached')
report={'schema':'contained-recovery-offline-qualification-v1','status':'PASS' if all(x['pass'] for x in REPORT) else 'FAIL',
        'passed':sum(x['pass'] for x in REPORT),'total':len(REPORT),'tests':REPORT,'evidence_class':'MOCK_ONLY_NO_HOST_PROCESS_QUALIFICATION',
        'actual_native_calls':0,'actual_process_spawns':0,'actual_signals':0,'full_reset_uses':0,
        'source_pins':[l.pin(BASE/name) for name in ('owned_process.py','native_worker.py','launcher.py','lossless_stdout.py','qualify_offline.py')],
        'limitations':'Mock controls establish branch behavior only. They do not qualify actual OS process/signal behavior. Synthetic receipt counters are not scientific executions.'}
l.save(BASE/'OFFLINE_QUALIFICATION.json',report)
print(json.dumps({'status':report['status'],'passed':report['passed'],'total':report['total'],'failures':[x for x in REPORT if not x['pass']]},indent=2))
raise SystemExit(0 if report['status']=='PASS' else 1)
