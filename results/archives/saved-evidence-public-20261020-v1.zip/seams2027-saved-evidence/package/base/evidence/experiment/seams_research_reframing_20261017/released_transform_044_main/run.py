"""One fixed044 pair, with closed three-case qualification and no solver route."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,importlib.util,json,os,sys,time
sys.dont_write_bytecode=True
from evidence import B,P,R,Q,H,ID,MODES,RECOVERY,STAGE,probe,read,save,pin,pins_in,unique,verify,require,now,select,authorization,native_sources,native_refs,old_schedule
CODE=('evidence.py','scope.py','check_pair.py','run.py','qualify_offline.py','PROTOCOL_JA.txt','OFFLINE_QUALIFICATION.json','SOURCE_SCOPE.json','map_pair.py','relations.py','pair_support.py','PAIR_ADAPTATION.diff','qualify_math.py','MATH_QUALIFICATION.json')

def prepare():
    require(not (B/'FROZEN.json').exists(),'No frozen overwrite')
    if not (B/'SELECTION.json').exists():save(B/'SELECTION.json',select())
    s=read(B/'SELECTION.json');verify(s['input_pins']);q=read(B/'OFFLINE_QUALIFICATION.json');m=read(B/'MATH_QUALIFICATION.json')
    for r in (q,m):
        require(r['status']=='PASS' and r['corpus_BDD_computations']==r['actual_child_processes']==0,'Synthetic-only preparation qualification');verify(r['source_pins'])
    require(q['new_native_JVM_calls']==m['native_runs']==0,'No scientific native preparation')
    code=[pin(B/n) for n in CODE]+read(P/'FROZEN.json')['native_files']+[pin(R/n) for n in ('evidence.py','trace_bridge.py','FROZEN.json','RUN_RECEIPT.json')]
    code += [pin(Q/n) for n in ('evidence.py','FROZEN.json','RUN_RECEIPT.json','JOINED_QUALIFICATION.json')]+[pin(H/n) for n in ('FROZEN.json','map_pair.py','relations.py','measure.py','qualify_math.py','MATH_QUALIFICATION.json')]
    native=unique(code);code += [pin(STAGE/'FROZEN.json')]+pins_in(read(STAGE/'FROZEN.json'))+[pin(Path(sys.executable).resolve())]
    code=unique(code);files=unique(code+s['input_pins']+[pin(B/'SELECTION.json')]);verify(files)
    save(B/'FROZEN.json',{'schema':'fixed044-transform-main-freeze-v1','created_utc':now(),'files':files,'code_files':code,'native_files':native,
        'python':pin(Path(sys.executable).resolve()),'selection':pin(B/'SELECTION.json'),'id':ID,'native_JVM_budget':2,'solver_budget':0,
        'limits':read(P/'FROZEN.json')['limits'],'new_native_JVM_calls':0,'corpus_BDD_computations':0,'U_F_direct_analysis_authorized':False,
        'root_review_status':'AWAITING_ROOT_MODEL_ONLY044_REVIEW'})
    print(json.dumps({'status':'PREPARED_044_NOT_STARTED','files':len(files),'native_files':len(native),'freeze':pin(B/'FROZEN.json')}))

def validate(result,freeze,selected,decision):
    require(result.get('schema')=='fixed044-model-main-check-v1' and result.get('id')==ID and result.get('status') in ('PASS','UNKNOWN_RESOURCE','UNKNOWN_INTEGRITY'),'Exact044 child identity/status')
    require(result.get('root_authorization')==decision and result.get('joined_qualification')==selected['joined_qualification'],'044 authorization and joined-qualification provenance')
    for k in ('checker_native_JVM_calls','solver_calls','controller_calls','full_reset_uses'):require(type(result.get(k)) is int and result[k]==0,'Exact zero '+k)
    require(result.get('old_global_stop_preserved') is True and result.get('v1_resumed') is False and result.get('U_F_direct_analysis_authorized') is False and result.get('winning_or_K_preservation_conclusion') is None,'No v1 resume or future scientific transfer')
    if result['status']=='PASS':
        expected=freeze['code_files']+selected['input_pins']+[pin(B/'FROZEN.json'),pin(B/'SELECTION.json'),decision]
        require(result['input_pins']==expected,'Exact044 source/code/decision pins')
        require(set(result['comparisons'])=={'original'} and set(result['native_exports'])==set(MODES) and result['released_old_reference_available'] is False,'Original-only prior reference; two complete native exports')
        c=result['comparisons']['original'];require(c['status']=='PASS' and c['source_inventory_fully_accounted_for'] is True and c['source_inventory_bridge']['status']=='PASS' and c['same_generator_configuration_claim'] is False,'Narrow044 source-bound trace bridge')
        pair=result['pair_structure'];require(pair['status']=='PASS' and pair['all_original_fields_and_AUX_retained'] is True and pair['helper_added'] is True and pair['original_carrier']==18816 and pair['released_carrier']==37632,'044 full carrier/AUX and helper branch')
        require(result['original_model_canonical_bound_to_independent_proof'] is True and result['authoritative_original_model']==selected['case']['authoritative_original_model'] and result['original_independent_proof']==selected['case']['original_independent_proof'],'Original reference bound to prior independent proof')
        rel=result['all_quadrant_relations'];require(rel['all_original_current_next_and_logical_AUX_retained'] is True and rel['projection_or_existential_elimination_of_original_AUX'] is False and rel['typed_original_edge_domain_count']==18816**2,'Full typed edge quadrant audit')
        require([q['quadrant'] for q in rel['quadrants']]==['00','01','10','11'],'Four ordered quadrants')
        zero=rel['quadrants'][0]['checks'];require(all(zero[k]['equal'] is True for k in ('ENV_literal_and_corrected','SYS_literal','SYS_corrected')) and result['supplemental_full_current_checks']['all_equal'] is True,'00/init/ordered justice correspondence')
        require(result['relation_classification_is_observation_not_theorem_assumption'] is True and result['ready_for_separately_reviewed_U_F_and_direct_analysis'] is True,'Future decomposition boundary')
        require(result['canonical_functions']==pin(B/'runs'/ID/'FUNCTIONS.json.gz'),'Actual canonical function artifact pin')

def run(deadline):
    decision=authorization();d=read(decision['path']);require(d.get('deadline_utc')==deadline,'Exact authorized deadline')
    end=datetime.fromisoformat(deadline);require(end.tzinfo is not None,'Absolute timezone-aware deadline')
    freeze=read(B/'FROZEN.json');selected=read(B/'SELECTION.json');case=selected['case'];verify(freeze['files']+[decision])
    require(freeze['python']==pin(Path(sys.executable).resolve()),'Frozen Python identity')
    require(not (B/'RUN_STARTED.json').exists() and not (B/'runs').exists() and not (B/'RUN_RECEIPT.json').exists(),'One separate044 dispatch; no resume/retry')
    save(B/'RUN_STARTED.json',{'started_utc':now(),'owner_pid':os.getpid(),'freeze':pin(B/'FROZEN.json'),'root_authorization':decision})
    sys.path.insert(0,str(RECOVERY));sp=importlib.util.spec_from_file_location('main044_contained_launcher',RECOVERY/'launcher.py');launcher=importlib.util.module_from_spec(sp);sp.loader.exec_module(launcher)
    sp=importlib.util.spec_from_file_location('main044_contained_savedcheck',STAGE/'bounded_process.py');bounded=importlib.util.module_from_spec(sp);sp.loader.exec_module(bounded)
    outputs=[decision,pin(B/'RUN_STARTED.json'),selected['joined_qualification']]
    def attempt(ident,mode):
        require(ident==ID,'One044 case only');arm=B/'runs'/ID/mode;refs=native_sources(freeze,case,decision);verify(refs)
        parent=launcher.launch_native(probe.command(case,mode,arm),arm,deadline,refs)
        p=pin(arm/'PARENT_RECEIPT.json');outputs.append(p)
        outs=[parent[k] for k in ('worker_receipt_pin','child_identity_pin','worker_stdout','worker_stderr') if parent.get(k)]+list((parent.get('worker_receipt') or {}).get('artifacts',{}).values())
        verify(outs);outputs.extend(outs)
        if parent['status']=='COMPLETE_PROCESS_AND_CAPTURE':outputs.extend(native_refs(arm,case,mode,decision,freeze))
        return {'status':parent['status'],'native_called':parent['native_called'],'global_stop':parent['global_stop'],'parent_receipt':p}
    def compare(ident):
        folder=B/'runs'/ident;target=folder/'CHECK.json';verify(freeze['code_files']+[decision])
        process=bounded.run_bounded([sys.executable,'-B',str(B/'check_pair.py')],folder/'check_process',deadline,wall_seconds=60,file_bytes=64*1024*1024,watch_files=[target,folder/'FUNCTIONS.json.gz'])
        pr=pin(folder/'check_process/PROCESS_RECEIPT.json');outputs.append(pr)
        row={'status':'UNKNOWN_PROCESS','checker_started':process['process_started'],'check_process':pr}
        if process['status']=='PROCESS_COMPLETED' and process['exit_code']==0 and target.is_file():
            result=read(target);validate(result,freeze,selected,decision);row.update(status=result['status'],check=pin(target));outputs.extend([row['check']]+pins_in(result));verify(pins_in(result))
        elif process['status']=='UNKNOWN_RESOURCE':row['status']='UNKNOWN_RESOURCE'
        return row
    started=time.monotonic();rows,stop,reasons=old_schedule()((ID,),lambda:(end-datetime.now(timezone.utc)).total_seconds(),attempt,compare)
    try:verify(freeze['files']+outputs)
    except BaseException as ex:stop=True;reasons.append('FINAL_PIN_INTEGRITY:'+repr(ex))
    calls=[a['native_called'] for row in rows for a in row['arms']]
    good=not stop and len(rows)==1 and rows[0]['status']=='PASS'
    result={'schema':'fixed044-transform-main-run-v1','finished_utc':now(),'elapsed_seconds':time.monotonic()-started,
        'status':'PASS_044_MODEL_PAIR' if good else 'UNKNOWN_INCOMPLETE','rows':rows,'global_stop':stop,'stop_reasons':reasons,
        'freeze':pin(B/'FROZEN.json'),'root_authorization':decision,'output_pins':unique(outputs),'joined_qualification':selected['joined_qualification'],
        'stopped_v1_qualification':selected['stopped_v1_qualification'],'old_global_stop_preserved':True,'v1_resumed':False,
        'native_JVM_calls':{'confirmed':sum(x is True for x in calls),'uncertain':sum(x is None for x in calls),'not_called':sum(x is False for x in calls)},
        'solver_calls':0,'controller_calls':0,'full_reset_uses':0,'U_F_direct_analysis_authorized':False,'unknown_is_negative':False,'winning_or_K_preservation_conclusion':None}
    if good:require(result['native_JVM_calls']=={'confirmed':2,'uncertain':0,'not_called':0},'Exactly two044 model probes')
    save(B/'RUN_RECEIPT.json',result)
    print(json.dumps({k:result[k] for k in ('status','global_stop','native_JVM_calls')}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('prepare','preflight','run'));p.add_argument('--deadline-utc');a=p.parse_args()
    if a.mode=='prepare':prepare()
    elif a.mode=='preflight':verify(read(B/'FROZEN.json')['files']);print('Frozen044 preparation PASS; no corpus BDD/native process')
    else:require(a.deadline_utc is not None,'Explicit root deadline required');run(a.deadline_utc)
