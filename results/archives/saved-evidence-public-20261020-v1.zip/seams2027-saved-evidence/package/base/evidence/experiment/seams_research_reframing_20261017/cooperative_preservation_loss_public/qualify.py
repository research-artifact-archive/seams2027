"""Synthetic set/import/authority checks; no corpus BDD or process dispatch."""
from pathlib import Path
from types import SimpleNamespace
from itertools import product
from datetime import datetime,timedelta,timezone
from unittest.mock import patch
import copy,gzip,importlib.util,json,signal,sys,tempfile
sys.dont_write_bytecode=True
from evidence import B,read,save,pin,require,now
from intersection import BDD,compute,summarize,load_k,import_loss,load_loss,export,count,root_digest
spec=importlib.util.spec_from_file_location('cooperative_loss_qualification_runner',B/'run.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
tests=[];set_triples=0;parent_mock_runs=0


def test(name,fn):
    try:fn();tests.append({'name':name,'pass':True})
    except Exception as ex:tests.append({'name':name,'pass':False,'error':repr(ex)})


def rejects(fn):
    try:fn()
    except (ValueError,KeyError,TypeError):return
    raise AssertionError('Expected rejection')


def fixture(ne,ns):
    eb,sb=(ne-1).bit_length(),(ns-1).bit_length()
    ec=[2*i for i in range(eb)];en=[x+1 for x in ec]
    sc=[2*(eb+i) for i in range(sb)];sn=[x+1 for x in sc];current=ec+sc;b=BDD(2*(eb+sb))
    bits=lambda value,vs:{v:bool(value>>i&1) for i,v in enumerate(vs)}
    vals=list(product(range(ne),range(ns)))
    cubes=[b.cube(bits(e,ec)|bits(y,sc)) for e,y in vals]
    region=lambda states:b.disj(*(cubes[i] for i in states))
    def field(name,owner,role,n,cb,nb):
        return {'name':name,'owner':owner,'role':role,'values':[str(x) for x in range(n)],'domain_size':n,
            'current_bits':cb,'next_bits':nb,'encoding':{str(x):{'current':{str(k):v for k,v in bits(x,cb).items()},
            'next':{str(k):v for k,v in bits(x,nb).items()}} for x in range(n)}}
    model=SimpleNamespace(b=b,q=region(range(len(vals))),current=current,ec=ec,sc=sc,en=en,sn=sn,
        fields=[field('e','ENV','ENV',ne,ec,en),field('aux','SYS','AUX',ns,sc,sn)])
    return model,region,vals


def exhaustive(ne,ns):
    global set_triples
    model,region,vals=fixture(ne,ns);b=model.b
    sets=[{i for i in range(len(vals)) if mask>>i&1} for mask in range(1<<len(vals))]
    for k,loss,reachable in product(sets,repeat=3):
        roots=compute(b,model.q,model.current,region(k),region(loss),region(reachable))
        expected={'K':k,'exact_loss':loss,'original_reachable':reachable,
            'cooperative_loss':k&loss,'original_reachable_cooperative_loss':reachable&k&loss}
        require(all(roots[n]==region(v) for n,v in expected.items()),'Independent finite-set triple intersection')
        out=summarize(model,roots)
        require(out['counts']=={n:len(v) for n,v in expected.items()},'Exact counts from complete typed carrier')
        for n in ('cooperative_loss','original_reachable_cooperative_loss'):
            require(out[n+'_nonempty']==bool(expected[n]),'Empty versus positive exact result')
            w=out['state_witnesses'][n]
            require((w is None)==(not expected[n]),'Witness existence')
            if w:
                require(set(w['state'])=={'e','aux'} and w['all_logical_AUX_retained'] and w['not_a_strategy_or_runtime_trace'],'Full logical AUX and witness scope')
                state=(int(w['state']['e']),int(w['state']['aux']))
                require(vals.index(state) in expected[n],'Witness finite-set membership')
        set_triples+=1


def domain_rejection():
    m,region,_=fixture(1,3)
    invalid=m.b.conj(m.b.var(m.sc[0]),m.b.var(m.sc[1]))
    for k,l,r in ((invalid,0,0),(0,invalid,0),(0,0,invalid),(m.b.var(m.sn[0]),0,0)):
        rejects(lambda:compute(m.b,m.q,m.current,k,l,r))


def importers():
    m,region,_=fixture(2,2);b=m.b
    k=region({0,1,3});loss=region({1,2});reachable=region({0,1})
    kp={'schema':'independent-canonical-robdd-region-set-v1','variable_count':b.n,
        'canonical_variable_order':list(range(b.n)),'fields':m.fields,'roots':{'K':k},
        'nodes':[[i,*row] for i,row in enumerate(b.nodes) if i>1]}
    proof={'counts':{'K':3},'comparisons':{'K':{'equal':True,'independent_count':3,'canonical_sha256':root_digest(b,k)}}}
    lp={**kp,'schema':'complete-semantic-preservation-loss-robdd-v1','current_bits':m.current,
        'ENV_current_bits':m.ec,'SYS_and_AUX_current_bits':m.sc,'ENV_next_bits':m.en,'SYS_and_AUX_next_bits':m.sn,
        'roots':{'W_minus_W_C':loss,'original_reachable':reachable}}
    old={'counts':{'W_minus_W_C':2,'original_reachable':2},
        'canonical_sha256':{'W_minus_W_C':root_digest(b,loss),'original_reachable':root_digest(b,reachable)}}
    with tempfile.TemporaryDirectory(dir=B,prefix='qualification-') as td:
        path=Path(td)/'independent.json.gz'
        def write(payload):
            with gzip.open(path,'wb') as f:f.write(json.dumps(payload).encode())
        write(kp);require(load_k(m,path,proof)==k,'Saved authoritative K imported')
        for key in ('equal','independent_count','canonical_sha256'):
            bad=copy.deepcopy(proof);bad['comparisons']['K'][key]={'equal':False,'independent_count':2,'canonical_sha256':'0'*64}[key]
            rejects(lambda:load_k(m,path,bad))
        for key in ('fields','variable_count','canonical_variable_order'):
            bad=copy.deepcopy(kp);bad[key]={'fields':[],'variable_count':b.n+2,'canonical_variable_order':list(reversed(range(b.n)))}[key]
            write(bad);rejects(lambda:load_k(m,path,proof))
        write(lp);require(load_loss(m,path,old)=={'W_minus_W_C':loss,'original_reachable':reachable},'Saved loss and reach imported')
        for key in ('schema','variable_count','canonical_variable_order','fields','current_bits','ENV_current_bits','SYS_and_AUX_current_bits','ENV_next_bits','SYS_and_AUX_next_bits'):
            bad=copy.deepcopy(lp);bad[key]='BAD' if key=='schema' else b.n+1 if key=='variable_count' else []
            rejects(lambda:import_loss(m,bad,old))
        for name in ('W_minus_W_C','original_reachable'):
            bad=copy.deepcopy(lp);del bad['roots'][name];rejects(lambda:import_loss(m,bad,old))
            bad=copy.deepcopy(old);bad['counts'][name]+=1;rejects(lambda:import_loss(m,lp,bad))
            bad=copy.deepcopy(old);bad['canonical_sha256'][name]='0'*64;rejects(lambda:import_loss(m,lp,bad))
        roots=compute(b,m.q,m.current,k,loss,reachable);export(Path(td)/'out.json.gz',m,roots)
        with gzip.open(Path(td)/'out.json.gz','rb') as f:out=json.load(f)
        require(out['roots']==roots and out['fields']==m.fields and out['SYS_and_AUX_current_bits']==m.sc,'Complete export identity')
        for name,root in roots.items():
            view={**out,'schema':'independent-canonical-robdd-region-set-v1','roots':{'W':root}}
            from intersection import condition
            require(condition.import_w(b,view,m.fields)==root,'Every exported Boolean function round trip')


def child_admission():
    for started in (False,True,None):
        v={'status':'UNKNOWN_NOT_ATTEMPTED','BDD_worker_started':started}
        require(runner.preserve_interrupted_attempt(v)['status']==('UNKNOWN_NOT_ATTEMPTED' if started is False else 'UNKNOWN_RUNNER_FAILURE'),'Interrupted accounting')
    decision={'path':'decision','bytes':0,'sha256':'0'*64};p={'path':'synthetic','bytes':0,'sha256':'1'*64}
    q={'value':False,'missing_environment_initial_count':1,'system_witness_count':0}
    row={'proof':{'path':'proof'},'process':p,'loss_proof':{'path':'loss'},'loss_process':p,'input_pins':[],
        'original_K_count':2,'original_K_initial_quantification':q}
    old={'counts':{'W_minus_W_C':3,'original_reachable':4},'canonical_sha256':{'W_minus_W_C':'2'*64,'original_reachable':'3'*64}}
    proof={'comparisons':{'K':{'canonical_sha256':'1'*64}}}
    base={'id':'synthetic','schema':'cooperative-preservation-loss-case-v1','status':'PASS','root_authorization':decision,'parent_aborted':True,
        'native_runs':0,'new_fixed_point_runs':0,'full_reset_uses':0,'complete_semantic_literal_only':True,
        'released_syntactic_loss_conclusion':None,'runtime_or_controller_reachability_conclusion':None,
        'cooperative_initializer_false_rejection_conclusion':None,
        'counts':{'K':2,'exact_loss':3,'original_reachable':4,'cooperative_loss':1,'original_reachable_cooperative_loss':1},
        'canonical_sha256':{'K':'1'*64,'exact_loss':'2'*64,'original_reachable':'3'*64,'cooperative_loss':'4'*64,'original_reachable_cooperative_loss':'5'*64},
        'cooperative_loss_nonempty':True,'original_reachable_cooperative_loss_nonempty':True,
        'state_witnesses':{n:{'all_logical_AUX_retained':True,'not_a_strategy_or_runtime_trace':True} for n in ('cooperative_loss','original_reachable_cooperative_loss')},
        'original_K_initial_quantification':q,'original_K_initial_recomputed':False,'original_independent_proof':row['proof'],
        'original_independent_process':p,'exact_loss_proof':row['loss_proof'],'exact_loss_process':p,'input_pins':[p,p,decision],'functions':p}
    with patch.object(runner,'pin',return_value=p),patch.object(runner,'verify',return_value=None),patch.object(runner,'read',side_effect=lambda path:proof if path=='proof' else old):
        runner.admit_pass(base,'synthetic',row,{'code_files':[]},decision)
        for key in ('status','counts','cooperative_loss_nonempty','state_witnesses','canonical_sha256','original_K_initial_quantification','original_K_initial_recomputed','exact_loss_process','input_pins','cooperative_initializer_false_rejection_conclusion'):
            bad=copy.deepcopy(base)
            if key=='status':bad[key]='UNKNOWN_INCOMPLETE'
            elif key=='counts':bad[key]['cooperative_loss']=3
            elif key=='cooperative_loss_nonempty':bad[key]=False
            elif key=='state_witnesses':bad[key]['cooperative_loss']=None
            elif key=='canonical_sha256':bad[key]['K']='0'*64
            elif key=='original_K_initial_quantification':bad[key]['value']=True
            elif key=='original_K_initial_recomputed':bad[key]=True
            elif key=='cooperative_initializer_false_rejection_conclusion':bad[key]='claimed'
            elif key=='input_pins':bad[key]=[]
            else:bad[key]={}
            rejects(lambda:runner.admit_pass(bad,'synthetic',row,{'code_files':[]},decision))


MOCK_STAGE='''import json,hashlib
from pathlib import Path
def run_bounded(argv,directory,deadline,**kwargs):
    root=Path(directory).parents[2];mode=(root/'MODE.txt').read_text()
    if mode=='wrapper_exception':raise RuntimeError('mock uncertain start')
    p=Path(directory);p.mkdir(parents=True);ident=argv[-1]
    process={'process_started':True,'status':'UNKNOWN_RESOURCE' if mode=='resource' else 'PROCESS_COMPLETED','exit_code':7 if mode=='nonzero' else 0}
    (p/'PROCESS_RECEIPT.json').write_text(json.dumps(process))
    dp=root/'ROOT_START_DECISION.json';raw=dp.read_bytes();decision={'path':str(dp),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    status={'unknown_status':'UNRECOGNIZED','integrity':'UNKNOWN_INTEGRITY','bad_pass':'PASS'}.get(mode,'UNKNOWN_RESOURCE')
    result={'id':ident,'schema':'cooperative-preservation-loss-case-v1','status':status,'root_authorization':decision,'parent_aborted':True,
      'native_runs':0,'new_fixed_point_runs':0,'full_reset_uses':0,'complete_semantic_literal_only':True,
      'released_syntactic_loss_conclusion':None,'runtime_or_controller_reachability_conclusion':None,'cooperative_initializer_false_rejection_conclusion':None}
    if mode!='missing_result':(p.parent/'RESULT.json').write_text('broken' if mode=='broken_result' else json.dumps(result))
    if mode=='decision_changed':dp.write_text('{}')
    return process
'''


def parent_case(mode):
    global parent_mock_runs
    with tempfile.TemporaryDirectory(dir=B,prefix='qualification-parent-') as td:
        root=Path(td);stage=root/'stage';stage.mkdir();(stage/'bounded_process.py').write_text(MOCK_STAGE);(root/'MODE.txt').write_text(mode)
        ids=['synthetic%03d'%i for i in range(425)]
        rows=[{'id':ident,'eligible':i<9,'not_selected_reason':'UNKNOWN_EXACT_LOSS_RESOURCE' if i==9 else 'NOT_SELECTED_CONDITION_PRESERVED' if i<59 else 'UNKNOWN_NO_AUTHORITATIVE_W',
            'prior_status':'PASS' if i<59 else 'UNKNOWN','condition_status':'PASS' if i<59 else 'UNKNOWN','condition_W_subset_C':i>=10,
            'exact_loss_status':'PASS' if i<9 else 'UNKNOWN_RESOURCE' if i==9 else 'NOT_SELECTED'} for i,ident in enumerate(ids)]
        save(root/'SELECTION.json',{'eligible_count':9,'eligible_ids':ids[:9],'rows':rows,'exact_loss_resource_unknown_ids':[ids[9]]})
        save(root/'FROZEN.json',{'files':[],'code_files':[],'python':pin(Path(sys.executable).resolve())})
        save(root/'ROOT_START_DECISION.json',{'start_authorized':True,'freeze':pin(root/'FROZEN.json')})
        end=datetime.now(timezone.utc)+timedelta(hours=1)
        class AuditClock:
            calls=0
            fromisoformat=staticmethod(datetime.fromisoformat)
            @classmethod
            def now(cls,tz):
                cls.calls+=1
                return end-timedelta(seconds=100) if cls.calls==1 else end
        with patch.object(runner,'B',root),patch.object(runner,'STAGE',stage):
            if mode=='post_audit_deadline':
                with patch.object(runner,'datetime',AuditClock):runner.run(end.isoformat())
            else:runner.run(end.isoformat())
        result=read(root/'RUN_RECEIPT.json');allrows=result['rows']
        require(len(allrows)==425 and result['prior_exact_loss_resource_unknown_count']==1,'Complete 425/59/10/9 funnel under interruption')
        require(allrows[9]['status']=='UNKNOWN_EXACT_LOSS_RESOURCE' and sum(r['status']=='UNKNOWN_NO_AUTHORITATIVE_W' for r in allrows)==366,'Preserved prior unknowns')
        if mode=='post_audit_deadline':
            require(not result['global_stop'] and result['BDD_worker_calls']=={'confirmed':0,'uncertain':0},'Deadline after audit prevents every dispatch')
            require(all(r['status']=='UNKNOWN_NOT_ATTEMPTED' for r in allrows[:9]),'No started attempt from reserve failure')
        elif mode=='resource':
            require(not result['global_stop'] and result['BDD_worker_calls']=={'confirmed':9,'uncertain':0},'Resource failures remain per-case unknown')
            require(all(r['status']=='UNKNOWN_RESOURCE' for r in allrows[:9]),'All resource attempts retained')
        else:
            require(result['global_stop'] and result['BDD_worker_calls']==({'confirmed':0,'uncertain':1} if mode=='wrapper_exception' else {'confirmed':1,'uncertain':0}),'Fatal admission global stop and exact start accounting')
            require(allrows[0]['status']!='UNKNOWN_NOT_ATTEMPTED' and all(r['status']=='UNKNOWN_NOT_ATTEMPTED' for r in allrows[1:9]),'Started failure cannot become not attempted; later cases remain unattempted')
        require(result['native_runs']==result['new_fixed_point_runs']==result['full_reset_uses']==0,'No native/fixed point/reset from parent')
        parent_mock_runs+=1


if __name__=='__main__':
    require(not (B/'FROZEN.json').exists() and not (B/'RUN_STARTED.json').exists(),'Qualification before freeze only')
    signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('60 second synthetic qualification cap')));signal.alarm(60)
    for ne,ns in ((2,2),(1,3),(3,1),(1,1)):
        test('all_triples_ENV%d_SYS_AUX%d'%(ne,ns),lambda ne=ne,ns=ns:exhaustive(ne,ns))
    test('invalid_typed_and_next_support_rejected',domain_rejection)
    test('K_loss_reachable_import_identity_and_all_export_roundtrips',importers)
    test('parent_child_claim_admission_and_interrupted_accounting',child_admission)
    for mode in ('nonzero','missing_result','unknown_status','integrity','bad_pass','wrapper_exception','broken_result','decision_changed','resource','post_audit_deadline'):
        test('whole_parent_mock_'+mode,lambda mode=mode:parent_case(mode))
    signal.alarm(0)
    result={'schema':'cooperative-preservation-loss-offline-qualification-v1','created_utc':now(),
        'status':'PASS' if all(t['pass'] for t in tests) else 'FAIL','tests':tests,'passed':sum(t['pass'] for t in tests),'total':len(tests),
        'finite_set_triples_checked':set_triples,'whole_parent_mock_runs':parent_mock_runs,
        'corpus_BDD_computations':0,'new_fixed_point_runs':0,'actual_child_processes':0,'native_runs':0,'full_reset_uses':0,
        'oracle':'Exhaustive independent finite-set triples with typed AUX; import identity mutations, full Boolean export roundtrips, mocked parent failure and reserve admission.',
        'source_pins':[pin(B/n) for n in ('evidence.py','intersection.py','measure.py','run.py','qualify.py','PROTOCOL_JA.txt')]}
    save(B/'OFFLINE_QUALIFICATION.json',result)
    print(json.dumps({k:result[k] for k in ('status','passed','total','finite_set_triples_checked','whole_parent_mock_runs','corpus_BDD_computations')}))
    require(result['status']=='PASS','Synthetic saved-set qualification failed')
