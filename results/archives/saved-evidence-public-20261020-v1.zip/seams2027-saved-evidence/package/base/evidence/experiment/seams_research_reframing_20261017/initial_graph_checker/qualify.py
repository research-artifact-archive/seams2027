"""Offline qualification only; synthetic source binder never enters production CLI."""
from pathlib import Path
from copy import deepcopy
import hashlib,importlib.util,json,shutil,time
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('initial_checker',HERE/'initial_graph_checker.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
OUT=HERE/'qualification'
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def pin(p):return {'file':p.name,'bytes':p.stat().st_size,'sha256':c.sha(p)}

def fixture(directory,mode='standard',pipeline='v_restricted_strict'):
    directory.mkdir(parents=True,exist_ok=True)
    src=directory/'synthetic.spectra';src.write_text('// OFFLINE SYNTHETIC QUALIFICATION; not a native model\n')
    profile={'fixture_id':'synthetic__qualification','case_id':'synthetic','variant':'qualification',
             'source':dict(path=str(src),bytes=src.stat().st_size,sha256=c.sha(src)),
             'bindings':{'synthetic_test_only':True}}
    b=c.BDD(6); e,s,a=b.var(0),b.var(2),b.var(4)
    ep,sp,ap=b.var(1),b.var(3),b.var(5)
    thetae=0 if mode=='empty_env' else 1
    thetas=0 if mode=='empty_joint' else b.neg(a)
    isolated=mode in ('second_root_strict','second_root_coop')
    rhoe=b.iff(e,ep) if isolated else 0 if mode=='empty_v' else 1
    rhos=b.conj(b.iff(s,sp),b.neg(ap)) if isolated else 1
    ej=[b.neg(s)] if mode=='second_root_coop' else [1] if mode=='second_root_strict' else [e]
    sj=[b.neg(s),1] if mode=='rank_memory' else [b.neg(s)]
    counter=[0]
    def save(u,label):
        counter[0]+=1;p=directory/(str(counter[0]).zfill(3)+'_'+label+'.bdd')
        seen=set(); rows=[]
        def walk(x):
            if x<2 or x in seen:return
            seen.add(x);v,lo,hi=b.nodes[x];walk(lo);walk(hi);rows.append(f'{x} {v} {lo} {hi}')
        walk(u)
        raw=f'0 {u}\n' if u<2 else '6\n0 1 2 3 4 5\n'+'\n'.join(rows)+'\n'
        p.write_text(raw)
        return dict(pin(p),support=sorted(b.support(u)),node_count=len(seen),zero=u==0,one=u==1)
    fields=[]
    for name,owner,role,cur,nxt in [('e','ENV','ENV',0,1),('s','SYS','SYS',2,3),('a','SYS','AUX',4,5)]:
        fields.append(dict(name=name,owner=owner,role=role,domain_size=2,values=['false','true'],current_bits=[cur],next_bits=[nxt],
                    encoding={v:{'current':{str(cur):v=='true'},'next':{str(nxt):v=='true'}} for v in ('false','true')}))
    def inventory():
        return {owner:{'variables':[{'name':f['name'],'type':'synthetic boolean','trace_id':i} for i,f in enumerate(fields) if f['role']==owner],
                       'constraints':[],'patterns':[]} for owner in ('ENV','SYS','AUX')}
    model=dict(schema='k7-native-model-export-v1',fixture_id=profile['fixture_id'],case_id=profile['case_id'],variant=profile['variant'],
        input=profile['source'],fields=fields,public_fields={'ENV':['e'],'SYS':['s']},all_current_bits=[0,2,4],all_next_bits=[1,3,5],
        bdd_variable_count=6,bdd_variable_order=list(range(6)),source_inventory={'parsed':inventory(),'translated':inventory(),
        'native_behaviors':{'env_justice_count':len(ej),'sys_justice_count':len(sj)}},
        original_bdds={k:save(u,k) for k,u in {'thetaE':thetae,'thetaS':thetas,'rhoE':rhoe,'rhoS':rhos,'domain':1,'domain_ENV_next':1,'domain_SYS_next':1}.items()},
        original_justices={'ENV':[save(x,'ej') for x in ej],'SYS':[save(x,'sj') for x in sj]})
    write(directory/'model.json',model)
    ctx=c.Context(directory,profile,model);v,alive,_=ctx.viability()
    # Transfer canonical node to producer-side synthetic BDD by verified bytes;
    # no solver is used and supplied W below is deliberate fixture data.
    def transfer(u):
        if u<2:return u
        var,lo,hi=ctx.b.nodes[u];return b.ite(b.var(var),transfer(hi),transfer(lo))
    v=transfer(v);alive=transfer(alive)
    member=not bool(thetae and b.conj(thetae,b.neg(b.exists(b.conj(thetas,v),[2,4]))))
    result=dict(schema='k7-native-admission-production-v1',fixture_id=profile['fixture_id'],case_id=profile['case_id'],variant=profile['variant'],
        pipeline=pipeline,solver='3fp' if pipeline=='v_restricted_strict' else '4fp',teardown='COMPLETED',controller_certified=False,
        input_sha256=profile['source']['sha256'],entry_mode='original_initializer',initialization=c.INIT,
        entry_valuation=None,entry_bits=None,replay_export=None,replay_sha256=None,trace_sha256=None,
        model_export=pin(directory/'model.json'),initial_ENV_empty=thetae==0,initial_joint_empty=b.conj(thetae,thetas)==0,
        native_solver_called=thetae!=0 and v!=0,controller_extraction_called=thetae!=0 and v!=0 and member,controller_export=None,
        initial_in_region=member)
    if thetae==0:
        result['status']='COMPLETE_VACUOUS_INITIALIZER';write(directory/'result.json',result);return profile
    copies=len(ej) if pipeline=='normalized_kind' else 0
    expected={'ENV':ej,'SYS':sj+(ej if copies else [])}
    result.update(V=save(v,'V'),alive=save(alive,'alive'),normalization={'V_restriction':True,'helper_added':False,'ENV_justice_copies':copies,
        'restricted_rhoS':save(b.conj(rhos,v,b.rename(v,{0:1,2:3,4:5})),'restricted_rhoS')},
        residual_thetaE=save(thetae,'residual_thetaE'),residual_thetaS=save(b.conj(thetas,v),'residual_thetaS'),
        preconstructor_justices={o:[save(x,'pre_'+o) for x in js] for o,js in expected.items()},
        solver_input_justices={o:[save(x,'solver_'+o) for x in js or [1]] for o,js in expected.items()},native_W=save(v,'native_W'),final_region=save(v,'final_region'))
    witness=b.conj(thetas,v); missing=b.conj(thetae,b.neg(b.exists(witness,[2,4])))
    result['original_initial_quantification']={'system_witness':save(witness,'witness'),'missing_environment_initials':save(missing,'missing'),
        'env_quantified_bits':[0],'sys_quantified_bits':[2,4],'verdict':missing==0}
    result['native_residual_initial_verdict']=missing==0
    if v==0:result['status']='COMPLETE_EMPTY_V_REJECTION'
    elif not member:result['status']='COMPLETE_REGION_REJECTION'
    else:
        result['status']='COMPLETE_CONTROLLER_EXPORTED'
        vals=[{'e':'false','s':'false','a':'false'},{'e':'true','s':'true' if isolated else 'false','a':'false'}]
        if mode=='rank_memory':vals+=deepcopy(vals)
        nodes=[]
        for i,val in enumerate(vals):
            rank=i//2 if mode=='rank_memory' else 0
            successors=[str(i)] if isolated else ['2','3'] if mode=='rank_memory' and i<2 else ['0','1']
            nodes.append({'id':str(i),'native_id':i,'rank':rank,'rank_class':'tau.smlab.syntech.games.gr1.GR1RankInfo',
                'rank_info':f'System Justice {rank}','initial':i<2,'valuation':val,
                'bits':{str(k):v for k,v in ctx.bits(val).items()},'successors':successors})
        controller=dict(schema='released-concrete-controller-export-v2',fixture_id=profile['fixture_id'],case_id=profile['case_id'],variant=profile['variant'],
             pipeline=pipeline,solver=result['solver'],complete=True,controller_certified=False,entry_mode='original_initializer',
             initialization=c.INIT,entry_valuation=None,entry_bits=None,replay_sha256=None,model_sha256=result['model_export']['sha256'],
             rank_domain_size=len(expected['SYS']) or 1,nodes=nodes)
        recount(controller);write(directory/'controller.json',controller)
        result['controller_export']=controller_pin(directory,controller)
    write(directory/'result.json',result)
    return profile

def recount(g):
    g['api_state_order']=[n['id'] for n in g['nodes']]
    g['edges']=[[n['id'],t] for n in g['nodes'] for t in n['successors']]
    g['api_state_count']=len(g['nodes']);g['api_transition_count']=g['exported_edge_count']=len(g['edges'])
def controller_pin(d,g):return dict(pin(d/'controller.json'),complete=True,**{k:g[k] for k in ('api_state_count','api_transition_count','exported_edge_count')})
def mutate_controller(d,fn):
    g=c.read_json(d/'controller.json');fn(g);recount(g);write(d/'controller.json',g)
    r=c.read_json(d/'result.json');r['controller_export']=controller_pin(d,g);write(d/'result.json',r)
def mutate_result(d,fn):
    r=c.read_json(d/'result.json');fn(r);write(d/'result.json',r)
def mutate_model(d,fn):
    m=c.read_json(d/'model.json');fn(m);write(d/'model.json',m)
    r=c.read_json(d/'result.json');r['model_export']=pin(d/'model.json');write(d/'result.json',r)
    if (d/'controller.json').exists():mutate_controller(d,lambda g:g.update(model_sha256=r['model_export']['sha256']))

def main():
    OUT.mkdir(exist_ok=True)
    rows=[]; original_binder=c.load_profile
    def run(name,mode='standard',pipeline='v_restricted_strict',mutation=None,status='VALID_EXPORT_CERTIFICATE',strict=True,coop=True,error=None,scope=None):
        d=OUT/name
        if d.exists():shutil.rmtree(d)
        profile=fixture(d,mode,pipeline)
        if mutation:mutation(d)
        c.load_profile=lambda fixture:profile
        try:cert=c.check_arm(d,profile['fixture_id'],pipeline)
        finally:c.load_profile=original_binder
        okay=cert['status']==status and (status!='VALID_EXPORT_CERTIFICATE' or (cert['strict_controller_pass']==strict and cert['nonconflicting_pass']==coop))
        if scope:okay &= cert['refusal_scope']==scope
        if error:okay &= error in cert.get('error','') or any(error in x.get('kind','') for x in cert['controller_defects'])
        write(d/'certificate.json',cert)
        rows.append({'name':name,'pass':bool(okay),'actual_status':cert['status'],'strict':cert['strict_controller_pass'],'cooperation':cert['nonconflicting_pass'],'error':cert.get('error'),'expected_error':error,'refusal_scope':cert['refusal_scope'],'expected_refusal_scope':scope})
    run('baseline_two_roots')
    run('normalized_kind_two_roots',pipeline='normalized_kind')
    run('same_values_distinct_private_rank',mode='rank_memory')
    run('second_root_only_strict_failure',mode='second_root_strict',strict=False,coop=True)
    run('second_root_only_cooperation_failure',mode='second_root_coop',strict=True,coop=False)
    run('empty_ENV_distinct_vacuous',mode='empty_env',status='VALID_VACUOUS_INITIALIZER')
    run('empty_joint_not_vacuous',mode='empty_joint',status='VALID_SEMANTIC_REFUSAL')
    run('empty_V_independent_refusal',mode='empty_v',status='VALID_SEMANTIC_REFUSAL')
    run('no_initial_nodes',mutation=lambda d:mutate_controller(d,lambda g:[n.update(initial=False) for n in g['nodes']]),status='INVALID',error='NO_INITIAL_NODE',scope='CANDIDATE_CONTROLLER')
    run('missing_initial_ENV',mutation=lambda d:mutate_controller(d,lambda g:g['nodes'][1].update(initial=False)),status='INVALID',error='MISSING_INITIAL_ENV_RESPONSE',scope='CANDIDATE_CONTROLLER')
    def duplicate(g):
        n=deepcopy(g['nodes'][0]);n.update(id='2',native_id=2);n['valuation']['s']='true';n['bits']['2']=True;g['nodes'].append(n)
    run('duplicate_initial_ENV',mutation=lambda d:mutate_controller(d,duplicate),status='INVALID',error='DUPLICATE_INITIAL_ENV_RESPONSE',scope='CANDIDATE_CONTROLLER')
    run('nonzero_initial_rank',mode='rank_memory',mutation=lambda d:mutate_controller(d,lambda g:(g['nodes'][0].update(initial=False),g['nodes'][2].update(initial=True))),status='INVALID',error='INITIAL_PRIVATE_MEMORY_NOT_RANK0',scope='CANDIDATE_CONTROLLER')
    def bad_aux(g):g['nodes'][0]['valuation']['a']='true';g['nodes'][0]['bits']['4']=True
    run('initial_AUX_violation',mutation=lambda d:mutate_controller(d,bad_aux),status='INVALID',error='ORIGINAL_INITIALIZER_OR_V_VIOLATION',scope='CANDIDATE_CONTROLLER')
    run('missing_legal_input',mutation=lambda d:mutate_controller(d,lambda g:g['nodes'][0].update(successors=['0'])),status='INVALID',error='MISSING_LEGAL_INPUT')
    run('illegal_ENV_edge',mode='second_root_strict',mutation=lambda d:mutate_controller(d,lambda g:g['nodes'][0].update(successors=['0','1'])),status='INVALID',error='ILLEGAL_ENV_EDGE')
    def duplicate_reply(g):
        n=deepcopy(g['nodes'][0]);n.update(id='2',native_id=2,initial=False);n['valuation']['s']='true';n['bits']['2']=True;g['nodes'].append(n);g['nodes'][0]['successors'].append('2')
    run('nondeterministic_response',mutation=lambda d:mutate_controller(d,duplicate_reply),status='INVALID',error='NONDETERMINISTIC_RESPONSE_OR_MEMORY')
    def sys_bad(g):
        g['nodes'][0]['successors']=['1'];g['nodes'][1]['valuation']['e']='false';g['nodes'][1]['bits']['0']=False;g['nodes'][1]['initial']=False
        # Keep second original ENV root separately to preserve initial coverage.
        n=deepcopy(g['nodes'][1]);n.update(id='2',native_id=2,initial=True,successors=['2']);n['valuation']['e']='true';n['bits']['0']=True;g['nodes'].append(n)
    run('original_SYS_safety',mode='second_root_strict',mutation=lambda d:mutate_controller(d,sys_bad),status='INVALID',error='ORIGINAL_SYS_SAFETY')
    run('wrong_quantified_AUX_bits',mutation=lambda d:mutate_result(d,lambda r:r['original_initial_quantification'].update(sys_quantified_bits=[2])),status='INVALID',error='SYS/AUX quantified bits')
    run('false_vacuity_flag',mutation=lambda d:mutate_result(d,lambda r:r.update(initial_ENV_empty=True)),status='INVALID',error='initializer emptiness')
    run('wrong_justice_normalization',pipeline='normalized_kind',mutation=lambda d:mutate_result(d,lambda r:r['normalization'].update(ENV_justice_copies=0)),status='INVALID',error='Normalization declaration')
    run('wrong_residual_initializer',mutation=lambda d:mutate_result(d,lambda r:r.update(residual_thetaS=r['V'])),status='INVALID',error='original SYS initializer')
    run('forged_missing_initial_BDD',mutation=lambda d:mutate_result(d,lambda r:r['original_initial_quantification'].update(missing_environment_initials=r['V'])),status='INVALID',error='Missing original ENV initials')
    run('untyped_duplicate_encoding',mutation=lambda d:mutate_model(d,lambda m:m['fields'][0]['encoding'].update(true=m['fields'][0]['encoding']['false'])),status='INVALID',error='Noninjective')
    run('hidden_unowned_bit',mutation=lambda d:mutate_model(d,lambda m:m.update(bdd_variable_count=7,bdd_variable_order=list(range(7)))),status='INVALID',error='Unaccounted')
    run('AUX_wrong_owner',mutation=lambda d:mutate_model(d,lambda m:m['fields'][2].update(owner='ENV')),status='INVALID',error='Owner/role')
    # Production source binder must refuse synthetic fixtures without monkeypatch.
    denied=c.check_arm(OUT/'baseline_two_roots','synthetic__qualification','v_restricted_strict')
    rows.append({'name':'production_source_binder_rejects_synthetic','pass':denied['status']=='INVALID' and 'outside unique frozen population' in denied.get('error',''),'actual_status':denied['status'],'error':denied.get('error')})
    result={'status':'PASS' if all(r['pass'] for r in rows) else 'FAIL','qualification_only':True,'native_runs':0,'cases':rows,
            'checker_sha256':c.sha(HERE/'initial_graph_checker.py'),'qualification_sha256':c.sha(Path(__file__)),
            'scope':'Full production checker with explicit test-local synthetic source binding; production CLI never accepts this bypass.'}
    write(HERE/'QUALIFICATION.json',result)
    print(json.dumps(result,indent=2))
    return 0 if result['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
