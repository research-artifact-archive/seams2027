"""Offline synthetic adapter qualification. This script never launches Slugs."""
from pathlib import Path
from copy import deepcopy
import importlib.util,json,shutil,time
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('slugs_certify',HERE/'certify.py');cert=importlib.util.module_from_spec(spec);spec.loader.exec_module(cert)
ex=cert.ex
builder_path=HERE.parent.parent/'initial_graph_checker/qualify.py'
spec=importlib.util.spec_from_file_location('frozen_initial_qualification_builder',builder_path);builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
OUT=HERE.parent/'qualification';OUT.mkdir(exist_ok=True)

def json_graph(ctx,mapping,mode):
 if mode=='empty_env':vals=[]
 elif mode in ('second_root_strict','second_root_coop'):
  vals=[{'e':'false','s':'false','a':'false'},{'e':'true','s':'true','a':'false'}]
 else:vals=[{'e':e,'s':s,'a':'false'} for e in ('false','true') for s in ('false','true')]
 nodes={}
 for i,v in enumerate(vals):
  bits=ctx.bits(v)
  nodes[str(i)]={'rank':0,'state':[int(bits[mapping['aliases'][a]]) for a in mapping['variables']],
                 'trans':[i] if mode in ('second_root_strict','second_root_coop') else [0,2]}
 return {'version':0,'slugs':'0.0.1','variables':mapping['variables'],'nodes':nodes}

def prepare(name,mode='standard'):
 d=OUT/name
 if d.exists():shutil.rmtree(d)
 profile=builder.fixture(d/'source','standard' if mode=='empty_justices' else mode)
 if mode=='empty_justices':
  model=ex.READ(d/'source/model.json');model['original_justices']={'ENV':[],'SYS':[]};model['source_inventory']['native_behaviors'].update(env_justice_count=0,sys_justice_count=0);ex.save(d/'source/model.json',model)
 ec=ex.export_model(d/'source',profile['fixture_id'],d/'export',qualification_profile=profile)
 ctx,_,mapping=ex.load_export(d/'export',qualification_profile=profile)
 native=d/'native';native.mkdir()
 graph=json_graph(ctx,mapping,mode);ex.save(native/'controller.json',graph)
 (native/'stdout.txt').write_text('');(native/'stderr.txt').write_text('SLUGS: synthetic offline fixture\nRESULT: Specification is realizable.\n')
 freeze=cert.baseline_freeze()
 r={'schema':'slugs-2015-native-run-v1','fixture_id':profile['fixture_id'],'evidence_class':'SYNTHETIC_OFFLINE_FIXTURE',
    'status':'COMPLETE_REALIZABLE','source_commit':freeze['source_commit'],'binary_sha256':freeze['binary']['sha256'],
    'input_sha256':ec['arena']['sha256'],'export_certificate_sha256':ex.sha(d/'export/EXPORT_CERTIFICATE.json'),
    'argv':[freeze['binary']['path']]+freeze['options']+[str(d/'export/arena.slugsin'),str(native/'controller.json')],
    'exit_code':0,'native_solver_called':True,'stdout':ex.pin(native/'stdout.txt'),'stderr':ex.pin(native/'stderr.txt'),
    'controller_export':ex.pin(native/'controller.json')}
 ex.save(native/'result.json',r)
 return d,profile,ctx,mapping

def graph_mutation(d,fn):
 p=d/'native/controller.json';g=ex.READ(p);fn(g);ex.save(p,g)
 result=ex.READ(d/'native/result.json');result['controller_export']=ex.pin(p);ex.save(d/'native/result.json',result)
def result_mutation(d,fn):
 p=d/'native/result.json';r=ex.READ(p);fn(r);ex.save(p,r)
def stderr_mutation(d,text):
 p=d/'native/stderr.txt';p.write_text(text)
 result_mutation(d,lambda r:r.update(stderr=ex.pin(p)))
def negative(d):
 (d/'native/controller.json').unlink()
 stderr_mutation(d,'RESULT: Specification is unrealizable.\n')
 result_mutation(d,lambda r:r.update(status='COMPLETE_UNREALIZABLE',controller_export=None))

def main():
 rows=[]
 def run(name,mode='standard',mutation=None,status='VALID_EXPORT_CERTIFICATE',strict=True,coop=True,scope=None,error=None):
  d,profile,ctx,mapping=prepare(name,mode)
  if mutation:mutation(d)
  result=cert.check(d/'export',d/'native',qualification_profile=profile)
  good=result['status']==status
  if status=='VALID_EXPORT_CERTIFICATE':good &= result['strict_controller_pass']==strict and result['nonconflicting_pass']==coop
  if scope:good &= result['refusal_scope']==scope
  if error:good &= error in result.get('error','') or any(error in x['kind'] for x in result.get('controller_defects',[]))
  ex.save(d/'certificate.json',result)
  rows.append({'name':name,'pass':bool(good),'status':result['status'],'strict':result['strict_controller_pass'],'cooperation':result['nonconflicting_pass'],
               'refusal_scope':result['refusal_scope'],'error':result.get('error'),'expected_error':error,
               'initial_states':result.get('controller_audit',{}).get('initial_state_count'),'initial_ENV_choices':result.get('controller_audit',{}).get('initial_ENV_count')})
 run('all_joint_roots_two_SYS_responses_per_ENV')
 run('second_root_only_strict_failure',mode='second_root_strict',strict=False,coop=True)
 run('second_root_only_cooperation_failure',mode='second_root_coop',strict=True,coop=False)
 run('empty_original_justice_rosters',mode='empty_justices')
 run('empty_ENV_vacuous',mode='empty_env',status='VALID_VACUOUS_INITIALIZER')
 def memory(g):
  old=deepcopy(g['nodes']);g['nodes']={}
  # Same typed valuation at different goal ranks is retained separately.
  for i,source in enumerate([old['0'],old['2'],old['0'],old['2']]):
   node=deepcopy(source);node['rank']=i//2;node['trans']=[2,3] if i<2 else [0,1];g['nodes'][str(i)]=node
 run('distinct_private_rank_same_valuation',mutation=lambda d:graph_mutation(d,memory))
 def missing_init(g):
  # ENV=true only appears at rank1: it remains reachable, but is not an initial root.
  for sid in ('2','3'):g['nodes'][sid]['rank']=1
  g['nodes']['0']['trans']=[1,3] # Make every node reachable, preserving a clean initial failure.
 run('missing_initial_ENV_despite_reachability',mutation=lambda d:graph_mutation(d,missing_init),status='INVALID',scope='CANDIDATE_CONTROLLER',error='MISSING_INITIAL_ENV_RESPONSE')
 run('no_rank0_roots',mutation=lambda d:graph_mutation(d,lambda g:[n.update(rank=1) for n in g['nodes'].values()]),status='INVALID',scope='CANDIDATE_CONTROLLER',error='NO_VALID_RANK0_INITIAL_ROOT')
 run('missing_legal_input',mutation=lambda d:graph_mutation(d,lambda g:g['nodes']['0'].update(trans=[0])),status='INVALID',scope='CANDIDATE_CONTROLLER',error='MISSING_LEGAL_INPUT')
 run('nondeterministic_response',mutation=lambda d:graph_mutation(d,lambda g:g['nodes']['0'].update(trans=[0,1,2])),status='INVALID',scope='CANDIDATE_CONTROLLER',error='NONDETERMINISTIC_RESPONSE_OR_MEMORY')
 run('illegal_ENV_edge',mode='second_root_strict',mutation=lambda d:graph_mutation(d,lambda g:g['nodes']['0'].update(trans=[0,1])),status='INVALID',scope='CANDIDATE_CONTROLLER',error='ILLEGAL_ENV_EDGE')
 run('unsafe_SYS_edge',mode='second_root_strict',mutation=lambda d:graph_mutation(d,lambda g:g['nodes']['0'].update(trans=[1])),status='INVALID',scope='CANDIDATE_CONTROLLER',error='ORIGINAL_SYS_SAFETY')
 run('duplicate_identity',mutation=lambda d:graph_mutation(d,lambda g:g['nodes'].update({'4':deepcopy(g['nodes']['0'])})),status='INVALID',error='Duplicate valuation/private-goal identity')
 run('out_of_range_rank',mutation=lambda d:graph_mutation(d,lambda g:g['nodes']['0'].update(rank=2)),status='INVALID',error='rank range')
 run('missing_AUX_variable',mutation=lambda d:graph_mutation(d,lambda g:g['variables'].pop()),status='INVALID',error='variable order')
 run('partial_state_bits',mutation=lambda d:graph_mutation(d,lambda g:g['nodes']['0']['state'].pop()),status='INVALID',error='Full Boolean output state')
 run('dangling_edge',mutation=lambda d:graph_mutation(d,lambda g:g['nodes']['0'].update(trans=[99])),status='INVALID',error='successor IDs')
 run('negative_receipt_no_unrealizability_claim',mutation=negative,status='VALID_NATIVE_NEGATIVE')
 run('negative_on_empty_ENV_rejected',mode='empty_env',mutation=negative,status='INVALID',error='Empty ENV')
 run('native_unknown_separate',mutation=lambda d:result_mutation(d,lambda r:r.update(status='UNKNOWN_TIMEOUT',exit_code=-9)),status='UNKNOWN_NATIVE_RUN',scope='CANDIDATE_TECHNICAL')
 run('nonzero_exit_not_complete',mutation=lambda d:result_mutation(d,lambda r:r.update(exit_code=1)),status='INVALID',error='execution receipt')
 run('wrong_binary_pin',mutation=lambda d:result_mutation(d,lambda r:r.update(binary_sha256='0'*64)),status='INVALID',error='source/binary binding')
 run('wrong_input_pin',mutation=lambda d:result_mutation(d,lambda r:r.update(input_sha256='0'*64)),status='INVALID',error='input binding')
 run('robotics_flag_forbidden',mutation=lambda d:result_mutation(d,lambda r:r['argv'].insert(1,'--sysInitRoboticsSemantics')),status='INVALID',error='Exact native argv')
 run('contradictory_verdict',mutation=lambda d:stderr_mutation(d,'RESULT: Specification is unrealizable.\n'),status='INVALID',error='positive verdict mismatch')
 run('duplicate_verdict_line',mutation=lambda d:stderr_mutation(d,'RESULT: Specification is realizable.\nRESULT: Specification is realizable.\n'),status='INVALID',error='Unique native verdict')
 # Direct language roundtrip negative controls defeat recomputed byte hashes.
 d,profile,ctx,mapping=prepare('language_roundtrip_controls')
 arena=d/'export/arena.slugsin';original=arena.read_text()
 language=[('changed_transition',lambda s:s.replace('[ENV_TRANS]\n1','[ENV_TRANS]\n0'),'roundtrip failed'),
           ('missing_AUX_output',lambda s:s.replace('[OUTPUT]\nb2\nb4','[OUTPUT]\nb2'),'ownership/order'),
           ('forward_memory_reference',lambda s:s.replace('[ENV_INIT]\n1','[ENV_INIT]\n$ 1 ? 0'),'Forward/unbound'),
           ('next_output_in_ENV_init',lambda s:s.replace('[ENV_INIT]\n1',"[ENV_INIT]\nb2'"),'forbidden bit alias'),
           ('missing_original_justice',lambda s:s.replace('[ENV_LIVENESS]\n$ 3 0 1 | & b0 ? 1 & ! b0 ? 0','[ENV_LIVENESS]'),'Formula/justice roster')]
 for name,fn,error in language:
  changed=fn(original);good=False;message=None
  try:
   ex.require(changed!=original,'Mutation did not apply');arena.write_text(changed);ex.audit_input(arena,ctx,mapping)
  except Exception as e:message=str(e);good=error in message
  rows.append({'name':name,'pass':good,'error':message,'expected_error':error})
 arena.write_text(original)
 # Non-power-of-two typed decoding: use a real saved model, with a synthetic node.
 actual=HERE.parent/'exports/corpus032__original';realctx,_,realmap=ex.load_export(actual)
 invfield=None;badcode=None
 for f in realctx.fields:
  legal={tuple(realctx.enc[f['name']][v][0][k] for k in f['current_bits']) for v in f['values']}
  from itertools import product
  missing=[x for x in product((False,True),repeat=len(f['current_bits'])) if x not in legal]
  if missing:invfield=f;badcode=missing[0];break
 bits=realctx.bits({f['name']:f['values'][0] for f in realctx.fields});bits.update(zip(invfield['current_bits'],badcode))
 invalid={'version':0,'slugs':'0.0.1','variables':realmap['variables'],'nodes':{'0':{'rank':0,'state':[int(bits[realmap['aliases'][a]]) for a in realmap['variables']],'trans':[]}}}
 try:cert.analyze_controller(realctx,realmap,invalid);good=False;msg=None
 except Exception as e:msg=str(e);good='invalid typed encoding' in msg
 rows.append({'name':'invalid_non_power_of_two_encoding','pass':good,'error':msg})
 # Production binding does not expose qualification override.
 refused=cert.check(d/'export',d/'native')
 rows.append({'name':'production_rejects_synthetic_export','pass':refused['status']=='INVALID' and 'Synthetic/production' in refused.get('error',''),'error':refused.get('error')})
 result={'status':'PASS' if all(x['pass'] for x in rows) else 'FAIL','qualification_only':True,'native_scientific_synthesis_calls':0,
         'upstream_binary_launches':0,'cases':rows,'checker_sha256':ex.sha(HERE/'certify.py'),'exporter_sha256':ex.sha(HERE/'exporter.py'),
         'script_sha256':ex.sha(Path(__file__)),'synthetic_fixture_builder':{'path':str(builder_path),'sha256':ex.sha(builder_path)},
         'scope':'Synthetic JSON/native receipts only, plus exact saved-model DAG roundtrip. No native Slugs synthesis result is fabricated or claimed.'}
 ex.save(HERE.parent/'QUALIFICATION.json',result);print(json.dumps(result,indent=2))
 return 0 if result['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
