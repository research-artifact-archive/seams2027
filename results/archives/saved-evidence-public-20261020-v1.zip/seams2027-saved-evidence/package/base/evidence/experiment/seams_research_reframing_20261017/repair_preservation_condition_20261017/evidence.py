"""Fixed eleven-repair evidence admission; metadata and byte pins only."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;E=B.parent;ROOT=E.parent.parent
M=E/'repair_preservation_feasibility_20261017'
R=ROOT/'experiment/seams_submission_push_20261016/v_restricted_strict'
CHECKER=R/'checker';STAGE=E/'contained_stage_process'
def require(x,message):
    if not x:raise ValueError(message)
def now():return datetime.now(timezone.utc).isoformat()
def unique_json(pairs):
    out={}
    for k,v in pairs:require(k not in out,'Duplicate JSON key');out[k]=v
    return out
def read(p):return json.loads(Path(p).read_text(),object_pairs_hook=unique_json)
def save(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def pin(p):
    p=Path(p).resolve();raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def verify(refs):
    for r in refs:require(pin(r['path'])==r,'File pin mismatch: '+r['path'])
def unique(refs):
    out={}
    for r in refs:
        require(r['path'] not in out or out[r['path']]==r,'Conflicting file pin');out[r['path']]=r
    return list(out.values())
def pins_in(d):
    if isinstance(d,dict):
        if set(d)=={'path','bytes','sha256'}:return [d]
        return sum((pins_in(v) for v in d.values()),[])
    if isinstance(d,list):return sum((pins_in(v) for v in d),[])
    return []
def select():
    manifest=read(M/'OUTPUT_MANIFEST.json');verify(manifest['files'])
    audit=read(M/'AUDIT_RECEIPT.json');meta=read(M/'SELECTION_METADATA.json');inputs=read(M/'INPUT_MANIFEST.json')['files']
    require(audit['status']=='PASS' and audit['candidates']==11,'Complete metadata audit')
    require(all(audit[k]==0 for k in ('native_runs','BDD_imports','C_computations','new_fixed_point_runs','full_reset_uses')),'Metadata-only preparation')
    verify(inputs)
    roster=read(R/'ROSTER.json');report=read(R/'REPORT.json');receipt=read(R/'RUN_RECEIPT_V3.json')
    ids=[r['fixture'] for r in roster['rows']]
    require(len(ids)==len(set(ids))==11 and ids==meta['eligible_ids']==[r['id'] for r in meta['rows']],'Exact original eleven roster/order')
    require(ids==[r['fixture'] for r in report['rows']]==[r['fixture'] for r in receipt['rows']],'Prior completion roster')
    require(report['status']=='COMPLETE_ALL_11_ZERO_SCIENTIFIC_UNKNOWNS' and receipt['status']=='COMPLETE_ALL_11' and receipt['final_input_pin_errors']==[],'Prior completed authority')
    refs=unique(inputs+manifest['files']+[pin(M/'OUTPUT_MANIFEST.json')]);rows=[]
    for row,old in zip(meta['rows'],report['rows']):
        match=read(row['existing_full_region_equality']['path']);native=read(row['native_result']['path'])
        require(match['status']=='PASS' and match['full_region_comparison'] is True and match['V_restricted_strict_equals_K'] is True,'Existing complete W_V=K authority')
        require(match['counts']==row['existing_counts']==old['full_regions'],'Prior full region counts')
        require(row['existing_full_W_V_equals_K'] is True and row['complete_typed_K_value_roster_metadata_valid'] is True,'All typed fields/AUX and complete K enumeration')
        require(row['source_profile']['profile_key']==row['id'],'Profile exact identity')
        row=dict(row);row.update(eligible=True,input_pins=refs,
            original_initial_formulas={k:row['original_formulas'][k] for k in ('thetaE','thetaS')},
            prior_native_initial_result={'status':native['status'],'native_residual_initial_verdict':native.get('native_residual_initial_verdict')})
        rows.append(row)
    verify(refs)
    return {'schema':'repair-preservation-condition-selection-v1','created_utc':now(),'denominator':11,'eligible_count':11,
        'eligible_ids':ids,'rows':rows,'input_pins':refs,'selection_rule':'All eleven fixed reconstructed repair candidates, including three empty K regions; no condition, K-size or initializer filtering.',
        'optional_original_W_secondary':'OMITTED: ordinary-strict negative region authority is source-qualified, not independently proved unrealizable.',
        'new_repaired_or_deployed_episode':False,'reconstructed_BDD_computations':0,'native_runs':0,'new_fixed_point_runs':0}
