"""Fixed044 model correspondence and all-quadrant audit, with no fixed-point solver."""
from pathlib import Path
import json,signal,sys,time,traceback
sys.dont_write_bytecode=True
from evidence import B,ID,MODES,read,save,pin,verify,require,now,authorization,native_refs,old_checker
from scope import actual_inventory
from map_pair import build,ResourceRefusal
from relations import compare
from pair_support import supplemental,export

def main():
    decision=authorization();freeze=read(B/'FROZEN.json');selected=read(B/'SELECTION.json');case=selected['case'];folder=B/'runs'/ID
    require(not (folder/'CHECK.json').exists() and not (folder/'FUNCTIONS.json.gz').exists(),'No duplicate044 checker');scope=read(B/'SOURCE_SCOPE.json')
    refs=freeze['code_files']+selected['input_pins']+[pin(B/'FROZEN.json'),pin(B/'SELECTION.json'),decision]
    result={'schema':'fixed044-model-main-check-v1','id':ID,'status':'UNKNOWN_INCOMPLETE','created_utc':now(),'root_authorization':decision,
        'joined_qualification':selected['joined_qualification'],'old_global_stop_preserved':True,'v1_resumed':False,
        'checker_native_JVM_calls':0,'solver_calls':0,'controller_calls':0,'full_reset_uses':0,'U_F_direct_analysis_authorized':False,
        'winning_or_K_preservation_conclusion':None,'scientific_scope':'Fixed044 model export, original-reference correspondence, full typed relation audit only'}
    started=time.monotonic();ce=old_checker();pair=None
    def timeout(*_):raise TimeoutError('044 model correspondence and quadrant cap60s')
    try:
        signal.signal(signal.SIGALRM,timeout);signal.alarm(60);verify(refs)
        contexts={};audits={}
        for mode in MODES:
            arm=folder/mode;producer_refs=native_refs(arm,case,mode,decision,freeze)
            ctx,audit=ce.admit_native_result(arm,case,mode,decision,freeze)
            contexts[mode]=ctx;audits[mode]={**audit,'producer_output_pins':producer_refs}
        baseline,_=ce.load_model(case['original_directory'],case,'original')
        metadata=actual_inventory(baseline.model,contexts['original'].model,read(folder/'original/result.json'),scope)
        original_comparison=ce.contexts_equal(baseline,contexts['original'],compare_inventory=False)
        original_comparison.update(source_inventory_bridge=metadata,source_inventory_fully_accounted_for=True,same_generator_configuration_claim=False)
        structure=ce.structural_pair(contexts['original'],contexts['released'],audits['released']['helper_added'])
        require(structure['original_AUX_fields']==['PREV_aux_0','PREV_aux_1'] and structure['original_carrier']==18816 and structure['released_carrier']==37632 and structure['helper_added'] is True,'Fixed044 complete past-time AUX and carrier')
        proof=read(case['original_independent_proof']['path']);original=case['authoritative_original_model']
        require(pin(Path(case['original_directory'])/'model.json')==original and original in proof['input_pins'] and proof['id']==ID and proof['status']=='PASS','Exact044 original independent proof/model binding')
        require(proof['carrier']==contexts['original'].carrier and proof['variable_count']==contexts['original'].b.n,'Independent proof complete typed carrier/variables')
        profile={'fixture_id':ID,'case_id':'corpus044','variant':'original','source':case['source'],'bindings':{'original_native_model':pin(folder/'original/model.json'),'released_native_model':pin(folder/'released/model.json')}}
        pair=build(folder/'original',folder/'released',ID,profile)
        summary,roots=compare(pair['common'],pair['typed_edge_mask'],pair['original_roots']['rhoE'],pair['original_roots']['rhoS'],pair['job_roots']['rhoE'],pair['job_roots']['rhoS'],pair['helper_current_bit'],pair['helper_next_bit'],pair['original_current_bits'],pair['original_next_bits'],pair['original_fields'])
        require(summary['typed_original_edge_domain_count']==18816**2 and [q['quadrant'] for q in summary['quadrants']]==['00','01','10','11'],'All four full typed edge quadrants')
        roots.update(typed_original_edge_mask=pair['typed_edge_mask'],**{'original_'+k:v for k,v in pair['original_roots'].items()},**{'released_'+k:v for k,v in pair['job_roots'].items()})
        extra=supplemental(pair,roots)
        zero=summary['quadrants'][0]['checks'];require(zero['ENV_literal_and_corrected']['equal'] and zero['SYS_literal']['equal'] and zero['SYS_corrected']['equal'],'Actual044 00 retains each original relation separately')
        require(extra['all_equal'] is True,'Actual044 full initial relation and ordered justice correspondence')
        export(folder/'FUNCTIONS.json.gz',pair,roots);verify(refs)
        result.update(status='PASS',native_exports=audits,comparisons={'original':original_comparison},released_old_reference_available=False,
            pair_structure=structure,all_quadrant_relations=summary,supplemental_full_current_checks=extra,canonical_functions=pin(folder/'FUNCTIONS.json.gz'),
            original_independent_proof=case['original_independent_proof'],authoritative_original_model=original,original_model_canonical_bound_to_independent_proof=True,
            original_K_count=0,original_K_initial_verdict=False,input_pins=refs,
            relation_classification_is_observation_not_theorem_assumption=True,ready_for_separately_reviewed_U_F_and_direct_analysis=True)
    except (TimeoutError,ResourceRefusal,ce.ResourceRefusal,MemoryError) as ex:result.update(status='UNKNOWN_RESOURCE',reason=repr(ex))
    except BaseException as ex:result.update(status='UNKNOWN_INTEGRITY',reason=repr(ex),traceback=traceback.format_exc())
    finally:
        signal.alarm(0);result.update(finished_utc=now(),elapsed_seconds=time.monotonic()-started,allocated_common_BDD_nodes=len(pair['common'].nodes) if pair else None);save(folder/'CHECK.json',result)
    print(json.dumps({k:result.get(k) for k in ('id','status','reason')}),flush=True)

if __name__=='__main__':main()
