"""Exhaustive small truth arenas, typed masks, and adversarial admission tests."""
import copy,importlib.util,itertools,json,sys
from types import SimpleNamespace
sys.dont_write_bytecode=True
from evidence import B,read,save,pin,require,now
from condition import BDD,compute,count,root_digest,import_w,summarize

tests=[];truth_arenas=0
def test(name,fn):
    try:fn();tests.append({'name':name,'pass':True})
    except Exception as ex:tests.append({'name':name,'pass':False,'error':repr(ex)})
def rejects(fn):
    try:fn()
    except (ValueError,KeyError,TypeError):return
    raise AssertionError('Expected invalid input rejection')
def bits(variables,value):return {v:bool(value>>i&1) for i,v in enumerate(variables)}

def exhaustive_binary():
    global truth_arenas
    triples=list(itertools.product(range(2),repeat=3))
    for mask in range(1<<len(triples)):
        b=BDD(3);relation={t for i,t in enumerate(triples) if mask>>i&1}
        rho=b.disj(*(b.cube({0:bool(s),1:bool(e),2:bool(y)}) for s,e,y in relation))
        expected={s for s in range(2) if all(any((s,e,y) in relation for y in range(2)) for e in range(2))}
        for wm in range(4):
            selected={s for s in range(2) if wm>>s&1};w=b.disj(*(b.cube({0:bool(s)}) for s in selected))
            result=compute(b,1,rho,1,1,(0,),(1,),(2,),w)
            require({s for s in range(2) if b.evaluate(result['C'],{0:bool(s)})}==expected,'Exhaustive quantifier mismatch')
            require(count(b,result['W_minus_C'],(0,))==len(selected-expected),'Exhaustive W difference mismatch')
        truth_arenas+=1
test('all_256_binary_safety_relations_and_all_4_W_sets',exhaustive_binary)

def exhaustive_typed_masks():
    global truth_arenas
    pairs=list(itertools.product(range(3),repeat=2))
    for mask in range(1<<len(pairs)):
        b=BDD(4);den=b.disj(*(b.cube(bits((0,1),e)) for e in range(3)));dsn=b.disj(*(b.cube(bits((2,3),y)) for y in range(3)))
        relation={t for i,t in enumerate(pairs) if mask>>i&1}
        legal=b.disj(*(b.cube({**bits((0,1),e),**bits((2,3),y)}) for e,y in relation))
        expected=all(any((e,y) in relation for y in range(3)) for e in range(3))
        for garbage in (0,b.cube(bits((2,3),3))):
            result=compute(b,1,b.disj(legal,garbage),den,dsn,(),(0,1),(2,3),1)
            require(bool(result['C'])==expected,'Typed domain quantifier mismatch')
            require(result['W_minus_C']==int(not expected),'Typed domain W difference mismatch')
        truth_arenas+=1
test('all_512_ternary_typed_relations_with_invalid_SYS_encodings',exhaustive_typed_masks)

def quantifier_order():
    b=BDD(2);rho=b.iff(b.var(0),b.var(1))
    c=compute(b,1,rho,1,1,(),(0,),(1,),1)['C']
    require(c==1 and b.exists(b.forall(rho,(0,)),(1,))==0,'forall ENV exists SYS order')
test('ENV_before_SYS_quantifier_order',quantifier_order)
def invalid_env():
    b=BDD(3);den=b.neg(b.conj(b.var(0),b.var(1)));rho=den
    result=compute(b,1,rho,den,1,(),(0,1),(2,),1)
    require(result['C']==1 and b.forall(b.exists(rho,(2,)),(0,1))==0,'Invalid ENV encodings must be masked')
test('invalid_ENV_encoding_is_not_a_missing_response',invalid_env)
def typed_current():
    b=BDD(4);q=b.neg(b.conj(b.var(0),b.var(1)))
    r=compute(b,q,1,1,1,(0,1),(2,),(3,),q)
    require(r['C']==q and count(b,r['C'],(0,1))==3,'C remains inside typed current domain')
test('C_is_masked_to_typed_current_states',typed_current)
def total_not_rhoe_relative():
    b=BDD(2);rho=b.neg(b.var(0));r=compute(b,1,rho,1,1,(),(0,),(1,),1)
    require(r['C']==0,'Complete semantic guard must include an ENV move forbidden by rhoE')
test('complete_ENV_semantics_does_not_filter_by_rhoE',total_not_rhoe_relative)
def empty_owners():
    for en,sn in (((),()),((0,),()),((),(0,))):
        b=BDD(len(en+sn));r=compute(b,1,1,1,1,(),en,sn,0)
        require(r['C']==1 and r['W_minus_C']==0,'Empty owner variables or empty W')
test('empty_owner_bit_rosters_and_empty_W',empty_owners)

def field(name,owner,role,current,nxt):
    return {'name':name,'owner':owner,'role':role,'domain_size':2,'values':['false','true'],
        'current_bits':[current],'next_bits':[nxt],
        'encoding':{v:{'current':{str(current):bool(i)},'next':{str(nxt):bool(i)}} for i,v in enumerate(('false','true'))}}
def witnesses():
    fields=[field('e','ENV','ENV',0,2),field('y','SYS','SYS',1,3),field('memory','SYS','AUX',4,5)]
    for rho_good in (False,True):
        b=BDD(6);rho=b.iff(b.var(3),b.var(2)) if rho_good else b.neg(b.var(2))
        m=SimpleNamespace(b=b,fields=fields,current=(0,1,4),en=(2,),sn=(3,5),dsn=1,forms={'rhoS':rho})
        r=compute(b,1,rho,1,1,m.current,m.en,m.sn,1);out=summarize(m,r)
        require(out['W_subset_C']==rho_good,'Witness criterion')
        witness=out['C_member_witness'] if rho_good else out['W_minus_C_witness']
        require(set(witness['state'])=={'e','y','memory'},'All typed state and AUX values retained')
        if not rho_good:require(witness['ENV_next']=={'e':'true'} and witness['no_typed_SYS_and_all_AUX_response'],'Bad ENV witness')
    b=BDD(6);rho=b.var(5)
    require(compute(b,1,rho,1,1,(0,1,4),(2,),(3,5),1)['C']==1,'AUX next must be existentially quantified')
test('typed_state_ENV_counterexample_and_existential_all_AUX',witnesses)

def imports():
    b=BDD(2);payload={'schema':'independent-canonical-robdd-region-set-v1','variable_count':2,
        'canonical_variable_order':[0,1],'fields':[],'roots':{'W':3},'nodes':[[2,1,0,1],[3,0,2,1]]}
    u=import_w(b,payload,[]);require(u==b.disj(b.var(0),b.var(1)),'Independent W import')
    for mutation in ('missing_child','bad_order','duplicate','fields','variable_count'):
        p=copy.deepcopy(payload)
        if mutation=='missing_child':p['nodes'][1][2]=999
        elif mutation=='bad_order':p['nodes'][1][1]=1
        elif mutation=='duplicate':p['nodes'].append(p['nodes'][0])
        elif mutation=='fields':p['fields']=[{}]
        else:p['variable_count']=3
        rejects(lambda:import_w(BDD(2),p,[]))
test('independent_W_import_and_structural_tamper_rejection',imports)

def interrupted_accounting():
    spec=importlib.util.spec_from_file_location('preservation_local_run_qualification',B/'run.py')
    local=importlib.util.module_from_spec(spec);spec.loader.exec_module(local)
    preserve_interrupted_attempt=local.preserve_interrupted_attempt
    for started in (False,True,None):
        value={'status':'UNKNOWN_NOT_ATTEMPTED','BDD_worker_started':started}
        result=preserve_interrupted_attempt(value)
        require(result['status']==('UNKNOWN_NOT_ATTEMPTED' if started is False else 'UNKNOWN_RUNNER_FAILURE'),'Interrupted call status')
        require(result['BDD_worker_started'] is started,'Confirmed/uncertain start evidence retained')
    value={'status':'UNKNOWN_RESOURCE','BDD_worker_started':True}
    require(preserve_interrupted_attempt(value)['status']=='UNKNOWN_RESOURCE','Completed technical result preserved')
test('interrupted_attempt_keeps_confirmed_uncertain_and_unstarted_distinct',interrupted_accounting)

require(not (B/'FROZEN.json').exists() and not (B/'RUN_STARTED.json').exists(),'Offline qualification before freeze only')
result={'schema':'preservation-condition-offline-qualification-v1','created_utc':now(),
    'status':'PASS' if all(x['pass'] for x in tests) else 'FAIL','tests':tests,'passed':sum(x['pass'] for x in tests),'total':len(tests),
    'exhaustive_truth_arenas':truth_arenas,'corpus_BDD_computations':0,'native_runs':0,'full_reset_uses':0,
    'source_pins':[pin(B/n) for n in ('evidence.py','condition.py','measure.py','run.py','qualify.py','PROTOCOL_JA.txt')]}
save(B/'OFFLINE_QUALIFICATION.json',result);print(json.dumps({k:result[k] for k in ('status','passed','total','exhaustive_truth_arenas','corpus_BDD_computations')}))
require(result['status']=='PASS','Offline mathematical qualification failed')
