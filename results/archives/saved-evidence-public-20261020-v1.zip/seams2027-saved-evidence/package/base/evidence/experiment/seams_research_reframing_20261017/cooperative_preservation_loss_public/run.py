"""Prepare and freeze before an explicitly authorized contained intersection run."""
import argparse,importlib.util,json,os,sys,time
from pathlib import Path
from datetime import datetime,timezone
sys.dont_write_bytecode=True
from evidence import B,C,E,L,S,select,read,save,pin,pins_in,unique,verify,require,now
STAGE=E/'contained_stage_process';MIN_START_SECONDS=75


def preserve_interrupted_attempt(value):
    if value.get('status')=='UNKNOWN_NOT_ATTEMPTED' and value.get('BDD_worker_started') is not False:
        value.update(status='UNKNOWN_RUNNER_FAILURE',reason='Worker start confirmed or uncertain before runner interruption')
    return value


def authorization():
    p=pin(B/'ROOT_START_DECISION.json');d=read(p['path'])
    require(d.get('start_authorized') is True and d.get('freeze')==pin(B/'FROZEN.json'),'Exact root review authorization required')
    verify([p]);return p


def prepare():
    require(not (B/'FROZEN.json').exists() and not (B/'RUN_STARTED.json').exists(),'No frozen overwrite')
    if not (B/'SELECTION.json').exists():save(B/'SELECTION.json',select())
    selection=read(B/'SELECTION.json');verify(selection['input_pins'])
    qualification=read(B/'OFFLINE_QUALIFICATION.json')
    require(qualification['status']=='PASS' and qualification['corpus_BDD_computations']==0 and qualification['new_fixed_point_runs']==0,'Synthetic-only set-operation qualification')
    verify(qualification['source_pins'])
    code=[pin(B/n) for n in ('evidence.py','intersection.py','measure.py','run.py','qualify.py','PROTOCOL_JA.txt','OFFLINE_QUALIFICATION.json')]
    code += [pin(L/n) for n in ('loss.py','evidence.py')]+[pin(C/n) for n in ('condition.py','evidence.py')]
    code += [pin(S/n) for n in ('check_case.py','symbolic.py','vendor/bdd_core.py','vendor/finite_sets_v1.py')]
    code += [pin(STAGE/'FROZEN.json')]+pins_in(read(STAGE/'FROZEN.json'))+[pin(Path(sys.executable).resolve())]
    files=unique(code+selection['input_pins']+[pin(B/'SELECTION.json')]);verify(files)
    save(B/'FROZEN.json',{'schema':'cooperative-preservation-loss-freeze-v1','created_utc':now(),
        'files':files,'code_files':unique(code),'python':pin(Path(sys.executable).resolve()),
        'limits':{'variables':64,'BDD_nodes_including_terminals':500000,'wall_seconds_per_case':60,'workers':1,
                  'native_BDD_bytes':8*1024*1024,'independent_export_expanded_bytes':64*1024*1024,'loss_export_expanded_bytes':64*1024*1024},
        'selection':pin(B/'SELECTION.json'),'source_denominator':425,'authoritative_regions':59,'condition_targeted_cases':10,
        'completed_exact_loss_cases':9,'prior_exact_loss_resource_unknown':1,'parent_aborted':True,
        'native_runs':0,'new_fixed_point_runs':0,'corpus_BDD_computations':0,
        'root_review_status':'AWAITING_ROOT_REVIEW_NO_CORPUS_DISPATCH'})
    print(json.dumps({'status':'PREPARED_CORPUS_NOT_STARTED','eligible':9,'files':len(files),'native_runs':0,'new_fixed_point_runs':0}))


def admit_pass(result,ident,row,freeze,decision_pin):
    require(result['id']==ident and result.get('schema')=='cooperative-preservation-loss-case-v1','Case result identity')
    require(result.get('status') in ('PASS','UNKNOWN_RESOURCE','UNKNOWN_INTEGRITY'),'Known child status')
    require(result.get('root_authorization')==decision_pin and result.get('parent_aborted') is True,'Child authorization provenance')
    require(result.get('native_runs')==0 and result.get('new_fixed_point_runs')==0 and result.get('full_reset_uses')==0,'No new synthesis or fixed points')
    require(result.get('complete_semantic_literal_only') is True,'Complete semantic literal scope')
    for key in ('released_syntactic_loss_conclusion','runtime_or_controller_reachability_conclusion','cooperative_initializer_false_rejection_conclusion'):
        require(result.get(key) is None,'No unsupported transferred conclusion '+key)
    if result['status']!='PASS':return
    names={'K','exact_loss','original_reachable','cooperative_loss','original_reachable_cooperative_loss'}
    counts=result['counts'];require(set(counts)==names and all(type(x) is int and x>=0 for x in counts.values()),'Exact state counts')
    require(counts['K']==row['original_K_count'],'Saved authoritative K count')
    loss=read(row['loss_proof']['path'])
    require(counts['exact_loss']==loss['counts']['W_minus_W_C'] and counts['original_reachable']==loss['counts']['original_reachable'],'Prior loss/reach counts')
    require(counts['cooperative_loss']<=min(counts['K'],counts['exact_loss']),'K/loss intersection count bounds')
    require(counts['original_reachable_cooperative_loss']<=min(counts['original_reachable'],counts['cooperative_loss']),'Reachable intersection count bounds')
    for name in ('cooperative_loss','original_reachable_cooperative_loss'):
        require(type(result.get(name+'_nonempty')) is bool and result[name+'_nonempty']==(counts[name]>0),'Intersection Boolean/count '+name)
        require((result['state_witnesses'][name] is None)==(counts[name]==0),'Typed witness existence '+name)
        if counts[name]:
            require(result['state_witnesses'][name].get('all_logical_AUX_retained') is True,'All logical AUX in witness')
            require(result['state_witnesses'][name].get('not_a_strategy_or_runtime_trace') is True,'State witness scope')
    require(set(result['canonical_sha256'])==names and all(isinstance(v,str) and len(v)==64 for v in result['canonical_sha256'].values()),'Canonical root digests')
    proof=read(row['proof']['path'])
    require(result['canonical_sha256']['K']==proof['comparisons']['K']['canonical_sha256'],'Saved K function identity')
    require(result['canonical_sha256']['exact_loss']==loss['canonical_sha256']['W_minus_W_C'] and result['canonical_sha256']['original_reachable']==loss['canonical_sha256']['original_reachable'],'Saved loss/reach function identities')
    require(result['original_K_initial_quantification']==row['original_K_initial_quantification'] and result['original_K_initial_recomputed'] is False,'Copied original initializer metadata')
    require(result['original_independent_proof']==row['proof'] and result['original_independent_process']==row['process'],'Original independent authority')
    require(result['exact_loss_proof']==row['loss_proof'] and result['exact_loss_process']==row['loss_process'],'Exact-loss authority')
    expected=freeze['code_files']+row['input_pins']+[pin(B/'FROZEN.json'),pin(B/'SELECTION.json'),decision_pin]
    require(result['input_pins']==expected,'Exact source/code/decision pins')
    verify([result['functions']])


def run(deadline):
    decision_pin=authorization();end=datetime.fromisoformat(deadline);require(end.tzinfo is not None,'Timezone-aware deadline')
    freeze=read(B/'FROZEN.json');verify(freeze['files'])
    require(freeze['python']==pin(Path(sys.executable).resolve()),'Frozen Python identity')
    selection=read(B/'SELECTION.json');require(selection['eligible_count']==9,'Fixed all-nine completed exact-loss cohort')
    byid={r['id']:r for r in selection['rows']}
    require(not (B/'RUN_STARTED.json').exists() and not (B/'RUN_RECEIPT.json').exists(),'One dispatch only; no retry')
    spec=importlib.util.spec_from_file_location('cooperative_loss_contained_stage',STAGE/'bounded_process.py')
    bounded=importlib.util.module_from_spec(spec);spec.loader.exec_module(bounded)
    with (B/'RUN_STARTED.json').open('x') as f:json.dump({'started_utc':now(),'owner_pid':os.getpid(),'freeze':pin(B/'FROZEN.json'),'root_authorization':decision_pin},f)
    outputs={};output_refs=[decision_pin];stop=False;reasons=[];started=time.monotonic()
    try:
        for ident in selection['eligible_ids']:
            value={'id':ident,'status':'UNKNOWN_NOT_ATTEMPTED','BDD_worker_started':False};outputs[ident]=value
            if stop or (end-datetime.now(timezone.utc)).total_seconds()<MIN_START_SECONDS:continue
            verify(freeze['code_files']+[decision_pin])
            if (end-datetime.now(timezone.utc)).total_seconds()<MIN_START_SECONDS:continue
            value['BDD_worker_started']=None;folder=B/'runs'/ident
            process=bounded.run_bounded([sys.executable,'-B',str(B/'measure.py'),ident],folder/'process',deadline,
                wall_seconds=60,file_bytes=64*1024*1024,watch_files=[folder/'RESULT.json',folder/'FUNCTIONS.json.gz'])
            value.update(BDD_worker_started=process['process_started'],process=pin(folder/'process/PROCESS_RECEIPT.json'));output_refs.append(value['process'])
            if process['status']=='PROCESS_COMPLETED' and process['exit_code']==0 and (folder/'RESULT.json').exists():
                value['status']='UNKNOWN_INTEGRITY';result=read(folder/'RESULT.json');admit_pass(result,ident,byid[ident],freeze,decision_pin)
                value.update(status=result['status'],result=pin(folder/'RESULT.json'));output_refs += [value['result']]+pins_in(result)
                if result['status']=='PASS':
                    value.update(counts=result['counts'],cooperative_loss_nonempty=result['cooperative_loss_nonempty'],
                        original_reachable_cooperative_loss_nonempty=result['original_reachable_cooperative_loss_nonempty'],
                        original_K_initial_quantification=result['original_K_initial_quantification'])
                elif result['status']=='UNKNOWN_INTEGRITY':stop=True;reasons.append('CASE_INTEGRITY')
            else:
                value['status']='UNKNOWN_RESOURCE' if process['status']=='UNKNOWN_RESOURCE' else 'UNKNOWN_PROCESS'
                if value['status']=='UNKNOWN_PROCESS':stop=True;reasons.append('UNEXPECTED_WORKER_EXIT_OR_MISSING_RESULT')
            if process['status'].startswith('FATAL_'):stop=True;reasons.append('PROCESS_INTEGRITY')
            verify([decision_pin]);save(B/'PROGRESS.json',{'finished':False,'rows':list(outputs.values()),'native_runs':0,'new_fixed_point_runs':0})
    except BaseException as ex:stop=True;reasons.append(repr(ex))
    try:verify(freeze['files']+output_refs)
    except BaseException as ex:stop=True;reasons.append('FINAL_PIN_INTEGRITY:'+repr(ex))
    for value in outputs.values():preserve_interrupted_attempt(value)
    rows=[]
    for source in selection['rows']:
        rows.append(outputs.get(source['id'],{'id':source['id'],
            'status':'UNKNOWN_NOT_ATTEMPTED' if source['eligible'] else source['not_selected_reason'],
            'BDD_worker_started':False,'prior_status':source['prior_status'],'condition_status':source['condition_status'],
            'condition_W_subset_C':source.get('condition_W_subset_C'),'exact_loss_status':source['exact_loss_status']}))
    receipt={'schema':'cooperative-preservation-loss-run-v1','finished_utc':now(),'elapsed_seconds':time.monotonic()-started,
        'source_denominator':425,'authoritative_region_count':59,'condition_targeted_count':10,'completed_exact_loss_count':9,
        'prior_exact_loss_resource_unknown_count':1,'prior_exact_loss_resource_unknown_ids':selection['exact_loss_resource_unknown_ids'],
        'rows':rows,'global_stop':stop,'stop_reasons':reasons,'parent_aborted':True,'root_authorization':decision_pin,
        'unknown_is_negative':False,'native_runs':0,'new_fixed_point_runs':0,'full_reset_uses':0,'complete_semantic_literal_only':True,
        'released_syntactic_loss_conclusion':None,'runtime_or_controller_reachability_conclusion':None,'cooperative_initializer_false_rejection_conclusion':None,
        'BDD_worker_calls':{'confirmed':sum(v.get('BDD_worker_started') is True for v in rows),'uncertain':sum(v.get('BDD_worker_started') is None for v in rows)}}
    save(B/'RUN_RECEIPT.json',receipt)
    save(B/'RESULT_FILES.json',{'files':[pin(p) for p in sorted(B.rglob('*')) if p.is_file() and p.name!='RESULT_FILES.json']})
    print(json.dumps({'global_stop':stop,'BDD_worker_calls':receipt['BDD_worker_calls']}))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=('select','prepare','preflight','run'));parser.add_argument('--deadline-utc');args=parser.parse_args()
    if args.mode=='select':
        require(not (B/'SELECTION.json').exists(),'No selection overwrite');save(B/'SELECTION.json',select());print('Selected all nine exact-loss PASS; corpus BDD=0');return
    if args.mode=='prepare':prepare();return
    frozen=read(B/'FROZEN.json');verify(frozen['files'])
    if args.mode=='preflight':print(json.dumps({'status':'PASS_SOURCE_FREEZE','native_runs':0,'new_fixed_point_runs':0,'corpus_BDD_computations':0}));return
    require(args.deadline_utc is not None,'Root-specified absolute deadline required');run(args.deadline_utc)


if __name__=='__main__':main()
