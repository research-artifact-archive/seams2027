"""Certify unmodified Slugs JSON against the exact exported original typed arena."""
from pathlib import Path
from collections import defaultdict,deque
from itertools import product
import argparse,importlib.util,json,re,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('slugs_arena_exporter',HERE/'exporter.py');ex=importlib.util.module_from_spec(spec);spec.loader.exec_module(ex)
core=ex.core;require,Invalid,ResourceRefusal=ex.require,ex.Invalid,ex.ResourceRefusal
MAX_STATES=32768;MAX_EDGES=1000000;MAX_INPUT_CHECKS=4000000

class ControllerDefect(Invalid):
 def __init__(self,defects):self.defects=defects;super().__init__('Complete Slugs controller violates original model obligations')

def baseline_freeze():
 require(ex.sha(HERE.parent/'BASELINE_FREEZE.json')=='7e21ad3c015dde23f8de56c65b5052cff2931bfac1244841ac31beba2d81131a','Baseline freeze changed')
 data=ex.READ(HERE.parent/'BASELINE_FREEZE.json')
 require(data['schema']=='slugs-public-2015-baseline-freeze-v1' and data['source_commit']=='ac09bf652d4ff47a7018d6a41627af73a67a049c','Baseline source identity')
 require(data['options']==['--cooperativeGR1Strategy','--explicitStrategy','--jsonOutput'] and data['TACAS2019_same_implementation_claim'] is False,'Baseline option/identity boundary')
 ref=data['binary'];p=Path(ref['path'])
 require(p.is_file() and p.stat().st_size==ref['bytes'] and ex.sha(p)==ref['sha256'],'Baseline binary changed')
 return data

def analyze_controller(ctx,mapping,data):
 require(isinstance(data,dict) and set(data)=={'version','slugs','variables','nodes'},'Exact upstream JSON top-level schema')
 require(type(data['version']) is int and data['version']==0 and data['slugs']=='0.0.1','Upstream JSON version')
 require(data['variables']==mapping['variables'],'Complete output variable order')
 nodes=data['nodes'];require(isinstance(nodes,dict),'JSON node map')
 if len(nodes)>MAX_STATES:raise ResourceRefusal('Slugs state budget exceeded')
 rank_size=max(1,len(ctx.justices['SYS']))+max(1,len(ctx.justices['ENV']))
 require(set(nodes)=={str(i) for i in range(len(nodes))},'Contiguous native node IDs')
 current_bits=[mapping['aliases'][n] for n in data['variables']]
 decoded={};seen=set();flat=[]
 for sid,node in nodes.items():
  require(isinstance(node,dict) and set(node)=={'rank','state','trans'},'Exact upstream node schema')
  rank=node['rank'];require(type(rank) is int and 0<=rank<rank_size,'Native private-goal rank range')
  state=node['state'];require(isinstance(state,list) and len(state)==len(current_bits)
      and all(type(bit) is int and bit in (0,1) for bit in state),'Full Boolean output state')
  bits={k:bool(v) for k,v in zip(current_bits,state)};values={}
  for field in ctx.fields:
   candidates=[v for v in field['values'] if all(bits[k]==truth for k,truth in ctx.enc[field['name']][v][0].items())]
   require(len(candidates)==1,'Output uses invalid typed encoding')
   values[field['name']]=candidates[0]
  key=(rank,tuple(values[k] for k in ctx.by_name));require(key not in seen,'Duplicate valuation/private-goal identity');seen.add(key)
  targets=node['trans'];require(isinstance(targets,list) and all(type(t) is int and str(t) in nodes for t in targets)
      and len(targets)==len(set(targets)),'Complete unique successor IDs')
  flat.extend([[sid,str(t)] for t in targets])
  if len(flat)>MAX_EDGES:raise ResourceRefusal('Slugs edge budget exceeded')
  decoded[sid]={'valuation':values,'bits':bits,'rank':rank,'successors':[str(t) for t in targets]}
 # Upstream JSON omits initial flags. The public extractor enumerates every
 # W & thetaE & thetaS valuation at goal 0. Reconstruct all nodes satisfying
 # the original initial predicates at rank0, retain all of them, and check the
 # resulting full graph. Do not select a convenient SYS witness per ENV.
 starts=[sid for sid,node in decoded.items() if node['rank']==0 and ctx.b.evaluate(ctx.b.conj(ctx.formulas['thetaE'],ctx.formulas['thetaS']),node['bits'])]
 env_inputs=list(product(*(ctx.by_name[k]['values'] for k in ctx.env)))
 env_initials={xs for xs in env_inputs if ctx.b.evaluate(ctx.formulas['thetaE'],ctx.bits(dict(zip(ctx.env,xs))))}
 if not env_initials:
  require(not nodes,'Empty ENV initializer should yield an empty upstream graph')
  return {'status':'VALID_VACUOUS_INITIALIZER','strict_controller_pass':None,'nonconflicting_pass':None,'kind_controller_pass':None,
          'state_count':0,'edge_count':0,'initial_state_count':0,'initial_ENV_count':0,'witnesses':[]}
 failures=[]
 if not starts:failures.append({'kind':'NO_VALID_RANK0_INITIAL_ROOT'})
 actual=defaultdict(list)
 for sid in starts:actual[tuple(decoded[sid]['valuation'][k] for k in ctx.env)].append(sid)
 missing=env_initials-set(actual)
 if missing:failures.append({'kind':'MISSING_INITIAL_ENV_RESPONSE','inputs':[dict(zip(ctx.env,xs)) for xs in sorted(missing)]})
 if failures:raise ControllerDefect(failures)
 parent={sid:None for sid in starts};queue=deque(starts)
 while queue:
  sid=queue.popleft()
  for target in decoded[sid]['successors']:
   if target not in parent:parent[target]=sid;queue.append(target)
 require(set(parent)==set(nodes),'Output has nodes unreachable from all reconstructed initial roots')
 if len(nodes)*len(env_inputs)>MAX_INPUT_CHECKS:raise ResourceRefusal('Slugs legal-input audit budget exceeded')
 checks=0
 for sid,node in decoded.items():
  legal={xs for xs in env_inputs if ctx.b.evaluate(ctx.formulas['rhoE'],node['bits']|ctx.bits(dict(zip(ctx.env,xs)),True))}
  checks+=len(env_inputs);responses=defaultdict(list)
  for tid in node['successors']:
   target=decoded[tid];inp=tuple(target['valuation'][k] for k in ctx.env);responses[inp].append(tid)
   if not ctx.b.evaluate(ctx.formulas['rhoS'],node['bits']|ctx.bits(target['valuation'],True)):
    failures.append({'kind':'ORIGINAL_SYS_SAFETY','source':sid,'target':tid})
  for kind,bad in [('MISSING_LEGAL_INPUT',legal-set(responses)),('ILLEGAL_ENV_EDGE',set(responses)-legal)]:
   if bad:failures.append({'kind':kind,'source':sid,'inputs':[dict(zip(ctx.env,xs)) for xs in sorted(bad)]})
  for xs,targets in responses.items():
   if len(targets)!=1:failures.append({'kind':'NONDETERMINISTIC_RESPONSE_OR_MEMORY','source':sid,'input':dict(zip(ctx.env,xs)),'targets':targets})
 if failures:raise ControllerDefect(failures)
 graph={'states':list(decoded),'starts':starts,'edges':flat}
 for owner,key in [('ENV','env_justice'),('SYS','sys_justice')]:
  graph[key]=[[sid for sid,node in decoded.items() if ctx.b.evaluate(u,node['bits'])] for u in ctx.justices[owner]]
 fair=core.graph_analyzer()(graph)
 witnesses=[]
 if not fair['nonconflicting']['pass']:
  witnesses.append({'kind':'NO_FAIR_CONTINUATION','prefix':fair['nonconflicting']['first_failing_prefix'],'all_bad_states':fair['nonconflicting']['failing_states']})
 witnesses.extend(fair['strict_liveness']['counterexamples'])
 return {'status':'VALID_EXPORT_CERTIFICATE','strict_controller_pass':fair['strict_liveness']['pass'],'nonconflicting_pass':fair['nonconflicting']['pass'],
         'kind_controller_pass':fair['strict_liveness']['pass'] and fair['nonconflicting']['pass'],'witnesses':witnesses,
         'state_count':len(nodes),'edge_count':len(flat),'initial_state_count':len(starts),'initial_ENV_count':len(env_initials),
         'initial_response_counts':[{'ENV':dict(zip(ctx.env,xs)),'root_ids':ids} for xs,ids in sorted(actual.items())],
         'initial_contract':'Each legal initial ENV has at least one SYS/AUX response. Every reconstructed joint initial root is retained and checked.',
         'initial_flag_boundary':'Upstream JSON has no initial flags; roots are reconstructed as all rank0 nodes satisfying original thetaE and thetaS, consistent with pinned extractor code.',
         'private_memory':'Unmodified upstream goal-index rank; not JTLV GR1RankInfo. No rank/valuation merge.',
         'V_restriction_applied':False,'legal_input_checks':checks,'fairness':fair,'graph':graph,
         'typed_nodes':decoded}

def check(export_dir,native_dir,qualification_profile=None):
 out={'schema':'slugs-original-model-graph-certificate-v1','status':'INVALID','baseline':ex.BASELINE,
      'strict_controller_pass':None,'nonconflicting_pass':None,'kind_controller_pass':None,'witnesses':[],
      'refusal_scope':'QUALIFICATION_INTEGRITY','failure_stage':'EXPORT_BINDING','native_scientific_synthesis_calls_by_checker':0,
      'checker_sha256':ex.sha(Path(__file__)),'trust_boundary':'Static supplied graph plus pinned upstream implementation and run receipt; saved JSON alone does not establish historical native invocation. Shared source-to-BDD compiler.'}
 try:
  ed=Path(export_dir).resolve();nd=Path(native_dir).resolve()
  ctx,export,mapping=ex.load_export(ed,qualification_profile)
  out['fixture_id']=export['fixture_id'];out['qualification_only']=qualification_profile is not None
  out['export_certificate_pin']=dict(path=str(ed/'EXPORT_CERTIFICATE.json'),**ex.pin(ed/'EXPORT_CERTIFICATE.json'))
  freeze=baseline_freeze();out['baseline_freeze_sha256']=ex.sha(HERE.parent/'BASELINE_FREEZE.json')
  out['failure_stage']='RUN_RECEIPT_BINDING'
  result=ex.READ(nd/'result.json');out['native_result_pin']=ex.pin(nd/'result.json')
  require(result.get('schema')=='slugs-2015-native-run-v1' and result.get('fixture_id')==export['fixture_id'],'Native receipt identity')
  require(result.get('source_commit')==freeze['source_commit'] and result.get('binary_sha256')==freeze['binary']['sha256'],'Native source/binary binding')
  require(result.get('input_sha256')==export['arena']['sha256'] and result.get('export_certificate_sha256')==ex.sha(ed/'EXPORT_CERTIFICATE.json'),'Native input binding')
  require(result.get('argv')==[freeze['binary']['path']]+freeze['options']+[str(ed/'arena.slugsin'),str(nd/'controller.json')],'Exact native argv: no robotics/recovery/other modes')
  stdout=core.pinned_file(nd,result['stdout']);stderr=core.pinned_file(nd,result['stderr'])
  out['native_status']=result.get('status')
  if str(result.get('status','')).startswith('UNKNOWN_'):
   out.update(status='UNKNOWN_NATIVE_RUN',refusal_scope='CANDIDATE_TECHNICAL',failure_stage='NATIVE_RUN');return out
  require(type(result.get('exit_code')) is int and result['exit_code']==0 and result.get('native_solver_called') is True,'Complete native execution receipt')
  results=re.findall(r'^RESULT: Specification is (realizable|unrealizable)\.$',stderr.read_text(),re.M)
  require(len(results)==1,'Unique native verdict line')
  if result['status']=='COMPLETE_UNREALIZABLE':
   require(results==['unrealizable'] and result.get('controller_export') is None and not (nd/'controller.json').exists(),'Native negative output boundary')
   require(ctx.formulas['thetaE']!=0,'Empty ENV cannot justify native unrealizable result')
   out.update(status='VALID_NATIVE_NEGATIVE',refusal_scope='SOURCE_BOUND_NATIVE_NEGATIVE',failure_stage=None,
       negative_claim='Pinned native verdict only; independent unrealizability is not claimed.');return out
  require(result['status']=='COMPLETE_REALIZABLE' and results==['realizable'],'Native positive verdict mismatch')
  cp=core.pinned_file(nd,result['controller_export']);require(cp.name=='controller.json','Controller filename/argv mismatch')
  out['failure_stage']='CONTROLLER_CHECK';out['controller_pin']=ex.pin(cp)
  proof=analyze_controller(ctx,mapping,ex.READ(cp))
  for key in ('status','strict_controller_pass','nonconflicting_pass','kind_controller_pass','witnesses'):out[key]=proof[key]
  out.update(controller_audit=proof,failure_stage=None,refusal_scope='VACUOUS_INITIALIZER' if proof['status']=='VALID_VACUOUS_INITIALIZER' else None)
 except ControllerDefect as e:out.update(status='INVALID',error=str(e),refusal_scope='CANDIDATE_CONTROLLER',controller_defects=e.defects,witnesses=e.defects)
 except ResourceRefusal as e:out.update(status='RESOURCE_REFUSAL',error=str(e),refusal_scope='CANDIDATE_TECHNICAL')
 except (Invalid,OSError,UnicodeError,json.JSONDecodeError,KeyError,TypeError,ValueError,IndexError,AttributeError,RecursionError) as e:
  out.update(status='INVALID',error=type(e).__name__+': '+str(e))
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--export-dir',required=True);ap.add_argument('--native-dir',required=True);ap.add_argument('--output-dir',required=True);a=ap.parse_args()
 dest=Path(a.output_dir).resolve();require(dest.is_relative_to(HERE.parent),'Certificate output outside baseline directory');dest.mkdir(parents=True,exist_ok=True)
 cert=check(a.export_dir,a.native_dir);ex.save(dest/'certificate.json',cert)
 print(json.dumps({k:cert.get(k) for k in ('fixture_id','status','kind_controller_pass','error')}))
 return 0 if cert['status'] in ('VALID_EXPORT_CERTIFICATE','VALID_NATIVE_NEGATIVE','VALID_VACUOUS_INITIALIZER') else 2
if __name__=='__main__':raise SystemExit(main())
