"""Serial, deadline-bounded orchestration; the parent does no BDD calculation."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import argparse, json, os, signal, subprocess, sys, time
sys.dont_write_bytecode = True
from check_case import HERE, BASE, CORPUS, read, save, pin, verify_pin, require

DEADLINE = datetime(2026, 10, 16, 23, 0, tzinfo=timezone.utc)


def now():
    return datetime.now(timezone.utc).isoformat()


def verify_freeze():
    frozen = read(HERE / 'FROZEN.json')
    for p in frozen['checker_files'] + frozen['dependency_files'] + frozen['source_files'] + [frozen['public_archive']]:
        verify_pin(p)
    return frozen


def run_case(case, version, destination, finite=False):
    destination = Path(destination)
    require(not (destination / 'PROCESS_RESULT.json').exists(), 'case already attempted')
    command = [sys.executable, '-B', str(HERE / 'check_case.py'), case, '--version', version,
               '--destination', str(destination)] + (['--finite'] if finite else [])
    logdir = HERE / 'logs' / ('qualification_v1' if finite else version)
    logdir.mkdir(parents=True, exist_ok=True)
    started = time.monotonic(); started_utc = now(); timeout = False
    with (logdir / (case + '.stdout')).open('wb') as out, (logdir / (case + '.stderr')).open('wb') as err:
        process = subprocess.Popen(command, stdout=out, stderr=err, start_new_session=True)
        try:
            code = process.wait(timeout=60)
        except subprocess.TimeoutExpired:
            timeout = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                code = process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL); code = process.wait()
    record = {'id': case, 'version': version, 'started_utc': started_utc, 'finished_utc': now(),
              'process_exit_code': code, 'process_elapsed_seconds': time.monotonic() - started,
              'hard_timeout': timeout, 'native_runs': 0, 'full_resets': 0}
    if timeout:
        record.update(status='UNKNOWN_RESOURCE_TIMEOUT', reason='60-second worker process limit')
    elif (destination / 'RESULT.json').exists():
        child = read(destination / 'RESULT.json')
        record.update(status=child['status'], child_result=pin(destination / 'RESULT.json'))
        if code != 0:
            record.update(status='FAIL_WORKER', reason='worker nonzero exit')
    else:
        record.update(status='FAIL_WORKER', reason='worker ended without RESULT.json')
    save(destination / 'PROCESS_RESULT.json', record)
    print(json.dumps({k: record[k] for k in ('id', 'version', 'status', 'process_elapsed_seconds')}), flush=True)
    return record


def qualify():
    frozen = verify_freeze()
    require(not (HERE / 'qualification/QUALIFICATION.json').exists(), 'qualification already recorded')
    start = now()
    boundary_process = subprocess.run([sys.executable, '-B', str(HERE / 'qualify.py')], timeout=60, capture_output=True, text=True)
    save(HERE / 'qualification/BOUNDARY_PROCESS.json', {'returncode': boundary_process.returncode,
         'stdout': boundary_process.stdout, 'stderr': boundary_process.stderr, 'native_runs': 0})
    if boundary_process.returncode != 0 or not (HERE / 'qualification/BOUNDARY.json').exists():
        out = {'status': 'FAIL_BOUNDARY', 'started_utc': start, 'finished_utc': now(), 'native_runs': 0, 'rows': []}
        save(HERE / 'qualification/QUALIFICATION.json', out)
        return out
    boundary = read(HERE / 'qualification/BOUNDARY.json')
    require(boundary['status'] == 'PASS', 'boundary failed')
    rows = []
    for case in sorted(frozen['finite_PASS_inputs']):
        row = run_case(case, 'v1', HERE / 'qualification/v1' / case, finite=True)
        rows.append(row)
    verify_freeze()
    out = {'status': 'PASS' if all(r['status'] == 'PASS' for r in rows) else 'FAIL_FINITE_COMPARISON',
           'started_utc': start, 'finished_utc': now(), 'native_runs': 0, 'scientific_inputs_added': 0,
           'boundary': pin(HERE / 'qualification/BOUNDARY.json'), 'finite_PASS_case_count': len(rows),
           'freeze': pin(HERE / 'FROZEN.json'), 'rows': rows}
    save(HERE / 'qualification/QUALIFICATION.json', out)
    print(json.dumps({k: out[k] for k in ('status', 'finite_PASS_case_count', 'native_runs')}), flush=True)
    return out


def native_outcome(case):
    p = BASE / 'kind_corpus_rle/runs' / case / 'OUTCOME.json'
    if not p.exists():
        return None
    try:
        return read(p)
    except (OSError, ValueError):
        return None


def snapshot(frozen, finished=False):
    rows = []
    for row in frozen['roster']:
        case = row['id']; p = HERE / 'runs/v2' / case / 'PROCESS_RESULT.json'
        native = native_outcome(case)
        out = {'id': case, 'source': row['path'], 'source_roles': row['source_roles'],
               'native_outcome': None if native is None else native.get('outcome'),
               'status': 'UNKNOWN_NATIVE_NOT_ARRIVED' if native is None else 'UNKNOWN_INDEPENDENT_NOT_ATTEMPTED',
               'counts': None, 'initial_quantification': None, 'well_separation': None}
        if p.exists():
            process = read(p); out['status'] = process['status']
            out['process_receipt'] = str(p)
            if process.get('child_result'):
                child = read(process['child_result']['path'])
                out['reason'] = child.get('reason')
                out['variable_count'] = child.get('variable_count'); out['carrier'] = child.get('carrier')
                if out['status'] == 'PASS':
                    out['counts'] = child['counts']; out['initial_quantification'] = child['initial_quantification']
                    out['well_separation'] = child['well_separation']; out['initialized_ENV_count'] = child['initialized_ENV_count']
        elif native is not None and native.get('outcome') != 'COMPLETE_SYMBOLIC_INDEPENDENT_PENDING':
            out['status'] = 'UNKNOWN_NATIVE'
        rows.append(out)
    passed = [x for x in rows if x['status'] == 'PASS']
    out = {'updated_utc': now(), 'finished': finished, 'deadline_utc': DEADLINE.isoformat(),
           'roster_count': len(rows), 'status_counts': dict(Counter(x['status'] for x in rows)),
           'native_outcome_counts': dict(Counter(x['native_outcome'] or 'NOT_ARRIVED' for x in rows)),
           'scientific_summary_over_independent_PASS_only': {
               'PASS_cases': len(passed),
               'nonempty_WV_minus_K': sum(x['counts']['WV_minus_K'] > 0 for x in passed),
               'nonempty_original_reachable_WV_minus_K': sum(x['counts']['reachable_WV_minus_K'] > 0 for x in passed),
               'original_initial_WV_true_K_false': sum(x['initial_quantification']['WV']['value'] and not x['initial_quantification']['K']['value'] for x in passed),
               'modified_definition_not_well_separated': sum(not x['well_separation']['definition_global_well_separated'] for x in passed),
               'original_joint_not_well_separated': sum(not x['well_separation']['original_joint_restricted_well_separated'] for x in passed),
               'empty_ENV_initial': sum(x['initialized_ENV_count'] == 0 for x in passed)},
           'qualification_v1_counted_as_scientific_inputs': False, 'native_runs': 0, 'full_resets': 0,
           'performance_claim': False, 'rows': rows}
    save(HERE / 'FOLLOW.json', out)
    return out


def follow():
    frozen = verify_freeze()
    qualification = read(HERE / 'qualification/QUALIFICATION.json')
    require(qualification['status'] == 'PASS' and qualification['freeze'] == pin(HERE / 'FROZEN.json'), 'qualification gate')
    lock = HERE / 'RUNNING.lock'
    descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    with os.fdopen(descriptor, 'w') as f:
        f.write(str(os.getpid()))
    if not (HERE / 'RUN_STARTED.json').exists():
        save(HERE / 'RUN_STARTED.json', {'started_utc': now(), 'pid': os.getpid(), 'freeze': pin(HERE / 'FROZEN.json'),
             'selection': 'entire frozen425 lex order; wait for native outcome; no result-sign selection', 'active_BDD_workers': 1})
    try:
        snapshot(frozen)
        for row in frozen['roster']:
            case = row['id']; destination = HERE / 'runs/v2' / case
            if (destination / 'PROCESS_RESULT.json').exists():
                continue
            while native_outcome(case) is None and (DEADLINE - datetime.now(timezone.utc)).total_seconds() >= 60:
                time.sleep(1)
            native = native_outcome(case)
            if native is None or (DEADLINE - datetime.now(timezone.utc)).total_seconds() < 60:
                break
            if native.get('outcome') != 'COMPLETE_SYMBOLIC_INDEPENDENT_PENDING':
                save(destination / 'PROCESS_RESULT.json', {'id': case, 'version': 'v2', 'status': 'UNKNOWN_NATIVE',
                    'native_outcome': native.get('outcome'), 'native_outcome_pin': pin(BASE / 'kind_corpus_rle/runs' / case / 'OUTCOME.json'),
                    'native_runs': 0, 'finished_utc': now()})
            else:
                run_case(case, 'v2', destination)
            snapshot(frozen)
        verify_freeze()
        final = snapshot(frozen, finished=True)
        save(HERE / 'RUN_RECEIPT.json', {'finished_utc': now(), 'status_counts': final['status_counts'],
             'freeze': pin(HERE / 'FROZEN.json'), 'all_pins_unchanged': True,
             'native_runs': 0, 'full_resets': 0, 'performance_claim': False})
        print(json.dumps({'finished': True, 'status_counts': final['status_counts']}), flush=True)
    finally:
        lock.unlink(missing_ok=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--qualify', action='store_true'); parser.add_argument('--follow', action='store_true')
    parser.add_argument('--snapshot', action='store_true')
    args = parser.parse_args()
    require(sum((args.qualify, args.follow, args.snapshot)) == 1, 'choose one operation')
    if args.qualify:
        out = qualify(); sys.exit(0 if out['status'] == 'PASS' else 1)
    if args.follow:
        follow()
    if args.snapshot:
        out = snapshot(read(HERE / 'FROZEN.json')); print(json.dumps(out['status_counts']))
