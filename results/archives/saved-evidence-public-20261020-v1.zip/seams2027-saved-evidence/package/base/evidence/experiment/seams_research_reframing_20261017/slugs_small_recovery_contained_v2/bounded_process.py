"""Compatibility import of the separately frozen exact-child stage supervisor."""
from pathlib import Path
import importlib.util
TARGET=Path(__file__).resolve().parent.parent/'contained_stage_process/bounded_process.py'
spec=importlib.util.spec_from_file_location('slugs_recovery_contained_process',TARGET)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
run_bounded=module.run_bounded
pin=module.pin
output_pin=module.output_pin
save=module.save
now=module.now
