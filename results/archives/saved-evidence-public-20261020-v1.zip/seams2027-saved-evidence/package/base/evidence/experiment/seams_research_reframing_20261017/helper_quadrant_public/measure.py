"""One authorized saved-output relation audit, bounded by the enclosing stage."""
import gzip,json,signal,sys,time,traceback
from pathlib import Path
sys.dont_write_bytecode=True
from evidence import B,read,save,pin,verify,require,now
from map_pair import build,ResourceRefusal
from relations import compare,count,digest,decode

def authorization():
    ref=pin(B/'ROOT_START_DECISION.json');decision=read(ref['path'])
    require(decision.get('start_authorized') is True and decision.get('freeze')==pin(B/'FROZEN.json'),'Exact Root freeze authorization required')
    verify([ref]);return ref

def supplemental(pair,roots):
    b=pair['common'];fields=pair['original_fields'];variables=tuple(pair['original_current_bits'])+((pair['helper_current_bit'],) if pair['helper_added'] else ())
    def detail(label,u):
        roots[label]=u;witness=None
        if u:
            bits=b.satone(u,variables);require(b.evaluate(u,bits),'Full current-domain witness')
            witness={'current':decode(fields,bits,'current'),'bits':bits,'helper_current':bits[pair['helper_current_bit']] if pair['helper_added'] else None}
        return {'count':count(b,u,variables),'canonical_sha256':digest(b,u),'typed_witness':witness}
    initial={}
    for k,v in pair['initial_full_domain'].items():initial[k]={'equal_full_typed_current_domain':v['equal_full_typed_current_domain'],'difference':detail('initial_'+k,v['difference_root'])}
    justice={}
    for owner,v in pair['justice_full_domain'].items():
        justice[owner]={k:x for k,x in v.items() if k!='difference_roots'}
        justice[owner]['differences']=[detail('justice_'+owner+'_'+str(i),u) for i,u in enumerate(v['difference_roots'])]
    return {'initial':initial,'justice':justice,'all_equal':all(v['equal_full_typed_current_domain'] for v in initial.values()) and all(v['equal_identity_and_order_full_typed_current_domain'] for v in justice.values()),'interpretation':'Full typed current domain includes both helper values. Original justice order is retained after removing the unique helper GF not-b entry; insertion position is recorded, not assumed.'}

def export(path,pair,roots):
    b=pair['common'];seen=set();todo=list(roots.values())
    while todo:
        u=todo.pop()
        if u<2 or u in seen:continue
        seen.add(u);todo.extend(b.nodes[u][1:])
    value={'schema':'helper-quadrant-canonical-functions-v1','variable_count':b.n,'canonical_variable_order':list(range(b.n)),
        'original_fields':pair['original_fields'],'original_current_bits':pair['original_current_bits'],'original_next_bits':pair['original_next_bits'],
        'helper_current_bit':pair['helper_current_bit'],'helper_next_bit':pair['helper_next_bit'],'roots':roots,'nodes':[[u,*b.nodes[u]] for u in sorted(seen)]}
    raw=json.dumps(value,ensure_ascii=False,separators=(',',':')).encode()
    if len(raw)>64*1024*1024:raise ResourceRefusal('Canonical function export uncompressed cap64MiB')
    with gzip.GzipFile(filename=str(path),mode='wb',mtime=0) as f:f.write(raw)

def main(ident):
    decision=authorization();freeze=read(B/'FROZEN.json');selection=read(B/'SELECTION.json')
    row=next(r for r in selection['rows'] if r['id']==ident and r['eligible']);directory=B/'runs'/ident;directory.mkdir(parents=True,exist_ok=True)
    require(not (directory/'RESULT.json').exists(),'No duplicate audit/retry')
    refs=freeze['code_files']+row['input_pins']+[pin(B/'FROZEN.json'),pin(B/'SELECTION.json'),decision]
    result={'schema':'helper-quadrant-case-v1','id':ident,'status':'UNKNOWN_INCOMPLETE','created_utc':now(),'parent_aborted':True,'root_authorization':decision,
        'native_runs':0,'full_reset_uses':0,'winning_regions_computed':False,'released_route_loss_conclusion':None,'AUX_causal_attribution':'UNKNOWN_NO_PER_CONSTRAINT_SEMANTIC_PROOF'}
    start=time.monotonic();pair=None
    def alarm(*_):raise TimeoutError('Saved-output relation audit wall60s')
    try:
        signal.signal(signal.SIGALRM,alarm);signal.alarm(60);verify(refs)
        pair=build(Path(row['original_model']['path']).parent,row['job_directory'],ident)
        summary,roots=compare(pair['common'],pair['typed_edge_mask'],pair['original_roots']['rhoE'],pair['original_roots']['rhoS'],pair['job_roots']['rhoE'],pair['job_roots']['rhoS'],pair['helper_current_bit'],pair['helper_next_bit'],pair['original_current_bits'],pair['original_next_bits'],pair['original_fields'])
        roots.update(typed_original_edge_mask=pair['typed_edge_mask'],original_rhoE=pair['original_roots']['rhoE'],original_rhoS=pair['original_roots']['rhoS'],job_rhoE=pair['job_roots']['rhoE'],job_rhoS=pair['job_roots']['rhoS'])
        extra=supplemental(pair,roots);export(directory/'FUNCTIONS.json.gz',pair,roots)
        result.update(comparison=summary,supplemental_full_current_checks=extra,original_model_audit=pair['original_audit'],job_model_audit=pair['job_audit'],source_bindings=pair['source_bindings'],
            original_model=row['original_model'],job_model=row['job_model'],native_result=row['native_result'],enclosing_native_parent=row['parent_receipt'],functions=pin(directory/'FUNCTIONS.json.gz'),input_pins=refs,
            shared_source_compiler=True,independent_source_compiler=False,all_original_AUX_retained=True,typed_original_state_carrier=pair['original'].carrier)
        require(summary['typed_original_edge_domain_count']==pair['original'].carrier**2,'Entire original typed current/next pair cardinality')
        verify(refs);result['status']='PASS'
    except (TimeoutError,ResourceRefusal,MemoryError) as error:result.update(status='UNKNOWN_RESOURCE',reason=repr(error))
    except BaseException as error:result.update(status='UNKNOWN_INTEGRITY',reason=repr(error),traceback=traceback.format_exc())
    finally:
        signal.alarm(0);result.update(finished_utc=now(),elapsed_seconds=time.monotonic()-start,allocated_common_BDD_nodes=len(pair['common'].nodes) if pair else None)
        save(directory/'RESULT.json',result)
    print(json.dumps({k:result.get(k) for k in ('id','status','reason')}),flush=True)
if __name__=='__main__':main(sys.argv[1])
