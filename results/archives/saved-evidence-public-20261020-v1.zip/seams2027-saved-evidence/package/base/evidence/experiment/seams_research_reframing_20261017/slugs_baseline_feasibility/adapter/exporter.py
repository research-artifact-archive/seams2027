"""Exact saved-ROBDD to upstream Slugs Boolean DAG language. No synthesis calls."""
from pathlib import Path
from functools import lru_cache
import argparse,hashlib,importlib.util,json,re,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('slugs_original_model_core',HERE/'model_core.py')
core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
require,Invalid,ResourceRefusal=core.require,core.Invalid,core.ResourceRefusal
READ=core.read_json
MAX_INPUT_BYTES=64*1024*1024
BASELINE='IROS2015_PUBLIC_SLUGS_COOPERATIVE_GR1'
SECTIONS=('INPUT','OUTPUT','ENV_INIT','SYS_INIT','ENV_TRANS','SYS_TRANS','ENV_LIVENESS','SYS_LIVENESS')

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):
 p=Path(p);return {'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}
def save(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def frozen_dependencies():
 data=READ(HERE/'DEPENDENCY_FREEZE.json')
 for r in data['files']:core.pinned_file(HERE,r,basename=False)
 return data

def load_model(directory,fixture,qualification_profile=None):
 directory=Path(directory).resolve();frozen_dependencies()
 profile=qualification_profile if qualification_profile is not None else core.load_profile(fixture)
 model=READ(directory/'model.json');ctx=core.Context(directory,profile,model)
 audit=ctx.audit_model()
 return ctx,audit,profile

def aliases(ctx):
 names={};inputs=[];outputs=[]
 for field in ctx.fields:
  target=inputs if field['owner']=='ENV' else outputs
  for pre,post in zip(field['current_bits'],field['next_bits']):
   alias='b'+str(pre);names[pre]=alias;names[post]=alias+"'";target.append(alias)
 require(len(set(names.values()))==len(names),'Nonunique bit aliases')
 return names,inputs,outputs

def encode_bdd(b,root,names):
 if root<2:return str(root)
 ordered=[];seen=set()
 def visit(u):
  if u<2 or u in seen:return
  seen.add(u);v,lo,hi=b.nodes[u];visit(lo);visit(hi);ordered.append(u)
 visit(root)
 indexes={0:0,1:1};cells=['0','1']
 for u in ordered:
  v,lo,hi=b.nodes[u]
  require(v in names,'Unmapped source BDD variable')
  cells.append('| & '+names[v]+' ? '+str(indexes[hi])+' & ! '+names[v]+' ? '+str(indexes[lo]))
  indexes[u]=len(cells)-1
 require(indexes[root]==len(cells)-1,'DAG root must be final memory cell')
 return '$ '+str(len(cells))+' '+' '.join(cells)

class PrefixParser:
 """Independent parser for the emitted subset of Slugs' documented source grammar."""
 def __init__(self,line,b,names,allowed):
  self.tokens=line.split();self.index=0;self.b=b;self.names=names;self.allowed=set(allowed)
 def token(self):
  require(self.index<len(self.tokens),'Truncated Boolean expression')
  t=self.tokens[self.index];self.index+=1;return t
 def expression(self,memory=()):
  op=self.token();b=self.b
  if op in ('0','1'):return int(op)
  if op=='!':return b.neg(self.expression(memory))
  if op in ('&','|','^'):
   lhs=self.expression(memory);rhs=self.expression(memory)
   return b.apply({'&':'and','|':'or','^':'xor'}[op],lhs,rhs)
  if op=='?':
   key=self.token();require(re.fullmatch('0|[1-9][0-9]*',key) is not None,'Invalid memory reference')
   i=int(key);require(i<len(memory),'Forward/unbound memory reference');return memory[i]
  if op=='$':
   key=self.token();require(re.fullmatch('[1-9][0-9]*',key) is not None,'Invalid memory count')
   count=int(key);require(count<=500002,'Memory expression budget')
   local=[]
   for _ in range(count):local.append(self.expression(local))
   return local[-1]
  require(op in self.names and self.names[op] in self.allowed,'Unknown/forbidden bit alias: '+op)
  return b.var(self.names[op])
 def parse(self):
  out=self.expression();require(self.index==len(self.tokens),'Trailing Boolean tokens');return out

def audit_input(path,ctx,mapping):
 raw=core.file_bytes(Path(path),MAX_INPUT_BYTES);text=raw.decode('ascii')
 sections={};current=None
 for rawline in text.splitlines():
  line=rawline.strip()
  if not line or line.startswith('#'):continue
  if line.startswith('['):
   require(line.startswith('[') and line.endswith(']'),'Section syntax')
   current=line[1:-1];require(current in SECTIONS and current not in sections,'Unknown/repeated section');sections[current]=[]
  else:
   require(current is not None,'Input before section');sections[current].append(line)
 require(tuple(sections)==SECTIONS,'Complete ordered section roster')
 names,inputs,outputs=aliases(ctx)
 expected_map={'variables':inputs+outputs,'inputs':inputs,'outputs':outputs,
               'aliases':{names[k]:k for k in sorted(names)},'fields':ctx.fields}
 require(mapping==expected_map,'Bit/field map drift')
 require(sections['INPUT']==inputs and sections['OUTPUT']==outputs,'Input/output bit ownership/order')
 inv={v:k for k,v in names.items()}
 limits={'ENV_INIT':ctx.current_env,'SYS_INIT':ctx.current,'ENV_TRANS':ctx.current+ctx.env_next,
         'SYS_TRANS':ctx.current+ctx.next,'ENV_LIVENESS':ctx.current,'SYS_LIVENESS':ctx.current}
 expected={'ENV_INIT':[ctx.formulas['thetaE']],'SYS_INIT':[ctx.formulas['thetaS']],
           'ENV_TRANS':[ctx.formulas['rhoE']],'SYS_TRANS':[ctx.formulas['rhoS']],
           'ENV_LIVENESS':ctx.justices['ENV'],'SYS_LIVENESS':ctx.justices['SYS']}
 rows=[]
 for section,targets in expected.items():
  require(len(sections[section])==len(targets),'Formula/justice roster: '+section)
  for index,(line,target) in enumerate(zip(sections[section],targets)):
   actual=PrefixParser(line,ctx.b,inv,limits[section]).parse()
   require(actual==target,'Exact BDD roundtrip failed: '+section+' '+str(index))
   rows.append({'section':section,'index':index,'equivalence':'EXACT_CANONICAL_BDD'})
 return {'status':'PASS','formula_count':len(rows),'equivalences':rows,
         'equivalence_domain':'Entire encoded Boolean carrier, including unused bit codes; typed domains remain the exact original predicates.',
         'extra_helper_variables':0,'initial_quantifier':'forall_ENV_exists_SYS_AUX','move_order':'ENV_next_then_SYS_AUX_next_atomic_Mealy',
         'native_empty_justice_padding':{o:len(ctx.justices[o])==0 for o in ('ENV','SYS')}}

def export_model(model_dir,fixture,out_dir,qualification_profile=None):
 out=Path(out_dir).resolve();out.mkdir(parents=True,exist_ok=False)
 ctx,audit,profile=load_model(model_dir,fixture,qualification_profile)
 names,inputs,outputs=aliases(ctx)
 mapping={'variables':inputs+outputs,'inputs':inputs,'outputs':outputs,'aliases':{names[k]:k for k in sorted(names)},'fields':ctx.fields}
 formulas={'ENV_INIT':[ctx.formulas['thetaE']],'SYS_INIT':[ctx.formulas['thetaS']],
           'ENV_TRANS':[ctx.formulas['rhoE']],'SYS_TRANS':[ctx.formulas['rhoS']],
           'ENV_LIVENESS':ctx.justices['ENV'],'SYS_LIVENESS':ctx.justices['SYS']}
 lines=['# Exact saved original BDD arena; no V restriction, no helper, no monitor reset.']
 for section in SECTIONS:
  lines.append('['+section+']')
  if section=='INPUT':lines.extend(inputs)
  elif section=='OUTPUT':lines.extend(outputs)
  else:lines.extend(encode_bdd(ctx.b,u,names) for u in formulas[section])
  lines.append('')
 raw=('\n'.join(lines)+'\n').encode('ascii')
 if len(raw)>MAX_INPUT_BYTES:raise ResourceRefusal('Slugs input byte budget exceeded')
 (out/'arena.slugsin').write_bytes(raw);save(out/'MAP.json',mapping)
 roundtrip=audit_input(out/'arena.slugsin',ctx,mapping)
 sources=[{'path':str(Path(model_dir).resolve()/'model.json'),**pin(Path(model_dir)/'model.json')}]
 sources.extend({'path':str(ctx.directory/name),**pin(ctx.directory/name)} for name,_ in sorted(ctx.refs))
 cert={'schema':'slugs-original-arena-export-certificate-v1','status':'PASS','baseline':BASELINE,'fixture_id':fixture,
       'qualification_only':qualification_profile is not None,'model_directory':str(Path(model_dir).resolve()),
       'model_audit':audit,'source_bindings':profile.get('bindings',{'qualification_only':True}),
       'source_files':sources,'arena':pin(out/'arena.slugsin'),'map':pin(out/'MAP.json'),'roundtrip':roundtrip,
       'exporter_sha256':sha(Path(__file__)),'dependency_freeze_sha256':sha(HERE/'DEPENDENCY_FREEZE.json'),
       'native_scientific_synthesis_calls':0,'original_ENV_initializer_empty':ctx.formulas['thetaE']==0,
       'original_joint_initializer_empty':ctx.b.conj(ctx.formulas['thetaE'],ctx.formulas['thetaS'])==0,
       'source_compiler_boundary':'Shared Spectra parser-translated BDD model; no independent Spectra language compiler.'}
 save(out/'EXPORT_CERTIFICATE.json',cert)
 return cert

def load_export(export_dir,qualification_profile=None):
 d=Path(export_dir).resolve();cert=READ(d/'EXPORT_CERTIFICATE.json')
 require(cert.get('schema')=='slugs-original-arena-export-certificate-v1' and cert.get('status')=='PASS' and cert.get('baseline')==BASELINE,'Export certificate identity')
 require(cert.get('qualification_only')==(qualification_profile is not None),'Synthetic/production source boundary')
 require(cert['exporter_sha256']==sha(Path(__file__)) and cert['dependency_freeze_sha256']==sha(HERE/'DEPENDENCY_FREEZE.json'),'Exporter/dependency source drift')
 ctx,audit,profile=load_model(cert['model_directory'],cert['fixture_id'],qualification_profile)
 require(audit==cert['model_audit'],'Model audit changed')
 for ref in cert['source_files']:
  p=Path(ref['path']);require(p.stat().st_size==ref['bytes'] and sha(p)==ref['sha256'],'Source file changed after export')
 arena=core.pinned_file(d,cert['arena']);mp=core.pinned_file(d,cert['map']);mapping=READ(mp)
 require(audit_input(arena,ctx,mapping)==cert['roundtrip'],'Roundtrip certificate changed')
 return ctx,cert,mapping

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--model-dir',required=True);ap.add_argument('--fixture-id',required=True);ap.add_argument('--output-dir',required=True);a=ap.parse_args()
 out=Path(a.output_dir).resolve();require(out.is_relative_to(HERE.parent),'Output outside Slugs baseline directory')
 cert=export_model(a.model_dir,a.fixture_id,out)
 print(json.dumps({'fixture_id':a.fixture_id,'status':cert['status'],'formula_count':cert['roundtrip']['formula_count'],'arena_bytes':cert['arena']['bytes'],'native_scientific_synthesis_calls':0}))
if __name__=='__main__':main()
