"""Saved-region imports and Boolean intersections only; no fixed-point calls."""
from pathlib import Path
import gzip,importlib.util,json,sys
sys.dont_write_bytecode=True
E=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('cooperative_loss_frozen_functions',E/'preservation_loss_public/loss.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
engine,condition=prior.engine,prior.condition
BDD,require,ResourceRefusal,count,root_digest=engine.BDD,engine.require,engine.ResourceRefusal,prior.count,prior.root_digest


def load_k(model,path,proof):
    return prior.load_independent(model,path,proof,names=('K',))['K']


def import_loss(model,payload,proof):
    require(payload['schema']=='complete-semantic-preservation-loss-robdd-v1','Exact-loss export schema')
    require(payload['variable_count']==model.b.n and payload['canonical_variable_order']==list(range(model.b.n)),'Loss canonical variable order')
    require(payload['fields']==model.fields,'Loss complete typed field encoding')
    for key,expected in (('current_bits',model.current),('ENV_current_bits',model.ec),('SYS_and_AUX_current_bits',model.sc),
                         ('ENV_next_bits',model.en),('SYS_and_AUX_next_bits',model.sn)):
        require(payload[key]==list(expected),'Exact-loss ownership/phase '+key)
    roots={}
    for name in ('W_minus_W_C','original_reachable'):
        require(name in payload['roots'],'Missing prior exact-loss root '+name)
        view={**payload,'schema':'independent-canonical-robdd-region-set-v1','roots':{'W':payload['roots'][name]}}
        root=condition.import_w(model.b,view,model.fields)
        require(model.b.support(root)<=set(model.current) and model.b.conj(root,model.b.neg(model.q))==0,'Typed current loss root '+name)
        require(count(model.b,root,model.current)==proof['counts'][name],'Prior loss count '+name)
        require(root_digest(model.b,root)==proof['canonical_sha256'][name],'Prior loss canonical function '+name)
        roots[name]=root
    return roots


def load_loss(model,path,proof):
    with gzip.open(path,'rb') as f:raw=f.read(64*1024*1024+1)
    if len(raw)>64*1024*1024:raise ResourceRefusal('Exact-loss expanded export byte cap')
    return import_loss(model,json.loads(raw,object_pairs_hook=engine.unique),proof)


def compute(b,q,current,k,loss,reachable):
    for name,root in (('K',k),('exact_loss',loss),('original_reachable',reachable)):
        require(b.support(root)<=set(current),'Current support '+name)
        require(b.conj(root,b.neg(q))==0,'Typed domain '+name)
    intersection=b.conj(k,loss)
    return {'K':k,'exact_loss':loss,'original_reachable':reachable,
        'cooperative_loss':intersection,'original_reachable_cooperative_loss':b.conj(reachable,intersection)}


def summarize(model,roots):
    b=model.b
    result={'counts':{name:count(b,root,model.current) for name,root in roots.items()},
        'canonical_sha256':{name:root_digest(b,root) for name,root in roots.items()},
        'cooperative_loss_nonempty':roots['cooperative_loss']!=0,
        'original_reachable_cooperative_loss_nonempty':roots['original_reachable_cooperative_loss']!=0,
        'state_witnesses':{}}
    for name in ('cooperative_loss','original_reachable_cooperative_loss'):
        if roots[name]:
            bits=b.satone(roots[name],model.current)
            require(b.evaluate(roots['K'],bits) and b.evaluate(roots['exact_loss'],bits),'K and exact-loss witness membership')
            if name.startswith('original_reachable'):require(b.evaluate(roots['original_reachable'],bits),'Original existential reachability witness membership')
            result['state_witnesses'][name]={'state':condition.typed_values(model.fields,bits,'current'),'bits':bits,
                'all_logical_AUX_retained':True,'not_a_strategy_or_runtime_trace':True}
        else:result['state_witnesses'][name]=None
    return result


def export(path,model,roots):
    seen=set();todo=list(roots.values())
    while todo:
        u=todo.pop()
        if u<2 or u in seen:continue
        seen.add(u);todo.extend(model.b.nodes[u][1:])
    payload={'schema':'cooperative-preservation-loss-robdd-v1','variable_count':model.b.n,
        'canonical_variable_order':list(range(model.b.n)),'fields':model.fields,'current_bits':model.current,
        'ENV_current_bits':model.ec,'SYS_and_AUX_current_bits':model.sc,'ENV_next_bits':model.en,'SYS_and_AUX_next_bits':model.sn,
        'roots':roots,'nodes':[[u,*model.b.nodes[u]] for u in sorted(seen)]}
    with gzip.GzipFile(filename=str(path),mode='wb',mtime=0) as f:f.write(json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode())
