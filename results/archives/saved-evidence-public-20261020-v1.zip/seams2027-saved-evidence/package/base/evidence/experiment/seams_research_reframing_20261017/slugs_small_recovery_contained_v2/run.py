"""Separate Slugs arm after all three small-recovery arms close. Root dispatch only."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,json,math,os,re,sys,time
sys.dont_write_bytecode=True
from bounded_process import run_bounded,pin,output_pin,save,now
B=Path(__file__).resolve().parent;E=B.parent;BASE=E/'slugs_baseline_feasibility'
PHASE1=E/'kind_corpus_rle';SMALL=E/'small_native_recovery'
PRIOR_ARMS=('v_restricted_strict','normalized_kind','released_kind');COHORT_SIZE=14
DEADLINE='2026-10-17T02:30:00+00:00';QUAL_IDS=['corpus002__original','corpus093__original','corpus058__original']
MIN_START_SECONDS=135;NATIVE_WALL=60;STAGE_WALL=60

def read(path):return json.loads(Path(path).read_text())
def require(ok,message):
    if not ok:raise ValueError(message)
def seconds_left():return (datetime.fromisoformat(DEADLINE)-datetime.now(timezone.utc)).total_seconds()
def call_counts(rows):
    return {'confirmed':sum(r.get('native_called') is True for r in rows),
            'uncertain':sum(r.get('native_called') is None for r in rows)}
def unique_pins(refs):
    out={}
    for ref in refs:
        key=str(Path(ref['path']).resolve());value={k:ref[k] for k in ('bytes','sha256')};value['path']=key
        require(key not in out or out[key]==value,'Conflicting frozen references: '+key);out[key]=value
    return list(out.values())
def pin_errors(refs):
    errors=[]
    for ref in refs:
        try:
            actual=pin(ref['path'])
            if actual!=ref:errors.append({'path':ref['path'],'reason':'CONTENT_CHANGED','expected':ref,'actual':actual})
        except Exception as exc:errors.append({'path':ref['path'],'reason':repr(exc)})
    return errors

def validate_parent(receipt):
    require(receipt.get('global_stop') is True and receipt.get('pin_errors')==[],
            'Preserved parent must remain an integrity-stopped run with unchanged pins')
    require(datetime.fromisoformat(receipt['finished_utc']).tzinfo is not None,'Parent completion timestamp')

def validate_prior(receipt,eligible_ids,parent_pin):
    require(receipt.get('global_stop') is False and receipt.get('pin_errors')==[],'Recovery phase integrity/global stop')
    require(receipt.get('stage')=='COMPLETE','Recovery phase has not closed all arms')
    require(receipt.get('parent_aborted') is True and receipt.get('preserved_parent_receipt')==parent_pin,
            'Recovery must preserve the original aborted parent receipt')
    require(datetime.fromisoformat(receipt['finished_utc']).tzinfo is not None,'Recovery completion timestamp')
    require(receipt.get('source_denominator')==425 and receipt.get('eligible_count')==COHORT_SIZE,'Recovery source counts')
    pairs=[(r['id'],r['pipeline']) for r in receipt['rows']]
    wanted={(ident,arm) for ident in eligible_ids for arm in PRIOR_ARMS}
    require(len(eligible_ids)==COHORT_SIZE and len(set(eligible_ids))==COHORT_SIZE,'Unique recovery cohort')
    require(len(pairs)==COHORT_SIZE*len(PRIOR_ARMS) and len(set(pairs))==len(pairs) and set(pairs)==wanted,
            'Recovery receipt requires each selected source in every native arm exactly once')
    # UNKNOWN outcomes remain observations; this gate never filters by mathematical result.

def choose(selection,roster):
    rows=selection['rows'];expected={r['id']:r for r in roster}
    require(len(roster)==425 and len(expected)==425,'Frozen source denominator')
    require(selection.get('total')==425,'Selection source denominator')
    require(len(rows)==425 and len({r['id'] for r in rows})==425 and {r['id'] for r in rows}==set(expected),
            'Recovery complete unique source selection')
    require(all(type(r.get('eligible')) is bool for r in rows),'Eligibility must be Boolean')
    require(selection.get('parent_aborted') is True,'Selection must retain aborted parent provenance')
    require(selection.get('selection_uses_mathematical_or_graph_outcomes') is False,'Selection must use only source/model availability and size')
    require(selection.get('same_small_cohort_before_interrupted_run') is True,'Unchanged pre-interruption small cohort proof')
    byid={r['id']:r for r in rows};eligible=[]
    for row in roster:
        item=byid[row['id']]
        require(item['source']==row['path'],'Selection source identity')
        if 'model' not in item:
            require(item['eligible'] is False and 'typed_carrier' not in item,'No model cannot be eligible')
            continue
        size=item.get('typed_carrier')
        require(type(size) is int and size>=1,'Positive integer typed carrier')
        require(item['eligible']==(size<=4096),'Eligibility must match model size without outcome filtering')
        if item['eligible']:
            require(Path(item['model']['path']).resolve()==(PHASE1/'runs'/row['id']/'model.json').resolve(),'Require saved v2 original model')
            eligible.append(row)
    ids=[r['id'] for r in eligible]
    require(selection['eligible_count']==len(eligible)==COHORT_SIZE,'Eligible count mismatch')
    require(selection.get('eligible_ids')==ids and selection.get('first_run_small_ids')==ids,'Recovery cohort identity and roster order')
    require(set(QUAL_IDS)<=set(ids),'Fixed qualification cases missing')
    return eligible,byid

def classify_certificate(cert):
    status=cert.get('status');scope=cert.get('refusal_scope')
    if status=='VALID_EXPORT_CERTIFICATE':return 'COMPLETE_GRAPH_CHECKED',True,False
    if status=='VALID_NATIVE_NEGATIVE':return 'COMPLETE_NATIVE_NEGATIVE',True,False
    if status=='VALID_VACUOUS_INITIALIZER':return 'COMPLETE_VACUOUS_INITIALIZER',True,False
    if status=='INVALID' and scope=='CANDIDATE_CONTROLLER':return 'COMPLETE_CONTROLLER_CONTRACT_FAILURE',True,False
    if status=='RESOURCE_REFUSAL':return 'UNKNOWN_CHECKER_RESOURCE',False,False
    if scope=='CANDIDATE_TECHNICAL':return 'UNKNOWN_CHECKER_TECHNICAL',False,False
    return 'UNKNOWN_CHECKER_INTEGRITY',False,True

def native_status(process,stderr,has_controller):
    if process['status'].startswith('FATAL_'):return 'UNKNOWN_SUPERVISOR_INTEGRITY',True
    if process['status']!='PROCESS_COMPLETED':return 'UNKNOWN_NATIVE_RESOURCE',False
    if process['exit_code']!=0:return 'UNKNOWN_NATIVE_EXIT',False
    verdicts=re.findall(r'^RESULT: Specification is (realizable|unrealizable)\.$',stderr,re.M)
    if len(verdicts)!=1:return 'UNKNOWN_VERDICT_INTEGRITY',True
    if verdicts==['realizable'] and has_controller:return 'COMPLETE_REALIZABLE',False
    if verdicts==['unrealizable'] and not has_controller:return 'COMPLETE_UNREALIZABLE',False
    return 'UNKNOWN_CONTROLLER_CAPTURE_INTEGRITY',True

class Runner:
    def __init__(self,package):
        self.files=unique_pins(package['files']+[pin(B/'PRODUCTION_SOURCE_FREEZE.json')]);self.stop=False
        self.errors=[];self.reasons=[];self.qual=[];self.rows=[];self.eligible=[];self.exports={}
        self.attempts={};self.started=time.monotonic();self.stage='WAITING_SMALL_NATIVE_RECOVERY'
    def fail(self,reason):self.stop=True;self.reasons.append(reason)
    def audit(self,where):
        errors=pin_errors(self.files);self.errors.extend(errors)
        if errors:self.fail('PIN_INTEGRITY')
        save(where,{'utc':now(),'status':'FAIL' if errors else 'PASS','checked_files':len(self.files),'errors':errors})
        return not errors
    def add(self,refs):self.files=unique_pins(self.files+refs)
    def archive_outputs(self,folder):
        self.add([pin(p) for p in sorted(Path(folder).rglob('*')) if p.is_file() and not p.name.endswith('.tmp')])
    def wait_and_select(self):
        needed=[SMALL/n for n in ('SELECTION.json','RUN_RECEIPT.json','FROZEN.json')]
        while True:
            if seconds_left()<=0:self.fail('DEADLINE_WAITING_SMALL_NATIVE_RECOVERY');return
            if all(p.is_file() for p in needed):
                try:
                    selection,previous,frozen=[read(p) for p in needed]
                    break
                except (FileNotFoundError,json.JSONDecodeError):
                    pass  # The producer may still be closing its JSON capture.
            time.sleep(min(5,max(0.01,seconds_left())))
        baseline=read(B/'BASELINE_SOURCE.json');parent_pin=baseline['original_parent_phase1_stop_receipt']
        require(pin(PHASE1/'RUN_RECEIPT.json')==parent_pin,'Original aborted parent receipt changed')
        validate_parent(read(PHASE1/'RUN_RECEIPT.json'))
        roster=read(E/'kind_corpus/ROSTER.json')['unique_inputs']
        self.eligible,items=choose(selection,roster)
        ids=[r['id'] for r in self.eligible]
        require(selection.get('parent_stop')==parent_pin,'Selection parent stop binding')
        require(frozen.get('parent_aborted') is True and frozen.get('cohort')==pin(SMALL/'SELECTION.json'),
                'Recovery frozen cohort identity')
        validate_prior(previous,ids,parent_pin)
        refs=[pin(p) for p in needed]+frozen['files']+selection['input_pins']+[parent_pin]
        self.add(refs);require(self.audit(B/'PRIOR_PHASE_PIN_AUDIT.json'),'Recovery phase dependencies changed')
        modelrefs=[]
        for row in self.eligible:
            ident=row['id'];modelpath=PHASE1/'runs'/ident/'model.json';expected=items[ident]['model']
            require(pin(modelpath)==expected,'Selection v2 model pin changed: '+ident);modelrefs.append(expected)
            model=read(modelpath);require(model['fixture_id']==ident and model['input']['sha256']==row['sha256'],'Model/source identity')
            require(math.prod(f['domain_size'] for f in model['fields'])==items[ident]['typed_carrier'],'Model carrier drift')
            records=list(model['original_bdds'].values())+[v for values in model['original_justices'].values() for v in values]
            for record in records:
                f=(modelpath.parent/record['file']).resolve();require(f.parent==modelpath.parent.resolve(),'Original BDD path must stay inside model directory')
                value=pin(f);require(value['bytes']==record['bytes'] and value['sha256']==record['sha256'],'Original BDD pin changed');modelrefs.append(value)
        self.add(modelrefs)
        save(B/'SELECTION.json',{'source_roster':pin(E/'kind_corpus/ROSTER.json'),'small_recovery_selection':pin(SMALL/'SELECTION.json'),
             'small_recovery_receipt':pin(SMALL/'RUN_RECEIPT.json'),'small_recovery_frozen':pin(SMALL/'FROZEN.json'),
             'parent_aborted':True,'parent_global_stop':True,'preserved_parent_receipt':parent_pin,
             'scientific_source_denominator':425,'eligible_count':len(self.eligible),'eligible_ids':ids,
             'selection_uses_solver_or_graph_outcomes':False,'same_small_cohort_before_interrupted_run':True,
             'prior_native_arms':list(PRIOR_ARMS),'v2_model_pins':modelrefs,'qualification_order':QUAL_IDS,'native_retry_count':0})
        self.add([pin(B/'SELECTION.json')]);self.stage='FRESH_V2_EXPORT'
    def export_all(self):
        for row in self.eligible:
            ident=row['id'];folder=B/'preparation'/ident;destination=B/'exports'/ident
            if self.stop or seconds_left()<MIN_START_SECONDS:
                self.exports[ident]={'status':'UNKNOWN_NOT_EXPORTED','reason':'GLOBAL_STOP_OR_DEADLINE'};continue
            require(self.audit(B/'preparation'/('before_'+ident+'.json')),'Pins before fresh export')
            if seconds_left()<MIN_START_SECONDS:
                self.exports[ident]={'status':'UNKNOWN_NOT_EXPORTED','reason':'DEADLINE_AFTER_PIN_AUDIT'};continue
            command=[sys.executable,'-B',str(B/'stage.py'),'export','--fixture-id',ident,'--export-dir',str(destination)]
            process=run_bounded(command,folder,DEADLINE,wall_seconds=STAGE_WALL,file_bytes=64*1024*1024,
                watch_files=[destination/'arena.slugsin',destination/'MAP.json',destination/'EXPORT_CERTIFICATE.json'])
            value={'status':'UNKNOWN_EXPORT_TECHNICAL','process':pin(folder/'PROCESS_RECEIPT.json')}
            if process['status'].startswith('FATAL_'):self.fail('EXPORT_SUPERVISOR_INTEGRITY')
            stage_result=read(folder/'STAGE_RESULT.json') if (folder/'STAGE_RESULT.json').is_file() else {}
            if process['status']=='PROCESS_COMPLETED' and process['exit_code']==0 and stage_result.get('status')=='RESOURCE_REFUSAL':
                value.update(status='UNKNOWN_EXPORT_RESOURCE',resource_reason=stage_result.get('error'))
            elif process['status']=='PROCESS_COMPLETED' and process['exit_code']==0 and stage_result.get('status')=='PASS':
                cert=read(destination/'EXPORT_CERTIFICATE.json')
                require(cert['status']=='PASS' and cert['fixture_id']==ident and cert['qualification_only'] is False,'Fresh export certificate')
                require(Path(cert['model_directory']).resolve()==(PHASE1/'runs'/ident).resolve(),'Fresh v2 export binding')
                value.update(status='PASS',export_certificate=pin(destination/'EXPORT_CERTIFICATE.json'))
                self.archive_outputs(destination)
            elif process['status']=='PROCESS_COMPLETED':self.fail('FRESH_EXPORT_INTEGRITY')
            self.exports[ident]=value;self.archive_outputs(folder)
            if destination.exists():self.archive_outputs(destination)
            if not self.audit(B/'preparation'/('after_'+ident+'.json')):break
        save(B/'EXPORT_STATUS.json',{'rows':self.exports,'native_calls':0});self.add([pin(B/'EXPORT_STATUS.json')])
        save(B/'INPUT_FREEZE.json',{'created_utc':now(),'files':self.files,'cohort':pin(B/'SELECTION.json'),
             'deadline_utc':DEADLINE,'qualification_calls_before_freeze':0,'graph_limits':{'states':4096,'edges':65536}})
        self.add([pin(B/'INPUT_FREEZE.json')]);self.stage='NATIVE_QUALIFICATION'
    def attempt(self,row,phase):
        ident=row['id'];arm=B/('qualification' if phase=='qualification' else 'runs')/ident
        value={'id':ident,'phase':phase,'outcome':'UNKNOWN_NOT_ATTEMPTED','qualification_gate_pass':False,'native_called':False,
               'strict_controller_pass':None,'nonconflicting_pass':None,'kind_controller_pass':None}
        self.attempts[(phase,ident)]=value
        if self.stop or seconds_left()<MIN_START_SECONDS:
            value['reason']='GLOBAL_STOP_OR_DEADLINE';return value
        if self.exports.get(ident,{}).get('status')!='PASS':
            value.update(outcome='UNKNOWN_EXPORT',reason=self.exports.get(ident));return value
        arm.mkdir(parents=True,exist_ok=False);require(self.audit(arm/'PINS_BEFORE.json'),'Pins before native')
        export=B/'exports'/ident;native=arm/'native';baseline=read(BASE/'BASELINE_FREEZE.json');ec=read(export/'EXPORT_CERTIFICATE.json')
        command=[baseline['binary']['path']]+baseline['options']+[str(export/'arena.slugsin'),str(native/'controller.json')]
        if seconds_left()<MIN_START_SECONDS:
            value['reason']='DEADLINE_AFTER_PIN_AUDIT';save(arm/'OUTCOME.json',value);self.archive_outputs(arm);return value
        value['native_called']=None  # A thrown wrapper call cannot establish non-execution.
        process=run_bounded(command,native,DEADLINE,wall_seconds=NATIVE_WALL,watch_files=[native/'controller.json'])
        value['native_called']=process['process_started']
        status,fatal=native_status(process,(native/'stderr.txt').read_text(errors='replace'),(native/'controller.json').is_file())
        if fatal:self.fail(status)
        result={'schema':'slugs-2015-native-run-v1','fixture_id':ident,'status':status,'source_commit':baseline['source_commit'],
                'binary_sha256':baseline['binary']['sha256'],'input_sha256':ec['arena']['sha256'],
                'export_certificate_sha256':pin(export/'EXPORT_CERTIFICATE.json')['sha256'],'argv':command,
                'exit_code':process['exit_code'],'native_solver_called':process['process_started'],
                'stdout':output_pin(native/'stdout.txt'),'stderr':output_pin(native/'stderr.txt'),
                'controller_export':output_pin(native/'controller.json') if (native/'controller.json').is_file() else None,
                'phase':phase,'process_receipt':pin(native/'PROCESS_RECEIPT.json'),'scientific_source_count_increment':0 if phase=='qualification' else 1}
        save(native/'result.json',result)
        value.update(outcome=status,native_status=status,native_result=pin(native/'result.json'),process_receipt=pin(native/'PROCESS_RECEIPT.json'),
                     native_elapsed_seconds=process['elapsed_seconds'],native_peak_rss_bytes=process['wait4_peak_rss_bytes'],
                     resource_reasons=process['resource_reasons'])
        save(arm/'NATIVE_CAPTURE.json',value)
        require(self.audit(arm/'PINS_AFTER_NATIVE.json'),'Pins after native')
        self.archive_outputs(native)
        if status.startswith('COMPLETE_') and not self.stop:
            certpath=arm/'certificate.json';command=[sys.executable,'-B',str(B/'stage.py'),'check','--fixture-id',ident,
                     '--export-dir',str(export),'--native-dir',str(native),'--certificate',str(certpath)]
            checked=run_bounded(command,arm/'checker',DEADLINE,wall_seconds=STAGE_WALL,file_bytes=64*1024*1024,watch_files=[certpath])
            value['checker_process_receipt']=pin(arm/'checker/PROCESS_RECEIPT.json')
            if checked['status']=='PROCESS_COMPLETED' and checked['exit_code']==0 and certpath.is_file():
                cert=read(certpath)
                require(cert.get('fixture_id')==ident,'Checker fixture identity')
                require(cert.get('effective_graph_limits')=={'states':4096,'edges':65536,'legal_input_checks':4000000},'Effective graph cap identity')
                outcome,gate,fatal=classify_certificate(cert)
                value.update(outcome=outcome,qualification_gate_pass=gate,certificate=pin(certpath),certificate_status=cert['status'],
                     strict_controller_pass=cert.get('strict_controller_pass'),nonconflicting_pass=cert.get('nonconflicting_pass'),
                     kind_controller_pass=cert.get('kind_controller_pass'),controller_defects=cert.get('controller_defects'))
                if fatal:self.fail('CHECKER_INTEGRITY')
            else:
                value['outcome']='UNKNOWN_CHECKER_RESOURCE' if checked['status']=='UNKNOWN_RESOURCE' else 'UNKNOWN_CHECKER_INTEGRITY'
                if value['outcome']=='UNKNOWN_CHECKER_INTEGRITY':self.fail(value['outcome'])
        require(self.audit(arm/'PINS_AFTER.json'),'Pins after checker')
        save(arm/'OUTCOME.json',value);self.archive_outputs(arm)
        with (B/'ACTIVITY.jsonl').open('a') as f:f.write(json.dumps(value,ensure_ascii=False)+'\n')
        print(json.dumps({k:value.get(k) for k in ['id','phase','outcome','native_called','kind_controller_pass']}),flush=True)
        return value
    def execute(self):
        self.wait_and_select()
        if self.stop:return
        self.export_all()
        lookup={r['id']:r for r in self.eligible}
        for ident in QUAL_IDS:self.qual.append(self.attempt(lookup[ident],'qualification'))
        passed=len(self.qual)==3 and all(r['qualification_gate_pass'] for r in self.qual) and not self.stop
        save(B/'QUALIFICATION.json',{'status':'PASS' if passed else 'FAIL_INTEGRATION','rows':self.qual,
             'native_calls':call_counts(self.qual),'scientific_sources_added':0,
             'gate':'Capture, source/model mapping, native receipt and structural graph integrity only. Strict/nonconflicting booleans and native polarity are not expected values.'})
        self.add([pin(B/'QUALIFICATION.json')])
        if not passed:self.fail('QUALIFICATION_INTEGRATION_FAILED')
        self.stage='MAIN_COHORT'
        for row in self.eligible:self.rows.append(self.attempt(row,'main'))
        self.stage='COMPLETE'
    def finish(self):
        # Every selected source remains represented even after a fatal exception.
        known={r['id'] for r in self.rows}
        self.rows += [value for (phase,ident),value in self.attempts.items() if phase=='main' and ident not in known]
        known={r['id'] for r in self.rows}
        qual_known={r['id'] for r in self.qual}
        self.qual += [value for (phase,ident),value in self.attempts.items() if phase=='qualification' and ident not in qual_known]
        qual_known={r['id'] for r in self.qual}
        self.qual += [{'id':ident,'phase':'qualification','outcome':'UNKNOWN_NOT_ATTEMPTED','native_called':False,
                       'qualification_gate_pass':False,'reason':'GLOBAL_STOP_OR_RUNNER_FAILURE'} for ident in QUAL_IDS if ident not in qual_known]
        for value in self.rows+self.qual:
            if value.get('outcome')=='UNKNOWN_NOT_ATTEMPTED' and value.get('native_called') is not False:
                value.update(outcome='UNKNOWN_RUNNER_FAILURE',reason='Native call started or uncertain before runner interruption')
        self.rows += [{'id':r['id'],'phase':'main','outcome':'UNKNOWN_NOT_ATTEMPTED','native_called':False,
                       'reason':'GLOBAL_STOP_OR_RUNNER_FAILURE'} for r in self.eligible if r['id'] not in known]
        errors=pin_errors(self.files);self.errors.extend(errors)
        if errors:self.fail('FINAL_PIN_INTEGRITY')
        receipt={'schema':'slugs-small-recovery-contained-v2-run','finished_utc':now(),'elapsed_seconds':time.monotonic()-self.started,
                 'global_stop':self.stop,'stop_reasons':self.reasons,'pin_errors':self.errors,'stage':self.stage,
                 'parent_aborted':True,'parent_global_stop':True,
                 'preserved_parent_receipt':read(B/'BASELINE_SOURCE.json')['original_parent_phase1_stop_receipt'],
                 'scientific_source_denominator':425,'eligible_count':len(self.eligible) if (B/'SELECTION.json').exists() else None,'rows':self.rows,'qualification_rows':self.qual,
                 'qualification_native_calls':call_counts(self.qual),'main_native_calls':call_counts(self.rows),
                 'attempt_retries':0,'workers':1,'deadline_utc':DEADLINE,'full_reset_uses':0,'live_cluster_operations':0,
                 'unknown_is_negative':False,'wall_times_support_speed_comparison':False,'files_checked':len(self.files)}
        save(B/'RUN_RECEIPT.json',receipt)
        save(B/'RESULT_FILES.json',{'files':[pin(p) for p in sorted(B.rglob('*')) if p.is_file() and p.name not in ['RESULT_FILES.json'] and '__pycache__' not in p.parts and not p.name.endswith('.tmp')]})
        return receipt

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true');ap.add_argument('--preflight',action='store_true');a=ap.parse_args()
    require(a.run!=a.preflight,'Choose --preflight or root-dispatched --run')
    package=read(B/'PRODUCTION_SOURCE_FREEZE.json');require(not pin_errors(package['files']),'Production source freeze changed')
    require(pin(Path(sys.executable).resolve())==package['python'],'Frozen Python runtime differs')
    if a.preflight:
        print(json.dumps({'status':'PASS_SOURCE_FREEZE','native_calls':0,'small_native_receipt_present':(SMALL/'RUN_RECEIPT.json').exists(),'deadline_utc':DEADLINE}));return
    require(not (B/'RUN_STARTED.json').exists() and not (B/'RUN_RECEIPT.json').exists(),'No duplicate or resumed run; retries are zero')
    # Exclusive creation is an atomic single-launch guard.
    with (B/'RUN_STARTED.json').open('x') as f:json.dump({'started_utc':now(),'owner_pid':os.getpid(),'source_freeze':pin(B/'PRODUCTION_SOURCE_FREEZE.json')},f)
    runner=Runner(package)
    try:runner.execute()
    except BaseException as exc:runner.fail('RUNNER_EXCEPTION:'+repr(exc));save(B/'RUNNER_FAILURE.json',{'utc':now(),'stage':runner.stage,'error':repr(exc)})
    result=runner.finish();print(json.dumps({k:result[k] for k in ['eligible_count','qualification_native_calls','main_native_calls','global_stop','stop_reasons']}),flush=True)
if __name__=='__main__':main()
