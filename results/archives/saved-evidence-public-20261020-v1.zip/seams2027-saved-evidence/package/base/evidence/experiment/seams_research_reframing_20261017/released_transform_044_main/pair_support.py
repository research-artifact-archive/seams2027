"""Exact supplemental/export functions from the frozen helper quadrant stage."""
import gzip,json
from evidence import require
from map_pair import ResourceRefusal
from relations import count,digest,decode

def supplemental(pair,roots):
    b=pair['common'];fields=pair['original_fields'];variables=tuple(pair['original_current_bits'])+((pair['helper_current_bit'],) if pair['helper_added'] else ())
    def detail(label,u):
        roots[label]=u;witness=None
        if u:
            bits=b.satone(u,variables);require(b.evaluate(u,bits),'Full current-domain witness')
            witness={'current':decode(fields,bits,'current'),'bits':bits,'helper_current':bits[pair['helper_current_bit']] if pair['helper_added'] else None}
        return {'count':count(b,u,variables),'canonical_sha256':digest(b,u),'typed_witness':witness}
    initial={}
    for k,v in pair['initial_full_domain'].items():initial[k]={'equal_full_typed_current_domain':v['equal_full_typed_current_domain'],'difference':detail('initial_'+k,v['difference_root'])}
    justice={}
    for owner,v in pair['justice_full_domain'].items():
        justice[owner]={k:x for k,x in v.items() if k!='difference_roots'}
        justice[owner]['differences']=[detail('justice_'+owner+'_'+str(i),u) for i,u in enumerate(v['difference_roots'])]
    return {'initial':initial,'justice':justice,'all_equal':all(v['equal_full_typed_current_domain'] for v in initial.values()) and all(v['equal_identity_and_order_full_typed_current_domain'] for v in justice.values()),'interpretation':'Full typed current domain includes both helper values. Original justice order is retained after removing the unique helper GF not-b entry; insertion position is recorded, not assumed.'}

def export(path,pair,roots):
    b=pair['common'];seen=set();todo=list(roots.values())
    while todo:
        u=todo.pop()
        if u<2 or u in seen:continue
        seen.add(u);todo.extend(b.nodes[u][1:])
    value={'schema':'helper-quadrant-canonical-functions-v1','variable_count':b.n,'canonical_variable_order':list(range(b.n)),
        'original_fields':pair['original_fields'],'original_current_bits':pair['original_current_bits'],'original_next_bits':pair['original_next_bits'],
        'helper_current_bit':pair['helper_current_bit'],'helper_next_bit':pair['helper_next_bit'],'roots':roots,'nodes':[[u,*b.nodes[u]] for u in sorted(seen)]}
    raw=json.dumps(value,ensure_ascii=False,separators=(',',':')).encode()
    if len(raw)>64*1024*1024:raise ResourceRefusal('Canonical function export uncompressed cap64MiB')
    with gzip.GzipFile(filename=str(path),mode='wb',mtime=0) as f:f.write(raw)
