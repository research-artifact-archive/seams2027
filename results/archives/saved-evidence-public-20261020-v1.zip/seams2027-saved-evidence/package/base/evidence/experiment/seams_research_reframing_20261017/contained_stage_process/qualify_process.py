"""Explicit root-authorized tiny owned Python qualification; no scientific run."""
from datetime import datetime,timezone,timedelta
from pathlib import Path
import json,os,sys
sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
import bounded_process as b

def require(value,why):
    if not value:raise AssertionError(why)
def run():
    root=BASE/'process_qualification'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');root.mkdir(parents=True)
    before=[b.pin(BASE/'bounded_process.py'),b.pin(BASE/'qualify_process.py'),b.pin(b.RECOVERY/'owned_process.py')]
    cases=[
      ('normal_complete',"import sys; sys.stdout.write('owned stdout\\n'); sys.stderr.write('owned stderr\\n')",{},'PROCESS_COMPLETED'),
      ('nonzero_exit',"import sys; sys.stderr.write('controlled nonzero\\n'); sys.exit(7)",{},'PROCESS_COMPLETED'),
      ('wall_cap','import time; time.sleep(5)',{'wall_seconds':.25},'UNKNOWN_RESOURCE'),
      ('stdout_cap',"import sys,time; sys.stdout.buffer.write(b'x'*65536); sys.stdout.flush(); time.sleep(5)",{'stream_bytes':4096},'UNKNOWN_RESOURCE'),
      ('stderr_cap',"import sys,time; sys.stderr.buffer.write(b'e'*65536); sys.stderr.flush(); time.sleep(5)",{'stream_bytes':4096},'UNKNOWN_RESOURCE'),
      ('file_cap_fast_exit',"from pathlib import Path; Path('output.dat').write_bytes(b'x'*131072)",{'file_bytes':65536},'UNKNOWN_RESOURCE'),
      ('file_exact_cap_fast_exit',"from pathlib import Path; Path('output.dat').write_bytes(b'x'*65536)",{'file_bytes':65536},'UNKNOWN_RESOURCE'),
    ]
    rows=[]
    for name,code,caps,expected in cases:
        folder=root/name;folder.mkdir();script=folder/'SYNTHETIC_INPUT.py';script.write_text(code+'\n');arm=folder/'arm'
        limits={'wall_seconds':2,'stream_bytes':65536,'file_bytes':1048576,'rss_bytes':256*1024*1024,**caps}
        result=None
        try:
            result=b.run_bounded([sys.executable,'-c',code],arm,(datetime.now(timezone.utc)+timedelta(minutes=10)).isoformat(),watch_files=[arm/'output.dat'],**limits)
            require(result['status']==expected,'Unexpected status '+str(result['status'])+' '+str(result['fatal_reasons']))
            require(result['process_started'] and result['owned_child_reaped'] and result['exact_child_wait4']['exact_child_reaped'],'Exact child not reaped')
            require(not result['exact_child_wait4']['authority_lost'],'Exact-child authority lost')
            require(result['final_group_observation']['state']=='ABSENT' and result['final_group_observation']['basis']=='SUCCESSFUL_BOUNDED_PROCESS_TABLE','Successful final absence missing')
            require(not result['fatal_reasons'],'Unexpected integrity failure')
            require(result['wait4_peak_rss_bytes'] is not None,'Direct child RSS missing')
            for stream in ('stdout','stderr'):
                pin=b.output_pin(arm/(stream+'.txt'))
                require(all(result['capture'][stream][k]==v for k,v in pin.items()),'Output pin mismatch')
            if name=='normal_complete':
                require((arm/'stdout.txt').read_bytes()==b'owned stdout\n' and (arm/'stderr.txt').read_bytes()==b'owned stderr\n','Complete output changed')
                require(all(c['complete'] for c in result['capture'].values()),'Normal capture incomplete')
            if name=='nonzero_exit':require(result['exit_code']==7,'Nonzero exit changed')
            if name in ('stdout_cap','stderr_cap'):
                stream=name.split('_')[0]
                require(result['capture'][stream]['complete'] is False and result['capture'][stream]['captured_bytes']==4096,'Capped prefix mislabeled')
            if name in ('wall_cap','stdout_cap','stderr_cap'):
                require(any(e.get('sent') for e in result['termination_signals']),'Owned cap cleanup not exercised')
            if name.startswith('file_'):
                require((arm/'output.dat').stat().st_size==65536,'Expected OS file cap differs')
                require(any('OUTPUT_FILE_CAP_FINAL' in x for x in result['resource_reasons']),'Fast final file cap not detected')
            if expected=='UNKNOWN_RESOURCE':require(result['resource_reasons'],'Resource cause absent')
            rows.append({'name':name,'pass':True,'status':result['status'],'process_receipt':b.pin(arm/'PROCESS_RECEIPT.json'),'input_pin':b.pin(script),
                         'provided_synthetic_child_called':True,'actual_native_calls':0,'actual_JVM_calls':0,'elapsed_seconds':result['elapsed_seconds'],'limits':limits})
        except Exception as error:
            rows.append({'name':name,'pass':False,'error':repr(error),'process_receipt':b.pin(arm/'PROCESS_RECEIPT.json') if (arm/'PROCESS_RECEIPT.json').exists() else None})
            break
    drift=[ref for ref in before if b.pin(ref['path'])!=ref]
    report={'schema':'contained-stage-real-python-qualification-v1','status':'PASS' if len(rows)==len(cases) and all(r['pass'] for r in rows) and not drift else 'FAIL',
       'created_utc':b.now(),'passed':sum(r['pass'] for r in rows),'total_planned':len(cases),'rows':rows,'source_pins':before,'source_pin_errors_after':drift,
       'actual_native_calls':0,'actual_JVM_calls':0,'full_reset_uses':0,
       'authorization':'Root explicitly requested normal/nonzero/wall/stdout/file caps with tiny Python children before stage supervisor freeze.',
       'scope':'Seven owned synthetic Python children plus bounded process-table helpers; EPERM/ECHILD remain mock-only.'}
    b.save(BASE/'PROCESS_QUALIFICATION.json',report)
    print(json.dumps({'status':report['status'],'passed':report['passed'],'total_planned':len(cases),'failures':[r for r in rows if not r['pass']],'actual_native_calls':0,'actual_JVM_calls':0},indent=2),flush=True)
    return 0 if report['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(run())
