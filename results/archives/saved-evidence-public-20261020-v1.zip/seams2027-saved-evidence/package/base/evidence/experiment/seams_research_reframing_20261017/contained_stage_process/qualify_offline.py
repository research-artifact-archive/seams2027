"""Offline whole-supervisor negative controls. No actual child is permitted."""
from contextlib import ExitStack
from datetime import datetime,timezone,timedelta
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import errno,json,os,signal,sys,tempfile
sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
import bounded_process as b

class FD:
    def __init__(self,n):self.n=n;self.closed=False
    def fileno(self):return self.n
    def close(self):self.closed=True
class Selector:
    def __init__(self):self.map={}
    def register(self,fd,event,data):self.map[fd.fileno()]=SimpleNamespace(fileobj=fd,data=data)
    def unregister(self,fd):return self.map.pop(fd.fileno())
    def get_map(self):return self.map
    def select(self,timeout):return [(v,1) for v in list(self.map.values())]
    def close(self):pass
class Clock:
    def __init__(self):self.t=0
    def tick(self):self.t+=.03;return self.t

def require(value,why):
    if not value:raise AssertionError(why)
def run_case(root,name,**config):
    raw=SimpleNamespace(pid=64000,stdout=FD(17001),stderr=FD(17002),returncode=None)
    counter={'wait':0,'spawn':0,'table':0};signals=[];clock=Clock()
    chunks={17001:list(config.get('stdout',[b''])),17002:list(config.get('stderr',[b'']))}
    usage=SimpleNamespace(ru_maxrss=config.get('maxrss',2048),ru_utime=.02,ru_stime=.01)
    def spawn(*args,**kwargs):counter['spawn']+=1;return raw
    def wait4(pid,flags):
        require(pid==raw.pid,'Unexpected exact wait target');counter['wait']+=1
        if config.get('wait_error'):raise OSError(config['wait_error'],'controlled exact wait failure')
        if config.get('wrong_wait_pid'):return raw.pid+1,0,usage
        if config.get('never_reap'):return 0,0,None
        ready=counter['wait']>=config.get('reap_after',1) or bool(signals) and not config.get('signal_permission')
        if ready:return raw.pid,config.get('exit',0)<<8,usage
        return 0,0,None
    def killpg(pid,sig):
        require(pid==raw.pid,'Unexpected group target');require(raw.returncode is None,'Signal after reap')
        signals.append((pid,int(sig)))
        if config.get('signal_permission'):raise PermissionError(errno.EPERM,'controlled signal refusal')
    def read(fd,size):
        if config.get('pipe_holder'):raise BlockingIOError()
        return chunks[fd].pop(0) if chunks[fd] else b''
    def table(fields):
        counter['table']+=1
        if config.get('ps_failure') or config.get('final_ps_failure') and raw.returncode is not None:
            return {'status':'UNKNOWN','returncode':None,'stdout':'','stderr':'','reason':'CONTROLLED_HELPER_FAILURE'}
        rows=[] if config.get('missing_observer') else [f'{os.getpid()} 1 1 {os.getuid()} 1024']
        if raw.returncode is None or config.get('reused_group'):
            uid=os.getuid()+1 if config.get('wrong_uid') else os.getuid()
            ppid=os.getpid()+1 if config.get('wrong_ppid') else os.getpid()
            rows.append(f'{raw.pid} {ppid} {raw.pid} {uid} {config.get("rss_kib",1024)}')
        if config.get('descendant'):rows.append(f'{raw.pid+1} {raw.pid} {raw.pid} {os.getuid()} 100')
        if config.get('malformed_ps'):rows.append('broken table')
        if config.get('duplicate_ps'):rows.append(rows[0])
        return {'status':'COMPLETE','returncode':0,'stdout':'\n'.join(rows)+'\n','stderr':'','exact_helper_wait4':{'exact_child_reaped':True}}
    folder=root/name;deadline=(datetime.now(timezone.utc)+timedelta(minutes=10)).isoformat()
    if config.get('past_deadline'):deadline=(datetime.now(timezone.utc)-timedelta(seconds=1)).isoformat()
    kwargs={'wall_seconds':20,'stream_bytes':4096,'file_bytes':65536,'rss_bytes':1024*1024*1024,**config.get('caps',{})}
    pin_orig=b.pin;pin_count={}
    def mock_pin(path):
        ref=pin_orig(path);key=str(Path(path).resolve());pin_count[key]=pin_count.get(key,0)+1
        if config.get('source_drift') and key==str(BASE/'bounded_process.py') and pin_count[key]>1:ref['sha256']='0'*64
        return ref
    with ExitStack() as stack:
        stack.enter_context(patch.object(b.subprocess,'Popen',side_effect=spawn))
        stack.enter_context(patch.object(b.os,'wait4',side_effect=wait4))
        stack.enter_context(patch.object(b.os,'killpg',side_effect=killpg))
        stack.enter_context(patch.object(b.os,'getpgid',return_value=raw.pid))
        stack.enter_context(patch.object(b.os,'set_blocking'))
        stack.enter_context(patch.object(b.os,'read',side_effect=read))
        stack.enter_context(patch.object(b.selectors,'DefaultSelector',Selector))
        stack.enter_context(patch.object(b,'bounded_ps',side_effect=table))
        stack.enter_context(patch.object(b.time,'monotonic',side_effect=clock.tick))
        stack.enter_context(patch.object(b.time,'sleep'))
        stack.enter_context(patch.object(b.signal,'getsignal',return_value=signal.SIG_IGN if config.get('ignored_sigchld') else signal.SIG_DFL))
        stack.enter_context(patch.object(b,'pin',side_effect=mock_pin))
        result=b.run_bounded(['SYNTHETIC_MOCK_ONLY'],folder,deadline,**kwargs)
    if config.get('expected') is not None:require(result['status']==config['expected'],str(result))
    if config.get('no_signal'):require(not signals,'Signal forbidden by case but sent')
    if config.get('wait_error') or config.get('wrong_wait_pid'):
        require(result['exit_code'] is None and result['exact_child_wait4']['authority_lost'],'Authority loss fabricated exit')
    if config.get('ignored_sigchld') or config.get('past_deadline'):require(counter['spawn']==0,'Unexpected spawn')
    if config.get('reused_group'):require(result['final_group_observation']['state']=='PRESENT','Reused group was ignored')
    if config.get('pipe_holder'):require(any('INCOMPLETE_PIPE_DRAIN' in x for x in result['fatal_reasons']),'Holder drain was not bounded')
    if config.get('source_drift'):require(any('SOURCE_PIN_CHANGED' in x for x in result['fatal_reasons']),'Source drift not rejected')
    if config.get('expected')=='PROCESS_COMPLETED':
        require(result['exit_code']==config.get('exit',0),'Exact nonzero exit changed')
        require(result['exact_child_wait4']['exact_child_reaped'],'Missing exact wait')
        require(result['final_group_observation']['state']=='ABSENT','Missing positive absence')
    if config.get('stdout') and sum(map(len,config['stdout']))>kwargs['stream_bytes']:
        require(result['capture']['stdout']['captured_bytes']==kwargs['stream_bytes'] and result['capture']['stdout']['complete'] is False,'Prefix labeled complete')
    return {'name':name,'pass':True,'status':result['status'],'mock_spawn_count':counter['spawn'],'mock_signals':signals,'receipt':b.pin(folder/'PROCESS_RECEIPT.json')}

def run():
    root=BASE/'offline_qualification'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');root.mkdir(parents=True)
    source=[b.pin(BASE/'bounded_process.py'),b.pin(BASE/'qualify_offline.py'),b.pin(b.RECOVERY/'owned_process.py')]
    F='FATAL_SUPERVISOR_INTEGRITY';U='UNKNOWN_RESOURCE';P='PROCESS_COMPLETED'
    cases=[
      ('normal',dict(expected=P,no_signal=True)),('nonzero_7',dict(expected=P,exit=7,no_signal=True)),
      ('echild_no_signal',dict(expected=F,wait_error=errno.ECHILD,no_signal=True)),
      ('eperm_wait_no_signal',dict(expected=F,wait_error=errno.EPERM,no_signal=True)),
      ('wrong_wait_pid',dict(expected=F,wrong_wait_pid=True,no_signal=True)),
      ('sigchld_ignored_no_spawn',dict(expected=F,ignored_sigchld=True,no_signal=True)),
      ('expired_deadline_no_spawn',dict(expected=U,past_deadline=True,no_signal=True)),
      ('ps_helper_failure',dict(expected=F,ps_failure=True,reap_after=20)),
      ('final_ps_failure',dict(expected=F,final_ps_failure=True,no_signal=True)),
      ('malformed_ps',dict(expected=F,malformed_ps=True)),
      ('duplicate_ps',dict(expected=F,duplicate_ps=True)),
      ('missing_ps_observer',dict(expected=F,missing_observer=True)),
      ('wrong_live_ppid',dict(expected=F,wrong_ppid=True)),
      ('wrong_live_uid',dict(expected=F,wrong_uid=True)),
      ('unexpected_descendant',dict(expected=F,descendant=True)),
      ('reaped_pid_reused_no_signal',dict(expected=F,reused_group=True,no_signal=True)),
      ('pipe_holder_after_reap_no_signal',dict(expected=F,pipe_holder=True,no_signal=True)),
      ('stdout_prefix_fast_exit',dict(expected=U,stdout=[b'x'*8192,b''],no_signal=True)),
      ('stderr_prefix_fast_exit',dict(expected=U,stderr=[b'e'*8192,b''],no_signal=True)),
      ('rss_sample_cap',dict(expected=U,rss_kib=2097152,reap_after=20)),
      ('rss_final_wait4_cap',dict(expected=U,maxrss=2*1024*1024*1024,no_signal=True)),
      ('wall_time_owned_cleanup',dict(expected=U,reap_after=1000,caps={'wall_seconds':.2})),
      ('eperm_signal_unknown_no_false_absence',dict(expected=F,never_reap=True,signal_permission=True,caps={'wall_seconds':.2})),
      ('source_pin_changed',dict(expected=F,source_drift=True,no_signal=True)),
    ]
    rows=[]
    with ExitStack() as stack:
        # Per-case mocks replace these prohibitions; anything outside the fixture fails.
        for target,name in [(b.subprocess,'Popen'),(b.os,'wait4'),(b.os,'killpg'),(b.os,'kill')]:
            stack.enter_context(patch.object(target,name,side_effect=AssertionError('Actual process operation forbidden in offline qualification')))
        for name,config in cases:
            try:rows.append(run_case(root,name,**config))
            except Exception as error:rows.append({'name':name,'pass':False,'error':repr(error)})
    drift=[ref for ref in source if b.pin(ref['path'])!=ref]
    report={'schema':'contained-stage-offline-qualification-v1','status':'PASS' if all(r['pass'] for r in rows) and not drift else 'FAIL',
      'created_utc':b.now(),'passed':sum(r['pass'] for r in rows),'total':len(cases),'rows':rows,'source_pins':source,'source_pin_errors_after':drift,
      'actual_child_processes':0,'actual_native_calls':0,'actual_JVM_calls':0,'actual_signals':0,'full_reset_uses':0,
      'limits':'Mock controls do not constitute real EPERM/ECHILD fault injection.'}
    b.save(BASE/'OFFLINE_QUALIFICATION.json',report)
    print(json.dumps({'status':report['status'],'passed':report['passed'],'total':len(cases),'failures':[r for r in rows if not r['pass']]},indent=2))
    return 0 if report['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(run())
