"""Use the frozen exact-arena joiner against a new, separately scoped arm."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;E=B.parent
spec=importlib.util.spec_from_file_location('frozen_model_join',E/'corpus_comparison/model_join.py')
j=importlib.util.module_from_spec(spec);spec.loader.exec_module(j)

def main():
    ident,pipeline,raw=sys.argv[1:];second=Path(raw).resolve()
    j.require(second.is_relative_to(B) and second.name==pipeline and second.parent.name==ident,'Exact owned arm')
    j.require(pipeline in ('v_restricted_strict','normalized_kind'),'Known comparison arm')
    first=E/'kind_corpus_rle/runs'/ident
    record={'id':ident,'pipeline':pipeline,'native_runs':0,'original_arena':j.original_model_join(first,second)}
    if record['original_arena']['status']=='EXACT_ORIGINAL_ARENA_MATCH':
        a,z=j.read(first/'result.json'),j.read(second/'result.json');region='WV' if pipeline=='v_restricted_strict' else 'K'
        if a.get('regions_complete') is True and region in a and 'final_region' in z:
            manager=j.sem.BDD(j.read(first/'model.json')['bdd_variable_count']);roots=[];refs=[]
            for folder,ref in [(first,a[region]),(second,z['final_region'])]:
                j.require(Path(ref['file']).name==ref['file'],'Region basename')
                p=j.pin(folder/ref['file']);j.require(p['bytes']==ref['bytes'] and p['sha256']==ref['sha256'],'Region pin')
                refs.append(p);roots.append(manager.read_native(Path(p['path']).read_bytes())[0])
            proofpath=E/'kind_corpus_symbolic_independent/runs/v2'/ident/'RESULT.json'
            processpath=proofpath.with_name('PROCESS_RESULT.json')
            proof=j.read(proofpath) if proofpath.exists() else {};process=j.read(processpath) if processpath.exists() else {}
            pp=j.pin(proofpath) if proofpath.exists() else None;xp=j.pin(processpath) if processpath.exists() else None
            checks=j.independent_binding_checks(j.pin(first/'model.json'),j.pin(first/'result.json'),proof,pp,process)
            record['region_comparison']={'phase1_region':region,'new_region':'final_region','exact_function_equal':roots[0]==roots[1],
                'phase1_independently_certified':all(checks.values()),'independent_authority_checks':checks,
                'independent_certificate':pp,'independent_process_receipt':xp,'region_pins':refs,
                'result_pins':[j.pin(first/'result.json'),j.pin(second/'result.json')]}
            j.require(all(j.pin(p['path'])==p for p in refs+[v for v in (pp,xp) if v]),'Joined evidence changed')
    record['status']=record['original_arena']['status']
    (second/'MODEL_JOIN.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'status':record['status'],'region_comparison':record.get('region_comparison',{})}))

if __name__=='__main__':main()
