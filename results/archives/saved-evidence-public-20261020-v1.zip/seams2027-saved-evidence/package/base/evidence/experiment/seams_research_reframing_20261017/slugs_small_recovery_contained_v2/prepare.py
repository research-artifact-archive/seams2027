"""Freeze the separate contained-process Slugs arm without scientific execution."""
from pathlib import Path
import json,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;sys.path.insert(0,str(B))
from bounded_process import pin,save,now
from run import unique_pins,pin_errors,require,validate_parent,DEADLINE,QUAL_IDS
def read(p):return json.loads(Path(p).read_text())
def main():
    target=B/'PRODUCTION_SOURCE_FREEZE.json'
    require(not target.exists() and not (B/'RUN_STARTED.json').exists(),'No frozen overwrite')
    baseline=read(B/'BASELINE_SOURCE.json');require(not pin_errors(baseline['files']),'Preserved ancestor changed')
    prior=B.parent/'slugs_small_recovery_contained';stage=B.parent/'contained_stage_process'
    for name in ('stage.py',):
        require((B/name).read_bytes()==(prior/name).read_bytes(),'Scientific exporter/checker stage must stay byte identical')
    parent=baseline['original_parent_phase1_stop_receipt'];require(pin(parent['path'])==parent,'Parent stop binding')
    validate_parent(read(parent['path']))
    integration=read(stage/'ROOT_INTEGRATION.json')
    require(not pin_errors(integration['source_pins']),'Contained supervisor source changed')
    sf=read(stage/'FROZEN.json');require(not pin_errors(sf['files']),'Contained supervisor freeze changed')
    q=read(B/'OFFLINE_QUALIFICATION.json');require(q['status']=='PASS' and q['slugs_binary_launches']==0 and q['bdd_computations']==0,'Offline gate')
    require(not pin_errors(q['source_pins']),'Qualified package source changed')
    files=read(prior/'PRODUCTION_SOURCE_FREEZE.json')['files']+baseline['files']+sf['files']+integration['source_pins']
    files += [pin(stage/n) for n in ('FROZEN.json','ROOT_INTEGRATION.json','OFFLINE_QUALIFICATION.json','PROCESS_QUALIFICATION.json')]
    files += [pin(B/n) for n in ('BASELINE_SOURCE.json','run.py','stage.py','bounded_process.py','prepare.py','qualify_runner.py','PROTOCOL_JA.txt','OFFLINE_QUALIFICATION.json')]
    python=pin(Path(sys.executable).resolve());files=unique_pins(files+[python,pin('/bin/ps')]);require(not pin_errors(files),'Package pin integrity')
    save(target,{'schema':'slugs-small-recovery-contained-v2-source-freeze','created_utc':now(),'files':files,'python':python,
        'deadline_utc':DEADLINE,'workers':1,'native_seconds':60,'qualification_order':QUAL_IDS,
        'native_calls_at_freeze':0,'bdd_computations_at_freeze':0,'parent_aborted':True,'parent_global_stop':True,
        'preserved_parent_receipt':parent,'preserved_recovery_source_freeze':pin(prior/'PRODUCTION_SOURCE_FREEZE.json'),
        'contained_supervisor_freeze':pin(stage/'FROZEN.json'),'graph_limits':{'states':4096,'edges':65536,'legal_input_checks':4000000},
        'old_source_or_manifest_modified':False,'root_review_status':'AWAITING_ROOT_REVIEW_AND_DISPATCH'})
    print(json.dumps({'status':'FROZEN_NATIVE_NOT_STARTED','files':len(files),'source_freeze':pin(target),'native_calls':0}))
if __name__=='__main__':main()
