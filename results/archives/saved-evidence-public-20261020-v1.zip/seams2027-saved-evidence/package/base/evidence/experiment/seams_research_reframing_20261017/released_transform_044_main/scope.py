"""Exact044 archive/import closure and trace generation scope, independent of032/093."""
from pathlib import Path
from copy import deepcopy
import re
from evidence import B,P,R,ID,CORPUS,RLE,JOB,probe,recovery,bridge,read,save,pin,verify,unique,require,now

def source_tokens(raw):
    tokens=re.findall(r'/\*.*?\*/|//[^\n]*|--[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[A-Za-z_]\w*|\S',raw,re.S)
    return [x for x in tokens if not x.startswith(('/*','//','--'))]

def scope_metadata(case):
    require(case['id']==ID,'Fixed044 identity')
    plan=read(CORPUS/'FROZEN.json');archive=next(r['path'] for r in plan['files'] if r['path'].endswith('/icse24_artifact.zip'))
    closure=probe.closure(case['public_roster_row'],archive)
    require(len(closure)==1 and closure[0]==case['source'] and Path(closure[0]['path']).name=='HumanoidLTL_460_Humanoid.spectra','Exact full044 standalone source closure')
    import_count=0
    for ref in closure:
        raw=Path(ref['path']).read_text(encoding='utf-8-sig')
        tokens=source_tokens(raw)
        require(not any(x.lower() in ('weight','weights','energy','energybound') for x in tokens),'044 entire source closure contains no weight/energy generation declarations')
        import_count+=sum(x=='import' for x in tokens)
        imports=[tokens[i+1] for i,x in enumerate(tokens) if x=='import']
        require(imports==[],'No literal044 imports in complete closure')
    require(import_count==0,'Zero044 imports and no transitive undisclosed source')
    oldmodel=read(Path(case['original_directory'])/'model.json');inventory=oldmodel['source_inventory']
    transformed=deepcopy(inventory)
    for owner in ('ENV','SYS','AUX'):transformed['native_behaviors'][owner]=[]
    # This is a metadata expectation fixture, not a new native export.
    expectation=bridge.compare(inventory,transformed,True)
    require(expectation['counts']=={'ENV':{'ALL_expected':1,'NONE_observed':0},'SYS':{'ALL_expected':11,'NONE_observed':0},'AUX':{'ALL_expected':4,'NONE_observed':0}},'Specific044 trace roster including two past-time AUX')
    require({f['name'] for f in oldmodel['fields'] if f['role']=='AUX'}=={'PREV_aux_0','PREV_aux_1'},'Retain both044 logical AUX fields')
    worker=read(RLE/'runs'/ID/'NATIVE_WORKER_RECEIPT.json');argv=worker['command']
    require(argv[-5:]==['CorpusProbeWithRle',ID,case['source']['path'],str(RLE/'runs'/ID/'result.json'),plan['origins']],'Old044 exact source/producer argv')
    require(argv[argv.index('-cp')+1].split(':')[:2]==[str(RLE/'classes'),str(CORPUS/'classes')],'Old044 wrapper classpath identity')
    producer=[pin(p) for p in (CORPUS/'src/PublicCorpusProbe.java',CORPUS/'classes/PublicCorpusProbe.class',
        RLE/'src/CorpusProbeWithRle.java',RLE/'classes/CorpusProbeWithRle.class',P/'src/ReleasedTransformOnly.java',P/'classes/ReleasedTransformOnly.class',JOB/'classes/ReleasedKindJobProducer.class')]
    prior={r['path']:r for r in read(P/'FROZEN.json')['files']}
    require(all(prior.get(r['path'])==r for r in producer),'All044 original/new producer source/classes previously frozen')
    jobfreeze=read(JOB/'EXECUTION_FREEZE.json');js=next(r for r in jobfreeze['files'] if r['path'].endswith('/src/ReleasedKindJobProducer.java'))
    require(pin(JOB/'src/ReleasedKindJobProducer.java')=={**js,'path':str((probe.ROOT/js['path']).resolve())},'Frozen serializer source')
    grammar=probe.ROOT/'experiment/seams_establishment_20261013/released_scientific_gate/Spectra.xtext'
    translator=recovery.SRC/'tau.smlab.syntech.spectragameinput/src/tau/smlab/syntech/spectragameinput/translator/Spectra2GameInputTranslator.java'
    require(pin(grammar)['sha256']=='1ba06e4920186fe1897f04751eea921decca96875d3336cae698ceac0a10ed23' and pin(translator)['sha256']=='632de27fed1cac68554e61496c9c23089994fcd3779b9cc7d02c5ac005dee093' and pin(recovery.ENERGY)['sha256']=='1e6618dc4f6bfb245598fcc1a92685b6d8144b39ef2c69d306d47147faab8010','Reviewed no-weight generation rationale sources')
    refs=unique(closure+case['input_pins']+producer+[pin(JOB/'src/ReleasedKindJobProducer.java'),pin(JOB/'EXECUTION_FREEZE.json')]+[pin(p) for p in (grammar,translator,recovery.GENERATOR,recovery.BEHAVIOR,recovery.ENERGY)])
    verify(refs)
    return {'schema':'main044-source-scope-v1','id':ID,'status':'PASS_SOURCE_METADATA_ONLY','created_utc':now(),
        'source_import_closure':closure,'archive_bytes_equal':True,'exact_total_import_count':0,'weight_energy_absence_checked_in_every_source':True,
        'comment_tokenization':'Block, // and -- comments removed while preserving literal strings',
        'no_weight_rationale':'Separately pinned grammar WeightDef requires weight; translator gathers WeightDef; generator empty list yields null; energy reduction returns for null. No new independent runtime parser equivalence claim.',
        'old_ALL_trace_expectation':expectation,'expectation_is_simulated_NONE_metadata_not_actual_new_export':True,
        'all_original_AUX_fields':['PREV_aux_0','PREV_aux_1'],'input_pins':refs,
        'old_configuration':{'TraceInfo':'ALL','groupVars':True,'generator_argument_count':5,'debugLog':False,'SCA_setter_called':True,'SCA_value':False,'TEST_MODE_setter_called':True,'TEST_MODE_value':False},
        'new_configuration':{'TraceInfo':'NONE','groupVars':False,'generator_argument_count':4,'debugLog_default':True,'SCA_setter_called':False,'TEST_MODE_setter_called':False},
        'same_generator_configuration_claim':False,'old_runtime_producer_self_hash_recorded':False,'corpus_BDD_computations':0,'new_native_JVM_calls':0}

def actual_inventory(old_model,new_model,actual_result,scope):
    require(scope['status']=='PASS_SOURCE_METADATA_ONLY' and scope['id']==ID,'Exact044 prepared source scope')
    verify(scope['input_pins'])
    require(actual_result['fixture_id']==ID and actual_result['mode']=='original' and actual_result['configuration']['TraceInfo']=='NONE' and actual_result['configuration']['groupVars'] is False,'Actual044 original native configuration')
    require(actual_result['probe_class_identity']['class_sha256']==pin(P/'classes/ReleasedTransformOnly.class')['sha256'],'Same frozen model-only Java class')
    oldresult=read(RLE/'runs'/ID/'result.json')
    require({x['class']:x['class_sha256'] for x in oldresult['class_identities']}=={x['class']:x['class_sha256'] for x in actual_result['class_identities']},'Exact old/new044 released runtime class digests')
    result=bridge.compare(old_model['source_inventory'],new_model['source_inventory'],True)
    require(result['counts']==scope['old_ALL_trace_expectation']['counts'],'Actual044 trace list difference matches prepared specific scope')
    return {**result,'source_scope':pin(B/'SOURCE_SCOPE.json'),'044_import_closure_and_AUX_audited':True}

if __name__=='__main__':
    require(not (B/'SOURCE_SCOPE.json').exists(),'No source-scope overwrite')
    case=read(P/'SELECTION.json')['cases'][ID];save(B/'SOURCE_SCOPE.json',scope_metadata(case));print('044 source/import/trace metadata scope prepared; no corpus BDD/native execution')
