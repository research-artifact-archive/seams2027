"""Admit one closed044 saved pair and exact original/literal authorities; metadata only."""
from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;E=B.parent;C=E/'helper_decomposition_public';H=E/'helper_quadrant_public';M=E/'released_transform_044_main'
S=E/'kind_corpus_symbolic_independent';CHECK=E/'released_kind_corpus_checker';STAGE=E/'contained_stage_process';P=E/'released_transform_probe_public';L=E/'preservation_loss_public'
ID='corpus044__original'
def load_module(name,path,evidence=None):
    prior=sys.modules.get('evidence')
    if evidence is not None:sys.modules['evidence']=evidence
    try:
        s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
    finally:
        if evidence is not None:
            if prior is None:sys.modules.pop('evidence',None)
            else:sys.modules['evidence']=prior
main_evidence=load_module('analysis044_main_evidence',M/'evidence.py')
read,save,pin,pins_in,unique,verify,require,now=(getattr(main_evidence,n) for n in ('read','save','pin','pins_in','unique','verify','require','now'))

def complete_process(ref,argv):
    verify([ref]);p=read(ref['path'])
    require(p['schema']=='contained-stage-process-v1' and p['status']=='PROCESS_COMPLETED' and type(p['exit_code']) is int and p['exit_code']==0 and p['process_started'] is True,'Completed saved-data checker process')
    require(p['owned_child_reaped'] is True and p['final_group_observation']['state']=='ABSENT' and p['argv'][1:]==argv[1:] and Path(p['argv'][0]).resolve()==Path(argv[0]).resolve() and pin(Path(p['argv'][0]).resolve())==pin(Path(argv[0]).resolve()),'Exact saved-data checker command/containment and frozen executable identity through symlink')
    return p

def closed_main():
    # First evidence read is the closed receipt; never inspect a live model pair.
    main=read(M/'RUN_RECEIPT.json')
    require(main['schema']=='fixed044-transform-main-run-v1' and main['status']=='PASS_044_MODEL_PAIR' and main['global_stop'] is False and not main['stop_reasons'],'Closed fixed044 model-only pair')
    require(main['native_JVM_calls']=={'confirmed':2,'uncertain':0,'not_called':0} and all(type(x) is int for x in main['native_JVM_calls'].values()),'Exactly two completed044 model JVMs')
    for name in ('solver_calls','controller_calls','full_reset_uses'):require(type(main[name]) is int and main[name]==0,'Closed main exact zero '+name)
    require(main['U_F_direct_analysis_authorized'] is False and main['old_global_stop_preserved'] is True and main['v1_resumed'] is False,'No inherited analysis authority or reopened stopped phase')
    require([r['id'] for r in main['rows']]==[ID] and main['rows'][0]['status']=='PASS','One fixed exploratory main case')
    decision=main_evidence.authorization();mf=read(M/'FROZEN.json');ms=read(M/'SELECTION.json');case=ms['case']
    require(main['freeze']==pin(M/'FROZEN.json') and main['root_authorization']==decision and main['joined_qualification']==ms['joined_qualification'],'Closed main exact freeze/decision/qualification')
    verify(mf['files']+main['output_pins']+[decision])
    done=main['rows'][0];require(done['check']==pin(M/'runs'/ID/'CHECK.json'),'Closed main check exact path');cert=read(done['check']['path'])
    require(cert['schema']=='fixed044-model-main-check-v1' and cert['id']==ID and cert['status']=='PASS' and cert['root_authorization']==decision,'Closed main checker identity')
    require(cert['original_model_canonical_bound_to_independent_proof'] is True and cert['original_independent_proof']==case['original_independent_proof'] and cert['authoritative_original_model']==case['authoritative_original_model'],'Exact original proof/model canonical equality')
    require(cert['comparisons']['original']['status']=='PASS' and cert['pair_structure']['status']=='PASS' and cert['pair_structure']['all_original_fields_and_AUX_retained'] is True,'Original canonical and full-field correspondence')
    require(cert['pair_structure']['original_carrier']==18816 and cert['pair_structure']['released_carrier']==37632 and cert['pair_structure']['original_AUX_fields']==['PREV_aux_0','PREV_aux_1'],'Fixed044 typed carrier/all AUX')
    require(cert['supplemental_full_current_checks']['all_equal'] is True and cert['U_F_direct_analysis_authorized'] is False,'Full original initial/ordered justice identity; fresh authority still required')
    require([x['quadrant'] for x in cert['all_quadrant_relations']['quadrants']]==['00','01','10','11'],'Four observed actual quadrants')
    proc=complete_process(done['check_process'],[mf['python']['path'],'-B',str(M/'check_pair.py')])
    refs=mf['files']+main['output_pins']+[pin(M/'FROZEN.json'),pin(M/'RUN_RECEIPT.json'),decision,done['check'],done['check_process']]+pins_in(cert)+pins_in(proc)
    for mode in ('original','released'):
        refs+=main_evidence.native_refs(M/'runs'/ID/mode,case,mode,decision,mf)
        require(cert['native_exports'][mode]['model']==pin(M/'runs'/ID/mode/'model.json'),'Certified native044 model pin '+mode)
    refs=unique(refs);verify(refs)
    return main,case,cert,done,ms,refs

def source_aware_pins(value,case):
    refs=[]
    for ref in pins_in(value):
        if not Path(ref['path']).is_absolute():
            require(ref=={**case['source'],'path':case['public_roster_row']['path']},'Only exact known archive-relative original source metadata may be resolved')
            ref=case['source']
        refs.append(ref)
    return refs

def select():
    main,case,cert,done,ms,refs=closed_main()
    cf=read(C/'FROZEN.json');cq=read(C/'MATH_QUALIFICATION.json')
    require(cq['status']=='PASS' and cq['corpus_BDD_computations']==cq['native_runs']==0,'Qualified generalized decomposition synthetic controls')
    for name in ('decomposition.py','import_original.py','measure.py','qualify_math.py','MATH_QUALIFICATION.json'):require(pin(C/name) in cf['files'],'Exact qualified decomposition source '+name)
    verify(cf['files']+cq['source_pins']);refs+=cf['files']+[pin(C/'FROZEN.json')]
    ls=read(L/'SELECTION.json');lf=read(L/'FROZEN.json');lr=read(L/'RUN_RECEIPT.json')
    require(lr['global_stop'] is False and not lr['stop_reasons'],'Prior complete-semantic literal loss study closed')
    ldref=pin(L/'ROOT_START_DECISION.json');ldec=read(ldref['path']);require(lr['root_authorization']==ldref and ldec['start_authorized'] is True and ldec['freeze']==pin(L/'FROZEN.json'),'Prior literal-loss root/freeze authority')
    for name in ('loss.py','measure.py','qualify.py','OFFLINE_QUALIFICATION.json'):require(pin(L/name) in lf['files'],'Exact qualified literal source '+name)
    lq=read(L/'OFFLINE_QUALIFICATION.json');require(lq['status']=='PASS','Prior literal-loss synthetic qualification');verify(lq['source_pins'])
    old=next(r for r in ls['rows'] if r['id']==ID);ld=next(r for r in lr['rows'] if r['id']==ID)
    require(old['eligible'] is True and ld['status']=='PASS','Exact fixed044 prior literal result available')
    require(ld['result']==pin(L/'runs'/ID/'RESULT.json'),'Prior literal044 exact result path')
    loss=read(ld['result']['path']);verify(old['input_pins']+[ld['result'],ld['process']]+pins_in(loss))
    require(loss['status']=='PASS' and loss['id']==ID and loss['root_authorization']==lr['root_authorization'],'Prior literal loss result identity/authority')
    require(loss['complete_semantic_literal_only'] is True and loss['original_independent_proof']==old['proof'] and loss['original_independent_process']==old['process'],'Literal-only result bound to original independent proof')
    require(old['proof']==case['original_independent_proof'] and old['model']==case['authoritative_original_model'],'Actual pair and literal-loss reference share exact original authority')
    proof=read(old['proof']['path']);iprocess=read(old['process']['path'])
    require(proof['status']=='PASS' and proof['id']==ID and proof['derived_region_export']==old['independent_regions'] and proof['comparisons']['W']['equal'] is True and proof['comparisons']['reachable']['equal'] is True,'Original W and existential reachable independently certified')
    require(iprocess['status']=='PASS' and iprocess['id']==ID and iprocess['process_exit_code']==0 and iprocess['hard_timeout'] is False and iprocess['child_result']==old['proof'],'Original independent worker completion')
    require(type(proof['counts']['K']) is int and proof['counts']['K']==0 and proof['initial_quantification']['K']['value'] is False,'Original K0 boundary')
    lp=complete_process(ld['process'],[lf['python']['path'],'-B',str(L/'measure.py'),ID])
    expected=lf['code_files']+old['input_pins']+[pin(L/'FROZEN.json'),pin(L/'SELECTION.json'),lr['root_authorization']]
    require(loss['input_pins']==expected,'Prior literal-loss exact input/code/decision pins')
    refs+=lf['files']+[pin(L/n) for n in ('FROZEN.json','SELECTION.json','RUN_RECEIPT.json')]+old['input_pins']+[ld['result'],ld['process']]+pins_in(lp)+pins_in(loss)+source_aware_pins(proof,case)
    refs=unique(refs);verify(refs)
    row={'id':ID,'eligible':True,'source':case['source'],'original_model':cert['native_exports']['original']['model'],'job_model':cert['native_exports']['released']['model'],
        'original_directory':str(M/'runs'/ID/'original'),'job_directory':str(M/'runs'/ID/'released'),
        'authoritative_original_model':case['authoritative_original_model'],'closed_main':pin(M/'RUN_RECEIPT.json'),'pair_check':done['check'],'pair_check_process':done['check_process'],
        'quadrant_functions':cert['canonical_functions'],'independent_W_certificate':old['proof'],'independent_W_process':old['process'],'independent_regions':old['independent_regions'],
        'prior_literal_loss_certificate':ld['result'],'prior_literal_loss_process':ld['process'],'prior_literal_loss_functions':loss['functions'],
        'original_K_count':0,'original_K_initial_verdict':False,'input_pins':refs}
    return {'schema':'fixed044-analysis-selection-v1','created_utc':now(),'source_denominator':425,'eligible_ids':[ID],'eligible_count':1,'row':row,
        'selection_rule':ms['selection_rule'],'selection_uses_prior_mathematical_outcome':True,'reselection_performed':False,
        'separate_from_fixed14_helper_cohort':True,'original_helper_cohort_size':14,'original_complete_helper_cohort_size':13,
        'input_pins':refs,'native_runs':0,'corpus_BDD_computations':0,'full_reset_uses':0,
        'kind_initializer_false_rejection_conclusion':None,'original_K_zero_is_scope_boundary':True}

def authorization():
    ref=pin(B/'ROOT_START_DECISION.json');d=read(ref['path']);s=read(B/'SELECTION.json')
    require(d.get('start_authorized') is True and d.get('scope')=='SAVED_044_DECOMPOSITION_ONLY' and d.get('freeze')==pin(B/'FROZEN.json'),'Separate exact fixed044 saved-analysis authorization')
    require(d.get('closed_model_pair')==s['row']['closed_main']==pin(M/'RUN_RECEIPT.json'),'Exact closed044 model-pair prerequisite')
    for name,value in (('saved_BDD_worker_budget',1),('native_JVM_budget',0),('native_solver_budget',0),('controller_budget',0)):
        require(type(d.get(name)) is int and d[name]==value,'Exact analysis budget '+name)
    verify([ref]);closed_main();return ref
