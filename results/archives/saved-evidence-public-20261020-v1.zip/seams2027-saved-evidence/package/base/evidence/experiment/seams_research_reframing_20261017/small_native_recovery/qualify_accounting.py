"""Pure offline check of interrupted-attempt accounting; launches no child."""
from pathlib import Path
import contextlib, importlib.util, io, json, sys, tempfile, time
sys.dont_write_bytecode = True
B=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('offline_small_accounting',B/'run.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
selected=m.read(B/'SELECTION.json')['eligible_ids']
with tempfile.TemporaryDirectory(prefix='small-recovery-accounting-') as tmp:
    m.B=Path(tmp)
    r=m.Runner.__new__(m.Runner)
    r.rows=[];r.qual=[];r.stop=True;r.reasons=['MOCK_INTERRUPTION'];r.pin_errors=[]
    r.stage='QUALIFICATION';r.start=time.monotonic();r.selected=selected;r.refs=[]
    r.attempts={}
    for phase,ident,pipeline,called in [
        ('qualification','corpus002__original','v_restricted_strict',True),
        ('qualification','corpus002__original','normalized_kind',None),
        ('runs',selected[0],'released_kind',True)]:
        r.attempts[(phase,ident,pipeline)]={'id':ident,'pipeline':pipeline,'phase':phase,
            'outcome':'UNKNOWN_NOT_ATTEMPTED','native_called':called}
    r.audit=lambda path:True
    with contextlib.redirect_stdout(io.StringIO()):r.finish()
    receipt=m.read(m.B/'RUN_RECEIPT.json')
    checks={
      'four_qualifications':len(receipt['qualification_rows'])==4,
      'all_42_main_cells':len(receipt['rows'])==42 and len({(v['id'],v['pipeline']) for v in receipt['rows']})==42,
      'qual_confirmed_and_unknown_retained':receipt['qualification_native_calls']=={'confirmed':1,'uncertain':1},
      'main_started_retained':receipt['main_native_calls']=={'confirmed':1,'uncertain':0},
      'no_started_case_marked_unattempted':all(v['outcome']!='UNKNOWN_NOT_ATTEMPTED'
         for v in receipt['rows']+receipt['qualification_rows'] if v.get('native_called') is not False)}
assert all(checks.values()),checks
m.save(B/'OFFLINE_ACCOUNTING_QUALIFICATION.json',{'status':'PASS','checks':checks,
    'run_source':m.pin(B/'run.py'),'qualification_source':m.pin(Path(__file__)),
    'mock_only':True,'real_native_calls':0,'real_child_processes':0,'full_reset_uses':0})
print(json.dumps({'status':'PASS','checks':checks,'native_calls':0}))
