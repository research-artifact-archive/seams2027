#!/usr/bin/env python3
"""One fresh Python worker / one native child; this module grants no release.

The parent must verify its exact frozen release and argv before invoking this
worker. This NEW copy requires explicit source pins and uses exact PID wait4.
Qualification mode permits only a Python synthetic child and smaller
limits. LosslessStdout is an unchanged copy of the previously qualified module.
"""
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import json
import math
import os
import resource
import signal
import stat
import subprocess
import sys
import time

from lossless_stdout import LosslessStdout
from owned_process import ExactChild, GroupObserver

BASE = Path(__file__).resolve().parent
CAPTURE_SHA256 = '90468954914cee1f713ebe43a1331de2a4a862d4d779996e0b55f146212de7eb'
DEFAULT_LIMITS = {
    'wall_seconds': 60,
    'raw_stdout_bytes': 256 * 1024 * 1024,
    'compressed_stdout_bytes': 16 * 1024 * 1024,
    'other_file_bytes': 16 * 1024 * 1024,
    'aggregate_arm_bytes': 128 * 1024 * 1024,
    'poll_seconds': 0.05,
    'term_seconds': 2,
    'kill_seconds': 3,
    'drain_seconds': 3,
}
_RUN_USED = False


class ReleaseExpired(ValueError):
    pass


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def pin(path):
    path = Path(path)
    return {'path': str(path.resolve()), 'bytes': path.stat().st_size,
            'sha256': sha256(path)}


def child_usage():
    value = resource.getrusage(resource.RUSAGE_CHILDREN)
    return {key: getattr(value, key) for key in dir(value) if key.startswith('ru_')}


def atomic_json(path, value):
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def validate_limits(limits, command):
    supplied = dict(limits or {})
    qualification = supplied.pop('qualification_only', False)
    if type(qualification) is not bool:
        raise ValueError('qualification_only must be boolean')
    if set(supplied) - set(DEFAULT_LIMITS):
        raise ValueError('unknown resource limit')
    effective = dict(DEFAULT_LIMITS)
    for key, value in supplied.items():
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
            raise ValueError('invalid resource limit: ' + key)
        if key.endswith('_bytes') and type(value) is not int:
            raise ValueError('byte limits must be integers')
        if value != DEFAULT_LIMITS[key]:
            if not qualification or key in {'poll_seconds', 'term_seconds', 'kill_seconds', 'drain_seconds'} or value > DEFAULT_LIMITS[key]:
                raise ValueError('only smaller qualification caps/wall are permitted')
        effective[key] = value
    if qualification:
        if len(command) != 3 or Path(command[0]).resolve() != Path(sys.executable).resolve() or command[1] != '-c':
            raise ValueError('qualification requires one synthetic Python -c child')
    elif Path(command[0]).name != 'java':
        raise ValueError('native mode requires provided JVM argv')
    return effective, qualification


def inspect_files(folder, limits):
    sizes, faults, reasons = {}, [], []
    for root, directories, files in os.walk(folder, followlinks=False):
        for name in directories + files:
            path = Path(root) / name
            try:
                info = path.lstat()
            except FileNotFoundError:
                continue  # Native checkpoint rename; inspect the next sample.
            relative = str(path.relative_to(folder))
            if stat.S_ISLNK(info.st_mode):
                faults.append('unexpected_symlink:' + relative)
            elif stat.S_ISREG(info.st_mode):
                sizes[relative] = info.st_size
                limit = limits['compressed_stdout_bytes'] if relative == 'stdout.txt.gz' else limits['other_file_bytes']
                if info.st_size > limit:
                    reasons.append(('compressed_stdout_cap' if relative == 'stdout.txt.gz' else 'other_file_cap:') + ('' if relative == 'stdout.txt.gz' else relative))
            elif not stat.S_ISDIR(info.st_mode):
                faults.append('unexpected_nonregular_artifact:' + relative)
    if sum(sizes.values()) > limits['aggregate_arm_bytes']:
        reasons.append('aggregate_arm_cap')
    return sizes, faults, reasons


def verify_source_pins(refs):
    if not isinstance(refs, list) or not refs:
        return [{'reason': 'NONEMPTY_EXPLICIT_SOURCE_PINS_REQUIRED'}]
    errors = []; seen = set()
    for ref in refs:
        try:
            if set(ref) != {'path', 'bytes', 'sha256'} or str(Path(ref['path']).resolve()) != ref['path']:
                raise ValueError('Invalid canonical source pin')
            if ref['path'] in seen:
                raise ValueError('Duplicate source pin')
            seen.add(ref['path'])
            if pin(ref['path']) != ref:
                errors.append({'path': ref['path'], 'reason': 'SOURCE_BYTES_CHANGED'})
        except Exception as error:
            errors.append({'path': ref.get('path') if isinstance(ref, dict) else None, 'reason': repr(error)})
    return errors


def run_native(command, arm_dir, deadline_utc, limits=None, source_pins=None):
    """Return a full process/capture receipt. Call once in a fresh worker only.

    PROCESS_COMPLETED means process/capture integrity only; it is not a native
    result, stderr, origin, graph, or scientific certificate. Those checks are
    mandatory in the releasing parent. All terminal receipts are retained.
    """
    global _RUN_USED
    folder = Path(arm_dir).resolve()
    receipt = {
        'schema': 'contained-native-worker-receipt-v1',
        'status': 'FATAL_INTEGRITY_FAILURE',
        'scope': 'PROCESS_AND_CAPTURE_ONLY_NOT_A_SCIENTIFIC_CERTIFICATE',
        'parent_aborted': True, 'study_scope': 'SEPARATE_RECOVERY_OLD_STOPS_UNCHANGED',
        'source_pins': source_pins, 'source_pin_errors_before': [], 'source_pin_errors_after': [],
        'native_execution_authorization': 'EXTERNAL_EXACT_FROZEN_RELEASE_REQUIRED',
        'worker_pid': os.getpid(), 'command': command, 'arm_dir': str(folder),
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'resource_reasons': [], 'fatal_reasons': [], 'termination_events': [],
        'worker_spawned_children': 0, 'child_reaped': False,
        'process_group_contained': False, 'stdout_capture': None,
        'returncode': None, 'artifacts': {},
        'qualification_only': False, 'scientific_JVM_executions': 0,
        'native_solver_calls': 0, 'actual_controller_extraction_calls': 0,
    }
    process = capture = error_stream = None
    started = time.monotonic()
    signals_started = False
    observer = GroupObserver()
    files_before_receipt = {}
    effective = dict(DEFAULT_LIMITS)

    def add_unique(key, values):
        receipt[key] = sorted(set(receipt[key]).union(values))

    def sample():
        nonlocal files_before_receipt
        files_before_receipt, faults, reasons = inspect_files(folder, effective)
        add_unique('fatal_reasons', faults)
        add_unique('resource_reasons', reasons)
        if capture:
            add_unique('resource_reasons', capture.cap_reasons)
            if capture.error:
                add_unique('fatal_reasons', ['stdout_capture_error:' + capture.error])

    def group_absent(final=False):
        observation = observer.observe(process, final=final)
        if observation.get('unexpected_members'):
            add_unique('fatal_reasons', ['unexpected_or_unowned_group_member'])
        if final:
            receipt['final_group_observation'] = observation
        return observation['state'] == 'ABSENT'

    def send_group(signum):
        event = process.signal_owned_group(signum)
        event['elapsed_seconds'] = time.monotonic() - started
        receipt['termination_events'].append(event)

    def wait_group(seconds):
        until = time.monotonic() + seconds
        while True:
            process.poll()  # Only exact wait4 can reap the native child.
            absent = group_absent()
            process.poll()
            if process.exact_reaped and absent:
                return True
            try:
                sample()
            except BaseException as exc:
                add_unique('fatal_reasons', ['termination_artifact_inspection_error:' + repr(exc)])
            if time.monotonic() >= until:
                return False
            time.sleep(min(effective['poll_seconds'], max(0, until - time.monotonic())))

    def stop_group():
        nonlocal signals_started
        if signals_started:
            return
        signals_started = True
        if process.poll() is None:
            send_group(signal.SIGTERM)
        if not wait_group(effective['term_seconds']):
            if process.poll() is None:
                send_group(signal.SIGKILL)
            if not wait_group(effective['kill_seconds']):
                add_unique('fatal_reasons', ['process_containment_unconfirmed_after_cleanup_bound'])
        if not process.exact_reaped:
            add_unique('fatal_reasons', ['direct_child_not_reaped_within_bound'])

    try:
        receipt['sigchld_disposition_before'] = int(signal.getsignal(signal.SIGCHLD)) if signal.getsignal(signal.SIGCHLD) in (signal.SIG_DFL, signal.SIG_IGN) else 'CUSTOM_HANDLER'
        if signal.getsignal(signal.SIGCHLD) != signal.SIG_DFL:
            raise ValueError('Exact wait4 requires default SIGCHLD disposition')
        receipt['source_pin_errors_before'] = verify_source_pins(source_pins)
        if receipt['source_pin_errors_before']:
            raise ValueError('Explicit source freeze failed before native spawn')
        receipt['worker_source_pins_before'] = [pin(BASE / name) for name in ('native_worker.py', 'owned_process.py', 'lossless_stdout.py')] + [pin('/bin/ps'), pin(Path(sys.executable).resolve())]
        baseline = child_usage()
        receipt['child_usage_before'] = baseline
        if _RUN_USED or any(value != 0 for value in baseline.values()):
            raise ValueError('worker is not fresh: prior child usage or prior invocation')
        _RUN_USED = True
        if not isinstance(command, list) or not command or any(not isinstance(arg, str) or '\0' in arg for arg in command):
            raise ValueError('command must be nonempty string argv')
        effective, qualification = validate_limits(limits, command)
        receipt['limits'] = effective
        receipt['qualification_only'] = qualification
        receipt['measurement_scope'] = 'EXACT_SYNTHETIC_CHILD_WAIT4_NO_NATIVE_SCIENCE' if qualification else 'EXACT_PROVIDED_JVM_PID_WAIT4_RUSAGE_ONLY'
        if not qualification:
            # The worker has no knowledge of solver/extractor calls inside Java.
            receipt['native_solver_calls'] = 'NOT_MEASURED_BY_WRAPPER'
            receipt['actual_controller_extraction_calls'] = 'NOT_MEASURED_BY_WRAPPER'
        expiry = datetime.fromisoformat(deadline_utc) if isinstance(deadline_utc, str) else deadline_utc
        if not isinstance(expiry, datetime) or expiry.tzinfo is None:
            raise ValueError('deadline must be timezone-aware UTC timestamp')
        receipt['deadline_utc'] = expiry.astimezone(timezone.utc).isoformat()
        remaining = (expiry - datetime.now(timezone.utc)).total_seconds()
        if remaining <= 0:
            add_unique('fatal_reasons', ['release_deadline_expired'])
            raise ReleaseExpired('release deadline already expired')
        deadline_monotonic = time.monotonic() + remaining
        if sha256(BASE / 'lossless_stdout.py') != CAPTURE_SHA256:
            raise ValueError('unchanged lossless capture source pin mismatch')
        receipt['capture_source'] = pin(BASE / 'lossless_stdout.py')
        folder.mkdir(parents=True, exist_ok=True)
        for name in ('stdout.txt.gz', 'stderr.txt', 'STDOUT_CAPTURE.json', 'NATIVE_WORKER_RECEIPT.json', 'NATIVE_CHILD_IDENTITY.json'):
            if (folder / name).exists():
                raise ValueError('refusing overwrite of prior worker artifact: ' + name)
        sample()
        if receipt['resource_reasons'] or receipt['fatal_reasons']:
            raise ValueError('arm failed initial artifact inspection')
        env = os.environ.copy()
        removed = {key: key in env for key in ('CLASSPATH', 'JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS')}
        for key in removed:
            env.pop(key, None)
        receipt['removed_environment_keys_present'] = removed
        error_stream = (folder / 'stderr.txt').open('xb', buffering=0)
        started = time.monotonic()
        receipt['started_utc'] = datetime.now(timezone.utc).isoformat()
        process = ExactChild(subprocess.Popen(command, cwd=folder, env=env, stdin=subprocess.DEVNULL,
                                   stdout=subprocess.PIPE, stderr=error_stream,
                                   start_new_session=True))
        receipt['worker_spawned_children'] = 1
        receipt['child_pid'] = process.pid
        receipt['process_group_id'] = process.pid
        receipt['scientific_JVM_executions'] = 0 if qualification else 1
        identity = {'schema': 'contained-native-child-identity-v1', 'worker_pid': os.getpid(),
                    'child_pid': process.pid, 'process_group_id': process.pid,
                    'command': list(command),
                    'command_sha256': hashlib.sha256(json.dumps(command, ensure_ascii=False, separators=(',', ':')).encode('utf-8')).hexdigest(),
                    'started_utc': receipt['started_utc'],
                    'qualification_only': qualification,
                    'purpose': 'EXTERNAL_WATCHDOG_CONTAINMENT_ONLY_ANY_USE_REQUIRES_GLOBAL_ABORT'}
        atomic_json(folder / 'NATIVE_CHILD_IDENTITY.json', identity)
        receipt['native_child_identity'] = pin(folder / 'NATIVE_CHILD_IDENTITY.json')
        capture = LosslessStdout(process.stdout, folder / 'stdout.txt.gz',
                                 raw_cap=effective['raw_stdout_bytes'],
                                 file_cap=effective['compressed_stdout_bytes'])
        capture.start()
        while True:
            sample()
            now = time.monotonic()
            if now >= deadline_monotonic:
                add_unique('fatal_reasons', ['release_deadline_expired'])
            if now - started >= effective['wall_seconds']:
                add_unique('resource_reasons', ['wall_time_cap'])
            rc = process.poll()
            if receipt['fatal_reasons'] or receipt['resource_reasons']:
                receipt['termination_trigger_elapsed_seconds'] = now - started
                stop_group()
                break
            if rc is not None:
                if not group_absent():
                    stop_group()
                break
            capture.alert.wait(effective['poll_seconds'])
    except ReleaseExpired:
        add_unique('fatal_reasons', ['release_deadline_expired'])
    except BaseException as exc:
        add_unique('fatal_reasons', ['worker_exception:' + repr(exc)])
    finally:
        if process:
            try:
                if process.poll() is None or not group_absent():
                    stop_group()
                process.poll()
            except BaseException as exc:
                add_unique('fatal_reasons', ['process_cleanup_error:' + repr(exc)])
            # Reap fields are always retained independently of group-observation
            # errors; neither Popen defaults nor EPERM can fabricate exit status.
            receipt['returncode'] = process.returncode
            receipt['child_reaped'] = process.exact_reaped
            receipt['exact_child_wait4'] = process.evidence()
            try:
                receipt['process_group_contained'] = process.exact_reaped and group_absent(final=True)
            except BaseException as exc:
                receipt['process_group_contained'] = False
                add_unique('fatal_reasons', ['final_group_observation_error:' + repr(exc)])
            if not receipt['child_reaped'] or not receipt['process_group_contained']:
                add_unique('fatal_reasons', ['process_containment_or_exact_reap_failed'])
        receipt['supervisor_observer'] = {'helper_process_calls': observer.helper_calls,
            'observation_count': observer.observation_count, 'retained_observations': observer.observations,
            'retention': 'FIRST_128_LAST_128_IF_OVER_256', 'native_usage_includes_helpers': False,
            'integrity_errors': observer.integrity_errors}
        if observer.integrity_errors:
            add_unique('fatal_reasons', ['supervisor_process_table_observation_failed'])
        if capture:
            try:
                result = capture.finish()  # Unchanged, fixed three-second reader join.
                if result['reader_joined']:
                    process.stdout.close()
                result['compressed_sha256'] = sha256(folder / 'stdout.txt.gz') if (folder / 'stdout.txt.gz').is_file() else None
                result['path'] = str(folder / 'stdout.txt.gz')
                receipt['stdout_capture'] = result
                add_unique('resource_reasons', result['cap_reasons'])
                if not result['capture_complete']:
                    add_unique('fatal_reasons', ['stdout_capture_incomplete_or_corrupt'])
                atomic_json(folder / 'STDOUT_CAPTURE.json', result)
            except BaseException as exc:
                add_unique('fatal_reasons', ['capture_finalize_error:' + repr(exc)])
        if error_stream:
            try:
                error_stream.flush()
                os.fsync(error_stream.fileno())
                error_stream.close()
            except BaseException as exc:
                add_unique('fatal_reasons', ['stderr_finalize_error:' + repr(exc)])
        receipt['cumulative_child_usage_after_not_native_measurement'] = child_usage()
        unit = 'bytes' if sys.platform == 'darwin' else ('KiB' if sys.platform.startswith('linux') else 'UNSUPPORTED')
        exact = process.exact_usage if process and process.exact_reaped else None
        raw_rss = exact.get('ru_maxrss') if exact else None
        receipt['peak_rss'] = {'rusage_field': 'os.wait4(exact_native_pid).ru_maxrss', 'os': sys.platform,
            'raw_value': raw_rss, 'raw_unit': unit,
            'bytes': raw_rss * (1024 if unit == 'KiB' else 1) if raw_rss is not None and unit != 'UNSUPPORTED' else None,
            'valid_one_child_measurement': bool(exact is not None and receipt['worker_spawned_children'] == 1),
            'calculation': 'EXACT_NATIVE_CHILD_WAIT4_EXCLUDES_PROCESS_TABLE_HELPERS'}
        receipt['source_pin_errors_after'] = verify_source_pins(source_pins)
        receipt['worker_source_pin_errors_after'] = verify_source_pins(receipt.get('worker_source_pins_before', []))
        if receipt['source_pin_errors_after'] or receipt['worker_source_pin_errors_after']:
            add_unique('fatal_reasons', ['source_freeze_changed_or_unavailable'])
        if unit == 'UNSUPPORTED':
            add_unique('fatal_reasons', ['unsupported_ru_maxrss_platform'])
        if receipt.get('deadline_utc') and datetime.now(timezone.utc) >= datetime.fromisoformat(receipt['deadline_utc']):
            add_unique('fatal_reasons', ['release_deadline_expired'])
        try:
            sample()
            receipt['artifact_sizes_before_receipt'] = files_before_receipt
            receipt['artifacts'] = {name: pin(folder / name) for name in sorted(files_before_receipt)}
            receipt['result_pin_errors_after'] = verify_source_pins(list(receipt['artifacts'].values()))
            if receipt['result_pin_errors_after']:
                add_unique('fatal_reasons', ['result_artifact_changed_while_pinning'])
        except BaseException as exc:
            add_unique('fatal_reasons', ['artifact_inspection_or_hash_error:' + repr(exc)])
        receipt['elapsed_seconds'] = time.monotonic() - started
        receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
        if receipt.get('deadline_utc') and datetime.now(timezone.utc) >= datetime.fromisoformat(receipt['deadline_utc']):
            add_unique('fatal_reasons', ['release_deadline_expired'])

    def classify():
        if receipt['fatal_reasons']:
            return 'FATAL_RELEASE_EXPIRED' if receipt['fatal_reasons'] == ['release_deadline_expired'] else 'FATAL_INTEGRITY_FAILURE'
        if receipt['resource_reasons']:
            return 'TECHNICAL_RESOURCE_REFUSAL'
        if receipt['returncode'] != 0:
            return 'TECHNICAL_NATIVE_REFUSAL'
        return 'PROCESS_COMPLETED'

    receipt['status'] = classify()
    try:
        if not folder.exists():
            folder.mkdir(parents=True, exist_ok=True)
        target = folder / 'NATIVE_WORKER_RECEIPT.json'
        if target.exists():
            # A repeated invocation must never overwrite an earlier receipt.
            raise FileExistsError('prior worker receipt preserved')
        # The receipt itself can cross a cap. Persist added reasons even when
        # the classification was already a refusal, and account for any growth
        # caused by the added metadata. At most self-file/aggregate/expiry can
        # be newly discovered after the child and all capture are complete.
        for _ in range(4):
            receipt['status'] = classify()
            before = (tuple(receipt['resource_reasons']), tuple(receipt['fatal_reasons']), receipt['status'])
            atomic_json(target, receipt)
            sample()
            if receipt.get('deadline_utc') and datetime.now(timezone.utc) >= datetime.fromisoformat(receipt['deadline_utc']):
                add_unique('fatal_reasons', ['release_deadline_expired'])
            after = (tuple(receipt['resource_reasons']), tuple(receipt['fatal_reasons']), classify())
            if before == after:
                break
        else:
            add_unique('fatal_reasons', ['receipt_resource_accounting_did_not_stabilize'])
            receipt['status'] = classify()
            atomic_json(target, receipt)
    except BaseException as exc:
        add_unique('fatal_reasons', ['receipt_write_or_final_inspection_error:' + repr(exc)])
        receipt['status'] = classify()
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('request', type=Path, help='JSON command/arm_dir/deadline_utc/limits request')
    arguments = parser.parse_args()
    with arguments.request.open(encoding='utf-8') as stream:
        request = json.load(stream)
    if set(request) != {'command', 'arm_dir', 'deadline_utc', 'limits', 'source_pins'}:
        raise SystemExit('request must contain exactly command, arm_dir, deadline_utc, limits, source_pins')
    result = run_native(**request)
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    return 0 if result['status'] == 'PROCESS_COMPLETED' else (2 if result['status'].startswith('FATAL_') else 1)


if __name__ == '__main__':
    raise SystemExit(main())
