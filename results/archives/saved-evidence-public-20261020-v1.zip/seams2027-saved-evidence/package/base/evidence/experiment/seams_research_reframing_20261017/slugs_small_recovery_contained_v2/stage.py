"""Bounded child entry for the unchanged Slugs exporter/checker and tighter caps."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;E=B.parent;BASE=E/'slugs_baseline_feasibility';V2=E/'kind_corpus_rle/runs'
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def strict_json(path):
    def pairs(items):
        out={}
        for k,v in items:
            if k in out:raise ValueError('Duplicate JSON key: '+k)
            out[k]=v
        return out
    return json.loads(Path(path).read_text(),object_pairs_hook=pairs)
def within(path):
    p=Path(path).resolve()
    if not p.is_relative_to(B):raise ValueError('Stage output outside runner package')
    return p

def main():
    ap=argparse.ArgumentParser();ap.add_argument('operation',choices=['export','check']);ap.add_argument('--fixture-id',required=True);ap.add_argument('--export-dir',required=True);ap.add_argument('--native-dir');ap.add_argument('--certificate')
    a=ap.parse_args();export=within(a.export_dir)
    if a.operation=='export':
        ex=load('slugs_runner_export',BASE/'adapter/exporter.py')
        try:
            result=ex.export_model(V2/a.fixture_id,a.fixture_id,export);ex.load_export(export)
            report={'status':result['status'],'fixture_id':a.fixture_id,'export_certificate':ex.pin(export/'EXPORT_CERTIFICATE.json')}
        except ex.ResourceRefusal as exc:
            report={'status':'RESOURCE_REFUSAL','fixture_id':a.fixture_id,'error':str(exc)}
        except Exception as exc:
            report={'status':'INVALID','fixture_id':a.fixture_id,'error':repr(exc)}
        ex.save(within(Path.cwd()/'STAGE_RESULT.json'),report);print(json.dumps(report))
        return
    native=within(a.native_dir);dest=within(a.certificate)
    c=load('slugs_runner_check',BASE/'adapter/certify.py');c.MAX_STATES=4096;c.MAX_EDGES=65536
    strict_json(native/'result.json')
    if (native/'controller.json').exists():strict_json(native/'controller.json')
    cert=c.check(export,native)
    cert.update(effective_graph_limits={'states':4096,'edges':65536,'legal_input_checks':c.MAX_INPUT_CHECKS},execution_adapter_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    dest.parent.mkdir(parents=True,exist_ok=True);c.ex.save(dest,cert)
    print(json.dumps({k:cert.get(k) for k in ['fixture_id','status','refusal_scope','strict_controller_pass','nonconflicting_pass','kind_controller_pass','error']}))
if __name__=='__main__':main()
