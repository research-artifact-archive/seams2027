from pathlib import Path
import importlib.util,json,math,time
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('slugs_exporter',HERE/'exporter.py');ex=importlib.util.module_from_spec(spec);spec.loader.exec_module(ex)
SOURCE=HERE.parent.parent/'kind_corpus/runs';DEST=HERE.parent/'exports';DEST.mkdir(exist_ok=True)
rows=[]
for f in sorted(SOURCE.glob('*/model.json')):
 model=ex.READ(f);carrier=math.prod(x['domain_size'] for x in model['fields'])
 if carrier>4096:continue
 started=time.monotonic()
 row={'fixture_id':f.parent.name,'carrier':carrier,'input_model_sha256':ex.sha(f)}
 try:
  cert=ex.export_model(f.parent,f.parent.name,DEST/f.parent.name)
  ctx,reloaded,mapping=ex.load_export(DEST/f.parent.name)
  row.update(status='PASS',arena_bytes=cert['arena']['bytes'],formula_count=cert['roundtrip']['formula_count'],reload_roundtrip='PASS',export_certificate_sha256=ex.sha(DEST/f.parent.name/'EXPORT_CERTIFICATE.json'))
 except Exception as e:row.update(status='FAIL',error=repr(e))
 row['elapsed_seconds']=time.monotonic()-started;rows.append(row)
result={'status':'PASS' if rows and all(r['status']=='PASS' for r in rows) else 'FAIL','native_scientific_synthesis_calls':0,'cases':rows,'exporter_sha256':ex.sha(HERE/'exporter.py'),'script_sha256':ex.sha(Path(__file__))}
ex.save(HERE.parent/'SAVED_MODEL_ROUNDTRIP.json',result);print(json.dumps(result,indent=2))
