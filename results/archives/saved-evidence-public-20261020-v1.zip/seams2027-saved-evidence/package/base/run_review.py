"""Bounded one-case driver. No all-cohort loop, automatic retry or native run."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,resource,signal,subprocess,sys,tempfile,time
ROOT=Path(__file__).resolve().parent
WALL=60.0;TOTAL_OUTPUT=64*1024*1024;PARENT_RESERVE=64*1024
OUTPUT=TOTAL_OUTPUT-PARENT_RESERVE;MEMORY=2*1024*1024*1024

def limits():
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    resource.setrlimit(resource.RLIMIT_CPU,(62,62))
    resource.setrlimit(resource.RLIMIT_FSIZE,(OUTPUT,OUTPUT))
    # Darwin's shared-library virtual mappings are not a resident-memory cap.
    # The parent separately samples this directly owned child's RSS on all hosts.
    if sys.platform!='darwin':resource.setrlimit(resource.RLIMIT_AS,(MEMORY,MEMORY))

def output_bytes(directory):
    total=0
    for p in directory.rglob('*'):
        try:
            if p.is_file():total+=p.stat().st_size
        except FileNotFoundError:pass
    return total

def reap_owned(proc):
    if proc.poll()is None:
        try:os.killpg(proc.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:proc.wait(timeout=0.5)
        except subprocess.TimeoutExpired:
            # An unreaped direct child cannot have its PID reused here.
            try:os.killpg(proc.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            proc.wait(timeout=2)
    return proc.wait()

def child(args,directory):
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=False)
    env={k:v for k,v in os.environ.items()if not k.startswith('PYTHON')};env['PYTHONDONTWRITEBYTECODE']='1'
    command=[sys.executable,'-I','-S','-B',str(ROOT/'worker.py'),*args]
    started=time.monotonic();reason=None;peak_rss=0;rss_samples=0;next_rss=0
    with (directory/'worker-output.txt').open('wb')as stream:
        proc=subprocess.Popen(command,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=stream,
            start_new_session=True,preexec_fn=limits)
        try:
            while proc.poll()is None:
                size=output_bytes(directory)
                if time.monotonic()-started>WALL:reason='UNKNOWN_RESOURCE_WALL_LIMIT'
                if size>OUTPUT:reason='UNKNOWN_RESOURCE_OUTPUT_LIMIT'
                if time.monotonic()>=next_rss and proc.poll()is None:
                    try:sample=subprocess.run(['/bin/ps','-o','rss=','-p',str(proc.pid)],capture_output=True,text=True,timeout=0.5)
                    except (OSError,subprocess.TimeoutExpired):reason='UNKNOWN_RESOURCE_RSS_OBSERVATION'
                    else:
                        raw=sample.stdout.strip();next_rss=time.monotonic()+0.2
                        if sample.returncode==0 and raw.isdigit():
                            rss=int(raw)*1024;rss_samples+=1;peak_rss=max(peak_rss,rss)
                            if rss>MEMORY:reason='UNKNOWN_RESOURCE_RSS_LIMIT'
                        elif proc.poll()is None:reason='UNKNOWN_RESOURCE_RSS_OBSERVATION'
                if reason:break
                time.sleep(0.03)
        finally:code=reap_owned(proc)
    size=output_bytes(directory)
    if size>OUTPUT:reason='UNKNOWN_RESOURCE_OUTPUT_LIMIT'
    return {'status':reason or ('PROCESS_COMPLETED'if code==0 else 'UNKNOWN_WORKER_FAILURE'),
        'returncode':code,'owned_child_reaped':True,'elapsed_seconds':round(time.monotonic()-started,6),
        'output_bytes':size,'limits':{'wall_seconds':WALL,'CPU_seconds':62,'combined_output_bytes':OUTPUT,
            'final_retained_output_bytes':TOTAL_OUTPUT,'parent_metadata_reserve_bytes':PARENT_RESERVE,
            'RSS_limit_bytes':MEMORY,'RSS_sampling_seconds':0.2,
            'address_space_limit_bytes':MEMORY if sys.platform!='darwin'else None},
        'sampled_peak_RSS_bytes':peak_rss,'RSS_samples':rss_samples,
        'RSS_boundary':'Sampled bound, not a continuous OS-enforced RSS cap; OS address-space cap additionally used except on Darwin.',
        'workers':1,'automatic_retries':0}

def compact_overflow(directory):
    """After reaping, discard only this new worker's oversized output files.

    Sampling cannot prevent a transient overshoot. Retained output is bounded
    after cleanup and the attempt remains UNKNOWN, even if the solver finished.
    """
    log=directory/'worker-output.txt';prefix=b''
    if log.is_file():
        with log.open('rb')as f:prefix=f.read(8192)
    removed=[];removed_count=0;removed_bytes=0
    for p in sorted(directory.rglob('*')):
        if p.is_file()or p.is_symlink():
            size=p.lstat().st_size;removed_count+=1;removed_bytes+=size
            if len(removed)<16:removed.append({'file':p.relative_to(directory).as_posix(),'bytes':size})
            p.unlink()
    log.write_bytes(prefix+b'\n[Output limit exceeded; fresh worker files discarded after reaping. No retry.]\n')
    return {'removed_files':removed_count,'removed_bytes':removed_bytes,'first_removed_files':removed,
        'diagnostic_log_prefix_bytes':len(prefix),'scope':'Only the new owned worker output directory; no package inputs.'}

def finalize_receipt(directory,marker,receipt):
    """Write a compact result pin and measure all retained per-case output."""
    marker_bytes=marker.stat().st_size;before=output_bytes(directory)
    result_path=directory/'RESULT.json';result=None;result_pin=None;result_error=None
    if result_path.exists():
        raw=result_path.read_bytes();result_pin={'file':'RESULT.json','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
        try:result=json.loads(raw)
        except (ValueError,UnicodeError)as ex:result_error=type(ex).__name__
    ok=receipt['process']['status']=='PROCESS_COMPLETED'and isinstance(result,dict)and result.get('status')=='PASS_SAVED_KERNEL_RECHECK'
    receipt.update(status='PASS'if ok else 'UNKNOWN_STOPPED_NO_RETRY',result_file=result_pin,
        result_status=str(result.get('status'))[:128]if isinstance(result,dict)else None,result_read_error=result_error)
    if before>OUTPUT:
        receipt.update(status='UNKNOWN_STOPPED_NO_RETRY',resource_reason='UNKNOWN_RESOURCE_OUTPUT_LIMIT',
            discarded_result_file=result_pin,result_file=None,output_cleanup=compact_overflow(directory))
    retained=output_bytes(directory)
    if retained>OUTPUT or marker_bytes>=PARENT_RESERVE:raise RuntimeError('Owned output accounting cannot satisfy reserved limit')
    receipt['output_accounting']={'total_limit_bytes':TOTAL_OUTPUT,'worker_limit_bytes':OUTPUT,
        'parent_reserve_bytes':PARENT_RESERVE,'observed_worker_bytes_before_cleanup':before,
        'worker_retained_bytes':retained,'start_marker_bytes':marker_bytes,
        'parent_receipt_bytes':0,'final_retained_bytes':0,
        'boundary':'Final retained bytes, including START and receipt. Transient worker overshoot is detected, marked UNKNOWN and compacted after reaping; not a continuous filesystem quota.'}
    path=directory/'RUN_RECEIPT.json'
    for _ in range(16):
        raw=(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode()
        if len(raw)+marker_bytes>PARENT_RESERVE:raise RuntimeError('Compact parent receipt exceeds reserved budget')
        account=receipt['output_accounting'];total=retained+marker_bytes+len(raw)
        if account['parent_receipt_bytes']==len(raw)and account['final_retained_bytes']==total:break
        account.update(parent_receipt_bytes=len(raw),final_retained_bytes=total)
    else:raise RuntimeError('Receipt byte accounting did not stabilize')
    path.write_bytes(raw)
    measured=output_bytes(directory)+marker_bytes
    if measured!=account['final_retained_bytes']or measured>TOTAL_OUTPUT:raise RuntimeError('Final retained output limit check failed')
    return receipt

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--metadata',action='store_true');ap.add_argument('--imports-only');ap.add_argument('--guard-probe',action='store_true')
    ap.add_argument('--run-reviewed',action='store_true');ap.add_argument('--route');ap.add_argument('--case');ap.add_argument('--expected-manifest',required=True)
    a=ap.parse_args();digest=hashlib.sha256((ROOT/'MANIFEST.json').read_bytes()).hexdigest()
    if digest!=a.expected_manifest or sum(bool(x)for x in (a.metadata,a.imports_only,a.run_reviewed))!=1:raise SystemExit('One mode and exact reviewed manifest digest required')
    if not a.run_reviewed:
        if a.route or a.case:raise SystemExit('Metadata/import qualification cannot compute a public case')
        args=['--metadata']if a.metadata else ['--imports-only',a.imports_only]
        if a.guard_probe:args.append('--guard-probe')
        with tempfile.TemporaryDirectory(prefix='all-cohort-qualification-')as temp:
            d=Path(temp)/'process';receipt=child(args+['--expected-manifest',digest],d)
            print((d/'worker-output.txt').read_text().strip());print(json.dumps(receipt))
        return 0 if receipt['status']=='PROCESS_COMPLETED'else 2
    if not a.route or not a.case or a.guard_probe:raise SystemExit('Reviewed run needs one explicit route and case')
    catalog=json.loads((ROOT/'ROUTES.json').read_text())['routes'];entry=next((r for r in catalog if r['route']==a.route),None)
    if entry is None or a.case not in entry['case_ids']:raise SystemExit('Outside fixed replay roster; saved UNKNOWN is not retried')
    runs=ROOT/'runs'
    if runs.is_symlink():raise SystemExit('Symlink result directory rejected')
    runs.mkdir(exist_ok=True);name=a.route+'__'+a.case
    marker=runs/(name+'.START.json')
    with marker.open('x')as f:json.dump({'route':a.route,'case_id':a.case,'manifest_sha256':digest,'created_utc':datetime.now(timezone.utc).isoformat()},f)
    directory=runs/name
    process=child(['--route',a.route,'--case',a.case,'--output',str(directory),'--expected-manifest',digest],directory)
    receipt={'schema':'one-reviewed-saved-case-run-v2',
        'manifest_sha256':digest,'route':a.route,'case_id':a.case,'process':process,
        'new_scientific_samples':0,'native_runs':0,'full_reset_uses':0}
    receipt=finalize_receipt(directory,marker,receipt)
    print(json.dumps({k:receipt[k]for k in ('status','route','case_id','new_scientific_samples','native_runs')}))
    return 0 if receipt['status']=='PASS'else 2
if __name__=='__main__':raise SystemExit(main())
