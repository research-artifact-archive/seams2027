"""Fresh single-case orchestration of unchanged saved-data mathematical kernels.

This module does not launch historical run/measure main functions. The evidence
namespace below supplies package paths and metadata I/O only; actual source,
typed-model, quantifier, region, graph and fairness kernels remain byte copies.
"""
from pathlib import Path
import gzip,importlib.util,json,sys,types
from datetime import datetime,timezone
from portable_data import E,require,sha

ROUTES=('condition','exact_loss','cooperative_loss','original_initial_WV','decomposition',
    'repair_condition','released_graph','v_restricted_graph','normalized_graph','slugs_graph','actual044')

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);obj=importlib.util.module_from_spec(spec)
    sys.modules[name]=obj;spec.loader.exec_module(obj);return obj

def evidence_namespace(package,folder):
    e=types.ModuleType('evidence');base=package.path(E.rstrip('/'),file=False);r=package.root/'evidence'
    paths={'B':base/folder,'E':base,'ROOT':r,'S':base/'kind_corpus_symbolic_independent',
        'H':base/'helper_quadrant_public','C':base/'helper_decomposition_public',
        'M':base/'released_transform_044_main','L':base/'preservation_loss_public',
        'N':base/'kind_corpus_rle','CHECK':base/'released_kind_corpus_checker',
        'CHECKER':r/'experiment/seams_submission_push_20261016/v_restricted_strict/checker'}
    for k,v in paths.items():setattr(e,k,v)
    e.ID='corpus044__original'
    def evidence_require(ok,message):
        if not ok:raise ValueError(message)
    e.require=evidence_require;e.read=package.runtime_read
    e.pin=lambda p:package.copied_pin(package.name(p));e.now=lambda:datetime.now(timezone.utc).isoformat()
    def forbidden(*args,**kwargs):raise ValueError('Historical evidence orchestration is not a portable computation entry point')
    e.verify=e.save=e.authorization=forbidden
    def load(name,path,evidence=None):
        old=sys.modules.get('evidence')
        if evidence is not None:sys.modules['evidence']=evidence
        try:return module(name,path)
        finally:
            if evidence is not None:sys.modules['evidence']=old
    e.load_module=load;sys.modules['evidence']=e
    sys.path.insert(0,str(paths['B']))
    return e

def bind_profile(base,p):
    base.read_json=p.runtime_read;base.load_profile=p.corpus_profile

def prepare(route,p):
    require(route in ROUTES,'Unknown computation route')
    if route in ('condition','original_initial_WV','exact_loss','cooperative_loss'):
        folder={'condition':'preservation_condition_public','original_initial_WV':'preservation_loss_public',
            'exact_loss':'preservation_loss_public','cooperative_loss':'cooperative_preservation_loss_public'}[route]
        evidence_namespace(p,folder)
        name={'condition':'condition','original_initial_WV':'loss','exact_loss':'loss','cooperative_loss':'intersection'}[route]
        return module(name,p.path(E+folder+'/'+name+'.py'))
    if route in ('decomposition','actual044'):
        folder='helper_decomposition_public'if route=='decomposition'else 'released_transform_044_analysis'
        evidence_namespace(p,folder);d=module('decomposition',p.path(E+folder+'/decomposition.py'))
        if route=='decomposition':
            bind_profile(d.pair_module.base,p)
            reporting=module('portable_saved_summary',p.path(E+folder+'/measure.py'))
            imp=module('import_original',p.path(E+folder+'/import_original.py'))
            return d,reporting,imp
        bind_profile(d.admitted_pair.base,p);bind_profile(d.pair_module.base,p)
        module('import_original',p.path(E+folder+'/import_original.py'))
        imp=module('imports',p.path(E+folder+'/imports.py'))
        refs=module('regions',p.path(E+folder+'/regions.py'))
        rep=module('reporting',p.path(E+folder+'/reporting.py'))
        return d,rep,imp,refs
    if route=='repair_condition':
        evidence_namespace(p,'repair_preservation_condition_20261017')
        a=module('adapter',p.path(E+'repair_preservation_condition_20261017/adapter.py'))
        a.checker.read_json=p.runtime_read
        return a
    if route=='released_graph':
        folder=E+'released_kind_corpus_checker/';sys.path.insert(0,str(p.path(folder.rstrip('/'),file=False)))
        b=module('generic_base',p.path(folder+'generic_base.py'));bind_profile(b,p)
        c=module('portable_released_certify',p.path(folder+'certify.py'));c.read_json=p.runtime_read
        return c
    if route in ('v_restricted_graph','normalized_graph'):
        c=module('portable_initial_graph',p.path(E+'initial_graph_checker/initial_graph_checker.py'));bind_profile(c,p)
        j=module('portable_exact_model_join',p.path(E+'corpus_comparison/model_join.py'));j.read=p.runtime_read
        return c,j
    if route=='slugs_graph':
        c=module('portable_slugs_certify',p.path(E+'slugs_baseline_feasibility/adapter/certify.py'))
        bind_profile(c.core,p);c.ex.READ=p.runtime_read
        return c

def selected(p,study,case):
    obj=p.read(E+study+'/SELECTION.json')
    rows=obj.get('rows',[obj.get('row')]);matches=[r for r in rows if r and r.get('id')==case]
    require(len(matches)==1,'Case must occur exactly once in fixed study selection')
    row=matches[0];require(row.get('eligible',True)is True,'Saved UNKNOWN/nonselected case is not a replay target')
    return row
def proof(p,ref):return p.read(p.name(p.origin_pin(ref)))
def mapped(p,row,study):
    # Historical runtime input_pins remain preserved in the saved files. New
    # execution admits only explicit mathematical inputs through the manifest.
    return p.materialize({k:v for k,v in row.items()if k!='input_pins'},E+study+'/SELECTION.json')
def same(actual,expected,keys):
    comparisons={k:actual[k]==expected[k]for k in keys}
    require(all(comparisons.values()),'Canonical saved-output disagreement: '+','.join(k for k,v in comparisons.items()if not v))
    return comparisons
def load_model(p,engine,row):
    ref=row.get('model',row.get('original_model'));path=p.origin_pin(ref);meta=p.runtime_read(path)
    prof=p.corpus_profile(row['id'])
    require(meta['fixture_id']==row['id']and meta['input']==prof['source'],'Original model/source profile binding')
    return engine.Model(path.parent,meta)

def compute(route,case,output,p):
    m=prepare(route,p);out=Path(output);comparisons={};fresh={};scope=''
    if route=='condition':
        study='preservation_condition_public';row=selected(p,study,case);model=load_model(p,m.engine,row)
        old=proof(p,row['proof']);w=m.load_w(model,p.origin_pin(row['independent_regions']),old)
        roots=m.compute(model.b,model.q,model.forms['rhoS'],model.den,model.dsn,model.current,model.en,model.sn,w)
        fresh=m.summarize(model,roots);expected=p.read(E+study+'/runs/'+case+'/RESULT.json')
        comparisons=same(fresh,expected,('W_subset_C','counts','canonical_sha256'))
        # Export through the unchanged historical export routine, without main.
        rep=module('portable_condition_export',p.path(E+study+'/measure.py'));rep.export(out/'FUNCTIONS.json.gz',model,roots)
        scope='Complete-semantic C and W-minus-C from the certified original W; all typed ENV-next inputs and SYS/AUX-next responses.'
    elif route=='exact_loss':
        study='preservation_loss_public';row=selected(p,study,case)
        require(case!='corpus159__original','159 stays UNKNOWN; no automatic retry')
        model=load_model(p,m.engine,row);old=m.load_independent(model,p.origin_pin(row['independent_regions']),proof(p,row['proof']))
        f=model.forms;roots,quant,log=m.compute(model.b,model.q,model.de,f['rhoE'],f['rhoS'],model.den,model.dsn,
            model.current,model.en,model.sn,model.prime,model.justices['ENV'],model.justices['SYS'],f['thetaE'],f['thetaS'],old['W'],old['reachable'])
        fresh=m.summarize(model,roots,quant);expected=p.read(E+study+'/runs/'+case+'/RESULT.json')
        comparisons=same(fresh,expected,('counts','canonical_sha256','initial_quantification','initial_verdict_changed'))
        authority=proof(p,row['proof']);require(fresh['initial_quantification']['W']==authority['initial_quantification']['W'],'Original initializer authority')
        m.export(out/'FUNCTIONS.json.gz',model,roots);fresh['iteration_logs']=log
        scope='Complete-semantic literal loss W-minus-W_C, with outer C and both C guards, original ordered justices and original typed initializer.'
    elif route=='cooperative_loss':
        study='cooperative_preservation_loss_public';row=selected(p,study,case);model=load_model(p,m.engine,row)
        k=m.load_k(model,p.origin_pin(row['independent_regions']),proof(p,row['proof']))
        old=m.load_loss(model,p.origin_pin(row['loss_functions']),proof(p,row['loss_proof']))
        roots=m.compute(model.b,model.q,model.current,k,old['W_minus_W_C'],old['original_reachable'])
        fresh=m.summarize(model,roots);expected=p.read(E+study+'/runs/'+case+'/RESULT.json')
        comparisons=same(fresh,expected,('counts','canonical_sha256','cooperative_loss_nonempty','original_reachable_cooperative_loss_nonempty'))
        m.export(out/'FUNCTIONS.json.gz',model,roots)
        scope='Boolean intersections of complete saved K/exact-loss/original-reachable functions; no new fixed points or source compilation.'
    elif route=='original_initial_WV':
        study='preservation_condition_public';row=selected(p,study,case)
        oldcond=p.read(E+study+'/runs/'+case+'/RESULT.json');require(oldcond['W_subset_C']is False,'Only the fixed ten condition-violating inputs')
        model=load_model(p,m.engine,row);old=proof(p,row['proof'])
        roots=m.load_independent(model,p.origin_pin(row['independent_regions']),old,names=('WV',))
        q=m.initial_quantification(model.b,model.de,model.forms['thetaE'],model.forms['thetaS'],roots['WV'],model.sc)
        fresh={'value':q['value'],'missing_environment_initial_count':m.count(model.b,q['missing_environment_initials'],model.ec),
            'system_witness_count':m.count(model.b,q['system_witness'],model.current)}
        comparisons=same(fresh,old['initial_quantification']['WV'],tuple(fresh))
        native=p.runtime_read(p.origin_pin(row['model']).with_name('result.json'));nq=native['WV_original_initial_quantification']
        require(set(nq['sys_quantified_bits'])==set(model.sc)and set(nq['env_quantified_bits'])==set(model.ec),'Original initializer SYS/AUX and ENV bit quantifiers')
        for key in ('system_witness','missing_environment_initials'):
            require(model.load(nq[key])==q[key],'Native original initializer function binding')
        scope='Original forall typed ENV exists typed SYS and every logical AUX current initializer quantifier on certified W_V; no M5 premise and no exact-loss retry.'
    elif route in ('decomposition','actual044'):
        study='helper_decomposition_public'if route=='decomposition'else 'released_transform_044_analysis'
        row=selected(p,study,case);mr=mapped(p,row,study);d,rep,imp=m[:3]
        original=Path(mr['original_model']['path']).parent;job=Path(mr['job_model']['path']).parent
        pair=d.build(original,job,case,p.corpus_profile(case));args=d.lifted_inputs(pair);answer=d.solve(**args)
        auth=proof(p,row['independent_W_certificate'])
        if route=='decomposition':
            w,audit=imp.load(pair,p.origin_pin(row['independent_regions']),auth)
            answer['roots']['independent_original_W_lifted']=w
            answer['roots']['original_W_authority_difference']=pair['common'].apply('xor',w,answer['roots']['W_original'])
            require(answer['roots']['original_W_authority_difference']==0,'Original W canonical authority')
        else:
            require(case=='corpus044__original'and pair['original'].carrier==18816 and pair['job'].carrier==37632,'Separate fixed044 full pair')
            roots,audit=imp.load_original_regions(pair,p.origin_pin(row['independent_regions']),auth)
            prior,pa=imp.load_loss(pair,p.origin_pin(row['prior_literal_loss_functions']),proof(p,row['prior_literal_loss_certificate']))
            m[3].add_references(answer,args,roots,prior)
        fresh=rep.summarize(pair,answer);expected=p.read(E+study+'/runs/'+case+'/RESULT.json')['summary']
        comparisons=same(fresh,expected,('counts','canonical_sha256','checks','initial_quantification','initial_ENV_choice_count'))
        oldq=auth['initial_quantification']['W'];q=fresh['initial_quantification']['W_original']
        require((q['value'],q['missing_initial_ENV_count'],q['SYS_witness_count'])==(oldq['value'],oldq['missing_environment_initial_count'],oldq['system_witness_count']),'Unchanged original typed initializer authority')
        rep.export(out/'FUNCTIONS.json.gz',pair,answer['roots'])
        scope='Actual saved full-field model pair: typed lift, U/F decomposition, direct strict full-helper solution and independent original W/initializer authority.'
    elif route=='repair_condition':
        study='repair_preservation_condition_20261017';row=selected(p,study,case);mr=mapped(p,row,study)
        profile_ref=row['source_profile']['file'];prpath=p.origin_pin(profile_ref);profiles=p.runtime_read(prpath)
        require(profiles['schema']=='k7-independent-source-profiles-v1'and row['source_profile']['profile_key']==case,'Exact repair formula profile')
        prof=profiles['profiles'][case]
        for key in ('source','trace'):
            r=prof[key];name=(Path(p.name(prpath)).parent/r['file']).as_posix();data=p.raw(name)
            require(len(data)==r['bytes']and sha(data)==r['sha256'],'Repair source/trace byte binding')
        trace=p.read((Path(p.name(prpath)).parent/prof['trace']['file']).as_posix())
        observations=[{k:'true'if v else 'false'for k,v in r.items()}for r in trace['observations']]
        require(all(type(v)is bool for r in trace['observations']for v in r.values())and prof['observations']==observations,'Repair trace/profile provenance')
        model=p.runtime_read(Path(mr['original_model']['path']));native=p.runtime_read(Path(mr['native_result']['path']))
        require(model['fixture_id']==native['fixture_id']==case and model['input']['sha256']==prof['source']['sha256'],'Repair source/model identity')
        context=m.checker.Context(Path(mr['original_model']['path']).parent,prof,model);context.audit_model()
        require(all(f['owner']=='SYS'for f in context.fields if f['role']=='AUX'),'Every logical AUX retained and SYS-owned')
        wv=context.read_bdd(native['final_region'],context.current)
        k=m.import_complete_k(context,proof(p,row['complete_K_valuations']),wv,row['existing_counts']['K'])
        roots=m.compute(context.b,context.domain,context.formulas['rhoS'],context.domain_en,context.domain_sn,context.current,context.env_next,context.sys_next,k)
        fresh=m.summarize(context,roots);expected=p.read(E+study+'/runs/'+case+'/RESULT.json')
        comparisons=same(fresh,expected,('counts','canonical_sha256','K_subset_C','W_V_subset_C'))
        m.export(out/'FUNCTIONS.json.gz',context,roots)
        scope='Fixed reconstructed/unchanged repair profile and exact complete typed K=W_V equality, then K subset C; original initial realizability not recomputed.'
    elif route=='released_graph':
        rows=p.read(E+'small_native_recovery/RUN_RECEIPT.json')['rows'];r=next(x for x in rows if x['id']==case and x['pipeline']=='released_kind')
        require(r['outcome']=='COMPLETE_ORIGINAL_VIEW_GRAPH_CHECKED','Incomplete released graph remains saved UNKNOWN')
        original=p.path(E+'kind_corpus_rle/runs/'+case,file=False);job=p.path(E+'small_native_recovery/runs/'+case+'/released_kind',file=False)
        c=m.check(original,job,case,out)
        expected=p.read(E+'released_kind_corpus_checker/small_recovery/runs/'+case+'/certificate.json')
        require(c['status']=='COMPLETE_DERIVED_ORIGINAL_CERTIFICATE','Complete released graph certificate')
        comparisons=same(c,expected,('derived_fairness','original_view_mapping'))
        require(all(c['native_graph'][k]==expected['native_graph'][k]for k in ('states','edges','initial_states')),'Complete native graph counts')
        require(json.loads((out/'derived_original_graph.json').read_text())==p.read(E+'released_kind_corpus_checker/small_recovery/runs/'+case+'/derived_original_graph.json'),'Full original-view graph equality')
        fresh=c;scope='Complete original-view graph, including all initial roots, native IDs/ranks/private memory; historical JVM invocation is not reexecuted.'
    elif route in ('v_restricted_graph','normalized_graph'):
        arm='v_restricted_strict'if route=='v_restricted_graph'else 'normalized_kind';c,j=m
        original=p.path(E+'kind_corpus_rle/runs/'+case,file=False);directory=p.path(E+'small_native_recovery/runs/'+case+'/'+arm,file=False)
        arena=j.original_model_join(original,directory);require(arena['status']=='EXACT_ORIGINAL_ARENA_MATCH','Original arena exact join')
        fresh=c.check_arm(directory,case,arm);expected=p.read(E+'small_native_recovery/runs/'+case+'/'+arm+'/certificate.json')
        comparisons=same(fresh,expected,('status','strict_controller_pass','nonconflicting_pass','kind_controller_pass'))
        if 'controller_audit'in fresh:comparisons.update(same(fresh['controller_audit'],expected['controller_audit'],('graph','fairness')))
        # The unchanged full-region importer binds the authority, then the arm's
        # saved final region is compared in the same canonical variable order.
        l=module('portable_graph_region_import',p.path(E+'preservation_loss_public/loss.py'))
        row=selected(p,'preservation_condition_public',case);model=load_model(p,l.engine,row)
        name='WV'if arm=='v_restricted_strict'else 'K'
        root=l.load_independent(model,p.origin_pin(row['independent_regions']),proof(p,row['proof']),names=(name,))[name]
        result=p.runtime_read(directory/'result.json');ref=result['final_region'];blob=p.raw(p.name(directory/ref['file']))
        observed,info=model.b.read_native(blob);require(observed==root,'Arm full final region equals independent canonical authority')
        fresh['portable_original_arena_join']=arena;fresh['portable_independent_region_equal']=True
        scope='Original-initializer graph/refusal audit plus exact original arena and independent complete region joins; native negative is not a new unrealizability proof.'
    elif route=='slugs_graph':
        ed=p.path(E+'slugs_small_recovery_contained_v2/exports/'+case,file=False)
        nd=p.path(E+'slugs_small_recovery_contained_v2/runs/'+case+'/native',file=False)
        cert=p.runtime_read(ed/'EXPORT_CERTIFICATE.json');require(cert['status']=='PASS'and cert['qualification_only']is False and cert['fixture_id']==case,'Slugs production export')
        model_dir=Path(cert['model_directory']);model=p.runtime_read(model_dir/'model.json');profile=p.corpus_profile(case)
        ctx=m.core.Context(model_dir,profile,model);ma=ctx.audit_model();require(ma==cert['model_audit'],'Slugs original model audit')
        mapping=p.runtime_read(ed/cert['map']['file']);roundtrip=m.ex.audit_input(ed/cert['arena']['file'],ctx,mapping)
        require(roundtrip==cert['roundtrip'],'Slugs exact Boolean export roundtrip')
        native=p.runtime_read(nd/'result.json');expected=p.read(E+'slugs_small_recovery_contained_v2/runs/'+case+'/certificate.json')
        if native['status']=='COMPLETE_UNREALIZABLE':
            require(expected['status']=='VALID_NATIVE_NEGATIVE'and native['controller_export']is None,'Historical native negative boundary')
            fresh={'status':'PRESERVED_NATIVE_NEGATIVE','fresh_unrealizability_proof':False,'roundtrip':roundtrip};comparisons={'saved_native_negative_preserved':True}
        else:
            require(native['status']=='COMPLETE_REALIZABLE','Saved unknown is not replayed')
            fresh=m.analyze_controller(ctx,mapping,p.runtime_read(nd/'controller.json'))
            comparisons=same(fresh,expected['controller_audit'],('status','graph','fairness','strict_controller_pass','nonconflicting_pass','kind_controller_pass'))
        scope='Same original Boolean arena roundtrip and complete upstream graph with all rank0 original initial roots; native binary invocation/negative verdict remain historical.'
    return {'schema':'fresh-single-case-kernel-recheck-v1','route':route,'case_id':case,'status':'PASS_SAVED_KERNEL_RECHECK',
        'scope':scope,'comparisons':comparisons,'computed':p.normalized(fresh),'historical_expected_only':True,
        'native_runs':0,'new_scientific_samples':0,'full_reset_uses':0}
