"""Independent saved-output Arbiter audit. No synthesis or production-checker imports.

Scientific execution requires a separately sealed input manifest and root GO.
The module itself has no file-reading or scientific-computation side effects.
"""
from pathlib import Path
from itertools import product
from datetime import datetime, timezone
import hashlib
import json
import re
import sys
import traceback

SOURCE_SHA = 'e412763fa69183ebadc1977768de0ea797c342f49f8717c2a5af0162046b4116'
ENV = ('a', 'r1', 'r2')
SYS = ('g1', 'g2')
AUX = ('SYS_CONSTRAINT.0.pRespondsToS.state', 'SYS_CONSTRAINT.1.pRespondsToS.state')
HELPER = '~envHelp'
ORIGINAL_NAMES = ENV + SYS + AUX
NATIVE_NAMES = ENV + (HELPER,) + SYS + AUX
VALUES = {n: ('false', 'true') for n in ENV + SYS + (HELPER,)}
VALUES.update({n: ('S0', 'S1') for n in AUX})


class AuditError(ValueError):
    pass


def need(value, reason):
    if not value:
        raise AuditError(reason)


def unique_object(pairs):
    out = {}
    for key, value in pairs:
        need(key not in out, 'Duplicate JSON key: ' + key)
        out[key] = value
    return out


def decode_json(raw):
    return json.loads(raw, object_pairs_hook=unique_object)


def pin(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read_pin(ref):
    path = Path(ref['path'])
    need(path.is_absolute() and not path.is_symlink(), 'Absolute regular pinned input required')
    raw = path.read_bytes()
    need(len(raw) == ref['bytes'] and hashlib.sha256(raw).hexdigest() == ref['sha256'],
         'Input pin mismatch: ' + path.name)
    return raw


def save_new(path, value):
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
    need(len(raw) < 16 * 1024 * 1024, 'Output file cap')
    with Path(path).open('xb') as stream:
        stream.write(raw)


class SavedDag:
    """Read the saved decision DAG and follow branches; never rebuild/apply BDDs."""
    def __init__(self, raw, variable_count, expected_order):
        need(len(raw) <= 8 * 1024 * 1024, 'Saved DAG input cap')
        rows = [line.split() for line in raw.decode('ascii').splitlines() if line.strip()]
        self.nodes = {}
        self.support = set()
        if rows == [['0', '0']] or rows == [['0', '1']]:
            self.root = int(rows[0][1])
            self.order = None
            return
        need(len(rows) >= 3 and rows[0] == [str(variable_count)], 'Saved DAG header')
        self.order = tuple(map(int, rows[1]))
        need(self.order == tuple(expected_order), 'Saved DAG/model variable order mismatch')
        need(len(self.order) == variable_count and set(self.order) == set(range(variable_count)),
             'Saved DAG variable permutation')
        levels = {var: level for level, var in enumerate(self.order)}
        seen_triples = set()
        for row in rows[2:]:
            need(len(row) == 4, 'Saved DAG node width')
            identity, variable, low, high = map(int, row)
            need(identity > 1 and identity not in self.nodes and variable in levels,
                 'Saved DAG node identity')
            need(low != high and all(child in (0, 1) or child in self.nodes for child in (low, high)),
                 'Saved DAG acyclic child order/reduction')
            triple = (variable, low, high)
            need(triple not in seen_triples, 'Saved DAG duplicate node')
            seen_triples.add(triple)
            for child in (low, high):
                need(child in (0, 1) or levels[self.nodes[child][0]] > levels[variable],
                     'Saved DAG ordered variables')
            self.nodes[identity] = triple
            self.support.add(variable)
            self.root = identity
        reachable = set()
        stack = [self.root]
        while stack:
            identity = stack.pop()
            if identity in (0, 1) or identity in reachable:
                continue
            reachable.add(identity)
            stack.extend(self.nodes[identity][1:])
        need(reachable == set(self.nodes), 'Saved DAG unreachable data')

    def value(self, assignment):
        identity = self.root
        while identity not in (0, 1):
            variable, low, high = self.nodes[identity]
            need(variable in assignment and type(assignment[variable]) is bool,
                 'Missing/non-Boolean DAG assignment')
            identity = high if assignment[variable] else low
        return identity == 1


def state_invariant(state):
    g1, g2, a = (state[x] == 'true' for x in ('g1', 'g2', 'a'))
    return (not g1 or not g2) and (a or (not g1 and not g2))


def source_initial(state):
    return state_invariant(state) and all(state[x] == 'S0' for x in AUX)


def source_env_edge(state):
    return state['a'] == 'true' or all(state[x] == 'false' for x in ('g1', 'g2', 'r1', 'r2'))


def source_sys_edge(state, successor):
    # Ordinary SYS state invariants are primed by the released StateInv translator.
    # The pattern state update instead reads the current request and grant.
    if not state_invariant(successor):
        return False
    for monitor, request, grant in zip(AUX, ('r1', 'r2'), ('g1', 'g2')):
        pending = (state[monitor] == 'S1' or state[request] == 'true') and state[grant] == 'false'
        if (successor[monitor] == 'S1') != pending:
            return False
    return True


def source_justices(state):
    return ([state['a'] == 'true'], [state[x] == 'S0' for x in AUX])


def profile_value(expression, state, successor=None):
    """Additional profile cross-check, never the definition of the source oracle."""
    if type(expression) is bool:
        return expression
    need(type(expression) is list and expression, 'Profile expression shape')
    operator, *args = expression
    if operator == 'var':
        name, prime = args
        return (successor if prime else state)[name] == 'true'
    if operator == 'eq':
        name, value, prime = args
        return (successor if prime else state)[name] == value
    values = [profile_value(arg, state, successor) for arg in args]
    if operator == 'not':
        need(len(values) == 1, 'not arity')
        return not values[0]
    if operator == 'and':
        return all(values)
    if operator == 'or':
        return any(values)
    need(len(values) == 2, 'Binary profile operator arity')
    if operator == 'implies':
        return not values[0] or values[1]
    if operator == 'iff':
        return values[0] == values[1]
    raise AuditError('Unexpected profile operator: ' + str(operator))


def closure(vertices, edges):
    """Reflexive transitive closure by integer bitset Warshall, not a DFS SCC library."""
    ordered = sorted(vertices, key=lambda x: int(x))
    position = {vertex: i for i, vertex in enumerate(ordered)}
    rows = [1 << i for i in range(len(ordered))]
    for source, target in edges:
        if source in position and target in position:
            rows[position[source]] |= 1 << position[target]
    for pivot in range(len(ordered)):
        bit, suffix = 1 << pivot, rows[pivot]
        for i in range(len(ordered)):
            if rows[i] & bit:
                rows[i] |= suffix
    return ordered, position, rows


def reachable_from(starts, result):
    ordered, position, rows = result
    bits = 0
    for start in starts:
        bits |= rows[position[start]]
    return {vertex for i, vertex in enumerate(ordered) if bits & (1 << i)}


def components(result):
    ordered, position, rows = result
    remaining = set(ordered)
    answer = []
    while remaining:
        root = min(remaining, key=int)
        ri = position[root]
        group = {vertex for vertex in remaining
                 if rows[ri] & (1 << position[vertex]) and rows[position[vertex]] & (1 << ri)}
        need(group, 'Reflexive component missing root')
        remaining -= group
        answer.append(sorted(group, key=int))
    return answer


def finite_fairness(vertices, edges, starts, env_justice, sys_justice):
    """Exact properties of this finite fixed-memory controller graph only."""
    vertices, edges = set(vertices), {tuple(edge) for edge in edges}
    need(set(starts) <= vertices and all(a in vertices and b in vertices for a, b in edges),
         'Fairness graph IDs')
    full = closure(vertices, edges)
    reachable = reachable_from(starts, full)
    need(reachable == vertices, 'Fairness input must be the reachable view')

    def accepting(group):
        members = set(group)
        cyclic = len(group) > 1 or (group[0], group[0]) in edges
        return cyclic and all(members & set(justice) for justice in env_justice)

    groups = components(full)
    fair_groups = [group for group in groups if accepting(group)]
    fair_vertices = {vertex for group in fair_groups for vertex in group}
    ordered, position, rows = full
    fair_bits = sum(1 << position[v] for v in fair_vertices)
    bad = [v for v in ordered if not rows[position[v]] & fair_bits]
    counterexamples = []
    for ji, justice in enumerate(sys_justice):
        reduced = closure(vertices - set(justice), edges)
        for group in components(reduced):
            if accepting(group):
                counterexamples.append({'SYS_justice_index': ji, 'SCC': group})
    return {'method': 'Direct finite-set truth labels and bitset Warshall transitive closure',
            'reachable_states': ordered, 'SCCs': groups, 'ENV_accepting_SCCs': fair_groups,
            'strict_liveness': {'pass': not counterexamples, 'counterexamples': counterexamples},
            'nonconflicting': {'pass': not bad, 'failing_states': bad,
                               'can_reach_ENV_accepting_SCC': [v for v in ordered if v not in set(bad)]}}


def audit(manifest):
    need(manifest['schema'] == 'arbiter-independent-audit-inputs-v1', 'Input manifest schema')
    refs = manifest['inputs']
    read_refs = []

    def read(name):
        raw = read_pin(refs[name])
        read_refs.append(name)
        return raw

    source = read('source')
    need(len(source) == 886 and hashlib.sha256(source).hexdigest() == SOURCE_SHA, 'Exact source contract')
    profile = decode_json(read('profile'))['profiles']['arbiter__preferred']
    result = decode_json(read('native_result'))
    model = decode_json(read('model'))
    graph = decode_json(read('controller'))
    printed = read('printer').decode('utf-8')
    process = decode_json(read('native_process'))
    need(process['status'] == 'PROCESS_COMPLETED' and process['exit_code'] == 0 and
         process['owned_child_reaped'] is True and process['final_group_observation']['state'] == 'ABSENT' and
         not process['fatal_reasons'] and not process['resource_reasons'] and
         all(value['complete'] for value in process['capture'].values()), 'Native process incomplete')
    for item in (result, model, graph):
        need(item['fixture_id'] == item['case_id'] == 'arbiter__preferred' and item['variant'] == 'initializers',
             'Raw identity')
    need(result['status'] == 'JOB_CONTROLLER_PRINTED' and result['teardown'] == 'COMPLETED', 'Incomplete native job')
    need(result['native_initial_verdict'] is True and result['memory_complete'] is True and
         result['memory_empty'] is False, 'Incomplete native extraction gate')
    need(result['native_solver_calls'] == result['controller_extraction_calls'] == result['native_printer_calls'] == 1,
         'Native call scope')
    need(result['pipeline'] == 'released_syntactic_kind_job_equivalent' and result['solver'] == '4fp',
         'Exact released syntactic native route')
    need(result['configuration'] == {
        'release': '1.0.0.202402072123', 'BDDPackage': 'JTLV', 'BDDPackageVersion': 'DEFAULT',
        'synthesisMethod': 'synthesisPitermanReduction', 'ConcreteControllerFormat': 'JTLV',
        'optChoice': 'none', 'reorderChoice': 'none', 'groupVars': False, 'TraceInfo': 'NONE',
        'TransFuncType': 'SINGLE_FUNC', 'extractor_strategy': 'native_two_argument_default_ZYX'},
         'Released native configuration changed')
    need(all(result[key] is False for key in
             ('initializers_replaced', 'semantic_reduction_used', 'ENV_justice_normalization_used')), 'Changed native semantics')
    need(result['input_sha256'] == model['input']['sha256'] == SOURCE_SHA and model['input']['bytes'] == 886,
         'Source/native binding')
    need(result['helper_added'] is True and result['helper_is_native_nonaux_ENV'] is True, 'Helper ownership')
    need(model['schema'] == 'k7-native-model-export-v1' and graph['schema'] == 'released-kind-complete-native-controller-v1',
         'Raw model/graph schema')
    need(graph['complete'] is True and graph['initialization'] == 'source_initializers' and
         graph['helper_policy'] == 'unchanged_native_graph_with_helper', 'Complete original-initializer graph')
    need(graph['model_sha256'] == refs['model']['sha256'] and
         graph['native_memory_identity'] == result['native_memory_identity'], 'Graph/model/memory binding')
    need(result['same_native_memory_passed_to_constructor'] is True and
         result['same_native_model_passed_to_constructor'] is True and
         result['controller_before_print_sha256'] == result['controller_after_print_sha256'], 'Native memory/printer identity')
    for key, logical in [('model_export', 'model'), ('controller_export', 'controller'), ('printed_controller', 'printer')]:
        need(result[key]['bytes'] == refs[logical]['bytes'] and result[key]['sha256'] == refs[logical]['sha256'],
             'Native export pin: ' + logical)
    need(profile['source']['sha256'] == SOURCE_SHA and profile['public_ENV'] == list(ENV) and
         profile['public_SYS'] == list(SYS), 'Original profile source/public fields')
    need(profile['formulas']['thetaE'] is True, 'Original initial input restriction')
    fields = model['fields']
    need([field['name'] for field in fields] == list(NATIVE_NAMES), 'All original fields, AUX and helper in native order')
    current, next_bits, env_current, env_next, sys_next = set(), set(), set(), set(), set()
    field_by_name = {field['name']: field for field in fields}
    for field in fields:
        name = field['name']
        need(field['domain_size'] == 2 and tuple(field['values']) == VALUES[name], 'Typed field values')
        owner = 'ENV' if name in ENV + (HELPER,) else 'SYS'
        role = 'ENV' if owner == 'ENV' else 'SYS' if name in SYS else 'AUX'
        need(field['owner'] == owner and field['role'] == role, 'Field owner/AUX role')
        cb, nb = field['current_bits'], field['next_bits']
        need(len(cb) == len(nb) == 1 and not ((set(cb) | set(nb)) & (current | next_bits)) and cb != nb,
             'Disjoint current/next field bits')
        current.update(cb); next_bits.update(nb)
        if owner == 'ENV':
            env_current.update(cb); env_next.update(nb)
        else:
            sys_next.update(nb)
        need(set(field['encoding']) == set(VALUES[name]), 'Complete encoding value roster')
        for timing, bits in [('current', cb), ('next', nb)]:
            encoded = []
            for value in VALUES[name]:
                mapping = field['encoding'][value][timing]
                need(set(mapping) == {str(bit) for bit in bits} and all(type(v) is bool for v in mapping.values()),
                     'Complete native Boolean encoding')
                encoded.append(tuple(mapping[str(bit)] for bit in bits))
            need(set(encoded) == {(False,), (True,)}, 'Bijective Boolean/enum encoding')
    need(current == set(model['all_current_bits']) and next_bits == set(model['all_next_bits']) and
         current | next_bits == set(range(model['bdd_variable_count'])) and len(current) == 8,
         'Complete native bit carrier')
    parsed = model['source_inventory']['parsed']
    need([x['name'] for x in parsed['ENV']['variables']] == list(ENV) and
         [x['name'] for x in parsed['SYS']['variables']] == list(SYS), 'Parsed original public fields')

    def bits(state, prime=False):
        answer = {}
        for name, value in state.items():
            need(name in field_by_name and value in VALUES[name], 'Typed valuation')
            mapping = field_by_name[name]['encoding'][value]['next' if prime else 'current']
            answer.update({int(k): v for k, v in mapping.items()})
        return answer

    loaded = {}

    def dag(ref, allowed):
        name = ref['file']
        need(Path(name).name == name and name in manifest['bdd_files'], 'Pinned local saved-DAG reference')
        target = manifest['bdd_files'][name]
        need(ref['bytes'] == target['bytes'] and ref['sha256'] == target['sha256'], 'Saved DAG native pin')
        if name not in loaded:
            loaded[name] = SavedDag(read_pin(target), model['bdd_variable_count'], model['bdd_variable_order'])
        answer = loaded[name]
        need(answer.support <= allowed, 'Saved DAG illegal variable support: ' + name)
        return answer

    native_formulas = {name: dag(model['original_bdds'][name], allowed) for name, allowed in
                       [('thetaE', env_current), ('thetaS', current), ('rhoE', current | env_next),
                        ('rhoS', current | next_bits)]}
    original_states = [dict(zip(ORIGINAL_NAMES, values)) for values in product(*(VALUES[x] for x in ORIGINAL_NAMES))]
    full_states = [dict(state, **{HELPER: helper}) for state in original_states for helper in VALUES[HELPER]]
    need(len(original_states) == 128 and len(full_states) == 256, 'Finite source carrier')
    cached_original = [(state, bits(dict(state, **{HELPER: 'false'})),
                        bits(dict(state, **{HELPER: 'false'}), True)) for state in original_states]
    for state, cb, _ in cached_original:
        need(native_formulas['thetaE'].value(cb) is True, 'Source/helper-false thetaE differs')
        need(native_formulas['thetaS'].value(cb) == source_initial(state), 'Source/helper-false thetaS differs')
        need(profile_value(profile['formulas']['thetaS'], state) == source_initial(state), 'Profile initial semantics differs')
        for successor, _, nb in cached_original:
            joined = cb | nb
            need(native_formulas['rhoE'].value(joined) == source_env_edge(state), 'Source/helper-false rhoE differs')
            need(native_formulas['rhoS'].value(joined) == source_sys_edge(state, successor), 'Source/helper-false rhoS differs')
            need(profile_value(profile['formulas']['rhoE'], state, successor) == source_env_edge(state), 'Profile ENV timing differs')
            need(profile_value(profile['formulas']['rhoS'], state, successor) == source_sys_edge(state, successor), 'Profile SYS/AUX timing differs')
    for key, allowed, sample in [('domain', current, full_states),
                                 ('domain_ENV_next', env_next, [dict(zip(ENV + (HELPER,), v)) for v in product(('false', 'true'), repeat=4)]),
                                 ('domain_SYS_next', sys_next, [dict(zip(SYS + AUX, v)) for v in product(*(VALUES[x] for x in SYS + AUX))])]:
        root = dag(model['original_bdds'][key], allowed)
        need(all(root.value(bits(state, key != 'domain')) for state in sample), 'Typed domain mismatch: ' + key)
    justice_roots = {owner: [dag(ref, current) for ref in model['original_justices'][owner]] for owner in ('ENV', 'SYS')}
    helper_matches = [i for i, root in enumerate(justice_roots['ENV'])
                      if all(root.value(bits(state)) == (state[HELPER] == 'false') for state in full_states)]
    need(len(helper_matches) == 1, 'Unique full-domain helper justice')
    source_roots = {'ENV': [root for i, root in enumerate(justice_roots['ENV']) if i != helper_matches[0]],
                    'SYS': justice_roots['SYS']}
    need(len(source_roots['ENV']) == 1 and len(source_roots['SYS']) == 2, 'Ordered source justice count')
    for state, cb, _ in cached_original:
        for owner, expected in zip(('ENV', 'SYS'), source_justices(state)):
            need([root.value(cb) for root in source_roots[owner]] == expected, 'Source justice identity/order')
            need([profile_value(expr, state) for expr in profile['justices'][owner]] == expected, 'Profile justice identity/order')
    for phase in ('preconstructor_justices', 'solver_justices'):
        for owner in ('ENV', 'SYS'):
            roots = [dag(ref, current) for ref in result[phase][owner]]
            need(len(roots) == len(justice_roots[owner]), 'Constructor justice count changed')
            need(all([root.value(bits(state)) for root in roots] ==
                     [root.value(bits(state)) for root in justice_roots[owner]] for state in full_states),
                 'Constructor justice semantics/order changed')

    nodes = graph['nodes']
    need(0 < len(nodes) <= 4096 and len(nodes) == graph['api_state_count'], 'Native node cap/count')
    by_id = {}
    flat = []
    need(graph['rank_domain_size'] == 2, 'Complete source SYS rank domain')
    lines = printed.splitlines()
    need(len(lines) == 2 * len(nodes), 'Complete native printer line count')
    for i, node in enumerate(nodes):
        identity = str(i)
        need(node['id'] == identity and node['native_id'] == i, 'Complete ordered native identity')
        need(type(node['initial']) is bool and type(node['rank']) is int and 0 <= node['rank'] < 2 and
             node['rank_class'] == 'tau.smlab.syntech.games.gr1.GR1RankInfo' and isinstance(node['rank_info'], str),
             'Native rank/private memory encoding')
        state = node['valuation']
        need(set(state) == set(NATIVE_NAMES), 'All original fields/AUX/helper retained per node')
        expected_bits = bits(state)
        need(all(type(value) is bool for value in node['bits'].values()), 'Native bit value types')
        need({str(k): v for k, v in expected_bits.items()} == node['bits'], 'Native valuation/bit correspondence')
        need(isinstance(node['successors'], list) and len(set(node['successors'])) == len(node['successors']), 'Unique successor IDs')
        prefix = 'Initial State ' if node['initial'] else 'State '
        need(lines[2*i].startswith(prefix + identity + ' <') and lines[2*i].endswith('>'), 'Printed native ID/initial')
        body = lines[2*i][len(prefix + identity + ' '):]
        need(body == node['native_bdd_text'], 'Printed native BDD valuation text')
        pairs = [item.split(':') for item in body[1:-1].split(', ')]
        need(all(len(pair) == 2 for pair in pairs) and len(pairs) == len(dict(pairs)) and dict(pairs) == state,
             'Printed complete valuation correspondence')
        expected_line = ('\tWith successors : ' + ', '.join(node['successors'])
                         if node['successors'] else '\tWith no successors.')
        need(lines[2*i+1] == expected_line, 'Printed complete ordered successors')
        by_id[identity] = node
        flat.extend((identity, successor) for successor in node['successors'])
    need([list(edge) for edge in flat] == graph['edges'] and len(flat) == graph['api_transition_count'] and
         len(flat) == len(set(flat)) <= 65536 and all(target in by_id for _, target in flat), 'Complete native edge export')
    starts = [node['id'] for node in nodes if node['initial']]
    need(starts and all(by_id[i]['rank'] == 0 and by_id[i]['valuation'][HELPER] == 'false' for i in starts),
         'Original initial native rank/helper')
    full_reachable = reachable_from(starts, closure(set(by_id), flat))
    need(full_reachable == set(by_id), 'Native unreachable extra states')
    input4 = [dict(zip(ENV + (HELPER,), v)) for v in product(('false', 'true'), repeat=4)]
    input3 = [dict(zip(ENV, v)) for v in product(('false', 'true'), repeat=3)]
    original_initial_keys = {tuple(state[name] for name in ENV) for state in input3}
    native_initial_keys = {tuple(state[name] for name in ENV + (HELPER,)) for state in input4
                           if native_formulas['thetaE'].value(bits(state))}
    actual_native_initial = {}
    for identity in starts:
        state = by_id[identity]['valuation']
        key = tuple(state[name] for name in ENV + (HELPER,))
        need(key not in actual_native_initial and native_formulas['thetaE'].value(bits(state)) and
             native_formulas['thetaS'].value(bits(state)) and source_initial(state), 'Native/source initial response')
        actual_native_initial[key] = identity
    need(set(actual_native_initial) == native_initial_keys and len(starts) == 8 and
         {key[:3] for key in native_initial_keys} == original_initial_keys, 'All eight original initial inputs exactly once')
    native_input_checks = 0
    for identity, node in by_id.items():
        cb = bits(node['valuation'])
        expected = {tuple(state[name] for name in ENV + (HELPER,)) for state in input4
                    if native_formulas['rhoE'].value(cb | bits(state, True))}
        actual = {}
        native_input_checks += len(input4)
        for successor_id in node['successors']:
            successor = by_id[successor_id]['valuation']
            joined = cb | bits(successor, True)
            need(native_formulas['rhoE'].value(joined) and native_formulas['rhoS'].value(joined), 'Raw native safety')
            key = tuple(successor[name] for name in ENV + (HELPER,))
            need(key not in actual, 'Raw native response/private-memory nondeterminism')
            actual[key] = successor_id
        need(set(actual) == expected, 'Raw native legal-input coverage')
    helper_false = {identity for identity, node in by_id.items() if node['valuation'][HELPER] == 'false'}
    zero_edges = [(a, b) for a, b in flat if a in helper_false and b in helper_false]
    view_ids = reachable_from(starts, closure(helper_false, zero_edges))
    view_edges = [(a, b) for a, b in zero_edges if a in view_ids]
    view_adjacency = {identity: [] for identity in view_ids}
    for a, b in view_edges:
        need(b in view_ids, 'View closure')
        view_adjacency[a].append(b)
    original_input_checks = 0
    for identity in sorted(view_ids, key=int):
        state = by_id[identity]['valuation']
        expected = original_initial_keys if source_env_edge(state) else set()
        actual = {}
        original_input_checks += len(input3)
        for successor_id in view_adjacency[identity]:
            successor = by_id[successor_id]['valuation']
            need(source_env_edge(state) and source_sys_edge(state, successor), 'Original view safety/AUX timing')
            key = tuple(successor[name] for name in ENV)
            need(key not in actual, 'Original response/private-memory nondeterminism')
            actual[key] = successor_id
        need(set(actual) == expected, 'Original legal-input coverage')
    env_labels = [{identity for identity in view_ids if by_id[identity]['valuation']['a'] == 'true'}]
    sys_labels = [{identity for identity in view_ids if by_id[identity]['valuation'][monitor] == 'S0'} for monitor in AUX]
    fairness = finite_fairness(view_ids, view_edges, starts, env_labels, sys_labels)
    view = {'schema': 'independent-arbiter-original-view-v1', 'states': sorted(view_ids, key=int),
            'starts': starts, 'edges': [list(edge) for edge in view_edges],
            'env_justice': [sorted(label, key=int) for label in env_labels],
            'sys_justice': [sorted(label, key=int) for label in sys_labels],
            'native_nodes': [by_id[i] for i in sorted(view_ids, key=int)]}
    summary = {'status': 'COMPLETE_INDEPENDENT_RAW_GRAPH_AUDIT', 'candidate': 'arbiter__preferred',
               'native_returned_graph': {'states': len(nodes), 'edges': len(flat), 'initial_states': len(starts),
                                         'all_reachable': True, 'safety': True, 'complete_input_checks': native_input_checks},
               'source_correspondence': {'source_sha256': SOURCE_SHA, 'original_typed_states': 128,
                                        'helper_false_state_pairs': 16384, 'initial_inputs': 8,
                                        'thetaE_thetaS_rhoE_rhoS_full_domain': True,
                                        'profile_crosscheck': True, 'ordered_justice_identity': True,
                                        'SYS_invariant_timing': 'initial current; transition next',
                                        'response_monitor_timing': 'current request/grant to next monitor',
                                        'ENV_mixed_invariant_timing': 'current-only, references SYS'},
               'original_view': {'states': len(view_ids), 'edges': len(view_edges), 'initial_states': len(starts),
                                 'safety': True, 'complete_input_checks': original_input_checks,
                                 'native_IDs_ranks_AUX_preserved': True, 'memory_reset_or_graph_repair': False},
               'fairness': fairness, 'independent_strict': fairness['strict_liveness']['pass'],
               'independent_cooperative': fairness['nonconflicting']['pass'],
               'saved_DAG_files_evaluated': sorted(loaded), 'logical_inputs_read': read_refs,
               'production_certificate_read': False, 'production_checker_imports': 0,
               'native_processes': 0, 'region_fixed_point_solves': 0,
               'scope': 'This complete source-initialized returned graph only; no population, repair-loop, or historical-label promotion.'}
    return summary, view


def main():
    need(len(sys.argv) == 3, 'Usage: audit_worker.py INPUTS.json OUTPUT_DIRECTORY')
    manifest_path, output = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
    need(output.is_dir() and not any(output.iterdir()), 'Fresh empty worker output directory required')
    manifest = decode_json(manifest_path.read_bytes())
    started = datetime.now(timezone.utc).isoformat()
    try:
        result, view = audit(manifest)
        save_new(output / 'INDEPENDENT_VIEW.json', view)
        result['view_pin'] = pin(output / 'INDEPENDENT_VIEW.json')
        exit_code = 0
    except BaseException as error:
        result = {'status': 'UNKNOWN_INDEPENDENT_AUDIT', 'error': str(error),
                  'exception_type': type(error).__name__, 'traceback': traceback.format_exc(),
                  'production_certificate_read': False, 'production_checker_imports': 0,
                  'native_processes': 0, 'region_fixed_point_solves': 0}
        exit_code = 2
    result.update(started_utc=started, finished_utc=datetime.now(timezone.utc).isoformat(),
                  input_manifest_pin=pin(manifest_path), worker_pin=pin(Path(__file__)))
    save_new(output / 'AUDIT_RESULT.json', result)
    print(json.dumps({key: result[key] for key in ['status', 'error', 'independent_strict', 'independent_cooperative'] if key in result}))
    return exit_code


if __name__ == '__main__':
    sys.exit(main())
