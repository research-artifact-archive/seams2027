Private Arbiter independent-audit candidate v1

Purpose and status
This package reproduces the existing finite source-equation and complete-graph
audit for Arbiter preferred. It is a private evidence candidate, not an external
publication or a new scientific result. No portable replay was run while this
package was prepared. The scientific worker is an unchanged copy of the already
qualified and independently executed worker, SHA-256:
93818c6e0ac1f7f9d3f1191a2cf028059e78cd8d66da2d3b0ec426c8b820158b

Scope
There is one selected published repair candidate, two historical native attempts,
and one completed native result. Attempt 1 remains resource UNKNOWN at the 8-MiB
stdout cap. Attempt 2 kept the source and implementation unchanged, raised only
the native stream caps to 64 MiB, reduced the native wall bound from 60 to 10
seconds, and increased the aggregate output postcheck from 64 to 128 MiB. Checker
limits stayed fixed. Receipt snapshots for both attempts are in history/; the
completed native process receipt is also a required input in inputs/native/.

The saved native graph has 112 states and 1,176 edges. Its original helper-false
view has 56 states, 280 edges and all eight permitted initial inputs. The existing
independent audit passes original safety, input coverage and strict liveness,
but fails cooperation: 21 reachable states lack an assumption-fair continuation.
The helper-false view retains native IDs, rank/private memory and both logical
monitors; it is not a projection performed by the native printer.

The worker evaluates saved decision-DAG branches against source-coded equations
on 128 original states and 16,384 state pairs, checks the complete printer and
input coverage, and uses finite-set/bitset transitive closure for graph fairness.
It does not call a native solver, calculate a winning region, import the
production checker, or reconstruct a live compiler/JVM/runtime. This replay
does not generate a repair, run an adaptation loop or demonstrate deployment.

Trust and provenance
The native model and graph share the producer's compiler exports. The direct
source-equation check is specific to this contract, not a general compiler proof.
The 886-byte source is the declared reconstruction of the published Arbiter
listing; its omitted response pattern was appended. The raw listing, declared
diff, pattern, original provenance, source obstruction and inspected translator
are included in provenance/. The contract-level obstruction applies to its
nonempty source initializer, not to artificial vacuous initializers.

expected/ contains the original result and view sealed before the original
production comparison. Replaying these known inputs is a reproduction, not a
new blinded audit. Historical records preserve their original absolute paths
and hashes as inert provenance; their external references are not runtime
dependencies and are not all bundled. COPY_ORIGINS.json maps each unchanged
copied file to its original workspace-relative origin. BUNDLE_MANIFEST.json
pins every packaged payload and adapter file. Protect its delivered hash
separately when checking integrity.

Portable runtime closure
Only Python's standard library is required. The original worker ran with
CPython 3.10.9; use Python 3.10 or later. No Python packages, network, Java, BDD
library, production checker or original checkout are needed for this audit.
The runtime closure is code/audit_worker.py, seven logical inputs, and nineteen
saved-DAG files. INPUTS.relative.json supplies bundle-relative pins. replay.py
checks all packaged bytes and binds those pins to absolute paths at the copied
location, as required by the unchanged worker. It never opens historical paths.

The unused final_region.bdd is omitted. Native stdout/stderr logs are omitted
because the worker does not parse them; it checks completion and capture status
in the saved native process receipt. This package therefore rechecks the saved
model/graph audit, not the historical live capture or source-to-bytecode build.

Exact commands, from this package directory

1. Metadata-only integrity check (does not run/import the scientific worker):

   python3 -I -B replay.py verify

2. After a separate authorization, run under an external bounded supervisor:

   python3 -I -B replay.py run ../seams2027-20261017-arbiter-audit-replay-01

   The output path must not exist and must be outside this package, with an
   existing parent. The adapter creates INPUTS.bound.json and REPLAY_REQUEST.json,
   then replaces itself with the unchanged worker using os.execv. No detached
   child is created. The proposed replay bounds are 120 seconds wall time,
   1 GiB RSS, 8 MiB per captured stream, 16 MiB per output file, and a 64 MiB
   aggregate output postcheck. The adapter does not enforce these external
   limits. Root must review the package and separately authorize the bounded
   isolated replay before command 2 is used in this research session.

3. After a successful bounded worker completion, compare saved outputs:

   python3 -I -B replay.py compare ../seams2027-20261017-arbiter-audit-replay-01

   Comparison is metadata/file equality only. INDEPENDENT_VIEW.json must match
   the sealed original byte for byte. All scientific AUDIT_RESULT.json fields
   must match; only timestamps and location-dependent pins are excluded from
   that JSON comparison, with local worker/input/view pins checked separately.
   A successful comparison writes COMPARISON.json in the replay directory.
   Failure or incomplete output is not a reproduced result; preserve it for
   inspection instead of treating it as a new Boolean scientific conclusion.

Preparation leaves prior evidence, manuscript sources, submission packages and
all scientific checker code unchanged. It uses no Full reset.
