"""Portable path binding and result comparison; never imports the audit worker.

The 'run' command replaces this process with the unchanged scientific worker.
Use it only after the proposed replay has been separately authorized and bounded.
The 'verify' and 'compare' commands only read/hash/compare JSON and file bytes.
"""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import sys

ROOT = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def pin(path):
    raw = Path(path).read_bytes()
    return {'path':str(Path(path).resolve()), 'bytes':len(raw),
            'sha256':hashlib.sha256(raw).hexdigest()}


def local(relative):
    require(type(relative) is str, 'Expected a string relative path')
    item = PurePosixPath(relative)
    require(relative == item.as_posix() and not item.is_absolute() and item.parts and
            all(part not in ('', '.', '..') for part in item.parts), 'Unsafe relative path')
    path = ROOT.joinpath(*item.parts)
    current = ROOT
    for part in item.parts:
        current = current / part
        require(not current.is_symlink(), 'Symlink is outside this portable closure: ' + relative)
    require(path.is_file() and ROOT in path.resolve().parents, 'Missing local regular file: ' + relative)
    return path


def matches(path, expected):
    actual = pin(path)
    require(actual['bytes'] == expected['bytes'] and actual['sha256'] == expected['sha256'],
            'Byte/hash mismatch: ' + str(path))
    return actual


def write_new(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def verify():
    manifest = load(local('BUNDLE_MANIFEST.json'))
    require(manifest['schema'] == 'portable-arbiter-audit-bundle-v1', 'Bundle manifest schema')
    records = manifest['files']
    require(len({row['file'] for row in records}) == len(records), 'Duplicate bundle file')
    by_file = {row['file']:row for row in records}
    for row in records:
        matches(local(row['file']), row)
    relative = load(local('INPUTS.relative.json'))
    require(relative['schema'] == 'arbiter-independent-audit-inputs-v1', 'Audit input schema')
    require(set(relative['inputs']) == {'source','profile','model','native_result','controller','printer','native_process'},
            'Logical input closure changed')
    require(len(relative['bdd_files']) == 19, 'Saved DAG closure changed')
    for group in ('inputs', 'bdd_files'):
        for ref in relative[group].values():
            require(ref['path'] in by_file, 'Unlisted runtime input')
            matches(local(ref['path']), ref)
    require(by_file['code/audit_worker.py']['sha256'] ==
            '93818c6e0ac1f7f9d3f1191a2cf028059e78cd8d66da2d3b0ec426c8b820158b',
            'Scientific worker changed')
    return relative, {'status':'BUNDLE_BYTES_VERIFIED', 'files':len(records),
                      'logical_inputs':7, 'saved_DAGs':19, 'scientific_worker_executed':False}


def bind_manifest(relative):
    bound = json.loads(json.dumps(relative))
    for group in ('inputs', 'bdd_files'):
        for ref in bound[group].values():
            ref['path'] = str(local(ref['path']).resolve())
    return bound


def run(output):
    relative, _ = verify()
    output = Path(output).resolve()
    require(output != ROOT and ROOT not in output.parents, 'Write replay outputs outside the immutable bundle')
    require(output.parent.is_dir() and not output.exists(), 'A fresh output path with an existing parent is required')
    output.mkdir()
    worker_output = output / 'worker_output'
    worker_output.mkdir()
    manifest_path = output / 'INPUTS.bound.json'
    write_new(manifest_path, bind_manifest(relative))
    worker = local('code/audit_worker.py')
    command = [sys.executable, '-I', '-B', str(worker), str(manifest_path), str(worker_output)]
    write_new(output / 'REPLAY_REQUEST.json', {
        'schema':'portable-arbiter-replay-request-v1',
        'created_utc':datetime.now(timezone.utc).isoformat(),
        'bundle_manifest':pin(ROOT/'BUNDLE_MANIFEST.json'), 'worker':pin(worker),
        'bound_manifest':pin(manifest_path), 'command':command,
        'scope':'Replay the existing finite source-equation and complete-graph audit only; no native synthesis.',
        'resource_supervision':'External bounded supervisor required; this adapter does not enforce wall/RSS/stream limits.',
        'worker_process_model':'os.execv replaces this process; no detached child or recursive subprocess.'})
    os.execv(sys.executable, command)


def compare(output):
    relative, _ = verify()
    output = Path(output).resolve()
    require(output != ROOT and ROOT not in output.parents, 'Expected an external replay directory')
    expected = load(local('expected/AUDIT_RESULT.json'))
    result_path = output / 'worker_output/AUDIT_RESULT.json'
    view_path = output / 'worker_output/INDEPENDENT_VIEW.json'
    result = load(result_path)
    require(result['status'] == 'COMPLETE_INDEPENDENT_RAW_GRAPH_AUDIT',
            'Replay is not complete; preserve UNKNOWN and inspect the saved result')
    request = load(output / 'REPLAY_REQUEST.json')
    matches(ROOT/'BUNDLE_MANIFEST.json', request['bundle_manifest'])
    matches(local('code/audit_worker.py'), request['worker'])
    matches(output/'INPUTS.bound.json', request['bound_manifest'])
    require(load(output/'INPUTS.bound.json') == bind_manifest(relative), 'Bound manifest changed')
    matches(local('code/audit_worker.py'), result['worker_pin'])
    matches(output/'INPUTS.bound.json', result['input_manifest_pin'])
    matches(view_path, result['view_pin'])
    require(view_path.read_bytes() == local('expected/INDEPENDENT_VIEW.json').read_bytes(),
            'Independent view bytes differ from the sealed original')
    ignored = {'started_utc','finished_utc','input_manifest_pin','worker_pin','view_pin'}
    old_science = {key:value for key,value in expected.items() if key not in ignored}
    new_science = {key:value for key,value in result.items() if key not in ignored}
    require(new_science == old_science, 'Scientific result fields differ from the sealed original')
    record = {'schema':'portable-arbiter-replay-comparison-v1', 'status':'PASS',
              'created_utc':datetime.now(timezone.utc).isoformat(),
              'all_scientific_result_fields_equal':True, 'independent_view_byte_identical':True,
              'ignored_top_level_metadata':sorted(ignored),
              'metadata_checks':'Relocated worker/input/view bytes and pins checked separately; timestamps differ.',
              'original_result':pin(local('expected/AUDIT_RESULT.json')), 'replayed_result':pin(result_path),
              'original_view':pin(local('expected/INDEPENDENT_VIEW.json')), 'replayed_view':pin(view_path),
              'native_runs':0, 'scope':'Reproduction of existing finite audit, not a new candidate or native result.'}
    write_new(output/'COMPARISON.json', record)
    print(json.dumps({'status':'PASS','all_scientific_result_fields_equal':True,
                      'independent_view_byte_identical':True}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('verify','run','compare'))
    parser.add_argument('output', nargs='?')
    args = parser.parse_args()
    if args.action == 'verify':
        require(args.output is None, 'verify takes no output path')
        print(json.dumps(verify()[1]))
    else:
        require(args.output is not None, 'An output path is required')
        (run if args.action == 'run' else compare)(args.output)


if __name__ == '__main__':
    main()
