"""Real worker CLI with tiny artificial contracts; no native or saved real data."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import importlib.util, json, shutil, sys

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('cli_artificial_fixtures', HERE/'qualify_artificial.py')
fixtures = importlib.util.module_from_spec(spec); spec.loader.exec_module(fixtures)
w = fixtures.w
supervisor = HERE.parents[1]/'source_model_execution_01'/'supervisor'/'bounded_process.py'
spec = importlib.util.spec_from_file_location('cli_synthetic_supervisor', supervisor)
stage = importlib.util.module_from_spec(spec); spec.loader.exec_module(stage)

ARTIFICIAL_CONTRACT = '''
# Added only to this artificial qualification copy; real-source map is excluded.
import hashlib
_RAW = b'ARTIFICIAL FIXTURE ONLY: e input, s next=e, p next=s, m next=S0.\\n'
_C = SourceContract('artificial_fixture',len(_RAW),hashlib.sha256(_RAW).hexdigest(),
    ('e',),('s',),(('m',('S0','S1')),('p',BOOL)),
    lambda s:s['e']=='false',
    lambda s:s['s']=='false' and s['m']=='S0' and s['p']=='false',
    lambda s,t:True,
    lambda s,t:t['s']==t['e'] and t['m']=='S0' and t['p']==s['s'],
    JUSTICE_FUNCTION,
    'Artificial CLI fixture only')
CONTRACTS = {_C.candidate:_C}
'''

def clean(p):
    return (p['status']=='PROCESS_COMPLETED' and p['exit_code']==0 and p['receipt_persisted']
            and p['parent_finalization_completed'] and not p['parent_aborted'] and p['owned_child_reaped']
            and p['exact_child_wait4']['exact_child_reaped'] and not p['exact_child_wait4']['authority_lost']
            and p['final_group_observation']['state']=='ABSENT' and not p['fatal_reasons'] and not p['resource_reasons']
            and all(x['complete'] for x in p['capture'].values()))

def main():
    root=Path(sys.argv[1]).resolve();root.mkdir()
    deadline=(datetime.now(timezone.utc)+timedelta(minutes=5)).isoformat()
    code_refs=[w.pin(HERE/name) for name in ('audit_worker.py','independent_core.py','source_contracts.py','qualify_artificial.py')]
    code_refs += [w.pin(__file__),w.pin(supervisor),w.pin(supervisor.with_name('owned_process.py'))]
    w.save_new(root/'PROTOCOL.json',{'schema':'independent-real-CLI-artificial-protocol-v1','code':code_refs,
        'deadline':deadline,'real_source_evaluations':0,'real_saved_DAG_evaluations':0,'native_processes':0,
        'scope':'Exact worker/core bytes, explicit qualification-only synthetic contract map; standalone bounded worker children, no mocks.'})
    # Full semantic artificial regression is separately bounded and launches no children.
    p=stage.run_bounded([sys.executable,'-I','-S','-B',str(HERE/'qualify_artificial.py'),str(root/'regression'),'--skip-cli'],
                       root/'regression_process',deadline,wall_seconds=120,rss_bytes=536870912,
                       watch_files=[root/'regression'/'QUALIFICATION.json'])
    assert clean(p),p
    regression=json.loads((root/'regression'/'QUALIFICATION.json').read_text());assert regression['status']=='PASS'
    rows=[]
    for empty in (False,True):
        runtime=root/('runtime_empty' if empty else 'runtime_nonempty');runtime.mkdir()
        for name in ('audit_worker.py','independent_core.py'):shutil.copyfile(HERE/name,runtime/name)
        justice="lambda s:([],[])" if empty else "lambda s:([s['e']=='true'],[s['s']=='true',s['p']=='true'])"
        (runtime/'source_contracts.py').write_text((HERE/'source_contracts.py').read_text()+ARTIFICIAL_CONTRACT.replace('JUSTICE_FUNCTION',justice))
        for helper in (False,True):
            outcomes=('JOB_CONTROLLER_PRINTED',) if empty else ('JOB_CONTROLLER_PRINTED','JOB_UNREALIZABLE_NO_CONTROLLER','JOB_EMPTY_MEMORY_NO_CONTROLLER')
            for outcome in outcomes:
                name=f'empty{int(empty)}_helper{int(helper)}_{outcome}'
                case=root/name;case.mkdir()
                manifest,contract=fixtures.build_fixture(case/'fixture',helper,outcome,empty)
                input_path=case/'INPUTS.json';w.save_new(input_path,manifest)
                output=case/'output';assert not output.exists()
                p=stage.run_bounded([sys.executable,'-I','-S','-B',str(runtime/'audit_worker.py'),str(input_path),str(output)],
                    case/'process',deadline,wall_seconds=30,rss_bytes=536870912,
                    watch_files=[output/'AUDIT_RESULT.json',output/'INDEPENDENT_VIEW.json'])
                assert clean(p),p
                result=json.loads((output/'AUDIT_RESULT.json').read_text())
                assert result['candidate_id']==contract.candidate and result['native_outcome']==outcome
                assert result['input_manifest_pin']==w.pin(input_path) and result['input_bindings']==manifest['inputs']
                assert result['worker_pin']==w.pin(runtime/'audit_worker.py')
                assert w.pin(runtime/'audit_worker.py')['sha256']==w.pin(HERE/'audit_worker.py')['sha256']
                assert result['source_contracts_pin']==w.pin(runtime/'source_contracts.py')
                if outcome=='JOB_CONTROLLER_PRINTED':
                    assert result['status']=='COMPLETE_INDEPENDENT_RAW_GRAPH_AUDIT'
                    assert result['view_pin']==w.pin(output/'INDEPENDENT_VIEW.json')
                    assert result['independent_strict'] is True and result['independent_cooperative'] is True
                else:
                    assert result['status']=='COMPLETE_INDEPENDENT_NO_CONTROLLER'
                    assert result['independent_strict'] is None and result['independent_cooperative'] is None
                rows.append({'name':name,'status':'PASS','result':w.pin(output/'AUDIT_RESULT.json'),
                             'process':w.pin(case/'process'/'PROCESS_RECEIPT.json'),'exact_worker_and_core_bytes':True,
                             'qualification_only_artificial_contract':w.pin(runtime/'source_contracts.py')})
    for ref in code_refs:assert w.pin(ref['path'])==ref
    result={'schema':'independent-real-CLI-artificial-qualification-v1','status':'PASS','cases':rows,
            'regression':w.pin(root/'regression'/'QUALIFICATION.json'),'regression_named_checks':regression['named_tests'],
            'regression_exhaustive_artificial_graphs':regression['exhaustive_artificial_graphs'],
            'real_source_evaluations':0,'real_saved_DAG_evaluations':0,'native_processes':0,'full_reset_uses':0,
            'code_pins':code_refs,'post_code_pin_check':'PASS'}
    w.save_new(root/'QUALIFICATION.json',result)
    print(json.dumps({'status':result['status'],'real_CLI_successes':len(rows),'regression_named_checks':regression['named_tests']}))

if __name__=='__main__':main()
