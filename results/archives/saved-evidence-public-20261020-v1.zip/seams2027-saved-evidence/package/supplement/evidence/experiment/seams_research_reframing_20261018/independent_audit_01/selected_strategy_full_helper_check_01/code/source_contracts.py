"""Independent handwritten source oracle for exactly two constructed contracts.

Original four-state source equations. No data are read and no formula is
evaluated at import. These constants are exact prospective Spectra byte pins.
"""
from dataclasses import dataclass

BOOL = ('false', 'true')
MONITOR = ('S0', 'S1')
HELPER = '~envHelp'


def truth(state, name):
    return state[name] == 'true'


def implies(a, b):
    return not a or b


def response_update(state, successor, monitor, request, response):
    # Exact four disjuncts of the source pRespondsToS declaration simplify to:
    pending = (state[monitor] == 'S1' or request) and not response
    return (successor[monitor] == 'S1') == pending


@dataclass(frozen=True)
class SourceContract:
    candidate: str
    source_bytes: int
    source_sha256: str
    env: tuple
    system: tuple
    aux: tuple
    theta_e: object
    theta_s: object
    rho_e: object
    rho_s: object
    justice: object
    timing_note: str

    @property
    def names(self):
        return self.env + self.system + tuple(name for name, _ in self.aux)

    @property
    def values(self):
        return {**{name: BOOL for name in self.env + self.system},
                **{name: values for name, values in self.aux}}

    @property
    def fields(self):
        return ([{'name': name, 'domain': list(BOOL), 'owner': 'ENV', 'role': 'ENV'} for name in self.env]
                + [{'name': name, 'domain': list(BOOL), 'owner': 'SYS', 'role': 'SYS'} for name in self.system]
                + [{'name': name, 'domain': list(values), 'owner': 'SYS', 'role': 'AUX'} for name, values in self.aux])



def initial_environment(state):
    return state['e'] == 'false'


def initial_system(state):
    return state['p'] == 'false'


def event_requires_previous_permission(state, successor):
    # Source G(next(e) -> p): the event is NEXT; permission is CURRENT.
    return successor['e'] == 'false' or state['p'] == 'true'


def unconstrained_system_step(state, successor):
    return True


def forced_permission_toggle(state, successor):
    # Source G(next(p) = !p); this does not constrain source initialization.
    return successor['p'] != state['p']


def original_justices(state):
    return ([state['e'] == 'true'], [state['p'] == 'false'])


CONTRACTS = {
    'cooperative_choice_gate': SourceContract(
        'cooperative_choice_gate', 250,
        '45165f47c7afc09211ce59bd0d8dd0bcaabbd0ba5f55dc796eab661002069521',
        ('e',), ('p',), (), initial_environment, initial_system,
        event_requires_previous_permission, unconstrained_system_step,
        original_justices,
        'ENV next(e) implies current p; unconstrained SYS transition; direct state justices e and !p; no AUX.'),
    'cooperative_forced_toggle': SourceContract(
        'cooperative_forced_toggle', 262,
        'f94fa807218cc59dae060e82fb60473163e9bd375b9537ba6e7cc496a737f983',
        ('e',), ('p',), (), initial_environment, initial_system,
        event_requires_previous_permission, forced_permission_toggle,
        original_justices,
        'ENV next(e) implies current p; SYS next(p) differs from current p; direct state justices e and !p; no AUX.'),
}
