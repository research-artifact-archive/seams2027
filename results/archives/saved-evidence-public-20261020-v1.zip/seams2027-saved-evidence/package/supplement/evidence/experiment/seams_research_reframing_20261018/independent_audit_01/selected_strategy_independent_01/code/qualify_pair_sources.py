"""Exact two-source truth tables and hand-specified artificial strategy controls.

No native process, native model, production checker, or production proof input.
The independent predicates are compared with literal truth tables, a separately
parsed profile, and finite graphs specified below without using either worker's
output as the oracle. This is prospective qualification, not native evidence.
"""
from pathlib import Path
from datetime import datetime, timezone
from itertools import product
import copy
import hashlib
import importlib.util
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
spec = importlib.util.spec_from_file_location('selected_strategy_source_worker', HERE / 'audit_worker.py')
w = importlib.util.module_from_spec(spec)
spec.loader.exec_module(w)

ORDER = ['cooperative_choice_gate', 'cooperative_forced_toggle']
STATES = [dict(zip(('e', 'p'), row)) for row in product(('false', 'true'), repeat=2)]
EXPECTED = {
    'thetaE': '1100', 'thetaS': '1010', 'ENV_justice': '0011', 'SYS_justice': '1010',
    'rhoE': ['1100', '1111', '1100', '1111'],
    'choice_rhoS': ['1111', '1111', '1111', '1111'],
    'toggle_rhoS': ['0101', '1010', '0101', '1010'],
}


def check(value, message):
    if not value:
        raise AssertionError(message)


def word(fn):
    values = [fn(state) for state in STATES]
    check(all(type(x) is bool for x in values), 'Predicate must return Boolean')
    return ''.join('1' if x else '0' for x in values)


def matrix(fn):
    return [word(lambda successor, current=current: fn(current, successor)) for current in STATES]


def actual_support(fn):
    rows = list(product((False, True), repeat=4))
    def val(row):
        return {'e': str(row[0]).lower(), 'p': str(row[1]).lower()}, {'e': str(row[2]).lower(), 'p': str(row[3]).lower()}
    names = ['current:e', 'current:p', 'next:e', 'next:p']
    support = []
    for i, name in enumerate(names):
        for row in rows:
            other = list(row); other[i] = not other[i]
            if fn(*val(row)) != fn(*val(other)):
                support.append(name); break
    return support


def verify_contract(c, profile):
    check(c.env == ('e',) and c.system == ('p',) and c.aux == (), 'Exact source public/AUX roster')
    check(profile['fixture_id'] == profile['case_id'] == c.candidate and profile['variant'] == 'initializers', 'Profile identity')
    check(profile['expected_fields_in_native_order'] == c.fields, 'Typed field order and roles')
    check(profile['public_ENV'] == ['e'] and profile['public_SYS'] == ['p'] and profile['AUX'] == [], 'Profile AUX and ownership')
    check(word(c.theta_e) == EXPECTED['thetaE'], 'thetaE literal table')
    check(word(c.theta_s) == EXPECTED['thetaS'], 'thetaS literal table')
    check(word(lambda s: c.justice(s)[0][0]) == EXPECTED['ENV_justice'], 'ENV justice literal table')
    check(word(lambda s: c.justice(s)[1][0]) == EXPECTED['SYS_justice'], 'SYS justice literal table')
    check(all(tuple(map(len, c.justice(s))) == (1, 1) for s in STATES), 'One ordered original justice per side')
    check(matrix(c.rho_e) == EXPECTED['rhoE'], 'rhoE literal 4x4 table')
    expected_system = EXPECTED['choice_rhoS' if c.candidate == ORDER[0] else 'toggle_rhoS']
    check(matrix(c.rho_s) == expected_system, 'rhoS literal 4x4 table')
    check(actual_support(c.rho_e) == ['current:p', 'next:e'], 'rhoE support and timing')
    check(actual_support(c.rho_s) == ([] if c.candidate == ORDER[0] else ['current:p', 'next:p']), 'rhoS support and timing')
    for key, fn in [('thetaE', c.theta_e), ('thetaS', c.theta_s), ('rhoE', c.rho_e), ('rhoS', c.rho_s)]:
        compiled = w.compile_profile(profile['formulas'][key], c.values, key.startswith('rho'))
        check(matrix(compiled) == matrix(fn) if key.startswith('rho') else word(compiled) == word(fn), 'Independent profile crosscheck ' + key)
    for owner, offset in [('ENV', 0), ('SYS', 1)]:
        check(len(profile['justices'][owner]) == 1, 'Profile ordered justice count')
        compiled = w.compile_profile(profile['justices'][owner][0], c.values, False)
        check(word(compiled) == word(lambda s: c.justice(s)[offset][0]), 'Profile justice crosscheck')
    initial = [state for state in STATES if c.theta_e(state) and c.theta_s(state)]
    check(initial == [{'e': 'false', 'p': 'false'}], 'Unique source initial state')
    return {'candidate_id': c.candidate, 'source_state_order': STATES,
            'thetaE': word(c.theta_e), 'thetaS': word(c.theta_s),
            'rhoE': matrix(c.rho_e), 'rhoS': matrix(c.rho_s),
            'original_justices': {'ENV': [word(lambda s: c.justice(s)[0][0])], 'SYS': [word(lambda s: c.justice(s)[1][0])]},
            'source_pairs_checked': 16, 'source_fields': c.fields, 'AUX_count': 0,
            'ENV_transition_support': actual_support(c.rho_e), 'SYS_transition_support': actual_support(c.rho_s),
            'initial_states': initial, 'original_ENV_initial_choices': 1,
            'profile_crosscheck': 'PASS'}


def rejection(name, fn, accepted):
    try:
        fn()
    except (AssertionError, w.AuditError, KeyError, ValueError):
        accepted.append(name)
        return
    raise AssertionError('Mutation accepted: ' + name)


def main():
    output = Path(sys.argv[1]).resolve(); output.mkdir()
    profile_path = ROOT / 'ORIGINAL_PROFILES.json'
    profiles = w.decode_json(profile_path.read_bytes())
    check(w.pin(profile_path)['sha256'] == '6b65a842582428e7ce4b3a2e0e6e9bfe84aa35b92e8d3bd627464ba0eb347668', 'Frozen profile bytes')
    check(list(w.CONTRACTS) == ORDER and profiles['candidate_order'] == ORDER, 'Exactly the declared independent pair')
    source_pins, rows = [], []
    for candidate in ORDER:
        c = w.CONTRACTS[candidate]; source = ROOT / 'sources' / (candidate + '.spectra')
        ref = w.pin(source); source_pins.append(ref)
        check(ref['bytes'] == c.source_bytes and ref['sha256'] == c.source_sha256, 'Exact handwritten source pin')
        check(profiles['profiles'][candidate]['source']['sha256'] == ref['sha256'], 'Profile source identity')
        rows.append(verify_contract(c, profiles['profiles'][candidate]))
    c = w.CONTRACTS[ORDER[0]]; control = w.CONTRACTS[ORDER[1]]; profile = profiles['profiles'][ORDER[0]]
    from dataclasses import replace
    mutations = []
    rejection('current-next ENV permission swap', lambda: verify_contract(replace(c, rho_e=lambda s,t: t['e']=='false' or t['p']=='true'), profile), mutations)
    rejection('current-next event swap', lambda: verify_contract(replace(c, rho_e=lambda s,t: s['e']=='false' or s['p']=='true'), profile), mutations)
    rejection('missing ENV initializer', lambda: verify_contract(replace(c, theta_e=lambda s: True), profile), mutations)
    rejection('reversed SYS initializer', lambda: verify_contract(replace(c, theta_s=lambda s: s['p']=='true'), profile), mutations)
    rejection('wrong ENV justice', lambda: verify_contract(replace(c, justice=lambda s: ([s['e']=='false'],[s['p']=='false'])), profile), mutations)
    rejection('unexpected AUX', lambda: verify_contract(replace(c, aux=(('hidden',('false','true')),)), profile), mutations)
    rejection('toggle made stuttering', lambda: verify_contract(replace(control, rho_s=lambda s,t: t['p']==s['p']), profiles['profiles'][ORDER[1]]), mutations)
    reordered = copy.deepcopy(profile); reordered['expected_fields_in_native_order'].reverse()
    rejection('profile field order reversed', lambda: verify_contract(c, reordered), mutations)
    primed = copy.deepcopy(profile); primed['formulas']['thetaS'] = ['not',['var','p',True]]
    rejection('primed initializer rejected', lambda: verify_contract(c, primed), mutations)
    # Explicit alternating strategy on all four source states. Starts include all
    # four only for a continuation-strategy proof, not as source initial states.
    good_edges = [('0','1'), ('1','0'), ('1','2'), ('2','1'), ('3','0'), ('3','2')]
    nodes = {str(i) for i in range(4)}
    for contract in (c, control):
        for i, state in enumerate(STATES):
            selected = [STATES[int(t)] for s,t in good_edges if s == str(i)]
            expected = [t for t in STATES if t['p'] != state['p'] and contract.rho_e(state,t)]
            check(selected == expected, 'Alternating graph full legal input coverage')
            check(all(contract.rho_s(state,t) for t in selected), 'Alternating graph source safety')
    good = w.finite_fairness(nodes, good_edges, sorted(nodes), [{'2','3'}], [{'0','2'}])
    check(good['strict_liveness']['pass'] is True and good['nonconflicting']['pass'] is True, 'Explicit all-state alternating strategy')
    bad = w.finite_fairness({'0'}, [('0','0')], ['0'], [set()], [{'0'}])
    check(c.theta_e(STATES[0]) and c.theta_s(STATES[0]) and c.rho_e(STATES[0],STATES[0]) and c.rho_s(STATES[0],STATES[0]), 'Primary bad strategy source coverage')
    check(bad['strict_liveness']['pass'] is True and bad['nonconflicting']['pass'] is False, 'Explicit blocking strategy')
    check(not control.rho_s(STATES[0],STATES[0]), 'Control excludes the primary bad self-loop')
    result = {'schema': 'selected-strategy-independent-source-qualification-v1', 'status': 'PASS',
              'completed_utc': datetime.now(timezone.utc).isoformat(), 'rows': rows,
              'hand_table_state_order': ['e=false,p=false','e=false,p=true','e=true,p=false','e=true,p=true'],
              'literal_expected_tables': EXPECTED, 'mutation_rejections': mutations,
              'constructive_strategy_controls': {
                  'alternating': {'edges': good_edges, 'all_four_continuation_starts': True, 'strict': True, 'nonconflicting': True},
                  'primary_constant_false': {'source_initial_node': '0', 'edges': [['0','0']], 'strict': True, 'nonconflicting': False},
                  'forced_toggle_excludes_blocking_self_loop': True,
                  'scope': 'Hand-declared artificial strategies, not predicted or observed native extraction.'},
              'source_pins': source_pins, 'profile_pin': w.pin(profile_path),
              'code_pins': [w.pin(HERE/name) for name in ['audit_worker.py','independent_core.py','source_contracts.py','qualify_pair_sources.py']],
              'native_calls': 0, 'native_saved_DAG_evaluations': 0, 'production_checker_imports': 0,
              'production_proof_inputs': 0, 'region_fixed_point_solves': 0, 'full_reset_uses': 0}
    w.save_new(output/'QUALIFICATION.json',result)
    print(json.dumps({'status':'PASS','sources':2,'source_pairs_per_case':16,'mutation_rejections':len(mutations),'native_calls':0}))


if __name__ == '__main__':
    main()
