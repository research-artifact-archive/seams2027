"""Full transformed-relation truth check from saved DAGs; no native or graph solve."""
from pathlib import Path
import importlib.util,json,sys,traceback
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('pair_full_independent',HERE/'audit_worker.py');w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)

def check(manifest,contract):
    need=w.need
    inputs=manifest['inputs'];raw={name:w.read_pin(ref) for name,ref in inputs.items()}
    need(w.pin(inputs['source']['path'])['sha256']==contract.source_sha256 and len(raw['source'])==contract.source_bytes,'Exact source bytes')
    profile=w.decode_json(raw['profile'])['profiles'][contract.candidate];model=w.decode_json(raw['model']);result=w.decode_json(raw['native_result'])
    need(model['schema']=='k7-native-model-export-v1' and model['fixture_id']==model['case_id']==contract.candidate and model['variant']=='initializers','Exact native model identity')
    need(model['input']['sha256']==contract.source_sha256 and model['input']['bytes']==contract.source_bytes,'Model source binding')
    need(result['input_sha256']==contract.source_sha256 and result['model_export']=={'file':Path(inputs['model']['path']).name,'bytes':inputs['model']['bytes'],'sha256':inputs['model']['sha256']} and result['helper_added'] is True,'Native source/model/helper binding')
    for ref in manifest['bdd_files'].values():w.read_pin(ref)
    ctx=w.ModelAudit(manifest,contract,raw,result,model,profile)
    need(not contract.aux and contract.env==('e',) and contract.system==('p',),'Exact constructed carrier without AUX')
    states=w.states_for(ctx.names,ctx.values,8);need(len(states)==8,'Eight complete typed states')
    source_states=w.states_for(contract.names,contract.values,4)
    for s in source_states:
        for name,fn in (('thetaE',contract.theta_e),('thetaS',contract.theta_s)):
            need(ctx.profile_formulas[name](s)==fn(s),'Profile/source initializer')
        for t in source_states:
            for name,fn in (('rhoE',contract.rho_e),('rhoS',contract.rho_s)):
                need(ctx.profile_formulas[name](s,t)==fn(s,t),'Profile/source transition')
        for owner,expected in zip(('ENV','SYS'),contract.justice(s)):
            need([fn(s) for fn in ctx.profile_justices[owner]]==expected,'Profile/source justice')
    roots=ctx.native_formulas;rows=[]
    for s in states:
        cb=ctx.bits(s);h=s[w.HELPER]=='true'
        expected={'thetaE':contract.theta_e(s) and not h,'thetaS':contract.theta_s(s)}
        need({name:roots[name].value(cb) for name in expected}==expected,'Full transformed initialization')
        for t in states:
            hb=t[w.HELPER]=='true';joined=cb|ctx.bits(t,True)
            expect_e=(contract.rho_e(s,t) or hb) and (not h or hb)
            expect_s=contract.rho_s(s,t) or h
            need(roots['rhoE'].value(joined)==expect_e,'Full transformed ENV relation / next-helper / monotonicity')
            need(roots['rhoS'].value(joined)==expect_s,'Full transformed SYS relation / current-helper')
            rows.append({'current':s,'next':t,'rhoE':expect_e,'rhoS':expect_s})
    phases={'original':model['original_justices'],'preconstructor':result['preconstructor_justices'],'solver':result['solver_justices']}
    for phase,justice in phases.items():
        need(set(justice)=={'ENV','SYS'} and len(justice['ENV'])==2 and len(justice['SYS'])==1,'Exact ordered justice count '+phase)
        env=[ctx.dag(ref,ctx.current) for ref in justice['ENV']];system=[ctx.dag(ref,ctx.current) for ref in justice['SYS']]
        for s in states:
            cb=ctx.bits(s);expected_e,expected_s=contract.justice(s)
            need([r.value(cb) for r in env]==expected_e+[s[w.HELPER]=='false'] and [r.value(cb) for r in system]==expected_s,'Full ordered justice truth '+phase)
    for name,allowed in (('domain',ctx.current),('domain_ENV_next',ctx.env_next),('domain_SYS_next',ctx.sys_next)):
        root=ctx.dag(model['original_bdds'][name],allowed)
        for s in states:need(root.value(ctx.bits(s,name!='domain')),'Full typed domain '+name)
    inverse={bit:{'name':name,'timing':timing} for name,f in ctx.field_by_name.items() for timing,key in (('current','current_bits'),('next','next_bits')) for bit in f[key]}
    return {'status':'COMPLETE_FULL_HELPER_CORRESPONDENCE','candidate_id':contract.candidate,'typed_states':8,'typed_pairs':64,'initial_states_checked':8,'ordered_justice_phases':list(phases),'source_profile_states':4,'source_profile_pairs':16,'native_formula_support':{name:[dict(inverse[bit],bit=bit) for bit in sorted(root.support)] for name,root in roots.items()},'truth_table':rows,'input_bindings':manifest,'strict':None,'cooperation':None,'controller_graph_evaluations':0,'region_solves':0,'native_processes':0}

def execute(protocol):
    w.need(protocol['schema']=='selected-strategy-full-helper-protocol-v1','Exact full-helper protocol schema')
    w.read_pin(protocol['released_transformation_source'])
    rows=[]
    for ref,candidate in zip(protocol['input_manifests'],('cooperative_choice_gate','cooperative_forced_toggle')):
        manifest=w.decode_json(w.read_pin(ref));w.need(manifest['schema']=='selected-strategy-independent-audit-inputs-v1' and manifest['candidate_id']==candidate,'Exact pair input identity')
        row=check(manifest,w.CONTRACTS[candidate]);row['input_manifest_pin']=ref;rows.append(row)
    w.need(len(protocol['input_manifests'])==len(rows)==2,'Exactly two pair manifests')
    return {'status':'COMPLETE_PAIR_FULL_HELPER_CORRESPONDENCE','cases':rows,'native_processes':0,'full_reset_uses':0}

def main():
    output=Path(sys.argv[2]);output.mkdir()
    try:
        result=execute(w.decode_json(Path(sys.argv[1]).read_bytes()));result['protocol_pin']=w.pin(sys.argv[1]);result['code_pins']=[w.pin(HERE/name) for name in ('full_helper_worker.py','audit_worker.py','source_contracts.py','independent_core.py')];code=0
    except BaseException as error:result={'status':'UNKNOWN_FULL_HELPER_CORRESPONDENCE','error':type(error).__name__+':'+str(error),'traceback':traceback.format_exc()};code=2
    w.save_new(output/'FULL_HELPER_RESULT.json',result);print(json.dumps({'status':result['status']}),flush=True);return code
if __name__=='__main__':sys.exit(main())
