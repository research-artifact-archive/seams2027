"""Prospective source-coded policy; no graph construction at import.

One private priority bit, distinct from the three logical source AUX monitors.
No native solver, saved region, rank, controller, or repair is consulted.
"""
ENV = ('b1', 'b2', 'b3', 'c')
SYS = ('f1', 'f2', 'f3')
AUX = tuple(f'SYS_CONSTRAINT.{i}.pRespondsToS.state' for i in range(3))
FIELDS = ENV + SYS + AUX
INITIAL_PRIORITY = 3


def initial_states():
    result = []
    for cancel in ('false', 'true'):
        valuation = dict(b1='false', b2='false', b3='false', c=cancel,
                         f1='true', f2='false', f3='false')
        valuation.update({name: 'S0' for name in AUX})
        result.append((valuation, INITIAL_PRIORITY))
    return result


def legal_environment(current, successor_environment):
    """Direct source clauses, independently checked against frozen source oracle."""
    if sum(current[f] == 'true' for f in SYS) != 1:
        return False
    for button, floor in zip(ENV[:3], SYS):
        if current[button] == 'true' and current[floor] == 'true':
            if successor_environment[button] != 'false':
                return False
        if current[button] == 'true' and current[floor] == 'false' and current['c'] == 'false':
            if successor_environment[button] != 'true':
                return False
    return True


def step(current, priority, successor_environment):
    assert type(priority) is int and priority in (1, 3)
    assert sum(current[f] == 'true' for f in SYS) == 1
    floor = next(i for i, name in enumerate(SYS, 1) if current[name] == 'true')
    b1, b2, b3 = [current[name] == 'true' for name in ENV[:3]]
    if floor == 1:
        target = 2 if b2 or b3 else 1
    elif floor == 3:
        target = 2 if b1 or b2 else 3
    elif b1 and b3:
        target = priority
    elif b1:
        target = 1
    elif b3:
        target = 3
    else:
        target = 2
    next_priority = 4 - target if floor == 2 and target != 2 else priority
    successor = dict(successor_environment)
    successor.update({name: 'true' if i == target else 'false' for i, name in enumerate(SYS, 1)})
    for monitor, button, floor_name in zip(AUX, ENV[:3], SYS):
        pending = current[monitor] == 'S1' or current[button] == 'true'
        answered_now = current[floor_name] == 'true' or current['c'] == 'true'
        successor[monitor] = 'S1' if pending and not answered_now else 'S0'
    return successor, next_priority
