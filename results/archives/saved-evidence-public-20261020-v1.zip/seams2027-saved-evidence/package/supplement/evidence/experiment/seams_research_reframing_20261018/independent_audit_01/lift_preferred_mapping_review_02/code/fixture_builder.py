"""Artificial end-to-end audit fixtures only; no nine-source/DAG evaluations."""
from pathlib import Path
from itertools import product
from datetime import datetime, timezone
import copy
import hashlib
import importlib.util
import json
import sys
import time
import subprocess

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('artificial_audit_worker', HERE / 'audit_worker.py')
w = importlib.util.module_from_spec(spec)
spec.loader.exec_module(w)
SourceContract = sys.modules['source_contracts'].SourceContract
BOOL, MON = ('false', 'true'), ('S0', 'S1')
tests = []


def check(name, value):
    if not value:
        raise AssertionError(name)
    tests.append(name)


def reject(name, fn, expected=None):
    try:
        fn()
    except (w.AuditError, ValueError, KeyError, TypeError) as error:
        if expected is not None and expected not in str(error):
            raise AssertionError(name + ': wrong rejection ' + str(error))
        tests.append(name + ': ' + str(error))
        return
    raise AssertionError(name + ': accepted')


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, separators=(',', ':')) + '\n')


def bdd_bytes(variable_count, fn, support=None):
    """Test-only Shannon tree constructor; production audit only follows saved DAGs."""
    nodes, unique = {}, {}
    assignment = {}

    variables = list(range(variable_count)) if support is None else sorted(support)
    def descend(level):
        if level == len(variables):
            return int(bool(fn(assignment)))
        var = variables[level]
        assignment[var] = False; low = descend(level + 1)
        assignment[var] = True; high = descend(level + 1)
        if low == high:
            return low
        key = (var, low, high)
        if key not in unique:
            identity = len(nodes) + 2
            unique[key] = identity; nodes[identity] = key
        return unique[key]

    root = descend(0)
    if root in (0, 1):
        return f'0 {root}\n'.encode()
    reachable, stack = set(), [root]
    while stack:
        node = stack.pop()
        if node in (0, 1) or node in reachable:
            continue
        reachable.add(node); stack.extend(nodes[node][1:])
    rows = [str(variable_count), ' '.join(map(str, range(variable_count)))]
    rows += [' '.join(map(str, (node,) + nodes[node])) for node in sorted(reachable)]
    return ('\n'.join(rows) + '\n').encode()


def synthetic_contract(empty_justice=False):
    raw = b'ARTIFICIAL FIXTURE ONLY: e input, s next=e, p next=s, m next=S0.\n'
    contract = SourceContract('artificial_fixture', len(raw), hashlib.sha256(raw).hexdigest(),
        ('e',), ('s',), (('m', MON), ('p', BOOL)),
        lambda s: s['e'] == 'false',
        lambda s: s['s'] == 'false' and s['m'] == 'S0' and s['p'] == 'false',
        lambda s, t: True,
        lambda s, t: t['s'] == t['e'] and t['m'] == 'S0' and t['p'] == s['s'],
        (lambda s: ([], [])) if empty_justice else (lambda s: ([s['e'] == 'true'], [s['s'] == 'true', s['p'] == 'true'])),
        'Artificial fixture, unrelated to the nine pinned sources')
    return raw, contract


def build_fixture(folder, helper=False, outcome='JOB_CONTROLLER_PRINTED', empty_justice=False):
    folder.mkdir()
    raw, c = synthetic_contract(empty_justice)
    source = folder / 'synthetic.source'; source.write_bytes(raw)
    names = c.env + (('~envHelp',) if helper else ()) + c.system + ('m', 'p')
    values = dict(c.values)
    if helper:
        values['~envHelp'] = BOOL
    fields = []
    for i, name in enumerate(names):
        owner = 'ENV' if name in c.env + (('~envHelp',) if helper else ()) else 'SYS'
        fields.append({'name': name, 'owner': owner, 'role': 'ENV' if owner == 'ENV' else 'SYS' if name in c.system else 'AUX',
                       'domain_size': 2, 'values': list(values[name]), 'current_bits': [2*i], 'next_bits': [2*i+1],
                       'encoding': {value: {'current': {str(2*i): bool(j)}, 'next': {str(2*i+1): bool(j)}}
                                    for j, value in enumerate(values[name])}})
    count = len(names) * 2
    def valuation(bits, prime=False):
        return {name: values[name][int(bits[2*i + int(prime)])] for i, name in enumerate(names)}
    def encode(state):
        return {str(2*i): state[name] == values[name][1] for i, name in enumerate(names)}
    bdd_files = {}
    def write_dag(name, fn):
        path = folder / (name + '.bdd'); data = bdd_bytes(count, lambda b: fn(valuation(b), valuation(b, True)))
        path.write_bytes(data); ref = w.pin(path); bdd_files[path.name] = ref
        return {'file': path.name, 'bytes': ref['bytes'], 'sha256': ref['sha256']}
    theta_e = lambda s, t: c.theta_e(s) and (not helper or s['~envHelp'] == 'false')
    theta_s = lambda s, t: c.theta_s(s)
    rho_e = lambda s, t: not helper or s['~envHelp'] == 'false' or t['~envHelp'] == 'true'
    rho_s = lambda s, t: c.rho_s(s, t)
    original_bdds = {key: write_dag('original_' + key, fn) for key, fn in
                     [('thetaE', theta_e), ('thetaS', theta_s), ('rhoE', rho_e), ('rhoS', rho_s)]}
    original_bdds.update({key: write_dag(key, lambda s, t: True) for key in ('domain', 'domain_ENV_next', 'domain_SYS_next')})
    env_js = ([] if empty_justice else [lambda s, t: s['e'] == 'true']) + ([lambda s, t: s['~envHelp'] == 'false'] if helper else [])
    sys_js = [] if empty_justice else [lambda s, t: s['s'] == 'true', lambda s, t: s['p'] == 'true']
    original_js = {owner: [write_dag(f'original_{owner}_justice_{i}', fn) for i, fn in enumerate(fs)]
                   for owner, fs in [('ENV', env_js), ('SYS', sys_js)]}
    pre_js = {owner: [write_dag(f'preconstructor_{owner}_justice_{i}', fn) for i, fn in enumerate(fs)]
              for owner, fs in [('ENV', env_js), ('SYS', sys_js)]}
    solver_js = {owner: [write_dag(f'solver_{owner}_justice_{i}', fn) for i, fn in enumerate(fs or [lambda s, t: True])]
                 for owner, fs in [('ENV', env_js), ('SYS', sys_js)]}
    model = {'fixture_id': c.candidate, 'case_id': c.candidate, 'variant': 'initializers', 'schema': 'k7-native-model-export-v1',
             'input': {'path': str(source.resolve()), 'bytes': c.source_bytes, 'sha256': c.source_sha256},
             'fields': fields, 'all_current_bits': list(range(0, count, 2)), 'all_next_bits': list(range(1, count, 2)),
             'bdd_variable_count': count, 'bdd_variable_order': list(range(count)), 'original_bdds': original_bdds,
             'original_justices': original_js,
             'source_inventory': {'parsed': {'ENV': {'variables': [{'name': 'e'}]}, 'SYS': {'variables': [{'name': 's'}]}}}}
    model_path = folder / 'model.json'; dump(model_path, model)
    profile = {'fixture_id': c.candidate, 'case_id': c.candidate, 'variant': 'initializers', 'source': w.pin(source),
               'public_ENV': ['e'], 'public_SYS': ['s'], 'expected_fields_in_native_order': c.fields,
               'formulas': {'thetaE': ['not', ['var', 'e', False]],
                            'thetaS': ['and', ['not', ['var', 's', False]], ['eq', 'm', 'S0', False], ['not', ['var', 'p', False]]],
                            'rhoE': True,
                            'rhoS': ['and', ['iff', ['var', 's', True], ['var', 'e', True]],
                                     ['eq', 'm', 'S0', True], ['iff', ['var', 'p', True], ['var', 's', False]]]},
               'justices': {'ENV': [] if empty_justice else [['var', 'e', False]],
                            'SYS': [] if empty_justice else [['var', 's', False], ['var', 'p', False]]}}
    profile_path = folder / 'profile.json'; dump(profile_path, {'profiles': {c.candidate: profile}})
    process = {'status': 'PROCESS_COMPLETED', 'exit_code': 0, 'owned_child_reaped': True,
               'final_group_observation': {'state': 'ABSENT'}, 'fatal_reasons': [], 'resource_reasons': [],
               'capture': {'stdout': {'complete': True}, 'stderr': {'complete': True}}}
    process_path = folder / 'native_process.json'; dump(process_path, process)
    returned = outcome == 'JOB_CONTROLLER_PRINTED'; false = outcome == 'JOB_UNREALIZABLE_NO_CONTROLLER'
    result = {'fixture_id': c.candidate, 'case_id': c.candidate, 'variant': 'initializers', 'status': outcome,
              'teardown': 'COMPLETED', 'native_solver_calls': 1, 'pipeline': 'released_syntactic_kind_job_equivalent',
              'solver': '4fp', 'configuration': w.CONFIGURATION, 'initializers_replaced': False,
              'semantic_reduction_used': False, 'ENV_justice_normalization_used': False,
              'input_sha256': c.source_sha256, 'model_export': w.pin(model_path), 'helper_added': helper,
              'helper_is_native_nonaux_ENV': helper, 'preconstructor_justices': pre_js, 'solver_justices': solver_js,
              'native_initial_verdict': not false, 'memory_complete': True, 'memory_empty_guard_called': not false,
              'memory_empty': outcome == 'JOB_EMPTY_MEMORY_NO_CONTROLLER', 'controller_extraction_calls': int(returned),
              'native_printer_calls': int(returned), 'native_memory_identity': 123,
              'same_native_memory_passed_to_constructor': True, 'same_native_model_passed_to_constructor': True}
    inputs = {'source': w.pin(source), 'profile': w.pin(profile_path), 'model': w.pin(model_path), 'native_process': w.pin(process_path)}
    if returned:
        inputs_env = c.env + (('~envHelp',) if helper else ())
        # The reachable 4-state source controller, doubled only by the synthetic helper.
        rows = [{'e': e, 's': e, 'm': 'S0', 'p': p, **({'~envHelp': h} if helper else {})}
                for h in (BOOL if helper else ('false',)) for e, p in product(BOOL, repeat=2)]
        index = {tuple(s[n] for n in names): str(i) for i, s in enumerate(rows)}
        nodes = []
        for i, state in enumerate(rows):
            succ = []
            for inp in product(*(values[n] for n in inputs_env)):
                t = dict(zip(inputs_env, inp)); t.update(s=t['e'], m='S0', p=state['s'])
                if rho_e(state, t):
                    succ.append(index[tuple(t[n] for n in names)])
            body = '<' + ', '.join(n + ':' + state[n] for n in names) + '>'
            nodes.append({'id': str(i), 'native_id': i, 'initial': theta_e(state, state) and theta_s(state, state),
                          'rank': 0, 'rank_class': 'tau.smlab.syntech.games.gr1.GR1RankInfo', 'rank_info': 'artificial rank 0',
                          'valuation': state, 'bits': encode(state), 'native_bdd_text': body, 'successors': succ})
        graph = {'fixture_id': c.candidate, 'case_id': c.candidate, 'variant': 'initializers',
                 'schema': 'released-kind-complete-native-controller-v1', 'complete': True, 'initialization': 'source_initializers',
                 'helper_policy': 'unchanged_native_graph_with_helper', 'model_sha256': inputs['model']['sha256'],
                 'native_memory_identity': 123, 'rank_domain_size': len(sys_js) or 1, 'nodes': nodes,
                 'api_state_count': len(nodes), 'edges': [[n['id'], t] for n in nodes for t in n['successors']]}
        graph['api_transition_count'] = len(graph['edges'])
        graph_path = folder / 'controller.json'; dump(graph_path, graph)
        printer_path = folder / 'controller.txt'; printer_path.write_text(printer_text(graph))
        result.update(controller_export=w.pin(graph_path), printed_controller=w.pin(printer_path),
                      controller_before_print_sha256=hashlib.sha256(graph_path.read_bytes()[:-1]).hexdigest(),
                      controller_after_print_sha256=hashlib.sha256(graph_path.read_bytes()[:-1]).hexdigest())
        inputs.update(controller=w.pin(graph_path), printer=w.pin(printer_path))
    result_path = folder / 'result.json'; dump(result_path, result); inputs['native_result'] = w.pin(result_path)
    manifest = {'schema': 'remaining-nine-independent-audit-inputs-v1', 'candidate_id': c.candidate,
                'inputs': inputs, 'bdd_files': bdd_files}
    dump(folder / 'INPUTS.json', manifest)
    return manifest, c


def printer_text(graph):
    lines = []
    for node in graph['nodes']:
        lines += [('Initial State ' if node['initial'] else 'State ') + node['id'] + ' ' + node['native_bdd_text'],
                  '\tWith successors : ' + ', '.join(node['successors']) if node['successors'] else '\tWith no successors.']
    return '\n'.join(lines) + '\n'


def mutate_fixture(root, base, name, logical, mutation):
    import shutil
    folder = root / name; shutil.copytree(base, folder)
    manifest = json.loads((folder / 'INPUTS.json').read_text())
    for refs in (manifest['inputs'], manifest['bdd_files']):
        for ref in refs.values():
            ref['path'] = str((folder / Path(ref['path']).name).resolve())
    target = Path(manifest['inputs'][logical]['path'])
    value = json.loads(target.read_text()); mutation(value); dump(target, value)
    result_path = folder / 'result.json'; result = json.loads(result_path.read_text())
    if logical == 'model':
        manifest['inputs']['model'] = w.pin(target); result['model_export'] = w.pin(target)
        if 'controller' in manifest['inputs']:
            gp = folder / 'controller.json'; graph = json.loads(gp.read_text()); graph['model_sha256'] = w.pin(target)['sha256']; dump(gp, graph)
            manifest['inputs']['controller'] = w.pin(gp); result['controller_export'] = w.pin(gp)
            digest = hashlib.sha256(gp.read_bytes()[:-1]).hexdigest()
            result['controller_before_print_sha256'] = result['controller_after_print_sha256'] = digest
    elif logical == 'controller':
        pp = folder / 'controller.txt'; pp.write_text(printer_text(value))
        manifest['inputs']['printer'] = w.pin(pp); result['printed_controller'] = w.pin(pp)
        manifest['inputs']['controller'] = w.pin(target); result['controller_export'] = w.pin(target)
        digest = hashlib.sha256(target.read_bytes()[:-1]).hexdigest()
        result['controller_before_print_sha256'] = result['controller_after_print_sha256'] = digest
    elif logical == 'native_result':
        result = value
    else:
        manifest['inputs'][logical] = w.pin(target)
    dump(result_path, result); manifest['inputs']['native_result'] = w.pin(result_path)
    dump(folder / 'INPUTS.json', manifest)
    return manifest


def mutate_dag(root, base, name, file_name, data):
    manifest = mutate_fixture(root, base, name, 'native_result', lambda result: None)
    folder = root / name
    path = folder / file_name; path.write_bytes(data); actual = w.pin(path)
    manifest['bdd_files'][file_name] = actual
    def replace(value):
        if type(value) is dict:
            if value.get('file') == file_name:
                value.update(bytes=actual['bytes'], sha256=actual['sha256'])
            for child in value.values():
                replace(child)
        elif type(value) is list:
            for child in value:
                replace(child)
    model_path = folder / 'model.json'; model = json.loads(model_path.read_text()); replace(model); dump(model_path, model)
    manifest['inputs']['model'] = w.pin(model_path)
    result_path = folder / 'result.json'; result = json.loads(result_path.read_text()); replace(result); result['model_export'] = w.pin(model_path)
    if 'controller' in manifest['inputs']:
        graph_path = folder / 'controller.json'; graph = json.loads(graph_path.read_text()); graph['model_sha256'] = w.pin(model_path)['sha256']; dump(graph_path, graph)
        manifest['inputs']['controller'] = w.pin(graph_path); result['controller_export'] = w.pin(graph_path)
        digest = hashlib.sha256(graph_path.read_bytes()[:-1]).hexdigest()
        result['controller_before_print_sha256'] = result['controller_after_print_sha256'] = digest
    dump(result_path, result); manifest['inputs']['native_result'] = w.pin(result_path)
    dump(folder / 'INPUTS.json', manifest)
    return manifest


def core_tests():
    dag = w.SavedDag(b'3\n2 0 1\n2 1 0 1\n3 0 2 1\n4 2 3 2\n', 3, [2, 0, 1])
    for row in product((False, True), repeat=3):
        check('synthetic reordered DAG row ' + str(row), dag.value(dict(enumerate(row))) == (row[1] or (not row[2] and row[0])))
    for val in (False, True):
        check('terminal ' + str(val), w.SavedDag(f'0 {int(val)}\n'.encode(), 3, [2, 0, 1]).value({}) == val)
    for name, data, count, order in [
        ('wrong order', b'2\n1 0\n2 0 0 1\n', 2, [0, 1]),
        ('forward child', b'2\n0 1\n2 0 3 1\n', 2, [0, 1]),
        ('unreduced', b'2\n0 1\n2 0 1 1\n', 2, [0, 1]),
        ('unreachable', b'2\n0 1\n2 1 0 1\n3 0 0 1\n', 2, [0, 1]),
        ('reverse levels', b'2\n0 1\n2 0 0 1\n3 1 0 2\n', 2, [0, 1])]:
        reject('DAG ' + name, lambda d=data, c=count, o=order: w.SavedDag(d, c, o))
    reject('missing assignment', lambda: dag.value({}))
    vertices = {'0', '1', '2'}; possible = [(a, b) for a in sorted(vertices) for b in sorted(vertices)]
    for mask in range(512):
        edges = {edge for i, edge in enumerate(possible) if mask & (1 << i)}
        expected = {(v, v) for v in vertices} | edges
        for _ in vertices:
            expected |= {(a, c) for a, b in tuple(expected) for b2, c in edges if b == b2}
        order, pos, rows = w.closure(vertices, edges)
        actual = {(a, b) for a in order for b in order if rows[pos[a]] & (1 << pos[b])}
        if actual != expected:
            raise AssertionError('Closure mismatch: ' + str(mask))
    tests.append('all 512 directed artificial three-node graphs: independent bounded-path oracle')
    examples = [
        ('dead end', {'0'}, [], ['0'], [{'0'}], [{'0'}], True, False),
        ('fair singleton', {'0'}, [('0','0')], ['0'], [{'0'}], [{'0'}], True, True),
        ('missing guarantee', {'0'}, [('0','0')], ['0'], [{'0'}], [set()], False, True),
        ('induced SCC', {'0','1'}, [('0','1'),('1','0'),('1','1')], ['0'], [{'1'}], [{'0'}], False, True),
        ('bad initial branch', {'0','1'}, [('0','0')], ['0','1'], [{'0'}], [{'0'}], True, False),
        ('multiple justices', {'0','1'}, [('0','1'),('1','0')], ['0'], [{'0'},{'1'}], [{'0'},{'1'}], True, True),
        ('empty justice cycle', {'0'}, [('0','0')], ['0'], [], [], True, True),
        ('empty justice dead end', {'0'}, [], ['0'], [], [], True, False),
        ('unfair cycle', {'0'}, [('0','0')], ['0'], [set()], [set()], True, False)]
    for name, states, edges, starts, env, system, strict, cooperative in examples:
        ans = w.finite_fairness(states, edges, starts, env, system)
        check('fairness ' + name, ans['strict_liveness']['pass'] == strict and ans['nonconflicting']['pass'] == cooperative)
    reject('unreachable view', lambda: w.finite_fairness({'0','1'}, [('0','0'),('1','1')], ['0'], [], []))


def main():
    out = Path(sys.argv[1]).resolve(); out.mkdir()
    started = time.monotonic(); core_tests()
    bases = {}
    for helper, empty in product((False, True), repeat=2):
        name = f'valid_helper{int(helper)}_empty{int(empty)}'; folder = out / name
        manifest, contract = build_fixture(folder, helper=helper, empty_justice=empty)
        answer, view = w.audit(manifest, {contract.candidate: contract})
        check(name, answer['status'] == 'COMPLETE_INDEPENDENT_RAW_GRAPH_AUDIT'
              and answer['independent_strict'] is True and answer['independent_cooperative'] is True
              and answer['source_correspondence']['original_typed_states'] == 16
              and answer['source_correspondence']['original_state_pairs_checked'] == 256)
        bases[(helper, empty)] = (folder, contract)
    for helper, outcome in product((False, True), ('JOB_UNREALIZABLE_NO_CONTROLLER', 'JOB_EMPTY_MEMORY_NO_CONTROLLER')):
        manifest, contract = build_fixture(out / f'valid_{int(helper)}_{outcome}', helper=helper, outcome=outcome, empty_justice=True)
        answer, view = w.audit(manifest, {contract.candidate: contract})
        check('no-controller ' + str(helper) + outcome, answer['status'] == 'COMPLETE_INDEPENDENT_NO_CONTROLLER'
              and answer['independent_strict'] is None and answer['independent_cooperative'] is None and view is None)
        if helper:
            bad = mutate_dag(out, out / f'valid_{int(helper)}_{outcome}', 'mutant_extra_helper_initial_' + outcome,
                             'original_thetaE.bdd', bdd_bytes(10, lambda b: not b[0], [0]))
            reject('no-controller extra helper initial ' + outcome,
                   lambda m=bad, c=contract: w.audit(m, {c.candidate: c}), 'Full native initial ENV/helper')
    base, contract = bases[(False, False)]
    variants = [
        ('wrong_owner', 'model', lambda x: x['fields'][-1].update(owner='ENV'), 'owner/AUX'),
        ('missing_field', 'model', lambda x: x['fields'].pop(), 'field order'),
        ('encoding_alias', 'model', lambda x: x['fields'][0]['encoding']['true'].update(current=x['fields'][0]['encoding']['false']['current']), 'Bijective'),
        ('bit_overlap', 'model', lambda x: x['fields'][1].update(current_bits=x['fields'][0]['current_bits']), 'Disjoint'),
        ('extra_helper_flag', 'native_result', lambda x: x.update(helper_added=True, helper_is_native_nonaux_ENV=True), 'field order'),
        ('profile_init', 'profile', lambda x: x['profiles']['artificial_fixture']['formulas'].update(thetaE=True), 'initializer mismatch'),
        ('profile_next_swap', 'profile', lambda x: x['profiles']['artificial_fixture']['formulas'].update(rhoS=['iff',['var','s',False],['var','e',True]]), 'transition timing'),
        ('profile_justice', 'profile', lambda x: x['profiles']['artificial_fixture']['justices'].update(ENV=[['not',['var','e',False]]]), 'justice mismatch'),
        ('bad_rank', 'controller', lambda x: x['nodes'][0].update(rank=2), 'rank/private'),
        ('missing_initial', 'controller', lambda x: x['nodes'][0].update(initial=False), 'initial private'),
        ('graph_field_missing', 'controller', lambda x: x['nodes'][0]['valuation'].pop('p'), 'node valuation'),
        ('graph_bits', 'controller', lambda x: x['nodes'][0]['bits'].update({'0': True}), 'bits/value'),
        ('graph_duplicate_response', 'controller', lambda x: x['nodes'][0]['successors'].append(x['nodes'][0]['successors'][0]), 'Unique native successors'),
        ('bad_native_gate', 'native_result', lambda x: x.update(memory_empty=True), 'extraction gate'),
        ('wrong_native_config', 'native_result', lambda x: x['configuration'].update(optChoice='changed'), 'configuration'),
        ('process_incomplete', 'native_process', lambda x: x['capture']['stdout'].update(complete=False), 'process incomplete'),
        ('justice_order', 'profile', lambda x: x['profiles']['artificial_fixture']['justices']['SYS'].reverse(), 'justice mismatch'),
    ]
    for name, logical, mutate, reason in variants:
        manifest = mutate_fixture(out, base, 'mutant_' + name, logical, mutate)
        reject(name, lambda m=manifest: w.audit(m, {contract.candidate: contract}), reason)
    def remove_edge(g):
        # Remove the initial self-loop so all nodes remain reachable by the other edge.
        target = g['nodes'][0]['successors'].pop(0)
        g['edges'].remove(['0', target]); g['api_transition_count'] -= 1
    manifest = mutate_fixture(out, base, 'mutant_missing_legal_edge', 'controller', remove_edge)
    reject('semantic legal edge missing in all representations', lambda: w.audit(manifest, {contract.candidate: contract}), 'legal-input coverage')
    # Labels alone do not establish helper presence; unchanged legacy label remains accepted.
    manifest = mutate_fixture(out, base, 'harmless_policy_label', 'controller', lambda x: x.update(helper_policy='label_is_not_semantics'))
    answer, _ = w.audit(manifest, {contract.candidate: contract})
    check('policy label not used as helper evidence', answer['status'] == 'COMPLETE_INDEPENDENT_RAW_GRAPH_AUDIT')
    empty_base, empty_contract = bases[(False, True)]
    bad = mutate_dag(out, empty_base, 'mutant_false_TRUE_padding', 'solver_SYS_justice_0.bdd', b'0 0\n')
    reject('wrong constructor TRUE padding', lambda: w.audit(bad, {empty_contract.candidate: empty_contract}), 'TRUE-padding semantics')
    bad = mutate_fixture(out, empty_base, 'mutant_padded_preconstructor', 'native_result',
                         lambda x: x['preconstructor_justices'].update(SYS=x['solver_justices']['SYS']))
    reject('constructor padding must not be preconstructor', lambda: w.audit(bad, {empty_contract.candidate: empty_contract}), 'TRUE-padding count')
    false_base = out / 'valid_0_JOB_UNREALIZABLE_NO_CONTROLLER'
    bad = mutate_fixture(out, false_base, 'mutant_false_verdict_profile_init', 'profile',
                         lambda x: x['profiles']['artificial_fixture']['formulas'].update(thetaS=True))
    reject('false verdict does not skip original model mapping', lambda: w.audit(bad, {empty_contract.candidate: empty_contract}), 'initializer mismatch')
    # Separate source-model entry is tested with the artificial original model only.
    qs = importlib.util.spec_from_file_location('artificial_source_qualification', HERE / 'source_model_qualification.py')
    source_worker = importlib.util.module_from_spec(qs); qs.loader.exec_module(source_worker)
    base_manifest = json.loads((base / 'INPUTS.json').read_text())
    source_manifest = {'schema': 'remaining-nine-source-model-inputs-v1', 'candidate_id': contract.candidate,
                       'inputs': {name: base_manifest['inputs'][name] for name in ('source','profile','model')},
                       'bdd_files': base_manifest['bdd_files'],
                       'expected_model_identity': {'fixture_id': contract.candidate, 'case_id': contract.candidate, 'variant': 'initializers'}}
    source_answer = source_worker.qualify(source_manifest, {contract.candidate: contract})
    check('source-only entry makes no native or cooperation claim', source_answer['status'] == 'COMPLETE_INDEPENDENT_SOURCE_MODEL_CORRESPONDENCE'
          and not source_answer['source_correspondence']['constructor_phases_inspected'] and source_answer['independent_cooperative'] is None)
    reject('unknown candidate cannot select real oracle', lambda: w.audit({**manifest, 'candidate_id': 'not_declared'}))
    reject('production certificate forbidden in logical inputs',
           lambda: w.audit({**manifest, 'inputs': {**manifest['inputs'], 'production_certificate': manifest['inputs']['model']}},
                           {contract.candidate: contract}), 'Forbidden')
    reject('profile code injection operator', lambda: w.compile_profile(['__import__', 'os'], {'e': BOOL}))
    reject('profile malformed timing', lambda: w.compile_profile(['var', 'e', 1], {'e': BOOL}))
    reject('profile enum Boolean misuse', lambda: w.compile_profile(['var', 'm', False], {'m': MON}))
    reject('profile primed initial', lambda: w.compile_profile(['var', 'e', True], {'e': BOOL}, False))
    cli_runs = []
    for filename, schema, output_name in [('audit_worker.py','remaining-nine-independent-audit-inputs-v1','AUDIT_RESULT.json'),
                                          ('source_model_qualification.py','remaining-nine-source-model-inputs-v1','SOURCE_MODEL_RESULT.json')] if '--skip-cli' not in sys.argv else []:
        cli_root = out / ('cli_' + filename.removesuffix('.py')); cli_root.mkdir()
        cli_input = cli_root / 'INPUTS.json'; dump(cli_input, {'schema': schema, 'candidate_id': 'artificial_not_a_real_contract'})
        cli_output = cli_root / 'output'
        if filename == 'source_model_qualification.py': cli_output.mkdir()
        completed = subprocess.run([sys.executable,'-I','-S','-B',str(HERE/filename),str(cli_input),str(cli_output)],
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=5, check=False)
        (cli_root/'stdout.txt').write_bytes(completed.stdout); (cli_root/'stderr.txt').write_bytes(completed.stderr)
        answer = json.loads((cli_output/output_name).read_text())
        check('isolated CLI failure receipt ' + filename, completed.returncode == 2 and answer['status'].startswith('UNKNOWN_')
              and not completed.stderr and answer['input_manifest_pin'] == w.pin(cli_input))
        cli_runs.append({'script':filename,'argv_flags':['-I','-S','-B'],'returncode':completed.returncode,'result':w.pin(cli_output/output_name)})
    result = {'schema': 'remaining-nine-independent-artificial-qualification-v1', 'status': 'PASS',
              'created_utc': datetime.now(timezone.utc).isoformat(), 'elapsed_seconds': time.monotonic() - started,
              'named_tests': len(tests), 'tests': tests, 'exhaustive_artificial_graphs': 512,
              'real_source_equation_evaluations': 0, 'real_saved_DAG_evaluations': 0, 'real_controller_evaluations': 0,
              'native_processes': 0, 'production_checker_imports': 0, 'full_reset_uses': 0,
              'isolated_CLI_synthetic_failure_runs':cli_runs,
              'CLI_failure_checks_moved_to_separate_bounded_integration': '--skip-cli' in sys.argv,
              'worker_files': [w.pin(HERE / name) for name in ('audit_worker.py', 'source_contracts.py', 'independent_core.py', 'source_model_qualification.py', 'qualify_artificial.py')]}
    w.save_new(out / 'QUALIFICATION.json', result)
    print(json.dumps({k: result[k] for k in ('status', 'named_tests', 'elapsed_seconds')}))


if __name__ == '__main__':
    main()
