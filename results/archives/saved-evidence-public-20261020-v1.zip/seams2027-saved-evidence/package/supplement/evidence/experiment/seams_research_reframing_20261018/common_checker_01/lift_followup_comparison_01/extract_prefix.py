"""Exact saved-value joins and scalar source equations; no BDD or graph search."""
from pathlib import Path
import argparse,hashlib,json
from datetime import datetime,timezone
FIELDS=['b1','b2','b3','c','f1','f2','f3']+['SYS_CONSTRAINT.%d.pRespondsToS.state'%i for i in range(3)]
AUX=FIELDS[7:]
SOURCE_SHA='6a8f8220385130b2eb219ecfa33186b179d610ffcf805a30f9cab47ab204dae7'
def need(v,m):
    if not v:raise ValueError(m)
def pin(path):
    p=Path(path).resolve();h=hashlib.sha256();n=0
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):n+=len(b);h.update(b)
    return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
def key(v):
    need(set(v)==set(FIELDS),'All original fields including every AUX exactly once')
    for f in FIELDS:need(v[f] in (['S0','S1'] if f in AUX else ['false','true']),'Typed value')
    return tuple(v[f] for f in FIELDS)
def original(node):
    need(set(node['valuation'])==set(FIELDS+['~envHelp']),'Exact native field roster')
    need(node['valuation']['~envHelp']=='false','Original view helper value')
    v={f:node['valuation'][f] for f in FIELDS};key(v);return v
def source_step(x,y):
    key(x);key(y)
    b=[None]+[x['b'+str(i)]=='true' for i in range(1,4)]
    f=[None]+[x['f'+str(i)]=='true' for i in range(1,4)]
    bn=[None]+[y['b'+str(i)]=='true' for i in range(1,4)]
    fn=[None]+[y['f'+str(i)]=='true' for i in range(1,4)]
    c=x['c']=='true'
    env={'one_floor':any(f[1:])}
    for i in range(1,4):
        env['button%d_off_at_floor%d'%(i,i)]=not(b[i] and f[i]) or not bn[i]
        env['button%d_stays_on'%i]=not(b[i] and not f[i] and not c) or bn[i]
        env['one_floor_only%d'%i]=not f[i] or not any(f[j] for j in range(1,4) if j!=i)
    sysc={
      'move_one_max1':not f[1] or (fn[1] and not b[2] and not b[3]) or (fn[2] and b[2]) or (fn[2] and b[3]) or (fn[1] and c),
      'move_one_max2':not f[2] or (fn[1] and b[1]) or (fn[2] and not b[1] and not b[3]) or (fn[3] and b[3]) or (fn[2] and c),
      'move_one_max3':not f[3] or (fn[3] and not b[1] and not b[2]) or (fn[2] and b[1]) or (fn[2] and b[2]) or (fn[3] and c)}
    updates={}
    for i,a in enumerate(AUX,1):
        wanted='S0' if (f[i] or c) or (x[a]=='S0' and not b[i]) else 'S1'
        updates[a]={'current':x[a],'next':y[a],'source_required_next':wanted,'pass':y[a]==wanted}
    return {'ENV_named_safety':env,'SYS_named_move_safety':sysc,'logical_AUX_updates':updates,
            'rhoE':all(env.values()),'rhoS':all(sysc.values()) and all(v['pass'] for v in updates.values())}
def main():
    a=argparse.ArgumentParser();a.add_argument('manifest');a.add_argument('--sha256',required=True);a.add_argument('--output-dir',required=True);args=a.parse_args()
    mp=Path(args.manifest);need(pin(mp)['sha256']==args.sha256,'Input manifest pin');m=json.loads(mp.read_text());refs=m['inputs']
    for r in refs.values():need(pin(r['path'])==r,'Pinned input')
    data={k:json.loads(Path(v['path']).read_text()) for k,v in refs.items() if k!='source'}
    comparison=data['comparison_result'];need(comparison['input_manifest']==refs['comparison_inputs'],'Comparison manifest binding')
    compared=[r for r in comparison['rows'] if r['candidate_id']=='lift__trivial_1'];need(len(compared)==1,'One LiftT comparison row')
    need(compared[0]['status']=='AGREE_RETURNED_GRAPH_SEMANTICS' and compared[0]['strict'] is True and compared[0]['nonconflicting'] is False,'Completed independent semantic equality')
    binding=[r for r in data['comparison_inputs']['rows'] if r['candidate_id']=='lift__trivial_1'][0]
    for name,other in [('controller','controller'),('view','production_graph'),('fairness','production_fairness')]:need(refs[name]==binding['inputs'][other],'Same compared evidence')
    need(refs['source']==binding['expected_source'],'Same compared original source')
    need(refs['source']['sha256']==SOURCE_SHA,'Exact Lift source')
    init,regions=data['initial_condition'],data['regions']
    need(init['candidate_id']=='lift__trivial_1' and init['input_bindings']['regions']==refs['regions'],'Sealed initial-region binding')
    need(init['input_bindings']['source']['sha256']==SOURCE_SHA,'Historical/current exact source equality')
    need(init['I_M_K']['nonvacuous_initial_region_condition'] is True and init['I_M_V']['nonvacuous_initial_region_condition'] is True,'Original initializer admissibility')
    need(data['region_comparison']['equal'] is True,'Saved explicit/native K agreement premise')
    need(init['input_bindings']['REGION_COMPARISON.json']==refs['region_comparison'],'Sealed K comparison binding')
    need(regions['field_order']==FIELDS,'Complete logical field order')
    K={key(v) for v in regions['K_valuations']};V={key(v) for v in regions['V_valuations']}
    need(len(K)==regions['K']==316 and len(V)==regions['V']==384 and K<=V,'Exact saved region sets')
    controller,view,fair=data['controller'],data['view'],data['fairness'];nodes={n['id']:n for n in controller['nodes']}
    need(view['env_justice']==[],'Original ENV justice list empty')
    need(len(nodes)==len(controller['nodes']),'Unique native node IDs')
    states=set(view['states']);edges={tuple(x) for x in view['edges']}
    prefix=fair['nonconflicting']['first_failing_prefix']
    need(prefix==['0','10','339','438','704','680'] and prefix[0] in view['starts'],'Saved exact initial prefix')
    need(all((x,y) in edges for x,y in zip(prefix,prefix[1:])),'Every saved prefix edge exists')
    need(fair['nonconflicting']['failing_states']==['680','708'],'Saved exact failing states')
    membership={i:{'K':key(original(nodes[i])) in K,'V':key(original(nodes[i])) in V} for i in view['states']}
    need(all(membership[i]['K'] and membership[i]['V'] for i in prefix[:-1]),'Predecessor prefix in K and V')
    need({i for i in states if not membership[i]['K']}=={i for i in states if not membership[i]['V']}=={'680','708'},'Only two exits in returned original view')
    rows=[]
    for i in prefix+['708']:
        n=nodes[i];rows.append({'id':i,'original_valuation':original(n),'membership':membership[i],
             'raw_native_node':n,'derived_successors':[y for x,y in view['edges'] if x==i],
             'native_successor_helper_values':{s:nodes[s]['valuation']['~envHelp'] for s in n['successors']}})
    steps=[]
    for x,y in zip(prefix,prefix[1:]):
        check=source_step(original(nodes[x]),original(nodes[y]));need(check['rhoE'] and check['rhoS'],'Source-safe observed prefix')
        steps.append({'source_id':x,'target_id':y,'source_rank':nodes[x]['rank'],'target_rank':nodes[y]['rank'],'source_equation_checks':check})
    current=original(nodes['704']);chosen=original(nodes['680']);alternative=dict(chosen);alternative['f2']='false'
    check=source_step(current,alternative)
    need(check['rhoE'] and check['rhoS'] and key(alternative) in K and key(alternative) in V,'Source-safe K-preserving same-input alternative')
    need(all(chosen[f]==alternative[f] for f in ['b1','b2','b3','c']+AUX),'Same ENV next assignment and source-implied AUX updates')
    matching=[i for i in nodes if nodes[i]['valuation']==dict(alternative,**{'~envHelp':'false'})]
    need(not set(matching)&set(nodes['704']['successors']),'Alternative is not a selected native edge')
    for i in ['680','708']:
        need(not [y for x,y in edges if x==i],'No original-view outgoing edge')
        need(all(nodes[s]['valuation']['~envHelp']=='true' for s in nodes[i]['successors']),'All raw outgoing edges enter helper')
    for r in refs.values():need(pin(r['path'])==r,'Input unchanged')
    value={'schema':'lift-selected-prefix-saved-region-join-v1','status':'PASS_SAVED_VALUE_JOIN_AND_SCALAR_SOURCE_CHECKS','created_utc':datetime.now(timezone.utc).isoformat(),
      'candidate_id':'lift__trivial_1','I_M_K':True,'I_M_V':True,'all_logical_AUX_retained':True,'field_order':FIELDS,
      'saved_region_counts':{'K':len(K),'V':len(V)},'original_view_nodes':len(states),'nodes_in_K_and_V':sum(x['K'] and x['V'] for x in membership.values()),
      'first_failing_prefix':prefix,'first_K_and_V_exit_edge':['704','680'],'failing_nodes':['680','708'],
      'node_records':rows,'prefix_step_checks':steps,'all_view_membership':membership,
      'hypothetical_same_ENV_response':{'valuation':alternative,'K':True,'V':True,'source_equation_checks':check,'changed_fields':['f2'],
          'native_source_node':'704','native_source_rank':nodes['704']['rank'],'native_chosen_target':'680','native_chosen_target_rank':nodes['680']['rank'],
          'hypothetical_rank_or_private_memory':None,'existing_native_nodes_with_same_valuation':matching,'selected_native_edge':False,
          'scope':'One legal source response into the saved K. It is not a native edge, repaired graph, strategy, trajectory, or implementation fix.'},
      'mechanism':'At source node 704 the current floor is f2. Chosen next f2 and f3 are both true. Incoming original rhoE and rhoS hold; the resulting current-state ENV one-floor-only2/3 assumptions fail, leaving no original legal ENV next choice. Source ENV justice list is empty, so no infinite original ENV-safe continuation exists from the two finite deadends.',
      'region_authority':'Membership in independently certified saved K/V is used as a premise; no region is recomputed here.',
      'input_manifest':pin(mp),'source_code':pin(__file__),'all_inputs_unchanged':True,'native_invocations':0,'BDD_evaluations':0,'graph_searches_or_SCC_runs':0,'full_reset_uses':0}
    out=Path(args.output_dir);out.mkdir(exist_ok=False)
    with (out/'RESULT.json').open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'status':value['status'],'first_exit':value['first_K_and_V_exit_edge'],'alternative_K':True,'result':pin(out/'RESULT.json')}))
if __name__=='__main__':main()
