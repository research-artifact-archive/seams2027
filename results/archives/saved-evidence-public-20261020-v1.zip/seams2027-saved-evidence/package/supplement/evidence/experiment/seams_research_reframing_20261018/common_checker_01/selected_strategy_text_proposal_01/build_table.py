"""Join sealed JSON summaries for the fixed eleven candidates; no scientific run."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
ORDER=['arbiter__preferred','arbiter__trivial_1','lift__preferred','lift__trivial_1','minepump__preferred','minepump__trivial_1','minepump__trivial_2','traffic_single__preferred','traffic_single__trivial_1','traffic_updated__preferred','traffic_updated__trivial_1']
LABELS=['Arbiter P','Arbiter T','Lift P','Lift T','Minepump P','Minepump T1','Minepump T2','Traffic S P','Traffic S T','Traffic U P','Traffic U T']
INPUTS={}
def need(x,message):
    if not x:raise ValueError(message)
def pin(path):
    p=Path(path).resolve();h=hashlib.sha256();n=0
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):n+=len(b);h.update(b)
    return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
def load(name,path):
    p=Path(path).resolve();raw=p.read_bytes();ref={'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    need(name not in INPUTS or INPUTS[name]==ref,'Unique evidence key');INPUTS[name]=ref;return json.loads(raw)
def keep(name,ref):
    need(pin(ref['path'])==ref,'Exact recorded evidence pin');INPUTS[name]=ref
def by_id(rows,key):return {r[key]:r for r in rows}
def main():
    old=load('first_nine_batch',ROOT/'remaining_nine_batch_01/RUN_RECEIPT.json')
    later=load('lift_followup_batch',ROOT/'lift_resource_followup_01/batch_01/RUN_RECEIPT.json')
    comparison=load('first_nine_comparison',ROOT/'common_checker_01/cohort_comparison_01/results_01/RESULT.json')
    followcomp=load('lift_followup_comparison',ROOT/'common_checker_01/lift_followup_comparison_01/results_01/RESULT.json')
    rootreview=load('root_followup_review',ROOT/'ROOT_FOLLOWUP_AND_PAIR_REVIEW_01.json')
    need(rootreview['fixed_published_denominator']==11 and rootreview['constructed_pair_in_published_denominator'] is False,'Published denominator')
    profiles=load('remaining_nine_profiles',ROOT/'runtime_closure_01/ORIGINAL_PROFILES.json')['profiles']
    initial=load('initial_condition_summary',ROOT/'initial_region_check_01/saved_results_01/RESULT.json')
    oldrows=by_id(old['rows'],'candidate');followrows=by_id(later['rows'],'candidate')
    oldcomp=by_id(comparison['rows'],'candidate_id');newcomp=by_id(followcomp['rows'],'candidate_id')
    need(set(oldrows)==set(ORDER)-{'arbiter__preferred','traffic_single__preferred'},'Fixed nine roster')
    need(set(followrows)=={'lift__preferred','lift__trivial_1'},'Exactly two followups')
    need(later['first_batch_receipt']==INPUTS['first_nine_batch'] and later['original_nine_rows_unchanged'] is True,'Immutable first batch')
    compat=ROOT/'common_checker_01/compatibility_preparation_01'
    provenance=load('baseline_copy_manifest',compat/'INPUT_MANIFEST.json')
    compatible=load('baseline_compatibility_receipt',compat/'EXECUTION_RECEIPT.json')
    need(compatible['status']=='PASS_THREE_SAVED_COMPATIBILITY_CASES' and compatible['native_invocations']==0,'Prior baseline compatibility')
    rows=[]
    for ident,label in zip(ORDER,LABELS):
        initkey='initial_'+ident;init=load(initkey,ROOT/'initial_region_check_01/saved_results_01'/(ident+'.json'))
        need(init['candidate_id']==ident,'Initial-condition identity')
        ik=init['I_M_K']['I_M_K_universal_predicate'];need(type(ik) is bool,'Boolean initializer result')
        need(init['I_M_K']['legal_ENV_initial_assignments']>0,'Nonvacuous ENV initializer')
        keep('source_'+ident,init['input_bindings']['source'])
        refs=[initkey,'source_'+ident];attempts=[];view=None;strict=None;coop=None;mapping='UNKNOWN';origin='FIRST_NINE_ATTEMPT'
        if ident in ['arbiter__preferred','traffic_single__preferred']:
            fixture='traffic_single' if ident=='traffic_single__preferred' else ident
            copied=(compat/'baseline'/fixture/'certificate.json').resolve()
            copied_prov=[x for x in provenance['copy_provenance'] if x['copy']['path']==str(copied)]
            need(len(copied_prov)==1,'Unique baseline origin');entry=copied_prov[0]
            keep('baseline_copy_'+ident,entry['copy']);keep('baseline_origin_'+ident,entry['source'])
            cert=load('certificate_'+ident,entry['source']['path']);refs+=['certificate_'+ident,'baseline_origin_'+ident,'baseline_copy_'+ident,'baseline_compatibility_receipt']
            prof=load('profile_'+ident,compat/'profiles'/(fixture+'.json'))['profiles'][fixture]
            upgraded=load('compatibility_certificate_'+ident,compat/'results'/fixture/'certificate.json');refs+=['profile_'+ident,'compatibility_certificate_'+ident]
            need(cert['fixture_id']==fixture and cert['status']=='COMPLETE_DERIVED_ORIGINAL_CERTIFICATE','Completed baseline certificate')
            need(cert['original_profiles_sha256']==INPUTS['profile_'+ident]['sha256'],'Baseline original-profile pin')
            need(upgraded['initialization_correspondence']['ENV_full_native_typed_domain'] is True,'Qualified full original initialization')
            native=cert['native_outcome'];need(native=='JOB_CONTROLLER_PRINTED','Baseline returned graph')
            origin='PRIOR_BASELINE_REUSED';attempts=[{'kind':origin,'certificate_ref':'baseline_origin_'+ident}]
            view={k:cert['original_view_mapping'][k] for k in ['states','edges']}
            strict=cert['derived_fairness']['strict_liveness']['pass'];coop=cert['derived_fairness']['nonconflicting']['pass'];mapping='PASS'
            need(upgraded['original_view_mapping']==cert['original_view_mapping'] and upgraded['derived_fairness']==cert['derived_fairness'],'Compatibility semantic equality')
        else:
            prof=profiles[ident];r=oldrows[ident];selected=oldcomp[ident]
            attempts=[{'kind':'FIRST_NINE_ATTEMPT','status':r['status'],'native_outcome':r['native_observed_outcome'],'batch_ref':'first_nine_batch'}]
            refs+=['first_nine_batch','first_nine_comparison','remaining_nine_profiles']
            if ident in followrows:
                need(r['status']=='UNKNOWN_NATIVE_PROCESS','Original resource UNKNOWN retained')
                r=followrows[ident];need(r['attempt_ordinal']==2 and r['first_attempt_not_relabelled'] is True,'Additional attempt identity')
                attempts.append({'kind':'EXPLICIT_RESOURCE_FOLLOWUP','status':r['status'],'native_outcome':r['native_observed_outcome'],'batch_ref':'lift_followup_batch'})
                selected=newcomp[ident];origin='LIFT_RESOURCE_FOLLOWUP';refs+=['lift_followup_batch','lift_followup_comparison','root_followup_review']
            native=r['native_observed_outcome']
            if selected['status']=='AGREE_RETURNED_GRAPH_SEMANTICS':
                view={'states':selected['states'],'edges':selected['edges']};strict=selected['strict'];coop=selected['nonconflicting'];mapping='PASS'
            elif selected['status']=='AGREE_NO_CONTROLLER':
                need(native=='JOB_UNREALIZABLE_NO_CONTROLLER','Native false verdict');mapping='PASS_NO_CONTROLLER'
            else:need(ident=='lift__preferred' and r['status']=='UNKNOWN_AUDIT_OR_MAPPING','Only LiftP mapping UNKNOWN')
            if 'production_certificate' in r:
                keep('certificate_'+ident,{k:r['production_certificate'][k] for k in ['path','bytes','sha256']});refs.append('certificate_'+ident)
        source=prof['source'];need(source['sha256']==init['input_bindings']['source']['sha256'] and source['bytes']==init['input_bindings']['source']['bytes'],'Same original source bytes between initialization and selected output')
        need(native in ['JOB_CONTROLLER_PRINTED','JOB_UNREALIZABLE_NO_CONTROLLER'],'Native outcome class')
        rows.append({'candidate_id':ident,'label':label,'I_M_K':ik,'native_outcome':native,'original_view':view,'strict':strict,'cooperative':coop,'original_correspondence':mapping,'selected_evidence':origin,'attempts':attempts,'evidence_refs':refs})
    counts={'candidates':len(rows),'I_M_K_true':sum(r['I_M_K'] for r in rows),'native_graphs':sum(r['native_outcome']=='JOB_CONTROLLER_PRINTED' for r in rows),'native_false':sum(r['native_outcome']=='JOB_UNREALIZABLE_NO_CONTROLLER' for r in rows),'source_correspondent_returned_graphs':sum(r['original_correspondence']=='PASS' for r in rows),'strict_and_cooperative':sum(r['strict'] is True and r['cooperative'] is True for r in rows),'strict_only':sum(r['strict'] is True and r['cooperative'] is False for r in rows),'mapping_unknown':sum(r['original_correspondence']=='UNKNOWN' for r in rows)}
    need(counts=={'candidates':11,'I_M_K_true':8,'native_graphs':10,'native_false':1,'source_correspondent_returned_graphs':9,'strict_and_cooperative':7,'strict_only':2,'mapping_unknown':1},'Expected exact aggregate with UNKNOWN retained')
    for ref in INPUTS.values():need(pin(ref['path'])==ref,'All source inputs unchanged')
    value={'schema':'fixed-eleven-original-initializer-table-v1','status':'COMPLETE_SAVED_JSON_JOIN','created_utc':datetime.now(timezone.utc).isoformat(),'candidate_order':ORDER,'rows':rows,'counts':counts,'inputs':INPUTS,'script':pin(__file__),'pair_included':False,'original_nine_attempts_unchanged':True,'unknown_promoted_to_negative':False,'native_invocations':0,'BDD_evaluations':0,'graph_algorithms':0,'full_reset_uses':0}
    with (HERE/'eleven-candidates.json').open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
    tex=[r'\begin{table}[t]',r'\centering',r'\caption{Fixed eleven published candidates under their original initializers. P: learned/preferred; T: trivial; S/U: Traffic Single/Updated. Graph and False are native outcomes. A question mark denotes unverified original correspondence; dashes denote no controller. $^{b}$ reuses a prior baseline; $^{f}$ uses a separate resource followup, retaining both initial UNKNOWN attempts. The artificial mechanism pair is excluded.}',r'\label{tab:repair-eleven}',r'\small\setlength{\tabcolsep}{3pt}',r'\begin{tabular}{@{}lccrcc@{}}',r'\toprule',r'Candidate & $I_M(K)$ & Native & $|Q|/|E|$ & Strict & Coop.\\',r'\midrule']
    for r in rows:
        suffix='$^{b}$' if r['selected_evidence']=='PRIOR_BASELINE_REUSED' else ('$^{f}$' if r['selected_evidence']=='LIFT_RESOURCE_FOLLOWUP' else '')
        v=r['original_view'];vs=str(v['states'])+'/'+str(v['edges']) if v else ('?' if r['original_correspondence']=='UNKNOWN' else '---')
        label=lambda v:'Pass' if v is True else 'Fail' if v is False else '?' if r['original_correspondence']=='UNKNOWN' else '---'
        tex.append(' & '.join([r['label']+suffix,'$\\mathsf{'+('T' if r['I_M_K'] else 'F')+'}$','Graph' if r['native_outcome']=='JOB_CONTROLLER_PRINTED' else 'False',vs,label(r['strict']),label(r['cooperative'])])+r'\\')
    tex += [r'\bottomrule',r'\end{tabular}',r'\end{table}']
    with (HERE/'eleven-candidates-table.tex').open('x') as f:f.write('\n'.join(tex)+'\n')
    print(json.dumps({'status':value['status'],'counts':counts,'json':pin(HERE/'eleven-candidates.json'),'table':pin(HERE/'eleven-candidates-table.tex')}))
if __name__=='__main__':main()
