"""Finite source-policy graph construction and independent saved-graph checking.

Import defines functions only. Real Lift construction requires the CLI manifest;
the parent launcher separately requires an exact Root GO and prospective freeze.
"""
from pathlib import Path
from itertools import product
from collections import deque
import sys, time
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import independent_core as core
import source_contracts as source
import policy


def check_time(deadline):
    core.need(time.monotonic() < deadline, 'Internal source-witness time budget')


def assignments(names, domains):
    return [dict(zip(names, values)) for values in product(*(domains[name] for name in names))]


def state_key(state, priority, fields):
    return tuple(state[name] for name in fields) + (priority,)


def build_graph(contract, initials, legal, choose, limits, deadline):
    fields = tuple(contract.names); environment = tuple(contract.env)
    inputs = assignments(environment, contract.values)
    nodes, edges, starts, by_key, queue = [], [], [], {}, deque()
    def add(state, priority):
        key = state_key(state, priority, fields)
        if key not in by_key:
            core.need(len(nodes) < limits['nodes'], 'Source-witness node cap')
            ident = str(len(nodes)); by_key[key] = ident
            nodes.append({'id': ident, 'valuation': dict(state), 'private_priority': priority})
            queue.append(ident)
        return by_key[key]
    for state, priority in initials:
        starts.append(add(state, priority))
    while queue:
        check_time(deadline)
        ident = queue.popleft(); node = nodes[int(ident)]
        for environment_step in inputs:
            if not legal(node['valuation'], environment_step):
                continue
            successor, priority = choose(node['valuation'], node['private_priority'], environment_step)
            target = add(successor, priority)
            core.need(len(edges) < limits['edges'], 'Source-witness edge cap')
            edges.append({'from': ident, 'to': target, 'environment': dict(environment_step)})
    return {'schema': 'source-coded-private-memory-controller-v1', 'source_candidate': contract.candidate,
            'field_order': list(fields), 'private_memory': {'name': 'priority', 'values': [1,3], 'initial': 3},
            'starts': starts, 'nodes': nodes, 'edges': edges,
            'scope': 'Constructed source-policy witness, not a released-native controller, repair or activation.'}


def audit_graph(graph, contract, initials, choose, limits, deadline, justice_counts):
    """Original source predicates and untouched fairness core are the authorities."""
    check_time(deadline)
    core.need(graph['schema'] == 'source-coded-private-memory-controller-v1', 'Graph schema')
    core.need(graph['source_candidate'] == contract.candidate, 'Exact source candidate')
    fields = tuple(contract.names); domains = contract.values
    core.need(graph['field_order'] == list(fields), 'Complete source field order')
    core.need(graph['private_memory'] == {'name':'priority','values':[1,3],'initial':3}, 'Exact private bit declaration')
    nodes, edges = graph['nodes'], graph['edges']
    core.need(type(nodes) is list and 0 < len(nodes) <= limits['nodes'], 'Typed bounded node array')
    core.need(type(edges) is list and len(edges) <= limits['edges'], 'Typed bounded edge array')
    by_id, by_key = {}, {}
    for i, node in enumerate(nodes):
        core.need(type(node) is dict and set(node) == {'id','valuation','private_priority'}, 'Full node schema')
        core.need(node['id'] == str(i), 'Canonical distinct node IDs')
        state, priority = node['valuation'], node['private_priority']
        core.need(type(state) is dict and set(state) == set(fields), 'All original logical AUX retained')
        core.need(all(type(state[name]) is str and state[name] in domains[name] for name in fields), 'Typed source values')
        core.need(type(priority) is int and priority in (1,3), 'Typed private priority bit')
        key = state_key(state, priority, fields)
        core.need(key not in by_key, 'No duplicate full source/memory state')
        by_id[node['id']] = node; by_key[key] = node['id']
    expected_starts = [by_key.get(state_key(state, priority, fields)) for state, priority in initials]
    core.need(all(x is not None for x in expected_starts), 'Every original initial state present')
    core.need(graph['starts'] == expected_starts and len(set(expected_starts)) == len(expected_starts), 'Exact original initial states/order')
    inputs = assignments(contract.env, domains)
    initial_environment = {tuple(state[n] for n in contract.env) for state, _ in initials}
    legal_initial_environment = {tuple(e[n] for n in contract.env) for e in inputs if contract.theta_e(e)}
    core.need(initial_environment == legal_initial_environment, 'All original legal ENV initial assignments')
    for state, priority in initials:
        core.need(contract.theta_e(state) and contract.theta_s(state) and priority == 3, 'Original SYS/AUX initialization and fixed private bit')
    outgoing = {ident: {} for ident in by_id}; pairs = set()
    for edge in edges:
        core.need(type(edge) is dict and set(edge) == {'from','to','environment'}, 'Source edge schema')
        a, b, e = edge['from'], edge['to'], edge['environment']
        core.need(type(a) is str and type(b) is str and a in by_id and b in by_id, 'Known edge endpoints')
        core.need(type(e) is dict and set(e) == set(contract.env), 'Full ENV edge label')
        core.need(all(type(e[n]) is str and e[n] in domains[n] for n in contract.env), 'Typed ENV edge label')
        key = tuple(e[n] for n in contract.env)
        core.need(key not in outgoing[a], 'Exactly one SYS response per legal ENV input')
        current, successor = by_id[a]['valuation'], by_id[b]['valuation']
        core.need(all(successor[n] == e[n] for n in contract.env), 'Successor/ENV input identity')
        core.need(contract.rho_e(current, e), 'Original ENV transition')
        core.need(contract.rho_s(current, successor), 'Original SYS and logical AUX transition')
        expected, priority = choose(current, by_id[a]['private_priority'], e)
        core.need(successor == expected and by_id[b]['private_priority'] == priority, 'Exact frozen source-policy response')
        outgoing[a][key] = b; pairs.add((a,b))
    for ident, node in by_id.items():
        check_time(deadline)
        expected = {tuple(e[n] for n in contract.env) for e in inputs if contract.rho_e(node['valuation'], e)}
        core.need(expected and set(outgoing[ident]) == expected, 'All and only legal ENV inputs, nonempty at every node')
    env_labels = [[] for _ in range(justice_counts[0])]
    sys_labels = [[] for _ in range(justice_counts[1])]
    for ident, node in by_id.items():
        e, s = contract.justice(node['valuation'])
        core.need(len(e) == len(env_labels) and len(s) == len(sys_labels), 'Exact original justice counts')
        core.need(all(type(x) is bool for x in e+s), 'Boolean original justice labels')
        for labels, values in ((env_labels,e),(sys_labels,s)):
            for label, value in zip(labels, values):
                if value: label.append(ident)
    check_time(deadline)
    fairness = core.finite_fairness(list(by_id), sorted(pairs), graph['starts'], env_labels, sys_labels)
    check_time(deadline)
    passed = fairness['strict_liveness']['pass'] and fairness['nonconflicting']['pass']
    return {'schema':'source-coded-controller-certificate-v1',
            'status':'COMPLETE_POSITIVE_SOURCE_WITNESS' if passed else 'COMPLETE_CONSTRUCTED_CONTROLLER_REJECTED',
            'source_candidate':contract.candidate,'state_count':len(nodes),'edge_count':len(edges),
            'original_initial_ENV_assignments':len(initials),'original_fields':list(fields),
            'logical_AUX':[n for n,_ in contract.aux],'private_memory':'one priority bit, initial3',
            'all_legal_ENV_inputs_preserved':True,'exactly_one_SYS_response_per_legal_input':True,
            'all_original_safety_and_logical_AUX_updates':True,'original_ENV_justice_count':len(env_labels),
            'original_SYS_justice_count':len(sys_labels),'ENV_justice':env_labels,'SYS_justice':sys_labels,
            'strict':fairness['strict_liveness']['pass'],'nonconflicting':fairness['nonconflicting']['pass'],
            'fairness':fairness,'native_calls':0,'BDD_calls':0,'fixed_point_game_solves':0,
            'claim_scope':'This fixed constructed policy from original initial states only; not all saved K states, released output, repair or activation.'}


def main():
    core.need(len(sys.argv) == 3 and sys.flags.isolated and sys.flags.no_site, 'Use python -I -S -B witness.py INPUTS NEW_OUTPUT')
    manifest_path, output = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).absolute()
    m = core.decode_json(manifest_path.read_bytes())
    core.need(m['schema'] == 'lift-positive-source-witness-inputs-v1' and m['candidate'] == 'lift__trivial_1', 'Prospective Lift source manifest')
    core.need(m['limits'] == {'nodes':2048,'edges':65536,'internal_seconds':55}, 'Prospective construction caps')
    core.need(not output.exists() and not output.is_symlink() and output.parent.is_dir(), 'Fresh source witness output')
    for ref in m['files']: core.read_pin(ref)
    contract = source.CONTRACTS[m['candidate']]
    raw = core.read_pin(m['source'])
    core.need(len(raw) == contract.source_bytes and core.pin(m['source']['path'])['sha256'] == contract.source_sha256, 'Exact source byte identity')
    profile = core.decode_json(core.read_pin(m['profiles']))['profiles'][m['candidate']]
    core.need(profile['expected_fields_in_native_order'] == contract.fields
              and [(x['name'],tuple(x['domain'])) for x in profile['AUX']] == list(contract.aux), 'Exact original field/AUX roster')
    core.need(all(x['source_owner'] == x['runtime_owner'] == 'SYS' and x['initial_value'] == 'S0'
                  for x in profile['AUX']), 'Original logical AUX ownership and initialization')
    core.need(profile['source']['bytes'] == contract.source_bytes and profile['source']['sha256'] == contract.source_sha256, 'Original source/profile binding')
    core.need(tuple(contract.names) == policy.FIELDS, 'Policy/source full field order')
    output.mkdir(); deadline = time.monotonic() + m['limits']['internal_seconds']
    print('BUILD_SOURCE_POLICY_GRAPH', flush=True)
    graph = build_graph(contract, policy.initial_states(), policy.legal_environment, policy.step, m['limits'], deadline)
    core.save_new(output/'CONTROLLER.json', graph)
    print('CHECK_ORIGINAL_SOURCE_COMPLETENESS_SAFETY_AND_ALL_JUSTICES', flush=True)
    certificate = audit_graph(graph, contract, policy.initial_states(), policy.step, m['limits'], deadline, (0,3))
    certificate.update(input_manifest=core.pin(manifest_path), source=m['source'], profiles=m['profiles'],
                       controller=core.pin(output/'CONTROLLER.json'), policy=core.pin(HERE/'policy.py'),
                       source_oracle=core.pin(HERE/'source_contracts.py'), fairness_core=core.pin(HERE/'independent_core.py'))
    for ref in m['files']: core.read_pin(ref)
    certificate['all_input_pins_unchanged'] = True
    core.save_new(output/'CERTIFICATE.json', certificate)
    print(certificate['status'], flush=True)


if __name__ == '__main__': main()
