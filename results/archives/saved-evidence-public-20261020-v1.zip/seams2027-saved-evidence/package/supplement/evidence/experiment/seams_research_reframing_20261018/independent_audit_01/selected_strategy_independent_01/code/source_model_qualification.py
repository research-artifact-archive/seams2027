"""Source/model correspondence only: no native outcome or controller claim.

Requires a separately frozen manifest and Root scientific start authorization.
Uses original unreduced helper-free saved models, never a production certificate.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import sys
import traceback

spec = importlib.util.spec_from_file_location('independent_source_model_worker', Path(__file__).with_name('audit_worker.py'))
w = importlib.util.module_from_spec(spec)
spec.loader.exec_module(w)


def qualify(manifest, contracts=w.CONTRACTS):
    w.need(manifest['schema'] == 'selected-strategy-source-model-inputs-v1', 'Source-model manifest schema')
    candidate = manifest['candidate_id']
    w.need(candidate in contracts, 'No exact declared source oracle')
    c = contracts[candidate]
    refs = manifest['inputs']
    w.need(set(refs) == {'source', 'profile', 'model'}, 'Exact source-only inputs; no result/graph/certificate')
    source = w.read_pin(refs['source'])
    w.need(len(source) == c.source_bytes and hashlib.sha256(source).hexdigest() == c.source_sha256, 'Exact declared source pin')
    profile = w.decode_json(w.read_pin(refs['profile']))['profiles'][candidate]
    model = w.decode_json(w.read_pin(refs['model']))
    identity = manifest['expected_model_identity']
    w.need(set(identity) == {'fixture_id', 'case_id', 'variant'} and identity['fixture_id'] == candidate
           and all(type(value) is str and model[key] == value for key, value in identity.items()), 'Exact historical original-model identity')
    w.need(model['schema'] == 'k7-native-model-export-v1' and model['input']['sha256'] == c.source_sha256
           and model['input']['bytes'] == c.source_bytes, 'Source/original-model byte identity')
    ctx = w.ModelAudit(manifest, c, None, None, model, profile)
    correspondence = ctx.verify_source()
    return {'status': 'COMPLETE_INDEPENDENT_SOURCE_MODEL_CORRESPONDENCE', 'candidate': candidate,
            'source_correspondence': correspondence, 'input_bindings': refs, 'historical_model_identity': identity,
            'saved_DAG_files_evaluated': sorted(ctx.loaded), 'production_certificate_read': False,
            'production_checker_imports': 0, 'native_processes': 0, 'graph_evaluations': 0,
            'native_outcome_evaluated': False, 'independent_strict': None, 'independent_cooperative': None,
            'scope': 'Original source/profile/model formula and justice correspondence only. No native-job verdict, returned-graph correctness, or original initial cooperation claim.'}


def main():
    w.need(len(sys.argv) == 3, 'Usage: source_model_qualification.py INPUTS.json FRESH_OUTPUT_DIR')
    input_path, output = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
    w.need(output.is_dir() and not any(output.iterdir()), 'Fresh empty qualification output directory')
    started = datetime.now(timezone.utc).isoformat()
    try:
        result = qualify(w.decode_json(input_path.read_bytes()))
        exit_code = 0
    except BaseException as error:
        result = {'status': 'UNKNOWN_INDEPENDENT_SOURCE_MODEL_CORRESPONDENCE', 'error': str(error),
                  'exception_type': type(error).__name__, 'traceback': traceback.format_exc(),
                  'native_processes': 0, 'graph_evaluations': 0, 'production_certificate_read': False}
        exit_code = 2
    result.update(started_utc=started, finished_utc=datetime.now(timezone.utc).isoformat(),
                  input_manifest_pin=w.pin(input_path),
                  code_pins=[w.pin(Path(__file__).with_name(name)) for name in
                             ('source_model_qualification.py', 'audit_worker.py', 'source_contracts.py', 'independent_core.py')])
    w.save_new(output / 'SOURCE_MODEL_RESULT.json', result)
    print(json.dumps({key: result[key] for key in ('status', 'candidate', 'error') if key in result}))
    return exit_code


if __name__ == '__main__':
    sys.exit(main())
