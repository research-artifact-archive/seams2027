"""Artificial-only complete saved-DAG policy extension qualification."""
from pathlib import Path
from types import SimpleNamespace
import copy,hashlib,importlib.util,json,sys
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('extension_tested',HERE/'extension_worker.py');x=importlib.util.module_from_spec(spec);spec.loader.exec_module(x);w=x.w;C=sys.modules['source_contracts'].SourceContract
ROOT=Path(sys.argv[1]);ROOT.mkdir();tests=[]
raw=b'ARTIFICIAL ONLY: two onehot floors, request, unguarded source AUX, helper.\n';sp=ROOT/'source.txt';sp.write_bytes(raw)
def mono(s):return (s['f1']=='true')!=(s['f2']=='true')
def env(s,t):return mono(s) and (not(s['e']=='true' and s['f1']=='true') or t['e']=='false') and (not(s['e']=='true' and s['f1']=='false') or t['e']=='true')
def aux(s,t):return (t['m']=='S1')==((s['m']=='S1' or s['e']=='true') and s['f1']=='false')
def move(s,t):return mono(t) and t['f1']!=s['f1'] and t['f2']!=s['f2']
c=C('artificial_extension',len(raw),hashlib.sha256(raw).hexdigest(),('e',),('f1','f2'),(('m',('S0','S1')),),lambda s:s['e']=='false',lambda s:s['f1']=='true' and s['f2']=='false' and s['m']=='S0',env,lambda s,t:move(s,t) and aux(s,t),lambda s:([],[s['m']=='S0',s['f1']=='true']),'Artificial')
def choose(s,priority,e):return dict(e,f1='false' if s['f1']=='true' else 'true',f2='false' if s['f2']=='true' else 'true',m='S1' if (s['m']=='S1' or s['e']=='true') and s['f1']=='false' else 'S0'),4-priority
p=SimpleNamespace(FIELDS=c.names,ENV=c.env,SYS=c.system,AUX=('m',),INITIAL_PRIORITY=3,initial_states=lambda:[({'e':'false','f1':'true','f2':'false','m':'S0'},3)],step=choose)
expected={'source_invariant_states':8,'full_native_states':32,'initial_ENV_choices':1,'native_current_policy_states':32,'policy_assignments':128}
fields=[];names=('e',w.HELPER,'f1','f2','m');values=dict(c.values,**{w.HELPER:w.BOOL});ORDER=[9,0,7,2,5,4,3,6,1,8]
for i,name in enumerate(names):
 owner='ENV' if i<2 else 'SYS';role='ENV' if i<2 else 'AUX' if name=='m' else 'SYS';cb,nb=2*i,2*i+1;invert=i%2==1
 fields.append({'name':name,'owner':owner,'role':role,'domain_size':2,'values':list(values[name]),'current_bits':[cb],'next_bits':[nb],'encoding':{v:{'current':{str(cb):bool(j)^invert},'next':{str(nb):bool(j)^invert}} for j,v in enumerate(values[name])}})
def valuation(b,prime=False):
 timing='next' if prime else 'current';return {f['name']:next(v for v,d in f['encoding'].items() if all(b[int(bit)]==x for bit,x in d[timing].items())) for f in fields}
def bdd(fn):
 nodes={};unique={};assignment={}
 def descend(level):
  if level==len(ORDER):return int(fn(valuation(assignment),valuation(assignment,True)))
  v=ORDER[level];assignment[v]=False;a=descend(level+1);assignment[v]=True;b=descend(level+1)
  if a==b:return a
  k=(v,a,b)
  if k not in unique:unique[k]=len(nodes)+2;nodes[unique[k]]=k
  return unique[k]
 root=descend(0)
 if root in (0,1):return f'0 {root}\n'.encode()
 seen=set();stack=[root]
 while stack:
  n=stack.pop()
  if n in (0,1) or n in seen:continue
  seen.add(n);stack.extend(nodes[n][1:])
 return ('10\n'+' '.join(map(str,ORDER))+'\n'+'\n'.join(' '.join(map(str,(i,)+nodes[i])) for i in sorted(seen))+'\n').encode()
refs={}
def dag(name,fn):
 path=ROOT/(name+'.bdd');path.write_bytes(bdd(fn));ref=w.pin(path);refs[path.name]=ref;return {'file':path.name,'bytes':ref['bytes'],'sha256':ref['sha256']}
def native_s(s,t):return (move(s,t) or s[w.HELPER]=='true') and aux(s,t)
roots={k:dag(k,f) for k,f in {'thetaE':lambda s,t:c.theta_e(s) and s[w.HELPER]=='false','thetaS':lambda s,t:c.theta_s(s),'rhoE':lambda s,t:(env(s,t) or t[w.HELPER]=='true') and (s[w.HELPER]=='false' or t[w.HELPER]=='true'),'rhoS':native_s}.items()}
for key in ('domain','domain_ENV_next','domain_SYS_next'):roots[key]=dag(key,lambda s,t:True)
js={'ENV':[dag('justice_helper',lambda s,t:s[w.HELPER]=='false')],'SYS':[dag('justice_m',lambda s,t:s['m']=='S0'),dag('justice_f1',lambda s,t:s['f1']=='true')]}
model={'schema':'k7-native-model-export-v1','fixture_id':c.candidate,'case_id':c.candidate,'variant':'initializers','input':w.pin(sp),'fields':fields,'all_current_bits':list(range(0,10,2)),'all_next_bits':list(range(1,10,2)),'bdd_variable_count':10,'bdd_variable_order':ORDER,'source_inventory':{'parsed':{'ENV':{'variables':[{'name':'e'}]},'SYS':{'variables':[{'name':'f1'},{'name':'f2'}]}}},'original_bdds':roots,'original_justices':js}
v=lambda name,prime=False:['var',name,prime];eq=lambda name,value,prime=False:['eq',name,value,prime];not_=lambda a:['not',a]
profile={'profiles':{c.candidate:{'fixture_id':c.candidate,'case_id':c.candidate,'variant':'initializers','source':w.pin(sp),'public_ENV':['e'],'public_SYS':['f1','f2'],'expected_fields_in_native_order':c.fields,'formulas':{'thetaE':not_(v('e')),'thetaS':['and',v('f1'),not_(v('f2')),eq('m','S0')],'rhoE':['and',not_(['iff',v('f1'),v('f2')]),['implies',['and',v('e'),v('f1')],not_(v('e',True))],['implies',['and',v('e'),not_(v('f1'))],v('e',True)]],'rhoS':['and',not_(['iff',v('f1',True),v('f2',True)]),not_(['iff',v('f1'),v('f1',True)]),not_(['iff',v('f2'),v('f2',True)]),['iff',eq('m','S1',True),['and',['or',eq('m','S1'),v('e')],not_(v('f1'))]]]},'justices':{'ENV':[],'SYS':[eq('m','S0'),v('f1')]}}}}
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n');return w.pin(path)
mp=save(ROOT/'model.json',model);pp=save(ROOT/'profile.json',profile)
export=lambda ref:{'file':Path(ref['path']).name,'bytes':ref['bytes'],'sha256':ref['sha256']}
result={'helper_added':True,'helper_is_native_nonaux_ENV':True,'model_export':export(mp),'input_sha256':c.source_sha256,'preconstructor_justices':copy.deepcopy(js),'solver_justices':copy.deepcopy(js)};rp=save(ROOT/'result.json',result)
m={'inputs':{'source':w.pin(sp),'profile':pp,'model':mp,'native_result':rp},'bdd_files':refs}
def run(mm=m,policy=p,counts=expected):return x.check_policy(x.load(mm,c),c,policy,counts)
r=run();assert {k:v['native_ENV_legal'] for k,v in r['helper_classes'].items()}=={'00':24,'01':32,'10':0,'11':32};tests.append('All128 assignments/four helper classes, exact independent counts24/32/0/32, nontrivial order/inverted encodings')
def reject(name,fn,part):
 try:fn()
 except (ValueError,KeyError,TypeError,AssertionError) as e:assert part in str(e),(name,str(e));tests.append(name+': '+str(e)[:250]);return
 raise AssertionError('Accepted mutation '+name)
def mutate(fn):
 mm=copy.deepcopy(m);mo=copy.deepcopy(model);res=copy.deepcopy(result);fn(mm,mo,res);i=len(list(ROOT.glob('mutation_model*')));mm['inputs']['model']=save(ROOT/('mutation_model'+str(i)+'.json'),mo);res['model_export']=export(mm['inputs']['model']);mm['inputs']['native_result']=save(ROOT/('mutation_result'+str(i)+'.json'),res);return mm
def replace_root(key,fn):
 def edit(mm,mo,r):
  ref=dag('bad_'+key+'_'+str(len(refs)),fn);mm['bdd_files'][ref['file']]=refs[ref['file']];mo['original_bdds'][key]=ref
 return mutate(edit)
reject('Missing monotonicity',lambda:run(replace_root('rhoE',lambda s,t:env(s,t) or t[w.HELPER]=='true')),'ENV equation')
reject('Helper ENV uses current',lambda:run(replace_root('rhoE',lambda s,t:(env(s,t) or s[w.HELPER]=='true') and (s[w.HELPER]=='false' or t[w.HELPER]=='true'))),'ENV equation')
reject('Retained AUX violated after helper flip',lambda:run(replace_root('rhoS',lambda s,t:native_s(s,t) and (s[w.HELPER]=='false' or t['m']=='S0'))),'Full native SYS/AUX safety')
reject('Next helper used in SYS',lambda:run(replace_root('rhoS',lambda s,t:native_s(s,t) and t[w.HELPER]=='false')),'SYS support excludes next ENV/helper')
reject('AUX variable introduced in ENV',lambda:run(replace_root('rhoE',lambda s,t:s['m']=='S0')),'ENV support excludes AUX')
reject('Next SYS variable introduced in ENV',lambda:run(replace_root('rhoE',lambda s,t:t['f1']=='true')),'illegal variable support')
reject('Missing helper initializer',lambda:run(replace_root('thetaE',lambda s,t:c.theta_e(s))),'ENV initializer')
reject('Wrong SYS initializer',lambda:run(replace_root('thetaS',lambda s,t:True)),'SYS/AUX initializer')
reject('Wrong model owner',lambda:run(mutate(lambda mm,mo,r:mo['fields'][1].update(owner='SYS'))),'owner/AUX')
reject('Wrong justice order',lambda:run(mutate(lambda mm,mo,r:r['solver_justices']['SYS'].reverse())),'ordered justice')
reject('Wrong justice count',lambda:run(mutate(lambda mm,mo,r:r['preconstructor_justices']['ENV'].clear())),'ordered justice')
reject('Wrong variable order',lambda:run(mutate(lambda mm,mo,r:mo['bdd_variable_order'].reverse())),'variable order')
reject('Nonbijective encoding',lambda:run(mutate(lambda mm,mo,r:mo['fields'][0]['encoding']['false'].update(current=mo['fields'][0]['encoding']['true']['current']))),'Bijective')
def policy_mutation(fn):z=copy.copy(p);z.step=fn;return z
reject('Drops AUX',lambda:run(policy=policy_mutation(lambda s,d,e:({k:v for k,v in choose(s,d,e)[0].items() if k!='m'},d))),'retained AUX')
reject('Resets AUX',lambda:run(policy=policy_mutation(lambda s,d,e:(dict(choose(s,d,e)[0],m='S0'),d))),'Original SYS and AUX safety')
reject('Nononehot output',lambda:run(policy=policy_mutation(lambda s,d,e:(dict(choose(s,d,e)[0],f1='true',f2='true'),d))),'Onehot invariant')
reject('Invalid private bit',lambda:run(policy=policy_mutation(lambda s,d,e:(choose(s,d,e)[0],2))),'retained private priority')
z=copy.copy(p);z.initial_states=lambda:[({'e':'false','f1':'true','f2':'false','m':'S1'},3)];reject('Wrong initial AUX',lambda:run(policy=z),'initial SYS/AUX/private')
held_ctx=x.load(m,c)
original_bool=w.BOOL
try:
 w.BOOL=('false',)
 reject('Omitted true-helper/first-flip coverage',lambda:x.check_policy(held_ctx,c,p,expected),'enumeration count')
finally:w.BOOL=original_bool
bad=copy.deepcopy(m);bad['bdd_files']['rhoE.bdd']['sha256']='0'*64;reject('DAG pin change',lambda:run(bad),'pin mismatch')
for label,mut in [('basename',lambda r:r['model_export'].update(file='other.json')),('hash',lambda r:r['model_export'].update(sha256='0'*64)),('manifest_format',lambda r:r.update(model_export=m['inputs']['model']))]:
 bad=copy.deepcopy(m);rr=copy.deepcopy(result);mut(rr);bad['inputs']['native_result']=save(ROOT/('bad_export_'+label+'.json'),rr);reject('Native export '+label,lambda mm=bad:run(mm),'export binding')
w.save_new(ROOT/'QUALIFICATION.json',{'status':'PASS','artificial_only':True,'actual_saved_DAG_reads':0,'tests':tests,'named_tests':len(tests),'artificial_result':r});print(json.dumps({'status':'PASS','tests':len(tests)}),flush=True)
