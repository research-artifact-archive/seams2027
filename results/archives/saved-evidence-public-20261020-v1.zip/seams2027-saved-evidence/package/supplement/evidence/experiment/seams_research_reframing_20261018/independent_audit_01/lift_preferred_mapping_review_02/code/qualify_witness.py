"""Artificial-only qualification. Never load any Lift source/model/DAG."""
from pathlib import Path
import copy,hashlib,importlib.util,json,sys,time
HERE=Path(__file__).resolve().parent
mods={}
for name in ('witness_worker','fixture_builder'):
 spec=importlib.util.spec_from_file_location(name,HERE/(name+'.py'));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);mods[name]=mod
x,q=mods['witness_worker'],mods['fixture_builder'];w=x.w
from dataclasses import replace
OUT=Path(sys.argv[1]);OUT.mkdir();tests=[]
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def repin_model(m,model):
 p=OUT/('mutated_'+str(len(list(OUT.glob('mutated_*'))))+'.json');save(p,model);m['inputs']['model']=w.pin(p)
 if 'native_result' in m['inputs']:
  r=json.loads(Path(m['inputs']['native_result']['path']).read_text());r['model_export']={'file':p.name,'bytes':m['inputs']['model']['bytes'],'sha256':m['inputs']['model']['sha256']};rp=p.with_suffix('.result.json');save(rp,r);m['inputs']['native_result']=w.pin(rp)
def set_rho(m,c,current):
 model=json.loads(Path(m['inputs']['model']['path']).read_text());count=model['bdd_variable_count'];fields=model['fields'];field=fields[0];bit=field['current_bits' if current else 'next_bits'][0]
 raw=q.bdd_bytes(count,lambda b:not b[bit],support=[bit]);p=OUT/('rho_'+str(len(list(OUT.glob('rho_*'))))+'.bdd');p.write_bytes(raw);ref=w.pin(p);m['bdd_files'][p.name]=ref;model['original_bdds']['rhoE']={'file':p.name,'bytes':ref['bytes'],'sha256':ref['sha256']};repin_model(m,model)
def alter_encoding_order(m):
 model=json.loads(Path(m['inputs']['model']['path']).read_text());count=model['bdd_variable_count'];rename=lambda bit:count-1-bit;flip=lambda bit:bit%3==0
 changed={}
 for old,ref in m['bdd_files'].items():
  raw=Path(ref['path']).read_text();rows=[r.split() for r in raw.splitlines() if r.strip()]
  if rows[0][0]!='0':
   rows[1]=[str(rename(int(v))) for v in rows[1]]
   for row in rows[2:]:
    v=int(row[1]);row[1]=str(rename(v))
    if flip(v):row[2],row[3]=row[3],row[2]
  p=OUT/('encoded_'+str(len(list(OUT.glob('encoded_*'))))+'.bdd');p.write_text('\n'.join(' '.join(r) for r in rows)+'\n');changed[old]=w.pin(p)
 def replace_refs(v):
  if isinstance(v,dict):
   if 'file' in v:
    ref=changed[v['file']];return {'file':Path(ref['path']).name,'bytes':ref['bytes'],'sha256':ref['sha256']}
   return {k:replace_refs(z) for k,z in v.items()}
  if isinstance(v,list):return [replace_refs(z) for z in v]
  return v
 model=replace_refs(model)
 for field in model['fields']:
  for key in ('current_bits','next_bits'):field[key]=[rename(bit) for bit in field[key]]
  for val in field['encoding'].values():
   for timing,mapping in val.items():val[timing]={str(rename(int(bit))):bool(value)^flip(int(bit)) for bit,value in mapping.items()}
 for key in ('all_current_bits','all_next_bits','bdd_variable_order'):model[key]=[rename(bit) for bit in model[key]]
 m['bdd_files']={Path(ref['path']).name:ref for ref in changed.values()};repin_model(m,model)

a,c=q.build_fixture(OUT/'original',False,'JOB_UNREALIZABLE_NO_CONTROLLER');b,c2=q.build_fixture(OUT/'reduced',True,'JOB_UNREALIZABLE_NO_CONTROLLER')
c=replace(c,rho_e=lambda s,t:t['e']=='false')
for m in (a,b):
 p=json.loads(Path(m['inputs']['profile']['path']).read_text());p['profiles'][c.candidate]['formulas']['rhoE']=['not',['var','e',True]]
 path=OUT/('profile_'+str(len(list(OUT.glob('profile_*'))))+'.json');save(path,p);m['inputs']['profile']=w.pin(path)
set_rho(a,c,False);set_rho(b,c,True);alter_encoding_order(a);alter_encoding_order(b)
s={'e':'false','s':'false','m':'S0','p':'false'};t=dict(s,e='true',s='true')
witnesses=[{'name':'artificial_timing','current':s,'next':t,'expected':{'original.rhoE':False,'reduced_helper_false.rhoE':True}}]
def run(aa=a,bb=b):return x.analyze(aa,bb,c,lambda s,t:s['e']=='false',('e','s'),('e',),witnesses)
result=run();assert result['counts']['rhoE_support_pairs']==8 and result['counts']['rhoE_disagreements']==4;tests.append('Artificial current-next shift, reversed bit order and inverted encodings, all 8 support assignments')
def rejection(name,fn,contains):
 try:fn()
 except (ValueError,KeyError,TypeError) as error:
  assert contains in str(error),(name,str(error));tests.append(name+': '+str(error));return
 raise AssertionError(name+' accepted')
def mutate_model(m,fn):
 mm=copy.deepcopy(m);model=json.loads(Path(mm['inputs']['model']['path']).read_text());fn(model);repin_model(mm,model);return mm
rejection('Owner mutation',lambda:run(mutate_model(a,lambda m:m['fields'][0].update(owner='SYS'))),'owner/AUX')
rejection('Encoding mutation',lambda:run(mutate_model(a,lambda m:m['fields'][0]['encoding']['false'].update(current=m['fields'][0]['encoding']['true']['current']))),'Bijective')
rejection('Order mutation',lambda:run(mutate_model(a,lambda m:m['bdd_variable_order'].reverse())),'variable order')
rejection('Schema mutation',lambda:run(mutate_model(a,lambda m:m.update(schema='wrong'))),'schema')
rejection('Source pin mutation',lambda:run(mutate_model(a,lambda m:m['input'].update(sha256='0'*64))),'source pin')
bad=copy.deepcopy(a);key=next(iter(bad['bdd_files']));bad['bdd_files'][key]['sha256']='0'*64
rejection('Saved DAG pin mutation',lambda:run(bad),'pin mismatch')
def dag_mutation(m,fieldname,prime):
 mm=copy.deepcopy(m);model=json.loads(Path(mm['inputs']['model']['path']).read_text());field=next(f for f in model['fields'] if f['name']==fieldname);bit=field['next_bits' if prime else 'current_bits'][0];p=OUT/('unsupported_'+fieldname+str(prime)+'.bdd')
 order=model['bdd_variable_order'];p.write_text(str(model['bdd_variable_count'])+'\n'+' '.join(map(str,order))+'\n2 '+str(bit)+' 0 1\n');ref=w.pin(p);mm['bdd_files'][p.name]=ref;model['original_bdds']['rhoE']={'file':p.name,'bytes':ref['bytes'],'sha256':ref['sha256']};repin_model(mm,model);return mm
rejection('AUX support mutation',lambda:run(dag_mutation(a,'m',False)),'unsupported AUX')
rejection('Next SYS support mutation',lambda:run(dag_mutation(a,'s',True)),'illegal variable support')
rejection('Prime timing mutation',lambda:run(dag_mutation(a,'e',False)),'full-support source relation')
rejection('Wrong reduced variant',lambda:x.analyze(a,b,c,lambda s,t:t['e']=='false',('e','s'),('e',),witnesses),'characterization')
wrong=copy.deepcopy(witnesses);wrong[0]['next'].pop('m')
rejection('Missing witness AUX',lambda:x.analyze(a,b,c,lambda s,t:s['e']=='false',('e','s'),('e',),wrong),'Complete witness')

wrong=copy.deepcopy(b);rp=OUT/'wrong_export_basename.json';rr=json.loads(Path(wrong['inputs']['native_result']['path']).read_text());rr['model_export']['file']='other_model.json';save(rp,rr);wrong['inputs']['native_result']=w.pin(rp)
rejection('Wrong native model export basename',lambda:run(a,wrong),'helper/model export pin')
wrong=copy.deepcopy(b);rp=OUT/'wrong_export_hash.json';rr=json.loads(Path(wrong['inputs']['native_result']['path']).read_text());rr['model_export']['sha256']='0'*64;save(rp,rr);wrong['inputs']['native_result']=w.pin(rp)
rejection('Wrong native model export hash',lambda:run(a,wrong),'helper/model export pin')
wrong=copy.deepcopy(b);rp=OUT/'manifest_shaped_export.json';rr=json.loads(Path(wrong['inputs']['native_result']['path']).read_text());rr['model_export']=wrong['inputs']['model'];save(rp,rr);wrong['inputs']['native_result']=w.pin(rp)
rejection('Manifest-shaped native export rejected',lambda:run(a,wrong),'helper/model export pin')

res={'status':'PASS','checks':tests,'named_checks':len(tests),'artificial_only':True,'real_source_or_DAG_evaluations':0,'result':result}
w.save_new(OUT/'QUALIFICATION.json',res);print(json.dumps({'status':'PASS','checks':len(tests)}),flush=True)
