"""One Root-authorized saved-data diagnostic worker, no retry and no native."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib,importlib.util,json,sys
ROOT=Path(__file__).resolve().parent

def pin(p):
 p=Path(p).resolve(strict=True);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def verify(r):assert pin(r['path'])==r,'Changed frozen input: '+r['path']
def read(p):return json.loads(Path(p).read_text())
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
go=read(ROOT/'ROOT_GO.json');assert go['schema']=='root-lift-full-helper-extension-go-v1' and go['start_authorized'] is True
verify(go['closure']);closure=read(go['closure']['path']);assert go['closure']==pin(ROOT/'CLOSURE.json')
assert closure['attempts']==1 and closure['native_processes']==0
assert pin(sys.executable)==closure['python_executable']
for ref in closure['files']:verify(ref)
start=datetime.now(timezone.utc);deadline=min(datetime.fromisoformat(go['deadline_utc']),start+timedelta(seconds=90))
assert (deadline-start).total_seconds()>=80,'Insufficient worker + cleanup time'
spec=importlib.util.spec_from_file_location('extension_supervisor',ROOT/'supervisor/bounded_process.py');stage=importlib.util.module_from_spec(spec);spec.loader.exec_module(stage)
run=ROOT/'execution_01';run.mkdir()
process=stage.run_bounded([sys.executable,'-I','-S','-B',str(ROOT/'code/extension_worker.py'),str(ROOT/'PROTOCOL.json'),str(run/'output')],run/'process',deadline.isoformat(),wall_seconds=60,rss_bytes=536870912,stream_bytes=1048576,file_bytes=16777216,output_tree=run,output_tree_bytes=33554432,aggregate_tree=ROOT,aggregate_tree_bytes=134217728,min_free_bytes=1073741824)
clean=(process['status']=='PROCESS_COMPLETED' and process['exit_code']==0 and not process['parent_aborted'] and process['receipt_persisted'] and process['parent_finalization_completed'] and process['owned_child_reaped'] and not process['fatal_reasons'] and not process['resource_reasons'] and process['exact_child_wait4']['exact_child_reaped'] and not process['exact_child_wait4']['authority_lost'] and process['final_group_observation']['state']=='ABSENT' and all(x['complete'] for x in process['capture'].values()))
receipt={'schema':'lift-full-helper-extension-execution-v1','status':'COMPLETE' if clean else 'UNKNOWN_PROCESS_FAILURE','process':pin(run/'process/PROCESS_RECEIPT.json'),'root_go':pin(ROOT/'ROOT_GO.json'),'closure':pin(ROOT/'CLOSURE.json'),'attempts':1,'native_processes':0,'full_reset_uses':0}
try:
 for ref in closure['files']:verify(ref)
 receipt['post_input_pins']='PASS'
 result=read(run/'output/EXTENSION_RESULT.json');receipt['result']=pin(run/'output/EXTENSION_RESULT.json');receipt['result_status']=result['status']
 assert result['protocol_pin']==pin(ROOT/'PROTOCOL.json') and result['protocol_bindings']==read(ROOT/'PROTOCOL.json')
 assert result['code_pins']==closure['worker_code']
 assert result['status']=='COMPLETE_NATIVE_POLICY_EXTENSION_SAFETY'
except BaseException as e:receipt.update(status='UNKNOWN_VALIDATION_FAILURE',error=type(e).__name__+':'+str(e))
save(run/'EXECUTION_RECEIPT.json',receipt);print(json.dumps(receipt),flush=True)
