"""Quantify original initializers over source-bound, previously saved K/V."""
from pathlib import Path
from datetime import datetime,timezone
import copy,hashlib,importlib.util,json,sys
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('initial_quantifier_core',HERE/'initial_condition.py')
core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
def pin(path):
    p=Path(path).resolve();raw=p.read_bytes()
    return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def read(ref):
    assert pin(ref['path'])==ref,ref['path']
    return json.loads(Path(ref['path']).read_text())
def main():
    manifest_path,out=Path(sys.argv[1]).resolve(),Path(sys.argv[2]).absolute()
    assert not out.exists() and not out.is_symlink()
    m=json.loads(manifest_path.read_text());assert m['schema']=='initial-region-saved-inputs-v1'
    assert [r['candidate_id'] for r in m['rows']]==m['candidate_order']
    for ref in m['files']:assert pin(ref['path'])==ref
    adapted=read(m['adapted_nine_profiles'])['profiles']
    out.mkdir();rows=[]
    for row in m['rows']:
        ident,refs=row['candidate_id'],row['inputs']
        source=refs['source'];profiles=read(refs['profile']);p=profiles['profiles'][ident]
        cert=read(refs['cooperative_certificate']);sem=read(refs['semantics'])['cooperative']
        region=read(refs['regions']);result=read(refs['population_result']);model=read(refs['model']);native=read(refs['result'])
        assert p['fixture_id']==ident and cert['fixture_id']==ident and result['fixture']==ident
        for source_ref in [p['source'],cert['source_profile_pins']['source'],model['input']]:
            assert source_ref['bytes']==source['bytes'] and source_ref['sha256']==source['sha256']
        assert cert['source_profile_pins']['profiles_sha256']==refs['profile']['sha256']
        assert cert['model_sha256']==refs['model']['sha256'] and cert['result_sha256']==refs['result']['sha256']
        assert cert['model_and_replay_validated'] is True and cert['original_model_audit']['status']=='PASS'
        assert sem['model']['status']=='PASS' and sem['source_binding']['fixture']==ident
        assert cert['normalization_and_handoff_audit']['status']=='PASS'
        assert sem['native_normalization']['status']=='PASS'
        for name in ['source','profile','model','result','input_roster']:
            historical=sem['source_binding'][name]
            assert historical['bytes']==refs[name]['bytes'] and historical['sha256']==refs[name]['sha256']
        assert native['model_export']['sha256']==refs['model']['sha256']
        for key,value in result['regions'].items():assert region[key]==value,(ident,key)
        if ident in adapted:
            assert adapted[ident]==dict(p,case_id=ident,variant='initializers'),ident
        k=core.check(p,region)
        k['region_parameter']='K'
        v_region=dict(region,K=region['V'],K_valuations=region['V_valuations'])
        v=core.check(p,v_region)
        v['region_parameter']='V'
        v['formula']=v['formula'].replace('K(e,s)','V(e,s)')
        for key in list(v):
            if '_K' in key or key.startswith('missing_K'):
                v[key.replace('_K','_V')]=v.pop(key)
        for env_row in v['environment_rows']:
            for key in list(env_row):
                if '_K_' in key:env_row[key.replace('_K_','_V_')]=env_row.pop(key)
        v['scope']='Exact original-initializer predicate for separately certified saved V; region correctness is a prior premise, and no controller is executed.'
        # This is a check of saved evidence, not an additional fixed-point solve.
        equality=None
        if 'REGION_COMPARISON.json' in refs:
            comparison=read(refs['REGION_COMPARISON.json']);arena=read(refs['arena.json'])
            assert read(refs['ARENA_AUDIT.json'])['status']=='PASS'
            assert comparison['equal'] is True and comparison['new_explicit_vertices']==comparison['native_vertices']
            semantics=arena['metadata']['vertex_semantics']
            explicit_members={tuple(semantics[q]['valuation'][n] for n in region['field_order']) for q in comparison['new_explicit_vertices']}
            saved_members={tuple(s[n] for n in region['field_order']) for s in region['K_valuations']}
            assert explicit_members==saved_members
            assert comparison['new_explicit_K']==comparison['native_K']==region['K']
            equality='SAVED_EXPLICIT_AND_NATIVE_K_EXACT_MEMBERSHIP_EQUAL'
        value={'candidate_id':ident,'purpose':row['purpose'],'I_M_K':k,'I_M_V':v,'historical_residual_entry':region['entry'],'saved_region_evidence':{'K':region['K'],'V':region['V'],'W':region['W'],'all_W_V_minus_K':region['all_W_V_minus_K'],'explicit_native_K_comparison':equality,'region_recomputed':False},'input_bindings':refs}
        with (out/(ident+'.json')).open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
        rows.append({'candidate_id':ident,'K':region['K'],'V':region['V'],'I_M_K':k['I_M_K_universal_predicate'],'I_M_V':v['I_M_V_universal_predicate'],'nonvacuous':k['legal_ENV_initial_assignments']>0,'legal_ENV_initial_assignments':k['legal_ENV_initial_assignments'],'missing_K_responses':len(k['missing_K_response_environment_assignments']),'historical_entry_K':region['entry']['K'],'result':pin(out/(ident+'.json'))})
    for ref in m['files']:assert pin(ref['path'])==ref
    baseline={r['candidate_id']:r for r in rows[:2]}
    assert baseline['arbiter__preferred']['I_M_K'] is False
    assert baseline['traffic_single__preferred']['I_M_K'] is True
    summary={'status':'COMPLETE_SOURCE_BOUND_ORIGINAL_INITIAL_REGION_CHECK','completed_utc':datetime.now(timezone.utc).isoformat(),'rows':rows,'input_manifest':pin(manifest_path),'source_code':pin(Path(__file__)),'core':pin(HERE/'initial_condition.py'),'baseline_controls':'PASS','region_fixed_point_solves':0,'new_native_calls':0,'controller_fairness_claims':0,'scope':m['scope'],'full_reset_uses':0}
    with (out/'RESULT.json').open('x') as f:json.dump(summary,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'status':summary['status'],'rows':rows},ensure_ascii=False))
if __name__=='__main__':main()
