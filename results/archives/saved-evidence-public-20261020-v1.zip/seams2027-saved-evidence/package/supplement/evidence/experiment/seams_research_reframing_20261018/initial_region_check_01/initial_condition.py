"""Exact typed quantifier check of an original initializer against a saved region.

This does not compute a winning region. Region correctness is a separately
identified, previously certified premise. Only current-state initial ASTs are
accepted; there is no dependency on either production or independent BDD code.
"""
from itertools import product
import math


class Invalid(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise Invalid(message)


def expression(expr, fields):
    """Validate first, then return (interpreter, exact syntactic support)."""
    if type(expr) is bool:
        return lambda state: expr, set()
    require(type(expr) is list and expr and type(expr[0]) is str, 'Initial AST shape')
    op = expr[0]
    if op == 'var':
        require(len(expr) == 3 and type(expr[1]) is str and expr[1] in fields,
                'Initial Boolean variable name')
        require(expr[2] is False, 'Initial variable must be unprimed')
        name = expr[1]
        require(set(fields[name]['domain']) == {'false', 'true'}, 'var on non-Boolean domain')
        return lambda state: state[name] == 'true', {name}
    if op == 'eq':
        require(len(expr) == 4 and type(expr[1]) is str and expr[1] in fields,
                'Initial equality variable name')
        require(expr[3] is False, 'Initial equality must be unprimed')
        name, value = expr[1], expr[2]
        require(type(value) is str and value in fields[name]['domain'], 'Typed equality value')
        return lambda state: state[name] == value, {name}
    require(op in {'and', 'or', 'not', 'implies', 'iff'}, 'Unsupported initial operator')
    if op == 'not':
        require(len(expr) == 2, 'Unary not arity')
    elif op in {'implies', 'iff'}:
        require(len(expr) == 3, 'Binary initial operator arity')
    else:
        require(len(expr) >= 2, 'Nonempty initial conjunction/disjunction')
    children = [expression(child, fields) for child in expr[1:]]
    functions = [x[0] for x in children]
    support = set().union(*(x[1] for x in children))
    if op == 'and':
        fn = lambda state: all(f(state) for f in functions)
    elif op == 'or':
        fn = lambda state: any(f(state) for f in functions)
    elif op == 'not':
        fn = lambda state: not functions[0](state)
    elif op == 'implies':
        fn = lambda state: not functions[0](state) or functions[1](state)
    else:
        fn = lambda state: functions[0](state) == functions[1](state)
    return fn, support


def check(profile, region):
    roster = profile['expected_fields_in_native_order']
    require(type(roster) is list and roster, 'Nonempty field roster')
    names = [f['name'] for f in roster]
    require(all(type(n) is str for n in names) and len(set(names)) == len(names),
            'Unique string field names')
    fields = dict(zip(names, roster))
    for field in roster:
        domain = field['domain']
        require(type(domain) is list and domain and all(type(x) is str for x in domain),
                'Nonempty string-valued typed domain')
        require(len(set(domain)) == len(domain), 'No duplicate domain values')
        require(field['owner'] in {'ENV', 'SYS'}, 'Field owner')
        require(field['role'] in {'ENV', 'SYS', 'AUX'}, 'Field role')
        require((field['owner'] == 'ENV') == (field['role'] == 'ENV'), 'ENV ownership/role')
    environment = [f['name'] for f in roster if f['owner'] == 'ENV']
    require(profile['public_ENV'] == environment, 'Exact original ENV roster/order')
    require(profile['public_SYS'] == [f['name'] for f in roster if f['role'] == 'SYS'],
            'Exact original public SYS roster/order')
    require(region['field_order'] == names, 'Saved region field order')
    carrier = math.prod(len(f['domain']) for f in roster)
    require(carrier <= 4096 and type(region['carrier']) is int and region['carrier'] == carrier,
            'Complete typed carrier count/cap')
    raw_members = region['K_valuations']
    require(type(raw_members) is list, 'Saved K valuation list')
    require(type(region['K']) is int and region['K'] == len(raw_members), 'Saved K count')
    members = set()
    for state in raw_members:
        require(type(state) is dict and set(state) == set(names), 'Complete K valuation fields')
        require(all(type(state[n]) is str and state[n] in fields[n]['domain'] for n in names),
                'Typed K valuation')
        key = tuple(state[n] for n in names)
        require(key not in members, 'No duplicate K valuation')
        members.add(key)
    theta_e, support_e = expression(profile['formulas']['thetaE'], fields)
    theta_s, support_s = expression(profile['formulas']['thetaS'], fields)
    require(support_e <= set(environment), 'Original thetaE may use only current ENV')
    rows = {}
    evaluations = 0
    for values in product(*(f['domain'] for f in roster)):
        state = dict(zip(names, values))
        environment_key = tuple(state[n] for n in environment)
        legal = theta_e(state)
        if environment_key not in rows:
            rows[environment_key] = {
                'environment': dict(zip(environment, environment_key)),
                'thetaE': legal,
                'typed_system_and_AUX_assignments': 0,
                'thetaS_responses': 0,
                'thetaS_and_K_responses': 0,
                'first_K_response': None,
            }
        row = rows[environment_key]
        require(row['thetaE'] is legal, 'thetaE is independent of SYS/AUX')
        row['typed_system_and_AUX_assignments'] += 1
        evaluations += 1
        if legal and theta_s(state):
            row['thetaS_responses'] += 1
            if values in members:
                row['thetaS_and_K_responses'] += 1
                if row['first_K_response'] is None:
                    row['first_K_response'] = state
    legal_rows = [row for row in rows.values() if row['thetaE']]
    missing = [row['environment'] for row in legal_rows if row['thetaS_and_K_responses'] == 0]
    no_system_response = [row['environment'] for row in legal_rows if row['thetaS_responses'] == 0]
    predicate = not missing
    status = ('EMPTY_ENV_INITIAL_DOMAIN' if not legal_rows else
              'INITIAL_REGION_CONDITION_TRUE' if predicate else 'INITIAL_REGION_CONDITION_FALSE')
    return {
        'schema': 'typed-original-initial-region-condition-v1',
        'status': status,
        'formula': 'forall original ENV e: thetaE(e) implies exists original SYS/logical-AUX s: thetaS(e,s) and K(e,s)',
        'carrier': carrier, 'saved_K_states': len(members),
        'typed_initial_state_evaluations': evaluations,
        'all_ENV_assignments': len(rows), 'legal_ENV_initial_assignments': len(legal_rows),
        'I_M_K_universal_predicate': predicate,
        'vacuous_due_to_empty_ENV_initial_domain': not legal_rows,
        'nonvacuous_initial_region_condition': bool(legal_rows) and predicate,
        'missing_K_response_environment_assignments': missing,
        'missing_any_thetaS_response_environment_assignments': no_system_response,
        'thetaE_support': sorted(support_e), 'thetaS_support': sorted(support_s),
        'environment_rows': list(rows.values()),
        'region_recomputed': False,
        'scope': 'Exact original-initializer predicate for a separately certified saved K; neither residual trace entry nor K nonemptiness is used as a substitute. This check does not establish correctness of K or execute a controller.',
    }
