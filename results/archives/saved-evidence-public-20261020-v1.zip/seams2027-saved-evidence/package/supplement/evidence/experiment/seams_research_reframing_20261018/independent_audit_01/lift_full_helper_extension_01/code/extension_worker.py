"""Evaluate a fixed policy on the full saved native relation, no game/graph solve."""
from pathlib import Path
import hashlib,importlib.util,json,sys,traceback
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('extension_independent',HERE/'audit_worker.py');w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
spec=importlib.util.spec_from_file_location('exact_extended_policy',HERE/'policy.py');policy=importlib.util.module_from_spec(spec);spec.loader.exec_module(policy)

def load(manifest,c):
    refs=manifest['inputs'];raw={name:w.read_pin(ref) for name,ref in refs.items()}
    w.need(len(raw['source'])==c.source_bytes and w.pin(refs['source']['path'])['sha256']==c.source_sha256,'Exact source identity')
    result,model,profile=(w.decode_json(raw[k]) for k in ('native_result','model','profile'))
    w.need(model['schema']=='k7-native-model-export-v1' and model['fixture_id']==model['case_id']==c.candidate and model['variant']=='initializers','Native model identity')
    w.need(model['input']['sha256']==c.source_sha256 and model['input']['bytes']==c.source_bytes,'Native model source pin')
    expected={'file':Path(refs['model']['path']).name,'bytes':refs['model']['bytes'],'sha256':refs['model']['sha256']}
    w.need(result['helper_added'] is True and result['model_export']==expected and result['input_sha256']==c.source_sha256,'Native source/helper/export binding')
    for ref in manifest['bdd_files'].values():w.read_pin(ref)
    if 'native_process' in raw:w.verify_process(w.decode_json(raw['native_process']))
    return w.ModelAudit(manifest,c,raw,result,model,profile['profiles'][c.candidate])

def check_policy(ctx,c,p,expected_counts):
    need=w.need
    need(tuple(p.FIELDS)==c.names and tuple(p.ENV)==c.env and tuple(p.SYS)==c.system and tuple(p.AUX)==tuple(n for n,_ in c.aux),'Exact policy field/AUX roster')
    need(p.INITIAL_PRIORITY==3,'Exact policy initial private priority')
    support_e={bit for n in c.env+c.system+(w.HELPER,) for bit in ctx.field_by_name[n]['current_bits']}
    support_e|=ctx.env_next
    need(ctx.native_formulas['rhoE'].support<=support_e,'Native ENV support excludes AUX and next SYS')
    need(ctx.native_formulas['rhoS'].support<=ctx.current|ctx.sys_next,'Native SYS support excludes next ENV/helper')
    originals=w.states_for(c.names,c.values,1024);full=w.states_for(ctx.names,ctx.values,2048)
    onehot=[s for s in originals if sum(s[n]=='true' for n in c.system)==1]
    need(len(onehot)==expected_counts['source_invariant_states'] and len(full)==expected_counts['full_native_states'],'Complete invariant/native carrier sizes')
    phases={'original':ctx.model['original_justices'],'preconstructor':ctx.result['preconstructor_justices'],'solver':ctx.result['solver_justices']}
    justice_roots={phase:{owner:[ctx.dag(ref,ctx.current) for ref in refs[owner]] for owner in ('ENV','SYS')} for phase,refs in phases.items()}
    for s in full:
        bits=ctx.bits(s);helper=s[w.HELPER]=='true'
        need(ctx.native_formulas['thetaE'].value(bits)==(c.theta_e(s) and not helper),'Full native ENV initializer')
        need(ctx.native_formulas['thetaS'].value(bits)==c.theta_s(s),'Full native SYS/AUX initializer')
        ee,ss=c.justice(s)
        for phase,roots in justice_roots.items():
            need([root.value(bits) for root in roots['ENV']]==ee+[not helper] and [root.value(bits) for root in roots['SYS']]==ss,'Full ordered justice: '+phase)
    for key,allowed,prime in (('domain',ctx.current,False),('domain_ENV_next',ctx.env_next,True),('domain_SYS_next',ctx.sys_next,True)):
        root=ctx.dag(ctx.model['original_bdds'][key],allowed)
        need(all(root.value(ctx.bits(s,prime)) for s in full),'Complete typed native domain: '+key)
    for s in originals:
        need(ctx.profile_formulas['thetaE'](s)==c.theta_e(s) and ctx.profile_formulas['thetaS'](s)==c.theta_s(s),'Source/profile initializer')
        for owner,expected in zip(('ENV','SYS'),c.justice(s)):
            need([f(s) for f in ctx.profile_justices[owner]]==expected,'Source/profile justice')
    inputs=w.states_for(c.env,c.values,16);initials=p.initial_states()
    need(len(initials)==expected_counts['initial_ENV_choices'],'Initial choice count')
    actual_env=set()
    for s,priority in initials:
        need(set(s)==set(c.names) and priority==3 and c.theta_e(s) and c.theta_s(s),'Exact source initial SYS/AUX/private values')
        need(sum(s[n]=='true' for n in c.system)==1,'Initial onehot invariant')
        actual_env.add(tuple(s[n] for n in c.env));native=ctx.native_state(s)
        need(ctx.native_formulas['thetaE'].value(ctx.bits(native)) and ctx.native_formulas['thetaS'].value(ctx.bits(native)),'Native initial response')
    expected_env={tuple(e[n] for n in c.env) for e in inputs if c.theta_e(e)}
    need(actual_env==expected_env and len(actual_env)==len(initials),'Universal original/native initial ENV coverage')
    classes={a+b:{'assignments':0,'native_ENV_legal':0,'native_SYS_safe':0,'source_SYS_safe':0,'first_legal_witness':None} for a in '01' for b in '01'}
    digest=hashlib.sha256();assignments=0;current_count=0
    for s in onehot:
        for priority in (1,3):
            for helper in w.BOOL:
                current=ctx.native_state(s,helper);cb=ctx.bits(current);legal_count=0;current_count+=1
                for e in inputs:
                    t,next_priority=p.step(s,priority,e)
                    need(type(t) is dict and set(t)==set(c.names) and all(t[n] in c.values[n] for n in c.names),'Complete typed successor with retained AUX')
                    need(type(next_priority) is int and next_priority in (1,3),'Valid retained private priority')
                    need(all(t[n]==e[n] for n in c.env),'Exact next ENV preserved')
                    need(sum(t[n]=='true' for n in c.system)==1,'Onehot invariant maintained')
                    source_e=c.rho_e(s,t);source_s=c.rho_s(s,t)
                    need(source_e==ctx.profile_formulas['rhoE'](s,t) and source_s==ctx.profile_formulas['rhoS'](s,t),'Full policy source/profile transition')
                    need(source_s is True,'Original SYS and AUX safety for every policy response')
                    for next_helper in w.BOOL:
                        successor=ctx.native_state(t,next_helper);joined=cb|ctx.bits(successor,True)
                        env=ctx.native_formulas['rhoE'].value(joined);system=ctx.native_formulas['rhoS'].value(joined)
                        expected_env=(source_e or next_helper=='true') and (helper=='false' or next_helper=='true')
                        if env!=expected_env: raise w.AuditError('Full native ENV equation/monotonicity on invariant carrier: '+json.dumps({'current':current,'priority':priority,'next':successor,'next_priority':next_priority,'observed':env,'expected':expected_env},sort_keys=True))
                        if system is not True: raise w.AuditError('Full native SYS/AUX safety including first/post helper flip: '+json.dumps({'current':current,'priority':priority,'next':successor,'next_priority':next_priority},sort_keys=True))
                        key=str(int(helper=='true'))+str(int(next_helper=='true'));row=classes[key]
                        row['assignments']+=1;row['native_ENV_legal']+=int(env);row['native_SYS_safe']+=int(system);row['source_SYS_safe']+=int(source_s)
                        if env:
                            legal_count+=1
                            if row['first_legal_witness'] is None:row['first_legal_witness']={'current':current,'priority':priority,'next':successor,'next_priority':next_priority}
                        digest.update((json.dumps({'s':current,'priority':priority,'t':successor,'next_priority':next_priority,'ENV':env,'SYS':system},sort_keys=True,separators=(',',':'))+'\n').encode());assignments+=1
                need(legal_count>0,'Native legal ENV choice nonempty at every invariant policy state')
    need(assignments==expected_counts['policy_assignments'] and current_count==expected_counts['native_current_policy_states'],'Complete 4-class policy enumeration count')
    need(all(r['assignments']==assignments//4 and r['native_SYS_safe']==r['assignments'] for r in classes.values()),'Every helper class covered with full SYS safety')
    need(classes['10']['native_ENV_legal']==0 and classes['01']['native_ENV_legal']==assignments//4 and classes['11']['native_ENV_legal']==assignments//4,'First flip/postflip/monotonicity complete counts')
    inverse={bit:{'field':n,'timing':timing} for n,f in ctx.field_by_name.items() for timing,key in (('current','current_bits'),('next','next_bits')) for bit in f[key]}
    return {'status':'COMPLETE_NATIVE_POLICY_EXTENSION_SAFETY','source_invariant_states':len(onehot),'native_full_states_checked':len(full),'native_current_policy_states':current_count,'policy_assignments':assignments,'initial_ENV_choices':len(initials),'helper_classes':classes,'ordered_assignment_sha256':digest.hexdigest(),'native_relation_support':{name:[dict(inverse[bit],bit=bit) for bit in sorted(root.support)] for name,root in ctx.native_formulas.items()},'all_original_SYS_AUX_policy_responses_safe':True,'all_full_native_SYS_AUX_policy_responses_safe':True,'all_native_ENV_legal_inputs_covered':True,'full_initial_domain_ordered_justice_checks':True,'source_graph_recomputed':False,'native_runs':0,'game_fixed_point_runs':0}

def bind_premise(refs,c):
    cert=w.decode_json(w.read_pin(refs['source_positive_certificate']));run=w.decode_json(w.read_pin(refs['source_positive_receipt']))
    need=w.need
    need(run['status']==cert['status']=='COMPLETE_POSITIVE_SOURCE_WITNESS' and run['owned_cleanup_confirmed'] is True and run['all_frozen_inputs_unchanged'] is True,'Completed source-positive premise')
    need(cert['strict'] is True and cert['nonconflicting'] is True and cert['all_legal_ENV_inputs_preserved'] is True and cert['all_original_safety_and_logical_AUX_updates'] is True and cert['all_input_pins_unchanged'] is True,'Strict/cooperative complete source-positive certificate')
    need(cert['source_candidate']==c.candidate and cert['original_fields']==list(c.names) and cert['logical_AUX']==[n for n,_ in c.aux],'Source-positive original field/AUX identity')
    need(cert['source']['bytes']==c.source_bytes and cert['source']['sha256']==c.source_sha256,'Source-positive source identity')
    need(run['certificate']==refs['source_positive_certificate'] and run['controller']==cert['controller']==refs['source_positive_controller'],'Source-positive certificate/controller binding')
    need(cert['policy']==refs['policy'] and cert['source_oracle']==refs['source_oracle'],'Source-positive exact policy/source oracle')
    for name,key in (('policy.py','policy'),('source_contracts.py','source_oracle')):
        actual=w.pin(HERE/name);need(actual['bytes']==refs[key]['bytes'] and actual['sha256']==refs[key]['sha256'],'Unchanged copied '+name)
    need(run['input_manifest']==cert['input_manifest'],'Source-positive input manifest binding')
    w.read_pin(run['input_manifest']);w.read_pin(cert['controller']);w.read_pin(run['process'])
    proc=w.decode_json(w.read_pin(run['process']));w.verify_process(proc)
    need(proc['exact_child_wait4']['exact_child_reaped'] is True and proc['parent_finalization_completed'] is True and proc['receipt_persisted'] is True and not proc['parent_aborted'],'Exact source-positive process closure')
    return {'certificate':refs['source_positive_certificate'],'receipt':refs['source_positive_receipt'],'controller':refs['source_positive_controller'],'states':cert['state_count'],'edges':cert['edge_count'],'initial_ENV_choices':cert['original_initial_ENV_assignments'],'strict':True,'cooperation':True,'fairness_recomputed':False}

def execute(protocol):
    w.need(protocol['schema']=='lift-full-helper-policy-extension-protocol-v1' and protocol['candidate_id']=='lift__trivial_1','Exact extension protocol/candidate')
    refs=protocol['inputs']
    for ref in refs.values():w.read_pin(ref)
    c=w.CONTRACTS['lift__trivial_1'];premise=bind_premise(refs,c)
    manifest=w.decode_json(w.read_pin(refs['native_manifest']));w.need(manifest['schema']=='remaining-nine-independent-audit-inputs-v1' and manifest['candidate_id']==c.candidate,'Exact native manifest')
    ctx=load(manifest,c)
    result=check_policy(ctx,c,policy,{'source_invariant_states':384,'full_native_states':2048,'initial_ENV_choices':2,'native_current_policy_states':1536,'policy_assignments':49152})
    result['source_positive_premise']=premise;result['native_input_bindings']=manifest;result['protocol_bindings']=protocol
    result['full_native_strict_strategy']='Established by complete invariant safety check plus monotone-helper case split and bound source-positive liveness certificate.'
    result['helper_false_original_view_cooperative']=True;result['full_native_cooperation_after_helper_true_claimed']=False;result['arbitrary_invariant_state_liveness_claimed']=False;result['native_core_memory_vs_extraction_attribution']=None
    return result

def main():
    output=Path(sys.argv[2]);output.mkdir()
    try:
        result=execute(w.decode_json(Path(sys.argv[1]).read_bytes()));result['protocol_pin']=w.pin(sys.argv[1]);result['code_pins']=[w.pin(HERE/name) for name in ('extension_worker.py','audit_worker.py','source_contracts.py','independent_core.py','policy.py')];code=0
    except BaseException as e:result={'status':'UNKNOWN_NATIVE_POLICY_EXTENSION','error':type(e).__name__+':'+str(e),'traceback':traceback.format_exc()};code=2
    w.save_new(output/'EXTENSION_RESULT.json',result);print(json.dumps({'status':result['status']}),flush=True);return code
if __name__=='__main__':sys.exit(main())
