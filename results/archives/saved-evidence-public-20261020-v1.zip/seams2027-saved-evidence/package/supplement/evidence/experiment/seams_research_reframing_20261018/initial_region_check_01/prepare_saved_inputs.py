"""Pin existing evidence; do not evaluate formulas, DAGs, regions, or graphs."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
POP=ROOT/'experiment/seams_candidate_search_20261015/population_expansion/v2/population'
RUNTIME=HERE.parent/'runtime_closure_01'
def pin(path):
    p=Path(path).resolve();raw=p.read_bytes()
    return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def read(p):return json.loads(Path(p).read_text())
native=read(RUNTIME/'NATIVE_INPUTS.json')
order=['arbiter__preferred','traffic_single__preferred']+native['order']
rows=[];files={}
def add(p):
    ref=pin(p);files[ref['path']]=ref;return ref
def bound(ref):
    actual=add(ROOT/ref['path'])
    assert actual['bytes']==ref['bytes'] and actual['sha256']==ref['sha256']
    return actual
for candidate in order:
    base=POP/candidate;sem=read(base/'SOURCE_SEMANTICS.json')['cooperative']
    refs={name:bound(sem['source_binding'][name]) for name in ['source','profile','model','result','input_roster']}
    refs.update({name:add(base/filename) for name,filename in [('regions','REGIONS.json'),('population_result','RESULT.json'),('semantics','SOURCE_SEMANTICS.json'),('cooperative_certificate','GENERIC_cooperative_CERTIFICATE.json')]})
    for optional in ['REGION_COMPARISON.json','arena.json','ARENA_AUDIT.json']:
        if (base/optional).exists():refs[optional]=add(base/optional)
    rows.append({'candidate_id':candidate,'purpose':'declared_existing_baseline_control' if candidate not in native['order'] else 'remaining_nine','inputs':refs})
for name in ['initial_condition.py','saved_worker.py','prepare_saved_inputs.py','SYNTHETIC_PROTOCOL.json','SYNTHETIC_QUALIFICATION.json','synthetic_process_01/PROCESS_RECEIPT.json']:
    add(HERE/name)
add(RUNTIME/'ORIGINAL_PROFILES.json')
value={'schema':'initial-region-saved-inputs-v1','status':'PREPARED_NOT_EXECUTED','created_utc':datetime.now(timezone.utc).isoformat(),'candidate_order':order,'rows':rows,'adapted_nine_profiles':pin(RUNTIME/'ORIGINAL_PROFILES.json'),'files':list(files.values()),'region_semantics':'Saved all-state original K and V, independently certified in prior work. Residual entry flags are not substituted for quantified original initialization.','scope':'New typed initializer quantifier only; no fixed-point recomputation or new controller/native execution.','full_reset_uses':0}
with (HERE/'SAVED_INPUTS.json').open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'status':'PREPARED_NOT_EXECUTED','rows':len(rows),'files':len(files)}))
