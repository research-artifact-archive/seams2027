"""Compare saved production/independent results; no solving or graph algorithm."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json

ORDER = ['arbiter__trivial_1','lift__preferred','lift__trivial_1','minepump__preferred',
         'minepump__trivial_1','minepump__trivial_2','traffic_single__trivial_1',
         'traffic_updated__preferred','traffic_updated__trivial_1']

class Invalid(ValueError): pass

def need(value, message):
    if not value: raise Invalid(message)

def pin(path):
    p=Path(path).resolve(); data=p.read_bytes()
    return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def unique_object(pairs):
    obj={}
    for key,value in pairs:
        need(key not in obj,'Duplicate JSON key '+key);obj[key]=value
    return obj

def decode(raw):
    return json.loads(raw,object_pairs_hook=unique_object,
                      parse_constant=lambda value: (_ for _ in ()).throw(Invalid('Nonfinite JSON literal '+value)))

def read(ref):
    need(pin(ref['path'])==ref,'File pin mismatch '+ref['path'])
    return decode(Path(ref['path']).read_bytes())

def same(a,b):
    if type(a) is not type(b): return False
    if type(a) is dict: return set(a)==set(b) and all(same(a[k],b[k]) for k in a)
    if type(a) is list: return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
    return a==b

def ids(values,known=None,nonempty=False):
    need(type(values) is list and all(type(v) is str and v for v in values),'String ID array')
    need(len(values)==len(set(values)),'Duplicate IDs')
    need(not nonempty or bool(values),'Nonempty ID array')
    value=frozenset(values)
    need(known is None or value<=known,'Unknown ID')
    return value

def graph(value):
    states=ids(value['states'],nonempty=True);starts=ids(value['starts'],states,True)
    need(type(value['edges']) is list,'Edge array')
    edges=[]
    for pair in value['edges']:
        need(type(pair) is list and len(pair)==2 and all(type(v) is str and v in states for v in pair),'Typed edge pair')
        edges.append(tuple(pair))
    need(len(edges)==len(set(edges)),'Duplicate edge')
    result={'states':states,'starts':starts,'edges':frozenset(edges)}
    for owner in ['env_justice','sys_justice']:
        need(type(value[owner]) is list,'Ordered justice array')
        result[owner]=tuple(ids(label,states) for label in value[owner])
    return result

def components(values,states):
    need(type(values) is list,'SCC array')
    normalized=[ids(x,states,True) for x in values]
    need(len(normalized)==len(set(normalized)),'Duplicate SCC')
    return frozenset(normalized)

def valid_process(p):
    need(p.get('owned_child_reaped') is True and p.get('receipt_persisted') is True
         and p.get('parent_finalization_completed') is True and p.get('parent_aborted') is False,
         'Completed process finalization')
    need(p.get('process_started') is True and p.get('exact_child_wait4',{}).get('exact_child_reaped') is True
         and p.get('exact_child_wait4',{}).get('authority_lost') is False
         and p.get('final_group_observation',{}).get('state')=='ABSENT','Exact owned child completion')
    need(p['status']=='PROCESS_COMPLETED' and type(p['exit_code']) is int and p['exit_code']==0
         and not p['fatal_reasons'] and not p['resource_reasons'],'Successful bounded process')
    need(set(p['capture'])=={'stdout','stderr'} and all(v['complete'] is True for v in p['capture'].values()),'Complete streams')

def compare_row(row,expected):
    ident=row['candidate_id'];result={'candidate_id':ident,'dispatch_status':row['dispatch_status'],
        'native_outcome':row.get('native_outcome'),'status':'NOT_COMPARABLE_INCOMPLETE_EVIDENCE',
        'strict':None,'nonconflicting':None,'new_solver_or_graph_runs':0}
    if row['dispatch_status'] not in ['COMPLETE_RETURNED_GRAPH_SEPARATE_AUDITS','COMPLETE_NATIVE_REFUSAL_MODEL_CHECKED','COMPLETE_NATIVE_EMPTY_MEMORY_MODEL_CHECKED']:
        result['reason']='Dispatcher did not certify completion of both separate audits; no missing result is coerced to false.'
        return result
    refs=row['inputs'];data={key:read(ref) for key,ref in refs.items()}
    for key in ['native_process','production_process','independent_process']: valid_process(data[key])
    native,prod,ind=data['native_result'],data['production_certificate'],data['independent_audit']
    need(native['fixture_id']==native['case_id']==ident and native['variant']=='initializers','Native candidate identity')
    need(prod['schema']=='released-kind-job-certificate-v2','Production certificate schema')
    need(prod['fixture_id']==ind['candidate_id']==ind['candidate']==ident,'Audit candidate identity')
    need(prod['native_outcome']==ind['native_outcome']==native['status']==row['native_outcome'],'Native outcome agreement')
    need(prod['native_result_sha256']==refs['native_result']['sha256'],'Production native result pin')
    need(prod['original_profiles_sha256']==expected['profiles']['sha256'] and prod['checker_sha256']==expected['production']['sha256'],'Production code/profile pins')
    need(ind['worker_pin']==expected['independent'],'Independent worker pin')
    need(ind['input_manifest_pin']==refs['independent_inputs'],'Independent manifest pin')
    need(same(ind['input_bindings'],data['independent_inputs']['inputs']),'Independent exact logical-input bindings')
    need(ind['input_bindings']['native_result']==refs['native_result'],'Independent same native result')
    need(ind['input_bindings']['native_process']==refs['native_process'],'Independent same native process')
    need(ind['input_bindings']['profile']==expected['profiles'],'Independent same profile')
    need(ind['input_bindings']['source']==row['expected_source'],'Independent same source')
    need(ind['production_certificate_read'] is False and ind['production_checker_imports']==0,'Independent logical separation')
    need(type(native['helper_added']) is bool,'Observed helper Boolean')
    mapping='helper_false' if native['helper_added'] else 'identity'
    imapping='helper_false_restriction' if native['helper_added'] else 'identity'
    need(prod['original_mapping_kind']==mapping and ind['source_correspondence']['mapping']==imapping,'Mapping branch agreement')
    need(prod['initialization_correspondence']['ENV_full_native_typed_domain'] is True
         and ind['source_correspondence']['full_native_initial_ENV_correspondence'] is True,'Full initial ENV correspondence')
    if native['status'] in ['JOB_UNREALIZABLE_NO_CONTROLLER','JOB_EMPTY_MEMORY_NO_CONTROLLER']:
        need(prod['status']=='COMPLETE_NO_CONTROLLER' and ind['status']=='COMPLETE_INDEPENDENT_NO_CONTROLLER','No-controller audit outcomes')
        need(prod['derived_fairness'] is None and ind['independent_strict'] is None and ind['independent_cooperative'] is None,'No-controller fairness stays null')
        need(not {'production_graph','production_fairness','independent_view','controller'}&set(refs),'Unexpected graph evidence on no-controller')
        result.update(status='AGREE_NO_CONTROLLER',reason=ind['no_controller_reason'],fairness_claimed=False)
        return result
    need(native['status']=='JOB_CONTROLLER_PRINTED' and prod['status']=='COMPLETE_DERIVED_ORIGINAL_CERTIFICATE'
         and ind['status']=='COMPLETE_INDEPENDENT_RAW_GRAPH_AUDIT','Complete returned graph outcomes')
    pview,iview=data['production_graph'],data['independent_view']
    need(set(pview)=={'states','starts','edges','env_justice','sys_justice'},'Production graph schema')
    need(iview['schema']=='independent-source-original-view-v1' and iview['candidate']==ident and iview['mapping']==imapping,'Independent view schema/identity')
    need(prod['derived_original_graph_sha256']==refs['production_graph']['sha256'] and ind['view_pin']==refs['independent_view'],'Saved graph hash bindings')
    need(ind['input_bindings']['controller']==refs['controller'],'Independent controller pin')
    need(prod['native_graph']['sha256']==refs['controller']['sha256'],'Production controller pin')
    pg,ig=graph(pview),graph(iview);differences=[]
    for key in pg:
        if pg[key]!=ig[key]:differences.append('original_view.'+key)
    for summary,g in [(prod['original_view_mapping'],pg),(ind['original_view'],ig)]:
        for key,group in [('states','states'),('edges','edges'),('initial_states','starts')]:
            need(type(summary[key]) is int and summary[key]==len(g[group]),'Original view summary count '+key)
    native_nodes=data['controller']['nodes'];need(type(native_nodes) is list,'Native node array')
    raw={node['id']:node for node in native_nodes};need(len(raw)==len(native_nodes),'Unique native node IDs')
    retained=iview['native_nodes'];need(type(retained) is list,'Retained native node array')
    independent_nodes={node['id']:node for node in retained};need(len(independent_nodes)==len(retained),'Unique retained IDs')
    need(set(independent_nodes)==set(ig['states']),'Retained node IDs equal view')
    need(all(same(node,raw[ident]) for ident,node in independent_nodes.items()),'Raw ID/rank/AUX/valuation/memory/successors retained verbatim')
    pf,inf=data['production_fairness'],ind['fairness']
    need(same(pf,prod['derived_fairness']),'Production saved fairness/certificate equality')
    need(ids(pf['reachable'])==pg['states'] and ids(inf['reachable_states'])==ig['states'],'Reachable-state claims bind views')
    need(type(pf['state_count']) is int and pf['state_count']==len(pg['states']) and type(pf['edge_count']) is int and pf['edge_count']==len(pg['edges']),'Production counts')
    for pkey,ikey in [('strict_liveness','strict_liveness'),('nonconflicting','nonconflicting')]:
        a,b=pf[pkey]['pass'],inf[ikey]['pass'];need(type(a) is bool and type(b) is bool,'Boolean fairness result')
        if a is not b:differences.append(pkey+'.pass')
    need(ind['independent_strict'] is inf['strict_liveness']['pass'] and ind['independent_cooperative'] is inf['nonconflicting']['pass'],'Independent summary booleans')
    if components([c['states'] for c in pf['reachable_sccs']],pg['states'])!=components(inf['SCCs'],ig['states']):differences.append('reachable_SCCs')
    if components([c['states'] for c in pf['reachable_sccs'] if c['accepting']],pg['states'])!=components(inf['ENV_accepting_SCCs'],ig['states']):differences.append('ENV_accepting_SCCs')
    for a,b,label in [('failing_states','failing_states','nonconflicting.failing_states'),('can_reach_accepting_scc','can_reach_ENV_accepting_SCC','nonconflicting.can_reach_fair')]:
        if ids(pf['nonconflicting'][a],pg['states'])!=ids(inf['nonconflicting'][b],ig['states']):differences.append(label)
    def bad_sccs(values,index_key,scc_key,states,justice_count,production):
        need(type(values) is list,'Counterexample array');answer=[]
        for value in values:
            ji=value[index_key];need(type(ji) is int and 0<=ji<justice_count,'Justice index')
            members=value[scc_key]['states'] if production else value[scc_key]
            answer.append((ji,ids(members,states,True)))
        need(len(answer)==len(set(answer)),'Duplicate indexed counterexample SCC')
        return frozenset(answer)
    a=bad_sccs(pf['strict_liveness']['counterexamples'],'sys_justice_index','scc',pg['states'],len(pg['sys_justice']),True)
    b=bad_sccs(inf['strict_liveness']['counterexamples'],'SYS_justice_index','SCC',ig['states'],len(ig['sys_justice']),False)
    if a!=b:differences.append('strict_liveness.indexed_counterexample_SCCs')
    result.update(status='DISAGREEMENT' if differences else 'AGREE_RETURNED_GRAPH_SEMANTICS',differences=differences,
                  strict=pf['strict_liveness']['pass'] if not differences else None,
                  nonconflicting=pf['nonconflicting']['pass'] if not differences else None,
                  production_strict=pf['strict_liveness']['pass'],independent_strict=inf['strict_liveness']['pass'],
                  production_nonconflicting=pf['nonconflicting']['pass'],independent_nonconflicting=inf['nonconflicting']['pass'],
                  states=len(pg['states']),edges=len(pg['edges']),initial_states=len(pg['starts']),
                  native_nodes_retained_exactly=True,witness_prefix_choice_compared=False,
                  scope='Exact equality of saved graph semantics and saved fairness conclusions; no fairness recomputation.')
    return result

def main():
    parser=argparse.ArgumentParser();parser.add_argument('manifest');parser.add_argument('--manifest-sha256',required=True);parser.add_argument('--output-dir',required=True)
    args=parser.parse_args();mp=Path(args.manifest).resolve();out=Path(args.output_dir).absolute()
    need(pin(mp)['sha256']==args.manifest_sha256,'Pinned comparison manifest')
    m=decode(mp.read_bytes());need(m['schema']=='remaining-nine-semantic-comparison-inputs-v1','Manifest schema')
    need(m['candidate_order']==ORDER and [r['candidate_id'] for r in m['rows']]==ORDER,'Exact fixed remaining-nine order')
    need(not out.exists() and not out.is_symlink() and out.parent.is_dir(),'Fresh comparison output directory')
    refs=m['files'];need(type(refs) is list and len({r['path'] for r in refs})==len(refs),'Unique input files')
    index={ref['path']:ref for ref in refs}
    for row in m['rows']:
        for ref in list(row['inputs'].values())+[row['expected_source']]:
            need(index.get(ref['path'])==ref,'Complete per-row input manifest closure')
    for ref in m['expected_code_and_profiles'].values():need(index.get(ref['path'])==ref,'Complete code/profile manifest closure')
    for ref in refs:need(pin(ref['path'])==ref,'Input manifest pin')
    out.mkdir();rows=[]
    for row in m['rows']:
        try:value=compare_row(row,m['expected_code_and_profiles'])
        except Exception as error:
            value={'candidate_id':row['candidate_id'],'dispatch_status':row['dispatch_status'],'native_outcome':row.get('native_outcome'),
                   'status':'UNKNOWN_COMPARISON','error':type(error).__name__+': '+str(error),'strict':None,'nonconflicting':None,'new_solver_or_graph_runs':0}
        rows.append(value)
    for ref in refs:need(pin(ref['path'])==ref,'Input mutation during comparison')
    result={'schema':'remaining-nine-saved-semantic-comparison-v1','status':'COMPLETE_SAVED_RESULT_COMPARISON',
            'completed_utc':datetime.now(timezone.utc).isoformat(),'rows':rows,'input_manifest':pin(mp),'source_code':pin(__file__),
            'all_inputs_unchanged':True,'native_invocations':0,'BDD_evaluations':0,'graph_algorithm_runs':0,'full_reset_uses':0,
            'scope':'Saved output equality only. This does not solve a new game, certify historical regions, promote missing outputs, or establish a population claim.'}
    with (out/'RESULT.json').open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'status':result['status'],'rows':[{'candidate_id':r['candidate_id'],'status':r['status']} for r in rows]}))

if __name__=='__main__':main()
