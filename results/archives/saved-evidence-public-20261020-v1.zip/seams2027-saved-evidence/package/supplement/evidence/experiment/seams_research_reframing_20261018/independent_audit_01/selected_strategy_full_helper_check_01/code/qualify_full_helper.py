"""Small artificial full-helper fixtures only; no actual pair DAG read."""
from pathlib import Path
import copy,hashlib,importlib.util,json,sys
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('full_helper',HERE/'full_helper_worker.py');x=importlib.util.module_from_spec(spec);spec.loader.exec_module(x);w=x.w
C=sys.modules['source_contracts'].SourceContract
ROOT=Path(sys.argv[1]);ROOT.mkdir();tests=[]
raw=b'ARTIFICIAL ONLY: explicit e,p helper-transform truth fixture.\n';source=ROOT/'source.txt';source.write_bytes(raw)
c=C('artificial_full_helper',len(raw),hashlib.sha256(raw).hexdigest(),('e',),('p',),(),lambda s:s['e']=='false',lambda s:s['p']=='false',lambda s,t:t['e']=='false' or s['p']=='true',lambda s,t:t['p']!=s['p'],lambda s:([s['e']=='true'],[s['p']=='false']),'Artificial')
ORDER=[5,3,1,4,2,0];fields=[]
for name,cb,nb,invert in [('e',5,3,False),(w.HELPER,1,4,True),('p',2,0,True)]:
 fields.append({'name':name,'owner':'SYS' if name=='p' else 'ENV','role':'SYS' if name=='p' else 'ENV','domain_size':2,'values':list(w.BOOL),'current_bits':[cb],'next_bits':[nb],'encoding':{val:{'current':{str(cb):bool(i)^invert},'next':{str(nb):bool(i)^invert}} for i,val in enumerate(w.BOOL)}})
def val(bits,prime=False):
 timing='next' if prime else 'current'
 return {field['name']:next(v for v,mapping in field['encoding'].items() if all(bits[int(bit)]==b for bit,b in mapping[timing].items())) for field in fields}
def bdd(fn):
 nodes={};unique={};assignment={}
 def descend(level):
  if level==6:return int(fn(val(assignment),val(assignment,True)))
  v=ORDER[level];assignment[v]=False;low=descend(level+1);assignment[v]=True;high=descend(level+1)
  if low==high:return low
  key=(v,low,high)
  if key not in unique:unique[key]=len(nodes)+2;nodes[unique[key]]=key
  return unique[key]
 root=descend(0)
 if root in (0,1):return ('0 '+str(root)+'\n').encode()
 seen=set();stack=[root]
 while stack:
  n=stack.pop()
  if n in (0,1) or n in seen:continue
  seen.add(n);stack.extend(nodes[n][1:])
 return ('6\n'+' '.join(map(str,ORDER))+'\n'+'\n'.join(' '.join(map(str,(i,)+nodes[i])) for i in sorted(seen))+'\n').encode()
refs={}
def dag(name,fn):
 p=ROOT/(name+'.bdd');p.write_bytes(bdd(fn));r=w.pin(p);refs[p.name]=r;return {'file':p.name,'bytes':r['bytes'],'sha256':r['sha256']}
roots={key:dag(key,fn) for key,fn in {'thetaE':lambda s,t:s['e']=='false' and s[w.HELPER]=='false','thetaS':lambda s,t:s['p']=='false','rhoE':lambda s,t:(t['e']=='false' or s['p']=='true' or t[w.HELPER]=='true') and (s[w.HELPER]=='false' or t[w.HELPER]=='true'),'rhoS':lambda s,t:t['p']!=s['p'] or s[w.HELPER]=='true'}.items()}
for key in ('domain','domain_ENV_next','domain_SYS_next'):roots[key]=dag(key,lambda s,t:True)
js={'ENV':[dag('justice_e',lambda s,t:s['e']=='true'),dag('justice_helper',lambda s,t:s[w.HELPER]=='false')],'SYS':[dag('justice_sys',lambda s,t:s['p']=='false')]}
model={'schema':'k7-native-model-export-v1','fixture_id':c.candidate,'case_id':c.candidate,'variant':'initializers','input':w.pin(source),'fields':fields,'all_current_bits':[5,1,2],'all_next_bits':[3,4,0],'bdd_variable_count':6,'bdd_variable_order':ORDER,'source_inventory':{'parsed':{'ENV':{'variables':[{'name':'e'}]},'SYS':{'variables':[{'name':'p'}]}}},'original_bdds':roots,'original_justices':js}
profile={'profiles':{c.candidate:{'fixture_id':c.candidate,'case_id':c.candidate,'variant':'initializers','source':w.pin(source),'public_ENV':['e'],'public_SYS':['p'],'expected_fields_in_native_order':c.fields,'formulas':{'thetaE':['not',['var','e',False]],'thetaS':['not',['var','p',False]],'rhoE':['implies',['var','e',True],['var','p',False]],'rhoS':['not',['iff',['var','p',False],['var','p',True]]]},'justices':{'ENV':[['var','e',False]],'SYS':[['not',['var','p',False]]]}}}}
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n');return w.pin(p)
mp=save(ROOT/'model.json',model);pp=save(ROOT/'profile.json',profile)
result={'helper_added':True,'helper_is_native_nonaux_ENV':True,'model_export':{'file':Path(mp['path']).name,'bytes':mp['bytes'],'sha256':mp['sha256']},'input_sha256':c.source_sha256,'preconstructor_justices':copy.deepcopy(js),'solver_justices':copy.deepcopy(js)}
rp=save(ROOT/'result.json',result);manifest={'inputs':{'source':w.pin(source),'profile':pp,'model':mp,'native_result':rp},'bdd_files':refs}
observed=x.check(manifest,c);assert observed['typed_states']==8 and observed['typed_pairs']==64;tests.append('All 8 typed states/64 pairs with nontrivial order and inverted helper/SYS encodings')
def mutate(fn):
 mm=copy.deepcopy(manifest);mo=copy.deepcopy(model);res=copy.deepcopy(result);fn(mm,mo,res)
 i=len(list(ROOT.glob('mutation_model*')));mm['inputs']['model']=save(ROOT/('mutation_model'+str(i)+'.json'),mo);res['model_export']={'file':Path(mm['inputs']['model']['path']).name,'bytes':mm['inputs']['model']['bytes'],'sha256':mm['inputs']['model']['sha256']};mm['inputs']['native_result']=save(ROOT/('mutation_result'+str(i)+'.json'),res);return mm
def reject(name,m,part):
 try:x.check(m,c)
 except (ValueError,KeyError,TypeError) as e:assert part in str(e),(name,str(e));tests.append(name+': '+str(e));return
 raise AssertionError('Accepted mutation: '+name)
def replace_root(key,fn):
 def edit(mm,mo,r):
  ref=dag('mut_'+key+'_'+str(len(refs)),fn);mm['bdd_files'][ref['file']]=refs[ref['file']];mo['original_bdds'][key]=ref
 return mutate(edit)
reject('Missing helper initializer',replace_root('thetaE',lambda s,t:s['e']=='false'),'transformed initialization')
reject('Wrong SYS initializer guard',replace_root('thetaS',lambda s,t:s['p']=='false' or s[w.HELPER]=='true'),'transformed initialization')
reject('Missing helper monotonicity',replace_root('rhoE',lambda s,t:t['e']=='false' or s['p']=='true' or t[w.HELPER]=='true'),'ENV relation')
reject('ENV helper uses current',replace_root('rhoE',lambda s,t:(t['e']=='false' or s['p']=='true' or s[w.HELPER]=='true') and (s[w.HELPER]=='false' or t[w.HELPER]=='true')),'ENV relation')
reject('SYS helper uses next',replace_root('rhoS',lambda s,t:t['p']!=s['p'] or t[w.HELPER]=='true'),'SYS relation')
reject('SYS helper omitted',replace_root('rhoS',lambda s,t:t['p']!=s['p']),'SYS relation')
reject('ENV next-SYS support',replace_root('rhoE',lambda s,t:t['p']=='true'),'illegal variable support')
reject('Wrong helper owner',mutate(lambda mm,mo,r:mo['fields'][1].update(owner='SYS')),'owner/AUX')
reject('Original justice reordered',mutate(lambda mm,mo,r:mo['original_justices']['ENV'].reverse()),'ordered justice truth original')
reject('Solver justice reordered',mutate(lambda mm,mo,r:r['solver_justices']['ENV'].reverse()),'ordered justice truth solver')
reject('Justice count mutation',mutate(lambda mm,mo,r:r['preconstructor_justices']['SYS'].clear()),'ordered justice count preconstructor')
reject('Variable order mismatch',mutate(lambda mm,mo,r:mo['bdd_variable_order'].reverse()),'variable order')
reject('Nonbijective encoding',mutate(lambda mm,mo,r:mo['fields'][0]['encoding']['false'].update(current=mo['fields'][0]['encoding']['true']['current'])),'Bijective')
bad=copy.deepcopy(manifest);bad['bdd_files']['rhoE.bdd']['sha256']='0'*64;reject('DAG pin mismatch',bad,'pin mismatch')
wrong=copy.deepcopy(manifest);wrong['inputs']['source']['sha256']='0'*64;reject('Source pin mismatch',wrong,'pin mismatch')

for label,change in [('basename',lambda r:r['model_export'].update(file='other_model.json')),('hash',lambda r:r['model_export'].update(sha256='0'*64)),('manifest_format',lambda r:r.update(model_export=manifest['inputs']['model']))]:
 bad=copy.deepcopy(manifest);rr=copy.deepcopy(result);change(rr);bad['inputs']['native_result']=save(ROOT/('bad_export_'+label+'.json'),rr);reject('Wrong native export '+label,bad,'source/model/helper binding')

w.save_new(ROOT/'QUALIFICATION.json',{'status':'PASS','artificial_only':True,'real_pair_DAG_reads':0,'checks':tests,'named_checks':len(tests),'typed_states':8,'typed_pairs':64});print(json.dumps({'status':'PASS','checks':len(tests)}),flush=True)
