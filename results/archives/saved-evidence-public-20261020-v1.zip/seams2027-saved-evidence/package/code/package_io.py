"""Closed saved-evidence input adapter; no science imports/evaluations.

Scientific input pins retain ORIGINAL byte identities. Actual anonymous copies
are independently verified using MANIFEST before an origin-aware view is made.
Only declared package path strings are projected to this copy's absolute paths.
No model/profile/result digest is silently changed to an anonymous-copy digest.
"""
from pathlib import Path, PurePosixPath
import hashlib,json,re,unicodedata

class PackageError(ValueError):pass

def need(ok,message):
    if not ok:raise PackageError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def unique(pairs):
    out={}
    for k,v in pairs:
        need(k not in out,'Duplicate JSON key');out[k]=v
    return out
def bad_constant(value):raise PackageError('Nonfinite JSON constant '+value)
def decode(raw):return json.loads(raw,object_pairs_hook=unique,parse_constant=bad_constant)
def encoded(value):return (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def valid_pin(ref):
    need(type(ref)is dict and type(ref.get('bytes'))is int and 0<=ref['bytes']<=128*1024*1024,'Invalid byte pin')
    need(type(ref.get('sha256'))is str and re.fullmatch('[0-9a-f]{64}',ref['sha256']),'Invalid digest pin')

def shape(value):
    """Audit fingerprint of all keys, scalar types and list ordering, not paths."""
    if type(value)is dict:return ['dict',[[k,shape(v)]for k,v in value.items()]]
    if type(value)is list:return ['list',[shape(v)for v in value]]
    if type(value)is str:return ['str']
    return [type(value).__name__,value]

class Package:
    def __init__(self,root,expected_manifest,verify=True):
        self.root=Path(root).absolute();need(not self.root.is_symlink()and self.root.is_dir(),'Regular package root')
        self.root=self.root.resolve();manifest_path=self.root/'MANIFEST.json'
        need(manifest_path.is_file()and not manifest_path.is_symlink(),'Regular nonsymlink top manifest required before read')
        raw=manifest_path.read_bytes()
        need(sha(raw)==expected_manifest,'Independent manifest digest mismatch')
        self.manifest=decode(raw);need(self.manifest.get('schema')=='saved-evidence-supplement-package-v1','Package schema')
        self.index={};self.origins={};self.origin_aliases={};self.reads=[];self.projections=[]
        records=self.manifest.get('files');need(type(records)is list and 1<=len(records)<=25000,'Manifest roster cap')
        nfc=set()
        for ref in records:
            need(set(ref)=={'file','bytes','sha256'},'Exact manifest pin schema');valid_pin(ref)
            name=ref['file'];self.path(name)
            need(name not in self.index and name!='MANIFEST.json'and not name.startswith('runs/'),'Duplicate/reserved file')
            normal=unicodedata.normalize('NFC',name);need(normal not in nfc,'Unicode path collision');nfc.add(normal);self.index[name]=ref
        if verify:self.verify_files()
        origin=decode(self.raw('ORIGIN_DIGESTS.json'))
        need(origin.get('schema')=='supplement-origin-and-copy-digests-v1','Origin schema')
        for r in origin['files']:
            name=r['file'];need(name in self.index and name not in self.origins,'Origin member unique')
            valid_pin({'bytes':r['origin_bytes'],'sha256':r['origin_sha256']});valid_pin({'bytes':r['copy_bytes'],'sha256':r['copy_sha256']})
            need((r['copy_bytes'],r['copy_sha256'])==(self.index[name]['bytes'],self.index[name]['sha256']),'Current origin/copy binding')
            need(r['transformation']in ('BYTE_IDENTICAL','PATH_STRINGS_ONLY'),'Origin transformation')
            if r['transformation']=='BYTE_IDENTICAL':need((r['origin_bytes'],r['origin_sha256'])==(r['copy_bytes'],r['copy_sha256']),'False byte identity')
            if Path(name).suffix in ('.py','.bdd','.spectra','.java','.gz')or Path(name).name in ('controller.json','CONTROLLER.json','controller.txt'):
                need(r['transformation']=='BYTE_IDENTICAL','Scientific code/source/DAG/graph/printer must be exact bytes')
            self.origins[name]=r
            # Source references may point to one of several byte-identical sibling
            # copies. Alias matching never chooses between distinct contents.
            key=(r.get('origin_relative_path'),r['origin_bytes'],r['origin_sha256'])
            self.origin_aliases.setdefault(key,[]).append(name)
        self.selected={}
        for r in decode(self.raw('INPUT_INDEX.json'))['files']:
            key=unicodedata.normalize('NFC',r['origin_relative_path'])
            need(key not in self.selected and r['file']in self.origins,'Selected input identity unique')
            origin=self.origins[r['file']]
            need((r['origin_bytes'],r['origin_sha256'])==(origin['origin_bytes'],origin['origin_sha256']),'Selected original binding')
            self.selected[key]=r
        self.base_binding=decode(self.raw('BASE_BINDING.json'))
        need(self.base_binding['manifest']['file']=='base/MANIFEST.json','Base identity path')
        got=self.index['base/MANIFEST.json'];need(got==self.base_binding['manifest'],'Pinned base manifest')
        base=decode(self.raw('base/MANIFEST.json'))
        need(base['schema']=='all-cohort-offline-review-manifest-v1','Exact existing base schema')
        for r in base['files']:
            need(self.index.get('base/'+r['file'])==dict(r,file='base/'+r['file']),'Every immutable base input included')
    def selected_path(self,relative):
        key=unicodedata.normalize('NFC',relative);need(key in self.selected,'Input outside selected route inventory')
        return self.path(self.selected[key]['file'])
    def selected_view(self,relative):return self.view(self.name(self.selected_path(relative)))
    def path(self,name,file=True):
        need(type(name)is str and name and '\\'not in name and not name.startswith('/'),'Relative path required')
        p=PurePosixPath(name);need(str(p)==name and all(x not in ('','.','..')for x in name.split('/')),'Canonical nonescaping path')
        out=self.root
        for bit in p.parts:
            out/=bit;need(not out.is_symlink(),'Symlink package path')
        need(out.resolve().is_relative_to(self.root),'Escaping package path')
        need(out.is_file()if file else out.exists(),'Missing package path '+name)
        return out
    def name(self,path):
        p=Path(path);need(p.is_absolute(),'Absolute package input required')
        # Do not resolve a symlink before checking each lexical component.
        need(p.is_relative_to(self.root),'Read outside package')
        name=p.relative_to(self.root).as_posix();self.path(name)
        need(name in self.index,'Unmanifested input');return name
    def raw(self,name):
        need(name in self.index,'Unmanifested read');p=self.path(name);raw=p.read_bytes();r=self.index[name]
        need((len(raw),sha(raw))==(r['bytes'],r['sha256']),'Current copy byte/hash drift: '+name)
        self.reads.append(name);return raw
    def verify_files(self):
        actual=set()
        for p in self.root.rglob('*'):
            rel=p.relative_to(self.root).as_posix()
            need(not p.is_symlink(),'Unlisted symlink')
            if rel=='runs'or rel.startswith('runs/'):continue
            if p.is_file()and rel!='MANIFEST.json':actual.add(rel)
        need(actual==set(self.index),'Manifest must enumerate all package files')
        for name in self.index:self.raw(name)
    def resolve_reference(self,value,containing):
        need(type(value)is str and value.startswith('pkg:'),'External or unresolved reference cannot be an execution input')
        rel=value[4:]
        # The old immutable base uses pkg:evidence/... relative to its own root.
        # New supplement references explicitly start with base/ or supplement/.
        if not rel.startswith(('base/','supplement/','code/')):
            need(containing.startswith('base/'),'Unqualified pkg reference outside base');rel='base/'+rel
        self.path(rel,file=False)
        return str(self.root/rel)
    def project(self,value,containing,pointer='',changes=None):
        """Only path strings change. Original byte/hash fields remain original."""
        if type(value)is dict:
            return {k:self.project(v,containing,pointer+'/'+k.replace('~','~0').replace('/','~1'),changes)for k,v in value.items()}
        if type(value)is list:return [self.project(v,containing,pointer+'/'+str(i),changes)for i,v in enumerate(value)]
        if type(value)is str and value.startswith('pkg:'):
            out=self.resolve_reference(value,containing)
            if changes is not None:changes.append({'pointer':pointer,'copy_reference':value,'resolved_package_relative_path':Path(out).relative_to(self.root).as_posix()})
            return out
        return value
    def view(self,name):
        raw=self.raw(name);obj=decode(raw);changes=[];view=self.project(obj,name,changes=changes)
        need(shape(obj)==shape(view),'Path projection structural drift')
        if changes:self.projections.append({'file':name,'origin_sha256':self.origins.get(name,{}).get('origin_sha256'),'copy_sha256':sha(raw),'view_sha256':sha(encoded(view)),'path_fields':changes,'all_hash_scalar_fields_unchanged':True})
        return view
    def origin_pin(self,path):
        """Legacy worker pin semantics for an admitted ORIGINAL input identity.

        This is deliberately NOT a hash of anonymous bytes. Current bytes have
        just been separately verified; fresh output pins use current_pin.
        """
        name=self.name(path);self.raw(name);r=self.origins.get(name)
        need(r is not None,'Input lacks admitted original identity')
        return {'path':str(self.path(name)),'bytes':r['origin_bytes'],'sha256':r['origin_sha256']}
    def current_pin(self,path):
        name=self.name(path);raw=self.raw(name)
        return {'path':str(self.path(name)),'bytes':len(raw),'sha256':sha(raw)}
    def read_pin(self,ref):
        valid_pin(ref);need(type(ref.get('path'))is str,'Pinned path type')
        name=self.name(ref['path']);r=self.origins.get(name)
        need(r is not None,'Unadmitted original input')
        need((ref['bytes'],ref['sha256'])==(r['origin_bytes'],r['origin_sha256']),'Original identity mismatch: '+name)
        raw=self.raw(name)
        # Exact graph/printer/source/DAG bytes never pass through serialization.
        # Only JSON metadata with package-reference strings receives a view.
        if Path(name).suffix=='.json'and b'pkg:'in raw:
            need(Path(name).name not in ('controller.json','CONTROLLER.json'),'Graph projection forbidden')
            changes=[];value=self.project(decode(raw),name,changes=changes);out=encoded(value)
            self.projections.append({'file':name,'origin_bytes':r['origin_bytes'],'origin_sha256':r['origin_sha256'],'copy_sha256':sha(raw),'view_sha256':sha(out),'path_fields':changes,'all_hash_scalar_fields_unchanged':True})
            return out
        return raw
    def read_json_pin(self,ref):return decode(self.read_pin(ref))
    def report(self):
        return {'input_view_semantics':'Original historical pins remain original; current anonymous-copy bytes checked separately before path projection.',
                'files_read':sorted(set(self.reads)),'projected_metadata':self.projections,
                'original_workspace_fallback':False,'scientific_hash_fields_rewritten':False}
