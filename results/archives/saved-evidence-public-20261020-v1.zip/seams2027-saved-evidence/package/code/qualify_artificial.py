"""Artificial adapter fixtures only: no real evidence import/evaluation."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import copy,hashlib,importlib.util,json,sys,types
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent
sys.path.insert(0,str(B))
import package_io as pi
import route_adapters as ra
import review
OUT=Path(sys.argv[1]).absolute();OUT.mkdir(exist_ok=False)
TESTS=[];serial=0

def check(x,m='Artificial assertion failed'):
 if not x:raise AssertionError(m)
def bad(f):
 try:f()
 except (ValueError,RuntimeError,OSError,KeyError,TypeError):return
 raise AssertionError('Expected rejection')
def case(name,f):
 try:f();TESTS.append({'name':name,'status':'PASS'})
 except BaseException as error:TESTS.append({'name':name,'status':'FAIL','error_type':type(error).__name__,'error':str(error)})
def save(p,obj):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(pi.encoded(obj))
def ref(name,raw):return {'file':name,'bytes':len(raw),'sha256':pi.sha(raw)}

def fixture():
 global serial
 serial+=1;root=OUT/('fixture_'+str(serial));root.mkdir()
 records={};origins=[]
 def add(name,obj,copyobj=None,raw=False):
  original=obj if raw else pi.encoded(obj);current=original if copyobj is None else pi.encoded(copyobj)
  p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(current);records[name]=ref(name,current)
  origins.append({'file':name,'origin_relative_path':name,'origin_bytes':len(original),'origin_sha256':pi.sha(original),'copy_bytes':len(current),'copy_sha256':pi.sha(current),'transformation':'BYTE_IDENTICAL'if current==original else'PATH_STRINGS_ONLY'})
  return {'path':'pkg:'+name,'bytes':len(original),'sha256':pi.sha(original)}
 source=add('base/evidence/source.spectra',b'env boolean e;\nsys boolean p;\n',raw=True)
 graph=add('base/evidence/controller.json',b'{"nodes": [{"id": "0", "values": {"e": false, "p": true}}], "edges": []}\n',raw=True)
 printer=add('base/evidence/controller.txt',b'State 0 e:0 p:1\n',raw=True)
 model_original={'input':dict(source,path='/ORIGINAL/source.spectra'),'model_bits':[False,True]}
 model_copy={'input':source,'model_bits':[False,True]}
 model=add('base/evidence/model.json',model_original,model_copy)
 result=add('base/evidence/result.json',{'model_export':{'file':'model.json','bytes':model['bytes'],'sha256':model['sha256']},'controller_after_print_sha256':pi.sha((root/'base/evidence/controller.json').read_bytes()[:-1])})
 profile=add('base/evidence/profile.json',{'model_sha256':model['sha256'],'result_sha256':result['sha256'],'profiles_sha256':'f'*64,'source':dict(source,path='/ORIGINAL/source.spectra')},{'model_sha256':model['sha256'],'result_sha256':result['sha256'],'profiles_sha256':'f'*64,'source':source})
 protocol=add('base/evidence/protocol.json',{'model':dict(model,path='/ORIGINAL/model.json'),'profile':dict(profile,path='/ORIGINAL/profile.json')},{'model':model,'profile':profile})
 certificate=add('base/evidence/certificate.json',{'protocol':dict(protocol,path='/ORIGINAL/protocol.json'),'inputs':{'model':dict(model,path='/ORIGINAL/model.json')}},{'protocol':protocol,'inputs':{'model':model}})
 run=add('base/evidence/run.json',{'protocol':dict(protocol,path='/ORIGINAL/protocol.json'),'certificate':dict(certificate,path='/ORIGINAL/certificate.json')},{'protocol':protocol,'certificate':certificate})
 save(root/'base/MANIFEST.json',{'schema':'all-cohort-offline-review-manifest-v1','files':[dict(r,file=n[5:])for n,r in records.items()]})
 save(root/'ORIGIN_DIGESTS.json',{'schema':'supplement-origin-and-copy-digests-v1','files':origins})
 save(root/'INPUT_INDEX.json',{'files':[{'origin_relative_path':r['origin_relative_path'],'file':r['file'],'origin_bytes':r['origin_bytes'],'origin_sha256':r['origin_sha256']}for r in origins]})
 save(root/'BASE_BINDING.json',{'manifest':ref('base/MANIFEST.json',(root/'base/MANIFEST.json').read_bytes())})
 def seal():
  files=[ref(p.relative_to(root).as_posix(),p.read_bytes())for p in sorted(root.rglob('*'))if p.is_file()and p.name!='MANIFEST.json' or p==root/'base/MANIFEST.json']
  save(root/'MANIFEST.json',{'schema':'saved-evidence-supplement-package-v1','files':files});return pi.sha((root/'MANIFEST.json').read_bytes())
 digest=seal();p=pi.Package(root,digest)
 return root,p,digest,seal

def pin_test():
 r,p,h,_=fixture();path=r/'base/evidence/model.json';a=p.origin_pin(path);b=p.current_pin(path)
 check(a['sha256']!=b['sha256']);check(pi.decode(p.read_pin(a))['input']['path']==str(r/'base/evidence/source.spectra'))
 bad(lambda:p.read_pin(b));check(p.report()['scientific_hash_fields_rewritten']is False)
case('dual original-copy identity and wrong-copy pin rejected',pin_test)

def native_test():
 r,p,h,_=fixture();out=OUT/'native_out';out.mkdir();io=ra.RouteIO(p,out);v=p.selected_view('base/evidence/result.json');ref=v['model_export'];check(io.pinned_file(r/'base/evidence',ref)==r/'base/evidence/model.json')
 for replacement in [dict(ref,sha256='0'*64),dict(ref,file='../model.json'),dict(ref,file='/model.json'),dict(ref,file='dir/model.json')]:bad(lambda x=replacement:io.pinned_file(r/'base/evidence',x))
case('native basename pin is original identity; hash and path mutations rejected',native_test)

def naked():
 r,p,h,_=fixture();v=p.selected_view('base/evidence/profile.json');raw=pi.decode((r/'base/evidence/profile.json').read_bytes())
 for k in ('model_sha256','result_sha256','profiles_sha256'):check(v[k]==raw[k])
 check(v['model_sha256']==p.origin_pin(r/'base/evidence/model.json')['sha256']);check(v['source']['path']==str(r/'base/evidence/source.spectra'))
case('naked scientific digests retained while only source path projects',naked)

def triple():
 r,p,h,_=fixture();run=p.selected_view('base/evidence/run.json');cert=p.read_json_pin(run['certificate']);protocol=p.read_json_pin(run['protocol'])
 check(cert['protocol']==run['protocol']);check(cert['inputs']['model']==protocol['model']);check(p.origin_pin(r/'base/evidence/model.json')==protocol['model'])
 mutation=copy.deepcopy(cert);mutation['protocol']['sha256']='0'*64;bad(lambda:ra.assert_equal(mutation['protocol'],run['protocol'],'nested protocol'))
case('three-way run-certificate-protocol identities consistent; mutant rejected',triple)

def raw_graph():
 r,p,h,_=fixture()
 for name in ('controller.json','controller.txt','source.spectra'):
  q=r/'base/evidence'/name;check(p.read_pin(p.origin_pin(q))==q.read_bytes())
 result=p.selected_view('base/evidence/result.json');check(pi.sha((r/'base/evidence/controller.json').read_bytes()[:-1])==result['controller_after_print_sha256'])
 graph=r/'base/evidence/controller.json';original_ref=p.origin_pin(graph);graph.write_bytes(pi.encoded(pi.decode(graph.read_bytes())));bad(lambda:p.read_pin(original_ref))
case('raw graph/printer/source bytes; graph newline-excluding digest; graph reserialization rejected',raw_graph)

for raw,label in [(b'{"a":1,"a":2}','duplicate key'),(b'{"a":NaN}','NaN'),(b'{"a":Infinity}','Infinity'),(b'{"a":-Infinity}','negative Infinity')]:case('reject '+label,lambda raw=raw:bad(lambda:pi.decode(raw)))

for kind in ('top_manifest_symlink','runs_symlink','input_symlink','outside_path','parent_path','unknown_file','copy_corruption','manifest_wrong_hash','unlisted_file'):
 def mutate(kind=kind):
  r,p,h,seal=fixture()
  if kind in ('top_manifest_symlink','runs_symlink','input_symlink'):
   target={'top_manifest_symlink':r/'MANIFEST.json','runs_symlink':r/'runs','input_symlink':r/'base/evidence/source.spectra'}[kind]
   if kind=='runs_symlink':target.mkdir()
   # Simulate the filesystem symlink predicate without creating an entry that
   # the immutable supervisor correctly rejects in its output tree.
   original=Path.is_symlink
   Path.is_symlink=lambda q:q==target or original(q)
   try:bad(lambda:pi.Package(r,h))
   finally:Path.is_symlink=original
  elif kind=='outside_path':bad(lambda:p.origin_pin(OUT/'external'))
  elif kind=='parent_path':bad(lambda:p.raw('base/../base/evidence/source.spectra'))
  elif kind=='unknown_file':bad(lambda:p.raw('base/evidence/missing'))
  elif kind=='copy_corruption':(r/'base/evidence/source.spectra').write_bytes(b'drift');bad(lambda:p.raw('base/evidence/source.spectra'))
  elif kind=='manifest_wrong_hash':bad(lambda:pi.Package(r,'0'*64))
  else:(r/'unlisted.txt').write_text('x');bad(lambda:pi.Package(r,h))
 case('closed package '+kind,mutate)

case('bool is not int in result',lambda:bad(lambda:ra.assert_equal({'n':[False]},{'n':[0]},'typed')))
case('list order cannot change',lambda:bad(lambda:ra.assert_equal([1,2],[2,1],'ordered')))
case('unknown result key cannot be removed',lambda:bad(lambda:ra.assert_equal({'x':1},{'x':1,'y':2},'keys')))

def aliases():
 r,p,h,_=fixture();out=OUT/'alias_out';out.mkdir();io=ra.RouteIO(p,out)
 child=types.SimpleNamespace(__name__='toy_child',read_pin=lambda r:None,pin=lambda p:None)
 parent=types.SimpleNamespace(__name__='toy_parent',w=child,read_pin=child.read_pin,pin=child.pin)
 io.bind_independent(parent);io.bind_independent(child);ref=p.origin_pin(r/'base/evidence/model.json')
 check(parent.read_pin(ref)==child.read_pin(ref)==p.read_pin(ref));check(parent.pin(ref['path'])==ref)
 P=io.path_type();check(pi.decode(P(ref['path']).read_bytes())['input']['path']==str(r/'base/evidence/source.spectra'))
 with P(ref['path']).open('rb')as f:check(f.read()==p.read_pin(ref))
 bad(lambda:P(OUT/'outside').read_bytes());bad(lambda:P(r/'base/evidence/new').open('w'))
 with P(out/'new').open('wb')as f:f.write(b'fresh')
 check(io.input_or_output_pin(out/'new')['sha256']==pi.sha(b'fresh'))
 bad(lambda:P(out/'..'/'escape').open('wb'))
case('local and sibling aliases plus scoped direct Path reads/writes',aliases)

def complete():return {'schema':'contained-stage-process-v2','status':'PROCESS_COMPLETED','exit_code':0,'process_started':True,'owned_child_reaped':True,'receipt_persisted':True,'parent_finalization_completed':True,'parent_aborted':False,'exact_child_wait4':{'exact_child_reaped':True,'authority_lost':False},'final_group_observation':{'state':'ABSENT'},'fatal_reasons':[],'resource_reasons':[],'capture':{k:{'complete':True,'observed_bytes':0,'captured_bytes':0}for k in ('stdout','stderr')}}
case('synthetic valid owned process receipt accepted',lambda:check(review.valid_process(complete())))
for kind in ('bool_exit','missing_fatal','missing_resource','capture_bool','negative_capture','incomplete_capture','unknown_group','not_reaped','lost_authority','fake_capture','missing_capture'):
 def process_test(kind=kind):
  p=complete()
  if kind=='bool_exit':p['exit_code']=False
  elif kind=='missing_fatal':del p['fatal_reasons']
  elif kind=='missing_resource':del p['resource_reasons']
  elif kind=='capture_bool':p['capture']['stdout']['observed_bytes']=False
  elif kind=='negative_capture':p['capture']['stdout'].update(observed_bytes=-1,captured_bytes=-1)
  elif kind=='incomplete_capture':p['capture']['stderr']['complete']=False
  elif kind=='unknown_group':p['final_group_observation']['state']='UNKNOWN'
  elif kind=='not_reaped':p['owned_child_reaped']=False
  elif kind=='lost_authority':p['exact_child_wait4']['authority_lost']=True
  elif kind=='fake_capture':p['capture']['stdout']=False
  else:del p['capture']['stderr']
  check(review.valid_process(p)is False)
 case('fake process rejected '+kind,process_test)

GO={'schema':'portable-evidence-single-route-go-v1','status':'GO','package_manifest_sha256':'e'*64,'route':'baseline_arbiter','case':'arbiter__preferred','output_root':str(OUT/'fresh_run'),'attempts':1,'native_calls':0,'saved_route_attempts':1,'deadline_utc':(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat(),'limits':review.LIMITS}
def go_test(kind):
 go=copy.deepcopy(GO)
 if kind=='bool_attempt':go['attempts']=True
 elif kind=='native':go['native_calls']=1
 elif kind=='case':go['case']='lift__preferred'
 elif kind=='route':go['route']='other'
 elif kind=='manifest':go['package_manifest_sha256']='0'*64
 elif kind=='output':go['output_root']=str(OUT/'wrong')
 elif kind=='expired':go['deadline_utc']='2000-01-01T00:00:00+00:00'
 elif kind=='naive':go['deadline_utc']='2099-01-01T00:00:00'
 elif kind=='extra':go['auto_retry']=True
 elif kind=='limits':go['limits']['wall_seconds']=61
 elif kind=='float_limits':go['limits']['wall_seconds']=60.0
 path=OUT/('GO_'+kind+'.json');save(path,go)
 f=lambda:review.load_go(path,GO['package_manifest_sha256'],GO['route'],GO['case'],GO['output_root'])
 if kind=='valid':check(f()[0]==GO)
 else:bad(f)
for kind in ('valid','bool_attempt','native','case','route','manifest','output','expired','naive','extra','limits','float_limits'):case('GO '+kind,lambda kind=kind:go_test(kind))


def finalization_fixture(kind):
 global serial
 serial+=1;out=OUT/('finalization_'+str(serial));(out/'process').mkdir(parents=True);(out/'worker').mkdir()
 process=complete()
 if kind=='unclean_no_worker_read':process['status']='FATAL_SUPERVISOR_INTEGRITY'
 save(out/'process/PROCESS_RECEIPT.json',process)
 route='baseline_arbiter';case_id='arbiter__preferred';expected='PASS_SAVED_EVIDENCE_RECHECK';package_hash='e'*64
 if kind=='valid_expected_unknown':route='lift_followup_independent_saved';case_id='lift__preferred';expected='EXPECTED_UNKNOWN_REPRODUCED'
 worker={'schema':'portable-evidence-worker-complete-v1','status':expected,'route':route,'case':case_id,'package_manifest_sha256':package_hash,'all_package_inputs_unchanged':True,'guard':{'external_data_reads_blocked':0,'network_process_attempts_blocked':0},'native_calls':0,'new_scientific_samples':0}
 comparison={'schema':'portable-saved-evidence-route-result-v1','status':expected,'route':route,'case':case_id,'all_compared_scientific_fields_equal':True,'original_unknown_promoted':False,'new_native_calls':0,'new_scientific_samples':0,'input_view_audit':{'original_workspace_fallback':False,'scientific_hash_fields_rewritten':False}}
 if kind=='worker_route':worker['route']='wrong'
 elif kind=='worker_case':worker['case']='wrong'
 elif kind=='worker_manifest':worker['package_manifest_sha256']='0'*64
 elif kind=='worker_status':worker['status']='SUCCESS'
 elif kind=='worker_boolean_zero':worker['native_calls']=False
 elif kind=='guard_boolean_zero':worker['guard']['external_data_reads_blocked']=False
 elif kind=='comparison_route':comparison['route']='wrong'
 elif kind=='comparison_case':comparison['case']='wrong'
 elif kind=='comparison_status':comparison['status']='EXPECTED_UNKNOWN_REPRODUCED'
 elif kind=='unknown_promotion':comparison['original_unknown_promoted']=True
 elif kind=='comparison_boolean_zero':comparison['new_native_calls']=False
 elif kind=='fallback':comparison['input_view_audit']['original_workspace_fallback']=True
 save(out/'worker/WORKER_COMPLETE.json',worker);save(out/'worker/COMPARISON.json',comparison)
 if kind=='missing_worker':(out/'worker/WORKER_COMPLETE.json').unlink()
 elif kind=='missing_comparison':(out/'worker/COMPARISON.json').unlink()
 elif kind=='malformed_worker':(out/'worker/WORKER_COMPLETE.json').write_bytes(b'{oops')
 elif kind=='malformed_comparison':(out/'worker/COMPARISON.json').write_bytes(b'{oops')
 elif kind=='persisted_process_mismatch':mutant=copy.deepcopy(process);mutant['exit_code']=1;save(out/'process/PROCESS_RECEIPT.json',mutant)
 elif kind=='no_process':(out/'process/PROCESS_RECEIPT.json').unlink();process=None
 worker_reads=[];original_read=Path.read_bytes;original_link=Path.is_symlink
 def tracked_read(q):
  if q.is_relative_to(out/'worker'):worker_reads.append(str(q))
  return original_read(q)
 targets={'completion_symlink':out/'worker/WORKER_COMPLETE.json','completion_parent_symlink':out/'worker','comparison_symlink':out/'worker/COMPARISON.json','process_parent_symlink':out/'process'}
 Path.read_bytes=tracked_read
 if kind in targets:Path.is_symlink=lambda q:q==targets[kind]or original_link(q)
 try:result=review.final_record(out,package_hash,route,case_id,{'fixture':'GO'},process,kind!='input_drift',{'type':'SyntheticLaunchError','message':'fixture'}if kind=='launch_error'else None)
 finally:Path.read_bytes=original_read;Path.is_symlink=original_link
 if kind in ('unclean_no_worker_read','persisted_process_mismatch','no_process','input_drift','launch_error','process_parent_symlink'):check(worker_reads==[],'Untrusted worker tree was read')
 save(out/'RUN_RECEIPT.json',result)
 check(result['original_unknown_promoted']is False)
 if kind in ('valid','valid_expected_unknown'):check(result['status']==expected and result['finalization_errors']==[])
 else:check(result['status']=='UNKNOWN_PORTABLE_VERIFICATION'and result['finalization_errors'])
for kind in ('valid','valid_expected_unknown','missing_worker','missing_comparison','malformed_worker','malformed_comparison','worker_route','worker_case','worker_manifest','worker_status','worker_boolean_zero','guard_boolean_zero','comparison_route','comparison_case','comparison_status','unknown_promotion','comparison_boolean_zero','fallback','persisted_process_mismatch','no_process','input_drift','launch_error','unclean_no_worker_read','completion_symlink','completion_parent_symlink','comparison_symlink','process_parent_symlink'):
 case('finalization preserves status '+kind,lambda kind=kind:finalization_fixture(kind))


def baseline_fixture_alias(kind):
 global serial
 serial+=1;root=OUT/('baseline_alias_'+str(serial));root.mkdir();out=root/'output';out.mkdir();inputs=root/'inputs';inputs.mkdir();profiles_path=root/'profiles.json'
 public='traffic_single__preferred';legacy='traffic_single';calls=[]
 profiles={'profiles':{legacy:{'fixture_id':legacy,'case_id':legacy,'variant':'initializers'}}};native={'fixture_id':legacy,'case_id':legacy}
 expected={'schema':'TOY_CERTIFICATE_ONLY','fixture_id':legacy,'status':'COMPLETE_TOY','unchanged_value':True}
 if kind=='wrong_profile_key':profiles['profiles']['wrong']=profiles['profiles'].pop(legacy)
 if kind=='wrong_native_identity':native['fixture_id']='wrong'
 save(profiles_path,profiles);save(inputs/'model.json',{'toy':True})
 def toy_check(directory,fixture,profiles_file,expected_sha,output):
  calls.append(fixture)
  partial={'fixture_id':fixture,'status':'UNKNOWN_ORIGINAL_MAPPING'}
  try:
   profile=profiles['profiles'][fixture]
   if profile['fixture_id']!=fixture or profile['case_id']!=fixture:raise ValueError('Toy profile identity')
   if native['fixture_id']!=fixture or native['case_id']!=fixture:raise ValueError('Toy native identity')
   return {'schema':'TOY_CERTIFICATE_ONLY','fixture_id':fixture,'status':'COMPLETE_TOY','unchanged_value':True}
  except (KeyError,ValueError)as error:partial['mapping_error']=str(error);return partial
 if kind=='old_unmapped_lookup':
  result=toy_check(inputs,public,profiles_path,'0'*64,out)
  check(result['status']=='UNKNOWN_ORIGINAL_MAPPING'and public in result['mapping_error']and calls==[public]);return
 if kind=='wrong_expected_identity':expected['fixture_id']=public
 class ToyPackage:
  def selected_path(self,relative):return inputs/'model.json'if relative.endswith('inputs/traffic_single/model.json')else profiles_path
  def origin_pin(self,path):raw=Path(path).read_bytes();return {'path':str(path),'bytes':len(raw),'sha256':pi.sha(raw)}
  def selected_view(self,relative):return copy.deepcopy(expected)
  def report(self):return {'original_workspace_fallback':False,'scientific_hash_fields_rewritten':False,'toy_only':True}
 case_id='traffic_single__trivial_1'if kind=='unmapped_public_case'else public
 prepared={'route':'baseline_traffic','case':case_id,'module':types.SimpleNamespace(check=toy_check),'package':ToyPackage(),'output':out,'io':types.SimpleNamespace(bindings=[])}
 if kind=='valid':
  result=ra.execute(prepared);check(calls==[legacy]and result['case']==public and result['status']=='PASS_SAVED_EVIDENCE_RECHECK')
  check(pi.decode((out/'RESULT.json').read_bytes())['fixture_id']==legacy)
 else:
  bad(lambda:ra.execute(prepared));check(not(out/'COMPARISON.json').exists())
  if kind=='unmapped_public_case':check(calls==[])
for kind in ('old_unmapped_lookup','valid','unmapped_public_case','wrong_profile_key','wrong_native_identity','wrong_expected_identity'):
 case('public-to-historical fixture artificial '+kind,lambda kind=kind:baseline_fixture_alias(kind))

# The permanent audit hook is installed last. All following I/O stays inside the
# assigned child output except deliberately rejected generated sibling fixtures.
# Symlink targets are simulated with Path.resolve; no physical symlink is placed
# in the supervisor's monitored tree.
source_files=[{'file':n,**{k:v for k,v in ref(n,(B/n).read_bytes()).items()if k!='file'}}for n in ('package_io.py','route_adapters.py','review.py','runtime_guard.py','qualify_artificial.py')]
import runtime_guard
guard_root=OUT/'guard_package';guard_root.mkdir();(guard_root/'input.txt').write_bytes(b'package toy input')
external=OUT.parent/'guard_external.txt';external.write_bytes(b'outside assigned output')
sibling=OUT.parent/'guard_sibling';sibling.mkdir();(sibling/'input.txt').write_bytes(b'sibling worker output')
guard=runtime_guard.install(guard_root,OUT)
def denied(f):
 try:f()
 except PermissionError:return
 raise AssertionError('Expected audit-hook PermissionError')
case('actual guard package read remains allowed',lambda:check((guard_root/'input.txt').read_bytes()==b'package toy input'))
def own_output_readback():
 p=OUT/'guard_own.txt';data=b'actual guarded output bytes\n'
 with p.open('xb')as f:f.write(data)
 check(p.read_bytes()==data and p.read_text(encoding='utf-8')==data.decode('utf-8'))
 check(review.pin(p)=={'path':str(p),'bytes':len(data),'sha256':pi.sha(data)})
case('actual guard assigned output write read bytes text pin',own_output_readback)
def nested_output_readback():
 p=OUT/'guard_nested'/'deep'/'value.txt';p.parent.mkdir(parents=True);p.write_bytes(b'nested');check(p.read_bytes()==b'nested')
case('actual guard nested assigned output write read',nested_output_readback)
case('actual guard external read rejected',lambda:denied(lambda:external.read_bytes()))
case('actual guard sibling output read rejected',lambda:denied(lambda:(sibling/'input.txt').read_bytes()))
case('actual guard parent escape read rejected',lambda:denied(lambda:(OUT/'..'/'guard_external.txt').read_bytes()))
case('actual guard noncanonical internal traversal rejected',lambda:denied(lambda:(OUT/'guard_nested'/'..'/'guard_own.txt').read_bytes()))
def mocked_symlink_resolution(target):
 alias=OUT/'guard_alias.txt';original=Path.resolve
 def resolve(q,*args,**kwargs):return target if q.absolute()==alias else original(q,*args,**kwargs)
 Path.resolve=resolve
 try:denied(lambda:alias.read_bytes())
 finally:Path.resolve=original
case('actual guard mocked symlink target outside rejected',lambda:mocked_symlink_resolution(external))
case('actual guard mocked symlink alias inside output rejected',lambda:mocked_symlink_resolution(OUT/'guard_own.txt'))
case('actual guard external write rejected',lambda:denied(lambda:(sibling/'forbidden.txt').write_bytes(b'forbidden')))
case('actual guard exact deliberate read rejection count',lambda:check(guard['external_data_reads_blocked']==6,'Exact deliberate read rejection count'))

report={'schema':'supplement-artificial-adapter-qualification-v1','status':'PASS'if all(t['status']=='PASS'for t in TESTS)else'FAIL','tests':TESTS,'count':len(TESTS),'legacy_fixture_test_scope':'Generated toy checker and metadata only; no real baseline checker, saved DAG, or graph calculation.','symlink_cases_use_mocked_filesystem_predicate':True,'real_scientific_modules_imported':0,'real_saved_DAG_evaluations':0,'real_graph_algorithms':0,'new_native_runs':0,'new_scientific_samples':0,'runtime_guard_test_scope':'Actual installed audit hook with generated byte/text/pin readbacks and real external/sibling/traversal rejections; symlink targets use mocked Path.resolve only. No physical symlinks.','runtime_guard_evidence':guard,'source_files':source_files}
save(OUT/'RESULT.json',report);print(json.dumps({'status':report['status'],'count':len(TESTS),'failures':[t for t in TESTS if t['status']!='PASS']}));sys.exit(0 if report['status']=='PASS'else 2)
