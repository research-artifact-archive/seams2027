"""Verify saved evidence. No native synthesis, automatic retries or downloads.

Real saved-data evaluation requires one new exact route/case GO. Metadata and
import-only preparation cannot authorize a scientific replay.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,importlib.util,json,sys,time
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from package_io import Package,need,decode,encoded,sha
import route_adapters as routes

LIMITS={'wall_seconds':60,'rss_bytes':512*1024*1024,'stream_bytes':8*1024*1024,'file_bytes':16*1024*1024,'output_tree_bytes':64*1024*1024,'min_free_bytes':1024*1024*1024}

def pin(p):
 p=Path(p).absolute();need(p.is_file()and not p.is_symlink(),'Regular pin file');raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':sha(raw)}
def save(p,obj):
 p=Path(p);raw=encoded(obj);need(len(raw)<=16*1024*1024,'Receipt file cap')
 with p.open('xb')as f:f.write(raw)
def load_go(path,package_hash,route,case,output):
 need(route in routes.CASES and case in routes.CASES[route],'Admitted exact route/case')
 ref=pin(path);obj=decode(Path(path).read_bytes())
 fields={'schema','status','package_manifest_sha256','route','case','output_root','attempts','native_calls','saved_route_attempts','deadline_utc','limits'}
 need(set(obj)==fields,'Exact new GO schema fields')
 need(obj['schema']=='portable-evidence-single-route-go-v1'and obj['status']=='GO','New single-route GO required')
 need(obj['package_manifest_sha256']==package_hash and obj['route']==route and obj['case']==case,'GO binds manifest/route/case')
 need(obj['output_root']==str(Path(output).absolute()),'GO binds exact fresh output')
 need(type(obj['attempts'])is int and obj['attempts']==1 and type(obj['saved_route_attempts'])is int and obj['saved_route_attempts']==1,'One exact saved-data attempt')
 need(type(obj['native_calls'])is int and obj['native_calls']==0,'No native call authorized')
 need(obj['limits']==LIMITS and all(type(obj['limits'][k])is type(v)for k,v in LIMITS.items()),'Exact bounded limits')
 deadline=datetime.fromisoformat(obj['deadline_utc']);need(deadline.tzinfo is not None,'Timezone-aware GO deadline')
 need((deadline-datetime.now(timezone.utc)).total_seconds()>1,'GO deadline expired')
 return obj,ref

def valid_process(p):
 if type(p)is not dict:return False
 if any(type(p.get(k))is not dict for k in ('exact_child_wait4','final_group_observation','capture')):return False
 if any(type(v)is not dict for v in p['capture'].values()):return False
 return (p.get('schema')=='contained-stage-process-v2'and p.get('status')=='PROCESS_COMPLETED'and type(p.get('exit_code'))is int and p.get('exit_code')==0
  and p.get('process_started')is True and p.get('owned_child_reaped')is True and p.get('receipt_persisted')is True
  and p.get('parent_finalization_completed')is True and p.get('parent_aborted')is False
  and p.get('exact_child_wait4',{}).get('exact_child_reaped')is True and p.get('exact_child_wait4',{}).get('authority_lost')is False
  and p.get('final_group_observation',{}).get('state')=='ABSENT'and type(p.get('fatal_reasons'))is list and p['fatal_reasons']==[] and type(p.get('resource_reasons'))is list and p['resource_reasons']==[]
  and set(p.get('capture',{}))=={'stdout','stderr'}and all(r.get('complete')is True and type(r.get('observed_bytes'))is int and type(r.get('captured_bytes'))is int and r['observed_bytes']>=0 and r['captured_bytes']>=0 and r['observed_bytes']==r['captured_bytes']for r in p['capture'].values()))

def scientific_call_guard(package):
 counts={'blocked_scientific_calls':0};before=sys.getprofile()
 forbidden={'audit','audit_graph','verify_source','finite_fairness','build_graph','states_for','check_policy','initial_case','check','viability','solve','compute','execute'}
 def profile(frame,event,arg):
  if event!='call':return
  try:p=Path(frame.f_code.co_filename).absolute()
  except Exception:return
  if not p.is_relative_to(package.root):return
  is_science='/evidence/'in str(p)
  class_name=type(frame.f_locals.get('self')).__name__
  if is_science and(frame.f_code.co_name in forbidden or(frame.f_code.co_name=='__init__'and class_name in ('BDD','SavedDag','Context','ModelAudit'))):
   counts['blocked_scientific_calls']+=1;raise RuntimeError('Import-only science-constructor/function trap: '+frame.f_code.co_name)
 sys.setprofile(profile)
 return counts,before

def worker(args):
 root=Path(args.package).absolute();package=Package(root,args.expected_manifest)
 output=Path(args.output).absolute();need(not output.exists()and not output.is_symlink()and output.parent.is_dir()and output.resolve()==output,'Fresh canonical worker output')
 if args.action=='worker':
  parent=output.parent;go,go_pin=load_go(args.go,args.expected_manifest,args.route,args.case,parent)
  pin(parent/'START.json');start=decode((parent/'START.json').read_bytes());need(start['GO']==go_pin and start['route']==args.route and start['case']==args.case and start['package_manifest_sha256']==args.expected_manifest,'Exact parent START/GO binding')
 output.mkdir(exist_ok=False)
 import runtime_guard
 guard=runtime_guard.install(root,output)
 try:
  if args.action=='imports':
   old_root_probe=None
   probe=output/'assigned_output_probe.txt';payload=b'portable assigned-output readback probe v1\n'
   with probe.open('xb')as f:f.write(payload)
   need(probe.read_bytes()==payload and probe.read_text(encoding='utf-8')==payload.decode('utf-8'),'Assigned output bytes/text readback')
   output_probe=pin(probe);need(output_probe['sha256']==sha(payload)and output_probe['bytes']==len(payload),'Assigned output digest readback')
   if args.reject_read_root:
    previous_root=Path(args.reject_read_root).resolve();need(previous_root!=root.resolve()and not previous_root.is_relative_to(root.resolve()),'Probe must target a different old package root')
    try:(previous_root/'MANIFEST.json').read_bytes()
    except PermissionError:old_root_probe='REJECTED_BEFORE_READ'
    else:raise RuntimeError('Old-root read probe was not rejected')
   counts,previous=scientific_call_guard(package)
   try:prepared=routes.prepare(args.route,args.case,package,output)
   finally:sys.setprofile(previous)
   need(counts['blocked_scientific_calls']==0,'No science invoked during import')
   need(guard['external_data_reads_blocked']==(1 if old_root_probe else 0)and guard['network_process_attempts_blocked']==0,'Only the deliberate old-root probe may be blocked')
   result={'status':'PASS_IMPORT_ONLY','route':args.route,'case':args.case,'science_calls':0,'entry':prepared['entry'],'IO_bindings':prepared['io'].bindings,'guard':guard,'assigned_output_read_probe':{'status':'PASS_ACTUAL_GUARDED_WRITE_READ_BYTES_TEXT_PIN','file':probe.name,'bytes':output_probe['bytes'],'sha256':output_probe['sha256']},'old_root_read_probe':old_root_probe,'native_calls':0}
   save(output/'IMPORT_RESULT.json',result)
  else:
   prepared=routes.prepare(args.route,args.case,package,output);result=routes.execute(prepared);package.verify_files()
   save(output/'WORKER_COMPLETE.json',{'schema':'portable-evidence-worker-complete-v1','status':result['status'],'route':args.route,'case':args.case,'package_manifest_sha256':args.expected_manifest,'all_package_inputs_unchanged':True,'guard':guard,'native_calls':0,'new_scientific_samples':0})
  print(json.dumps({'status':result['status'],'route':args.route,'case':args.case}));return 0
 except BaseException as error:
  result={'status':'UNKNOWN_PORTABLE_VERIFICATION','error_type':type(error).__name__,'error':str(error),'route':args.route,'case':args.case,'guard':guard,'original_scientific_status_not_changed':True,'native_calls':0,'new_scientific_samples':0}
  save(output/'UNKNOWN.json',result);print(json.dumps(result));return 2

def read_output_artifact(path,output):
 """Validate every output path component before reading and pinning bytes."""
 root=Path(output).absolute();p=Path(path).absolute()
 need('..'not in root.parts and '..'not in p.parts and p.is_relative_to(root),'Canonical contained output artifact')
 current=Path(root.anchor)
 for bit in root.parts[1:]:
  current/=bit;need(not current.is_symlink(),'Symlink in output root')
 need(root.resolve()==root and root.is_dir(),'Canonical regular output root')
 current=root
 for bit in p.relative_to(root).parts:
  current/=bit;need(not current.is_symlink(),'Symlink in output artifact path')
 need(p.resolve()==p and p.is_file()and p.stat().st_size<=16*1024*1024,'Regular bounded output artifact')
 raw=p.read_bytes();need(len(raw)<=16*1024*1024,'Output artifact byte cap')
 ref={'path':str(p),'bytes':len(raw),'sha256':sha(raw)}
 return decode(raw),ref

def final_record(output,package_hash,route,case,go_pin,process,unchanged,launch_error=None):
 """Turn every missing/malformed/misbound result into a preserved UNKNOWN."""
 output=Path(output);errors=[];process_pin=None;comparison_pin=None;observed_status=None
 clean=False
 if launch_error is not None:errors.append({'phase':'launch_or_owned_finalization','detail':launch_error})
 try:
  persisted,process_pin=read_output_artifact(output/'process/PROCESS_RECEIPT.json',output)
  routes.assert_equal(persisted,process,'persisted owned process receipt')
  need(valid_process(process),'Owned process did not complete cleanly')
  clean=True
 except BaseException as error:errors.append({'phase':'owned_receipt','type':type(error).__name__,'message':str(error)[:2000]})
 if unchanged is not True:errors.append({'phase':'input_identity','message':'Package inputs changed or could not be verified'})
 # Never traverse a failed or untrusted worker output tree.
 if not errors:
  try:
   worker,worker_pin=read_output_artifact(output/'worker/WORKER_COMPLETE.json',output)
   comparison,comparison_pin=read_output_artifact(output/'worker/COMPARISON.json',output)
   expected='EXPECTED_UNKNOWN_REPRODUCED'if route=='lift_followup_independent_saved'and case=='lift__preferred'else'PASS_SAVED_EVIDENCE_RECHECK'
   need(worker.get('schema')=='portable-evidence-worker-complete-v1','Exact worker completion schema')
   need(worker.get('route')==route and worker.get('case')==case and worker.get('package_manifest_sha256')==package_hash,'Worker manifest/route/case binding')
   need(worker.get('status')==expected and worker.get('all_package_inputs_unchanged')is True,'Worker status and unchanged inputs')
   need(all(type(worker.get(k))is int and worker[k]==0 for k in ('native_calls','new_scientific_samples')),'Worker zero counts are exact integers')
   guard=worker.get('guard');need(type(guard)is dict and all(type(guard.get(k))is int and guard[k]==0 for k in ('external_data_reads_blocked','network_process_attempts_blocked')),'No unexpected worker I/O boundary violation')
   need(comparison.get('schema')=='portable-saved-evidence-route-result-v1','Exact comparison schema')
   need(comparison.get('route')==route and comparison.get('case')==case and comparison.get('status')==expected,'Comparison route/case/status binding')
   need(comparison.get('all_compared_scientific_fields_equal')is True and comparison.get('original_unknown_promoted')is False,'Exact evidence agreement without UNKNOWN promotion')
   need(all(type(comparison.get(k))is int and comparison[k]==0 for k in ('new_native_calls','new_scientific_samples')),'Comparison zero counts are exact integers')
   view=comparison.get('input_view_audit');need(type(view)is dict and view.get('original_workspace_fallback')is False and view.get('scientific_hash_fields_rewritten')is False,'Closed origin-aware input view')
   observed_status=comparison['status']
  except BaseException as error:errors.append({'phase':'worker_result','type':type(error).__name__,'message':str(error)[:2000]})
 complete=not errors
 return {'schema':'portable-evidence-bounded-run-receipt-v1','status':observed_status if complete else'UNKNOWN_PORTABLE_VERIFICATION','route':route,'case':case,'GO':go_pin,'package_manifest_sha256':package_hash,'all_package_inputs_unchanged':unchanged,'owned_process_clean':clean,'process':process_pin,'comparison':comparison_pin if complete else None,'finalization_errors':errors,'native_calls':0,'new_scientific_samples':0,'original_unknown_promoted':False,'scope':'Existing-evidence verification, not full reproduction of native synthesis.'}

def run(args):
 root=Path(args.package).absolute();package=Package(root,args.expected_manifest)
 output=Path(args.output).absolute();need(not output.exists()and not output.is_symlink()and output.parent.is_dir()and output.resolve()==output,'Fresh canonical parent output')
 go,go_pin=load_go(args.go,args.expected_manifest,args.route,args.case,output)
 need((datetime.fromisoformat(go['deadline_utc'])-datetime.now(timezone.utc)).total_seconds()>=80,'At least60s work +20s cleanup remaining')
 output.mkdir(exist_ok=False)
 save(output/'START.json',{'schema':'portable-evidence-one-attempt-start-v1','created_utc':datetime.now(timezone.utc).isoformat(),'route':args.route,'case':args.case,'GO':go_pin,'package_manifest_sha256':args.expected_manifest,'native_calls':0})
 process=None;launch_error=None
 try:
  sys.path.insert(0,str(HERE/'supervisor'))
  spec=importlib.util.spec_from_file_location('portable_bounded_process',HERE/'supervisor/bounded_process.py');stage=importlib.util.module_from_spec(spec);spec.loader.exec_module(stage)
  command=[sys.executable,'-I','-S','-B',str(Path(__file__).resolve()),'worker','--package',str(root),'--expected-manifest',args.expected_manifest,'--route',args.route,'--case',args.case,'--output',str(output/'worker'),'--go',str(Path(args.go).absolute())]
  process=stage.run_bounded(command,output/'process',go['deadline_utc'],wall_seconds=LIMITS['wall_seconds'],rss_bytes=LIMITS['rss_bytes'],stream_bytes=LIMITS['stream_bytes'],file_bytes=LIMITS['file_bytes'],output_tree=output,output_tree_bytes=LIMITS['output_tree_bytes'],min_free_bytes=LIMITS['min_free_bytes'])
 except BaseException as error:
  launch_error={'type':type(error).__name__,'message':str(error)[:2000]}

 unchanged=True
 try:package.verify_files()
 except Exception:unchanged=False
 record=final_record(output,args.expected_manifest,args.route,args.case,go_pin,process,unchanged,launch_error)
 complete=record['status']in('PASS_SAVED_EVIDENCE_RECHECK','EXPECTED_UNKNOWN_REPRODUCED')
 save(output/'RUN_RECEIPT.json',record);print(json.dumps(record));return 0 if complete else 2

def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('action',choices=('metadata','imports','run','worker'));a.add_argument('--package',required=True);a.add_argument('--expected-manifest',required=True);a.add_argument('--route');a.add_argument('--case');a.add_argument('--output');a.add_argument('--go');a.add_argument('--reject-read-root');args=a.parse_args()
 need(not args.reject_read_root or args.action=='imports','Old-root probe is import qualification only')
 if args.action=='metadata':
  p=Package(args.package,args.expected_manifest);print(json.dumps({'status':'PASS_COPY_METADATA','files':len(p.index),'origin_entries':len(p.origins),'selected_entries':len(p.selected),'new_native_calls':0,'scientific_evaluations':0,'scope':'File closure and separate original/copy identity metadata only.'}));return 0
 need(args.route and args.case and args.output,'Explicit route,case,fresh output required')
 if args.action in ('run','worker'):need(args.go,'A new exact GO is required')
 return run(args)if args.action=='run'else worker(args)
if __name__=='__main__':sys.exit(main())
