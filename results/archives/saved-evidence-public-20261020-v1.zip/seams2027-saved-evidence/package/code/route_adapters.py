"""Explicit saved-evidence routes around unchanged scientific source files.

prepare imports definitions only. execute is never called by preparation or
import qualification, and requires the separately gated driver for real data.
All metadata I/O is origin-aware; graph/printer/source/DAG payloads stay raw.
"""
from pathlib import Path, PurePosixPath
from datetime import datetime,timezone
import hashlib,importlib.util,io,json,sys,time
from package_io import need,decode,encoded,sha

E='experiment/seams_research_reframing_20261018/'
COMPAT=E+'common_checker_01/compatibility_preparation_01/'
ARB='output/artifacts/seams2027-20261017-arbiter-audit-candidate-v1/'
NINE=['arbiter__trivial_1','lift__preferred','lift__trivial_1','minepump__preferred','minepump__trivial_1','minepump__trivial_2','traffic_single__trivial_1','traffic_updated__preferred','traffic_updated__trivial_1']
PAIR=['cooperative_choice_gate','cooperative_forced_toggle']
ELEVEN=['arbiter__preferred','traffic_single__preferred']+NINE
ENTRY={
 'original_initial_K_V':E+'initial_region_check_01/saved_worker.py',
 'baseline_arbiter':ARB+'code/audit_worker.py',
 'baseline_traffic':COMPAT+'code/certify.py',
 'remaining_nine_independent_saved':E+'frozen_execution_01/code/independent/audit_worker.py',
 'lift_followup_independent_saved':E+'frozen_execution_01/code/independent/audit_worker.py',
 'choice_toggle_independent_saved':E+'independent_audit_01/selected_strategy_independent_01/code/audit_worker.py',
 'production_independent_saved_view_agreement':None,
 'lift_saved_prefix':E+'common_checker_01/lift_followup_comparison_01/extract_prefix.py',
 'lift_source_positive_saved_graph':E+'lift_positive_policy_01/code/witness.py',
 'pair_full_native_helper_saved':E+'independent_audit_01/selected_strategy_full_helper_check_01/code/full_helper_worker.py',
 'lift_preferred_timing_saved':E+'independent_audit_01/lift_preferred_mapping_review_02/code/witness_worker.py',
 'lift_full_native_policy_extension_saved':E+'independent_audit_01/lift_full_helper_extension_01/code/extension_worker.py'}
CASES={'original_initial_K_V':ELEVEN,'baseline_arbiter':['arbiter__preferred'],'baseline_traffic':['traffic_single__preferred'],
 'remaining_nine_independent_saved':[x for x in NINE if not x.startswith('lift__')],
 'lift_followup_independent_saved':['lift__trivial_1','lift__preferred'],'choice_toggle_independent_saved':PAIR,
 'production_independent_saved_view_agreement':['nine_first_attempts','lift_followups','constructed_pair'],
 'lift_saved_prefix':['lift__trivial_1'],'lift_source_positive_saved_graph':['lift__trivial_1'],
 'pair_full_native_helper_saved':['constructed_pair'],'lift_preferred_timing_saved':['lift__preferred'],
 'lift_full_native_policy_extension_saved':['lift__trivial_1']}
# Public cohort labels and preserved historical fixture identities are distinct.
LEGACY_FIXTURES={('baseline_traffic','traffic_single__preferred'):'traffic_single'}
def legacy_fixture_for(route,case):
 need((route,case)in LEGACY_FIXTURES,'Explicit public-case to legacy-fixture binding required')
 return LEGACY_FIXTURES[(route,case)]

COMPARISONS={'nine_first_attempts':'cohort_comparison_01','lift_followups':'lift_followup_comparison_01','constructed_pair':'selected_strategy_comparison_01'}
# These are metadata added by original CLI mains, not fields produced by the
# unchanged science functions. All remaining result fields compare exactly.
MAIN_METADATA={'started_utc','finished_utc','input_manifest_pin','worker_pin','source_contracts_pin','independent_core_pin','view_pin','protocol_pin','code_pins'}

class RouteIO:
 def __init__(self,package,output):
  self.p=package;self.output=Path(output).absolute();self.bindings=[]
  need('..'not in self.output.parts and self.output.resolve()==self.output and not self.output.is_symlink(),'Canonical nonsymlink fresh output root')
 def output_path(self,path):
  p=Path(path).absolute();need('..'not in p.parts and p.is_relative_to(self.output)and p.resolve()==p,'Escaping fresh output path')
  current=p
  while current!=self.output.parent:
   need(not current.is_symlink(),'Symlink in fresh output path');current=current.parent
  return p
 def input_or_output_pin(self,path):
  p=Path(path).absolute()
  if p.is_relative_to(self.output):
   p=self.output_path(p);need(p.is_file(),'Regular fresh output pin required');raw=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(raw),'sha256':sha(raw)}
  need(p.is_relative_to(self.p.root),'Pin outside admitted input/fresh output');return self.p.origin_pin(p)
 def read_json(self,path):return self.p.read_json_pin(self.p.origin_pin(path))
 def file_bytes(self,path,limit=64*1024*1024):
  ref=self.p.origin_pin(path);need(ref['bytes']<=limit,'Original input byte cap');raw=self.p.read_pin(ref);need(len(raw)<=limit,'Projected metadata byte cap');return raw
 def pinned_file(self,base,ref,basename=True):
  need(type(ref)is dict and type(ref.get('file'))is str,'Native basename pin required')
  name=ref['file'];q=PurePosixPath(name)
  need(name==str(q)and not q.is_absolute()and '\\'not in name and all(x not in ('','.','..')for x in name.split('/'))and(not basename or len(q.parts)==1),'Canonical native file pin')
  p=Path(base)/name;actual=self.p.origin_pin(p)
  need((actual['bytes'],actual['sha256'])==(ref['bytes'],ref['sha256']),'Native ORIGINAL basename pin mismatch')
  return p
 def path_type(self):
  context=self
  class BoundPath(type(Path())):
   def read_bytes(self):
    p=Path(str(self)).absolute()
    if p.is_relative_to(context.output):return context.output_path(p).read_bytes()
    need(p.is_relative_to(context.p.root),'Direct Path read outside package/fresh output');return context.file_bytes(p,128*1024*1024)
   def read_text(self,encoding=None,errors=None):return self.read_bytes().decode(encoding or'utf-8',errors or'strict')
   def open(self,mode='r',buffering=-1,encoding=None,errors=None,newline=None):
    p=Path(str(self)).absolute();writing=any(x in mode for x in 'wax+')
    if writing:
     return context.output_path(p).open(mode,buffering,encoding,errors,newline)
    if p.is_relative_to(context.output):return context.output_path(p).open(mode,buffering,encoding,errors,newline)
    need(p.is_relative_to(context.p.root),'Direct Path open outside package/fresh output')
    data=self.read_bytes();return io.BytesIO(data)if'b'in mode else io.StringIO(data.decode(encoding or'utf-8',errors or'strict'))
  return BoundPath
 def bind_independent(self,m):
  for name,value in [('read_pin',self.p.read_pin),('pin',self.input_or_output_pin)]:
   if hasattr(m,name):setattr(m,name,value);self.bindings.append({'module':m.__name__,'attribute':name,'API':'origin-aware input identity / actual fresh output identity'})
 def bind_main_io(self,m):
  self.bind_independent(m);m.Path=self.path_type()
  if hasattr(m,'read'):m.read=self.p.read_json_pin
  self.bindings.append({'module':m.__name__,'attribute':'Path','API':'scoped direct-read projection; writes only fresh output'})
 def bind_production(self,m):
  for target in (m,sys.modules['admission_checker']):
   target.read_json=self.read_json;target.pinned_file=self.pinned_file
   target.sha=lambda path:self.input_or_output_pin(path)['sha256']
   if hasattr(target,'file_bytes'):target.file_bytes=self.file_bytes
   self.bindings.append({'module':target.__name__,'attributes':['read_json','pinned_file','sha','file_bytes'],'API':'explicit production metadata and native basename original-pin APIs'})

def module(package,relative,name):
 p=package.selected_path(relative);package.origin_pin(p)
 spec=importlib.util.spec_from_file_location(name,p);obj=importlib.util.module_from_spec(spec);sys.modules[name]=obj;spec.loader.exec_module(obj);return obj

def prepare(route,case,package,output):
 need(route in CASES and case in CASES[route],'Exact prepared route/case required; no automatic cohort expansion')
 # One isolated worker owns a route. Qualification may import routes sequentially
 # in a fresh process; clear only these explicit scientific sibling aliases.
 for name in ('independent_core','source_contracts','policy','admission_checker','bdd_core','graph_fairness'):
  sys.modules.pop(name,None)
 relative=ENTRY[route]
 if route=='production_independent_saved_view_agreement':relative=E+'common_checker_01/'+COMPARISONS[case]+'/compare.py'
 m=module(package,relative,'supplement_route_'+route);context=RouteIO(package,output)
 if route=='baseline_traffic':context.bind_production(m)
 elif route in ('lift_saved_prefix','production_independent_saved_view_agreement'):context.bind_main_io(m)
 else:
  context.bind_independent(m)
  if hasattr(m,'w'):context.bind_independent(m.w)
  if hasattr(m,'core'):context.bind_independent(m.core)
  if 'independent_core'in sys.modules:context.bind_independent(sys.modules['independent_core'])
 # witness_worker aliases read_pin/pin locally at import; bind_independent(m)
 # and bind_independent(m.w) deliberately cover both references.
 return {'route':route,'case':case,'module':m,'io':context,'entry':relative,'package':package,'output':Path(output)}

def assert_equal(actual,expected,message):
 need(type(actual)is type(expected),'Result type mismatch: '+message)
 if type(actual)is dict:
  need(set(actual)==set(expected),'Result key mismatch: '+message)
  for k in actual:assert_equal(actual[k],expected[k],message+'/'+str(k))
 elif type(actual)is list:
  need(len(actual)==len(expected),'Result array length mismatch: '+message)
  for i,(a,b)in enumerate(zip(actual,expected)):assert_equal(a,b,message+'/'+str(i))
 else:need(actual==expected,'Scientific result differs: '+message)

def stripped(obj,keys):return {k:v for k,v in obj.items()if k not in keys}
def save(path,value):
 raw=encoded(value);need(len(raw)<=16*1024*1024,'Fresh output file cap')
 with Path(path).open('xb')as f:f.write(raw)

def initial_case(m,case,p):
 """Retain saved_worker.main's per-row binding checks; unchanged core.check."""
 manifest=p.selected_view(E+'initial_region_check_01/SAVED_INPUTS.json')
 need(manifest['candidate_order']==ELEVEN and [r['candidate_id']for r in manifest['rows']]==ELEVEN,'Fixed original eleven source roster')
 for ref in manifest['files']:p.read_pin(ref)
 adapted=p.read_json_pin(manifest['adapted_nine_profiles'])['profiles']
 row=next(r for r in manifest['rows']if r['candidate_id']==case);refs=row['inputs']
 source=refs['source'];profiles=p.read_json_pin(refs['profile']);profile=profiles['profiles'][case]
 cert=p.read_json_pin(refs['cooperative_certificate']);sem=p.read_json_pin(refs['semantics'])['cooperative']
 region=p.read_json_pin(refs['regions']);result=p.read_json_pin(refs['population_result']);model=p.read_json_pin(refs['model']);native=p.read_json_pin(refs['result'])
 need(profile['fixture_id']==cert['fixture_id']==result['fixture']==case,'Saved initial source identity')
 for source_ref in (profile['source'],cert['source_profile_pins']['source'],model['input']):need((source_ref['bytes'],source_ref['sha256'])==(source['bytes'],source['sha256']),'Initial source original pin')
 need(cert['source_profile_pins']['profiles_sha256']==refs['profile']['sha256'],'Initial original profile SHA')
 need(cert['model_sha256']==refs['model']['sha256']and cert['result_sha256']==refs['result']['sha256'],'Initial original model/result SHA')
 need(cert['model_and_replay_validated']is True and cert['original_model_audit']['status']=='PASS','Historical model premise')
 need(sem['model']['status']=='PASS'and sem['source_binding']['fixture']==case,'Historical source premise')
 need(cert['normalization_and_handoff_audit']['status']=='PASS'and sem['native_normalization']['status']=='PASS','Historical normalization premise')
 for name in ('source','profile','model','result','input_roster'):
  old=sem['source_binding'][name];need((old['bytes'],old['sha256'])==(refs[name]['bytes'],refs[name]['sha256']),'Original source semantic pin')
 need(native['model_export']['sha256']==refs['model']['sha256'],'Original native model export SHA')
 for key,value in result['regions'].items():need(region[key]==value,'Saved region equality')
 if case in adapted:need(adapted[case]==dict(profile,case_id=case,variant='initializers'),'Original initializer adapter profile')
 k=m.core.check(profile,region);k['region_parameter']='K'
 v=m.core.check(profile,dict(region,K=region['V'],K_valuations=region['V_valuations']));v['region_parameter']='V';v['formula']=v['formula'].replace('K(e,s)','V(e,s)')
 for key in list(v):
  if'_K'in key or key.startswith('missing_K'):v[key.replace('_K','_V')]=v.pop(key)
 for env_row in v['environment_rows']:
  for key in list(env_row):
   if'_K_'in key:env_row[key.replace('_K_','_V_')]=env_row.pop(key)
 v['scope']='Exact original-initializer predicate for separately certified saved V; region correctness is a prior premise, and no controller is executed.'
 equality=None
 if'REGION_COMPARISON.json'in refs:
  comparison=p.read_json_pin(refs['REGION_COMPARISON.json']);arena=p.read_json_pin(refs['arena.json'])
  need(p.read_json_pin(refs['ARENA_AUDIT.json'])['status']=='PASS','Saved arena premise')
  need(comparison['equal']is True and comparison['new_explicit_vertices']==comparison['native_vertices'],'Saved explicit/native equality')
  semantics=arena['metadata']['vertex_semantics'];explicit={tuple(semantics[q]['valuation'][n]for n in region['field_order'])for q in comparison['new_explicit_vertices']};stored={tuple(s[n]for n in region['field_order'])for s in region['K_valuations']}
  need(explicit==stored and comparison['new_explicit_K']==comparison['native_K']==region['K'],'Exact saved K membership')
  equality='SAVED_EXPLICIT_AND_NATIVE_K_EXACT_MEMBERSHIP_EQUAL'
 return {'candidate_id':case,'purpose':row['purpose'],'I_M_K':k,'I_M_V':v,'historical_residual_entry':region['entry'],'saved_region_evidence':{'K':region['K'],'V':region['V'],'W':region['W'],'all_W_V_minus_K':region['all_W_V_minus_K'],'explicit_native_K_comparison':equality,'region_recomputed':False},'input_bindings':refs}

def execute(prepared):
 route,case,m,p,out=(prepared[k]for k in ('route','case','module','package','output'));context=prepared['io']
 need(out.is_dir()and not any(out.iterdir()),'Fresh empty isolated worker output')
 view=None;ignored=[];failure=False
 if route=='original_initial_K_V':
  result=initial_case(m,case,p);expected=p.selected_view(E+'initial_region_check_01/saved_results_01/'+case+'.json')
 elif route in ('remaining_nine_independent_saved','lift_followup_independent_saved','choice_toggle_independent_saved'):
  prefix={'remaining_nine_independent_saved':'remaining_nine_batch_01/','lift_followup_independent_saved':'lift_resource_followup_01/batch_01/','choice_toggle_independent_saved':'selected_strategy_execution_01/batch_01/'}[route]
  directory=E+prefix+case+'/'
  manifest=p.selected_view(directory+'independent_inputs.json');old=p.selected_view(directory+'independent/AUDIT_RESULT.json')
  try:result,view=m.audit(manifest)
  except Exception as error:
   result={'status':'UNKNOWN_INDEPENDENT_AUDIT','error':str(error),'exception_type':type(error).__name__,'production_certificate_read':False,'production_checker_imports':0,'native_processes':0,'region_fixed_point_solves':0};failure=True
  ignored=sorted(MAIN_METADATA|({'traceback'}if failure else set()));expected=stripped(old,set(ignored))
  if view is not None:assert_equal(view,p.selected_view(directory+'independent/INDEPENDENT_VIEW.json'),'complete independent graph view')
  if failure:need(route=='lift_followup_independent_saved'and case=='lift__preferred'and old['status']=='UNKNOWN_INDEPENDENT_AUDIT','Unexpected new independent failure')
 elif route=='baseline_arbiter':
  relative=p.selected_view(ARB+'INPUTS.relative.json');base=p.selected_path(ARB+'INPUTS.relative.json').parent
  for group in ('inputs','bdd_files'):
   for ref in relative[group].values():
    local=PurePosixPath(ref['path']);need(not local.is_absolute()and '..'not in local.parts,'Arbiter relative input');ref['path']=str(base/local)
  result,view=m.audit(relative);ignored=sorted(MAIN_METADATA);expected=stripped(p.selected_view(ARB+'expected/AUDIT_RESULT.json'),set(ignored))
  assert_equal(view,p.selected_view(ARB+'expected/INDEPENDENT_VIEW.json'),'complete baseline independent view')
 elif route=='baseline_traffic':
  directory=p.selected_path(COMPAT+'inputs/traffic_single/model.json').parent;profiles=p.selected_path(COMPAT+'profiles/traffic_single.json');legacy=out/'legacy';legacy.mkdir()
  result=m.check(directory,legacy_fixture_for(route,case),profiles,p.origin_pin(profiles)['sha256'],legacy)
  expected=p.selected_view(COMPAT+'results/traffic_single/certificate.json')
  for name in ('derived_original_graph.json','derived_original_fairness.json'):
   if(legacy/name).exists():assert_equal(decode((legacy/name).read_bytes()),p.selected_view(COMPAT+'results/traffic_single/'+name),'baseline production '+name)
 elif route=='production_independent_saved_view_agreement':
  folder=E+'common_checker_01/'+COMPARISONS[case]+'/';manifest=p.selected_view(folder+'prepared_inputs_01/INPUTS.json')
  need(manifest['candidate_order']==m.ORDER and [r['candidate_id']for r in manifest['rows']]==m.ORDER,'Exact saved comparison roster')
  for ref in manifest['expected_code_and_profiles'].values():p.read_pin(ref)
  # Deliberately use the unchanged per-row comparator, not historical main's
  # complete launch/freezer/capture ledger. Omitted captures remain historical.
  rows=[m.compare_row(row,manifest['expected_code_and_profiles'])for row in manifest['rows']]
  result={'status':'COMPLETE_SAVED_RESULT_COMPARISON','rows':rows,'native_invocations':0,'BDD_evaluations':0,'graph_algorithm_runs':0}
  old=p.selected_view(folder+'results_01/RESULT.json');expected={key:old[key]for key in result};ignored=sorted(set(old)-set(result))
 elif route=='lift_saved_prefix':
  folder=E+'common_checker_01/lift_followup_comparison_01/';mp=p.selected_path(folder+'PREFIX_INPUTS.json');legacy=out/'legacy'
  oldargv=sys.argv;sys.argv=[str(m.__file__),str(mp),'--sha256',p.origin_pin(mp)['sha256'],'--output-dir',str(legacy)]
  try:m.main()
  finally:sys.argv=oldargv
  ignored=['created_utc'];result=stripped(decode((legacy/'RESULT.json').read_bytes()),set(ignored));expected=stripped(p.selected_view(folder+'prefix_results_01/RESULT.json'),set(ignored))
 elif route=='lift_source_positive_saved_graph':
  folder=E+'lift_positive_policy_01/';graph=p.selected_view(folder+'positive_witness_01/witness/CONTROLLER.json');cert=p.selected_view(folder+'positive_witness_01/witness/CERTIFICATE.json')
  for key in ('input_manifest','source','profiles','controller','policy','source_oracle','fairness_core'):p.read_pin(cert[key])
  for key,name in (('policy','policy.py'),('source_oracle','source_contracts.py'),('fairness_core','independent_core.py')):
   actual=p.origin_pin(Path(m.__file__).with_name(name));need((actual['bytes'],actual['sha256'])==(cert[key]['bytes'],cert[key]['sha256']),'Exact positive science copy '+name)
  result=m.audit_graph(graph,m.source.CONTRACTS[case],m.policy.initial_states(),m.policy.step,{'nodes':2048,'edges':65536},time.monotonic()+55,(0,3))
  ignored=['input_manifest','source','profiles','controller','policy','source_oracle','fairness_core','all_input_pins_unchanged'];expected=stripped(cert,set(ignored))
 elif route in ('pair_full_native_helper_saved','lift_preferred_timing_saved','lift_full_native_policy_extension_saved'):
  d,entry,resultname={'pair_full_native_helper_saved':('selected_strategy_full_helper_check_01','PROTOCOL.json','FULL_HELPER_RESULT.json'),'lift_preferred_timing_saved':('lift_preferred_mapping_review_02','INPUTS.json','WITNESS_RESULT.json'),'lift_full_native_policy_extension_saved':('lift_full_helper_extension_01','PROTOCOL.json','EXTENSION_RESULT.json')}[route]
  folder=E+'independent_audit_01/'+d+'/';result=m.execute(p.selected_view(folder+entry));ignored=sorted(MAIN_METADATA);expected=stripped(p.selected_view(folder+'execution_01/output/'+resultname),set(ignored))
 else:raise ValueError('Unimplemented route')
 assert_equal(result,expected,'all declared result fields for '+route+'/'+case)
 save(out/'RESULT.json',result)
 if view is not None:save(out/'INDEPENDENT_VIEW.json',view)
 receipt={'schema':'portable-saved-evidence-route-result-v1','status':'EXPECTED_UNKNOWN_REPRODUCED'if failure else'PASS_SAVED_EVIDENCE_RECHECK','route':route,'case':case,'historical_scientific_status':result.get('status'),'all_compared_scientific_fields_equal':True,'excluded_original_CLI_metadata':ignored,'input_IO_bindings':context.bindings,'input_view_audit':p.report(),'new_native_calls':0,'new_scientific_samples':0,'original_unknown_promoted':False,'scope':'Verification of existing evidence; not full reproduction of native synthesis or new scientific independence.'}
 save(out/'COMPARISON.json',receipt);return receipt
