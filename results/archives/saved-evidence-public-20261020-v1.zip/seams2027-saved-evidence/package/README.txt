Saved evidence for the fixed repair candidates and selected-strategy controls
PRIVATE LOCAL PREPARATION — not published, not yet qualified for saved-data runs.

This package verifies existing evidence. It does not fully reproduce native
synthesis, add scientific samples, or establish a new independent implementation.
Current preparation state is PREPARATION_STATUS.json. A successful metadata audit
alone does not qualify the scientific replay adapters.

Reading order
1. CLAIM_GUIDE.txt gives six short entrances from Table IV and Figure 2 to the
   saved claims, results, boundaries and corresponding routes. CLAIMS.json is
   the complete machine-readable file index, including individual saved DAGs.
2. ROUTE_DESIGN.json states the original scope and I/O requirements for every
   route. The executable route/case registry is code/route_adapters.py:CASES.
3. BASE_BINDING.json fixes the existing anonymous base package. Its historical
   qualifications and pilots are not qualifications of this new supplement.
4. BINDING_SEMANTICS.json explains original bytes, anonymous-copy bytes and the
   explicitly recorded in-memory path view. ORIGIN_DIGESTS.json and MANIFEST.json
   are different ledgers: do not compare an original digest to anonymous bytes.
5. OMITTED_PAYLOADS.json describes mixed native/Python captures and external
   runtime identities that are not distributed. Their historical receipt pins
   do not freshly verify the omitted contents.

The fixed published denominator is eleven. The first nine new native attempts
and the two later Lift attempts remain separate attempt records. The two
constructed Choice/Toggle controls are outside the published eleven.
I_M(K) is true for eight and false for three original initial conditions.
Initial Lift resource UNKNOWNs, later Lift/P mapping UNKNOWN and Mine/P native
refusal remain visible; none becomes a mathematical negative or success through
packaging. A native refusal is not an independent unrealizability proof.

The source-coded positive Lift policy has 128 states and 1020 edges with both
original c initial choices, all three logical AUX monitors initially S0, and
private priority 3. Its saved-graph audit does not regenerate the graph. The
separate full-native extension checks 49152 policy assignments and 2048 states;
it supports a strict full-native strategy from the original initials whose
helper-false original view is cooperative. It does not claim cooperation after
helper becomes true, liveness from arbitrary invariant states, or a unique
core-memory-versus-extractor cause. See the interpretation records linked in CLAIM_GUIDE.txt.

Safe inspection
From the package root, with Python 3.10+:
  python3 -I -S -B code/review.py metadata --package . \
    --expected-manifest INDEPENDENTLY_RECORDED_SHA256
The manifest must be independently supplied. This checks file closure and
separate original/copy identity metadata without evaluating saved DAGs or graphs.
The code requires canonical nonsymlink input paths. No network/native runtime,
Java/JAR download or old workspace path is used as an execution fallback.

Preparation and later rechecks
Import-only qualification imports definitions with science constructors and
functions trapped. Actual routes are one bounded owned Python worker per new
explicit route/case GO, with fresh output/START and no automatic retry. Each
worker has 60 seconds, 512 MiB sampled RSS, 8 MiB per stream, 16 MiB per output file and
64 MiB sampled aggregate output; require 1 GiB free disk. The parent allows cleanup
and uses the consumer's /bin/ps on POSIX. These are sampled termination bounds,
not a hard continuous filesystem/RSS quota.

The original scientific Python/source/DAG/controller/printer files are byte
copies. Anonymous JSON changes only recorded path strings. Original naked
model/profile/result hashes, native basename pins and controller JSON before/after-print
hashes remain original. The adapter first checks current copied bytes, validates
the admitted original pin, then projects package paths consistently in memory.
Raw controller JSON bytes are never reserialized. The before/after-print
controller digests exclude the controller JSON final newline as specified;
printer text is a separate exact-byte payload. New receipts describe this distinction explicitly.

Historical source/compiler sharing, region premises and saved-result scope
remain unchanged. The Python audit hook is a boundary for pinned code, not an
operating-system sandbox for hostile code. Component rights and attribution
remain unresolved where the existing package says so; LICENSES_AND_SCOPE.txt
must be read before any publication or redistribution decision.

Artificial I/O qualification
ARTIFICIAL_RESULT.json records 90 synthetic checks of the adapter, typed
process receipts, GO validation and finalization failure branches. The source
is code/qualify_artificial.py; it uses generated toy files, not scientific
evidence. This does not replace relocation/import qualification or saved-data
pilots. REVISION_CHANGES.json records the preserved earlier candidate.

The public Traffic S/P case label traffic_single__preferred selects the
historical checker fixture traffic_single. Scientific evidence retains the
historical fixture identifiers. This exact name binding affects only the I/O
adapter argument; the original checker, source and saved evidence are unchanged.

The worker may read back files in its exact assigned output directory when the
path is canonical and resolves to itself. External directories, sibling worker
outputs, parent traversal and symlink aliases gain no read access. The package
input API remains package-only. Each import-only qualification also writes a
small generated output fixture and checks its bytes, text and digest under the
installed audit hook; no scientific function is called by that probe.
