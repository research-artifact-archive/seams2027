OBSTACLE A/B: POSITIVE SOURCE CERTIFICATES AND PUBLIC MODE CONTROLS

This is a separate, unpublished publication candidate. The underlying scientific
results have been adopted in SCIENTIFIC_ADOPTION.json. The later existing-host
replay of exact public v1 inputs is adopted in replay/records/ROOT_PUBLIC_REPLAY_ADOPTION.json.
This v2 package still awaits the publication owner's adoption after review.
It changes neither an earlier archive nor the prior UNKNOWN history. The package
identifier r6_positive_certificates_and_controls is not a manuscript appendix name.

Start with SCIENTIFIC_DISPOSITION.json. The two evidence roles are separate:

C1 — Positive source-strategy existence
certificates/A.json and B.json specify finite-state response strategies for the
exact old authored query A and exact updated point query B. The independently
authored checkers/check_certificate.py directly enumerates typed source inputs
and checks safety, closure, phase transitions, finite-rank descent and initial
quantification. It does not import a saved winning-set evaluator, fixed-point
routine, predecessor routine, generator semantics, or saved graph coverage.
The accepted original A contains 5,016 states and 12,656 policy edges over two
phases; B contains 5,015 states and 12,672 policy edges. The maximum rank is 17 in
each phase of each case. These are positive certificates, not proofs of winning
region maximality or of every negative point. The saved W and graph used to
generate them are untrusted proposal provenance, not checker proof premises.

The separate all-domain ENV totality check covers all 6,272 source states and
98 typed next ENV inputs per state. It finds 9,536 legal ENV edges, with outdegree 1..9, and checks
both exact source files and the 45-byte projection/124-byte point-initialization
binding. Empty ENV justice, next-SYS-independent ENV safety, and typed-total
strategy completion connect the positive strategies to the existing all-history
source-kind bridge. This is specific to these sources, not a general equality of
legal-prefix cooperation and Kind. See theory/INDEPENDENT_CHECKER_RATIONALE.md
and theory/FINITE_POSITIVE_PROOF.txt.

c1/stages/ contains the original execution records as explicit location-sanitized
derivatives. Both original positive checks passed; qualification accepted two
positive controls and rejected 25 predetermined malformed inputs per source with
their expected codes. All 50 actual malformed inputs are retained in gzip form.
For 48 cases, a checker receipt contains the original uncompressed input hash.
The two duplicate_json_key inputs fail during JSON parsing before that hash is
assigned, so their receipt field is null. Their retained exact construction,
driver summary and archive-hash chain bind them instead. Do not claim all 50
checker receipts directly contain an input hash. Qualification tests a fixed
defect roster; it is not a proof of complete checker correctness.

C2 — Selected public mode contrast
The public Check Realizability action ran once for A and once for B with Original
GR(1), JTLV, optimizations disabled and reordering disabled. Both returned true;
the console identified GR1GameMemoryless. Prior selected-Kind checks of the same
two queries returned false and identified GR1SeparatedGame. Those prior records
are copied byte-identically from the existing public AD candidate in prior_kind/.
No new Kind run was made. The new mode controls are in c2/A and c2/B, with exact
logger XML and labeled visual console transcriptions.

The ordinary preference file has no synthesisMethod entry. The private screenshot
visibly selected Original GR(1), and the installed preference initializer sets
the missing key's default to synthesisGR1. The raw four-setting file, initializer
disassembly and visual attestation are separate evidence; the package does not
invent an explicitly stored ordinary-selection key. The 20 pinned installed JARs
and preparation baseline are in c2/runtime. Installed byte identity, registration,
observed console class and actual live intermediate BDD equality are distinct.

Changing the selected mode changes both reduction and solver algorithm. The
comparison therefore supports mode-dependent answers for the same queries, not
first-change timing as an exclusive internal cause. No live GUI BDD was exported.
Q is not identified with W or K. No default/all-backend defect, deployed rejection,
controller installation, private-memory handoff, live update switch, incidence
estimate or performance comparison follows. A was already negative in Kind mode;
the update is not shown to introduce the obstruction. Plugin times and sampled
RSS are diagnostic records only. Short generation stages had only two RSS samples;
their sampled 573,440 bytes must not be read as actual peak memory.

Exact queries and third-party source boundary
A is the unchanged 2,097-byte published old source. B is the 1,902-byte ordinary
update projection plus the disclosed 124-byte point initializer at
(obstacle0,obstacle1,obsWait;robot0,robot1)=(3,5,true;5,5). It is a separate fixed
continuation query, not the unchanged published update or an old-controller
memory transfer. No old initializer is conjoined.

No upstream .spectra or .spectraArxived body is distributed. All five required
source-byte inputs are privately frozen and publicly specified by exact hashes
in SOURCE_RESTORATION.json. Obtain the official distributor archive under its
terms, verify its member hashes, and perform only the stated transformations.
The archive inspection found no identified license/readme/notice member; this
package grants no third-party source rights. Only our point-initializer appendix
is included. Screenshots and AX are withheld; the final screenshots display
third-party source code. Original image hashes are retained, with no image edit
or crop. Console transcriptions were read visually from the unedited images;
they are neither AX-exported console text nor workbench stdout/stderr.

Derivatives, integrity and the recorded v1 replay
TRANSFORMATION_LEDGER.json maps each copied original record to its current public
derivative. Textual derivatives replace private path prefixes only. Certificate
and malformed-fixture fields outside top-level informational provenance are
unchanged, including duplicate JSON properties. Gzip derivatives have fresh
compressed/uncompressed hashes. Historical hashes inside execution records still
identify the original executed bytes. They do not silently become hashes of these
sanitized derivatives. PUBLIC_QUALIFICATION_INPUT_MAP.json gives both identities.
The checker and qualifier code are unchanged bytes from the executed freezes.

Run both static integrity commands to inspect this package:
  python3 -I -S -B verify_integrity.py
  python3 -I -S -B verify_replay_integrity.py
They check file rosters, hashes, gzip integrity, recorded result bindings, syntax
and limited privacy patterns; they import no scientific module and perform no
game, policy, rank, predecessor or fixed-point calculation. The unchanged first
verifier reports its own zero scientific executions; the replay evidence below
records a separate, earlier execution.

replay/VERIFICATION_ADDENDUM.txt describes the adopted existing-host replay of
the exact public v1 checker, qualifier, certificates and controls. A and B, the
separate totality/source binding and all 52 qualification controls passed their
recorded expected outcomes. The 50 malformed gzip inputs match the existing
public controls byte-for-byte and are mapped without duplicate payloads. Actual
restored source paths are identified by argv; receipt source.path fields remain
historical labels. The addendum distinguishes original hashes from sanitized
record hashes and v1 replay identities from this v2 container.

This is not fresh-host, external or fully hermetic reproduction. Assembly of
v2 performed no scientific execution or source restoration. Optional future
scientific calls are in FUTURE_REPLAY_COMMANDS.txt. The historic generator/supervisor in
inspection/ are inspection material with original layout/expiry dependencies,
not portable current execution entrypoints. Existing eight independent exported
fixed-point UNKNOWN results remain UNKNOWN and distinct from these positive
source certificates. Original contributions retain LICENSE-original.txt; see
THIRD_PARTY_NOTICES.md for the separate source/runtime boundary.
