#!/usr/bin/env python3
"""Fresh owned process-group supervisor for preregistered Python stages.

Sampled RSS is recorded honestly; it is not instantaneous memory isolation.
Only the child process group created by this invocation may be signalled.
"""
from __future__ import annotations
import argparse
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

STOP_UTC = dt.datetime(2026, 10, 25, 22, 0, 0, tzinfo=dt.timezone.utc)


def now():
    return dt.datetime.now(dt.timezone.utc)


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def process_snapshot():
    completed = subprocess.run(['/bin/ps', '-axo', 'pid=,ppid=,pgid=,rss='],
                               capture_output=True, text=True, timeout=5, check=True)
    rows = []
    for line in completed.stdout.splitlines():
        fields = line.split()
        if len(fields) != 4:
            raise RuntimeError('UNPARSEABLE_PS_ROW')
        pid, ppid, pgid, rss_kib = map(int, fields)
        rows.append({'pid': pid, 'ppid': ppid, 'pgid': pgid, 'rss_bytes': rss_kib * 1024})
    return rows


def owned_rows(rows, child_pid):
    # start_new_session gives the child an owned process group with PGID=PID.
    # Include descendants too, even if a descendant creates another PGID.
    owned = {r['pid'] for r in rows if r['pgid'] == child_pid}
    owned.add(child_pid)
    while True:
        additions = {r['pid'] for r in rows if r['ppid'] in owned}
        if additions <= owned:
            break
        owned |= additions
    return [r for r in rows if r['pid'] in owned]


def directory_bytes(path):
    total = 0
    for item in Path(path).rglob('*'):
        if item.is_file() and not item.is_symlink():
            try:
                total += item.stat().st_size
            except FileNotFoundError:
                pass
    return total


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def child_limits(cpu_seconds):
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds))
    resource.setrlimit(resource.RLIMIT_FSIZE, (67108864, 67108864))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', required=True)
    parser.add_argument('--run-dir', type=Path, required=True)
    parser.add_argument('--total-root', type=Path, required=True)
    parser.add_argument('--wall-seconds', type=int, choices=(180, 300), required=True)
    parser.add_argument('--rss-bytes', type=int, default=1073741824)
    parser.add_argument('--output-bytes', type=int, default=134217728)
    parser.add_argument('--total-output-bytes', type=int, default=536870912)
    parser.add_argument('--sample-seconds', type=float, default=0.25)
    parser.add_argument('--expected-script-sha256', required=True)
    parser.add_argument('--root-go', type=Path, required=True)
    parser.add_argument('--root-go-sha256', required=True)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.command and args.command[0] == '--':
        args.command = args.command[1:]
    if args.rss_bytes > 1073741824 or args.output_bytes > 134217728 or args.total_output_bytes > 536870912:
        raise SystemExit('CAPS_EXCEED_PROTOCOL')
    if args.sample_seconds <= 0 or args.sample_seconds > 0.25:
        raise SystemExit('SAMPLE_INTERVAL_EXCEEDS_PROTOCOL')
    if len(args.command) < 2 or not Path(args.command[0]).is_absolute() or not Path(args.command[1]).is_absolute():
        raise SystemExit('REQUIRE_ABSOLUTE_RUNTIME_AND_SCRIPT')
    script_pin = pin(args.command[1])
    if script_pin['sha256'] != args.expected_script_sha256:
        raise SystemExit('SCRIPT_HASH_MISMATCH')
    go_pin = pin(args.root_go)
    if go_pin['sha256'] != args.root_go_sha256:
        raise SystemExit('GO_HASH_MISMATCH')
    go = json.loads(args.root_go.read_text())
    if go.get('status') != 'GO_PROTOCOL_WITH_CODE_FREEZE_AND_PREFLIGHT_GATES':
        raise SystemExit('GO_STATUS_MISMATCH')
    if now() >= STOP_UTC or now() >= dt.datetime.fromisoformat(go['expires_utc']):
        raise SystemExit('SCIENCE_DEADLINE_EXPIRED')
    declared = go['limits']['certificate_stages']
    if args.stage not in declared or not isinstance(declared[args.stage], dict):
        raise SystemExit('STAGE_NOT_AUTHORIZED')
    if args.wall_seconds != declared[args.stage]['wall_s']:
        raise SystemExit('STAGE_WALL_MISMATCH')
    run_dir = args.run_dir.resolve()
    total_root = args.total_root.resolve()
    if total_root not in run_dir.parents:
        raise SystemExit('RUN_DIR_NOT_WITHIN_TOTAL_ROOT')
    total_root.mkdir(parents=True, exist_ok=True)
    # A shared advisory lock excludes *different* stages as well as duplicate
    # stage names. Keep this file object alive through child exit and cleanup.
    stage_lock = (total_root / 'STAGE_EXECUTION.lock').open('a+')
    try:
        fcntl.flock(stage_lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        stage_lock.close()
        raise SystemExit('ANOTHER_CERTIFICATE_STAGE_IS_RUNNING')
    stage_lock.seek(0)
    stage_lock.truncate()
    json.dump({'supervisor_pid': os.getpid(), 'stage': args.stage,
               'acquired_utc': now().isoformat()}, stage_lock)
    stage_lock.write('\n')
    stage_lock.flush()
    reservation = total_root / f'RESERVED_{args.stage}.json'
    with reservation.open('x') as reserved:
        json.dump({'stage': args.stage, 'created_utc': now().isoformat(),
                   'run_dir': str(run_dir), 'root_go_sha256': go_pin['sha256']}, reserved)
        reserved.write('\n')
    # Atomic directory creation reserves this stage invocation: no overwrite/retry.
    run_dir.mkdir(parents=True, exist_ok=False)
    snapshot = process_snapshot()
    if not any(r['pid'] == os.getpid() for r in snapshot):
        raise SystemExit('SUPERVISOR_NOT_VISIBLE_TO_PS')
    preflight = {'status': 'PASS_BEFORE_CHILD_LAUNCH', 'stage': args.stage,
                 'created_utc': now().isoformat(), 'root_go': go_pin,
                 'supervisor': pin(Path(__file__)), 'script': script_pin,
                 'runtime': pin(args.command[0]), 'runtime_version': sys.version,
                 'command': args.command, 'cwd': str(Path.cwd()),
                 'limits': {'wall_seconds': args.wall_seconds, 'rss_bytes': args.rss_bytes,
                            'sample_seconds': args.sample_seconds, 'output_bytes': args.output_bytes,
                            'total_output_bytes': args.total_output_bytes,
                            'CPU_seconds': args.wall_seconds, 'file_bytes': 67108864,
                            'core_dump_bytes': 0},
                 'rss_semantics': 'Owned process-group/tree RSS sampled, not instantaneous hard isolation',
                 'scientific_child_started': False}
    write_json(run_dir / 'PREFLIGHT.json', preflight)
    if directory_bytes(total_root) >= args.total_output_bytes:
        raise SystemExit('TOTAL_OUTPUT_ALREADY_AT_CAP')
    start = time.monotonic()
    child = None
    signals = []
    sample_count = 0
    peak_rss = 0
    outcome = 'PENDING'
    error = None
    child_pid = None
    exit_code = None
    try:
        with (run_dir / 'STDOUT.txt').open('wb') as stdout, (run_dir / 'STDERR.txt').open('wb') as stderr, \
                (run_dir / 'SAMPLES.jsonl').open('w') as samples:
            child = subprocess.Popen(args.command, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                     shell=False, start_new_session=True,
                                     preexec_fn=lambda: child_limits(args.wall_seconds))
            child_pid = child.pid
            if child_pid == os.getpgrp():
                raise RuntimeError('OWNED_GROUP_EQUALS_SUPERVISOR_GROUP')
            write_json(run_dir / 'START.json', {'pid': child_pid, 'owned_pgid': child_pid,
                                              'started_utc': now().isoformat(), 'stage': args.stage})
            while True:
                rows = owned_rows(process_snapshot(), child_pid)
                rss = sum(r['rss_bytes'] for r in rows)
                peak_rss = max(peak_rss, rss)
                elapsed = time.monotonic() - start
                out_size = directory_bytes(run_dir)
                all_size = directory_bytes(total_root)
                sample = {'elapsed_seconds': elapsed, 'rss_bytes': rss,
                          'owned_rows': rows, 'output_bytes': out_size, 'total_output_bytes': all_size}
                samples.write(json.dumps(sample, separators=(',', ':')) + '\n')
                samples.flush()
                sample_count += 1
                if now() >= STOP_UTC:
                    outcome = 'STOP_SCIENCE_DEADLINE'
                    break
                if elapsed > args.wall_seconds:
                    outcome = 'UNKNOWN_WALL_CAP'
                    break
                if rss > args.rss_bytes:
                    outcome = 'UNKNOWN_RSS_CAP'
                    break
                if out_size > args.output_bytes or all_size > args.total_output_bytes:
                    outcome = 'UNKNOWN_OUTPUT_CAP'
                    break
                exit_code = child.poll()
                if exit_code is not None:
                    # ps may have observed the just-finished child before poll reaped it.
                    remaining_descendants = [r for r in rows if r['pid'] != child_pid]
                    if remaining_descendants:
                        outcome = 'UNKNOWN_CHILD_EXIT_WITH_DESCENDANTS'
                    else:
                        outcome = 'FINISHED_ZERO' if exit_code == 0 else 'FINISHED_NONZERO'
                    break
                time.sleep(args.sample_seconds)
    except BaseException as exc:
        outcome = 'UNKNOWN_SUPERVISOR_EXCEPTION'
        error = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        if child is not None:
            # Kill only our new PGID, and only when an abnormal outcome or live child remains.
            if outcome not in ('FINISHED_ZERO', 'FINISHED_NONZERO') or child.poll() is None:
                try:
                    os.killpg(child.pid, signal.SIGTERM)
                    signals.append('SIGTERM_OWNED_GROUP')
                except ProcessLookupError:
                    pass
                try:
                    child.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                        signals.append('SIGKILL_OWNED_GROUP')
                    except ProcessLookupError:
                        pass
                    child.wait(timeout=5)
            exit_code = child.poll()
        receipt = {'schema': 'v71-r6-bounded-python-stage-result-v1', 'status': outcome,
                   'stage': args.stage, 'finished_utc': now().isoformat(),
                   'elapsed_wall_seconds': time.monotonic() - start,
                   'child_pid': child_pid, 'child_exit_code': exit_code,
                   'scientific_child_started': child is not None, 'scientific_attempts': int(child is not None),
                   'sample_count': sample_count, 'sampled_peak_process_tree_RSS_bytes': peak_rss,
                   'signals': signals, 'error': error, 'command': args.command,
                   'root_go': go_pin, 'supervisor': pin(Path(__file__)), 'script': script_pin,
                   'output_bytes_before_receipt': directory_bytes(run_dir),
                   'total_output_bytes_before_receipt': directory_bytes(total_root),
                   'full_reset': 0}
        write_json(run_dir / 'RUN_RECEIPT.json', receipt)
        print(json.dumps({k: receipt[k] for k in ['stage', 'status', 'elapsed_wall_seconds',
                                                'sampled_peak_process_tree_RSS_bytes']}))
    fcntl.flock(stage_lock.fileno(), fcntl.LOCK_UN)
    stage_lock.close()
    return 0 if outcome == 'FINISHED_ZERO' else 1


if __name__ == '__main__':
    sys.exit(main())
