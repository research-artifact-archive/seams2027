#!/usr/bin/env python3
"""Propose a finite winning witness from a fixed saved graph/candidate set.

This is NOT the independent checker. It deliberately proposes from saved data;
the separately owned checker must reconstruct source ENV/safety predicates.
No source evaluator, solver, predecessor implementation, or checker is imported.
"""
from __future__ import annotations
import argparse
import datetime as dt
import gzip
import hashlib
import json
from pathlib import Path
import sys
import time

BASE = Path('experiment/v71_acceptance_cycle_20261025')
FRONT = BASE / 'research_strategy_after_r3/resumed_2333/frontend_workspace/FixedObstacleR4'
CASES = {
    'old': {
        'case_id': 'A_OLD_PUBLIC_INITIAL',
        'source_name': 'MovingObstacleEvasion.spectra',
        'source_sha256': '19c71d970b05fec41f0fa60fce155bf136b33836ffd785a65c2c436a712c3ac1',
        'graph_sha256': '52126fa01edcf0f247366f5e9b879a996043a3aabb0a9bdd0e39d54a2ee00224',
        'result_sha256': 'fd4a92f6b0d78f8a50a879488ec61b0b10b8d554ee6dca1f7fd6d845465196f3',
        'candidate_count': 5016, 'initial': (7, 7, False, 1, 1),
        'goals': ((5, 2), (2, 3)),
    },
    'new': {
        'case_id': 'B_NEW_POINT_R2404',
        'source_name': 'MovingObstacleEvasionUpdate_retained_r2404.spectra',
        'source_sha256': '212309df489c3ddc7bf7ec6a750aed2d0da4fb7e26995e5ee3a0405c9897e1d5',
        'graph_sha256': '335a31adc455ddd9e0372ea11154508005b4e670b7cafb1de804cdff2f705dac',
        'result_sha256': '8aa5e90722972bf4085fedcd1e7fa9e33e5e5bcb03549cbf85c9ff18ef500519',
        'candidate_count': 5015, 'initial': (3, 5, True, 5, 5),
        'goals': ((3, 7), (4, 8)),
    },
}


class CandidateFailure(Exception):
    pass


def require(condition, message):
    if not condition:
        raise CandidateFailure(message)


def pin(path):
    data = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def strict_int(value):
    return type(value) is int


def typed_state(s):
    return (len(s) == 5 and all(strict_int(s[k]) for k in (0, 1, 3, 4))
            and type(s[2]) is bool and 1 <= s[0] <= 7 and 1 <= s[1] <= 7
            and 1 <= s[3] <= 8 and 1 <= s[4] <= 8)


def encode_state(s):
    ox, oy, wait, rx, ry = s
    return (((ox - 1) * 7 + oy - 1) * 2 + int(wait)) * 64 + (rx - 1) * 8 + ry - 1


def load_candidate(repo, variant, source):
    cfg = CASES[variant]
    graph_path = repo / BASE / 'published_update/independent_source' / f'run_{variant}/data/SOURCE_GAME.jsonl.gz'
    result_path = graph_path.with_name('SOURCE_RESULT.json')
    pins = {'source': pin(source), 'graph': pin(graph_path), 'candidate_result': pin(result_path)}
    for field, expected in [('source', cfg['source_sha256']), ('graph', cfg['graph_sha256']),
                            ('candidate_result', cfg['result_sha256'])]:
        require(pins[field]['sha256'] == expected, f'INPUT_HASH_MISMATCH:{field}')
    raw_result = json.loads(result_path.read_text())
    raw_ids = raw_result['winning_ids']
    require(all(strict_int(i) and 0 <= i < 6272 for i in raw_ids), 'INVALID_CANDIDATE_ID')
    require(len(raw_ids) == len(set(raw_ids)) == cfg['candidate_count'], 'CANDIDATE_COUNT_OR_DUPLICATE')
    region = frozenset(raw_ids)
    states, blocks = {}, {}
    with gzip.open(graph_path, 'rt', encoding='utf-8') as stream:
        for line in stream:
            row = json.loads(line)
            item = row['state']
            sid = item['state_id']
            state = (item['obstacle[0]'], item['obstacle[1]'], item['obsWait'],
                     item['robot[0]'], item['robot[1]'])
            require(strict_int(sid) and typed_state(state) and encode_state(state) == sid,
                    'GRAPH_ID_OR_STATE_MISMATCH')
            require(sid not in states, 'DUPLICATE_GRAPH_STATE')
            states[sid] = state
            parsed = []
            inputs_seen = set()
            for block in row['blocks']:
                env = tuple(block['next_env'])
                require(len(env) == 3 and strict_int(env[0]) and strict_int(env[1])
                        and type(env[2]) is bool and 1 <= env[0] <= 7 and 1 <= env[1] <= 7,
                        'GRAPH_ENV_NOT_TYPED')
                require(env not in inputs_seen, 'DUPLICATE_GRAPH_ENV_BLOCK')
                inputs_seen.add(env)
                successors = block['safe_successor_ids']
                require(all(strict_int(i) and 0 <= i < 6272 for i in successors), 'GRAPH_BAD_SUCCESSOR')
                require(len(successors) == len(set(successors)), 'GRAPH_DUPLICATE_SUCCESSOR')
                parsed.append((env, tuple(successors)))
            blocks[sid] = tuple(sorted(parsed))
    require(set(states) == set(range(6272)), 'GRAPH_STATE_COVERAGE')
    for sid, entries in blocks.items():
        for env, successors in entries:
            require(all(states[nxt][:3] == env for nxt in successors), 'GRAPH_SUCCESSOR_ENV_MISMATCH')
    require(encode_state(cfg['initial']) in region, 'FIXED_QUERY_NOT_IN_CANDIDATE')
    return states, blocks, region, pins


def construct_rank(states, blocks, region, goal):
    # Synchronous reachability layers within the one frozen candidate region.
    # The source truth/coverage of recorded blocks is checked only by the other program.
    targets = {sid for sid in region if states[sid][3:] == goal}
    require(bool(targets), 'CANDIDATE_HAS_NO_GOAL_STATE')
    for sid in sorted(targets):
        require(bool(blocks[sid]) and all(any(nxt in region for nxt in successors)
                                         for _, successors in blocks[sid]),
                f'GOAL_HAS_NO_RECORDED_SAFE_REGION_RESPONSE:{sid}')
    ranks = {sid: 0 for sid in targets}
    depth = 0
    while len(ranks) < len(region):
        new_layer = []
        for sid in sorted(region - ranks.keys()):
            if blocks[sid] and all(any(nxt in ranks for nxt in successors)
                                   for _, successors in blocks[sid]):
                new_layer.append(sid)
        require(bool(new_layer), f'CANDIDATE_NOT_FULLY_RANKED:{len(ranks)}/{len(region)}')
        depth += 1
        require(depth <= 6271, 'RANK_BOUND_EXCEEDED')
        for sid in new_layer:
            ranks[sid] = depth
    return ranks


def generate(repo, variant, source):
    cfg = CASES[variant]
    states, blocks, region, pins = load_candidate(repo, variant, source)
    ranks = [construct_rank(states, blocks, region, goal) for goal in cfg['goals']]
    rows = []
    witness_count = [0, 0]
    for sid in sorted(region):
        policy = []
        for phase in (0, 1):
            at_goal = states[sid][3:] == cfg['goals'][phase]
            phase_policy = []
            for env, successors in blocks[sid]:
                choices = [nxt for nxt in successors if nxt in region
                           and (at_goal or ranks[phase][nxt] < ranks[phase][sid])]
                require(bool(choices), f'NO_RANK_COMPATIBLE_RESPONSE:{sid}:{phase}:{env}')
                chosen = min(choices, key=lambda nxt: states[nxt][3:])
                phase_policy.append({'env': list(env), 'sys': list(states[chosen][3:]),
                                     'next_phase': 1 - phase if at_goal else phase})
            witness_count[phase] += len(phase_policy)
            policy.append(phase_policy)
        rows.append({'state': list(states[sid]), 'rank': [ranks[0][sid], ranks[1][sid]],
                     'policy': policy})
    cert = {
        'schema': 'v71-obstacle-source-winning-certificate-v1',
        'case_id': cfg['case_id'], 'source_path': str(FRONT / cfg['source_name']),
        'source_sha256': cfg['source_sha256'],
        'query': {'kind': 'source_initial', 'env': list(cfg['initial'][:3]),
                  'sys': list(cfg['initial'][3:])},
        'initial': {'state': list(cfg['initial']), 'phase': 0},
        'completion': {
            'after_env_violation': 'sys_1_1_phase_0_forever',
            'invalid_env_initial': 'sys_1_1_phase_0_forever',
            'unreachable_history': 'sys_1_1_phase_0_forever'},
        'states': rows,
        'provenance': {
            'generator': pin(Path(__file__)), 'input_pins': pins,
            'candidate_source': 'Fixed saved winning_ids, not trusted by independent checker',
            'region_states': len(region), 'rank_maxima': [max(r.values()) for r in ranks],
            'witnesses_per_phase': witness_count,
            'algorithm': 'Synchronous per-goal attractor ranks within fixed R; lexicographic SYS witness',
            'shared_evaluator_solver_predecessor_imports': False,
            'correctness_requires_separate_direct_source_checker': True,
        },
    }
    return cert


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--variant', choices=('old', 'new'), required=True)
    parser.add_argument('--repo-root', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True, help='Byte-identical source override, exact hash checked')
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    receipt = {'schema': 'v71-obstacle-certificate-generation-result-v1',
               'case_id': CASES[args.variant]['case_id'], 'variant': args.variant,
               'created_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
               'generator': pin(Path(__file__)), 'new_scientific_candidate_attempts': 1}
    try:
        cert = generate(args.repo_root.resolve(), args.variant, args.source.resolve())
        encoded = (json.dumps(cert, ensure_ascii=False, separators=(',', ':')) + '\n').encode()
        require(len(encoded) <= 67108864, 'CERTIFICATE_FILE_CAP')
        certificate_path = args.output_dir / 'CERTIFICATE.json'
        certificate_path.write_bytes(encoded)
        receipt.update(status='CANDIDATE_GENERATED_NOT_YET_INDEPENDENTLY_VERIFIED',
                       certificate=pin(certificate_path),
                       region_states=cert['provenance']['region_states'],
                       rank_maxima=cert['provenance']['rank_maxima'],
                       witnesses_per_phase=cert['provenance']['witnesses_per_phase'])
        code = 0
    except Exception as exc:
        receipt.update(status='CANDIDATE_NOT_CERTIFIED', error_type=type(exc).__name__, error=str(exc))
        code = 1
    receipt['elapsed_seconds'] = time.monotonic() - started
    (args.output_dir / 'GENERATION_RESULT.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({k: receipt[k] for k in ('case_id', 'status', 'elapsed_seconds')}))
    return code


if __name__ == '__main__':
    sys.exit(main())
