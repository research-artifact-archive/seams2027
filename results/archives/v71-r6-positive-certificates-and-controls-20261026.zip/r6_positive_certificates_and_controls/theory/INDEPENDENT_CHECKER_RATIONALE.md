# Independent positive certificate checker

Preparation status: code and rationale prepared before root GO. Static syntax
checking is permitted during preparation. Running the checker, totality mode,
or qualification suite against actual certificates is deferred until root GO.
No result is asserted by this document.

## Independence boundary

`check_certificate.py` imports Python standard-library modules only. It reads
the exact original A and retained B source files, checks their length and
SHA-256, and uses predicates transcribed directly from those source equations.
It does not load old `independent_source/source_eval.py`, any producer module,
any fixed-point or predecessor routine, a saved graph, or candidate-W truth.
Certificate provenance is an informational object, never a proof premise.

The only supported sources are:

| Case | Original file | Bytes | SHA-256 |
| --- | --- | ---: | --- |
| A_OLD_PUBLIC_INITIAL | `research_strategy_after_r3/resumed_2333/frontend_workspace/FixedObstacleR4/MovingObstacleEvasion.spectra` | 2097 | `19c71d970b05fec41f0fa60fce155bf136b33836ffd785a65c2c436a712c3ac1` |
| B_NEW_POINT_R2404 | `research_strategy_after_r3/resumed_2333/frontend_workspace/FixedObstacleR4/MovingObstacleEvasionUpdate_retained_r2404.spectra` | 2026 | `212309df489c3ddc7bf7ec6a750aed2d0da4fb7e26995e5ee3a0405c9897e1d5` |

Paths in the table are relative to `experiment/v71_acceptance_cycle_20261025`.
The checker pins their full repository-relative paths. B is the exact retained
point query with its appended initializer, not a general initial-state result
for the separately published unmodified new specification.

## Source equations and types

A state is `(ox, oy, wait, rx, ry)`. The two obstacle coordinates range over
1..7, `wait` is Boolean, and the two robot coordinates range over 1..8. This
gives 98 typed ENV valuations and 64 typed SYS valuations, or 6272 states.
JSON booleans are explicitly rejected where an integer is required; a numeric
0 or 1 is explicitly rejected where a Boolean is required.

For state s and next environment e', the independent E(s,e') predicate is the
conjunction of these original assumptions, shared by A and B:

1. `obsWaitSwitches`: next wait is the complement of current wait.
2. `obstacleDoesNotMoveWhenObsWait`: if current wait is true, both obstacle
   coordinates stay unchanged.
3. `obstacleMovesAtMostOne`: each coordinate changes by -1, 0, or +1.
4. `obstacleIsSmart`: when current wait is false, each coordinate above the
   corresponding robot coordinate must decrease by 1, and each coordinate
   below robot coordinate minus 1 must increase by 1. These are four separate
   implications, exactly as written in the source.

The source's four collision clauses exclude the robot from the obstacle's
2-by-2 square with corners `(ox,oy)` and `(ox+1,oy+1)`. Current-state safety
checks `robotNotOnObstacle` and both `AvoidInfinitely` declarations. They forbid
robot points (3,5)/(4,5) for A and (6,4)/(8,7) for B. Despite their names, the
two `AvoidInfinitely` clauses are `G` safety guarantees, not liveness clauses.

Transition safety checks `robotMovesAtMostOne` on **next robot**, and
`robotAvoidsObstacle` on **current robot against next obstacle**. The latter is
not next robot against next obstacle. A successor's membership in safe R also
checks its own current-state safety, including next robot against next
obstacle. Thus both distinct safety obligations are preserved.

The two goals follow their authored source order: A has (5,2) then (2,3); B has
(3,7) then (4,8). No ENV justice assumptions occur in either pinned source.

The checker uses the intended Spectra initial and global declaration semantics:
unqualified retained boundary declarations are initial constraints, while the
temporal assumptions and guarantees above constrain every applicable step.
This is a source-equation proof checker, not an independently implemented
Spectra compiler or a validation of every possible frontend interpretation.

## Frozen JSON schema

Top-level keys are exactly:

```text
schema = "v71-obstacle-source-winning-certificate-v1"
case_id = "A_OLD_PUBLIC_INITIAL" | "B_NEW_POINT_R2404"
source_path = exact pinned repository-relative source path
source_sha256 = exact pinned source SHA-256
query = {kind:"source_initial", env:[ox,oy,wait], sys:[rx,ry]}
initial = {state:[ox,oy,wait,rx,ry], phase:0}
completion = {
  after_env_violation:"sys_1_1_phase_0_forever",
  invalid_env_initial:"sys_1_1_phase_0_forever",
  unreachable_history:"sys_1_1_phase_0_forever"
}
states = [{
  state:[ox,oy,wait,rx,ry],
  rank:[integer_in_0_to_6271, integer_in_0_to_6271],
  policy:[
    [{env:[oxNext,oyNext,waitNext],sys:[rxNext,ryNext],next_phase:0|1},...],
    [{env:[oxNext,oyNext,waitNext],sys:[rxNext,ryNext],next_phase:0|1},...]
  ]
},...]
provenance = arbitrary informational object
```

Duplicate JSON keys, duplicate states, duplicate ENV witnesses, extra schema
fields, and non-finite JSON numbers are rejected. R must be nonempty and
contain at most 6272 distinct typed states. State IDs and saved graph indices
are not accepted as substitutes for explicit typed tuples.

For each s in R and q in {0,1}, the checker independently enumerates all 98
typed ENV inputs and keeps exactly those satisfying E(s,e'). The policy's key
set must equal that entire legal-input set. The set is also required to be
nonempty for every state in R. There must be exactly one typed SYS witness for
each such input; the witness must satisfy the original transition safety and
lead to a state in R. A fixed chosen witness for every universally quantified
legal input defines a deterministic reactive strategy.

For phase q, rank_q(s) is an integer in 0..6271, and rank_q(s)=0 iff s is in
goal Gq. The upper bound enforces the frozen construction/schema size bound;
the well-foundedness proof itself only needs nonnegative finite integers.
If s is outside Gq, the selected edge must preserve phase q and strictly
decrease rank_q. If s is in Gq, the selected edge must switch to phase 1-q and
remain safely in R. No descent is demanded across a goal-triggered phase
switch.

## Positive winning argument

Inductively, every play following the policy under legal ENV moves remains in
safe R. In any phase q, an infinite suffix that avoids Gq would induce an
infinite strictly decreasing sequence of nonnegative integers. That is
impossible, so Gq is reached after finitely many steps. On the next step the
phase alternates. The argument repeats forever, establishing infinitely many
visits to both authored justice goals. The strategy uses one bit of phase
memory plus the ENV-violation latch described below.

The check additionally enumerates all 98 possible initial ENV assignments.
For every assignment satisfying the exact source ENV initializer, it
enumerates all 64 SYS assignments and requires a source-initial SYS witness in
R. A has exactly ENV (7,7,false) and SYS (1,1); retained B has exactly ENV
(3,5,true) and SYS (5,5). Each source therefore has one admissible initial pair,
which the certificate must include with phase 0. The CLI's requested case,
certificate case, query, explicit initial tuple, and exact source hash must
all agree. A certificate cannot silently answer another query.

This proves only positive existence for the pinned source query, and for
states in the checked R with their indicated phase strategy. It proves no
maximality, no exclusion of states outside R, no negative-query result, no
public-API cause, and no resolution of the old eight UNKNOWN results.

## Total completion and separate ENV-totality bridge

For an invalid ENV initializer, or after the first ENV safety violation,
the strategy latches a violation flag and forever returns typed SYS (1,1),
phase 0. It does not resume the certificate if ENV later becomes legal.
For otherwise unreachable histories it uses the same specified fallback.
Before any ENV violation, the checked R policy satisfies all source duties.
After a violation, the original strict duties are vacuous under the frozen
strict semantics, while outputs remain typed. This extends the exhibited
strategy to all typed histories without discarding any earlier obligation.

The separate `--env-totality-only` mode binds **both** exact source hashes and
enumerates all 6272 typed states, including states outside R and states that
could be reached by the fallback. For each state it independently enumerates
all 98 next ENV tuples and requires at least one legal successor under the
shared original ENV equations. Its receipt is `ACCEPT_SOURCE_ENV_TOTALITY_ONLY`.
It is not incorporated into the strict winning proof result.

That stage also binds the three published/projection source files and checks
their actual bytes: A equals published old; the 1947-byte published new equals
the 1902-byte ordinary projection plus the exact 45-byte `switch robotLoc`
suffix; retained B equals that projection plus the exact 124-byte retained
ENV/SYS initializer. These are explicit byte identities, not a deployed
handoff or dynamic-update correctness claim. All five source files can be
passed as explicit exact-hash bytecopies, without the original workspace.

Combined adoption as a new source-kind certificate requires both the exact
query's `ACCEPT_POSITIVE_EXISTENCE` receipt and the separate successful full
ENV-totality receipt bound to both sources. If either stage is unfinished,
timed out, resource-limited, or rejected, combined adoption is unestablished.
A passing strict certificate alone remains a strict positive result. This is
a source-specific bridge and does not claim K=Kind in general, change an
existing bridge, or certify the separate old seven-edge/history claim.

## Execution and failure policy

Each checker process has a 180-second wall budget, a matching CPU cap, a hard
64-MiB single-output-file cap, and disabled core dumps. Limit installation
failure is an error with no conclusion. The required external owned-process
supervisor samples the complete process tree against the 1-GiB RSS limit and
enforces the stage/total output bounds. Its separate successful receipt is
required for protocol compliance; standalone checker acceptance does not
establish RSS compliance. Virtual address space is not used as a proxy for RSS.
Certificate input size is bounded at 64 MiB. The qualification driver also has
a combined 300-second wall deadline and monitors its own and its active child
RSS against 1 GiB; the protocol supervisor remains authoritative for the
complete tree. The optional address-space cap in the initial prepared version
was removed by root's preexecution design decision, before any science attempt.
All outputs use exclusive creation: earlier evidence files are not replaced.
Qualification fixes 25 deterministic rejection cases per certificate before
generation, including an explicit stuck phase at a goal, and first runs one
unmodified positive control per case within that qualification stage. Each
actual mutated input is retained as a verified lossless gzip archive, with its
uncompressed SHA-256, rather than accumulating large JSON copies.
The third preexecution freeze adds the explicit oversized-rank rejection case
to the preserved 24-case roster and lowers the local FSIZE limit to match the
supervisor's inherited 64-MiB hard limit; the 128-MiB stage aggregate output
cap remains enforced separately by that supervisor.

CLI examples (only after root GO):

```bash
python3 check_certificate.py --repo-root /absolute/repository --case A_OLD_PUBLIC_INITIAL --certificate /absolute/A.json --output /new/path/A.receipt.json
python3 check_certificate.py --repo-root /absolute/repository --case B_NEW_POINT_R2404 --certificate /absolute/B.json --output /new/path/B.receipt.json
python3 check_certificate.py --repo-root /absolute/repository --case A_OLD_PUBLIC_INITIAL --env-totality-only --output /new/path/shared_env_totality.receipt.json
python3 qualify_rejections.py --repo-root /absolute/repository --a /absolute/A.json --b /absolute/B.json --output-dir /new/path/qualification
```

Portable explicit-bytecopy equivalents:

```bash
python3 check_certificate.py --case A_OLD_PUBLIC_INITIAL --source /bundle/A_OLD_PUBLIC_INITIAL.spectra --certificate /bundle/A.json --output /new/path/A.receipt.json
python3 check_certificate.py --case B_NEW_POINT_R2404 --source /bundle/B_NEW_POINT_R2404.spectra --certificate /bundle/B.json --output /new/path/B.receipt.json
python3 check_certificate.py --case A_OLD_PUBLIC_INITIAL --env-totality-only --source-a /bundle/A_OLD_PUBLIC_INITIAL.spectra --source-b /bundle/B_NEW_POINT_R2404.spectra --published-old /bundle/published_old.spectra --published-new /bundle/published_new.spectra --ordinary-projection /bundle/updated_ordinary_projection.spectra --output /new/path/shared_env_totality.receipt.json
python3 qualify_rejections.py --source-a /bundle/A_OLD_PUBLIC_INITIAL.spectra --source-b /bundle/B_NEW_POINT_R2404.spectra --a /bundle/A.json --b /bundle/B.json --output-dir /new/path/qualification
```

Only byte locations change in this mode. Certificate provenance paths and all
source hashes remain exact pins; no source parser, source rewriting, or source
equivalence shortcut is used.

A rejection concerns the supplied certificate, not realizability of the
source. Timeout, parser failure, infrastructure failure, and memory failure
make no scientific conclusion. Receipts bind checker SHA-256 and input
certificate SHA-256, record the requested case, and report scope explicitly.
