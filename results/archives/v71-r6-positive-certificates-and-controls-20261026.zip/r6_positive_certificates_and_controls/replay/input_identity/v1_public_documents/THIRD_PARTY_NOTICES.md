# Third-party boundary

The original artifact license covers original code, documentation and research
outputs. It does not grant rights to third-party specifications, software or
papers.

The Obstacle specification pair comes from the official dynamic-update examples
archive identified in SOURCE_RESTORATION.json. Inspection of that archive found
no license, readme or notice member. Accordingly, this public payload excludes
all upstream `.spectra` and `.spectraArxived` bodies. Five exact input copies are
retained privately; their public identities and transformations are specified by
hash. Obtain those inputs independently under the distributor's terms. The only
included standalone source fragment is the original124-byte retained-point
appendix authored for this study. The frozen checker also embeds the45-byte
expected switch suffix as a byte-comparison constant; this is not the full
third-party specification body.

No Eclipse/Spectra JAR, compiled class, native runtime, publisher PDF or distributor
ZIP is shipped. Runtime hashes and saved diagnostic disassembly identify the
observed configuration; they are not a runtime distribution or proof of identical
live intermediate game objects. Screenshots containing upstream source are
withheld. No image was edited to remove its source text.

The exact official source archive location is recorded as provenance, not fetched
by this package or by its integrity verifier. Neither source restoration nor a
scientific replay occurred during preparation of this payload.
