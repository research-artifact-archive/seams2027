#!/usr/bin/env python3
"""Private exact-plan adapter; preparation does not authorize execution.

The unchanged supervisor launches [python, this_absolute_script, ...].
This adapter checks the pinned plan and inputs, then replaces itself with
the same Python and -I -S -B. PID, PGID and inherited limits survive exec.
No scientific module is imported by this adapter.
"""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import sys


def checked_bytes(record):
    path = Path(record['path'])
    if not path.is_absolute() or path.is_symlink() or not path.is_file():
        raise RuntimeError('PIN_PATH_NOT_ABSOLUTE_REGULAR_FILE: ' + str(path))
    raw = path.read_bytes()
    if len(raw) != record['bytes'] or hashlib.sha256(raw).hexdigest() != record['sha256']:
        raise RuntimeError('PIN_MISMATCH: ' + str(path))
    return raw


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--plan-sha256', required=True)
    parser.add_argument('--stage', required=True)
    args = parser.parse_args()
    raw = args.plan.read_bytes()
    if not args.plan.is_absolute() or hashlib.sha256(raw).hexdigest() != args.plan_sha256:
        raise RuntimeError('PLAN_PATH_OR_HASH_MISMATCH')
    plan = json.loads(raw)
    go = json.loads(checked_bytes(plan['active_root_go']))
    if go['status'] != 'GO_PROTOCOL_WITH_CODE_FREEZE_AND_PREFLIGHT_GATES':
        raise RuntimeError('ACTIVE_ROOT_GO_STATUS_MISMATCH')
    if dt.datetime.now(dt.timezone.utc) >= dt.datetime.fromisoformat(go['expires_utc']):
        raise RuntimeError('ROOT_GO_DEADLINE_EXPIRED')
    for record in plan['common_pins'].values():
        checked_bytes(record)
    for record in plan['restored_input_pins']:
        checked_bytes(record)
    restoration = json.loads(Path(plan['restoration_receipt']).read_bytes())
    if (restoration['status'] != 'PASS_FIVE_PRIVATE_INPUTS_RESTORED_EXACTLY'
            or restoration['plan_sha256'] != args.plan_sha256
            or restoration['restored_files'] != plan['restored_input_pins']):
        raise RuntimeError('RESTORATION_RECEIPT_MISMATCH')
    stage = next(item for item in plan['stages'] if item['stage'] == args.stage)
    for required in stage['required_prior_results']:
        previous = json.loads(Path(required['path']).read_bytes())
        if any(previous.get(key) != value for key, value in required['fields'].items()):
            raise RuntimeError('PRIOR_STAGE_GATE_MISMATCH: ' + required['path'])
    if Path(sys.executable).resolve() != Path(plan['common_pins']['python']['path']):
        raise RuntimeError('WRAPPER_RUNTIME_MISMATCH')
    if Path(__file__).resolve() != Path(plan['common_pins']['wrapper']['path']):
        raise RuntimeError('WRAPPER_PATH_MISMATCH')
    if Path.cwd() != Path(plan['cwd']):
        raise RuntimeError('CWD_MISMATCH')
    if os.getpgrp() != os.getpid():
        raise RuntimeError('REQUIRE_SUPERVISOR_OWNED_PROCESS_GROUP')
    preflight = json.loads((Path(stage['run_dir']) / 'PREFLIGHT.json').read_bytes())
    if preflight['stage'] != args.stage or preflight['root_go'] != plan['active_root_go']:
        raise RuntimeError('SUPERVISOR_PREFLIGHT_MISMATCH')
    if preflight['script'] != plan['common_pins']['wrapper']:
        raise RuntimeError('SUPERVISOR_WRAPPER_PIN_MISMATCH')
    argv = stage['scientific_argv']
    if argv[:4] != [plan['common_pins']['python']['path'], '-I', '-S', '-B']:
        raise RuntimeError('ISOLATED_ARGV_MISMATCH')
    if argv[4] != plan['common_pins'][stage['script_key']]['path']:
        raise RuntimeError('SCIENTIFIC_SCRIPT_PATH_MISMATCH')
    environment = dict(os.environ)
    for key in list(environment):
        if key.startswith('PYTHON'):
            del environment[key]
    environment.update(plan['environment_overrides'])
    print(json.dumps({'wrapper_preflight': 'PASS_BEFORE_EXEC', 'stage': args.stage,
                      'plan_sha256': args.plan_sha256, 'command': argv,
                      'meaning': 'Exec intent only; inspect scientific receipt for result.'}),
          flush=True)
    os.execve(argv[0], argv, environment)


if __name__ == '__main__':
    main()
