#!/usr/bin/env python3
"""One private restoration attempt, only after root activates the exact GO.

Reads the already-local pinned ZIP; never fetches or extracts arbitrary paths.
Preparation only creates this program, not any restored source or run root.
"""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import resource
import signal
import sys
import zipfile


def verify(raw, record, label):
    if len(raw) != record['bytes'] or hashlib.sha256(raw).hexdigest() != record['sha256']:
        raise RuntimeError('PIN_MISMATCH: ' + label)


def checked_bytes(record):
    path = Path(record['path'])
    if not path.is_absolute() or path.is_symlink() or not path.is_file():
        raise RuntimeError('PIN_PATH_NOT_ABSOLUTE_REGULAR_FILE: ' + str(path))
    raw = path.read_bytes()
    verify(raw, record, str(path))
    return raw


def write_json_exclusive(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def timeout(_signal, _frame):
    raise TimeoutError('RESTORATION_WALL_CAP')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--plan-sha256', required=True)
    args = parser.parse_args()
    raw = args.plan.read_bytes()
    if not args.plan.is_absolute() or hashlib.sha256(raw).hexdigest() != args.plan_sha256:
        raise RuntimeError('PLAN_PATH_OR_HASH_MISMATCH')
    plan = json.loads(raw)
    go = json.loads(checked_bytes(plan['active_root_go']))
    if go['status'] != 'GO_PROTOCOL_WITH_CODE_FREEZE_AND_PREFLIGHT_GATES':
        raise RuntimeError('ACTIVE_ROOT_GO_STATUS_MISMATCH')
    if dt.datetime.now(dt.timezone.utc) >= dt.datetime.fromisoformat(go['expires_utc']):
        raise RuntimeError('ROOT_GO_DEADLINE_EXPIRED')
    if Path(sys.executable).resolve() != Path(plan['common_pins']['python']['path']):
        raise RuntimeError('RESTORATION_RUNTIME_MISMATCH')
    if Path(__file__).resolve() != Path(plan['common_pins']['restorer']['path']):
        raise RuntimeError('RESTORER_PATH_MISMATCH')
    for record in plan['common_pins'].values():
        checked_bytes(record)
    directory = Path(plan['restoration_directory'])
    if directory.exists():
        raise RuntimeError('RESTORATION_DIRECTORY_ALREADY_EXISTS')
    # Exclusive reservation persists on any failure; no retries or deletion.
    write_json_exclusive(Path(plan['restoration_reservation']), {
        'status': 'RESERVED_ONE_RESTORATION_ATTEMPT', 'created_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'plan_sha256': args.plan_sha256, 'root_go': plan['active_root_go']})
    receipt = {'status': 'INCOMPLETE_RESTORATION', 'plan_sha256': args.plan_sha256,
               'restored_files': [], 'scientific_executions': 0, 'network_calls': 0,
               'full_reset': 0}
    try:
        resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
        resource.setrlimit(resource.RLIMIT_FSIZE, (1048576, 1048576))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        signal.signal(signal.SIGALRM, timeout)
        signal.setitimer(signal.ITIMER_REAL, 30)
        recipe = json.loads(checked_bytes(plan['common_pins']['source_recipe']))
        with zipfile.ZipFile(plan['common_pins']['source_archive']['path']) as archive:
            if archive.testzip() is not None:
                raise RuntimeError('SOURCE_ARCHIVE_CRC_FAILURE')
            old, new = [archive.read(member['member']) for member in recipe['members']]
        for raw_member, member in zip((old, new), recipe['members']):
            verify(raw_member, member, member['member'])
        update = recipe['members'][1]
        if update['removed_start'] != 1902 or update['removed_end'] != 1947:
            raise RuntimeError('UNEXPECTED_PROJECTION_OFFSETS')
        suffix = new[1902:1947]
        if len(suffix) != 45 or hashlib.sha256(suffix).hexdigest() != update['removed_sha256']:
            raise RuntimeError('REMOVED_SUFFIX_PIN_MISMATCH')
        projection = new[:1902]
        verify(projection, {'bytes': update['projected_bytes'],
                            'sha256': update['projected_sha256']}, 'ordinary projection')
        appendix = checked_bytes(plan['common_pins']['retained_point_appendix'])
        bodies = {'A_OLD_PUBLIC_INITIAL.spectra': old,
                  'B_NEW_POINT_R2404.spectra': projection + appendix,
                  'published_old.spectra': old, 'published_new.spectra': new,
                  'updated_ordinary_projection.spectra': projection}
        for record in plan['restored_input_pins']:
            verify(bodies[Path(record['path']).name], record, record['path'])
        if sum(map(len, bodies.values())) != 10069:
            raise RuntimeError('RESTORATION_TOTAL_SIZE_MISMATCH')
        if dt.datetime.now(dt.timezone.utc) >= dt.datetime.fromisoformat(go['expires_utc']):
            raise RuntimeError('ROOT_GO_DEADLINE_EXPIRED_BEFORE_WRITE')
        directory.mkdir(mode=0o700, exist_ok=False)
        for record in plan['restored_input_pins']:
            path = Path(record['path'])
            if path.parent != directory:
                raise RuntimeError('RESTORED_PATH_OUTSIDE_PRIVATE_DIRECTORY')
            with path.open('xb') as stream:
                stream.write(bodies[path.name])
            path.chmod(0o400)
            checked_bytes(record)
            receipt['restored_files'].append(record)
        receipt['status'] = 'PASS_FIVE_PRIVATE_INPUTS_RESTORED_EXACTLY'
    except BaseException as exc:
        receipt['failure'] = {'type': type(exc).__name__, 'detail': str(exc)}
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        receipt['finished_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
        write_json_exclusive(Path(plan['restoration_receipt']), receipt)
    print(json.dumps(receipt, ensure_ascii=False))
    return 0 if receipt['status'] == 'PASS_FIVE_PRIVATE_INPUTS_RESTORED_EXACTLY' else 1


if __name__ == '__main__':
    raise SystemExit(main())
