#!/usr/bin/env python3
"""Static evidence integrity only. Never imports or executes scientific code."""
from pathlib import Path, PurePosixPath
import ast
import base64
import gzip
import hashlib
import json
import re
import sys

ROOT = Path(__file__).resolve().parent
CODE_PINS = {
    'checkers/check_certificate.py': '9618f0cbbe7dafb92f963e200f2304f802629aef248f563de0e039eda23ce28d',
    'checkers/qualify_rejections.py': '4ff6c3beb4e04050e87b0c401ae6bf6fc90a6bfcd0bb7b4a10ffad8c7f5be4cf',
    'inspection/generate_certificate.py': '1458d4cb890682d479a78d7a7c36f5a96b5a50738eb935b38f74f7eeb7f54eeb',
    'inspection/bounded_python_stage.py': 'e4caa2d8af9ef8895e631ffbf6743c2d92e7822cb9ee3ee46ba23255ecc5f2b4',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(relative):
    return json.loads((ROOT / relative).read_text())


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def safe_relative(name):
    value = PurePosixPath(name)
    return bool(name) and not value.is_absolute() and '..' not in value.parts and '\\' not in name


def private_markers(raw):
    text = raw.decode('utf-8', errors='replace')
    markers = [('/' + 'Users' + '/'), ('/' + 'home' + '/'), ('/' + 'private' + '/var/')]
    hits = ['private_home_path' for value in markers if value in text]
    if re.search(r'\b01a[0-9a-f]{5}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b', text):
        hits.append('private_chat_identifier_pattern')
    credential = re.compile(r'(?i)(?:api[_-]?key|access[_-]?token|password|secret)\s*[:=]\s*[\"\x27]?[A-Za-z0-9_\-]{20,}')
    if credential.search(text):
        hits.append('credential_assignment_pattern')
    return hits


def maybe_base64_strings(raw):
    # Inspect structured diagnostic Base64 values, not arbitrary source identifiers.
    try:
        value = json.loads(raw)
    except (ValueError, UnicodeDecodeError):
        return []
    found = []
    def visit(item):
        if isinstance(item, dict):
            for key, val in item.items():
                if isinstance(val, str) and ('base64' in key.lower() or key.lower().endswith('_b64')):
                    try:
                        found.append(base64.b64decode(val, validate=True))
                    except ValueError:
                        pass
                visit(val)
        elif isinstance(item, list):
            for val in item:
                visit(val)
    visit(value)
    return found


def main():
    manifest = load('MANIFEST.json')
    require(manifest['scope'] == 'STATIC_PUBLIC_PAYLOAD_ONLY_NO_SCIENTIFIC_REPLAY', 'manifest scope')
    roster = manifest['files']
    paths = [row['path'] for row in roster]
    require(len(paths) == len(set(paths)) == len(set(p.casefold() for p in paths)), 'duplicate/case-colliding path')
    require(all(safe_relative(p) and p != 'MANIFEST.json' for p in paths), 'unsafe manifest path')
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()}
    require(actual == set(paths) | {'MANIFEST.json'}, 'unlisted or missing file')
    require(not any(p.is_symlink() for p in ROOT.rglob('*')), 'symlink in payload')
    gzip_count = 0
    syntax_count = 0
    decoded_chunks = 0
    for row in roster:
        path = ROOT / row['path']
        raw = path.read_bytes()
        require(len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'file pin mismatch: ' + row['path'])
        require(path.suffix not in ('.spectra', '.spectraArxived', '.png', '.jpg', '.jpeg', '.jar', '.class', '.dylib', '.so'), 'excluded upstream/UI/runtime file')
        content = raw
        if path.suffix == '.gz':
            content = gzip.decompress(raw)
            gzip_count += 1
        require(not private_markers(content), 'private marker: ' + row['path'])
        for chunk in maybe_base64_strings(content):
            decoded_chunks += 1
            require(not private_markers(chunk), 'private Base64 diagnostic: ' + row['path'])
        if path.suffix == '.py':
            ast.parse(content, filename=row['path'])
            syntax_count += 1
    require(gzip_count == 50, 'expected exactly50 retained malformed gzip files')
    for path, expected in CODE_PINS.items():
        require(sha((ROOT / path).read_bytes()) == expected, 'frozen code changed: ' + path)

    ledger = load('TRANSFORMATION_LEDGER.json')
    by_public = {}
    for row in ledger['files']:
        relative = row['public_path']
        require(relative not in by_public, 'duplicate ledger path')
        by_public[relative] = row
        raw = (ROOT / relative).read_bytes()
        require(len(raw) == row['public']['bytes'] and sha(raw) == row['public']['sha256'], 'ledger public mismatch')
        if row['byte_identical']:
            require(row['original'] == row['public'], 'claimed byte identity disagrees')
        if relative.endswith('.gz'):
            require(sha(gzip.decompress(raw)) == row['public_uncompressed_sha256'], 'gzip derivative mismatch')
        if row.get('all_non_provenance_JSON_pairs_unchanged'):
            pairs = json.loads(gzip.decompress(raw) if relative.endswith('.gz') else raw,
                               object_pairs_hook=lambda entries: entries)
            body = [(k, v) for k, v in pairs if k != 'provenance']
            body_hash = sha(json.dumps(body, ensure_ascii=False, separators=(',', ':')).encode())
            require(body_hash == row['non_provenance_canonical_sha256'], 'certificate-data digest mismatch')

    # These are cross-checks of recorded execution metadata, not new scientific checks.
    qmap = load('PUBLIC_QUALIFICATION_INPUT_MAP.json')
    require(len(qmap['cases']) == 50, 'qualification map count')
    direct_hash = 0
    null_hash = 0
    for case in qmap['cases']:
        raw = (ROOT / case['public_archive']).read_bytes()
        require(sha(raw) == case['public_compressed_sha256'], 'qualification public archive pin')
        require(sha(gzip.decompress(raw)) == case['public_uncompressed_sha256'], 'qualification public uncompressed pin')
        receipt = load(case['public_receipt'])
        require(receipt['verdict'] == 'REJECT' and receipt['code'] == case['expected_code'], 'recorded rejection code')
        require(case['recorded_observed_code'] == case['expected_code'], 'summary observed/expected mismatch')
        if case['name'] == 'duplicate_json_key':
            require(receipt['certificate_sha256'] is None, 'duplicate-key receipt hash should be null')
            null_hash += 1
        else:
            require(receipt['certificate_sha256'] == case['original_uncompressed_sha256'], 'original executed input hash mismatch')
            direct_hash += 1
    require((direct_hash, null_hash) == (48, 2), 'qualification input hash coverage')
    for label in ('A', 'B'):
        new = load(f'c2/{label}/RESULT.json')
        require(new['status'] == 'COMPLETED_TRUE' and new['actual_result'] is True and new['public_action_count'] == 1, 'recorded ordinary result')
        xmls = list((ROOT / f'c2/{label}/logger').glob('*.spectraXML'))
        require(len(xmls) == 2, 'ordinary logger count')
        combined = ''.join(p.read_text() for p in xmls)
        require(combined.count('Start-tau.smlab.syntech.checkRealAction') == 1 and combined.count('Status-true') == 1, 'ordinary action/verdict logger')
        source_pins = load('c2/ARCHIVED_SOURCE_BINDING.json')['records']
        matches = [x for x in source_pins if x['case'] == label]
        require(len(matches) == 2 and all(x['sha256'] == new['source']['sha256'] for x in matches), 'archived source binding')
    settings = (ROOT / 'c2/runtime/PREFS_ORDINARY_APPLIED.txt').read_text()
    require('synthesisMethod' not in settings and 'BDDEngine=JTLV' in settings and 'optChoice=none' in settings and 'reorderChoice=none' in settings, 'raw ordinary prefs caveat')
    runtime = load('c2/runtime/PREPARATION_BASELINE.json')
    require(runtime['target_jar_count'] == len(runtime['target_jars']) == 20, '20JAR record count')
    print(json.dumps({'status': 'PASS_STATIC_INTEGRITY_ONLY', 'files': len(paths) + 1,
                      'gzip_archives': gzip_count, 'python_syntax_only': syntax_count,
                      'decoded_diagnostic_chunks': decoded_chunks,
                      'recorded_qualification_direct_hashes': direct_hash,
                      'recorded_duplicate_key_null_hashes': null_hash,
                      'scientific_modules_imported': 0, 'scientific_replays': 0,
                      'GUI_actions': 0, 'source_restorations': 0,
                      'privacy_scope': 'Limited static patterns and declared diagnostic Base64, not complete anonymity proof.'}, indent=2))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(json.dumps({'status': 'FAIL_STATIC_INTEGRITY', 'type': type(exc).__name__, 'detail': str(exc)}))
        sys.exit(1)
