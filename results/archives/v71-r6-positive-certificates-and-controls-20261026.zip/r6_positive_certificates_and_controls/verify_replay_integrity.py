#!/usr/bin/env python3
"""Static replay-record bindings only; never import or run scientific programs."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
CHECKER = '9618f0cbbe7dafb92f963e200f2304f802629aef248f563de0e039eda23ce28d'
QUALIFIER = '4ff6c3beb4e04050e87b0c401ae6bf6fc90a6bfcd0bb7b4a10ffad8c7f5be4cf'
V1_MANIFEST = 'd1b3c296fa49a264061ed7f5e9dae99ecf4791a325edebbcaf45a999e06b1c4c'
V1_ZIP = 'e1359c08454430ff19c8af2a8322a426d089b8a1c0cd180a2c631f267782ac8b'
ORIGINAL_ADOPTION = 'bb5b092a59cd3d089ba2989a88613e56ed4cf4ff6fdc38e40187105155ffaff5'


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def path(relative):
    value = PurePosixPath(relative)
    require(bool(relative) and not value.is_absolute() and '..' not in value.parts
            and '\\' not in relative, 'unsafe relative path')
    result = ROOT / relative
    require(result.is_file() and not result.is_symlink(), 'missing or linked file: ' + relative)
    return result


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def pin(relative):
    raw = path(relative).read_bytes()
    return {'bytes': len(raw), 'sha256': sha(raw)}


def load(relative):
    return json.loads(path(relative).read_text())


def fields(record):
    return {key: record[key] for key in ('bytes', 'sha256')}


def option(argv, flag):
    require(argv.count(flag) == 1, 'missing or duplicate argument: ' + flag)
    index = argv.index(flag)
    require(index + 1 < len(argv), 'missing argument value')
    return argv[index + 1]


def main():
    ledger = load('replay/TRANSFORMATION_LEDGER.json')['files']
    by_public = {}
    for row in ledger:
        name = row['public_path']
        require(name not in by_public, 'duplicate replay ledger path')
        by_public[name] = row
        require(pin(name) == row['public'], 'replay derivative pin: ' + name)
        if row['byte_identical']:
            require(row['original'] == row['public'] and not row['changes'], 'false byte identity')
        require(all(change['kind'] == 'location_prefix' for change in row['changes']), 'unexpected transformation')
    require(by_public['replay/records/ROOT_PUBLIC_REPLAY_ADOPTION.json']['original']['sha256']
            == ORIGINAL_ADOPTION, 'original root adoption pin')
    require(load('replay/records/ROOT_PUBLIC_REPLAY_ADOPTION.json')['status']
            == 'ADOPT_SCOPED_SUCCESSFUL_EXISTING_HOST_PUBLIC_BYTES_REPLAY', 'replay adoption status')

    retained = load('replay/input_identity/V1_PAYLOAD_MAP.json')
    require(retained['v1_zip'] == {'name': 'v71-r6-positive-certificates-and-controls-20261026.zip',
            'bytes': 2347279, 'sha256': V1_ZIP}, 'replayed v1 ZIP identity')
    v1_rows = retained['v1_files']
    require(len(v1_rows) == 312, 'v1 payload count')
    by_v1 = {row['v1_path']: row for row in v1_rows}
    require(len(by_v1) == 312, 'duplicate v1 path')
    for row in v1_rows:
        require(pin(row['retained_path']) == fields(row), 'retained v1 byte mismatch')
    manifest_path = by_v1['MANIFEST.json']['retained_path']
    require(pin(manifest_path)['sha256'] == V1_MANIFEST, 'v1 manifest input pin')
    original_manifest = load(manifest_path)
    require({r['path'] for r in original_manifest['files']} == set(by_v1) - {'MANIFEST.json'}, 'v1 manifest roster')
    for row in original_manifest['files']:
        require(fields(row) == fields(by_v1[row['path']]), 'v1 manifest row pin')
    require(pin('checkers/check_certificate.py')['sha256'] == CHECKER, 'checker changed')
    require(pin('checkers/qualify_rejections.py')['sha256'] == QUALIFIER, 'qualifier changed')

    bindings = load('replay/INPUT_BINDINGS.json')
    plan = load('replay/records/REPLAY_PLAN.json')
    require(bindings['common_original_input_pins'] == plan['common_pins'], 'common input records disagree')
    common = plan['common_pins']
    for key, relative in [('checker', 'checkers/check_certificate.py'),
                          ('qualifier', 'checkers/qualify_rejections.py'),
                          ('certificate_A', 'certificates/A.json'),
                          ('certificate_B', 'certificates/B.json'),
                          ('retained_point_appendix', 'inputs/retained_point_appendix.txt'),
                          ('supervisor', 'inspection/bounded_python_stage.py'),
                          ('wrapper', 'replay/inspection/isolated_python_exec.py'),
                          ('restorer', 'replay/inspection/restore_private_inputs.py')]:
        require(fields(common[key]) == pin(relative), 'direct replay input pin: ' + key)
    require(common['manifest']['sha256'] == V1_MANIFEST
            and common['public_candidate_zip']['sha256'] == V1_ZIP, 'plan v1 identity')
    require(common['source_recipe']['sha256'] == pin(by_v1['SOURCE_RESTORATION.json']['retained_path'])['sha256'], 'source recipe pin')
    restored = bindings['restored_source_pins']
    require(restored == plan['restored_input_pins'], 'restored plan pins')
    restoration = load('replay/records/RESTORATION_RECEIPT.json')
    require(restoration['status'] == 'PASS_FIVE_PRIVATE_INPUTS_RESTORED_EXACTLY'
            and restoration['restored_files'] == restored, 'restoration record binding')
    source_by_name = {PurePosixPath(row['path']).name: row for row in restored}
    require(len(source_by_name) == 5, 'five restored input identities')
    for row in load('SOURCE_RESTORATION.json')['five_required_input_files']:
        require(fields(row) == fields(source_by_name[row['name']]), 'source restoration recipe identity')
    actual_argv = {row['stage']: row['argv'] for row in bindings['scientific_stage_argv']}
    samples = 0
    for stage in plan['stages']:
        name = stage['stage']
        argv = actual_argv[name]
        require(argv == stage['scientific_argv'], 'scientific argv binding')
        require(argv[:4] == [common['python']['path'], '-I', '-S', '-B'], 'outer flags')
        require(argv[4] == common[stage['script_key']]['path'], 'scientific program argv')
        flags = {'--source-a': 'A_OLD_PUBLIC_INITIAL.spectra', '--source-b': 'B_NEW_POINT_R2404.spectra'}
        if name in ('public_checker_A', 'public_checker_B'):
            source_name = 'A_OLD_PUBLIC_INITIAL.spectra' if name.endswith('_A') else 'B_NEW_POINT_R2404.spectra'
            flags = {'--source': source_name}
        elif name == 'public_source_ENV_totality_binding':
            flags.update({'--published-old': 'published_old.spectra', '--published-new': 'published_new.spectra',
                          '--ordinary-projection': 'updated_ordinary_projection.spectra'})
        for flag, source_name in flags.items():
            require(option(argv, flag) == source_by_name[source_name]['path'], 'actual restored source argv')
        prefix = 'replay/runs/' + name + '/'
        run = load(prefix + 'RUN_RECEIPT.json')
        require(run['status'] == 'FINISHED_ZERO' and run['child_exit_code'] == 0
                and run['scientific_attempts'] == 1 and not run['signals'] and run['error'] is None, 'stage completion')
        first_line = path(prefix + 'STDOUT.txt').read_text().splitlines()[0]
        wrapper = json.loads(first_line)
        require(wrapper['wrapper_preflight'] == 'PASS_BEFORE_EXEC' and wrapper['command'] == argv, 'wrapper exec intent')
        rows = [json.loads(line) for line in path(prefix + 'SAMPLES.jsonl').read_text().splitlines()]
        require(len(rows) == run['sample_count'], 'sample count')
        for row in rows:
            require(row['rss_bytes'] < 1073741824 and row['output_bytes'] <= 134217728
                    and row['total_output_bytes'] <= 536870912, 'recorded sampled cap')
        samples += len(rows)
    require(len(plan['stages']) == 4 and samples == 70, 'four stages / seventy samples')

    for label, state_count, edge_count in [('A', 5016, 12656), ('B', 5015, 12672)]:
        receipt = load('replay/runs/public_checker_' + label + '/CHECK_RECEIPT.json')
        require(receipt['verdict'] == 'ACCEPT_POSITIVE_EXISTENCE' and receipt['checker_sha256'] == CHECKER, 'positive outcome')
        require(receipt['certificate_sha256'] == pin('certificates/' + label + '.json')['sha256'], 'positive certificate hash')
        require(receipt['states_checked'] == state_count and receipt['policy_edges_checked'] == edge_count, 'recorded positive counts')
        expected_source = source_by_name['A_OLD_PUBLIC_INITIAL.spectra' if label == 'A' else 'B_NEW_POINT_R2404.spectra']
        require(fields(receipt['source']) == fields(expected_source), 'positive source byte identity')
    totality = load('replay/runs/public_source_ENV_totality_binding/TOTALITY_BINDING_RECEIPT.json')
    require(totality['verdict'] == 'ACCEPT_SOURCE_ENV_TOTALITY_ONLY' and totality['checker_sha256'] == CHECKER, 'totality verdict')
    require((totality['typed_states_checked'], totality['typed_env_candidates_per_state'], totality['legal_env_edges'],
             totality['min_legal_env_outdegree'], totality['max_legal_env_outdegree']) == (6272, 98, 9536, 1, 9), 'recorded totality counts')

    mapping = load('replay/QUALIFICATION_REPLAY_INPUT_MAP.json')
    require(len(mapping['cases']) == 50 and len(mapping['positive_controls']) == 2, 'qualification map counts')
    summary = load('replay/runs/public_checker_qualification/qualification/qualification_summary.json')
    require(summary['status'] == 'PASS_REJECTION_QUALIFICATION'
            and summary['checker_sha256'] == CHECKER and summary['driver_sha256'] == QUALIFIER, 'qualification freeze/verdict')
    expected = {(case['case_id'], mutation['name']): mutation
                for case in summary['cases'] for mutation in case['mutations']}
    require(len(expected) == 50, 'summary mutation count')
    direct, null = 0, 0
    for row in mapping['cases']:
        key = (row['case_id'], row['name'])
        require(key in expected, 'missing summary input')
        mutation = expected.pop(key)
        require(pin(row['existing_public_archive']) == row['actual_replay_archive_pin'], 'actual replay gzip identity')
        raw_hash = sha(gzip.decompress(path(row['existing_public_archive']).read_bytes()))
        require(raw_hash == row['uncompressed_sha256'] == mutation['input']['uncompressed_sha256'], 'raw replay input hash')
        receipt = load(row['replay_receipt'])
        require(receipt['verdict'] == 'REJECT' and receipt['checker_sha256'] == CHECKER, 'rejection receipt')
        require(receipt['code'] == row['expected_code'] == mutation['expected_code'] == mutation['observed_code']
                and mutation['passed'], 'expected rejection binding')
        if row['name'] == 'duplicate_json_key':
            require(receipt['certificate_sha256'] is None and row['recorded_checker_input_sha256'] is None, 'duplicate-key hash scope')
            null += 1
        else:
            require(receipt['certificate_sha256'] == raw_hash == row['recorded_checker_input_sha256'], 'direct replay input hash')
            direct += 1
    require(not expected and (direct, null) == (48, 2), 'qualification hash coverage')
    for row in mapping['positive_controls']:
        receipt = load(row['receipt'])
        label = 'A' if row['case_id'].startswith('A_') else 'B'
        require(receipt['verdict'] == 'ACCEPT_POSITIVE_EXISTENCE' and receipt['checker_sha256'] == CHECKER
                and receipt['certificate_sha256'] == row['certificate_sha256'] == pin('certificates/' + label + '.json')['sha256'], 'positive control binding')
    audit = load('replay/records/PUBLIC_REPLAY_EXECUTION_AUDIT.json')
    require(audit['check_count'] == len(audit['checks']) == 1455 and not audit['failed']
            and all(row['pass'] for row in audit['checks']), 'recorded independent audit disposition')
    print(json.dumps({'status': 'PASS_STATIC_REPLAY_RECORD_BINDINGS_ONLY',
                      'mapped_original_public_files': len(ledger), 'retained_exact_v1_payload_files': 312,
                      'reused_actual_replay_gzip_files': 50, 'recorded_checker_outcomes': 55,
                      'direct_input_hashes': direct, 'duplicate_key_null_hashes': null,
                      'recorded_supervisor_samples': samples, 'scientific_modules_imported': 0,
                      'scientific_execution': 0, 'source_restoration': 0, 'GUI': 0, 'network': 0}, indent=2))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(json.dumps({'status': 'FAIL_STATIC_REPLAY_RECORD_BINDINGS', 'type': type(exc).__name__, 'detail': str(exc)}))
        sys.exit(1)
