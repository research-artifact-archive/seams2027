"""Unchanged completed-process validator from qualified fixed188 parent."""
import re

def valid_process(p):
    if type(p)is not dict:return False
    if any(type(p.get(k))is not dict for k in ('exact_child_wait4','final_group_observation','capture')):return False
    if set(p['capture'])!={'stdout','stderr'} or any(type(v)is not dict for v in p['capture'].values()):return False
    for name,v in p['capture'].items():
        if v.get('file')!=name+'.txt' or type(v.get('bytes'))is not int or v['bytes']<0 or type(v.get('sha256'))is not str or re.fullmatch('[0-9a-f]{64}',v['sha256'])is None:return False
        if v['bytes']!=v.get('captured_bytes'):return False
    return (p.get('schema')=='contained-stage-process-v2' and p.get('status')=='PROCESS_COMPLETED' and type(p.get('exit_code'))is int and p['exit_code']==0
      and p.get('process_started')is True and p.get('owned_child_reaped')is True and p.get('receipt_persisted')is True and p.get('parent_finalization_completed')is True and p.get('parent_aborted')is False
      and p['exact_child_wait4'].get('exact_child_reaped')is True and p['exact_child_wait4'].get('authority_lost')is False and p['final_group_observation'].get('state')=='ABSENT'
      and type(p.get('fatal_reasons'))is list and p['fatal_reasons']==[] and type(p.get('resource_reasons'))is list and p['resource_reasons']==[]
      and all(v.get('complete')is True and type(v.get('observed_bytes'))is int and type(v.get('captured_bytes'))is int and v['observed_bytes']==v['captured_bytes'] and v['observed_bytes']>=0 for v in p['capture'].values()))

