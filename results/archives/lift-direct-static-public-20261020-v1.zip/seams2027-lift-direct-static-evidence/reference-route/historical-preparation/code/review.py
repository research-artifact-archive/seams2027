"""Separate qualification and single saved-source audit authority.

The reused supervisor owns exactly its child and persists complete captures.
No preparation mode evaluates a real saved graph or scientific DAG.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, json, math, shutil, signal, sys, traceback
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import authority as a
import process_validation as pv
if Path(a.__file__).resolve() != HERE/'authority.py' or Path(pv.__file__).resolve() != HERE/'process_validation.py':
    raise RuntimeError('Unexpected authority/validation module origin')


def import_only_profile(frozen):
    previous = sys.getprofile()
    events = {'blocked_mathematical_calls': 0}
    paths = {frozen.path('code/' + n) for n in ('audit.py', 'codec.py', 'independent_core.py', 'graph_fairness.py')}
    def hook(frame, event, arg):
        if event == 'call' and Path(frame.f_code.co_filename).absolute() in paths and frame.f_code.co_name != '<module>':
            # Class bodies during an import have no self and are allowed.
            if frame.f_code.co_name in ('AuditError', 'SavedDag', 'FieldCodec', 'OriginalPredicates', 'GraphValidationError') and 'self' not in frame.f_locals:
                return
            if (frame.f_code.co_name in ('<genexpr>', '<dictcomp>', '<listcomp>') and
                    frame.f_back is not None and frame.f_back.f_code.co_name == '<module>'):
                return  # module-level declared names/values only
            events['blocked_mathematical_calls'] += 1
            raise RuntimeError('Import qualification attempted a mathematical call')
    sys.setprofile(hook)
    return previous, events


def load_scope(frozen):
    core = a.load_module('lift_reference_independent_dag_core', frozen.path('code/independent_core.py'))
    source = a.load_module('lift_reference_original_bdd_codec', frozen.path('code/codec.py'))
    audit = a.load_module('lift_reference_original_bdd_graph_audit', frozen.path('code/audit.py'))
    fairness = a.load_module('lift_reference_kosaraju_fairness', frozen.path('code/graph_fairness.py'))
    return core, source, audit, fairness


def worker(args):
    frozen = a.Frozen(args.root, args.expected_manifest)
    output = a.canonical_path(args.output)
    kind = args.action.removesuffix('-worker')
    a.need(output.parent.is_dir() and not output.exists() and not output.is_relative_to(frozen.root), 'Fresh outside worker output')
    go, go_pin = (a.load_go(args.go, frozen.manifest_hash, output.parent) if kind == 'actual'
                  else a.load_preparation_go(args.preparation_go, frozen.manifest_hash, output.parent, kind))
    if kind=='actual':a.exact(a.digest(frozen.raw('prior/NATIVE_PROVENANCE_PREFLIGHT.json')),{k:go['native_provenance_receipt'][k]for k in('bytes','sha256')},'Frozen Root native provenance identity')
    start = a.decode(a.file_bytes(output.parent/'START.json'))
    a.exact(start['GO'], go_pin, 'Parent/worker authority')
    a.need(start['action'] == kind and start['frozen_manifest_sha256'] == frozen.manifest_hash, 'Parent scope/action')
    output.mkdir()
    guard = a.load_module('lift_reference_unchanged_guard', frozen.path('code/runtime_guard.py')).install(frozen.root, output)
    events = {'audit_entries': 0, 'blocked_graph_calls': 0, 'blocked_native_library_loads': 0}
    def native_hook(event, args):
        if event.startswith('ctypes.'):
            events['blocked_native_library_loads'] += 1
            raise PermissionError('Scientific native library loading is outside this scalar audit')
    sys.addaudithook(native_hook)
    previous = None
    try:
        deadline = datetime.fromisoformat(go['deadline_utc'])
        def timed_out(*_): raise TimeoutError('Bounded source audit deadline')
        signal.signal(signal.SIGALRM, timed_out)
        signal.alarm(max(1, math.ceil(min(a.LIMITS['wall_seconds'], (deadline-datetime.now(timezone.utc)).total_seconds()))))
        if kind == 'imports':
            previous, imported = import_only_profile(frozen)
            try: core, source, audit, fairness = load_scope(frozen)
            finally: sys.setprofile(previous); previous = None
            probe = output/'OWN_OUTPUT_PROBE.txt'
            probe.write_bytes(b'bounded source audit own output\n')
            a.need(probe.read_bytes() == b'bounded source audit own output\n', 'Assigned output readback')
            external = a.canonical_path(args.reject_read_root)
            a.need(not external.is_relative_to(frozen.root) and not external.is_relative_to(output), 'External read probe')
            try: (external/'OUTSIDE_READ_PROBE').read_bytes()
            except PermissionError: rejected = True
            else: rejected = False
            a.need(rejected and imported['blocked_mathematical_calls'] == 0 and guard['external_data_reads_blocked'] == 1,
                   'Import-only zero math and exact external read rejection')
            report = {'status': 'PASS_IMPORT_ONLY', 'saved_DAG_evaluations': 0, 'saved_graph_evaluations':0,
                      'import_events': imported, 'external_read_rejected_before_open': rejected,
                      'module_origins': [str(m.__file__) for m in (core, source, audit, fairness)]}
        else:
            core, source, audit, fairness = load_scope(frozen)
            def forbidden_graph(*args, **kwargs):
                events['blocked_graph_calls'] += 1
                raise RuntimeError('Shared bitset finite graph operations are outside this independent reference scope')
            for name in ('closure', 'reachable_from', 'components', 'finite_fairness'):
                setattr(core, name, forbidden_graph)
            if kind == 'artificial':
                qualification = a.load_module('lift_reference_generated_qualification', frozen.path('code/qualify_artificial.py'))
                report = qualification.run(frozen, output, a, core, source, audit, pv, completion, fairness)
                a.need(report['status'] == 'PASS_ARTIFICIAL_BDD_GRAPH_REFERENCE' and report['saved_DAG_evaluations'] == 0,
                       'Artificial-only qualification completion')
            else:
                events['audit_entries'] += 1
                report = audit.run(frozen, a, core, source, fairness, pv)
                a.need(report['status'] in ('COMPLETE_ORIGINAL_BDD_GRAPH_CERTIFICATE','COMPLETE_ORIGINAL_BDD_GRAPH_REJECTION') and report['saved_DAG_files_loaded']==10 and report['saved_graph_evaluations']==1, 'Complete reference graph result')
        a.need(events['audit_entries'] == int(kind == 'actual') and events['blocked_graph_calls'] == 0 and
               events['blocked_native_library_loads'] == 0, 'Exact observed source-only scope')
        a.need(guard['external_data_reads_blocked'] == int(kind == 'imports') and
               guard['network_process_attempts_blocked'] == 0, 'No unexpected I/O or native process attempts')
        report.update(frozen_manifest_sha256=frozen.manifest_hash, scope=a.SCOPE, case=a.CASE,
                      execution_events=events, guard=guard,
                      no_native_or_graph_basis='Pinned scalar BDD codec and separate Kosaraju graph code; shared bitset graph entry points blocked, and audited process/library boundary with zero attempted calls.')
        a.save(output/'RESULT.json', report)
        frozen.verify()
        complete = {'schema': 'lift-original-bdd-reference-worker-complete-v1', 'status': report['status'],
                    'frozen_manifest_sha256': frozen.manifest_hash, 'scope': a.SCOPE, 'case': a.CASE,
                    'kind': kind, 'all_inputs_unchanged': True, 'execution_events': events, 'guard': guard,
                    'result': a.pin(output/'RESULT.json')}
        a.save(output/'WORKER_COMPLETE.json', complete)
        print(json.dumps({'status': report['status'], 'kind': kind}), flush=True)
        return 0
    except BaseException as error:
        if previous is not None: sys.setprofile(previous)
        failure = {'schema': 'lift-original-bdd-reference-worker-unknown-v1', 'status': 'UNKNOWN_BDD_GRAPH_REFERENCE',
                   'error_type': type(error).__name__, 'reason': str(error), 'traceback': traceback.format_exc(),
                   'frozen_manifest_sha256': frozen.manifest_hash, 'scope': a.SCOPE, 'case': a.CASE,
                   'execution_events': events, 'guard': guard, 'admitted_scientific_result': False,
                   'partial_comparisons': getattr(error, 'partial_comparisons', []),
                   'original_full_mapping_UNKNOWN_preserved': True}
        a.save(output/'UNKNOWN.json', failure)
        print(json.dumps({'status': failure['status'], 'reason': str(error)}), flush=True)
        return 2
    finally:
        signal.alarm(0)


def completion(output, frozen, kind, process, unchanged, launch_error):
    errors, records = [], {}
    if launch_error: errors.append({'phase': 'launch', 'reason': launch_error})
    try:
        persisted = a.decode(a.file_bytes(output/'process/PROCESS_RECEIPT.json'))
        a.exact(persisted, process, 'Persisted supervisor receipt')
        a.need(pv.valid_process(process), 'Complete exact owned child with full captures')
        records['process'] = a.pin(output/'process/PROCESS_RECEIPT.json')
        for name, row in process['capture'].items():
            raw = a.file_bytes(output/'process'/(name+'.txt'), a.LIMITS['stream_bytes'])
            a.exact(a.digest(raw), {k: row[k] for k in ('bytes', 'sha256')}, 'Capture actual byte identity')
            a.need(len(raw) == row['captured_bytes'] == row['observed_bytes'], 'Complete capture counts')
            records[name] = a.pin(output/'process'/(name+'.txt'))
    except BaseException as error: errors.append({'phase': 'owned_process', 'reason': str(error)})
    if unchanged is not True: errors.append({'phase': 'inputs', 'reason': 'Frozen bytes not confirmed unchanged'})
    scientific = None
    if not errors:
        try:
            done = a.decode(a.file_bytes(output/'worker/WORKER_COMPLETE.json'))
            report = a.decode(a.file_bytes(output/'worker/RESULT.json'))
            a.exact(a.pin(output/'worker/RESULT.json'), done['result'], 'Completed worker result pin')
            for obj in (done, report):
                a.need(obj['frozen_manifest_sha256'] == frozen.manifest_hash and obj['scope'] == a.SCOPE and
                       obj['case'] == a.CASE, 'Exact source scope output')
            a.need(done['all_inputs_unchanged'] is True and done['kind'] == kind and done['status'] == report['status'], 'Worker completion identity')
            expected = {'artificial': {'PASS_ARTIFICIAL_BDD_GRAPH_REFERENCE'}, 'imports': {'PASS_IMPORT_ONLY'},
                        'actual': {'COMPLETE_ORIGINAL_BDD_GRAPH_CERTIFICATE', 'COMPLETE_ORIGINAL_BDD_GRAPH_REJECTION'}}[kind]
            a.need(report['status'] in expected, 'Recognized complete result status')
            a.exact(done['execution_events'], report['execution_events'], 'Execution event record')
            a.exact(report['execution_events'], {'audit_entries': int(kind == 'actual'),
                'blocked_graph_calls': 0, 'blocked_native_library_loads': 0}, 'Exact source-only execution events')
            a.need(report['guard']['external_data_reads_blocked'] == int(kind == 'imports') and
                   report['guard']['network_process_attempts_blocked'] == 0, 'Expected guard observations')
            if kind != 'actual':
                a.need(type(report['saved_DAG_evaluations']) is int and report['saved_DAG_evaluations'] == 0 and type(report['saved_graph_evaluations'])is int and report['saved_graph_evaluations']==0, 'No saved science in qualification')
            else:
                a.need(report['admitted_scientific_result'] is False and report['saved_DAG_files_loaded']==10 and report['saved_graph_evaluations']==1,
                       'Exactly ten original BDDs, one saved graph and no pre-adoption')
                scientific = report['status']
            records['result'] = a.pin(output/'worker/RESULT.json')
            records['complete'] = a.pin(output/'worker/WORKER_COMPLETE.json')
        except BaseException as error: errors.append({'phase': 'worker_result', 'reason': str(error)})
    status = ('PASS_BDD_GRAPH_REFERENCE_QUALIFICATION' if kind != 'actual' else scientific + '_PENDING_INDEPENDENT_ADOPTION') if not errors else 'UNKNOWN_BDD_GRAPH_REFERENCE_NOT_ADMITTED'
    return {'schema': 'lift-original-bdd-reference-parent-v1', 'status': status,
            'qualification_kind': kind if kind != 'actual' else None, 'scientific_status': scientific,
            'scope': a.SCOPE, 'case': a.CASE, 'frozen_manifest_sha256': frozen.manifest_hash,
            'inputs_unchanged': unchanged, 'records': records, 'errors': errors,
            'attempts': 1, 'admitted_scientific_result': False,
            'original_full_mapping_UNKNOWN_preserved': True}


def parent(args):
    frozen = a.Frozen(args.root, args.expected_manifest)
    output = a.canonical_path(args.output)
    a.need(output.parent.is_dir() and not output.exists() and not output.is_relative_to(frozen.root), 'Fresh outside output')
    a.need(shutil.disk_usage(output.parent).free > a.LIMITS['min_free_bytes'] + a.LIMITS['reserve_bytes'], 'Disk floor plus 16MiB reserve')
    go, go_pin = (a.load_go(args.go, frozen.manifest_hash, output) if args.action == 'actual'
                  else a.load_preparation_go(args.preparation_go, frozen.manifest_hash, output, args.action))
    deadline = datetime.fromisoformat(go['deadline_utc'])
    a.need((deadline-datetime.now(timezone.utc)).total_seconds() > a.LIMITS['wall_seconds']+10, 'Full bounded interval and finalization reserve')
    output.mkdir()
    a.save(output/'START.json', {'schema': 'lift-original-bdd-reference-start-v1', 'GO': go_pin,
        'frozen_manifest_sha256': frozen.manifest_hash, 'scope': a.SCOPE, 'case': a.CASE,
        'action': args.action, 'started_utc': datetime.now(timezone.utc).isoformat(),
        'python': a.pin(Path(sys.executable).resolve())})
    supervisor = a.load_module('lift_reference_unchanged_exact_child_supervisor', frozen.path('code/supervisor/bounded_process.py'))
    argv = [sys.executable, '-I', '-S', '-B', str(frozen.path('code/review.py')), args.action+'-worker',
            '--root', str(frozen.root), '--expected-manifest', frozen.manifest_hash, '--output', str(output/'worker')]
    argv += ['--go', str(Path(args.go).absolute())] if args.action == 'actual' else ['--preparation-go', str(Path(args.preparation_go).absolute())]
    if args.action == 'imports': argv += ['--reject-read-root', args.reject_read_root]
    process, error = None, None
    try:
        process = supervisor.run_bounded(argv, output/'process', go['deadline_utc'],
            wall_seconds=a.LIMITS['wall_seconds'], rss_bytes=a.LIMITS['rss_bytes'],
            stream_bytes=a.LIMITS['stream_bytes'], file_bytes=a.LIMITS['file_bytes'],
            watch_files=[output/'worker'/name for name in ('RESULT.json', 'UNKNOWN.json', 'WORKER_COMPLETE.json')],
            output_tree=output, output_tree_bytes=a.LIMITS['output_tree_bytes'], min_free_bytes=a.LIMITS['min_free_bytes'])
    except BaseException as ex: error = repr(ex)
    try: unchanged = frozen.verify()
    except BaseException as ex: unchanged = False; error = (error or '') + '; input integrity: ' + repr(ex)
    result = completion(output, frozen, args.action, process, unchanged, error)
    result['GO'] = go_pin
    a.save(output/'RUN_RECEIPT.json', result)
    print(json.dumps({'status': result['status'], 'errors': result['errors']}), flush=True)
    return 2 if result['errors'] else 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('action', choices=['artificial', 'imports', 'actual', 'artificial-worker', 'imports-worker', 'actual-worker'])
    for name in ('root', 'expected-manifest', 'output'): ap.add_argument('--'+name, required=True)
    for name in ('go', 'preparation-go', 'reject-read-root'): ap.add_argument('--'+name)
    args = ap.parse_args()
    return worker(args) if args.action.endswith('-worker') else parent(args)


if __name__ == '__main__': raise SystemExit(main())
