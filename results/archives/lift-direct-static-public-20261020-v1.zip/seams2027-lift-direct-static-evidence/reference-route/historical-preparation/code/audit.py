"""Distinct original-BDD reference traversal of a pinned raw native graph."""
from collections import deque


def validate_raw(g,m,r,printed,codec,need):
    c=codec.FieldCodec(m,True,need);nodes=g['nodes'];edges=[];by={}
    need(g['schema']=='released-kind-complete-native-controller-v1'and g['complete']is True and g['initialization']=='source_initializers','Complete raw graph')
    need(type(nodes)is list and 0<len(nodes)<=1024 and type(g['api_state_count'])is int and len(nodes)==g['api_state_count'],'Raw graph node cap')
    need(g['model_sha256']==r['model_export']['sha256']and g['native_memory_identity']==r['native_memory_identity'],'Native raw graph identity')
    need(type(g['rank_domain_size'])is int and g['rank_domain_size']==len(m['original_justices']['SYS'])==3,'Exact rank domain')
    lines=printed.splitlines();need(len(lines)==2*len(nodes),'Printer complete line count')
    for k,node in enumerate(nodes):
        u=str(k);need(node['id']==u and type(node['native_id'])is int and node['native_id']==k,'Canonical raw IDs')
        need(type(node['initial'])is bool and type(node['rank'])is int and 0<=node['rank']<3 and node['rank_class']=='tau.smlab.syntech.games.gr1.GR1RankInfo'and type(node['rank_info'])is str,'Private rank identity')
        s=node['valuation'];need(type(s)is dict and set(s)==set(c.names),'Complete raw valuation')
        bits={str(k):v for k,v in c.bits(s).items()};need(type(node['bits'])is dict and all(type(v)is bool for v in node['bits'].values())and node['bits']==bits,'Exact raw typed bits')
        dest=node['successors'];need(type(dest)is list and all(type(v)is str for v in dest)and len(dest)==len(set(dest)),'Unique raw successors')
        text=node['native_bdd_text'];prefix=('Initial State 'if node['initial']else'State ')+u+' '
        need(lines[2*k]==prefix+text and text.startswith('<')and text.endswith('>'),'Printer raw state')
        pairs=[x.split(':')for x in text[1:-1].split(', ')];need(all(len(p)==2 for p in pairs)and len(pairs)==len(dict(pairs))and dict(pairs)==s,'Printer typed state identity')
        need(lines[2*k+1]==('\tWith successors : '+', '.join(dest)if dest else'\tWith no successors.'),'Printer adjacency')
        by[u]=node;edges.extend((u,v)for v in dest)
    need(type(g['api_transition_count'])is int and len(edges)==g['api_transition_count']<=32768 and len(edges)==len(set(edges))and g['edges']==[list(e)for e in edges]and all(v in by for _,v in edges),'Complete raw closed edges')
    roots=[n['id']for n in nodes if n['initial']];need(roots and all(by[u]['rank']==0 and by[u]['valuation'][codec.HELPER]=='false'for u in roots),'Raw initial memory/helper binding')
    seen=set(roots);todo=list(roots)
    while todo:
        for v in by[todo.pop()]['successors']:
            if v not in seen:seen.add(v);todo.append(v)
    need(seen==set(by),'All raw nodes reachable')
    return by,edges,roots


def analyze(by,edges,roots,pred,fairness,need):
    env=pred.env;key=lambda s:tuple(s[n]for n in env)
    expected={key(e)for e in pred.inputs if pred.initial_env(e)};init={k:[]for k in expected};excluded=[];initial_bad=[]
    for u in roots:
        s=by[u]['valuation'];k=key(s)
        if k not in expected:excluded.append(u);continue
        init[k].append(u)
        if not pred.initial_sys(s):initial_bad.append(u)
    starts=[u for u in roots if key(by[u]['valuation'])in expected]
    parents={u:None for u in starts};queue=deque(starts);selected=[];coverage=[];holes=[];unsafe=[];illegal=set();legal_counts={}
    def prefix(u):
        row=[]
        while u is not None:row.append(u);u=parents[u]
        return row[::-1]
    while queue:
        u=queue.popleft();s=by[u]['valuation'];legal_counts[u]=0
        # Compute input-to-raw-ID map independently before querying each legal input.
        response={key(e):[]for e in pred.inputs}
        for v in by[u]['successors']:
            if by[v]['valuation']['~envHelp']=='false':response[key(by[v]['valuation'])].append(v)
        for e in pred.inputs:
            k=key(e);is_legal=pred.legal(s,e);targets=response[k]
            if not is_legal:
                illegal.update((u,v)for v in targets);continue
            legal_counts[u]+=1
            row={'state':u,'input':e,'responses':list(targets)};coverage.append(row)
            if len(targets)!=1:holes.append(dict(row,reason='MISSING_RESPONSE'if not targets else'AMBIGUOUS_RESPONSE'))
            for v in targets:
                selected.append((u,v))
                if not pred.safe(s,by[v]['valuation']):unsafe.append({'source':u,'target':v,'input':e})
                if v not in parents:parents[v]=u;queue.append(v)
    if holes:holes[0]['prefix']=prefix(holes[0]['state'])
    if unsafe:unsafe[0]['prefix']=prefix(unsafe[0]['source'])
    vertices=set(parents);need(len(vertices)*len(pred.inputs)<=16384,'Bounded original input work')
    initrows=[{'input':dict(zip(env,k)),'responses':init[k]}for k in sorted(init)]
    complete=bool(expected)and all(len(v)==1 for v in init.values())and not initial_bad and not holes and not unsafe
    envlabels=None;syslabels=None
    for u in sorted(vertices,key=int):
        es,ss=pred.justice(by[u]['valuation'])
        need(type(es)is list and type(ss)is list and all(type(v)is bool for v in es+ss),'Exact Boolean justice tuple')
        if envlabels is None:envlabels=[[]for _ in es];syslabels=[[]for _ in ss]
        need(len(es)==len(envlabels)and len(ss)==len(syslabels),'Stable ordered justice counts')
        for labels,vals in ((envlabels,es),(syslabels,ss)):
            for label,yes in zip(labels,vals):
                if yes:label.append(u)
    if envlabels is None:envlabels=[];syslabels=[]
    graph={'states':sorted(vertices,key=int),'edges':[list(e)for e in selected],'starts':starts,'env_justice':envlabels,'sys_justice':syslabels}
    result=fairness.analyze_graph(graph)if complete else None
    outgoing={u:0 for u in vertices}
    for u,v in selected:outgoing[u]+=1
    dead=[u for u in sorted(vertices,key=int)if not outgoing[u]]
    environmental_dead=[u for u in dead if legal_counts[u]==0]
    strategy_dead=[u for u in dead if legal_counts[u]>0]
    need(set(environmental_dead).isdisjoint(strategy_dead)and set(dead)==set(environmental_dead)|set(strategy_dead),'Complete deadend distinction')
    classifications=[];counts={};selectedset=set(selected)
    for u,v in edges:
        if by[u]['valuation']['~envHelp']!='false'or by[v]['valuation']['~envHelp']!='false':c='EXCLUDED_HELPER'
        elif u not in vertices:c='OUTSIDE_ORIGINAL_LEGAL_REACHABLE_ORIGIN'
        elif(u,v)in illegal:c='EXCLUDED_ORIGINAL_ENV_ILLEGAL'
        else:need((u,v)in selectedset,'Every relevant edge classified');c='SELECTED_ORIGINAL_ENV_LEGAL'
        classifications.append([u,v,c]);counts[c]=counts.get(c,0)+1
    return {'status':'COMPLETE_ORIGINAL_BDD_GRAPH_CERTIFICATE'if complete else'COMPLETE_ORIGINAL_BDD_GRAPH_REJECTION','admitted_scientific_result':False,'complete_source_controller':complete,'original_strict_controller':result['strict_liveness']['pass']if complete else None,'original_cooperative_controller':result['nonconflicting']['pass']if complete else None,'initial_response_table':initrows,'initial_coverage_failures':[r for r in initrows if len(r['responses'])!=1],'initial_SYS_AUX_failures':initial_bad,'excluded_initial_nodes':excluded,'input_coverage_failures':holes,'SYS_AUX_safety_failures':unsafe,'fairness_evaluated_after_all_controller_gates':complete,'fairness':result,'deadends':dead,'environmental_deadends':environmental_dead,'strategy_deadends':strategy_dead,'legal_ENV_input_count_by_node':{u:legal_counts[u]for u in sorted(vertices,key=int)},'deadend_prefixes':[{'state':u,'prefix':prefix(u)}for u in dead],'edge_classification_counts':counts,'view':dict(graph,native_nodes=[by[u]for u in sorted(vertices,key=int)],raw_edge_classifications=classifications,legal_input_response_table=coverage,BFS_parent=parents),'input_choices_checked':len(vertices)*len(pred.inputs),'all_raw_IDs_private_ranks_AUX_retained':True,'original_mapping_UNKNOWN_preserved':True}


def run(frozen,a,core,codec,fairness,pv):
    old=frozen.read('prior/ORIGINAL_INPUTS.json');prior=frozen.read('prior/SOURCE_MODEL_RESULT.json')
    a.need(prior['status']=='COMPLETE_INDEPENDENT_SOURCE_MODEL_CORRESPONDENCE'and prior['candidate']==a.CASE,'Accepted source correspondence status')
    a.need(prior['source_correspondence']['source_sha256']==a.SOURCE['sha256'],'Source qualification identity')
    a.exact(a.digest(frozen.raw('prior/ORIGINAL_INPUTS.json')),{k:prior['input_manifest_pin'][k]for k in('bytes','sha256')},'Prior exact source-qualified manifest')
    a.exact(prior['input_bindings'],old['inputs'],'Prior original input bindings')
    a.exact(a.digest(frozen.raw('inputs/source.spectra')),a.SOURCE,'Pinned source')
    original=frozen.read('inputs/original/model.json');native=frozen.read('inputs/native/model.json');result=frozen.read('inputs/native/result.json')
    a.exact(a.digest(frozen.raw('inputs/original/model.json')),{k:old['inputs']['model'][k]for k in('bytes','sha256')},'Source-qualified original model')
    a.need(original['fixture_id']==a.CASE and original['case_id']=='lift'and original['variant']=='preferred','Helper-free original identity')
    a.need(original['input']['sha256']==a.SOURCE['sha256']and original['input']['bytes']==a.SOURCE['bytes'],'Original source pin')
    refs=a.model_references(original);raws={};refnames=[]
    keyed=dict(original['original_bdds']);keyed.update({'justice_'+str(i):r for i,r in enumerate(original['original_justices']['SYS'])})
    for k,ref in keyed.items():
        n=a.check_reference(ref);data=frozen.raw('inputs/original/'+n);a.exact(a.digest(data),{j:ref[j]for j in('bytes','sha256')},'Declared original BDD');a.exact(a.digest(data),{j:old['bdd_files'][n][j]for j in('bytes','sha256')},'Source-qualified original BDD');raws[k]=data;refnames.append(n)
    a.need(set(refnames)==set(old['bdd_files']),'Full source-qualified ten-BDD roster')
    pred=codec.OriginalPredicates(original,raws,core,a.need)
    a.need(pv.valid_process(frozen.read('inputs/native/PROCESS_RECEIPT.json')),'Historical native exact process')
    provenance=frozen.read('prior/NATIVE_PROVENANCE_PREFLIGHT.json');process=frozen.read('inputs/native/PROCESS_RECEIPT.json')
    for key,name in [('source','inputs/source.spectra'),('model','inputs/native/model.json'),('native_result','inputs/native/result.json'),('controller','inputs/native/controller.json'),('printer','inputs/native/controller.txt'),('native_process_receipt','inputs/native/PROCESS_RECEIPT.json')]:a.exact(a.digest(frozen.raw(name)),{k:provenance[key][k]for k in('bytes','sha256')},'Root capture provenance inputs')
    for stream in ('stdout','stderr'):
        a.exact({k:process['capture'][stream][k]for k in('bytes','sha256')},{k:provenance[stream][k]for k in('bytes','sha256')},'Root actual capture stream hash')
        a.need(provenance[stream]['bytes']==process['capture'][stream]['captured_bytes']==process['capture'][stream]['observed_bytes'],'Complete provenance captured counts')
    for obj in(native,result):a.need(obj['fixture_id']==obj['case_id']==a.CASE and obj['variant']=='initializers','Native case identity')
    a.need(result['status']=='JOB_CONTROLLER_PRINTED'and result['teardown']=='COMPLETED'and result['native_solver_calls']==result['controller_extraction_calls']==result['native_printer_calls']==1,'Complete one-call historical job')
    for k in('native_initial_verdict','memory_complete','memory_empty_guard_called','same_native_model_passed_to_constructor','same_native_memory_passed_to_constructor','helper_added','helper_is_native_nonaux_ENV'):a.need(result[k]is True,'Native extraction binding '+k)
    for k in('memory_empty','initializers_replaced','semantic_reduction_used','ENV_justice_normalization_used'):a.need(result[k]is False,'Native fixed mode '+k)
    a.need(result['input_sha256']==native['input']['sha256']==a.SOURCE['sha256']and native['input']['bytes']==a.SOURCE['bytes'],'Native source identity')
    for field,name in [('model_export','model.json'),('controller_export','controller.json'),('printed_controller','controller.txt')]:a.exact(a.digest(frozen.raw('inputs/native/'+name)),{k:result[field][k]for k in('bytes','sha256')},'Native byte export')
    data=frozen.raw('inputs/native/controller.json');a.need(data.endswith(b'\n')and a.sha(data[:-1])==result['controller_before_print_sha256']==result['controller_after_print_sha256'],'Before/after printer byte identity')
    g=a.decode(data);a.need(g['fixture_id']==g['case_id']==a.CASE and g['variant']=='initializers','Raw graph case')
    by,edges,roots=validate_raw(g,native,result,frozen.raw('inputs/native/controller.txt').decode(),codec,a.need)
    a.need(len(by)==810 and len(edges)==13958 and len(roots)==2,'Fixed saved graph size')
    report=analyze(by,edges,roots,pred,fairness,a.need)
    report.update(native_provenance=a.digest(frozen.raw('prior/NATIVE_PROVENANCE_PREFLIGHT.json')),saved_DAG_files_loaded=10,saved_graph_evaluations=1,saved_DAG_scalar_evaluations=sum(pred.calls.values()),predicate_evaluations=pred.calls,actual_decoded_supports={k:sorted(v.support)for k,v in pred.dags.items()},raw_graph={'states':810,'edges':13958,'initial_flags':2},native_calls=0,solver_calls=0,region_fixed_point_calls=0,source_equation_evaluations=0,independence='Source-qualified original saved-BDD predicates and separate value codec/traversal plus unchanged production Kosaraju/reverse reach; no source_contracts or bitset fairness. SavedDag decoder shared and B code previously read, so no blind-independence claim.',scope_limit='Separate exact saved-graph certificate only, under helper=false original legal histories. Historical whole-model mapping UNKNOWN unchanged; no controller runtime binding, native rerun, repair, region computation or deployment.')
    return report
