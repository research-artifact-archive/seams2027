"""Typed original/native codecs and scalar saved-BDD predicates only.

No hand-derived source predicates or bitset graph routines are used here.
"""
from itertools import product
ENV = ('b1','b2','b3','c')
SYS = ('f1','f2','f3')
AUX = tuple('SYS_CONSTRAINT.'+str(i)+'.pRespondsToS.state' for i in range(3))
HELPER = '~envHelp'

class FieldCodec:
    def __init__(self, model, helper, need):
        self.need=need;self.env=ENV;self.system=SYS+AUX
        self.names=ENV+((HELPER,)if helper else ())+SYS+AUX
        need(type(model['fields'])is list and [f['name']for f in model['fields']]==list(self.names),'Exact field roster/order')
        self.fields={f['name']:f for f in model['fields']};self.current=set();self.next=set()
        self.values={n:('S0','S1')if n in AUX else ('false','true')for n in self.names}
        for n,f in self.fields.items():
            owner='ENV'if n in ENV+(HELPER,)else'SYS';role='AUX'if n in AUX else owner
            need(f['owner']==owner and f['role']==role and type(f['domain_size'])is int and f['domain_size']==2,'Typed owner/role/domain')
            need(f['values']==list(self.values[n])and set(f['encoding'])==set(self.values[n]),'Exact semantic value labels')
            used=self.current|self.next
            cb,nb=f['current_bits'],f['next_bits'];need(type(cb)is list and type(nb)is list and len(cb)==len(nb)==1,'One physical bit per field')
            need(all(type(v)is int and v>=0 for v in cb+nb)and len(set(cb+nb))==2 and not(set(cb+nb)&used),'Unique disjoint bit IDs')
            self.current.update(cb);self.next.update(nb)
            for phase,bits in [('current',cb),('next',nb)]:
                vals=[]
                for label in self.values[n]:
                    mapping=f['encoding'][label][phase]
                    need(type(mapping)is dict and set(mapping)=={str(bits[0])}and type(mapping[str(bits[0])])is bool,'Exact Boolean bit mapping')
                    vals.append(mapping[str(bits[0])])
                need(set(vals)=={False,True},'Bijective value encoding')
        self.count=model['bdd_variable_count'];self.order=model['bdd_variable_order']
        need(type(self.count)is int and self.count==2*len(self.names)and self.current|self.next==set(range(self.count)),'Exact full bit carrier')
        need(type(self.order)is list and len(self.order)==self.count and all(type(v)is int for v in self.order)and set(self.order)==set(range(self.count)),'Variable order permutation')
        for key,bits in [('all_current_bits',self.current),('all_next_bits',self.next)]:
            row=model[key];need(type(row)is list and all(type(x)is int for x in row)and len(row)==len(set(row))and set(row)==bits,'Full phase roster')
        need(model['public_fields']=={'ENV':list(ENV)+([HELPER]if helper else []),'SYS':list(SYS)},'Public ownership roster')
    def bits(self,state,phase='current',names=None):
        names=self.names if names is None else names;out={}
        for n in names:
            self.need(type(state[n])is str and state[n]in self.values[n],'Typed valuation')
            for k,v in self.fields[n]['encoding'][state[n]][phase].items():out[int(k)]=v
        return out
    def valuations(self,names):
        return [dict(zip(names,vs))for vs in product(*(self.values[n]for n in names))]

class OriginalPredicates:
    def __init__(self,model,raws,core,need):
        self.codec=FieldCodec(model,False,need);self.env=ENV;self.need=need;self.calls={};self.dags={}
        required={'thetaE','thetaS','rhoE','rhoS','domain','domain_ENV_next','domain_SYS_next'}
        need(set(model['original_bdds'])==required,'Seven predicate/domain references')
        need(model['original_justices']['ENV']==[]and len(model['original_justices']['SYS'])==3,'Original zero ENV and three ordered SYS justices')
        refs=dict(model['original_bdds']);refs.update({'justice_'+str(i):r for i,r in enumerate(model['original_justices']['SYS'])})
        need(len(refs)==len(raws)==10 and set(refs)==set(raws),'Exact ten raw predicates')
        envcur={b for n in ENV for b in self.codec.fields[n]['current_bits']};envnext={b for n in ENV for b in self.codec.fields[n]['next_bits']}
        syscur=self.codec.current-envcur;sysnext=self.codec.next-envnext
        bounds={'thetaE':envcur,'thetaS':syscur,'rhoE':self.codec.current|envnext,'rhoS':self.codec.current|self.codec.next,'domain':self.codec.current,'domain_ENV_next':envnext,'domain_SYS_next':sysnext}
        bounds.update({'justice_'+str(i):self.codec.current for i in range(3)})
        for name,data in raws.items():
            dag=core.SavedDag(data,self.codec.count,self.codec.order)
            need(dag.support<=bounds[name],'Actual DAG support excludes undeclared dependency: '+name)
            self.dags[name]=dag;self.calls[name]=0
        self.inputs=self.codec.valuations(ENV)
        for name,names,phase in [('domain',self.codec.names,'current'),('domain_ENV_next',ENV,'next'),('domain_SYS_next',SYS+AUX,'next')]:
            for state in self.codec.valuations(names):need(self.value(name,self.codec.bits(state,phase,names)),'Full typed domain factor')
    def value(self,name,bits):self.calls[name]+=1;return self.dags[name].value(bits)
    def initial_env(self,e):return self.value('thetaE',self.codec.bits(e,'current',ENV))
    def initial_sys(self,s):return self.value('thetaS',self.codec.bits(s))
    def legal(self,s,e):return self.value('rhoE',self.codec.bits(s)|self.codec.bits(e,'next',ENV))
    def safe(self,s,t):return self.value('rhoS',self.codec.bits(s)|self.codec.bits(t,'next'))
    def justice(self,s):return [],[self.value('justice_'+str(i),self.codec.bits(s))for i in range(3)]
