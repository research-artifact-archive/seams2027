"""Artificial-only tests: no actual frozen graph/model/BDD is decoded."""
from copy import deepcopy
from itertools import product
from datetime import datetime,timezone,timedelta

def run(frozen,output,a,core,codec,audit,pv,completion,fairness):
    tests=[]
    def check(name,fn):
        fn();tests.append({'name':name,'status':'PASS'})
    def reject(name,fn):
        try:fn()
        except (ValueError,KeyError,TypeError,AssertionError):tests.append({'name':name,'status':'PASS_REJECTED'});return
        raise AssertionError('Mutation accepted: '+name)
    def eq(x,y):a.exact(x,y,'Artificial expectation')
    def model(helper=False):
        names=codec.ENV+((codec.HELPER,)if helper else ())+codec.SYS+codec.AUX;fields=[]
        for i,n in enumerate(names):
            vals=['S0','S1']if n in codec.AUX else['false','true'];owner='ENV'if n in codec.ENV+(codec.HELPER,)else'SYS'
            fields.append({'name':n,'owner':owner,'role':'AUX'if n in codec.AUX else owner,'domain_size':2,'values':vals,'current_bits':[2*i],'next_bits':[2*i+1],'encoding':{v:{'current':{str(2*i):bool(j)},'next':{str(2*i+1):bool(j)}}for j,v in enumerate(vals)}})
        return {'fields':fields,'public_fields':{'ENV':list(codec.ENV)+([codec.HELPER]if helper else []),'SYS':list(codec.SYS)},'all_current_bits':list(range(0,2*len(names),2)),'all_next_bits':list(range(1,2*len(names),2)),'bdd_variable_count':2*len(names),'bdd_variable_order':list(range(2*len(names))),'original_bdds':{k:{}for k in('thetaE','thetaS','rhoE','rhoS','domain','domain_ENV_next','domain_SYS_next')},'original_justices':{'ENV':[],'SYS':[{}, {}, {}]}}
    m=model();c=codec.FieldCodec(m,False,a.need)
    check('codec_complete_original_20bit',lambda:eq((len(c.names),c.count,len(c.valuations(codec.ENV))),(10,20,16)))
    base={n:c.values[n][0]for n in c.names};base['f1']='true'
    check('codec_source_values_encode_current',lambda:eq(c.bits(base)[8],True))
    check('codec_source_values_encode_next',lambda:eq(c.bits(base,'next')[9],True))
    n=model(True);nc=codec.FieldCodec(n,True,a.need)
    check('native_helper_shift_is_distinct',lambda:eq((c.fields['f1']['current_bits'],nc.fields['f1']['current_bits']),([8],[10])))
    mutations=[('field_missing',lambda x:x['fields'].pop()),('owner',lambda x:x['fields'][0].update(owner='SYS')),('role',lambda x:x['fields'][-1].update(role='SYS')),('bool_domain_count',lambda x:x['fields'][0].update(domain_size=True)),('duplicate_values',lambda x:x['fields'][0].update(values=['false','false'])),('phase_overlap',lambda x:x['fields'][0].update(next_bits=[0])),('bool_bit_id',lambda x:x['fields'][0].update(current_bits=[False])),('missing_encoding',lambda x:x['fields'][0]['encoding'].pop('false')),('integer_encoding',lambda x:x['fields'][0]['encoding']['false']['current'].update({'0':0})),('nonbijective',lambda x:x['fields'][0]['encoding']['true']['current'].update({'0':False})),('duplicate_order',lambda x:x['bdd_variable_order'].__setitem__(1,0)),('wrong_public_helper',lambda x:x['public_fields']['ENV'].append('~envHelp')),('missing_current_roster',lambda x:x['all_current_bits'].pop())]
    for name,mut in mutations:
        x=deepcopy(m);mut(x);reject('codec_'+name,lambda x=x:codec.FieldCodec(x,False,a.need))
    bad=dict(base);bad['f1']='TRUE';reject('codec_invalid_label',lambda:c.bits(bad))
    # Build tiny artificial saved DAG byte strings, never any real input DAG.
    def dag(variables,fn,count=20):
        nodes=[];unique={}
        def visit(j,bits):
            if j==len(variables):return int(fn(bits))
            v=variables[j];lo=visit(j+1,dict(bits,**{str(v):False}));hi=visit(j+1,dict(bits,**{str(v):True}))
            if lo==hi:return lo
            triple=(v,lo,hi)
            if triple not in unique:unique[triple]=len(nodes)+2;nodes.append((unique[triple],v,lo,hi))
            return unique[triple]
        root=visit(0,{})
        if root<2:return ('0 '+str(root)+'\n').encode()
        return (str(count)+'\n'+' '.join(map(str,range(count)))+'\n'+'\n'.join(' '.join(map(str,r))for r in nodes)+'\n').encode()
    raws={k:b'0 1\n'for k in m['original_bdds']};raws.update({'justice_'+str(i):b'0 1\n'for i in range(3)})
    raws['thetaE']=dag([0],lambda b:not b['0']);raws['thetaS']=dag([8],lambda b:b['8'])
    raws['rhoE']=dag([0,1],lambda b:not b['0']or b['1']);raws['rhoS']=dag([8,9],lambda b:b['8']==b['9'])
    pred=codec.OriginalPredicates(m,raws,core,a.need)
    check('artificial_BDD_initial_ENV_false_button',lambda:eq(pred.initial_env(dict.fromkeys(codec.ENV,'false')),True))
    check('artificial_BDD_initial_ENV_true_button',lambda:eq(pred.initial_env(dict(dict.fromkeys(codec.ENV,'false'),b1='true')),False))
    check('artificial_BDD_initial_SYS',lambda:eq(pred.initial_sys(base),True))
    s=dict(base,b1='true');e=dict.fromkeys(codec.ENV,'false')
    check('artificial_BDD_ENV_next_needed',lambda:eq(pred.legal(s,e),False));check('artificial_BDD_ENV_next_accepts',lambda:eq(pred.legal(s,dict(e,b1='true')),True))
    check('artificial_BDD_SYS_phase_equal',lambda:eq(pred.safe(base,base),True));check('artificial_BDD_SYS_phase_unequal',lambda:eq(pred.safe(base,dict(base,f1='false')),False))
    check('artificial_ordered_justice',lambda:eq(pred.justice(base),([],[True,True,True])))
    for name,key,data in [('rhoE_next_SYS','rhoE',dag([9],lambda b:b['9'])),('thetaE_SYS','thetaE',dag([8],lambda b:b['8'])),('domain_not_full','domain',dag([0],lambda b:b['0'])),('ENV_domain_next_SYS','domain_ENV_next',dag([9],lambda b:b['9']))]:
        x=dict(raws);x[key]=data;reject('support_or_domain_'+name,lambda x=x:codec.OriginalPredicates(m,x,core,a.need))
    x=dict(raws);x.pop('justice_2');reject('missing_tenth_DAG',lambda:codec.OriginalPredicates(m,x,core,a.need))
    reject('DAG_wrong_order',lambda:core.SavedDag(b'20\n'+b' '.join(str(i).encode()for i in reversed(range(20)))+b'\n2 0 0 1\n',20,list(range(20))))
    class Toy:
        env=('e',);inputs=[{'e':'false'},{'e':'true'}]
        def __init__(self,legal=None,init=None,syslabels=None):self.allowed=legal;self.initial=init;self.syslabels=[{'0','1'}]if syslabels is None else syslabels
        def initial_env(self,e):return self.initial is None or e['e']in self.initial
        def initial_sys(self,s):return s.get('good_init',True)
        def legal(self,s,e):return self.allowed is None or e['e']in self.allowed[s['tag']]
        def safe(self,s,t):return not t.get('bad',False)
        def justice(self,s):return [],[s['tag']in label for label in self.syslabels]
    def nodes():return {'0':{'valuation':{'e':'false','~envHelp':'false','tag':'0'},'successors':['0','1']},'1':{'valuation':{'e':'true','~envHelp':'false','tag':'1'},'successors':['0','1']}}
    def analyze(by=None,p=None,roots=None):
        by=nodes()if by is None else by;return audit.analyze(by,[(u,v)for u,node in by.items()for v in node['successors']],['0','1']if roots is None else roots,Toy()if p is None else p,fairness,a.need)
    r=analyze();check('complete_selected_total_graph',lambda:eq((r['complete_source_controller'],r['original_strict_controller'],r['original_cooperative_controller']),(True,True,True)))
    r=analyze(roots=['0']);check('missing_original_initial',lambda:eq((r['complete_source_controller'],r['fairness']),(False,None)))
    by=nodes();by['0']['valuation']['good_init']=False;r=analyze(by);check('bad_initial_SYS',lambda:eq((len(r['initial_SYS_AUX_failures']),r['fairness']),(1,None)))
    by=nodes();by['0']['successors']=['0'];r=analyze(by);check('missing_legal_response_retained',lambda:eq((len(r['input_coverage_failures']),r['original_strict_controller']),(1,None)))
    by=nodes();by['1']['valuation']['~envHelp']='true';r=analyze(by);check('helper_true_cannot_fill_input',lambda:a.need(bool(r['input_coverage_failures'])and r['fairness']is None,'Expected helper-false hole'))
    by=nodes();by['2']={'valuation':dict(by['0']['valuation'],tag='2'),'successors':['0','1']};by['0']['successors'].append('2');r=analyze(by);check('distinct_private_ID_ambiguous_response',lambda:a.need(any(x['reason']=='AMBIGUOUS_RESPONSE'for x in r['input_coverage_failures'])and '2'in r['view']['states']and r['fairness']is None,'Keep ambiguity'))
    by=nodes();by['1']['valuation']['bad']=True;r=analyze(by);check('SYS_unsafe_edges_not_pruned',lambda:a.need(bool(r['SYS_AUX_safety_failures'])and len(r['view']['edges'])==4 and r['fairness']is None,'Keep bad edges'))
    by=nodes();by['1']['valuation']['bad']=True;r=analyze(by,Toy({'0':{'false'},'1':{'false'}},{'false'}),['0']);check('original_ENV_illegal_extra_not_SYS_failure',lambda:eq((r['complete_source_controller'],r['view']['states'],r['edge_classification_counts']['EXCLUDED_ORIGINAL_ENV_ILLEGAL']),(True,['0'],1)))
    by=nodes();by['1']['successors']=[];r=analyze(by,Toy({'0':{'false','true'},'1':set()},{'false'}),['0']);check('legal_prefix_deadend_cooperation_false',lambda:eq((r['complete_source_controller'],r['original_strict_controller'],r['original_cooperative_controller'],r['deadends']),(True,True,False,['1'])))
    check('environmental_deadend_has_zero_legal_inputs',lambda:eq((r['environmental_deadends'],r['strategy_deadends'],r['legal_ENV_input_count_by_node']),(['1'],[],{'0':2,'1':0})))
    by=nodes();by['1']['successors']=[];r=analyze(by);check('strategy_deadend_has_unanswered_legal_inputs',lambda:eq((r['environmental_deadends'],r['strategy_deadends'],r['legal_ENV_input_count_by_node'],r['complete_source_controller'],r['fairness']),([],['1'],{'0':2,'1':2},False,None)))
    r=analyze(p=Toy(syslabels=[{'0'}]));check('reachable_rejecting_subcycle',lambda:eq((r['original_strict_controller'],r['original_cooperative_controller']),(False,True)))
    # Exhaust all 2-vertex edge sets and each justice label; separate literal cycles oracle.
    checked=0
    for mask in range(16):
        edges=[['0','0'],['0','1'],['1','0'],['1','1']];es=[e for i,e in enumerate(edges)if mask>>i&1]
        cycles=([{'0'}]if ['0','0']in es else[])+([{'1'}]if ['1','1']in es else[])+([{'0','1'}]if ['0','1']in es and ['1','0']in es else[])
        for labelmask in range(4):
            label={str(i)for i in range(2)if labelmask>>i&1};g={'states':['0','1'],'edges':es,'starts':['0','1'],'env_justice':[],'sys_justice':[sorted(label)]};fr=fairness.analyze_graph(g)
            strict=all(bool(cyc&label)for cyc in cycles);can=set().union(*cycles)if cycles else set()
            if ['0','1']in es and '1'in can:can.add('0')
            if ['1','0']in es and '0'in can:can.add('1')
            eq((fr['strict_liveness']['pass'],fr['nonconflicting']['pass']),(strict,len(can)==2));checked+=1
    check('all64_two_vertex_graph_justice_cases_literal_cycle_oracle',lambda:eq(checked,64))
    g={'states':['0'],'edges':[],'starts':['0'],'env_justice':[],'sys_justice':[['0']]};fr=fairness.analyze_graph(g);check('singleton_deadend_not_stutter',lambda:eq((fr['strict_liveness']['pass'],fr['nonconflicting']['pass']),(True,False)))
    g={'states':['0','1','2'],'edges':[['0','1'],['1','1'],['1','2'],['2','1']],'starts':['0'],'env_justice':[],'sys_justice':[['2']]};fr=fairness.analyze_graph(g);check('whole_SCC_acceptance_does_not_hide_subcycle',lambda:eq(fr['strict_liveness']['pass'],False))
    # Raw-native schema fixtures, using artificial metadata and printer only.
    nm=model(True);co=codec.FieldCodec(nm,True,a.need);rawnodes=[]
    for i,e in enumerate(('false','true')):
        val={n:co.values[n][0]for n in co.names};val.update(b1=e,f1='true');text='<'+', '.join(n+':'+val[n]for n in co.names)+'>'
        rawnodes.append({'id':str(i),'native_id':i,'initial':True,'rank':0,'rank_class':'tau.smlab.syntech.games.gr1.GR1RankInfo','rank_info':'System Justice 0','valuation':val,'bits':{str(k):v for k,v in co.bits(val).items()},'native_bdd_text':text,'successors':['0','1']})
    rg={'schema':'released-kind-complete-native-controller-v1','complete':True,'initialization':'source_initializers','nodes':rawnodes,'edges':[['0','0'],['0','1'],['1','0'],['1','1']],'api_state_count':2,'api_transition_count':4,'model_sha256':'toy','native_memory_identity':7,'rank_domain_size':3};rr={'model_export':{'sha256':'toy'},'native_memory_identity':7}
    printer=''.join('Initial State '+n['id']+' '+n['native_bdd_text']+'\n\tWith successors : 0, 1\n'for n in rawnodes)
    check('artificial_raw_native_integrity',lambda:eq(len(audit.validate_raw(rg,nm,rr,printer,codec,a.need)[0]),2))
    for name,mut in [('bool_rank',lambda g:g['nodes'][0].update(rank=True)),('duplicate_ID',lambda g:g['nodes'][1].update(id='0')),('initial_helper',lambda g:g['nodes'][0]['valuation'].update({'~envHelp':'true'})),('missing_bit',lambda g:g['nodes'][0]['bits'].pop('0')),('duplicate_successor',lambda g:g['nodes'][0]['successors'].append('0')),('dangling_target',lambda g:g['nodes'][0]['successors'].append('9')),('wrong_edge_count',lambda g:g.update(api_transition_count=3)),('wrong_rank_count',lambda g:g.update(rank_domain_size=2)),('wrong_memory',lambda g:g.update(native_memory_identity=8))]:
        bad=deepcopy(rg);mut(bad);reject('raw_'+name,lambda bad=bad:audit.validate_raw(bad,nm,rr,printer,codec,a.need))
    reject('raw_printer_mismatch',lambda:audit.validate_raw(rg,nm,rr,printer.replace('State 0','State 9'),codec,a.need))
    # Authority fixtures are synthetically generated records in this toy output.
    from pathlib import Path
    mh='a'*64;future=(datetime.now(timezone.utc)+timedelta(minutes=5)).isoformat()
    qrefs=[]
    for kind in ('artificial','imports'):
        p=output/('TOY_'+kind+'_RUN.json')
        a.save(p,{'status':'PASS_BDD_GRAPH_REFERENCE_QUALIFICATION','qualification_kind':kind,'scope':a.SCOPE,'case':a.CASE,'frozen_manifest_sha256':mh,'inputs_unchanged':True,'errors':[],'attempts':1,'admitted_scientific_result':False});qrefs.append(a.pin(p))
    refrow={'path':'/TOY_NOT_REAL','bytes':0,'sha256':a.sha(b'')}
    proof={'schema':'lift-preferred-native-provenance-preflight-v1','status':'PASS','case':a.CASE,'created_utc':datetime.now(timezone.utc).isoformat(),'all_pins_verified':True,'stdout_stream_hash_completed':True}
    proof.update({k:dict(refrow)for k in ('source','model','native_result','controller','printer','native_process_receipt','stdout','stderr')})
    proofpath=output/'TOY_PROVENANCE.json';a.save(proofpath,proof)
    go={'schema':'lift-original-bdd-reference-single-go-v1','status':'GO','frozen_manifest_sha256':mh,'scope':a.SCOPE,'case':a.CASE,'output_root':str(output/'NOT_EXECUTED'),'attempts':1,'saved_evaluations':1,'native_calls':0,'solver_calls':0,'fixed_point_calls':0,'deadline_utc':future,'limits':dict(a.LIMITS),'qualification_receipts':qrefs,'native_provenance_receipt':a.pin(proofpath)}
    goindex=0
    def loadtoy(obj):
        nonlocal goindex
        goindex+=1;p=output/('TOY_GO_'+str(goindex)+'.json');a.save(p,obj)
        return a.load_go(p,mh,output/'NOT_EXECUTED')
    check('synthetic_actual_authority_positive_no_execution',lambda:eq(loadtoy(go)[0],go))
    for name,mut in [('missing_provenance',lambda x:x.pop('native_provenance_receipt')),('wrong_case',lambda x:x.update(case='other')),('wrong_scope',lambda x:x.update(scope='other')),('wrong_manifest',lambda x:x.update(frozen_manifest_sha256='b'*64)),('bool_attempt',lambda x:x.update(attempts=True)),('two_attempts',lambda x:x.update(attempts=2)),('saved_budget0',lambda x:x.update(saved_evaluations=0)),('native_budget',lambda x:x.update(native_calls=1)),('solver_budget',lambda x:x.update(solver_calls=1)),('FP_budget',lambda x:x.update(fixed_point_calls=1)),('expired',lambda x:x.update(deadline_utc='2000-01-01T00:00:00+00:00')),('changed_limits',lambda x:x['limits'].update(wall_seconds=61)),('duplicate_qualification',lambda x:x['qualification_receipts'].__setitem__(1,x['qualification_receipts'][0])),('wrong_output',lambda x:x.update(output_root=str(output/'OTHER')))]:
        bad=deepcopy(go);mut(bad);reject('authority_'+name,lambda bad=bad:loadtoy(bad))
    for key,value in [('case','other'),('inputs_unchanged',False),('errors',['toy']),('attempts',True),('admitted_scientific_result',True)]:
        qual={'status':'PASS_BDD_GRAPH_REFERENCE_QUALIFICATION','qualification_kind':'artificial','scope':a.SCOPE,'case':a.CASE,'frozen_manifest_sha256':mh,'inputs_unchanged':True,'errors':[],'attempts':1,'admitted_scientific_result':False};qual[key]=value
        qp=output/('TOY_BAD_QUAL_'+key+'.json');a.save(qp,qual);bad=deepcopy(go);bad['qualification_receipts'][0]=a.pin(qp);reject('authority_bad_qualification_'+key,lambda bad=bad:loadtoy(bad))
    for key,value in [('status','UNKNOWN'),('case','other'),('stdout_stream_hash_completed',False),('all_pins_verified',False)]:
        fake=deepcopy(proof);fake[key]=value;pp=output/('TOY_BAD_PROOF_'+key+'.json');a.save(pp,fake);bad=deepcopy(go);bad['native_provenance_receipt']=a.pin(pp);reject('authority_bad_provenance_'+key,lambda bad=bad:loadtoy(bad))
    original_reader=a.file_bytes;reads=[]
    def denied(path,*args):reads.append(str(path));raise ValueError('Synthetic unclean process')
    a.file_bytes=denied
    try:out=completion(output/'TOY_MISSING',type('F',(),{'manifest_hash':mh})(),'actual',None,True,None)
    finally:a.file_bytes=original_reader
    check('unclean_process_never_reads_worker',lambda:a.need(bool(out['errors'])and len(reads)==1 and reads[0].endswith('PROCESS_RECEIPT.json'),'No worker consumption after process failure'))
    return {'status':'PASS_ARTIFICIAL_BDD_GRAPH_REFERENCE','saved_DAG_evaluations':0,'saved_graph_evaluations':0,'source_equation_evaluations':0,'tests':tests,'test_count':len(tests),'exhaustive_tiny_graph_label_cases':checked,'actual_input_models_or_graphs_decoded':0,'qualification_scope':'Artificial codec, saved-DAG bytes, raw printer and selected-graph fixtures only; no real frozen input decoded or mathematical source_contracts imported.'}
