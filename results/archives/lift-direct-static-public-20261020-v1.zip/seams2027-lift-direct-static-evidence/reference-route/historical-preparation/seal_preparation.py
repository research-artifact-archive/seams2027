"""Metadata-only byte freeze; no scope imports or scientific evaluation."""
from pathlib import Path
import ast, hashlib, json
root=Path(__file__).resolve().parent
target=root/'FROZEN_MANIFEST.json'
if target.exists():raise FileExistsError('No frozen overwrite')
def digest(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
origins=json.loads((root/'REUSE_AND_ORIGINS.json').read_text())
for row in origins['records']:
    wanted={k:row[k]for k in ('bytes','sha256')}
    assert digest((root/row['file']).read_bytes())==wanted
    assert digest(Path(row['origin']).read_bytes())==wanted
rows=[];python_files=[]
for path in sorted(root.rglob('*')):
    assert not path.is_symlink()
    if not path.is_file():assert path.is_dir();continue
    raw=path.read_bytes();assert len(raw)<=4194304
    name=str(path.relative_to(root))
    if path.suffix=='.py':ast.parse(raw.decode(),filename=name);python_files.append(name)
    rows.append({'file':name,**digest(raw)})
value={'schema':'lift-original-bdd-reference-freeze-v1','scope':'original_bdd_selected_graph_reference','case':'lift__preferred','status':'STATIC_FROZEN_AWAITING_INDEPENDENT_REVIEW_AND_PREPARATION_GO','files':rows,'checked_origin_copies':len(origins['records']),'AST_parsed_python_files':python_files,'saved_DAG_evaluations':0,'saved_graph_evaluations':0,'scientific_module_imports':0,'new_native_calls':0,'full_reset_uses':0}
raw=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
with target.open('xb')as f:f.write(raw)
print(json.dumps({'file':str(target),'manifest':digest(raw),'frozen_files':len(rows),'frozen_bytes':sum(r['bytes']for r in rows),'origin_copies':len(origins['records']),'Python_ASTs':len(python_files)}))
