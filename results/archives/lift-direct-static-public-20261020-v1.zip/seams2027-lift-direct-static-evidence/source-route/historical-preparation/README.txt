LiftPreferred: separate direct original-history graph audit preparation

This closure is prepared, not qualified or executed. A new Root authority is required for the two generated/import qualification runs, and another exact authority is required for one saved graph audit. No native, solver or game-region fixed point may be run.

The saved native graph is evidence for a distinct finite-controller proposition. Its original/global relation mapping remains UNKNOWN. The audit uses the byte-identical already qualified original source equations and unchanged finite-fairness checker. It validates raw codec/printer/memory provenance, every original initialized response, every legal original ENV input, complete SYS/AUX safety and ordered justices. Missing/ambiguous responses or unsafe legal responses cause a complete rejection with no strict/cooperative verdict; they are never removed or repaired. All raw nodes, rank, model AUX and excluded edge IDs remain visible.

Environmental dead ends and strategy missing-response dead ends are separate evidence. A legal ENV domain of zero is an environmental dead end. An available legal input with no strategy response is a controller-gate rejection. On a fully valid controller, strict and cooperative properties are reported separately, with finite prefixes and lasso/SCC evidence as appropriate.

INITIALIZATION_COUNTER_CLARIFICATION.json resolves F31's 3072/2048 concern by exact source tracing. Those historical names count unconditional correspondence checks over two carriers, not satisfying initial states. The raw graph's two initial flags are a separate quantity.

Qualified historical metadata and native stdout remain unchanged. Root must provide the specified completed native-provenance receipt after streaming the original captures before the actual GO. Code does not inspect native BDD predicates. Qualification only exercises generated graph data/source assignments plus metadata controls. Future actual output, all qualification outputs, authorities and independent reviews must be outside this immutable directory.

CLI (each path absolute; replace placeholders only after new Root authority):
python3 -I -S -B code/review.py artificial --root ROOT --expected-manifest SHA --output NEW_ARTIFICIAL --preparation-go ROOT_PREPARATION_GO
python3 -I -S -B code/review.py imports --root ROOT --expected-manifest SHA --output NEW_IMPORTS --preparation-go ROOT_PREPARATION_GO --reject-read-root EXISTING_OUTSIDE_DIRECTORY
python3 -I -S -B code/review.py actual --root ROOT --expected-manifest SHA --output NEW_ACTUAL --go ROOT_ACTUAL_GO

Every invocation is single attempt, supervised, 60 seconds/512MiB, 64KiB per output stream, 4MiB per output file, 8MiB output tree, 16MiB reserve above a 1GiB free-disk floor. Full actual scope is described in PREPARATION_SCOPE.json. No automatic retry, reset, cleanup, or publication authority is included.
