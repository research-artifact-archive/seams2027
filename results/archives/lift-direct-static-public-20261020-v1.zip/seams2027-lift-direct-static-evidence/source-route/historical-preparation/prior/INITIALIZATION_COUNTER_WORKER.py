"""Targeted saved-model timing diagnosis; no native process or graph/fixed point."""
from pathlib import Path
from itertools import product
import importlib.util, json, sys, traceback
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('witness_independent_worker',HERE/'audit_worker.py')
w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
need,read_pin,pin,save_new=w.need,w.read_pin,w.pin,w.save_new

def current_invariant_environment(s,t):
    truth=lambda v,n:v[n]=='true'
    if sum(truth(s,n) for n in ('f1','f2','f3'))!=1:return False
    for b,f in zip(('b1','b2','b3'),('f1','f2','f3')):
        if truth(s,b) and truth(s,f) and truth(t,b):return False
        if truth(s,b) and not truth(s,f) and not truth(s,'c') and not truth(t,b):return False
    if truth(s,'c') and all(truth(s,n) for n in ('b1','b2','b3')):return False
    if not truth(s,'f1') and all(truth(s,n) for n in ('b1','b2','b3')):return False
    return True

def load_context(manifest,contract,helper):
    inputs=manifest['inputs'];raw={key:read_pin(ref) for key,ref in inputs.items()}
    need(len(raw['source'])==contract.source_bytes and pin(inputs['source']['path'])['sha256']==contract.source_sha256,'Exact source identity')
    profile=w.decode_json(raw['profile'])['profiles'][contract.candidate]
    model=w.decode_json(raw['model'])
    need(model['schema']=='k7-native-model-export-v1','Exact saved-model schema')
    need(model['fixture_id']==contract.candidate,'Exact saved-model fixture')
    need(model['input']['bytes']==contract.source_bytes and model['input']['sha256']==contract.source_sha256,'Exact saved-model source pin')
    result=w.decode_json(raw['native_result']) if helper else None
    if helper:
        need(result['helper_added'] is True and result['model_export']=={'file':Path(inputs['model']['path']).name,'bytes':inputs['model']['bytes'],'sha256':inputs['model']['sha256']},'Native helper/model export pin')
        need(result['input_sha256']==contract.source_sha256,'Native source pin')
    for ref in manifest['bdd_files'].values():read_pin(ref)
    return w.ModelAudit(manifest,contract,raw,result,model,profile)

def support_names(ctx,root):
    inverse={bit:('next' if prime else 'current',name) for name,field in ctx.field_by_name.items()
             for prime,key in ((False,'current_bits'),(True,'next_bits')) for bit in field[key]}
    return [{'bit':bit,'timing':inverse[bit][0],'name':inverse[bit][1]} for bit in sorted(root.support)]

def analyze(original,reduced,contract,reduced_environment,current_support,next_support,witnesses):
    a,b=load_context(original,contract,False),load_context(reduced,contract,True)
    names=tuple(current_support)+tuple(next_support)
    need(len(set(current_support))==len(current_support) and len(set(next_support))==len(next_support),'Unique support names')
    need(set(current_support)<=set(contract.names) and set(next_support)<=set(contract.env),'Named complete source support carrier')
    need(2**len(names)<=2048,'Support enumeration cap')
    for ctx in (a,b):
        allowed={bit for name in current_support for bit in ctx.field_by_name[name]['current_bits']}
        allowed|={bit for name in next_support for bit in ctx.field_by_name[name]['next_bits']}
        if ctx.helper:allowed|=set(ctx.field_by_name[w.HELPER]['current_bits']+ctx.field_by_name[w.HELPER]['next_bits'])
        need(ctx.native_formulas['rhoE'].support<=allowed,'rhoE unsupported AUX or next SYS variable')
    base={name:contract.values[name][0] for name in contract.names}
    counts={'source_initial_states':0,'native_initial_states':0,'ordered_justice_states':0,'rhoE_support_pairs':0,'rhoE_original_true':0,'rhoE_reduced_true':0,'rhoE_disagreements':0,'original_false_reduced_true':0,'original_true_reduced_false':0}
    orig_states=w.states_for(contract.names,contract.values,1024)
    for ctx in (a,b):
        full=w.states_for(ctx.names,ctx.values,2048)
        for s in full:
            cb=ctx.bits(s)
            need(ctx.native_formulas['thetaE'].value(cb)==(contract.theta_e(s) and (not ctx.helper or s[w.HELPER]=='false')),'Full ENV initialization correspondence')
            counts['native_initial_states']+=1
        for s in orig_states:
            cb=ctx.bits(ctx.native_state(s))
            for k,f in (('thetaE',contract.theta_e),('thetaS',contract.theta_s)):
                need(ctx.native_formulas[k].value(cb)==f(s)==ctx.profile_formulas[k](s),'Source/helper-false initialization correspondence')
            counts['source_initial_states']+=1
        roots={owner:[ctx.dag(ref,ctx.current) for ref in ctx.model['original_justices'][owner]] for owner in ('ENV','SYS')}
        idx=None
        if ctx.helper:
            matches=[i for i,root in enumerate(roots['ENV']) if all(root.value(ctx.bits(s))==(s[w.HELPER]=='false') for s in full)]
            need(len(matches)==1,'Unique helper justice')
            idx=matches[0]
        for s in orig_states:
            cb=ctx.bits(ctx.native_state(s))
            for owner,wanted in zip(('ENV','SYS'),contract.justice(s)):
                relevant=[r for i,r in enumerate(roots[owner]) if not(owner=='ENV' and i==idx)]
                need([r.value(cb) for r in relevant]==wanted==[f(s) for f in ctx.profile_justices[owner]],'Ordered source justice')
            counts['ordered_justice_states']+=1
        for key,allowed in (('domain',ctx.current),('domain_ENV_next',ctx.env_next),('domain_SYS_next',ctx.sys_next)):
            root=ctx.dag(ctx.model['original_bdds'][key],allowed)
            for s in full:need(root.value(ctx.bits(s,key!='domain')),'Full typed domain')
    for values in product(w.BOOL,repeat=len(names)):
        s,t=dict(base),dict(base)
        s.update(zip(current_support,values[:len(current_support)]));t.update(zip(next_support,values[len(current_support):]))
        aa=a.bits(s)|a.bits(t,True);bb=b.bits(b.native_state(s))|b.bits(b.native_state(t),True)
        expected,changed=contract.rho_e(s,t),reduced_environment(s,t)
        need(a.native_formulas['rhoE'].value(aa)==expected==a.profile_formulas['rhoE'](s,t),'Original full-support source relation')
        need(b.profile_formulas['rhoE'](s,t)==expected,'Reduced input profile still original source')
        need(b.native_formulas['rhoE'].value(bb)==changed,'Reduced current-invariant relation characterization')
        counts['rhoE_support_pairs']+=1;counts['rhoE_original_true']+=int(expected);counts['rhoE_reduced_true']+=int(changed)
        counts['rhoE_disagreements']+=int(expected!=changed)
        counts['original_false_reduced_true']+=int(not expected and changed);counts['original_true_reduced_false']+=int(expected and not changed)
    rows=[]
    for witness in witnesses:
        s,t=witness['current'],witness['next']
        need(set(s)==set(t)==set(contract.names),'Complete witness typed/AUX valuations')
        row={'name':witness['name'],'current':s,'next':t,'helper_current':'false','helper_next':'false'}
        for label,ctx in (('original',a),('reduced_helper_false',b)):
            cb=ctx.bits(ctx.native_state(s));nb=ctx.bits(ctx.native_state(t),True)
            row[label]={k:root.value(cb if k.startswith('theta') else cb|nb) for k,root in ctx.native_formulas.items()}
        source={'thetaE':contract.theta_e(s),'thetaS':contract.theta_s(s),'rhoE':contract.rho_e(s,t),'rhoS':contract.rho_s(s,t)}
        row['hand_source']=source;row['profile']={k:f(s,t) for k,f in a.profile_formulas.items()}
        need(row['original']==source==row['profile'],'Witness full original source/profile relation')
        need(row['reduced_helper_false']==dict(source,rhoE=reduced_environment(s,t)),'Witness reduced complete relation')
        for key,expected in witness.get('expected',{}).items():
            label,formula=key.split('.')
            need(row[label][formula] is expected,'Predeclared witness expected truth: '+key)
        row['original_joint_initial']=source['thetaE'] and source['thetaS'];rows.append(row)
    return {'status':'COMPLETE_SAVED_DAG_TIMING_CHARACTERIZATION','candidate_id':contract.candidate,'counts':counts,'witnesses':rows,
            'rhoE_support':{'original':support_names(a,a.native_formulas['rhoE']),'reduced':support_names(b,b.native_formulas['rhoE'])},
            'scope':{'full_rhoE_support_exhausted':True,'full_rhoS_domain_exhausted':False,'rhoS_witnesses_checked':len(rows),'controller_certificate':False,'strict':None,'cooperation':None,'native_processes':0,'region_solves':0,'full_reset_uses':0}}

def execute(manifest):
    need(manifest['schema']=='lift-preferred-mapping-witness-inputs-v1' and manifest['candidate_id']=='lift__preferred','Exact diagnostic manifest schema/candidate')
    original=w.decode_json(read_pin(manifest['original_manifest']));reduced=w.decode_json(read_pin(manifest['reduced_manifest']));protocol=w.decode_json(read_pin(manifest['protocol']))
    need(original['schema']=='remaining-nine-source-model-inputs-v1' and reduced['schema']=='remaining-nine-independent-audit-inputs-v1','Original/reduced input schema')
    need(original['candidate_id']==reduced['candidate_id']==manifest['candidate_id'],'Both original and reduced exact candidate')
    witnesses=[]
    for p in protocol['witnesses']:
        witnesses.append({'name':p['name'],'current':p['current'],'next':p['next'],'expected':{'original.rhoE':p['prospective_expected_original_rhoE'],'reduced_helper_false.rhoE':p['prospective_expected_reduced_rhoE']}})
    for seed in list(witnesses):
        witnesses.append({'name':seed['name']+'_exact_current_next_reverse','current':seed['next'],'next':seed['current']})
        for side in ('current','next'):
            x={'name':seed['name']+'_flip_'+side+'_c','current':dict(seed['current']),'next':dict(seed['next'])}
            x[side]['c']='false' if x[side]['c']=='true' else 'true';witnesses.append(x)
    result=analyze(original,reduced,w.CONTRACTS['lift__preferred'],current_invariant_environment,('b1','b2','b3','c','f1','f2','f3'),('b1','b2','b3','c'),witnesses)
    need(result['witnesses'][0]['original_joint_initial'] is True,'First witness from original joint initial state')
    need(result['witnesses'][0]['original']['rhoS'] is True and result['witnesses'][1]['original']['rhoS'] is True,'Both declared timing witnesses satisfy SYS relation')
    result['input_bindings']=manifest;result['original_input_bindings']=original;result['reduced_input_bindings']=reduced
    return result

def main():
    output=Path(sys.argv[2]);output.mkdir()
    try:
        manifest=w.decode_json(Path(sys.argv[1]).read_bytes());result=execute(manifest)
        result['input_manifest_pin']=pin(sys.argv[1]);result['code_pins']=[pin(HERE/n) for n in ('witness_worker.py','audit_worker.py','source_contracts.py','independent_core.py')]
        exit_code=0
    except BaseException as error:
        result={'status':'UNKNOWN_SAVED_DAG_TIMING_CHARACTERIZATION','error':type(error).__name__+':'+str(error),'traceback':traceback.format_exc()};exit_code=2
    save_new(output/'WITNESS_RESULT.json',result);print(json.dumps({'status':result['status']}),flush=True);return exit_code
if __name__=='__main__':sys.exit(main())
