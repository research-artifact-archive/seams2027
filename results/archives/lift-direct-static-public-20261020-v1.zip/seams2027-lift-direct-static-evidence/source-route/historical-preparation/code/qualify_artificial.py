"""Generated hand-expected qualifications; no saved graph is interpreted."""
from copy import deepcopy
from types import SimpleNamespace
from datetime import datetime, timezone, timedelta
from pathlib import Path


def run(frozen, output, a, core, sources, audit, pv, completion):
    checks = []
    def check(name, thunk, expected=True):
        try:
            value = thunk(); a.exact(value, expected, name)
            checks.append({'name': name, 'pass': True})
        except BaseException as error:
            checks.append({'name': name, 'pass': False, 'error': repr(error)})
    def rejects(name, thunk):
        def attempt():
            try: thunk()
            except (ValueError, KeyError, TypeError, IndexError): return True
            return False
        check(name, attempt)
    c = sources.CONTRACTS[a.CASE]; monitors = [name for name, _ in c.aux]
    def state(**changes):
        value = {n: 'false' for n in c.env + c.system}
        value['f1'] = 'true'; value.update({n: 'S0' for n in monitors}); value.update(changes)
        return value
    def env(**changes): return {n: state(**changes)[n] for n in c.env}
    def floors(number, **changes):
        value = state(f1='false', f2='false', f3='false', **changes)
        value['f'+str(number)] = 'true'; return value
    def mon(index, current, nxt, request, response):
        return sources.response_update(current, nxt, monitors[index], request, response)
    check('source_initial_c_free', lambda: [c.theta_e(env(c=x)) for x in sources.BOOL], [True, True])
    check('source_initial_button_pressed', lambda: c.theta_e(env(b1='true')), False)
    check('source_system_initial', lambda: c.theta_s(state()))
    check('source_initial_monitor_pending', lambda: c.theta_s(state(**{monitors[1]: 'S1'})), False)
    check('source_original_next_pure_ENV_rejection', lambda: c.rho_e(state(), env(b1='true', b2='true', b3='true', c='true')), False)
    check('source_original_next_pure_ENV_allows_c_false', lambda: c.rho_e(state(), env(b1='true', b2='true', b3='true')))
    check('source_current_pure_ENV_not_reinserted', lambda: c.rho_e(state(b1='true', b2='true', b3='true', c='true'), env()))
    check('source_mixed_current_floor_clause', lambda: c.rho_e(floors(2, b1='true', b2='true', b3='true', c='true'), env()), False)
    check('source_current_one_floor_failure', lambda: c.rho_e(state(f2='true'), env()), False)
    check('source_served_button_clears', lambda: c.rho_e(state(b1='true', c='true'), env(b1='true')), False)
    check('source_unserved_button_persists', lambda: c.rho_e(state(b2='true'), env()), False)
    check('source_current_c_releases_persistence', lambda: c.rho_e(state(b2='true', c='true'), env()))
    check('source_next_c_does_not_release', lambda: c.rho_e(state(b2='true'), env(c='true')), False)
    check('source_move_reads_current_buttons', lambda: c.rho_s(state(), floors(2, b2='true')), False)
    check('source_request_floor2_moves_to2', lambda: c.rho_s(state(b2='true'), floors(2, **{monitors[1]: 'S1'})))
    check('source_current_c_permits_stay', lambda: c.rho_s(state(b2='true', c='true'), state()))
    check('source_monitor_current_request', lambda: mon(1, state(b2='true'), floors(2, **{monitors[1]: 'S1'}), True, False))
    check('source_next_floor_cannot_clear_current_pending', lambda: mon(1, state(b2='true'), floors(2), True, False), False)
    check('source_next_request_does_not_trigger', lambda: mon(1, state(), state(b2='true'), False, False))
    check('source_pending_without_request_persists', lambda: mon(1, state(**{monitors[1]: 'S1'}), state(**{monitors[1]: 'S1'}), False, False))
    check('source_current_c_clears_pending', lambda: mon(1, state(c='true', **{monitors[1]: 'S1'}), state(), False, True))
    check('source_next_c_does_not_clear', lambda: mon(1, state(**{monitors[1]: 'S1'}), state(c='true'), False, False), False)
    check('source_justice_order', lambda: list(c.justice(state(**{monitors[1]: 'S1'}))), [[], [True, False, True]])

    def toy_contract():
        return SimpleNamespace(names=('e', 's', 'm'), env=('e',), system=('s',), aux=(('m', sources.BOOL),),
             values={n: sources.BOOL for n in ('e', 's', 'm')},
             theta_e=lambda e: True, theta_s=lambda s: s['s'] == s['m'] == 'false',
             rho_e=lambda s, t: True, rho_s=lambda s, t: t['s'] == 'false',
             justice=lambda s: ([], [s['m'] == 'false']))
    def node(i, e='false', s='false', m='false', helper='false', initial=False, targets=()):
        return {'id': str(i), 'native_id': i, 'initial': initial, 'rank': 0,
                'rank_class': 'tau.smlab.syntech.games.gr1.GR1RankInfo', 'rank_info': 'System Justice 0',
                'valuation': {'e': e, audit.HELPER: helper, 's': s, 'm': m},
                'successors': [str(x) for x in targets]}
    def fixture():
        return toy_contract(), {'0': node(0, initial=True, targets=(0, 1)),
                                '1': node(1, e='true', initial=True, targets=(0, 1))}
    def evaluate(contract, nodes):
        edges = [(i, target) for i, n in nodes.items() for target in n['successors']]
        starts = [i for i, n in nodes.items() if n['initial']]
        return audit.source_history(nodes, edges, starts, contract, core, a.need)
    def altered(mutator, inspect):
        contract, nodes = fixture(); mutator(contract, nodes)
        result, view = evaluate(contract, nodes); return inspect(result, view)
    def outcome(result, view):
        return [result['complete_source_controller'], result['original_strict_controller'], result['original_cooperative_controller']]
    check('graph_complete_total_cycle', lambda: altered(lambda c,n: None, outcome), [True, True, True])
    check('graph_missing_initial_input', lambda: altered(lambda c,n: n['1'].update(initial=False),
          lambda r,v: not r['complete_source_controller'] and r['initial_response_failures'][0]['input'] == {'e':'true'} and r['fairness'] is None))
    def duplicate_initial(c, n): n['2'] = node(2, initial=True, targets=(0,1)); n['2']['rank'] = 1
    check('graph_duplicate_initial_private_rank', lambda: altered(duplicate_initial,
          lambda r,v: not r['complete_source_controller'] and len(r['initial_response_failures'][0]['responses']) == 2 and '2' in v['states']))
    check('graph_initial_SYS_or_AUX_invalid', lambda: altered(lambda c,n: n['0']['valuation'].update(m='true'),
          lambda r,v: bool(r['initial_SYS_AUX_failures']) and r['original_strict_controller'] is None))
    check('graph_legal_input_hole', lambda: altered(lambda c,n: n['0'].update(successors=['0']),
          lambda r,v: r['input_coverage_failures'][0]['reason'] == 'MISSING_RESPONSE' and r['input_coverage_failures'][0]['prefix'] == ['0']))
    def helper_hole(c, n):
        n['2'] = node(2, e='true', helper='true', targets=(0,1)); n['0']['successors'] = ['0','2']
    check('graph_helper_true_does_not_fill_hole', lambda: altered(helper_hole,
          lambda r,v: bool(r['input_coverage_failures']) and '2' not in v['states']))
    def duplicate_response(c, n):
        n['2'] = node(2, e='true', targets=(0,1)); n['0']['successors'].append('2')
    check('graph_duplicate_private_response', lambda: altered(duplicate_response,
          lambda r,v: r['input_coverage_failures'][0]['reason'] == 'AMBIGUOUS_RESPONSE' and ['0','2'] in v['edges']))
    def rank_preservation(c, n):
        duplicate_response(c,n); n['2']['rank'] = 1; n['2']['successors'] = ['2']
    check('graph_same_input_distinct_rank_no_quotient', lambda: altered(rank_preservation,
          lambda r,v: any(x['id']=='2' and x['rank']==1 and x['successors']==['2'] for x in v['native_nodes']) and not r['complete_source_controller']))
    def illegal_extra(c, n):
        c.theta_e = lambda e: e['e']=='false'; c.rho_e = lambda s,t:t['e']=='false'
        n['1']['initial'] = False; n['1']['valuation']['s'] = 'true'
    check('graph_original_illegal_extra_edge', lambda: altered(illegal_extra,
          lambda r,v: r['complete_source_controller'] and not r['SYS_AUX_safety_failures'] and v['states']==['0']
          and r['edge_classification_counts']['EXCLUDED_ORIGINAL_ENV_ILLEGAL']==1))
    def unsafe_edge(c,n):
        n['2'] = node(2, e='true', s='true', targets=(0,1)); n['0']['successors'] = ['0','2']
    check('graph_source_legal_bad_SYS_edge', lambda: altered(unsafe_edge,
          lambda r,v: bool(r['SYS_AUX_safety_failures']) and ['0','2'] in v['edges'] and '2' in v['states'] and r['fairness'] is None))
    def helper_only(c,n):
        n['2'] = node(2, helper='true', targets=(2,)); n['0']['successors'].append('2')
    check('graph_unreachable_under_original_assumptions', lambda: altered(helper_only,
          lambda r,v: r['complete_source_controller'] and '2' not in v['states'] and len(v['raw_edge_classifications'])==6))
    def empty_env(c,n): c.rho_e = lambda s,t:s['e']=='false'
    check('graph_empty_source_ENV_domain', lambda: altered(empty_env,
          lambda r,v: r['complete_source_controller'] and r['source_legal_view']['deadends']==['1'] and r['original_cooperative_controller'] is False))
    check('graph_environmental_deadend_classified', lambda: altered(empty_env,
          lambda r,v: r['source_legal_view']['environmental_deadends']==['1']
          and r['source_legal_view']['strategy_deadends']==[] and v['legal_ENV_choice_counts']['1']==0))
    check('graph_strategy_deadend_is_coverage_rejection', lambda: altered(lambda c,n:n['0'].update(successors=[]),
          lambda r,v: r['source_legal_view']['strategy_deadends']==['0']
          and r['source_legal_view']['environmental_deadends']==[] and not r['complete_source_controller']
          and r['fairness'] is None and v['legal_ENV_choice_counts']['0']==2))
    def singleton(loop, justice=True, env_justice=False):
        c,n=fixture();c.theta_e=lambda e:e['e']=='false';n={'0':node(0,initial=True,targets=(0,)if loop else ())}
        c.rho_e=lambda s,t:loop and t['e']=='false';c.justice=lambda s:([False]if env_justice else [],[justice])
        return evaluate(c,n)
    check('graph_singleton_deadend', lambda: outcome(*singleton(False)), [True, True, False])
    check('graph_singleton_self_loop', lambda: outcome(*singleton(True)), [True, True, True])
    check('graph_cycle_missing_SYS_justice', lambda: outcome(*singleton(True, False)), [True, False, True])
    def subcycle(c,n):
        n['1']['initial']=False;n['0']['valuation']['m']='true'
        c.theta_e=lambda e:e['e']=='false';c.theta_s=lambda s:True
        n['1']['successors']=['0'];c.rho_e=lambda s,t:s['e']=='false' or t['e']=='false'
    check('graph_accepting_full_SCC_contains_rejecting_subcycle', lambda: altered(subcycle,
          lambda r,v: r['complete_source_controller'] and not r['original_strict_controller']
          and r['original_cooperative_controller'] and r['strict_liveness_traces'][0]['cycle']==['0','0']))
    def unreachable_cycle(c,n):
        c.theta_e=lambda e:e['e']=='false';c.rho_e=lambda s,t:False;n['1']['initial']=False;n['1']['successors']=['1']
    check('graph_unreachable_accepting_cycle', lambda: altered(unreachable_cycle,
          lambda r,v:r['complete_source_controller'] and not r['original_cooperative_controller'] and v['states']==['0']))
    def branch_deadend(c,n):
        n['1']['initial']=False;c.theta_e=lambda e:e['e']=='false';c.rho_e=lambda s,t:s['e']=='false';n['1']['successors']=[]
    check('graph_branch_to_deadend', lambda: altered(branch_deadend,
          lambda r,v:r['complete_source_controller'] and not r['original_cooperative_controller']
          and r['deadend_traces']==[{'state':'1','prefix':['0','1']}]))
    check('graph_ENV_fairness_general_core', lambda: outcome(*singleton(True, True, True)), [True, True, False])
    check('graph_old_mapping_failure_not_result', lambda: altered(lambda c,n: None,
          lambda r,v:r['status']=='COMPLETE_DIRECT_ORIGINAL_GRAPH_CERTIFICATE'))
    def next_sys(c,n): c.rho_e=lambda s,t:t['s']=='false'
    rejects('graph_oracle_next_SYS_access_rejected', lambda: altered(next_sys, outcome))
    rejects('graph_nonboolean_source_predicate_rejected', lambda: altered(lambda c,n:setattr(c,'rho_e',lambda s,t:1),outcome))

    def raw_fixture():
        c,n=fixture();names=c.env+(audit.HELPER,)+c.system+tuple(x for x,_ in c.aux)
        fields=[]
        for i,name in enumerate(names):
            owner='ENV'if name in c.env+(audit.HELPER,)else'SYS';role=owner if name in c.env+(audit.HELPER,)+c.system else'AUX'
            fields.append({'name':name,'owner':owner,'role':role,'domain_size':2,'values':list(sources.BOOL),
                           'current_bits':[2*i],'next_bits':[2*i+1],
                           'encoding':{value:{'current':{str(2*i):value=='true'},'next':{str(2*i+1):value=='true'}}for value in sources.BOOL}})
        model={'fields':fields,'all_current_bits':[0,2,4,6],'all_next_bits':[1,3,5,7],
               'bdd_variable_count':8,'bdd_variable_order':list(range(8)),
               'public_fields':{'ENV':['e',audit.HELPER],'SYS':['s']},'original_justices':{'SYS':[{}]}}
        printed=[]
        for x in n.values():
            x['bits']={str(2*i):x['valuation'][name]=='true'for i,name in enumerate(names)}
            x['native_bdd_text']='<'+', '.join(name+':'+x['valuation'][name]for name in names)+'>'
            printed.extend([('Initial State 'if x['initial']else'State ')+x['id']+' '+x['native_bdd_text'],
                            '\tWith successors : '+', '.join(x['successors'])])
        graph={'schema':'released-kind-complete-native-controller-v1','complete':True,'initialization':'source_initializers',
               'model_sha256':'metadata-hash','native_memory_identity':1,'rank_domain_size':1,
               'api_state_count':2,'api_transition_count':4,'nodes':list(n.values()),'edges':[[i,t]for i,x in n.items()for t in x['successors']]}
        result={'model_export':{'sha256':'metadata-hash'},'native_memory_identity':1,
                'same_native_memory_passed_to_constructor':True,'same_native_model_passed_to_constructor':True,
                'controller_before_print_sha256':'same','controller_after_print_sha256':'same'}
        return graph,'\n'.join(printed)+'\n',model,result,c
    def raw_run(mutate=None):
        g,p,m,r,c=raw_fixture()
        if mutate: g,p,m,r=mutate(g,p,m,r)
        answer=audit.raw_graph(g,p,m,r,c,a.need);return [len(answer[0]),len(answer[1]),len(answer[2])]
    check('raw_complete_generated_printer_binding',raw_run,[2,4,2])
    def mut(fn):
        def change(g,p,m,r):fn(g,m,r);return g,p,m,r
        return change
    rejects('raw_dangling_or_duplicate_edge',lambda:raw_run(mut(lambda g,m,r:g['nodes'][0]['successors'].append('1'))))
    rejects('raw_printer_identity_mismatch',lambda:raw_run(lambda g,p,m,r:(g,p.replace('Initial State 0','Initial State 7'),m,r)))
    rejects('raw_before_after_digest_mismatch',lambda:raw_run(mut(lambda g,m,r:r.update(controller_after_print_sha256='changed'))))
    rejects('raw_typed_AUX_owner_mutation',lambda:raw_run(mut(lambda g,m,r:m['fields'][-1].update(owner='ENV'))))
    rejects('raw_typed_bit_value_mutation',lambda:raw_run(mut(lambda g,m,r:g['nodes'][0]['bits'].update({'0':True}))))
    rejects('raw_bool_rank_rejected',lambda:raw_run(mut(lambda g,m,r:g['nodes'][0].update(rank=False))))
    rejects('raw_missing_field_rejected',lambda:raw_run(mut(lambda g,m,r:g['nodes'][0]['valuation'].pop('m'))))
    rejects('raw_duplicate_encoding_rejected',lambda:raw_run(mut(lambda g,m,r:m['fields'][0]['encoding']['true']['current'].update({'0':False}))))
    rejects('raw_edge_array_mismatch',lambda:raw_run(mut(lambda g,m,r:g['edges'].pop())))
    rejects('raw_count_bool_rejected',lambda:raw_run(mut(lambda g,m,r:g.update(api_state_count=True))))
    rejects('raw_initial_helper_true_rejected',lambda:raw_run(mut(lambda g,m,r:g['nodes'][0]['valuation'].update({audit.HELPER:'true'}))))
    rejects('strict_JSON_duplicate_key',lambda:a.decode(b'{"x":1,"x":2}'))
    rejects('strict_JSON_nonfinite',lambda:a.decode(b'{"x":NaN}'))
    rejects('typed_exact_bool_int',lambda:a.exact(True,1))
    rejects('unsafe_relative_path',lambda:a.relative_name('../source'))
    rejects('wrong_frozen_manifest',lambda:a.Frozen(frozen.root,'0'*64))
    check('saved_DAG_constructor_blocked',lambda:_blocked_DAG(core))
    qrefs=[]
    qbase={'status':'PASS_DIRECT_GRAPH_QUALIFICATION','scope':a.SCOPE,'case':a.CASE,
           'frozen_manifest_sha256':frozen.manifest_hash,'inputs_unchanged':True,'errors':[],
           'attempts':1,'admitted_scientific_result':False}
    for kind in ('artificial','imports'):
        path=output/(kind+'_generated_receipt.json');a.save(path,dict(qbase,qualification_kind=kind));qrefs.append(a.pin(path))
    copies={row['file']:row for row in frozen.read('COPY_RECEIPT.json')['files']}
    proof={'schema':'lift-preferred-native-provenance-preflight-v1','status':'PASS','case':a.CASE,
           'created_utc':datetime.now(timezone.utc).isoformat(),'all_pins_verified':True,'stdout_stream_hash_completed':True}
    for key,name in [('source','source.spectra'),('model','model.json'),('native_result','result.json'),
                     ('controller','controller.json'),('printer','controller.txt'),('native_process_receipt','PROCESS_RECEIPT.json')]:
        row=copies['inputs/'+name];proof[key]={'path':row['origin'],'bytes':row['bytes'],'sha256':row['sha256']}
    native_process=frozen.read('inputs/PROCESS_RECEIPT.json')
    for name in ('stdout','stderr'):
        row=native_process['capture'][name]
        proof[name]={'path':str(Path(proof['native_process_receipt']['path']).parent/(name+'.txt')),
                     'bytes':row['bytes'],'sha256':row['sha256']}
    proof_path=output/'generated_not_real_provenance.json';a.save(proof_path,proof)
    go={'schema':'lift-preferred-direct-original-graph-single-go-v1','status':'GO',
        'frozen_manifest_sha256':frozen.manifest_hash,'scope':a.SCOPE,'case':a.CASE,
        'output_root':str(output/'never_execute_toy_output'),'attempts':1,'saved_evaluations':1,
        'native_calls':0,'solver_calls':0,'fixed_point_calls':0,
        'deadline_utc':(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat(),
        'limits':dict(a.LIMITS),'qualification_receipts':qrefs,'native_provenance_receipt':a.pin(proof_path)}
    authority_index=[0]
    def check_go(value):
        authority_index[0]+=1;path=output/('generated_authority_'+str(authority_index[0])+'.json');a.save(path,value)
        a.load_go(path,frozen,output/'never_execute_toy_output');return True
    check('generated_metadata_authority_accepted_without_execution',lambda:check_go(go))
    for key,value in [('attempts',True),('saved_evaluations',2),('native_calls',1),('scope','old_scope'),
                      ('case','wrong_case'),('frozen_manifest_sha256','0'*64),('qualification_receipts',qrefs[:1]),
                      ('deadline_utc','2000-01-01T00:00:00+00:00')]:
        rejects('authority_rejects_'+key,lambda key=key,value=value:check_go(dict(go,**{key:value})))
    for key,value in [('case','wrong_case'),('inputs_unchanged',False),('errors',['problem']),('attempts',True),('admitted_scientific_result',True)]:
        def bad_qualification(key=key,value=value):
            path=output/('generated_bad_qualification_'+key+'.json');a.save(path,dict(qbase,qualification_kind='artificial',**{key:value}))
            return check_go(dict(go,qualification_receipts=[a.pin(path),qrefs[1]]))
        rejects('authority_bad_qualification_'+key,bad_qualification)
    def bad_provenance():
        changed=deepcopy(proof);changed['stdout']['sha256']='0'*64
        path=output/'generated_bad_native_capture.json';a.save(path,changed)
        return check_go(dict(go,native_provenance_receipt=a.pin(path)))
    rejects('authority_native_capture_binding_mismatch',bad_provenance)
    proc={'schema':'contained-stage-process-v2','status':'PROCESS_COMPLETED','exit_code':0,
          'process_started':True,'owned_child_reaped':True,'receipt_persisted':True,
          'parent_finalization_completed':True,'parent_aborted':False,
          'exact_child_wait4':{'exact_child_reaped':True,'authority_lost':False},
          'final_group_observation':{'state':'ABSENT'},'fatal_reasons':[],'resource_reasons':[],
          'capture':{name:{'file':name+'.txt','bytes':0,'sha256':a.sha(b''),'complete':True,
                           'observed_bytes':0,'captured_bytes':0}for name in ('stdout','stderr')}}
    check('exact_child_complete_process',lambda:pv.valid_process(proc))
    check('exact_child_bool_exit_rejected',lambda:pv.valid_process(dict(proc,exit_code=False)),False)
    check('exact_child_unreaped_rejected',lambda:pv.valid_process(dict(proc,owned_child_reaped=False)),False)
    def capture_mutation():
        folder=output/'generated_capture';(folder/'process').mkdir(parents=True);(folder/'worker').mkdir()
        process=deepcopy(proc)
        for name,raw in [('stdout',b'abc'),('stderr',b'')]:
            (folder/'process'/(name+'.txt')).write_bytes(raw)
            process['capture'][name].update(a.digest(raw),observed_bytes=len(raw),captured_bytes=len(raw))
        a.save(folder/'process/PROCESS_RECEIPT.json',process)
        result={'status':'PASS_IMPORT_ONLY','scope':a.SCOPE,'case':a.CASE,'frozen_manifest_sha256':'3'*64,
                'saved_DAG_evaluations':0,'saved_graph_evaluations':0,
                'execution_events':{'audit_entries':0,'blocked_saved_DAG_calls':0,'blocked_native_library_loads':0},
                'guard':{'external_data_reads_blocked':1,'network_process_attempts_blocked':0}}
        a.save(folder/'worker/RESULT.json',result)
        a.save(folder/'worker/WORKER_COMPLETE.json',dict(result,all_inputs_unchanged=True,kind='imports',result=a.pin(folder/'worker/RESULT.json')))
        fake=SimpleNamespace(manifest_hash='3'*64)
        good=completion(folder,fake,'imports',process,True,None)
        a.need(good['status']=='PASS_DIRECT_GRAPH_QUALIFICATION','Generated completion accepted')
        (folder/'process/stdout.txt').write_bytes(b'xyz')
        bad=completion(folder,fake,'imports',process,True,None)
        return bad['status']=='UNKNOWN_DIRECT_GRAPH_SCOPE_NOT_ADMITTED' and any(x['phase']=='owned_process'for x in bad['errors'])
    check('parent_same_length_capture_mutation_rejected',capture_mutation)
    report={'schema':'lift-direct-generated-qualification-v1',
            'status':'PASS_ARTIFICIAL_DIRECT_GRAPH_QUALIFICATION'if all(x['pass']for x in checks)else'FAIL_ARTIFICIAL_DIRECT_GRAPH_QUALIFICATION',
            'checks':checks,'passed':sum(x['pass']for x in checks),'total':len(checks),
            'saved_graph_evaluations':0,'saved_DAG_evaluations':0,'native_calls':0,
            'independent_hand_case_document':a.digest(frozen.raw('qualification/HAND_CASES.json')),
            'scope':'Generated source assignments and generated graph fixtures only. No saved graph/model predicate interpreted.'}
    a.save(output/'QUALIFICATION.json',report)
    return report


def _blocked_DAG(core):
    try: core.SavedDag(b'',1,[0])
    except RuntimeError:return True
    return False
