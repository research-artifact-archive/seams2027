"""Direct certificate for the original-ENV-legal histories of a saved graph.

No BDD is interpreted and no relation-correspondence gate is changed. The raw
graph is immutable evidence. Only the source environment assumption determines
which helper-false histories belong to this distinct certificate scope.
"""
from collections import deque
from itertools import product
import hashlib

MAX_NODES = 4096
MAX_EDGES = 65536
MAX_INPUT_CHECKS = 65536
HELPER = '~envHelp'


def typed_fields(model, contract, need):
    names = contract.env + (HELPER,) + contract.system + tuple(n for n, _ in contract.aux)
    values = dict(contract.values, **{HELPER: ('false', 'true')})
    fields = model['fields']
    need([f['name'] for f in fields] == list(names), 'Exact native field order including helper/AUX')
    current, successor = set(), set()
    for field in fields:
        name = field['name']
        owner = 'ENV' if name in contract.env + (HELPER,) else 'SYS'
        role = owner if name in contract.env + (HELPER,) + contract.system else 'AUX'
        need(field['owner'] == owner and field['role'] == role, 'Field owner/role')
        need(type(field['domain_size']) is int and field['domain_size'] == 2
             and field['values'] == list(values[name]), 'Exact typed two-valued domain')
        cb, nb = field['current_bits'], field['next_bits']
        need(type(cb) is list and type(nb) is list and len(cb) == len(nb) == 1
             and type(cb[0]) is int and type(nb[0]) is int and min(cb + nb) >= 0
             and cb != nb and not (set(cb + nb) & (current | successor)), 'Disjoint current/next encoding')
        current.update(cb); successor.update(nb)
        need(set(field['encoding']) == set(values[name]), 'Full typed encoding roster')
        for phase, bits in [('current', cb), ('next', nb)]:
            encoded = []
            for value in values[name]:
                mapping = field['encoding'][value][phase]
                need(set(mapping) == {str(bits[0])} and type(mapping[str(bits[0])]) is bool,
                     'Typed Boolean encoding')
                encoded.append(mapping[str(bits[0])])
            need(set(encoded) == {False, True}, 'Bijective typed encoding')
    for key, wanted in [('all_current_bits', current), ('all_next_bits', successor)]:
        row = model[key]
        need(type(row) is list and all(type(x) is int for x in row)
             and len(row) == len(set(row)) and set(row) == wanted, 'Exact model bit roster')
    count, order = model['bdd_variable_count'], model['bdd_variable_order']
    need(type(count) is int and 0 < count <= 64 and current | successor == set(range(count)), 'Complete bit carrier')
    need(type(order) is list and len(order) == count and all(type(x) is int for x in order)
         and set(order) == set(range(count)), 'Native variable permutation metadata')
    need(model['public_fields'] == {'ENV': list(contract.env) + [HELPER], 'SYS': list(contract.system)},
         'Original public fields plus explicit ENV helper')
    return names, values, {f['name']: f for f in fields}


def raw_graph(graph, printed, model, result, contract, need):
    names, values, fields = typed_fields(model, contract, need)
    need(graph['schema'] == 'released-kind-complete-native-controller-v1' and graph['complete'] is True
         and graph['initialization'] == 'source_initializers', 'Complete raw original-initialized graph')
    need(graph['model_sha256'] == result['model_export']['sha256']
         and graph['native_memory_identity'] == result['native_memory_identity'], 'Native graph/model/memory identity')
    need(result['same_native_memory_passed_to_constructor'] is True
         and result['same_native_model_passed_to_constructor'] is True
         and result['controller_before_print_sha256'] == result['controller_after_print_sha256'], 'Unchanged extraction/printer identity')
    rank_count = len(model['original_justices']['SYS'])
    need(type(graph['rank_domain_size']) is int and graph['rank_domain_size'] == rank_count > 0,
         'Exact native rank domain metadata')
    nodes, flat, by_id = graph['nodes'], [], {}
    need(type(nodes) is list and 0 < len(nodes) <= MAX_NODES
         and type(graph['api_state_count']) is int and len(nodes) == graph['api_state_count'], 'Raw node count/cap')
    lines = printed.splitlines()
    need(len(lines) == 2 * len(nodes), 'Complete printer line count')
    for index, node in enumerate(nodes):
        identity = str(index)
        need(node['id'] == identity and type(node['native_id']) is int and node['native_id'] == index,
             'Ordered distinct native IDs')
        need(type(node['initial']) is bool and type(node['rank']) is int and 0 <= node['rank'] < rank_count
             and node['rank_class'] == 'tau.smlab.syntech.games.gr1.GR1RankInfo'
             and type(node['rank_info']) is str, 'Native rank/private-memory fields')
        state = node['valuation']
        need(type(state) is dict and set(state) == set(names), 'Complete raw native valuation')
        bits = {}
        for name in names:
            need(type(state[name]) is str and state[name] in values[name], 'Typed native value')
            bits.update(fields[name]['encoding'][state[name]]['current'])
        need(type(node['bits']) is dict and all(type(v) is bool for v in node['bits'].values())
             and node['bits'] == bits, 'Raw bit/value identity')
        successors = node['successors']
        need(type(successors) is list and all(type(v) is str for v in successors)
             and len(successors) == len(set(successors)), 'Unique ordered successors')
        prefix = ('Initial State ' if node['initial'] else 'State ') + identity + ' '
        need(lines[2*index].startswith(prefix + '<') and lines[2*index].endswith('>'), 'Printed raw ID/initial')
        body = lines[2*index][len(prefix):]
        need(body == node['native_bdd_text'], 'Exact raw printed valuation string')
        pairs = [item.split(':') for item in body[1:-1].split(', ')]
        need(all(len(pair) == 2 for pair in pairs) and len(pairs) == len(dict(pairs))
             and dict(pairs) == state, 'Printed full typed valuation identity')
        line = '\tWith successors : ' + ', '.join(successors) if successors else '\tWith no successors.'
        need(lines[2*index+1] == line, 'Exact printed ordered successor list')
        by_id[identity] = node
        flat.extend((identity, target) for target in successors)
    need(type(graph['api_transition_count']) is int and len(flat) == graph['api_transition_count']
         and len(flat) == len(set(flat)) <= MAX_EDGES and [list(e) for e in flat] == graph['edges']
         and all(target in by_id for _, target in flat), 'Complete closed raw edge export/cap')
    initial = [n['id'] for n in nodes if n['initial']]
    need(initial and all(by_id[i]['rank'] == 0 and by_id[i]['valuation'][HELPER] == 'false' for i in initial),
         'Raw source-initial memory/helper values')
    reached, queue = set(initial), deque(initial)
    while queue:
        for target in by_id[queue.popleft()]['successors']:
            if target not in reached:
                reached.add(target); queue.append(target)
    need(reached == set(by_id), 'Raw graph has no unreachable extra nodes')
    return by_id, flat, initial


def path_from_parents(target, parents):
    path = [target]
    while parents[path[-1]] is not None:
        path.append(parents[path[-1]])
    return list(reversed(path))


def find_path(start, target, adjacency, allowed):
    queue, parents = deque([start]), {start: None}
    while queue:
        current = queue.popleft()
        if current == target:
            return path_from_parents(current, parents)
        for nxt in adjacency[current]:
            if nxt in allowed and nxt not in parents:
                parents[nxt] = current; queue.append(nxt)
    raise ValueError('Required SCC path missing')


def lasso(component, adjacency, parents, env_labels):
    allowed = set(component); start = min(component, key=int)
    cycle, current = [start], start
    for label in env_labels:
        target = min(allowed & set(label), key=int)
        part = find_path(current, target, adjacency, allowed)
        cycle.extend(part[1:]); current = target
    cycle.extend(find_path(current, start, adjacency, allowed)[1:])
    if len(cycle) == 1:
        neighbor = next(x for x in adjacency[start] if x in allowed)
        cycle.append(neighbor)
        cycle.extend(find_path(neighbor, start, adjacency, allowed)[1:])
    return {'prefix': path_from_parents(start, parents), 'cycle': cycle}


def source_history(by_id, flat, initial, contract, core, need):
    """Analyze all source-legal histories; SYS failures are retained in the BFS."""
    names, env_names = contract.names, contract.env
    original = {i: {n: node['valuation'][n] for n in names} for i, node in by_id.items()}
    inputs = [dict(zip(env_names, row)) for row in product(*(contract.values[n] for n in env_names))]
    need(len(by_id) * len(inputs) <= MAX_INPUT_CHECKS, 'Bounded original-input enumeration')
    counters = {'source_theta_ENV': 0, 'source_theta_SYS': 0, 'source_rho_ENV': 0,
                'source_rho_SYS': 0, 'source_justice': 0}
    def scalar(name, function, *args):
        counters[name] += 1; value = function(*args)
        need(type(value) is bool, 'Source predicate must return Boolean')
        return value
    def key(state): return tuple(state[n] for n in env_names)
    expected_initial = {key(e) for e in inputs if scalar('source_theta_ENV', contract.theta_e, e)}
    starts, initial_excluded, initial_safety, responses = [], [], [], {e: [] for e in expected_initial}
    for identity in initial:
        state = original[identity]
        if key(state) not in expected_initial:
            initial_excluded.append({'id': identity, 'reason': 'ORIGINAL_ENV_INITIAL_ILLEGAL'})
            continue
        starts.append(identity); responses[key(state)].append(identity)
        if not scalar('source_theta_SYS', contract.theta_s, state):
            initial_safety.append({'id': identity, 'prefix': [identity], 'valuation': by_id[identity]['valuation']})
    initial_coverage = [{'input': dict(zip(env_names, e)), 'responses': ids}
                        for e, ids in sorted(responses.items())]
    initial_bad = [row for row in initial_coverage if len(row['responses']) != 1]
    queue, parents = deque(starts), {identity: None for identity in starts}
    selected, illegal, coverage_bad, safety_bad, input_rows = [], set(), [], [], []
    legal_input_counts = {}
    while queue:
        identity = queue.popleft(); state = original[identity]
        # Successor dictionaries contain ENV fields only. An oracle that reads
        # next SYS/AUX/helper raises instead of silently depending on a response.
        legal = {key(e): e for e in inputs if scalar('source_rho_ENV', contract.rho_e, state, e)}
        legal_input_counts[identity] = len(legal)
        observed = {e: [] for e in legal}
        for target in by_id[identity]['successors']:
            if by_id[target]['valuation'][HELPER] != 'false':
                continue
            successor = original[target]; e = key(successor)
            if e not in legal:
                illegal.add((identity, target)); continue
            selected.append((identity, target)); observed[e].append(target)
            safe = scalar('source_rho_SYS', contract.rho_s, state, successor)
            if not safe:
                safety_bad.append({'source': identity, 'target': target,
                                   'prefix': path_from_parents(identity, parents),
                                   'input': dict(zip(env_names, e))})
            # Even a SYS-unsafe or ambiguous response remains reachable evidence.
            if target not in parents:
                parents[target] = identity; queue.append(target)
        for e, targets in sorted(observed.items()):
            row = {'state': identity, 'input': dict(zip(env_names, e)), 'responses': targets}
            input_rows.append(row)
            if len(targets) != 1:
                coverage_bad.append(dict(row, prefix=path_from_parents(identity, parents),
                                         reason='MISSING_RESPONSE' if not targets else 'AMBIGUOUS_RESPONSE'))
    vertices = set(parents); selected_set = set(selected)
    need(len(selected) == len(selected_set), 'No duplicate selected raw edges')
    labels = None
    for identity in sorted(vertices, key=int):
        counters['source_justice'] += 1; values = contract.justice(original[identity])
        need(type(values) is tuple and len(values) == 2
             and all(type(row) is list and all(type(v) is bool for v in row) for row in values),
             'Ordered source justice tuple')
        if labels is None: labels = [[set() for _ in row] for row in values]
        need([len(row) for row in labels] == [len(row) for row in values], 'Stable ordered justice counts')
        for owner_labels, owner_values in zip(labels, values):
            for label, holds in zip(owner_labels, owner_values):
                if holds: label.add(identity)
    if labels is None:
        # The empty initialized candidate is a complete negative coverage result.
        counters['source_justice'] += 1
        values = contract.justice(next(iter(original.values())))
        need(type(values) is tuple and len(values) == 2
             and all(type(row) is list and all(type(v) is bool for v in row) for row in values), 'Empty-view justice shape')
        labels = [[set() for _ in row] for row in values]
    complete = bool(expected_initial) and not initial_bad and not initial_safety and not coverage_bad and not safety_bad
    fairness = core.finite_fairness(vertices, selected, starts, labels[0], labels[1]) if complete else None
    adjacency = {identity: [] for identity in vertices}
    for source, target in selected: adjacency[source].append(target)
    strict_traces = []
    represented = set()
    for bad in (fairness['strict_liveness']['counterexamples'] if fairness is not None else []):
        ji = bad['SYS_justice_index']
        if ji not in represented:
            represented.add(ji)
            strict_traces.append({'SYS_justice_index': ji, 'component': bad['SCC'],
                                 **lasso(bad['SCC'], adjacency, parents, labels[0])})
    cooperative_traces = []
    if fairness is not None and fairness['nonconflicting']['failing_states']:
        identity = fairness['nonconflicting']['failing_states'][0]
        cooperative_traces.append({'state': identity, 'prefix': path_from_parents(identity, parents),
                                   'proof': 'No ENV-accepting cyclic SCC is reachable, as certified by the complete finite fairness table.'})
    deadends = [identity for identity in sorted(vertices, key=int) if not adjacency[identity]]
    environmental_deadends = [i for i in deadends if legal_input_counts[i] == 0]
    strategy_deadends = [i for i in deadends if legal_input_counts[i] > 0]
    edge_classes, counts = [], {}
    for source, target in flat:
        if by_id[source]['valuation'][HELPER] != 'false' or by_id[target]['valuation'][HELPER] != 'false':
            classification = 'EXCLUDED_HELPER'
        elif source not in vertices:
            classification = 'OUTSIDE_ORIGINAL_LEGAL_REACHABLE_ORIGIN'
        elif (source, target) in illegal:
            classification = 'EXCLUDED_ORIGINAL_ENV_ILLEGAL'
        else:
            need((source, target) in selected_set, 'Every reachable helper-false edge classified')
            classification = 'SELECTED_ORIGINAL_ENV_LEGAL'
        edge_classes.append([source, target, classification]); counts[classification] = counts.get(classification, 0) + 1
    report = {'status': 'COMPLETE_DIRECT_ORIGINAL_GRAPH_CERTIFICATE' if complete else 'COMPLETE_SOURCE_GRAPH_REJECTION', 'admitted_scientific_result': False,
              'complete_source_controller': complete,
              'original_strict_controller': fairness['strict_liveness']['pass'] if complete else None,
              'original_cooperative_controller': fairness['nonconflicting']['pass'] if complete else None,
              'initial_ENV_choices': len(expected_initial), 'original_initial_response_table': initial_coverage,
              'initial_response_failures': initial_bad, 'initial_SYS_AUX_failures': initial_safety,
              'input_coverage_failures': coverage_bad, 'SYS_AUX_safety_failures': safety_bad,
              'source_legal_view': {'states': len(vertices), 'edges': len(selected), 'starts': starts,
                                   'ordered_ENV_justices': len(labels[0]), 'ordered_SYS_justices': len(labels[1]),
                                   'deadends': deadends, 'environmental_deadends': environmental_deadends,
                                   'strategy_deadends': strategy_deadends,
                                   'input_choices_checked': len(vertices) * len(inputs)},
              'fairness_evaluated_after_all_controller_gates': complete,
              'edge_classification_counts': counts, 'raw_edges_classified': len(flat),
              'excluded_initial_nodes': initial_excluded, 'fairness': fairness,
              'strict_liveness_traces': strict_traces, 'cooperation_failure_traces': cooperative_traces,
              'deadend_traces': [{'state': i, 'prefix': path_from_parents(i, parents)} for i in deadends],
              'environmental_deadend_traces': [{'state': i, 'prefix': path_from_parents(i, parents),
                    'legal_ENV_choices': 0} for i in environmental_deadends],
              'strategy_deadend_traces': [{'state': i, 'prefix': path_from_parents(i, parents),
                    'legal_ENV_choices': legal_input_counts[i]} for i in strategy_deadends],
              'algorithmic_counters': counters,
              'source_ENV_successor_fields_supplied': list(env_names),
              'source_ENV_no_next_SYS_dependency_enforced': True,
              'raw_native_ID_rank_AUX_preserved': True, 'SYS_unsafe_legal_edges_retained': True,
              'missing_ambiguous_responses_not_repaired': True}
    view = {'schema': 'lift-direct-original-complete-finite-view-v1',
            'states': sorted(vertices, key=int), 'starts': starts, 'edges': [list(e) for e in selected],
            'ENV_justice': [sorted(row, key=int) for row in labels[0]],
            'SYS_justice': [sorted(row, key=int) for row in labels[1]],
            'native_nodes': [by_id[i] for i in sorted(vertices, key=int)],
            'raw_edge_classifications': edge_classes, 'legal_input_response_table': input_rows,
            'legal_ENV_choice_counts': legal_input_counts,
            'BFS_parent': parents}
    return report, view


def run(frozen, a, core, sources, process_validation):
    contract = sources.CONTRACTS[a.CASE]
    source = frozen.raw('inputs/source.spectra')
    a.exact(a.digest(source), a.SOURCE, 'Exact source listing')
    a.need(contract.source_bytes == a.SOURCE['bytes'] and contract.source_sha256 == a.SOURCE['sha256'], 'Exact source oracle')
    prior = frozen.read('prior/SOURCE_MODEL_RESULT.json')
    a.need(prior['status'] == 'COMPLETE_INDEPENDENT_SOURCE_MODEL_CORRESPONDENCE'
           and prior['candidate'] == a.CASE and prior['source_correspondence']['source_sha256'] == a.SOURCE['sha256'],
           'Previously qualified original source oracle binding')
    prior_source_pins = [p for p in prior['code_pins'] if p['path'].endswith('/source_contracts.py')]
    a.need(len(prior_source_pins) == 1 and prior_source_pins[0]['sha256'] == a.sha(frozen.raw('code/source_contracts.py')),
           'Byte-identical accepted source contract')
    result, model = frozen.read('inputs/result.json'), frozen.read('inputs/model.json')
    process = frozen.read('inputs/PROCESS_RECEIPT.json')
    a.need(process_validation.valid_process(process), 'Previously completed native process receipt')
    for obj in (result, model):
        a.need(obj['fixture_id'] == obj['case_id'] == a.CASE and obj['variant'] == 'initializers', 'Original native case identity')
    a.need(result['status'] == 'JOB_CONTROLLER_PRINTED' and result['teardown'] == 'COMPLETED'
           and result['native_solver_calls'] == result['controller_extraction_calls'] == result['native_printer_calls'] == 1,
           'Exactly one completed historical native job')
    a.need(result['native_initial_verdict'] is True and result['memory_complete'] is True
           and result['memory_empty_guard_called'] is True and result['memory_empty'] is False, 'Historical native extraction gate')
    a.need(all(result[k] is False for k in ('initializers_replaced', 'semantic_reduction_used', 'ENV_justice_normalization_used')),
           'Unchanged historical native options')
    a.need(result['helper_added'] is True and result['helper_is_native_nonaux_ENV'] is True, 'Exact native ENV helper')
    a.need(result['input_sha256'] == model['input']['sha256'] == a.SOURCE['sha256']
           and model['input']['bytes'] == a.SOURCE['bytes'], 'Original source identity')
    for field, filename in [('model_export', 'model.json'), ('controller_export', 'controller.json'), ('printed_controller', 'controller.txt')]:
        a.exact(a.digest(frozen.raw('inputs/' + filename)), {k: result[field][k] for k in ('bytes', 'sha256')}, 'Historical exported bytes')
    graph_raw = frozen.raw('inputs/controller.json')
    a.need(graph_raw.endswith(b'\n') and hashlib.sha256(graph_raw[:-1]).hexdigest() == result['controller_after_print_sha256'],
           'After-printer exact graph serialization')
    graph = a.decode(graph_raw)
    a.need(graph['fixture_id'] == graph['case_id'] == a.CASE and graph['variant'] == 'initializers', 'Raw graph case identity')
    by_id, flat, initial = raw_graph(graph, frozen.raw('inputs/controller.txt').decode('utf-8'), model, result, contract, a.need)
    a.need(len(by_id) == 810 and len(flat) == 13958 and len(initial) == 2, 'Exact saved graph size and initial flags')
    report, view = source_history(by_id, flat, initial, contract, core, a.need)
    a.need(report['initial_ENV_choices'] == 2 and report['source_legal_view']['ordered_ENV_justices'] == 0
           and report['source_legal_view']['ordered_SYS_justices'] == 3, 'Original initializer and ordered justice roster')
    report.update(raw_graph={'states': len(by_id), 'edges': len(flat), 'initial_flags': len(initial),
                            'printer_lines': 2 * len(by_id), 'all_raw_nodes_reachable': True},
                  source_timing=contract.timing_note, saved_graph_evaluations=1, saved_DAG_evaluations=0,
                  native_calls=0, solver_calls=0, region_fixed_point_calls=0,
                  original_full_mapping_UNKNOWN_preserved=True,
                  claims_scope='This exact saved graph under original-ENV-legal helper-false histories only. No whole relation correspondence, native solver completeness, new native execution, or full winning region claim.',
                  native_capture_provenance='Existing exact native process/case receipts and source-to-export byte bindings; large native stdout is retained at its original location and is not copied or reinterpreted by this direct graph scope.')
    return report, view
