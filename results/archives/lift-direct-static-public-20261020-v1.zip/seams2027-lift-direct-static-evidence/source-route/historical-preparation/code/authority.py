"""Pinned file authority for a separate LiftPreferred direct original graph scope."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib, importlib.util, json, re, sys
CASE="lift__preferred"
SCOPE="direct_original_legal_history_graph"
SOURCE={"bytes":2391,"sha256":"ff72b88abec4316e9f78f807344748687bcdeb68606817ba34fa975f34482202"}
LIMITS={"wall_seconds":60,"rss_bytes":536870912,"stream_bytes":65536,"file_bytes":4194304,"output_tree_bytes":8388608,"reserve_bytes":16777216,"min_free_bytes":1073741824}
CORE_PINS={"code/source_contracts.py":"30d1d89c5977798601cfcf661ef8d642c3fdb7c7c7600cd9d9fa9a3a25011fc8","code/independent_core.py":"aa7aa11d0ab35f9505db132db45cb9cc7832e91216e80f56651bf0b3cea8805e","code/runtime_guard.py":"c6df8c8921976cd0f8e1ea03fefd11b65705603dbc755e41b49de020eece3b12","code/supervisor/bounded_process.py":"ee08963ad88b0259c744cbed732f339536fd504a89342c5e661449ffc0e367c9","code/supervisor/owned_process.py":"20ce5ef1912afd9ff144a9c4c102d347e09e5006596372d38bd3e05ad3b57596"}

class Rejection(ValueError):pass



def need(ok,message):
    if not ok:raise Rejection(message)



def sha(raw):return hashlib.sha256(raw).hexdigest()



def digest(raw):return {'bytes':len(raw),'sha256':sha(raw)}



def unique(pairs):
    result={}
    for k,v in pairs:
        need(k not in result,'Duplicate JSON key: '+str(k));result[k]=v
    return result



def decode(raw):
    def bad(value):raise Rejection('Nonfinite JSON number: '+value)
    return json.loads(raw.decode('utf-8'),object_pairs_hook=unique,parse_constant=bad)



def encoded(obj):return (json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()



def exact(a,b,label='value'):
    need(type(a)is type(b),label+' type differs')
    if isinstance(a,dict):
        need(set(a)==set(b),label+' key set differs')
        for k in a:exact(a[k],b[k],label+'/'+str(k))
    elif isinstance(a,list):
        need(len(a)==len(b),label+' length differs')
        for i,(x,y) in enumerate(zip(a,b)):exact(x,y,label+'/'+str(i))
    else:need(a==b,label+' differs')



def canonical_path(path):
    p=Path(path).absolute()
    need('..' not in p.parts and p.resolve()==p,'Canonical path required')
    cur=Path(p.anchor)
    for part in p.parts[1:]:
        cur/=part;need(not cur.is_symlink(),'Symlink path component')
    return p



def relative_name(name):
    need(type(name)is str and bool(name),'Relative file name')
    p=PurePosixPath(name)
    need(not p.is_absolute() and p.as_posix()==name and '\\' not in name,'Canonical relative file name')
    need(all(x not in ('','.','..') for x in name.split('/')),'Unsafe relative file name')
    return name



def file_bytes(path,cap=4194304):
    p=canonical_path(path);need(p.is_file() and p.stat().st_size<=cap,'Regular bounded input file')
    raw=p.read_bytes();need(len(raw)<=cap,'Read byte cap');return raw



def pin(path):return {'path':str(canonical_path(path)),**digest(file_bytes(path))}



def save(path,obj):
    raw=encoded(obj);need(len(raw)<=LIMITS['file_bytes'],'Output file cap')
    p=Path(path);need(p.parent.is_dir() and not p.exists() and not p.is_symlink(),'Fresh output file')
    with p.open('xb') as f:f.write(raw)
    return {'file':p.name,**digest(raw)}



def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);need(spec is not None and spec.loader is not None,'Exact module loader')
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    need(Path(module.__file__).resolve()==Path(path).resolve(),'Imported module origin')
    return module



class Frozen:
    def __init__(self,root,expected_manifest):
        self.root=canonical_path(root);need(self.root.is_dir(),'Closure directory')
        raw=file_bytes(self.root/'FROZEN_MANIFEST.json');need(sha(raw)==expected_manifest,'Frozen manifest hash')
        self.manifest_hash=expected_manifest;self.manifest=decode(raw)
        need(self.manifest.get('schema')=='lift-preferred-direct-original-graph-freeze-v1','Frozen manifest schema')
        need(self.manifest.get('scope')==SCOPE and self.manifest.get('case')==CASE,'Fixed target scope/case')
        self.files={}
        for row in self.manifest['files']:
            name=relative_name(row['file']);need(name not in self.files,'Duplicate manifest file')
            need(type(row.get('bytes'))is int and row['bytes']>=0,'Exact integer byte pin')
            need(type(row.get('sha256'))is str and re.fullmatch('[0-9a-f]{64}',row['sha256'])is not None,'SHA256 pin')
            self.files[name]=row
        for name,h in CORE_PINS.items():need(name in self.files and self.files[name]['sha256']==h,'Unchanged core pin: '+name)
        self.verify()
    def path(self,name):
        name=relative_name(name);need(name in self.files,'File outside frozen authority: '+name)
        return canonical_path(self.root/name)
    def raw(self,name):
        raw=file_bytes(self.path(name));row=self.files[name]
        exact(digest(raw),{k:row[k] for k in ('bytes','sha256')},'Input pin '+name);return raw
    def read(self,name):return decode(self.raw(name))
    def verify(self):
        present=set()
        for entry in self.root.rglob('*'):
            need(not entry.is_symlink(),'Symlink anywhere in frozen closure')
            if entry.is_file():present.add(str(entry.relative_to(self.root)))
            else:need(entry.is_dir(),'Nonregular entry in frozen closure')
        need(present==set(self.files)|{'FROZEN_MANIFEST.json'},'Exact frozen file roster; unmanifested or missing file')
        for name in self.files:self.raw(name)
        need(sha(file_bytes(self.root/'FROZEN_MANIFEST.json'))==self.manifest_hash,'Manifest changed')
        return True


def load_preparation_go(path, manifest_hash, output, kind):
    ref = pin(path)
    go = decode(file_bytes(path))
    keys = {'schema', 'status', 'frozen_manifest_sha256', 'scope', 'case',
            'output_roots', 'deadline_utc', 'limits', 'saved_graph_evaluations_authorized'}
    need(type(go) is dict and set(go) == keys, 'Exact preparation authority fields')
    need(go['schema'] == 'lift-preferred-direct-original-graph-preparation-go-v1' and
         go['status'] == 'GO_ARTIFICIAL_AND_IMPORT_QUALIFICATION', 'New preparation authority')
    need(go['frozen_manifest_sha256'] == manifest_hash and go['scope'] == SCOPE and
         go['case'] == CASE, 'Exact preparation scope/case/freeze')
    need(type(go['saved_graph_evaluations_authorized']) is int and
         go['saved_graph_evaluations_authorized'] == 0, 'Preparation prohibits saved graph evaluation')
    need(type(go['output_roots']) is dict and set(go['output_roots']) == {'artificial', 'imports'},
         'Two distinct preparation output roots')
    need(len(set(go['output_roots'].values())) == 2 and
         go['output_roots'][kind] == str(canonical_path(output)), 'Exact fresh qualification output')
    exact(go['limits'], LIMITS, 'Preparation limits')
    deadline = datetime.fromisoformat(go['deadline_utc'])
    need(deadline.tzinfo is not None and (deadline-datetime.now(timezone.utc)).total_seconds() > 1,
         'Unexpired timezone-aware preparation authority')
    return go, ref


def check_native_provenance(ref, frozen):
    need(type(ref) is dict and set(ref) == {'path', 'bytes', 'sha256'}, 'Native provenance receipt pin')
    exact(pin(ref['path']), ref, 'Current native provenance receipt bytes')
    proof = decode(file_bytes(ref['path']))
    keys = {'schema', 'status', 'case', 'created_utc', 'source', 'model', 'native_result',
            'controller', 'printer', 'native_process_receipt', 'stdout', 'stderr',
            'all_pins_verified', 'stdout_stream_hash_completed'}
    need(type(proof) is dict and set(proof) == keys, 'Exact native provenance fields')
    need(proof['schema'] == 'lift-preferred-native-provenance-preflight-v1'
         and proof['status'] == 'PASS' and proof['case'] == CASE
         and proof['all_pins_verified'] is True and proof['stdout_stream_hash_completed'] is True,
         'Root completed streaming native provenance preflight')
    date = datetime.fromisoformat(proof['created_utc'])
    need(date.tzinfo is not None and date <= datetime.now(timezone.utc), 'Native preflight time')
    copies = {row['file']: row for row in frozen.read('COPY_RECEIPT.json')['files']}
    for key, name in [('source', 'source.spectra'), ('model', 'model.json'), ('native_result', 'result.json'),
                      ('controller', 'controller.json'), ('printer', 'controller.txt'),
                      ('native_process_receipt', 'PROCESS_RECEIPT.json')]:
        row = copies['inputs/' + name]
        exact(proof[key], {'path': row['origin'], 'bytes': row['bytes'], 'sha256': row['sha256']},
              'Native origin/copy binding ' + key)
        exact(digest(frozen.raw('inputs/' + name)), {k: row[k] for k in ('bytes', 'sha256')},
              'Current small native copy ' + key)
    process = frozen.read('inputs/PROCESS_RECEIPT.json')
    origin = Path(copies['inputs/PROCESS_RECEIPT.json']['origin']).parent
    for key in ('stdout', 'stderr'):
        row = process['capture'][key]
        exact(proof[key], {'path': str(origin/(key+'.txt')), 'bytes': row['bytes'], 'sha256': row['sha256']},
              'Exact completed native capture ' + key)
        need(row['complete'] is True and row['bytes'] == row['observed_bytes'] == row['captured_bytes'],
             'Historical native capture completeness')
    return ref


def load_go(path, frozen, output):
    manifest_hash = frozen.manifest_hash
    ref = pin(path)
    go = decode(file_bytes(path))
    keys = {'schema', 'status', 'frozen_manifest_sha256', 'scope', 'case', 'output_root',
            'attempts', 'saved_evaluations', 'native_calls', 'solver_calls', 'fixed_point_calls',
            'deadline_utc', 'limits', 'qualification_receipts', 'native_provenance_receipt'}
    need(type(go) is dict and set(go) == keys, 'Exact actual authority fields')
    need(go['schema'] == 'lift-preferred-direct-original-graph-single-go-v1' and go['status'] == 'GO',
         'New actual direct-graph authority')
    need(go['frozen_manifest_sha256'] == manifest_hash and go['scope'] == SCOPE and
         go['case'] == CASE and go['output_root'] == str(canonical_path(output)), 'Exact actual scope/output')
    for key, value in [('attempts', 1), ('saved_evaluations', 1), ('native_calls', 0),
                       ('solver_calls', 0), ('fixed_point_calls', 0)]:
        need(type(go[key]) is int and go[key] == value, 'Exact integer authority ' + key)
    exact(go['limits'], LIMITS, 'Actual limits')
    deadline = datetime.fromisoformat(go['deadline_utc'])
    need(deadline.tzinfo is not None and (deadline-datetime.now(timezone.utc)).total_seconds() > 1,
         'Unexpired timezone-aware actual authority')
    need(type(go['qualification_receipts']) is list and len(go['qualification_receipts']) == 2,
         'Exactly artificial and import qualification receipts')
    kinds = set()
    for q in go['qualification_receipts']:
        need(type(q) is dict and set(q) == {'path', 'bytes', 'sha256'}, 'Qualification pin fields')
        exact(pin(q['path']), q, 'Qualification receipt current identity')
        record = decode(file_bytes(q['path']))
        need(record.get('status') == 'PASS_DIRECT_GRAPH_QUALIFICATION' and
             record.get('frozen_manifest_sha256') == manifest_hash and record.get('scope') == SCOPE
             and record.get('case') == CASE and record.get('inputs_unchanged') is True
             and record.get('errors') == [] and type(record.get('attempts')) is int
             and record['attempts'] == 1 and record.get('admitted_scientific_result') is False,
             'Qualified same immutable source scope')
        kind = record.get('qualification_kind')
        need(kind in ('artificial', 'imports') and kind not in kinds, 'Distinct qualification kinds')
        kinds.add(kind)
    need(kinds == {'artificial', 'imports'}, 'Both qualification prerequisites')
    check_native_provenance(go['native_provenance_receipt'], frozen)
    return go, ref

