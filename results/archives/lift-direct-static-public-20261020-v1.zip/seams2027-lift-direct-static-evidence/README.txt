LiftPreferred: static evidence addendum

The exact saved native graph has a complete original-source controller view with 136 states and 958 edges. The separate post-hoc certificate establishes strict winning and failure of cooperation. All two original initial inputs, legal-input response coverage/determinism, SYS/AUX safety and ordered justice checks pass. Its 16 dead ends have no legal original ENV input; none is a strategy missing-response dead end. Read SCOPE.json and root/SELECTED_CONTROLLER_ROOT_ADOPTION.json.gz for the adopted statement and limits.

This is a static evidence addendum, not a rerunnable public execution closure. The original/global source-to-native relation mapping remains UNKNOWN. This distinct certificate does not transfer the native positive decision to the original contract. Existing core and verification ZIPs, the historical fixed-11 table and paper v9 are untouched by this addendum. A later editorial revision, if any, has separate authority.

The source route uses handwritten original-source predicates, raw native IDs with rank/AUX preserved, and bitset transitive closure. The reference route uses source-qualified original saved-BDD predicates, a separate codec/traversal and Kosaraju/reverse reach. Its actual result was recorded before reading the source-route actual result. Their 42 saved-output comparisons agree, including all 13,958 raw edge classifications, all original initialized choices and legal responses, ordered justice labels, reachable states, dead ends and fairness evidence. Shared source/graph inputs, prior source qualification, the saved-DAG decoder and earlier code visibility are disclosed; this is not independent compilation or wholly blind implementation independence.

A separately reviewed two-round source argument establishes that every original-strict controller can be driven to an environmental dead end. It explains the lack of a jointly strict/cooperative initialized controller for this source. It is a deductive source result, not another winning-region computation, selection-gap witness or native false-refusal example. The authoritative proof is root/SOURCE_OBSTRUCTION_PROOF_V2.txt, with its separate Root V2 adoption and clarification records included under root. The original SOURCE_OBSTRUCTION_PROOF.txt and draft are retained as historical records. V2 clarifies why an existential continuation from an intermediate state does not establish membership in the universal-input nonblocking region V; it does not alter the two-round obstruction or graph certificate.

Navigation

* source-route/historical-preparation and reference-route/historical-preparation retain the scientific code, source, graph/model data and original preparation records.
* Each route's qualification and actual directories retain its completed single-attempt execution evidence, captures, process ownership and worker outputs.
* independent-comparison contains the reviewed comparator and the full 42-field comparison record; independent-reviews contains the static and saved-output reviews.
* root contains separate authorities, the completed native-capture provenance preflight, adoption records and the source obstruction proof.
* source-route/actual/worker/HISTORY.json.gz contains the complete retained node/input/edge/label tables and raw-edge ledger. The source RESULT and reference RESULT provide their full outcomes and finite evidence.
* source-route/historical-preparation/INITIALIZATION_COUNTER_CLARIFICATION.json.gz explains the earlier 3072/2048 counters: they count aggregate initialization-correspondence checks over two typed carriers, not satisfying initial states.

Anonymous views and historical identities

All scientific code and exact unprojected data keep their bytes. JSON files and text containing private paths are stored with lossless gzip. Only declared private path strings are projected. Every nonpath scientific value, scalar type, array order and historical digest field remains unchanged. RECEIPT_INDEX.json.gz gives three identities for each such file: original execution bytes, anonymous expanded bytes and stored gzip bytes. PATH_ADAPTATIONS.json.gz lists every changed JSON pointer or text-path marker. Verify stored bytes, then decompress and verify expanded bytes. expanded:, origin: and external: are evidence references defined in the ledger, not shell paths.

Historical FROZEN_MANIFEST records intentionally continue to identify the original execution inputs. They do not identify their path-projected public descendants. In particular, the public model's source path has changed, so its current byte digest is different from the original model-export digest. No historical scientific hash has been rewritten to conceal that difference. The historical execution entrypoints therefore cannot be treated as a qualified relocated rerun interface. This package makes no fresh scientific-reader or cross-OS reproduction claim.

The 220,856,594-byte historical native stdout remains outside this small addendum. Its completed Root streaming-hash receipt, expected byte identity and native process/capture records are included. A reader can inspect that recorded provenance but cannot independently rehash an omitted file from this archive. Both new scientific routes read the already saved graph; there was no new native synthesis, region fixed point, benchmark sample or Full reset.

File integrity

Use an externally trusted release SHA-256 for this ZIP. verify_archive.py checks that hash, safe filenames, CRCs and the exact SHA256SUMS member closure, and can extract into a new ordinary directory. It never executes scientific code. Example with locally supplied absolute paths:

    python3 -I -S -B /absolute/path/to/verify_archive.py /absolute/path/to/addendum.zip --expected-sha256 TRUSTED_SHA256 --extract-to /absolute/path/to/new-extraction --receipt /absolute/path/to/new-receipt.json --reserve-bytes 8388608

The verifier refuses existing destinations and preserves partial output on failure. It has a 1 GiB free-space floor, at most 2,048 members, 8 MiB per member and 64 MiB decoded ZIP-member total. This release's actual inventory is much smaller. Gzip-expanded evidence sizes are recorded separately in the identity ledger. A checksum supplied only by an untrusted archive is not an external authenticity source.

Any subsequent Fable32 assessment or editorial decision may be recorded separately by Root. It is not an omitted prerequisite for the evidence already adopted here.
