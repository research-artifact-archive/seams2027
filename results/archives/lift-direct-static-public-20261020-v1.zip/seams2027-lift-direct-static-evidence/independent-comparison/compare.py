"""Read-only semantic comparison of two completed, independently computed outputs.

No source predicate, saved BDD, native job, reachability or SCC algorithm is run.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json
pins={};checks=[]
def need(ok,message):
    if not ok:raise AssertionError(message)
def pin(path):
    p=Path(path).resolve();b=p.read_bytes();row={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};pins[str(p)]=row;return row
def unique(pairs):
    d={}
    for k,v in pairs:need(k not in d,'Duplicate JSON key');d[k]=v
    return d
def read(path):
    p=Path(path);pin(p);return json.loads(p.read_text(),object_pairs_hook=unique,parse_constant=lambda v:(_ for _ in()).throw(ValueError(v)))
def exact(x,y,label):
    need(type(x)is type(y),label+' exact type')
    if isinstance(x,dict):
        need(set(x)==set(y),label+' keys')
        for k in x:exact(x[k],y[k],label+'/'+str(k))
    elif isinstance(x,list):
        need(len(x)==len(y),label+' length')
        for k,(u,v)in enumerate(zip(x,y)):exact(u,v,label+'/'+str(k))
    else:need(x==y,label+' value')
def eq(x,y,label):exact(x,y,label);checks.append(label)
def canon(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def unordered(x,y,label):
    xx=[canon(a)for a in x];yy=[canon(a)for a in y];need(len(xx)==len(set(xx))and len(yy)==len(set(yy)),label+' no duplicates');eq(sorted(xx),sorted(yy),label)
def strip_prefix(rows):return [{k:v for k,v in row.items()if k!='prefix'}for row in rows]
def validate_paths(view,report,source):
    states=set(view['states']);starts=set(view['starts']);edges={tuple(x)for x in view['edges']};parents=view['BFS_parent']
    need(set(parents)==states,'Complete BFS map')
    def path(p,end=None):
        need(type(p)is list and bool(p)and p[0]in starts and all(x in states for x in p),'Original initialized prefix')
        need(all((u,v)in edges for u,v in zip(p,p[1:])),'Every prefix step selected')
        if end is not None:need(p[-1]==end,'Prefix endpoint')
    for u in states:
        seen=set();v=u;p=[]
        while v is not None:
            need(v in states and v not in seen,'Acyclic complete parent chain');seen.add(v);p.append(v);v=parents[v]
        path(p[::-1],u)
    for row in report['input_coverage_failures']:
        if 'prefix'in row:path(row['prefix'],row['state'])
    for row in report['SYS_AUX_safety_failures']:
        if 'prefix'in row:path(row['prefix'],row['source'])
        need((row['source'],row['target'])in edges,'Unsafe edge retained')
    for row in report['deadend_traces'if source else'deadend_prefixes']:path(row['prefix'],row['state'])
    if source:
        for row in report['initial_SYS_AUX_failures']:path(row['prefix'],row['id'])
        for row in report['environmental_deadend_traces']+report['strategy_deadend_traces']:path(row['prefix'],row['state'])
        for row in report['cooperation_failure_traces']:path(row['prefix'],row['state'])
        for row in report['strict_liveness_traces']:
            path(row['prefix']);cyc=row['cycle'];need(len(cyc)>=2 and cyc[0]==cyc[-1]==row['prefix'][-1]and all((u,v)in edges for u,v in zip(cyc,cyc[1:])),'Actual nonempty selected lasso')
            comp=set(row['component']);need(set(cyc)<=comp,'Lasso component')
            need(not(set(cyc)&set(view['SYS_justice'][row['SYS_justice_index']])),'Missed ordered SYS justice')
            need(all(set(cyc)&set(label)for label in view['ENV_justice']),'Lasso satisfies all ENV justice')
    return len(states)
def completed(root):
    run=read(root/'RUN_RECEIPT.json');proc=read(root/'process/PROCESS_RECEIPT.json')
    need(proc['status']=='PROCESS_COMPLETED'and type(proc['exit_code'])is int and proc['exit_code']==0 and proc['owned_child_reaped']is True and proc['receipt_persisted']is True and proc['parent_finalization_completed']is True and proc['parent_aborted']is False,'Basic owned process completion')
    need(proc['exact_child_wait4']['exact_child_reaped']is True and proc['exact_child_wait4']['authority_lost']is False and proc['final_group_observation']['state']=='ABSENT'and proc['fatal_reasons']==proc['resource_reasons']==[],'Clean exact child and group')
    for name,cap in proc['capture'].items():
        p=pin(root/'process'/(name+'.txt'));exact({k:p[k]for k in('bytes','sha256')},{k:cap[k]for k in('bytes','sha256')},'Actual stream identity');need(cap['complete']is True and cap['bytes']==cap['captured_bytes']==cap['observed_bytes'],'Full stream counts')
    res=read(root/'worker/RESULT.json');done=read(root/'worker/WORKER_COMPLETE.json')
    need(run['errors']==[]and run['inputs_unchanged']is True and type(run['attempts'])is int and run['attempts']==1 and run['admitted_scientific_result']is False,'Unadmitted complete one-run parent')
    need(run['status']==res['status']+'_PENDING_INDEPENDENT_ADOPTION'and done['status']==res['status']and done['all_inputs_unchanged']is True and done['kind']=='actual','Exact completed output statuses')
    for row in run['records'].values():exact(pin(row['path']),row,'Parent output pin')
    exact(pin(root/'worker/RESULT.json'),done['result'],'Worker result pin')
    exact(pin(run['GO']['path']),run['GO'],'Current GO');go=read(run['GO']['path'])
    need(go['output_root']==str(root)and go['attempts']==1 and go['saved_evaluations']==1,'Actual one-run authority')
    exact(pin(go['native_provenance_receipt']['path']),go['native_provenance_receipt'],'Root native provenance current pin')
    need(res['case']=='lift__preferred'and res['saved_graph_evaluations']==1 and res['native_calls']==res['solver_calls']==res['region_fixed_point_calls']==0,'Exact saved-graph scope')
    return run,res,done,go

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source',required=True);ap.add_argument('--reference',required=True);ap.add_argument('--output',required=True);args=ap.parse_args()
    sroot=Path(args.source).resolve();croot=Path(args.reference).resolve();sr,s,sd,sg=completed(sroot);cr,c,cd,cg=completed(croot)
    need(s['status']in('COMPLETE_DIRECT_ORIGINAL_GRAPH_CERTIFICATE','COMPLETE_SOURCE_GRAPH_REJECTION'),'Direct status');need(c['status']in('COMPLETE_ORIGINAL_BDD_GRAPH_CERTIFICATE','COMPLETE_ORIGINAL_BDD_GRAPH_REJECTION'),'Reference status')
    exact(pin(s['history']['path']),s['history'],'Full direct history pin');sv=read(s['history']['path']);cv=c['view']
    eq(sg['native_provenance_receipt'],cg['native_provenance_receipt'],'Same Root native provenance receipt')
    for key in ('complete_source_controller','original_strict_controller','original_cooperative_controller','fairness_evaluated_after_all_controller_gates','admitted_scientific_result'):eq(s[key],c[key],key)
    for key in('states','starts','edges'):unordered(sv[key],cv[key],key)
    for owner in('ENV','SYS'):eq(sv[owner+'_justice'],cv[owner.lower()+'_justice'],'Ordered '+owner+' justice labels')
    eq(sv['native_nodes'],cv['native_nodes'],'All raw ID/private rank/AUX/typed bits/native text/successor fields')
    eq(sv['raw_edge_classifications'],cv['raw_edge_classifications'],'Complete raw-edge classifications')
    eq(s['edge_classification_counts'],c['edge_classification_counts'],'All classification counts')
    unordered(sv['legal_input_response_table'],cv['legal_input_response_table'],'Every legal-input raw response list')
    eq(sv['legal_ENV_choice_counts'],c['legal_ENV_input_count_by_node'],'Exact per-node legal ENV counts')
    eq(s['original_initial_response_table'],c['initial_response_table'],'Every required original initial response')
    eq(s['initial_response_failures'],c['initial_coverage_failures'],'Initial coverage failures')
    eq([x['id']for x in s['initial_SYS_AUX_failures']],c['initial_SYS_AUX_failures'],'Initial SYS/AUX failures')
    eq([x['id']for x in s['excluded_initial_nodes']],c['excluded_initial_nodes'],'Excluded original-initial illegal nodes')
    unordered(strip_prefix(s['input_coverage_failures']),strip_prefix(c['input_coverage_failures']),'All missing/ambiguous legal input failures')
    unordered(strip_prefix(s['SYS_AUX_safety_failures']),strip_prefix(c['SYS_AUX_safety_failures']),'All retained unsafe original-legal edges')
    for key in('deadends','environmental_deadends','strategy_deadends'):eq(s['source_legal_view'][key],c[key],key)
    eq(s['source_legal_view']['input_choices_checked'],c['input_choices_checked'],'Full source input enumeration count')
    co=s['algorithmic_counters'];pc=c['predicate_evaluations']
    for sk,ck in [('source_theta_ENV','thetaE'),('source_theta_SYS','thetaS'),('source_rho_ENV','rhoE'),('source_rho_SYS','rhoS')]:eq(co[sk],pc[ck],'Corresponding scalar count '+sk)
    for i in range(3):eq(co['source_justice'],pc['justice_'+str(i)],'Corresponding ordered justice count '+str(i))
    eq([pc[k]for k in('domain','domain_ENV_next','domain_SYS_next')],[1024,16,64],'Original typed-domain factor evaluation counts')
    if s['complete_source_controller']:
        sf=s['fairness'];cf=c['fairness']
        unordered(sf['reachable_states'],cf['reachable'],'Fairness reachable states')
        unordered([sorted(x,key=int)for x in sf['SCCs']],[sorted(x['states'],key=int)for x in cf['reachable_sccs']],'Complete SCC partitions')
        unordered([sorted(x,key=int)for x in sf['ENV_accepting_SCCs']],[sorted(x['states'],key=int)for x in cf['reachable_sccs']if x['accepting']],'All ENV accepting cyclic SCCs')
        for key in('pass','failing_states'):unordered(sf['nonconflicting'][key],cf['nonconflicting'][key],'Cooperation '+key)if key!='pass'else eq(sf['nonconflicting'][key],cf['nonconflicting'][key],'Cooperation pass')
        unordered(sf['nonconflicting']['can_reach_ENV_accepting_SCC'],cf['nonconflicting']['can_reach_accepting_scc'],'Full fair continuation reach set')
        eq(sf['strict_liveness']['pass'],cf['strict_liveness']['pass'],'Strict graph liveness')
        lhs=[{'index':x['SYS_justice_index'],'states':sorted(x['SCC'],key=int)}for x in sf['strict_liveness']['counterexamples']];rhs=[{'index':x['sys_justice_index'],'states':sorted(x['scc']['states'],key=int)}for x in cf['strict_liveness']['counterexamples']]
        unordered(lhs,rhs,'All ordered-justice rejecting sub-SCCs')
    else:eq(s['fairness'],None,'Direct no fairness after failed gate');eq(c['fairness'],None,'Reference no fairness after failed gate')
    paths={'direct_nodes_with_valid_initial_prefixes':validate_paths(sv,s,True),'reference_nodes_with_valid_initial_prefixes':validate_paths(cv,c,False)}
    for row in list(pins.values()):exact(pin(row['path']),row,'All read bytes unchanged after comparison')
    out={'schema':'lift-preferred-two-route-output-comparison-v1','status':'PASS_ALL_SEMANTIC_FIELDS_AND_WITNESS_PATHS','created_utc':datetime.now(timezone.utc).isoformat(),'checks':checks,'check_count':len(checks),'source_status':s['status'],'reference_status':c['status'],'complete_source_controller':s['complete_source_controller'],'original_strict_controller':s['original_strict_controller'],'original_cooperative_controller':s['original_cooperative_controller'],'view_counts':{'states':len(sv['states']),'edges':len(sv['edges']),'starts':len(sv['starts']),'legal_input_rows':len(sv['legal_input_response_table']),'classified_raw_edges':len(sv['raw_edge_classifications'])},'witness_paths':paths,'input_pins':list(pins.values()),'comparison_activity':{'candidate_imports':0,'predicate_evaluations':0,'saved_BDD_evaluations':0,'graph_SCC_or_reachability_algorithm_evaluations':0,'native_calls':0},'scope':'Structural equality of complete saved outputs from direct source/bitset route and source-qualified original-BDD/independent codec/Kosaraju route. Traversal/prefix/SCC order may differ, with witness paths validated. A owns independent process/review acceptance; Root owns admission. Whole-model mapping UNKNOWN and v9/fixed11 unchanged.','admitted_scientific_result':False}
    p=Path(args.output);need(not p.exists(),'Fresh comparison receipt');p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':out['status'],'report':pin(p),'check_count':len(checks),'view_counts':out['view_counts']}))
if __name__=='__main__':main()
