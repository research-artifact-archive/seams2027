# Third-party boundaries

LICENSE covers original artifact contributions, including original checker, wrapper, observer, transport and supervision code and original evidence records. It is not an aggregate license for external dependencies.

The unchanged CatchingIntruder specification (syn23/1673286053.spectra) and its exact syn23/imports/DwyerPatterns.spectra dependency originate in the fixed Zenodo 10553249 corpus. Both are included unchanged with the exact BSD 3-Clause notice at licenses/zenodo10553249-LICENSE.txt. The archive identity is recorded in the existing public repository notices. No paper-derived Lift specification is included.

Both GR1ObservedControllerConstructionSkip.java and GR1ContinuationPreferenceConstruction.java are full upstream-derived extractor sources. They are omitted. SOURCE_RESTORATION_REFERENCE.json binds their exact identities to the existing fourth-archive source-only recipes. Reader retrieval retains the original distributor terms and grants no additional redistribution rights.

No installed JDK/Python runtime, JAR, native library, compiled class, downloaded source cache or third-party paper PDF is included. Original runtime/build inventories and original class identities are historical provenance. Saved model/BDD exports, including the unmodified incomplete 16 MiB relation file, and complete recorded output streams remain inspectable. This is a static evidence snapshot, not a dependency bundle or a relocated executable kit.
