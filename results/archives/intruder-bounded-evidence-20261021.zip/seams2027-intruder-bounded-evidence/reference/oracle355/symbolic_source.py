"""Source formula construction independent of the direct arithmetic evaluator.

No source/state/DAG is evaluated on import. Finite integer equality relations
use exact values; arithmetic beyond the domain has no modular wraparound.
"""
from source_semantics import ENV, SYS, HISTORY, HELPER


def build(ctx, contract, transformed):
    b = ctx.b
    def lit(name, value, prime=False):
        return ctx.literal(name, str(value).lower(), prime)
    def eq(a, c, offset=0):
        # a + offset = c; constants handled separately below.
        an, ap = a; cn, cp = c
        return b.disj(*(b.conj(lit(an, x, ap), lit(cn, y, cp))
                        for x in range(contract.maximum + 1)
                        for y in range(contract.maximum + 1) if x + offset == y))
    def xy(who, prime=False):
        return ((('intruderX', prime), ('intruderY', prime)) if who == 'intruder'
                else (('robotX' + str(who), prime), ('robotY' + str(who), prime)))
    def at(a, x, y):
        return b.conj(lit(a[0][0], x, a[0][1]), lit(a[1][0], y, a[1][1]))
    def equalpoint(a, c):
        return b.conj(eq(a[0], c[0]), eq(a[1], c[1]))
    def adjacent(a, c):
        return b.disj(b.conj(b.disj(eq(a[0], c[0], 1), eq(a[0], c[0], -1)), eq(a[1], c[1])),
                      b.conj(eq(a[0], c[0]), b.disj(eq(a[1], c[1], 1), eq(a[1], c[1], -1))))
    def movement(a, c):
        return b.disj(equalpoint(a, c), adjacent(a, c))
    def clear(a):
        return b.conj(*(b.neg(at(a, x, y)) for x, y in contract.obstacles))
    def invariants(prime):
        a, c, e = xy(0, prime), xy(1, prime), xy('intruder', prime)
        return [clear(a), clear(c), b.neg(equalpoint(a, c)),
                b.neg(equalpoint(e, a)), b.neg(equalpoint(e, c))]
    e, ne = xy('intruder'), xy('intruder', True)
    h, hn = lit(HISTORY, 'true'), lit(HISTORY, 'true', True)
    init_positions = b.conj(at(xy(0), 0, 0), at(xy(1), contract.maximum, 0))
    hist_init = b.iff(h, at(xy(0), 0, contract.maximum))
    hist_step = b.iff(hn, b.disj(h, at(xy(0, True), 0, contract.maximum)))
    avoid = [b.implies(adjacent(xy(i), e),
                       b.conj(b.neg(eq(ne[0], xy(i)[0])), b.neg(eq(ne[1], xy(i)[1])))) for i in (0, 1)]
    moves = [movement(xy(0), xy(0, True)),
             b.disj(b.conj(h, movement(xy(1), xy(1, True))), equalpoint(xy(1), xy(1, True)))]
    f = {'thetaE': b.conj(lit('intruderY', contract.maximum), clear(e)),
         'thetaS': b.conj(init_positions, *invariants(False), hist_init),
         'rhoE': b.conj(clear(ne), movement(e, ne), *avoid),
         'rhoS': b.conj(*invariants(True), *moves, hist_step)}
    justices = {'ENV': [], 'SYS': [b.conj(adjacent(xy(0), e), adjacent(xy(1), e))]}
    if transformed:
        g, gn = lit(HELPER, 'true'), lit(HELPER, 'true', True)
        f = {'thetaE': b.conj(lit('intruderY', contract.maximum), b.neg(g)),
             'thetaS': b.conj(init_positions, *(b.disj(v, g) for v in invariants(False)), hist_init),
             'rhoE': b.conj(*(b.disj(v, gn) for v in [clear(e), movement(e, ne), *avoid]), b.implies(g, gn)),
             'rhoS': b.conj(*(b.disj(v, gn) for v in invariants(True)),
                            *(b.disj(v, g) for v in moves), hist_step)}
        justices['ENV'] = [b.neg(g)]
    return f, justices

