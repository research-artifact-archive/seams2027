"""Synthetic-only complete truth tables and rejection controls; never reads355 data."""
from pathlib import Path
import importlib.util
import sys
import json
import hashlib
import tempfile
from itertools import product
from copy import deepcopy

HERE = Path(__file__).resolve().parent
for name in ('independent_core', 'bdd_core', 'source_semantics', 'symbolic_source', 'model355', 'graph355', 'activity'):
    spec = importlib.util.spec_from_file_location(name, HERE / (name + '.py'))
    mod = importlib.util.module_from_spec(spec); sys.modules[name] = mod; spec.loader.exec_module(mod)
from independent_core import pin, need, SavedDag, finite_fairness, decode_json
from source_semantics import Contract, ENV, SYS, HISTORY, HELPER
from symbolic_source import build
from model355 import Model
from graph355 import audit as graph_audit, fairness
from activity import compare


def synthetic_model(contract, helper):
    names = ENV + ((HELPER,) if helper else ()) + SYS + (HISTORY,)
    values = dict(contract.values)
    if helper: values[HELPER] = ('false', 'true')
    fields, bit = [], 0
    for i, n in enumerate(names):
        vs = values[n]; width = (len(vs) - 1).bit_length()
        cb = list(range(bit, bit + width)); nb = list(range(bit + width, bit + width * 2)); bit += width * 2
        enc = {}
        for j, v in enumerate(vs):
            # Deliberately reverse selected field encodings.
            code = len(vs) - 1 - j if i % 2 else j
            vals = [bool(code & (1 << k)) for k in range(width)]
            enc[v] = {'current': dict(zip(map(str, cb), vals)), 'next': dict(zip(map(str, nb), vals))}
        fields.append({'name': n, 'owner': 'ENV' if n in ENV + (HELPER,) else 'SYS',
                       'role': 'AUX' if n == HISTORY else 'ENV' if n in ENV + (HELPER,) else 'SYS',
                       'domain_size': len(vs), 'values': list(vs), 'current_bits': cb, 'next_bits': nb, 'encoding': enc})
    return {'schema': 'k7-native-model-export-v1', 'fixture_id': 'synthetic_only', 'fields': fields,
            'all_current_bits': [x for f in fields for x in f['current_bits']],
            'all_next_bits': [x for f in fields for x in f['next_bits']],
            'bdd_variable_count': bit, 'bdd_variable_order': list(range(bit)), 'original_bdds': {}, 'original_justices': {}}


def serialize(b, root):
    if root < 2: return ('0 ' + str(root) + '\n').encode()
    seen, rows = set(), []
    def visit(u):
        if u < 2 or u in seen: return
        seen.add(u); v, lo, hi = b.nodes[u]; visit(lo); visit(hi); rows.append(f'{u} {v} {lo} {hi}')
    visit(root)
    return ('\n'.join([str(b.n), ' '.join(map(str, range(b.n))), *rows]) + '\n').encode()


def install(ctx, folder):
    f, j = build(ctx, ctx.contract, ctx.transformed)
    f.update(domain=ctx.domain, domain_ENV_next=ctx.den, domain_SYS_next=ctx.dsn)
    for n, root in list(f.items()) + [(o + str(i), r) for o in ('ENV', 'SYS') for i, r in enumerate(j[o])]:
        p = folder / (n + '.bdd'); p.write_bytes(serialize(ctx.b, root)); ref = pin(p)
        ctx.bdd_files[p.name] = ref
        target = {'file': p.name, 'bytes': ref['bytes'], 'sha256': ref['sha256']}
        if n in f: ctx.model['original_bdds'][n] = target
        else: ctx.model['original_justices'].setdefault(n[:3], []).append(target)
    for o in ('ENV', 'SYS'): ctx.model['original_justices'].setdefault(o, [])
    return f, j


def states(ctx):
    return [dict(zip(ctx.names, row)) for row in product(*(ctx.values[n] for n in ctx.names))]


def main():
    need(len(sys.argv) == 2, 'Usage qualify.py NEW_RESULT.json')
    output = Path(sys.argv[1]).resolve(); need(not output.exists(), 'Fresh qualification receipt')
    controls, complete_pairs = [], 0
    def ok(name): controls.append({'name': name, 'status': 'PASS'})
    def reject(name, fn):
        try: fn()
        except (ValueError, RuntimeError, AssertionError, KeyError): ok(name); return
        raise AssertionError('Negative control accepted: ' + name)
    with tempfile.TemporaryDirectory(prefix='synthetic355_', dir=HERE) as td:
        base = Path(td)
        for helper in (False, True):
            contract = Contract(maximum=1, obstacles=((0, 1),))
            m = synthetic_model(contract, helper); ctx = Model(m, {}, contract, helper)
            folder = base / str(helper); folder.mkdir(); f, j = install(ctx, folder)
            certificate = ctx.verify_source(); need(certificate['status'].startswith('PASS_'), 'Synthetic complete model correspondence')
            ss = states(ctx); cached = [(s, ctx.bits(s), ctx.bits(s, True)) for s in ss]
            for s, cb, _ in cached:
                need(ctx.b.evaluate(f['thetaE'], cb) == contract.theta_e(s, helper), 'Direct/symbolic initial ENV')
                need(ctx.b.evaluate(f['thetaS'], cb) == contract.theta_s(s, helper), 'Direct/symbolic initial SYS')
                ej, sj = contract.justices(s, helper)
                need([ctx.b.evaluate(r, cb) for r in j['ENV']] == ej and [ctx.b.evaluate(r, cb) for r in j['SYS']] == sj, 'Direct/symbolic justices')
                for t, _, nb in cached:
                    assignment = cb | nb
                    need(ctx.b.evaluate(f['rhoE'], assignment) == contract.rho_e(s, t, helper), 'Direct/symbolic complete ENV relation')
                    need(ctx.b.evaluate(f['rhoS'], assignment) == contract.rho_s(s, t, helper), 'Direct/symbolic complete SYS relation')
                    complete_pairs += 1
            ok('all_typed_truth_tables_helper_' + str(helper))
            wrong = deepcopy(m); wrong['fields'][0]['encoding']['1'] = deepcopy(wrong['fields'][0]['encoding']['0'])
            reject('duplicate_integer_encoding_' + str(helper), lambda: Model(wrong, {}, contract, helper))
            wrong = deepcopy(m); wrong['fields'][-1]['role'] = 'SYS'
            reject('missing_ONCE_AUX_role_' + str(helper), lambda: Model(wrong, {}, contract, helper))
            ref = ctx.model['original_bdds']['rhoS']; saved = ctx.bdd_files[ref['file']]
            bad = dict(saved, sha256='0' * 64); old = ctx.bdd_files[ref['file']]; ctx.bdd_files[ref['file']] = bad
            fresh = Model(m, ctx.bdd_files, contract, helper)
            reject('stale_BDD_pin_' + str(helper), fresh.verify_source)
            ctx.bdd_files[ref['file']] = old
            # Incorrect full SYS relation is rejected even when all shapes remain valid.
            wrong_model = deepcopy(m); wrong_model['original_bdds']['rhoS'] = deepcopy(m['original_bdds']['thetaE'])
            reject('wrong_full_SYS_relation_' + str(helper), lambda: Model(wrong_model, ctx.bdd_files, contract, helper).verify_source())
        # Integer arithmetic is nonmodular; direct helper timing already fully covered above.
        from source_semantics import step, adjacent
        need(not step((0, 0), (3, 0)) and not adjacent((0, 0), (3, 0)), 'No modular wraparound')
        ok('integer_boundary_no_wraparound')
        # Eight-valued synthetic geometry uses a different obstacle map; no355 input is read.
        eight = Contract(maximum=7, obstacles=((3, 3),))
        m8 = synthetic_model(eight, False); cx8 = Model(m8, {}, eight, False)
        folder8 = base / 'eight_values'; folder8.mkdir(); f8, _ = install(cx8, folder8); cx8.verify_source()
        start = {'intruderX': '7', 'intruderY': '7', 'robotX0': '0', 'robotY0': '0',
                 'robotX1': '6', 'robotY1': '0', HISTORY: 'false'}
        cases = []
        cases.append(('symbolic_integer_0_to_7_no_wrap', start, dict(start, robotX0='7'), False))
        cases.append(('symbolic_integer_7_to_0_no_wrap', dict(start, robotX0='7'), start, False))
        cases.append(('symbolic_diagonal_move_rejected', start, dict(start, robotX0='1', robotY0='1'), False))
        cases.append(('symbolic_safe_unit_step', start, dict(start, robotX0='1'), True))
        arrival = dict(start, robotY0='6')
        cases.append(('ONCE_first_arrival_cannot_move_robot1_same_step', arrival,
                      dict(start, robotY0='7', robotX1='5', **{HISTORY: 'true'}), False))
        cases.append(('ONCE_first_arrival_stay_robot1', arrival, dict(start, robotY0='7', **{HISTORY: 'true'}), True))
        visited = dict(start, robotY0='7', **{HISTORY: 'true'})
        cases.append(('ONCE_later_move_allowed', visited, dict(visited, robotX1='5'), True))
        cases.append(('ONCE_cannot_reset_after_true', visited, dict(visited, **{HISTORY: 'false'}), False))
        for name, s, t, wanted in cases:
            bits = cx8.bits(s) | cx8.bits(t, True)
            need(eight.rho_s(s, t) is wanted and cx8.b.evaluate(f8['rhoS'], bits) is wanted
                 and cx8.dags[cx8.model['original_bdds']['rhoS']['file']].value(bits) is wanted, 'Eight-valued direct/symbolic/SavedDag point control')
            ok(name)
        reject('duplicate_JSON_key', lambda: decode_json('{"a":1,"a":2}'))
        reject('malformed_saved_DAG', lambda: SavedDag(b'2\n0 1\n2 0 3 1\n', 2, [0, 1]))
        # Two-state synthetic controller has every legal input but never meets SYS goal.
        contract = Contract(maximum=1, obstacles=())
        m = synthetic_model(contract, False); ctx = Model(m, {}, contract, False)
        folder = base / 'graph'; folder.mkdir(); install(ctx, folder); ctx.verify_source()
        ns = []
        for i in range(2):
            s = {'intruderX': str(i), 'intruderY': '1', 'robotX0': '0', 'robotY0': '0', 'robotX1': '1', 'robotY1': '0', HISTORY: 'false'}
            ns.append({'id': str(i), 'native_id': i, 'rank': 0, 'rank_class': 'tau.smlab.syntech.games.gr1.GR1RankInfo',
                       'rank_info': 'System Justice 0', 'initial': True, 'valuation': s,
                       'bits': {str(k): v for k, v in ctx.bits(s).items()}, 'successors': [str(1-i)]})
        g = {'schema': 'released-concrete-controller-export-v2', 'complete': True, 'rank_domain_size': 1,
             'api_state_count': 2, 'api_transition_count': 2, 'exported_edge_count': 2, 'api_state_order': ['0', '1'],
             'nodes': ns, 'edges': [['0', '1'], ['1', '0']]}
        summary, view = graph_audit(ctx, g, {})
        need(summary['independent_nonconflicting'] is True and summary['independent_strict'] is False
             and summary['independent_cooperative'] is False, 'Goal violation is not cooperative success')
        ok('complete_graph_wrong_goal_two_independent_routes')
        # Independently enumerate finite source replies to construct a saved V proof.
        all_states = states(ctx); all_inputs = [dict(zip(ENV, row)) for row in product(*(contract.values[n] for n in ENV))]
        legal, replies = {}, {}
        for si, s in enumerate(all_states):
            legal[si] = [ei for ei, e in enumerate(all_inputs) if contract.rho_e(s, e)]
            for ei in legal[si]:
                replies[(si, ei)] = {ti for ti, t in enumerate(all_states)
                                     if all(t[n] == all_inputs[ei][n] for n in ENV) and contract.rho_s(s, t)}
        alive_ids = {si for si in legal if legal[si]}
        def finite_step(v):
            return {si for si in alive_ids if all(replies[(si, ei)] & v for ei in legal[si])}
        def root_ids(ids): return ctx.b.disj(*(ctx.b.cube(ctx.bits(all_states[i])) for i in sorted(ids)))
        def ref(name, root):
            p = folder / (name + '.bdd'); p.write_bytes(serialize(ctx.b, root)); x = pin(p); ctx.bdd_files[p.name] = x
            return {'file': p.name, 'bytes': x['bytes'], 'sha256': x['sha256']}
        ids = set(range(len(all_states))); iterations = []
        while True:
            nxt = finite_step(ids); i = len(iterations)
            iterations.append({'iteration': i, 'before': ref('v_before' + str(i), root_ids(ids)),
                               'after': ref('v_after' + str(i), root_ids(nxt)), 'descending': nxt <= ids, 'equal': nxt == ids})
            if nxt == ids: break
            ids = nxt
        v = root_ids(ids); witness = ctx.b.conj(ctx.formulas['thetaS'], v)
        missing = ctx.b.conj(ctx.formulas['thetaE'], ctx.b.neg(ctx.b.exists(witness, ctx.sc)))
        normalization = {'alive': ref('finite_alive', root_ids(alive_ids)), 'viability_iterations': iterations,
                         'V': ref('finite_V', v), 'normalization': {'restricted_rhoS': ref('restricted_s', ctx.b.conj(ctx.formulas['rhoS'], v, ctx.b.rename(v, ctx.prime)))},
                         'residual_thetaE': ref('residual_e', ctx.formulas['thetaE']), 'residual_thetaS': ref('residual_s', witness),
                         'final_region': ref('final_region', v), 'native_W': ref('native_W', ctx.domain), 'native_solver_called': True,
                         'original_initial_quantification': {'env_quantified_bits': sorted(ctx.ec), 'sys_quantified_bits': sorted(ctx.sc),
                             'system_witness': ref('initial_witness', witness), 'missing_environment_initials': ref('missing', missing), 'verdict': missing == 0},
                         'initial_in_region': missing == 0, 'native_residual_initial_verdict': missing == 0}
        need(ctx.verify_normalization(normalization)['status'] == 'PASS_SAVED_V_CHAIN_AND_NORMALIZATION', 'Explicit finite V versus symbolic proof checker')
        ok('finite_source_V_chain_and_normalization')
        bad_norm = deepcopy(normalization); bad_norm['viability_iterations'][0]['after'] = bad_norm['viability_iterations'][0]['before']
        reject('wrong_V_proof_chain_step', lambda: ctx.verify_normalization(bad_norm))
        bad_norm = deepcopy(normalization); bad_norm['original_initial_quantification']['verdict'] = not (missing == 0)
        reject('wrong_original_initial_quantifier', lambda: ctx.verify_normalization(bad_norm))
        bad = deepcopy(g); bad['nodes'][0]['successors'] = []; bad['edges'] = [['1', '0']]; bad['api_transition_count'] = bad['exported_edge_count'] = 1
        reject('missing_legal_input', lambda: graph_audit(ctx, bad, {}))
        bad = deepcopy(g); bad['nodes'][0]['valuation'][HISTORY] = 'true'
        reject('wrong_ONCE_native_bits_or_initializer', lambda: graph_audit(ctx, bad, {}))
        bad = deepcopy(g); bad['nodes'][0]['rank'] = 1
        reject('wrong_private_memory_rank', lambda: graph_audit(ctx, bad, {}))
        need(compare(view, view)['status'] == 'NO_OBSERVED_ORIGINAL_LEGAL_RESPONSE_DIVERGENCE', 'Equal product graph')
        ok('equal_product_graph')
        alternative = deepcopy(view); alternative['nodes'][1]['valuation']['robotX0'] = '1'
        need(compare(view, alternative)['status'] == 'INITIAL_SOURCE_RESPONSE_DIVERGENCE', 'Different initialized response')
        ok('different_initialized_response')
        shared = deepcopy(view); changed = deepcopy(alternative)
        shared['starts'] = changed['starts'] = ['0']
        divergence = compare(shared, changed)
        need(divergence['status'] == 'OBSERVED_ORIGINAL_LEGAL_RESPONSE_DIVERGENCE'
             and divergence['shortest_common_prefix_BFS'] is True
             and divergence['candidate_event_causality_established'] is False, 'Shared-prefix response divergence')
        ok('shared_prefix_observed_response_divergence_not_candidate_event')
        # Finite graph deadend, fair cycle, and avoiding-goal cycle controls in both algorithms.
        for name, vv, ee, starts, aa, gg in [
                ('deadend', ['0'], [], ['0'], [], [['0']]),
                ('fair_goal_cycle', ['0','1'], [('0','1'),('1','0')], ['0'], [], [['1']]),
                ('avoid_goal_subcycle', ['0','1'], [('0','0'),('0','1'),('1','0')], ['0'], [], [['1']]),
                ('unmet_environment_justice', ['0'], [('0','0')], ['0'], [[]], [[]])]:
            a, b = fairness(vv, ee, aa, gg), finite_fairness(vv, ee, starts, aa, gg)
            need(a['strict_liveness']['pass'] == b['strict_liveness']['pass'] and a['nonconflicting']['pass'] == b['nonconflicting']['pass']
                 and a['nonconflicting']['failing_states'] == b['nonconflicting']['failing_states'], 'Two algorithm fairness control')
            ok(name)
    result = {'schema': 'v48-oracle355-synthetic-qualification-v1', 'status': 'PASS', 'controls': controls,
              'control_count': len(controls), 'complete_synthetic_typed_pairs': complete_pairs,
              'actual355_sources_read': 0, 'actual355_models_or_BDDs_read': 0, 'native_JVM_calls': 0,
              'whole_region_solves': 0, 'files': [pin(p) for p in sorted(HERE.glob('*.py'))]}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'controls': len(controls), 'synthetic_pairs': complete_pairs, 'receipt': pin(output)}))


if __name__ == '__main__':
    main()

