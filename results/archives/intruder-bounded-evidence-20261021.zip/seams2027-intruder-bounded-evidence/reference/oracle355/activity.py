"""Observed source-legal graph response divergence, not candidate-event logging."""
from collections import deque
from independent_core import need
from source_semantics import ENV, SYS, HISTORY

MAX_PRODUCT_PAIRS = 16384
MAX_INPUT_CHECKS = 1048576


def compare(left, right):
    fields = ENV + SYS + (HISTORY,)
    def prepare(view):
        nodes = {n['id']: n for n in view['nodes']}
        adjacency = {n: {} for n in nodes}
        for a, z in view['edges']:
            key = tuple(nodes[z]['valuation'][n] for n in ENV)
            need(key not in adjacency[a], 'Product comparison requires deterministic responses')
            adjacency[a][key] = z
        initial = {tuple(nodes[n]['valuation'][k] for k in ENV): n for n in view['starts']}
        need(len(initial) == len(view['starts']), 'Distinct initial ENV choices')
        return nodes, adjacency, initial, {q['id']: q for q in view['Q_rows']}
    ln, la, li, lq = prepare(left); rn, ra, ri, rq = prepare(right)
    need(set(li) == set(ri), 'Same original initial input choices')
    def valuation(n): return tuple(n['valuation'][f] for f in fields)
    queue, parent, checks = deque(), {}, 0
    for e in sorted(li):
        pair = li[e], ri[e]
        if valuation(ln[pair[0]]) != valuation(rn[pair[1]]):
            return {'status': 'INITIAL_SOURCE_RESPONSE_DIVERGENCE', 'initial_ENV': list(e),
                    'baseline_node': ln[pair[0]], 'preference_node': rn[pair[1]],
                    'candidate_event_causality_established': False}
        parent[pair] = None; queue.append(pair)
    while queue:
        a, c = queue.popleft()
        need(valuation(ln[a]) == valuation(rn[c]), 'Shared-prefix source valuation invariant')
        need(set(la[a]) == set(ra[c]), 'Sourcelegal equal-state ENV coverage agreement')
        for e in sorted(la[a]):
            checks += 1
            if checks > MAX_INPUT_CHECKS:
                return {'status': 'UNKNOWN_PRODUCT_INPUT_CAP', 'pairs': len(parent), 'input_checks': checks - 1}
            z, w = la[a][e], ra[c][e]
            if valuation(ln[z]) != valuation(rn[w]):
                prefix, p = [], (a, c)
                while p is not None:
                    prefix.append({'baseline': p[0], 'preference': p[1],
                                   'baseline_rank': ln[p[0]]['rank'], 'preference_rank': rn[p[1]]['rank'],
                                   'valuation': ln[p[0]]['valuation']})
                    p = parent[p]
                prefix.reverse()
                return {'status': 'OBSERVED_ORIGINAL_LEGAL_RESPONSE_DIVERGENCE',
                        'meaning': 'First selected full-source output difference along a shared legal input prefix; not a captured native candidate event.',
                        'prefix': prefix, 'next_ENV': dict(zip(ENV, e)),
                        'baseline_source': ln[a], 'preference_source': rn[c],
                        'baseline_target': ln[z], 'preference_target': rn[w],
                        'baseline_target_Q': lq[z], 'preference_target_Q': rq[w],
                        'pairs_examined': len(parent), 'input_checks': checks,
                        'candidate_event_causality_established': False, 'shortest_common_prefix_BFS': True}
            pair = z, w
            if pair not in parent:
                if len(parent) >= MAX_PRODUCT_PAIRS:
                    return {'status': 'UNKNOWN_PRODUCT_PAIR_CAP', 'pairs': len(parent), 'input_checks': checks}
                parent[pair] = (a, c); queue.append(pair)
    return {'status': 'NO_OBSERVED_ORIGINAL_LEGAL_RESPONSE_DIVERGENCE',
            'reachable_product_pairs': len(parent), 'input_checks': checks,
            'candidate_event_causality_established': False,
            'scope': 'Complete bounded reachable synchronous product from equal original source initial responses; no raw-helper/ENV-illegal-only activity promoted.'}

