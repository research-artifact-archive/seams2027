"""Typed integer/Boolean model audit and full source-function correspondence."""
from functools import lru_cache
from itertools import product
from bdd_core import BDD
from independent_core import need, read_pin, SavedDag
from source_semantics import ENV, SYS, HISTORY, HELPER, BOOL
from symbolic_source import build


class Model:
    def __init__(self, model, bdd_files, contract, transformed=False):
        self.model, self.bdd_files, self.contract, self.transformed = model, bdd_files, contract, transformed
        self.names = ENV + ((HELPER,) if transformed else ()) + SYS + (HISTORY,)
        self.env = ENV + ((HELPER,) if transformed else ())
        self.values = dict(contract.values)
        if transformed:
            self.values[HELPER] = BOOL
        need(model['schema'] == 'k7-native-model-export-v1', 'Model schema')
        fields = model['fields']
        need(type(fields) is list and [f['name'] for f in fields] == list(self.names), 'Exact native field order/AUX roster')
        self.by_name = {f['name']: f for f in fields}
        self.current, self.next, self.ec, self.en, self.sc, self.sn = set(), set(), set(), set(), set(), set()
        for f in fields:
            n = f['name']; owner = 'ENV' if n in self.env else 'SYS'; role = owner if n != HISTORY else 'AUX'
            wanted = self.values[n]
            need(f['owner'] == owner and f['role'] == role and f['domain_size'] == len(wanted)
                 and set(f['values']) == set(wanted) and len(f['values']) == len(wanted), 'Typed field declaration: ' + n)
            cb, nb = f['current_bits'], f['next_bits']
            width = (len(wanted) - 1).bit_length()
            need(len(cb) == len(nb) == width and all(type(x) is int and x >= 0 for x in cb + nb)
                 and len(set(cb + nb)) == 2 * width and not set(cb + nb) & (self.current | self.next), 'Field bit allocation')
            self.current.update(cb); self.next.update(nb)
            (self.ec if owner == 'ENV' else self.sc).update(cb)
            (self.en if owner == 'ENV' else self.sn).update(nb)
            need(set(f['encoding']) == set(wanted), 'Complete value encoding')
            images = []
            for value in wanted:
                pair = []
                for key, bits in [('current', cb), ('next', nb)]:
                    enc = f['encoding'][value][key]
                    need(set(enc) == set(map(str, bits)) and all(type(x) is bool for x in enc.values()), 'Boolean bit map')
                    pair.append(tuple(enc[str(x)] for x in bits))
                need(pair[0] == pair[1], 'Current/next semantic encoding correspondence')
                images.append(pair[0])
            need(len(set(images)) == len(wanted), 'Injective typed encoding')
        n = model['bdd_variable_count']; order = model['bdd_variable_order']
        need(type(n) is int and 0 < n <= 64 and self.current | self.next == set(range(n)), 'Complete BDD bit carrier')
        need(len(order) == n and set(order) == set(range(n)) and all(type(v) is int for v in order), 'BDD variable order')
        for key, wanted in [('all_current_bits', self.current), ('all_next_bits', self.next)]:
            need(len(model[key]) == len(wanted) and set(model[key]) == wanted, 'Declared bit roster')
        self.b = BDD(n, node_limit=500000)
        self.literal = lru_cache(None)(self.literal)
        self.prime = {c: p for f in fields for c, p in zip(f['current_bits'], f['next_bits'])}
        self.domain = self.domain_for(self.names, False)
        self.den, self.dsn = self.domain_for(self.env, True), self.domain_for(tuple(n for n in self.names if n not in self.env), True)
        self.loaded, self.dags = {}, {}

    def bits(self, state, prime=False):
        need(type(state) is dict and set(state) <= set(self.names), 'Known typed state names')
        out = {}
        for n, v in state.items():
            need(type(v) is str and v in self.values[n], 'Typed state value: ' + n)
            out.update({int(k): x for k, x in self.by_name[n]['encoding'][v]['next' if prime else 'current'].items()})
        return out

    def literal(self, name, value, prime=False):
        return self.b.cube(self.bits({name: value}, prime))

    def domain_for(self, names, prime):
        return self.b.conj(*(self.b.disj(*(self.literal(n, v, prime) for v in self.values[n])) for n in names))

    def load(self, ref, allowed=None):
        name = ref['file']
        need(type(name) is str and '/' not in name and name in self.bdd_files, 'Declared pinned BDD file')
        p = self.bdd_files[name]
        need(ref['bytes'] == p['bytes'] and ref['sha256'] == p['sha256'], 'Model BDD pin identity')
        if name not in self.loaded:
            raw = read_pin(p)
            dag = SavedDag(raw, self.b.n, self.model['bdd_variable_order'])
            root, meta = self.b.read_native(raw)
            need(meta['order'] is None or meta['order'] == self.model['bdd_variable_order'], 'BDD/model exact order')
            need(self.b.support(root) == dag.support, 'Independent DAG support parity')
            self.loaded[name], self.dags[name] = root, dag
        root = self.loaded[name]
        need(allowed is None or self.b.support(root) <= set(allowed), 'Unexpected relation support: ' + name)
        return root

    def check_equal(self, ref, expected, name, allowed=None):
        actual = self.load(ref, allowed)
        need(actual == expected, 'Full source/native function mismatch: ' + name)
        return actual

    def verify_source(self):
        b = self.b
        expected, justice = build(self, self.contract, self.transformed)
        allowed = {'thetaE': self.ec, 'thetaS': self.current,
                   'rhoE': self.current | self.en, 'rhoS': self.current | self.next}
        self.formulas = {key: self.check_equal(self.model['original_bdds'][key], wanted, key, allowed[key])
                         for key, wanted in expected.items()}
        for key, wanted, bits in [('domain', self.domain, self.current), ('domain_ENV_next', self.den, self.en),
                                  ('domain_SYS_next', self.dsn, self.sn)]:
            self.check_equal(self.model['original_bdds'][key], wanted, key, bits)
        self.justices = {}
        for owner in ('ENV', 'SYS'):
            refs = self.model['original_justices'][owner]
            need(len(refs) == len(justice[owner]), 'Exact source justice roster')
            self.justices[owner] = [self.check_equal(ref, root, owner + ' justice', self.current)
                                    for ref, root in zip(refs, justice[owner])]
        self.native_justice_count = {owner: len(v) or 1 for owner, v in self.justices.items()}
        # Typed field domains are powers of two here, but retain domain-aware checks.
        result = {'status': 'PASS_FULL_SOURCE_NATIVE_CORRESPONDENCE', 'transformed': self.transformed,
                  'method': 'Independent exact finite-integer source factor construction and canonical ROBDD equality',
                  'functions': list(expected), 'ordered_justice_counts': {o: len(v) for o, v in justice.items()},
                  'BDD_nodes': len(b.nodes), 'full_typed_state_count': self.carrier(),
                  'dense_state_pairs_enumerated': 0, 'all_logical_ONCE_values_retained': True,
                  'native_AST_used_to_construct_expected_functions': False}
        if self.transformed:
            original, _ = build(self, self.contract, False)
            off = self.literal(HELPER, 'false'); offn = self.literal(HELPER, 'false', True)
            edge00 = b.conj(self.domain, b.rename(self.domain, self.prime), off, offn)
            e00 = self.formulas['rhoE']; s00 = self.formulas['rhoS']
            # Every original-legal input is present while current source obstacle invariant holds.
            # Globally E_original=>E00 need not hold from arbitrary current obstacle states.
            obs = b.conj(*(b.neg(b.conj(self.literal('intruderX', str(x)), self.literal('intruderY', str(y))))
                           for x, y in self.contract.obstacles))
            env_subset_delta = b.conj(edge00, obs, original['rhoE'], b.neg(e00))
            sys_delta = b.conj(edge00, b.apply('xor', original['rhoS'], s00))
            need(env_subset_delta == 0, 'Original legal input subset on original obstacle-invariant states')
            need(sys_delta == 0, 'SYS full original relation identity on00')
            q_orig = b.exists(original['rhoE'], self.en - set(self.by_name[HELPER]['next_bits']))
            q_impl = b.disj(self.literal(HELPER, 'true'), b.exists(b.conj(e00, offn), self.en))
            need(b.conj(self.domain, off, obs, q_orig, b.neg(q_impl)) == 0, 'Q_original implies Q_impl under original obstacle invariant')
            self.q_original, self.q_impl = q_orig, q_impl
            result.update(E00_global_original_equal=b.conj(edge00, b.apply('xor', original['rhoE'], e00)) == 0,
                          E00_original_input_subset_under_current_obstacle_invariant=True,
                          SYS00_full_original_equal=True, Q_original_defined=True, Q_impl_defined=True,
                          Q_original_implies_Q_impl_under_current_obstacle_invariant=True,
                          Q_global_equal=b.conj(self.domain, off, b.apply('xor', q_orig, q_impl)) == 0)
        return result

    def carrier(self):
        n = 1
        for name in self.names:
            n *= len(self.values[name])
        return n

    def direct_q(self, state):
        c = self.contract
        inputs = [dict(zip(ENV, row)) for row in product(*(c.values[n] for n in ENV))]
        qo = any(c.rho_e(state, t) for t in inputs)
        qi = (state.get(HELPER) == 'true' or
              any(c.rho_e(dict(state, **{HELPER: 'false'}), dict(t, **{HELPER: 'false'}), True) for t in inputs))
        return qo, qi

    def verify_normalization(self, result):
        """Verify a saved descending V proof chain; do not solve the native Kind region."""
        need(not self.transformed, 'Normalized proof uses original source model')
        b, f = self.b, self.formulas
        alive = b.exists(b.conj(f['rhoE'], self.den), self.en)
        self.check_equal(result['alive'], alive, 'Original source Alive', self.current)
        def step(v):
            replies = b.exists(b.conj(f['rhoS'], self.dsn, b.rename(v, self.prime)), self.sn)
            return b.conj(self.domain, alive, b.forall(b.implies(b.conj(self.den, f['rhoE']), replies), self.en))
        rows = result['viability_iterations']
        need(type(rows) is list and 0 < len(rows) <= self.carrier() + 1, 'Saved V proof chain length')
        v = self.domain
        for i, row in enumerate(rows):
            need(type(row['iteration']) is int and row['iteration'] == i, 'Ordered V proof chain')
            self.check_equal(row['before'], v, 'V chain before', self.current)
            nxt = step(v)
            self.check_equal(row['after'], nxt, 'V chain after', self.current)
            need(b.conj(nxt, b.neg(v)) == 0 and row['descending'] is True
                 and row['equal'] is (nxt == v), 'Descending/fixed V proof flags')
            need((nxt == v) == (i == len(rows) - 1), 'V proof ends exactly at first fixed point')
            v = nxt
        need(step(v) == v, 'Terminal V fixed point')
        self.check_equal(result['V'], v, 'Exact greatest viable region', self.current)
        self.check_equal(result['normalization']['restricted_rhoS'], b.conj(f['rhoS'], v, b.rename(v, self.prime)), 'Source V restriction')
        self.check_equal(result['residual_thetaE'], f['thetaE'], 'Preserved source ENV initializer', self.ec)
        self.check_equal(result['residual_thetaS'], b.conj(f['thetaS'], v), 'Source SYS initializer restricted to V', self.current)
        region = self.load(result['final_region'], self.current)
        if result.get('native_solver_called'):
            native = self.load(result['native_W'], self.current)
            need(region == b.conj(v, native), 'Final region V intersection with native W')
        else:
            need(v == region == 0, 'No-solver empty V rejection')
        witness = b.conj(f['thetaS'], v, region)
        missing = b.conj(f['thetaE'], b.neg(b.exists(witness, self.sc)))
        q = result['original_initial_quantification']
        need(set(q['env_quantified_bits']) == self.ec and len(q['env_quantified_bits']) == len(self.ec)
             and set(q['sys_quantified_bits']) == self.sc and len(q['sys_quantified_bits']) == len(self.sc), 'Original initial quantifier bit roster')
        self.check_equal(q['system_witness'], witness, 'Initial SYS witness in saved region', self.current)
        self.check_equal(q['missing_environment_initials'], missing, 'Missing initial ENV choices', self.ec)
        need(q['verdict'] is (missing == 0) and result['initial_in_region'] is (missing == 0), 'Initial quantifier truth')
        if result.get('native_solver_called'):
            need(result['native_residual_initial_verdict'] is (missing == 0), 'Native versus exact initial quantifier truth')
        self.v = v
        return {'status': 'PASS_SAVED_V_CHAIN_AND_NORMALIZATION', 'saved_V_steps_recomputed': len(rows),
                'initial_quantifier_value': missing == 0, 'whole_region_K_recomputed': False,
                'native_final_region_semantically_certified_as_K': False}

