"""Direct typed source/controller audit; iterative graph algorithms, no BDD solver."""
from itertools import product
from collections import deque
from independent_core import need, finite_fairness
from source_semantics import ENV, HELPER, point

MAX_NODES = 4096
MAX_EDGES = 65536
MAX_INPUT_CHECKS = 1048576


def reached(starts, adjacency):
    out = set(starts); todo = list(starts)
    while todo:
        x = todo.pop()
        for y in adjacency[x]:
            if y not in out:
                out.add(y); todo.append(y)
    return out


def scc(vertices, edges):
    """Iterative Kosaraju, independent of production Tarjan/Warshall implementations."""
    vertices = set(vertices)
    adj, rev = {v: [] for v in vertices}, {v: [] for v in vertices}
    for x, y in edges:
        if x in vertices and y in vertices:
            adj[x].append(y); rev[y].append(x)
    seen, order = set(), []
    for start in sorted(vertices, key=int):
        if start in seen:
            continue
        seen.add(start); stack = [(start, iter(adj[start]))]
        while stack:
            x, children = stack[-1]
            try:
                y = next(children)
                if y not in seen:
                    seen.add(y); stack.append((y, iter(adj[y])))
            except StopIteration:
                order.append(x); stack.pop()
    seen, groups = set(), []
    for start in reversed(order):
        if start in seen:
            continue
        seen.add(start); todo, group = [start], []
        while todo:
            x = todo.pop(); group.append(x)
            for y in rev[x]:
                if y not in seen:
                    seen.add(y); todo.append(y)
        groups.append(sorted(group, key=int))
    return groups


def fairness(vertices, edges, env_justice, sys_justice):
    vertices, edges = set(vertices), set(map(tuple, edges))
    def accepting(group):
        z = set(group)
        return (len(z) > 1 or (group[0], group[0]) in edges) and all(z & set(a) for a in env_justice)
    groups = scc(vertices, edges)
    fair = [g for g in groups if accepting(g)]
    rev = {v: [] for v in vertices}
    for x, y in edges:
        rev[y].append(x)
    live = reached([v for g in fair for v in g], rev)
    counter = []
    for i, justice in enumerate(sys_justice):
        for g in scc(vertices - set(justice), edges):
            if accepting(g):
                counter.append({'SYS_justice_index': i, 'SCC': g})
    return {'method': 'Iterative Kosaraju SCCs and reverse reachability over direct source truth labels',
            'strict_liveness': {'pass': not counter, 'counterexamples': counter},
            'nonconflicting': {'pass': live == vertices, 'failing_states': sorted(vertices - live, key=int)},
            'SCCs': groups, 'ENV_accepting_SCCs': fair}


def audit(ctx, graph, result, printed=None, original_ctx=None):
    c, transformed = ctx.contract, ctx.transformed
    original_ctx = original_ctx if original_ctx is not None else (ctx if not transformed else None)
    need(original_ctx is not None, 'Independently source-matched original saved DAG model required')
    def dag(ctx0, name, s, t=None):
        a = ctx0.bits({k: v for k, v in s.items() if k in ctx0.names})
        if t is not None:
            a.update(ctx0.bits({k: v for k, v in t.items() if k in ctx0.names}, True))
        return ctx0.dags[ctx0.model['original_bdds'][name]['file']].value(a)
    allowed_schema = ('released-kind-complete-native-controller-v1', 'experimental-extractor-complete-controller-v1') if transformed else ('released-concrete-controller-export-v2',)
    need(graph['schema'] in allowed_schema and graph['complete'] is True, 'Complete native graph schema')
    need(graph['rank_domain_size'] == 1, 'One original SYS justice and native rank domain')
    nodes = graph['nodes']
    need(type(nodes) is list and 0 < len(nodes) <= MAX_NODES and graph['api_state_count'] == len(nodes), 'Graph state cap/count')
    by_id, edges, starts = {}, [], []
    printer_lines = printed.splitlines() if printed is not None else None
    if printer_lines is not None:
        need(len(printer_lines) == 2 * len(nodes), 'Complete printer line count')
    for i, n in enumerate(nodes):
        sid = n['id']
        need(type(sid) is str and sid == str(n['native_id']) and sid not in by_id, 'Distinct native IDs')
        need(type(n['native_id']) is int and n['native_id'] >= 0 and type(n['rank']) is int and n['rank'] == 0
             and n['rank_class'] == 'tau.smlab.syntech.games.gr1.GR1RankInfo'
             and n['rank_info'] == 'System Justice 0' and type(n['initial']) is bool, 'Rank/initial metadata')
        s = n['valuation']
        need(type(s) is dict and set(s) == set(ctx.names), 'Complete typed node valuation')
        need(type(n['bits']) is dict and all(type(v) is bool for v in n['bits'].values())
             and n['bits'] == {str(k): v for k, v in ctx.bits(s).items()}, 'Native bit/valuation identity')
        need(dag(ctx, 'thetaE', s) == c.theta_e(s, transformed)
             and dag(ctx, 'thetaS', s) == c.theta_s(s, transformed), 'Separate SavedDag all-node initializer truth')
        direct_justice = c.justices(s, transformed)
        for owner, expected_truth in zip(('ENV', 'SYS'), direct_justice):
            refs = ctx.model['original_justices'][owner]
            need([ctx.dags[r['file']].value(ctx.bits(s)) for r in refs] == expected_truth, 'Separate SavedDag all-node justice truth')
        successors = n['successors']
        need(type(successors) is list and all(type(t) is str for t in successors)
             and len(successors) == len(set(successors)), 'Distinct successor IDs')
        if printer_lines is not None:
            prefix = ('Initial State ' if n['initial'] else 'State ') + sid + ' '
            need(printer_lines[2*i].startswith(prefix + '<') and printer_lines[2*i].endswith('>'), 'Printed ID')
            body = printer_lines[2*i][len(prefix):]
            need(body == n['native_bdd_text'], 'Printed exact BDD valuation text')
            pairs = [x.split(':') for x in body[1:-1].split(', ')]
            need(all(len(p) == 2 for p in pairs) and len(dict(pairs)) == len(pairs) and dict(pairs) == s, 'Printed typed valuation')
            want = '\tWith successors : ' + ', '.join(successors) if successors else '\tWith no successors.'
            need(printer_lines[2*i+1] == want, 'Complete printed successor vector')
        by_id[sid] = n
        edges.extend((sid, t) for t in successors)
        if n['initial']:
            starts.append(sid)
    need(len(edges) <= MAX_EDGES and len(edges) == graph['api_transition_count'] and graph['edges'] == [list(e) for e in edges]
         and all(y in by_id for _, y in edges), 'Complete graph edge export/cap')
    adjacency = {sid: n['successors'] for sid, n in by_id.items()}
    need(starts and reached(starts, adjacency) == set(by_id), 'Every exported state reachable from native roots')
    if not transformed:
        need(graph['api_state_order'] == list(by_id) and graph['exported_edge_count'] == len(edges), 'Normalized raw API order/count')
    inputs = [dict(zip(ctx.env, row)) for row in product(*(ctx.values[n] for n in ctx.env))]
    original_inputs = [dict(zip(ENV, row)) for row in product(*(c.values[n] for n in ENV))]
    expected_init = set()
    for s in inputs:
        truth = c.theta_e(s, transformed)
        need(dag(ctx, 'thetaE', s) == truth, 'Separate SavedDag every initial ENV input')
        if truth: expected_init.add(tuple(s[n] for n in ctx.env))
    actual_init = []
    for sid in starts:
        s = by_id[sid]['valuation']
        need(c.theta_e(s, transformed) and c.theta_s(s, transformed) and c.theta_e(s) and c.theta_s(s), 'Exact native and original source initializers')
        need(dag(ctx, 'thetaE', s) and dag(ctx, 'thetaS', s)
             and dag(original_ctx, 'thetaE', s) and dag(original_ctx, 'thetaS', s), 'Separate SavedDag initial truth')
        actual_init.append(tuple(s[n] for n in ctx.env))
    need(len(set(actual_init)) == len(actual_init) and set(actual_init) == expected_init, 'All initial ENV inputs exactly once')
    need(len(nodes) * len(inputs) <= MAX_INPUT_CHECKS, 'Raw input coverage cap')
    for sid, n in by_id.items():
        s = n['valuation']; actual = {}
        expected = set()
        for t in inputs:
            direct = c.rho_e(s, t, transformed)
            need(dag(ctx, 'rhoE', s, t) == direct, 'Separate SavedDag raw ENV truth')
            if direct: expected.add(tuple(t[k] for k in ctx.env))
        for tid in n['successors']:
            t = by_id[tid]['valuation']; key = tuple(t[k] for k in ctx.env)
            need(key not in actual and c.rho_e(s, t, transformed) and c.rho_s(s, t, transformed), 'Raw exact transformed source safety/determinism')
            need(dag(ctx, 'rhoE', s, t) and dag(ctx, 'rhoS', s, t), 'Separate SavedDag raw safety truth')
            actual[key] = tid
        need(set(actual) == expected, 'Raw all legal ENV input coverage')
    # Preserve raw data, restrict first to helper=false then original legal ENV edges.
    allowed_nodes = {sid for sid, n in by_id.items() if not transformed or n['valuation'][HELPER] == 'false'}
    kept, discarded = [], []
    for a, z in edges:
        if a not in allowed_nodes or z not in allowed_nodes:
            discarded.append({'source': a, 'target': z, 'reason': 'HELPER_TRUE_ENDPOINT'})
        else:
            direct = c.rho_e(by_id[a]['valuation'], by_id[z]['valuation'])
            need(dag(original_ctx, 'rhoE', by_id[a]['valuation'], by_id[z]['valuation']) == direct, 'Separate SavedDag original edge filtering')
            if not direct:
                discarded.append({'source': a, 'target': z, 'reason': 'ORIGINAL_ENV_ILLEGAL'})
            else:
                kept.append((a, z))
    allowed_adj = {v: [] for v in allowed_nodes}
    for a, z in kept:
        allowed_adj[a].append(z)
    view_ids = reached(starts, allowed_adj)
    view_edges = [(a, z) for a, z in kept if a in view_ids]
    view_adj = {v: [] for v in view_ids}
    for a, z in view_edges:
        need(z in view_ids, 'Rooted legal view closure'); view_adj[a].append(z)
    need(len(view_ids) * len(original_inputs) <= MAX_INPUT_CHECKS, 'Original input coverage cap')
    q_rows, bad_safety, coverage = [], [], []
    for sid in sorted(view_ids, key=int):
        s = by_id[sid]['valuation']
        need(point(s, 'intruder') not in c.obstacles, 'Original reached ENV obstacle invariant')
        expected = set()
        for t in original_inputs:
            direct = c.rho_e(s, t)
            need(dag(original_ctx, 'rhoE', s, t) == direct, 'Separate SavedDag original ENV truth')
            if direct: expected.add(tuple(t[k] for k in ENV))
        actual = {}
        for tid in view_adj[sid]:
            t = by_id[tid]['valuation']; key = tuple(t[k] for k in ENV)
            need(key not in actual, 'Original response determinism')
            actual[key] = tid
            direct = c.rho_s(s, t)
            need(dag(original_ctx, 'rhoS', s, t) == direct, 'Separate SavedDag original SYS truth')
            if not direct:
                bad_safety.append({'source': sid, 'target': tid})
        if set(actual) != expected:
            coverage.append({'source': sid, 'missing': sorted(expected - set(actual)), 'extra': sorted(set(actual) - expected)})
        qo, qi = ctx.direct_q(s)
        if transformed:
            need(ctx.b.evaluate(ctx.q_original, ctx.bits(s)) == qo and ctx.b.evaluate(ctx.q_impl, ctx.bits(s)) == qi, 'Direct/BDD Q semantics agreement')
        q_rows.append({'id': sid, 'Q_original': qo, 'Q_impl': qi, 'original_legal_ENV_count': len(expected)})
    env_labels, sys_labels = [], [set()]
    for sid in view_ids:
        ea, sg = c.justices(by_id[sid]['valuation'])
        need(ea == [] and len(sg) == 1, 'Original source justice roster')
        raw = original_ctx.model['original_justices']['SYS'][0]
        need(original_ctx.dags[raw['file']].value(original_ctx.bits({k: v for k, v in by_id[sid]['valuation'].items() if k in original_ctx.names})) == sg[0], 'Separate SavedDag original justice truth')
        if sg[0]: sys_labels[0].add(sid)
    fair = fairness(view_ids, view_edges, env_labels, sys_labels)
    second = finite_fairness(view_ids, view_edges, starts, env_labels, sys_labels)
    need(fair['strict_liveness']['pass'] == second['strict_liveness']['pass']
         and fair['nonconflicting']['pass'] == second['nonconflicting']['pass']
         and fair['nonconflicting']['failing_states'] == second['nonconflicting']['failing_states'], 'Independent Kosaraju/Warshall fairness agreement')
    view = {'schema': 'v48-independent355-original-legal-view-v1', 'states': sorted(view_ids, key=int), 'starts': starts,
            'edges': [list(e) for e in view_edges], 'nodes': [by_id[s] for s in sorted(view_ids, key=int)],
            'env_justice': [], 'sys_justice': [sorted(x, key=int) for x in sys_labels], 'Q_rows': q_rows,
            'discarded_edges': discarded, 'unrooted_helper_false_nodes': sorted(allowed_nodes - view_ids, key=int)}
    summary = {'raw_states': len(nodes), 'raw_edges': len(edges), 'raw_exact_source_safety_and_coverage': True,
               'original_view_states': len(view_ids), 'original_view_edges': len(view_edges), 'initial_states': len(starts),
               'source_legal_input_checks': len(view_ids) * len(original_inputs),
               'discarded_edge_counts': {k: sum(e['reason'] == k for e in discarded) for k in ('HELPER_TRUE_ENDPOINT', 'ORIGINAL_ENV_ILLEGAL')},
               'source_safety_failures': bad_safety, 'source_input_coverage_failures': coverage, 'fairness': fair,
               'independent_strict': not bad_safety and not coverage and fair['strict_liveness']['pass'],
               'independent_nonconflicting': not bad_safety and not coverage and fair['nonconflicting']['pass'],
               'independent_cooperative': not bad_safety and not coverage and fair['strict_liveness']['pass'] and fair['nonconflicting']['pass'],
               'private_memory_preserved': True, 'raw_graph_mutated': False,
               'separate_SavedDag_truth_crosscheck': True, 'independent_Warshall_fairness_crosscheck': True,
               'view_policy': 'Rooted helper-false restriction filtered by exact original ENV relation; no reset, no output repair'}
    return summary, view

