"""Independent, hand-derived source semantics. Import performs no model evaluation.

The released syntactic reduction precedes invariant and past-time translation.
Consequently the exact transformed factors differ from a uniform rhoS OR b.
"""
from dataclasses import dataclass

SOURCE_BYTES = 2071
SOURCE_SHA256 = '6203bdf9a0e65726aa2d46503ae935ba2ac4e9fa27f00650ded83a25a5318c10'
HELPER = '~envHelp'
HISTORY = 'ONCE_aux_0'
ENV = ('intruderX', 'intruderY')
SYS = ('robotX0', 'robotY0', 'robotX1', 'robotY1')
BOOL = ('false', 'true')


def point(s, who):
    if who == 'intruder':
        return int(s['intruderX']), int(s['intruderY'])
    return int(s['robotX' + str(who)]), int(s['robotY' + str(who)])


def adjacent(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1]) == 1


def step(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1]) <= 1


@dataclass(frozen=True)
class Contract:
    maximum: int = 7
    obstacles: tuple = ((2, 1), (3, 1), (4, 1), (5, 1))

    @property
    def values(self):
        return {**{n: tuple(str(i) for i in range(self.maximum + 1)) for n in ENV + SYS}, HISTORY: BOOL}

    def corner(self, s):
        return point(s, 0) == (0, self.maximum)

    def invariants(self, s):
        a, b, e = point(s, 0), point(s, 1), point(s, 'intruder')
        return (a not in self.obstacles, b not in self.obstacles, a != b, e != a, e != b)

    def theta_e(self, s, transformed=False):
        e = point(s, 'intruder')
        return e[1] == self.maximum and ((s[HELPER] == 'false') if transformed else e not in self.obstacles)

    def theta_s(self, s, transformed=False):
        guard = transformed and s[HELPER] == 'true'
        return (point(s, 0) == (0, 0) and point(s, 1) == (self.maximum, 0)
                and all(x or guard for x in self.invariants(s))
                and (s[HISTORY] == 'true') == self.corner(s))

    def rho_e(self, s, t, transformed=False):
        e, ne = point(s, 'intruder'), point(t, 'intruder')
        avoid = tuple(not adjacent(point(s, i), e)
                      or (ne[0] != point(s, i)[0] and ne[1] != point(s, i)[1]) for i in (0, 1))
        if transformed:
            bn = t[HELPER] == 'true'
            return (all(x or bn for x in (e not in self.obstacles, step(e, ne), *avoid))
                    and (s[HELPER] == 'false' or bn))
        return ne not in self.obstacles and step(e, ne) and all(avoid)

    def rho_s(self, s, t, transformed=False):
        current_guard = transformed and s[HELPER] == 'true'
        next_guard = transformed and t[HELPER] == 'true'
        r0, r1, n0, n1 = point(s, 0), point(s, 1), point(t, 0), point(t, 1)
        movement0 = step(r0, n0)
        movement1 = ((s[HISTORY] == 'true' and step(r1, n1)) or r1 == n1)
        history = (t[HISTORY] == 'true') == (s[HISTORY] == 'true' or self.corner(t))
        return (all(x or next_guard for x in self.invariants(t))
                and (movement0 or current_guard) and (movement1 or current_guard) and history)

    def justices(self, s, transformed=False):
        goal = all(adjacent(point(s, i), point(s, 'intruder')) for i in (0, 1))
        return ([s[HELPER] == 'false'] if transformed else [], [goal])

