"""One root-authorized batch source/graph audit; no actual input reads at import.

Usage: python -I -S -B audit355.py ROOT_GO.json INPUTS.json NEW_OUTPUT_DIR
Synthetic qualification imports the modules directly and never invokes main.
"""
from pathlib import Path
from datetime import datetime, timezone
import importlib.util
import sys
import hashlib
import traceback
import json

HERE = Path(__file__).resolve().parent
for _name in ('independent_core', 'bdd_core', 'source_semantics', 'symbolic_source', 'model355', 'graph355', 'activity'):
    _spec = importlib.util.spec_from_file_location(_name, HERE / (_name + '.py'))
    _module = importlib.util.module_from_spec(_spec)
    sys.modules[_name] = _module
    _spec.loader.exec_module(_module)

from independent_core import need, decode_json, read_pin, save_new, pin
from source_semantics import Contract, SOURCE_BYTES, SOURCE_SHA256
from model355 import Model
from graph355 import audit as graph_audit
from activity import compare as compare_views

CODE_NAMES = ('audit355.py', 'independent_core.py', 'bdd_core.py', 'source_semantics.py', 'symbolic_source.py', 'model355.py', 'graph355.py', 'activity.py')


def now():
    return datetime.now(timezone.utc).isoformat()


def process_complete(ref):
    p = decode_json(read_pin(ref))
    need(p['status'] == 'PROCESS_COMPLETED' and p['exit_code'] == 0 and p['owned_child_reaped'] is True
         and p['final_group_observation']['state'] == 'ABSENT'
         and not p['fatal_reasons'] and not p['resource_reasons'], 'Incomplete bounded native process')
    need(set(p['capture']) == {'stdout', 'stderr'} and all(v['complete'] is True for v in p['capture'].values()), 'Incomplete process capture')
    need(p.get('parent_finalization_completed') is True and p.get('receipt_persisted') is True
         and p.get('parent_aborted') is False and p.get('exact_child_wait4', {}).get('exact_child_reaped') is True
         and not p.get('exact_child_wait4', {}).get('authority_lost'), 'Exact parent/child process finalization')


def model_context(row, transformed):
    model = decode_json(read_pin(row['model']))
    need(model['input']['sha256'] == SOURCE_SHA256 and model['input']['bytes'] == SOURCE_BYTES, 'Source/model exact pin')
    need(model['fixture_id'] == 'corpus355__original', 'Fixed355 model identity')
    ctx = Model(model, row['bdd_files'], Contract(), transformed)
    return ctx, ctx.verify_source()


def justice_phases(ctx, result, normalized):
    phases = ('preconstructor_justices', 'solver_input_justices') if normalized else ('preconstructor_justices', 'solver_justices')
    checked = {}
    for phase in phases:
        if phase not in result:
            if normalized and not result.get('native_solver_called') and phase == 'solver_input_justices':
                continue
            need(False, 'Missing native justice phase: ' + phase)
        checked[phase] = {}
        for owner in ('ENV', 'SYS'):
            expected = ctx.justices[owner]
            if phase.startswith('solver') and not expected:
                expected = [1]
            refs = result[phase][owner]
            need(len(refs) == len(expected), 'Exact ordered justice phase count')
            for ref, wanted in zip(refs, expected):
                ctx.check_equal(ref, wanted, phase + ' ' + owner, ctx.current)
            checked[phase][owner] = len(refs)
    return checked


def native_binding(row, result, ctx):
    mode, label = row['mode'], row['label']
    need(mode in ('syntactic', 'normalized'), 'Fixed native mode')
    need(result['input_sha256'] == SOURCE_SHA256 and result['fixture_id'] == 'corpus355__original'
         and result['teardown'] == 'COMPLETED', 'Completed native source identity')
    need(result['model_export']['bytes'] == row['model']['bytes']
         and result['model_export']['sha256'] == row['model']['sha256'], 'Result/model export binding')
    if mode == 'syntactic':
        need(result['schema'] in ('released-kind-job-native-result-v1', 'experimental-extractor-native-result-v1'), 'Pair result schema')
        expected_pipeline = 'released_syntactic_4fp_experimental_extractor' if label == 'preference' else 'released_syntactic_kind_job_equivalent'
        need(result['pipeline'] == expected_pipeline and result['solver'] == '4fp'
             and result['native_solver_calls'] == 1, 'One native syntactic solver call')
        need(result['helper_added'] is True and result['helper_is_native_nonaux_ENV'] is True
             and result['initializers_replaced'] is False and result['semantic_reduction_used'] is False
             and result['ENV_justice_normalization_used'] is False, 'Fixed syntactic/helper pipeline')
        need(result['status'] in ('JOB_UNREALIZABLE_NO_CONTROLLER', 'JOB_EMPTY_MEMORY_NO_CONTROLLER', 'JOB_CONTROLLER_PRINTED'), 'Pair supported completed outcome')
    else:
        need(result['schema'] == 'k7-native-admission-production-v1' and result['pipeline'] == 'normalized_kind'
             and result['solver'] == '4fp', 'Normalized result identity')
        need(result['status'] in ('COMPLETE_EMPTY_V_REJECTION', 'COMPLETE_REGION_REJECTION', 'COMPLETE_CONTROLLER_EXPORTED', 'COMPLETE_EXTRACTION_OR_EXPORT_FAILURE'), 'Normalized supported outcome')
        norm = result['normalization']
        need(norm['helper_added'] is False and norm['V_restriction'] is True and norm['ENV_justice_copies'] == 0, 'Fixed original source normalized pipeline')
    return justice_phases(ctx, result, mode == 'normalized')


def audit_job(row, output, original_ctx):
    if row.get('status') == 'NOT_RUN':
        need(row['label'] == 'preference' and row['mode'] == 'syntactic'
             and row['reason'] == 'PAIR_BASELINE_NO_CONTROLLER'
             and set(row) == {'label', 'mode', 'status', 'reason'}, 'Exact declared dependent nonexecution')
        return {'label': 'preference', 'mode': 'syntactic', 'status': 'NOT_RUN_PAIR_BASELINE_NO_CONTROLLER',
                'independent_strict': None, 'independent_cooperative': None}, None
    process_complete(row['process'])
    transformed = row['mode'] == 'syntactic'
    ctx, correspondence = model_context(row, transformed)
    result = decode_json(read_pin(row['result']))
    phases = native_binding(row, result, ctx)
    normalization = ctx.verify_normalization(result) if row['mode'] == 'normalized' else None
    preference_checked = False
    if row['label'] == 'preference':
        ctx.check_equal(result['selection_preference'], ctx.q_impl, 'Unchanged extractor Q_impl preference', ctx.current)
        preference_checked = True
    answer = {'label': row['label'], 'mode': row['mode'], 'status': 'PASS_SOURCE_MODEL_NO_GRAPH',
              'native_outcome': result['status'], 'source_correspondence': correspondence,
              'justice_phases': phases, 'independent_strict': None, 'independent_cooperative': None,
              'input_bindings': row, 'whole_region_K_recomputed': False,
              'native_verdict_independently_proven': False}
    answer['selection_preference_equals_Q_impl'] = preference_checked
    answer['normalization_certificate'] = normalization
    has_graph = result['status'] in ('JOB_CONTROLLER_PRINTED', 'COMPLETE_CONTROLLER_EXPORTED')
    need(('controller' in row) == has_graph, 'Exact graph presence for native outcome')
    if not has_graph:
        need('printer' not in row, 'Printer without graph')
        if transformed:
            if result['status'] == 'JOB_UNREALIZABLE_NO_CONTROLLER':
                need(result['native_initial_verdict'] is False and result['memory_empty_guard_called'] is False, 'Native false short circuit')
            else:
                need(result['native_initial_verdict'] is True and result['memory_empty_guard_called'] is True and result['memory_empty'] is True, 'Native empty-memory short circuit')
            need(result['controller_extraction_calls'] == result['native_printer_calls'] == 0, 'No extraction on short circuit')
        answer['no_graph_scope'] = 'Native completed no-controller outcome only; source-model correspondence does not independently establish a losing region.'
        return answer, None
    graph_raw = read_pin(row['controller']); graph = decode_json(graph_raw)
    need(graph['model_sha256'] == row['model']['sha256'], 'Graph/model pin')
    for key in ('bytes', 'sha256'):
        need(result['controller_export'][key] == row['controller'][key], 'Result/controller pin')
    printed = None
    if transformed:
        need(result['native_initial_verdict'] is True and result['memory_empty_guard_called'] is True and result['memory_empty'] is False
             and result['memory_complete'] is True and result['controller_extraction_calls'] == result['native_printer_calls'] == 1, 'Completed native extraction')
        need(result['same_native_memory_passed_to_constructor'] is True and result['same_native_model_passed_to_constructor'] is True
             and graph['native_memory_identity'] == result['native_memory_identity'], 'Exact native model/memory reuse')
        need(graph_raw.endswith(b'\n') and hashlib.sha256(graph_raw[:-1]).hexdigest() == result['controller_after_print_sha256']
             and result['controller_before_print_sha256'] == result['controller_after_print_sha256'], 'Before/after print graph binding')
        need('printer' in row, 'Complete native printer required')
        printed = read_pin(row['printer']).decode('utf-8')
        need(all(result['printed_controller'][k] == row['printer'][k] for k in ('bytes', 'sha256')), 'Printer pin')
    summary, view = graph_audit(ctx, graph, result, printed, original_ctx)
    path = output / (row['label'] + '_ORIGINAL_VIEW.json'); save_new(path, view)
    answer.update(summary, status='PASS_COMPLETE_SOURCE_GRAPH_AUDIT', view_pin=pin(path),
                  saved_BDD_files=sorted(ctx.loaded), source_expected_BDD_nodes=len(ctx.b.nodes))
    return answer, view


def main():
    need(len(sys.argv) == 4, 'Usage audit355.py ROOT_GO INPUTS NEW_OUTPUT')
    go_path, manifest_path, output = map(lambda x: Path(x).resolve(), sys.argv[1:])
    manifest = decode_json(manifest_path.read_bytes())
    need(manifest['schema'] == 'v48-independent355-inputs-v1' and manifest['authorization'] == pin(go_path), 'Exact input manifest/root authorization')
    go = decode_json(read_pin(manifest['authorization']))
    need(go.get('start_authorized') is True and go.get('oracle355_worker_budget') == 1, 'Root one-worker authorization')
    wanted_code = [pin(HERE / n) for n in CODE_NAMES]
    need(go.get('oracle355_code') == wanted_code, 'Root frozen exact oracle code roster')
    need(not output.exists() and not output.is_symlink(), 'Fresh absent output required')
    output.mkdir()
    started = now()
    need(read_pin(manifest['source']) and manifest['source']['bytes'] == SOURCE_BYTES and manifest['source']['sha256'] == SOURCE_SHA256, 'Exact355source')
    read_pin(manifest['import'])
    need(manifest['import']['bytes'] == 49400 and manifest['import']['sha256'] == '5c45b64f7b9b9f4f480d3cb485adcd8a772bce6d6c11356345386c5f143333cc', 'Exact imported DwyerPatterns source')
    rows, views, original, original_ctx = [], {}, None, None
    try:
        original_ctx, original = model_context(manifest['original_model'], False)
    except Exception as error:
        original = {'status': 'UNKNOWN_SOURCE_MODEL', 'error': str(error), 'traceback': traceback.format_exc()}
    need([r['label'] for r in manifest['jobs']] == ['baseline', 'preference', 'normalized'], 'Fixed complete three-arm roster')
    for row in manifest['jobs']:
        try:
            if row.get('status') == 'NOT_RUN':
                need(rows and rows[0].get('native_outcome') in ('JOB_UNREALIZABLE_NO_CONTROLLER', 'JOB_EMPTY_MEMORY_NO_CONTROLLER'), 'Dependent nonexecution requires a completed no-controller baseline')
            answer, view = audit_job(row, output, original_ctx)
            if view is not None: views[row['label']] = view
        except Exception as error:
            answer = {'label': row['label'], 'status': 'UNKNOWN_INDEPENDENT_AUDIT', 'error': str(error), 'traceback': traceback.format_exc()}
        rows.append(answer)
        save_new(output / (row['label'] + '_RESULT.json'), answer)
    try:
        activity = compare_views(views['baseline'], views['preference']) if {'baseline', 'preference'} <= set(views) else {'status': 'UNKNOWN_BOTH_SOURCELEGAL_GRAPHS_REQUIRED'}
    except Exception as error:
        activity = {'status': 'UNKNOWN_ACTIVITY', 'error': str(error), 'traceback': traceback.format_exc()}
    final = {'schema': 'v48-independent355-audit-v1', 'status': 'COMPLETE_BOUNDED_INDEPENDENT_AUDIT',
             'original_source_model': original, 'rows': rows, 'started_utc': started, 'finished_utc': now(),
             'observed_graph_activity': activity,
             'input_manifest': pin(manifest_path), 'authorization': manifest['authorization'], 'code': wanted_code,
             'native_JVM_calls': 0, 'compiler_calls': 0, 'whole_region_K_solves': 0, 'full_reset_uses': 0,
             'saved_V_steps_recomputed': sum((r.get('normalization_certificate') or {}).get('saved_V_steps_recomputed', 0) for r in rows),
             'production_certificates_read': False, 'raw_graphs_modified': False}
    save_new(output / 'RESULT.json', final)
    print(json.dumps({'status': final['status'], 'rows': [{k: r[k] for k in ('label', 'status')} for r in rows]}))
    return 0 if original.get('status') == 'PASS_FULL_SOURCE_NATIVE_CORRESPONDENCE' and all(r['status'].startswith(('PASS_', 'NOT_RUN_')) for r in rows) else 2


if __name__ == '__main__':
    sys.exit(main())

