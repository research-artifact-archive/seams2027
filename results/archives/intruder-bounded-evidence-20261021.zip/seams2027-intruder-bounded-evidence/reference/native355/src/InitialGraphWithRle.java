import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

public final class InitialGraphWithRle {
  public static void main(String[] args) throws Exception {
    if(args.length!=6)throw new IllegalArgumentException("id pipeline solver input result origins");
    Path receipt=Paths.get(args[4]).toAbsolutePath().getParent().resolve("RLE_STDOUT_RECEIPT.json");
    LosslessStdoutRle stream=new LosslessStdoutRle(System.out,receipt);
    Runtime.getRuntime().addShutdownHook(new Thread(()->{
      try{stream.finish();}catch(Exception ex){ex.printStackTrace(System.err);}
    },"lossless-stdout-rle-finalizer"));
    System.setOut(new PrintStream(stream,true,StandardCharsets.UTF_8));
    InitialGraphProducer.main(args);
  }
}
