import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

/** Reversible transport encoding. No BDD, solver or producer code is changed. */
public final class LosslessStdoutRle extends OutputStream {
  static final byte[] REPEAT = ("lookup, class net.sf.javabdd.JTLVJavaFactory$BddCache" + System.lineSeparator()).getBytes(StandardCharsets.UTF_8);
  static final long DECODED_CAP = 8L * 1024 * 1024 * 1024;
  static final int CHUNK_CAP = 65536;
  private final OutputStream encoded;
  private final Path receipt;
  private final MessageDigest digest;
  private final ByteArrayOutputStream line = new ByteArrayOutputStream(128);
  private long rawBytes, runCount, totalRepeatedLines, recordCount;
  private boolean finished, capReached;

  public LosslessStdoutRle(OutputStream encoded, Path receipt) throws Exception {
    this.encoded=encoded; this.receipt=receipt; this.digest=MessageDigest.getInstance("SHA-256");
  }
  private void record(String value) throws IOException {
    encoded.write((value+"\n").getBytes(StandardCharsets.US_ASCII)); recordCount++;
  }
  private void flushRun() throws IOException {
    if(runCount!=0){record("{\"kind\":\"repeat\",\"count\":"+runCount+",\"data\":\""+Base64.getEncoder().encodeToString(REPEAT)+"\"}");runCount=0;}
  }
  private void chunk() throws IOException {
    byte[] data=line.toByteArray(); line.reset();
    if(Arrays.equals(data,REPEAT)){
      runCount++;totalRepeatedLines++;
      if(runCount==1000000)flushRun();
    }else if(data.length>0){
      flushRun();record("{\"kind\":\"bytes\",\"data\":\""+Base64.getEncoder().encodeToString(data)+"\"}");
    }
  }
  @Override public synchronized void write(byte[] data,int off,int len) throws IOException {
    if(finished)throw new IOException("RLE stream already finished");
    Objects.checkFromIndexSize(off,len,data.length);
    if(rawBytes+len>DECODED_CAP){capReached=true;throw new IllegalStateException("RLE_DECODED_STDOUT_8_GIB_CAP");}
    digest.update(data,off,len);rawBytes+=len;
    int at=off, end=off+len;
    while(at<end){
      int room=CHUNK_CAP-line.size(), stop=Math.min(end,at+room), k=at;
      while(k<stop && data[k]!='\n')k++;
      if(k<stop)k++;
      line.write(data,at,k-at);at=k;
      if(line.size()==CHUNK_CAP || (k>off && data[k-1]=='\n'))chunk();
    }
  }
  @Override public synchronized void write(int data) throws IOException {write(new byte[]{(byte)data},0,1);}
  @Override public synchronized void flush() throws IOException {
    // A PrintStream flush after every println must not split a repeated run.
    encoded.flush();
  }
  public synchronized void finish() throws IOException {
    if(finished)return;
    chunk();flushRun();
    String hash=HexFormat.of().formatHex(digest.digest());
    String info="{\"kind\":\"end\",\"schema\":\"lossless-exact-line-rle-v1\",\"raw_bytes\":"+rawBytes+",\"raw_sha256\":\""+hash+"\",\"repeated_lines\":"+totalRepeatedLines+",\"data_records\":"+recordCount+",\"decoded_cap_bytes\":"+DECODED_CAP+",\"cap_reached\":"+capReached+"}";
    record(info);encoded.flush();finished=true;
    if(receipt!=null)Files.writeString(receipt,info+"\n",StandardCharsets.US_ASCII,StandardOpenOption.CREATE_NEW);
  }
  @Override public void close() throws IOException {finish();}
}
