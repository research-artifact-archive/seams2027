import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

/** Reversible stdout transport only; paired game/solver/extraction are unchanged. */
public final class PairedContinuationWithRle {
  public static void main(String[] args) throws Exception {
    if(args.length!=4)throw new IllegalArgumentException("fixture input result origins");
    Path receipt=Paths.get(args[2]).toAbsolutePath().getParent().resolve("RLE_STDOUT_RECEIPT.json");
    LosslessStdoutRle stream=new LosslessStdoutRle(System.out,receipt);
    Runtime.getRuntime().addShutdownHook(new Thread(()->{
      try{stream.finish();}catch(Exception ex){ex.printStackTrace(System.err);}
    },"lossless-stdout-rle-finalizer"));
    System.setOut(new PrintStream(stream,true,StandardCharsets.UTF_8));
    PairedContinuationDiagnostic.main(args);
  }
}
