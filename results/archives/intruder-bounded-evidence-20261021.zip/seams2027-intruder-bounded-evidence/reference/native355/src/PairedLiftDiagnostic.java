import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.io.*;
import java.time.Instant;
import java.util.*;
import net.sf.javabdd.*;
import org.apache.log4j.*;
import org.apache.log4j.spi.LoggingEvent;
import tau.smlab.syntech.jtlv.env.module.ModuleBDDField;
import tau.smlab.syntech.spectragameinput.SpectraInputProviderNoIDE;
import tau.smlab.syntech.gameinputtrans.TranslationProvider;
import tau.smlab.syntech.gameinput.model.*;
import tau.smlab.syntech.gameinput.spec.*;
import tau.smlab.syntech.bddgenerator.BDDGenerator;
import tau.smlab.syntech.bddgenerator.BDDGenerator.TraceInfo;
import tau.smlab.syntech.gamemodel.*;
import tau.smlab.syntech.games.gr1.*;
import tau.smlab.syntech.games.controller.enumerate.*;
import tau.smlab.syntech.gameinput.kind.PitermanSyntacticReduction;
import tau.smlab.syntech.games.controller.enumerate.printers.SimpleTextPrinter;
import tau.smlab.syntech.jtlv.*;

/** One immutable input and one check per JVM. No packaged CLI or custom repair. */
public final class PairedLiftDiagnostic {
  static final Map<String,Object> out = new LinkedHashMap<>();
  static Path receipt;
  static volatile String stage = "START";
  static long start;
  static String fixtureId,caseId,variant,pipeline,selectedSolver;
  static java.math.BigInteger carrierSize=java.math.BigInteger.ONE;
  static final List<Object> stageEvents=new ArrayList<>();
  static final Map<String,Long> sampledPeakHeap=new LinkedHashMap<>();
  static Timer heapSampler;
  static void sampleHeap(){long used=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();synchronized(sampledPeakHeap){sampledPeakHeap.put(stage,Math.max(sampledPeakHeap.getOrDefault(stage,0L),used));}}
  static void startHeapSampler(){heapSampler=new Timer("k7-heap-sampler",true);heapSampler.scheduleAtFixedRate(new TimerTask(){public void run(){sampleHeap();}},0,20);}

  static Map<String,Object> m(Object... kv) {
    Map<String,Object> x = new LinkedHashMap<>();
    for(int i=0;i<kv.length;i+=2) x.put((String)kv[i],kv[i+1]);
    return x;
  }
  static String q(String s) {
    StringBuilder b=new StringBuilder("\"");
    for(char c:s.toCharArray()) switch(c) {
      case '"': b.append("\\\""); break;
      case '\\': b.append("\\\\"); break;
      case '\n': b.append("\\n"); break;
      case '\r': b.append("\\r"); break;
      case '\t': b.append("\\t"); break;
      default: if(c<32) b.append(String.format("\\u%04x",(int)c)); else b.append(c);
    }
    return b.append('"').toString();
  }
  static String json(Object x) {
    if(x==null) return "null";
    if(x instanceof Boolean || x instanceof Number) return x.toString();
    if(x instanceof Map) {
      List<String> z=new ArrayList<>();
      for(Object e0:((Map<?,?>)x).entrySet()) {
        Map.Entry<?,?> e=(Map.Entry<?,?>)e0; z.add(q(String.valueOf(e.getKey()))+":"+json(e.getValue()));
      }
      return "{"+String.join(",",z)+"}";
    }
    if(x instanceof Iterable) {
      List<String> z=new ArrayList<>(); for(Object v:(Iterable<?>)x) z.add(json(v));
      return "["+String.join(",",z)+"]";
    }
    return q(String.valueOf(x));
  }
  static String sha(byte[] b) throws Exception {
    byte[] h=MessageDigest.getInstance("SHA-256").digest(b);
    StringBuilder s=new StringBuilder(); for(byte x:h) s.append(String.format("%02x",x&255)); return s.toString();
  }
  static void checkpoint(String s) throws Exception {
    sampleHeap();long elapsed=(System.nanoTime()-start)/1000000;
    Runtime rt=Runtime.getRuntime();
    stageEvents.add(m("stage",s,"elapsed_ms",elapsed,"heap_used_bytes",rt.totalMemory()-rt.freeMemory(),"heap_committed_bytes",rt.totalMemory(),"heap_max_bytes",rt.maxMemory()));
    stage=s; out.put("stage",stage); out.put("elapsed_ms",elapsed);out.put("stage_events",stageEvents);
    synchronized(sampledPeakHeap){out.put("sampled_peak_heap_by_stage",new LinkedHashMap<>(sampledPeakHeap));}
    out.put("heap_measurement",m("period_ms",20,"scope","sampled JVM heap used, excludes direct memory and OS RSS"));
    Path t=receipt.resolveSibling(receipt.getFileName()+".tmp");
    Files.writeString(t,json(out)+"\n",StandardCharsets.UTF_8);
    Files.move(t,receipt,StandardCopyOption.REPLACE_EXISTING);
  }
  static Object identity(Class<?> c) throws Exception {
    String r="/"+c.getName().replace('.','/')+".class";
    try(InputStream in=c.getResourceAsStream(r)) {
      return m("class",c.getName(),"code_source",String.valueOf(c.getProtectionDomain().getCodeSource()),"class_sha256",sha(in.readAllBytes()));
    }
  }
  static Object constraint(Constraint c) {
    return m("name",c.getName(),"kind",String.valueOf(c.getKind()),"trace_id",c.getTraceId(),"spec",String.valueOf(c.getSpec()),"spec_ast",specTree(c.getSpec()),"text",c.toString());
  }
  static Object player(Player p) {
    List<Object> vars=new ArrayList<>(), cons=new ArrayList<>(), pats=new ArrayList<>(), triggers=new ArrayList<>();
    for(Variable v:p.getVars()) vars.add(m("name",v.getName(),"type",String.valueOf(v.getType()),"trace_id",v.getTraceId()));
    for(Constraint c:p.getConstraints()) cons.add(constraint(c));
    for(PatternConstraint c:p.getPatterns()) pats.add(m("name",c.getName(),"trace_id",c.getTraceId(),"pattern",String.valueOf(c.getPattern()),"actuals",String.valueOf(c.getParameters()),"actuals_ast",specTrees(c.getParameters()),"text",c.toString()));
    for(TriggerConstraint c:p.getTriggers()) triggers.add(constraint(c));
    return m("variables",vars,"constraints",cons,"patterns",pats,"triggers",triggers,"existential_count",p.getExistentialConstraints().size());
  }
  static Object inventory(GameInput gi) { return m("ENV",player(gi.getEnv()),"SYS",player(gi.getSys()),"AUX",player(gi.getAux())); }
  static Object behaviors(List<BehaviorInfo> bs) {
    List<Object> a=new ArrayList<>();
    for(BehaviorInfo b:bs) a.add(m("trace_id",b.traceId,"aux",b.aux,"initial",b.isInitial(),"safety",b.isSafety(),"justice",b.isJustice(),"existential",b.isExistential()));
    return a;
  }
  static Object modelInventory(GameModel gm) {
    return m("ENV",behaviors(gm.getEnvBehaviorInfo()),"SYS",behaviors(gm.getSysBehaviorInfo()),"AUX",behaviors(gm.getAuxBehaviorInfo()),"env_fields",gm.getEnv().getAllFields().toString(),"sys_fields",gm.getSys().getAllFields().toString(),"env_justice_count",gm.getEnv().justiceNum(),"sys_justice_count",gm.getSys().justiceNum(),"env_initial_false",gm.getEnv().initial().isZero(),"sys_initial_false",gm.getSys().initial().isZero());
  }
  static String backend() {
    BDD t=Env.TRUE(); String c=t.getFactory().getClass().getName(); t.free();
    if(!c.equals("net.sf.javabdd.JTLVJavaFactory")) throw new IllegalStateException("Unexpected BDD backend: "+c);
    return c;
  }
  static final List<String> validatorErrors = Collections.synchronizedList(new ArrayList<>());
  static final class ValidationLogWatch extends AppenderSkeleton {
    protected void append(LoggingEvent e) {
      String n=e.getLoggerName();
      if(n!=null && n.contains("validation") && e.getLevel().isGreaterOrEqual(Level.ERROR)) {
        validatorErrors.add(n+": "+e.getRenderedMessage());
      }
    }
    public void close() {} public boolean requiresLayout() { return false; }
  }
  static void validationHealthy() {
    if(!validatorErrors.isEmpty()) throw new IllegalStateException("VALIDATOR_ERROR_LOG: "+validatorErrors);
  }
  static final class UnsupportedDomain extends RuntimeException {
    UnsupportedDomain(String message) { super(message); }
  }
  static void auditSpec(Spec s,boolean prime,boolean initial,Set<String> sys,List<String> violations) {
    if(s instanceof SpecExp) {
      SpecExp e=(SpecExp)s;
      for(Spec child:e.getChildren())auditSpec(child,prime||e.getOperator()==Operator.PRIME,initial,sys,violations);
    } else if(s instanceof VariableReference) {
      VariableReference r=(VariableReference)s;
      String n=r.getVariable().getName();
      boolean p=prime||r.getReferenceName().endsWith("'");
      if(sys.contains(n)&&(p||initial))violations.add((initial?"ENV initial references SYS ":"ENV next references SYS ")+n);
      if(r.getIndexSpecs()!=null)for(Spec idx:r.getIndexSpecs())auditSpec(idx,prime,initial,sys,violations);
    } else if(!(s instanceof PrimitiveValue)) {
      violations.add("Unsupported translated ENV expression class: "+s.getClass().getName());
    }
  }
  static void auditTranslated(GameInput gi) {
    Set<String> sys=new HashSet<>();
    for(Variable v:gi.getSys().getVars())sys.add(v.getName());
    for(Variable v:gi.getAux().getVars())sys.add(v.getName());
    List<String> violations=new ArrayList<>();
    for(Constraint c:gi.getEnv().getConstraints()) {
      if(c.getKind()==Constraint.Kind.INI||c.getKind()==Constraint.Kind.SAFETY)
        auditSpec(c.getSpec(),false,c.getKind()==Constraint.Kind.INI,sys,violations);
    }
    out.put("translated_turn_audit",m("SYS_and_AUX_names",sys,"violations",violations));
    if(!violations.isEmpty())throw new UnsupportedDomain(String.join("; ",violations));
  }
  static List<Integer> ints(int[] xs) { List<Integer> a=new ArrayList<>(); for(int x:xs)a.add(x); return a; }
  static List<Integer> support(BDD b) { BDDVarSet s=b.support(); List<Integer> r=ints(s.toArray()); s.free(); return r; }
  static void currentOnly(String name,BDD b) {
    if(Env.containPrimeVars(b)) throw new IllegalStateException(name+" contains next-state support: "+support(b));
  }
  static boolean subset(BDD a,BDD b) { BDD n=b.not(),x=a.and(n);boolean ok=x.isZero();x.free();n.free();return ok; }
  static Map<String,Object> snapshot(String name,BDD b) throws Exception {
    Path f=receipt.getParent().resolve(name+".bdd");Env.saveBDD(f.toString(),b,false);
    return m("file",f.getFileName().toString(),"bytes",Files.size(f),"sha256",sha(Files.readAllBytes(f)),"node_count",b.nodeCount(),"zero",b.isZero(),"one",b.isOne(),"support",support(b));
  }
  static BDD domain(PlayerModule pm,boolean next) {
    BDD d=Env.TRUE();
    for(ModuleBDDField f:pm.getAllFields()) d.andWith((next?f.other():f).getDomain().domain());
    return d;
  }
  static Object fields(PlayerModule pm) {
    List<Object> a=new ArrayList<>();
    for(ModuleBDDField f:pm.getAllFields()) a.add(m("field",f.toString(),"domain_size",f.getDomain().size().toString(),"current_bits",ints(f.getDomain().vars()),"next_bits",ints(f.other().getDomain().vars())));
    return a;
  }
  static void checkOrigins(Path file)throws Exception{Properties ps=new Properties();try(Reader r=Files.newBufferedReader(file)){ps.load(r);}require(ps.size()==22,"origin roster count");List<Object> ids=new ArrayList<>();for(String n:new TreeSet<>(ps.stringPropertyNames())){Class<?> c=Class.forName(n,false,ClassLoader.getSystemClassLoader());Path a=Paths.get(c.getProtectionDomain().getCodeSource().getLocation().toURI());require(Files.isSameFile(a,Paths.get(ps.getProperty(n))),"wrong class origin "+n);ids.add(identity(c));}out.put("class_identities",ids);}
  static final class InvariantMismatch extends RuntimeException{InvariantMismatch(String s){super(s);}}
  static void require(boolean b,String s){if(!b)throw new InvariantMismatch(s);}
  static Object specTree(Spec s){
    if(s==null)return null;
    if(s instanceof SpecExp){SpecExp e=(SpecExp)s;List<Object>children=new ArrayList<>();for(Spec c:e.getChildren())children.add(specTree(c));return m("kind","operator","operator",e.getOperator().toString(),"children",children);}
    if(s instanceof VariableReference){VariableReference v=(VariableReference)s;return m("kind","variable","name",v.getVariable().getName(),"reference_name",v.getReferenceName(),"trace_id",v.getVariable().getTraceId());}
    if(s instanceof PrimitiveValue)return m("kind","primitive","value",((PrimitiveValue)s).getValue());
    return m("kind","other","class",s.getClass().getName(),"text",s.toString());
  }
  static List<Object>specTrees(Iterable<Spec> xs){List<Object>r=new ArrayList<>();for(Spec x:xs)r.add(specTree(x));return r;}
  static Map<String,Object> filePin(Path p)throws Exception{return m("file",p.getFileName().toString(),"bytes",Files.size(p),"sha256",sha(Files.readAllBytes(p)));}
  static Map<String,Object> writeJson(String file,Map<String,Object> data)throws Exception{Path p=receipt.getParent().resolve(file);Files.writeString(p,json(data)+"\n",StandardCharsets.UTF_8);return filePin(p);}
  static Map<String,Object> identityFields(){return m("fixture_id",fixtureId,"case_id",caseId,"variant",variant);}
  static void equality(String label,BDD actual,BDD expected)throws Exception{BDD diff=actual.xor(expected);out.put(label,m("equal",diff.isZero(),"actual",snapshot(label+"_actual",actual),"expected",snapshot(label+"_expected",expected),"xor",snapshot(label+"_xor",diff)));boolean ok=diff.isZero();diff.free();expected.free();require(ok,label+" BDD equality failed");}
  static List<ModuleBDDField> allFields(GameModel gm){List<ModuleBDDField>x=new ArrayList<>();x.addAll(gm.getEnv().getAllFields());x.addAll(gm.getSys().getAllFields());return x;}
  static Map<String,Object> fixedBits(BDD b,int[]indices){Map<String,Object>r=new TreeMap<>();for(int bit:indices){BDD yes=b.getFactory().ithVar(bit),no=b.getFactory().nithVar(bit);boolean y=subset(b,yes),n=subset(b,no);yes.free();no.free();require(y!=n,"Incomplete or empty bit assignment "+bit);r.put(String.valueOf(bit),y);}return r;}
  static Map<String,Object> stateBits(BDD b,GameModel gm){BDDVarSet vars=gm.getEnv().moduleUnprimeVars().union(gm.getSys().moduleUnprimeVars());Map<String,Object>r=fixedBits(b,vars.toArray());vars.free();return r;}
  static Map<String,Object> singletonValuation(BDD b,GameModel gm){
    currentOnly("complete valuation",b);if(b.isZero())return null;Map<String,Object>r=new LinkedHashMap<>();BDD cube=Env.TRUE();
    for(ModuleBDDField field:allFields(gm)){String name=field.getName(),chosen=null;List<String>values=Env.getValueNames(name);int count=0;
      for(String value:values){BDD literal=Env.getBDDValue(name,value);require(literal!=null,"Missing native domain value");if(subset(b,literal)){chosen=value;count++;}}
      if(count!=1){cube.free();return null;}r.put(name,chosen);cube.andWith(Env.getBDDValue(name,chosen).id());
    }
    boolean full=b.equals(cube);cube.free();return full?r:null;
  }
  static List<Object> modelFields(GameModel gm,Set<String>publicEnv,Set<String>publicSys){
    List<Object>r=new ArrayList<>();Set<String>seen=new HashSet<>();Set<Integer>bits=new HashSet<>();carrierSize=java.math.BigInteger.ONE;
    for(ModuleBDDField f:allFields(gm)){String name=f.getName();require(seen.add(name),"Duplicate native field");List<String>values=Env.getValueNames(name);Collections.sort(values);require(java.math.BigInteger.valueOf(values.size()).equals(f.getDomain().size()),"Native value roster/domain mismatch");Map<String,Object>enc=new LinkedHashMap<>();
      for(int bit:f.getDomain().vars())require(bits.add(bit),"Duplicate current field bit");for(int bit:f.other().getDomain().vars())require(bits.add(bit),"Duplicate next field bit");
      for(String value:values){BDD lit=Env.getBDDValue(name,value);require(lit!=null&&!lit.isZero(),"Native field encoding missing");BDD prime=Env.prime(lit);enc.put(value,m("current",fixedBits(lit,f.getDomain().vars()),"next",fixedBits(prime,f.other().getDomain().vars())));prime.free();}
      String owner=gm.getEnv().getAllFields().contains(f)?"ENV":"SYS";String role=publicEnv.contains(name)?"ENV":publicSys.contains(name)?"SYS":"AUX";require(!owner.equals("ENV")||role.equals("ENV"),"Unexpected ENV auxiliary ownership");
      r.add(m("name",name,"owner",owner,"role",role,"domain_size",f.getDomain().size().intValueExact(),"values",values,"current_bits",ints(f.getDomain().vars()),"next_bits",ints(f.other().getDomain().vars()),"encoding",enc));carrierSize=carrierSize.multiply(f.getDomain().size());
    }return r;
  }
  static List<Object> justiceSnapshots(PlayerModule module,String prefix)throws Exception{List<Object>x=new ArrayList<>();for(int i=0;i<module.justiceNum();i++){currentOnly(prefix,module.justiceAt(i));x.add(snapshot(prefix+"_"+i,module.justiceAt(i)));}return x;}
  static Map<String,Object> modelExport(GameModel gm,Set<String>pe,Set<String>ps,Object parsed,Object translated,Path input)throws Exception{
    Map<String,Object>r=identityFields();r.put("schema","k7-native-model-export-v1");r.put("input",m("path",input.toString(),"bytes",Files.size(input),"sha256",sha(Files.readAllBytes(input))));r.put("fields",modelFields(gm,pe,ps));r.put("public_fields",m("ENV",pe,"SYS",ps));
    BDDVarSet curr=gm.getEnv().moduleUnprimeVars().union(gm.getSys().moduleUnprimeVars()),next=gm.getEnv().modulePrimeVars().union(gm.getSys().modulePrimeVars());r.put("all_current_bits",ints(curr.toArray()));r.put("all_next_bits",ints(next.toArray()));curr.free();next.free();
    BDD de=domain(gm.getEnv(),false),ds=domain(gm.getSys(),false),dep=domain(gm.getEnv(),true),dsp=domain(gm.getSys(),true),d=de.and(ds);
    r.put("bdd_variable_count",d.getFactory().varNum());List<Integer>varOrder=new ArrayList<>();for(int level=0;level<d.getFactory().varNum();level++)varOrder.add(d.getFactory().level2Var(level));r.put("bdd_variable_order",varOrder);r.put("original_bdds",m("thetaE",snapshot("original_thetaE",gm.getEnv().initial()),"thetaS",snapshot("original_thetaS",gm.getSys().initial()),"rhoE",snapshot("original_rhoE",gm.getEnv().trans()),"rhoS",snapshot("original_rhoS",gm.getSys().trans()),"domain",snapshot("domain",d),"domain_ENV_next",snapshot("domain_ENV_next",dep),"domain_SYS_next",snapshot("domain_SYS_next",dsp)));
    r.put("original_justices",m("ENV",justiceSnapshots(gm.getEnv(),"original_ENV_justice"),"SYS",justiceSnapshots(gm.getSys(),"original_SYS_justice")));r.put("source_inventory",m("parsed",parsed,"translated",translated,"native_behaviors",modelInventory(gm)));de.free();ds.free();dep.free();dsp.free();d.free();return r;
  }

  static Map<String,Object> controllerSnapshot(EnumStrategyI c,GameModel gm)throws Exception{
    require(c.numOfStates()>0&&c.numOfStates()<=4096,"Controller state cap/nonempty");
    require(!c.isCalcStats(),"Unexpected controller statistics mode");
    List<Object> nodes=new ArrayList<>(),edges=new ArrayList<>();Set<Integer> ids=new HashSet<>();
    for(int i=0;i<c.numOfStates();i++){
      EnumStateI st=c.getState(i);require(st.getStateId()==i&&ids.add(i),"Printer index/native ID mismatch");
      Map<String,Object> value=singletonValuation(st.getData(),gm);require(value!=null,"Non-singleton native controller valuation");
      List<String> succ=new ArrayList<>();Set<Integer> seenSucc=new HashSet<>();
      for(EnumStateI to:st.getSuccessors()){int j=to.getStateId();require(j>=0&&j<c.numOfStates(),"Unknown successor ID");require(c.getState(j)==to,"Successor object/ID mismatch");require(seenSucc.add(j),"Duplicate successor");succ.add(String.valueOf(j));edges.add(Arrays.asList(String.valueOf(i),String.valueOf(j)));require(edges.size()<=65536,"Controller edge cap");}
      AbstractRankInfo rank=st.get_rank_info();require(rank instanceof GR1RankInfo,"Unexpected rank type");
      nodes.add(m("id",String.valueOf(i),"native_id",i,"initial",st.isInitial(),"rank",rank.memVal(),"rank_class",rank.getClass().getName(),"rank_info",rank.rankInfoString(),"valuation",value,"bits",stateBits(st.getData(),gm),"native_bdd_text",st.getData().toStringWithDomains(Env.stringer),"successors",succ));
    }
    require(c.enumController().size()==c.numOfStates(),"Controller vector size");require(edges.size()==c.numOfTransitions(),"Native/export edge count");
    Map<String,Object> result=identityFields();result.putAll(m("schema","released-kind-complete-native-controller-v1","complete",true,"initialization","source_initializers","helper_policy","unchanged_native_graph_with_helper","controller_identity",System.identityHashCode(c),"model_sha256",sha(Files.readAllBytes(receipt.getParent().resolve("model.json"))),"native_memory_identity",out.get("native_memory_identity"),"rank_domain_size",gm.getSys().justiceNum(),"api_state_count",c.numOfStates(),"api_transition_count",c.numOfTransitions(),"nodes",nodes,"edges",edges));return result;
  }
  static void extraOrigins()throws Exception{
    Class<?>[]cs={GR1ConceteControllerConstructionSkip.class,GR1Memory.class,GR1RankInfo.class,EnumStrategyImpl.class,EnumStateI.class,SimpleTextPrinter.class};List<Object>x=new ArrayList<>();
    for(Class<?>c:cs){Class<?>anchor=c.getName().contains(".gr1.")?GR1Game.class:tau.smlab.syntech.games.GameMemory.class;require(c.getProtectionDomain().getCodeSource().getLocation().equals(anchor.getProtectionDomain().getCodeSource().getLocation()),"Unexpected class origin "+c.getName());x.add(identity(c));}out.put("extractor_printer_origins",x);
  }
  static void setNoneOptimizationEffects(){
    GR1GameExperiments.DETECT_FIX_POINT_EARLY=false;GR1GameExperiments.USE_FIXPOINT_RECYCLE=false;GR1GameExperiments.STOP_WHEN_INITIALS_LOST=false;GR1GameExperiments.SIMULTANEOUS_CONJUNCTION_ABSTRACTION=false;
    tau.smlab.syntech.games.rabin.RabinGame.DETECT_FIX_POINT_EARLY=false;tau.smlab.syntech.games.rabin.RabinGame.USE_FIXPOINT_RECYCLE=false;tau.smlab.syntech.games.rabin.RabinGame.STOP_WHEN_WIN_FROM_SOME_INITIALS=false;tau.smlab.syntech.games.rabin.RabinGame.SIMULTANEOUS_CONJUNCTION_ABSTRACTION=false;
  }
  public static void main(String[]args)throws Exception{
    if(args.length!=4)throw new IllegalArgumentException("fixture input result origins");
    fixtureId=args[0];caseId=fixtureId;variant="initializers";pipeline="released_syntactic_kind_job_equivalent";selectedSolver="4fp";
    receipt=Paths.get(args[2]).toAbsolutePath();start=System.nanoTime();startHeapSampler();int exit=0;BDDFactory factory=null;GR1SeparatedGame game=null;GameModel gm=null;
    out.putAll(identityFields());out.putAll(m("schema","released-kind-job-native-result-v1","pipeline",pipeline,"solver","4fp","status","RUNNING","native_solver_calls",0,"controller_extraction_calls",0,"native_printer_calls",0,"initializers_replaced",false,"semantic_reduction_used",false,"ENV_justice_normalization_used",false,"GUI_execution",false));
    out.put("runtime",m("java_version",System.getProperty("java.version"),"java_home",System.getProperty("java.home"),"os_arch",System.getProperty("os.arch")));
    out.put("configuration",m("release","1.0.0.202402072123","BDDPackage","JTLV","BDDPackageVersion","DEFAULT","synthesisMethod","synthesisPitermanReduction","ConcreteControllerFormat","JTLV","optChoice","none","reorderChoice","none","groupVars",false,"TraceInfo","NONE","TransFuncType","SINGLE_FUNC","extractor_strategy","native_two_argument_default_ZYX"));
    Logger.getRootLogger().addAppender(new ValidationLogWatch());
    try{
      checkOrigins(Paths.get(args[3]));extraOrigins();Path input=Paths.get(args[1]).toRealPath();out.put("input",input.toString());out.put("input_sha256",sha(Files.readAllBytes(input)));
      checkpoint("PARSE_VALIDATE");GameInput gi=new SpectraInputProviderNoIDE().getGameInput(input.toString());validationHealthy();Object parsed=inventory(gi);out.put("parsed_inventory",parsed);Set<String>pe=new LinkedHashSet<>(),ps=new LinkedHashSet<>();for(Variable v:gi.getEnv().getVars())pe.add(v.getName());for(Variable v:gi.getSys().getVars())ps.add(v.getName());out.put("original_public_fields",m("ENV",new ArrayList<>(pe),"SYS",new ArrayList<>(ps)));
      checkpoint("RELEASED_SYNTACTIC_REDUCTION_BEFORE_TRANSLATORS");PitermanSyntacticReduction.doReduction(gi);out.put("reduced_inventory",inventory(gi));
      checkpoint("FULL_DEFAULT_TRANSLATORS");TranslationProvider.translate(gi,tau.smlab.syntech.gameinputtrans.translator.DefaultTranslators.getDefaultTranslators());validationHealthy();Object translated=inventory(gi);out.put("translated_inventory",translated);auditTranslated(gi);
      checkpoint("JTLV_BACKEND_AND_SOURCE_INITIAL_MODEL");BDDPackage.setCurrPackage(BDDPackage.JTLV,BDDPackage.BBDPackageVersion.DEFAULT);Env.disableReorder();BDD one=Env.TRUE();factory=one.getFactory();one.free();out.put("observed_backend",backend());
      gm=BDDGenerator.generateGameModel(gi,TraceInfo.NONE,false,PlayerModule.TransFuncType.SINGLE_FUNC);
      boolean helper=Env.getVar("~envHelp")!=null;out.put("helper_added",helper);if(helper)pe.add("~envHelp");out.put("helper_is_native_nonaux_ENV",helper&&gm.getEnv().getNonAuxFields().contains(Env.getVar("~envHelp")));
      out.put("model_export",writeJson("model.json",modelExport(gm,pe,ps,parsed,translated,input)));require(!Env.hasVars(gm.getEnv().trans(),gm.getSys().modulePrimeVars()),"Transformed ENV next SYS");
      out.put("preconstructor_justices",m("ENV",justiceSnapshots(gm.getEnv(),"preconstructor_ENV_justice"),"SYS",justiceSnapshots(gm.getSys(),"preconstructor_SYS_justice")));
      checkpoint("SOLVER_CONSTRUCTION");setNoneOptimizationEffects();game=new GR1SeparatedGame(gm);out.put("solver_class_identity",identity(game.getClass()));out.put("native_model_identity",System.identityHashCode(gm));out.put("native_memory_identity",System.identityHashCode(game.getMem()));out.put("solver_justices",m("ENV",justiceSnapshots(gm.getEnv(),"solver_ENV_justice"),"SYS",justiceSnapshots(gm.getSys(),"solver_SYS_justice")));
      checkpoint("NATIVE_KIND_SOLVER");out.put("native_solver_calls",1);boolean realizable=game.checkRealizability();out.put("native_initial_verdict",realizable);out.put("memory_complete",game.getMem().isComplete());out.put("final_region",snapshot("final_region",game.sysWinningStates()));
      if(!realizable){out.put("status","JOB_UNREALIZABLE_NO_CONTROLLER");out.put("memory_empty_guard_called",false);}
      else{
        Env.disableReorder();checkpoint("RELEASED_MEMORY_EMPTY_GUARD");out.put("memory_empty_guard_called",true);boolean empty=game.getMem().isEmptyController();out.put("memory_empty",empty);
        if(empty){out.put("status","JOB_EMPTY_MEMORY_NO_CONTROLLER");}
        else{
          checkpoint("UNCHANGED_GENERIC_EXTRACTION");GR1Memory mem=game.getMem();GR1ConceteControllerConstructionSkip cc=new GR1ConceteControllerConstructionSkip(mem,gm);out.put("same_native_memory_passed_to_constructor",System.identityHashCode(mem)==((Number)out.get("native_memory_identity")).intValue());out.put("same_native_model_passed_to_constructor",System.identityHashCode(gm)==((Number)out.get("native_model_identity")).intValue());out.put("controller_extraction_calls",1);EnumStrategyI controller=cc.calculateConcreteController();
          Map<String,Object>before=controllerSnapshot(controller,gm);String beforeJSON=json(before);out.put("controller_before_print_sha256",sha(beforeJSON.getBytes(StandardCharsets.UTF_8)));
          checkpoint("RELEASED_SIMPLE_TEXT_PRINTER");Path printed=receipt.getParent().resolve("controller.txt");out.put("native_printer_calls",1);try(PrintStream stream=new PrintStream(Files.newOutputStream(printed),false,StandardCharsets.UTF_8)){new SimpleTextPrinter().printController(stream,controller);if(stream.checkError())throw new IOException("Printer output stream error");}
          out.put("printed_controller",filePin(printed));Map<String,Object>after=controllerSnapshot(controller,gm);String afterJSON=json(after);out.put("controller_after_print_sha256",sha(afterJSON.getBytes(StandardCharsets.UTF_8)));require(beforeJSON.equals(afterJSON),"Native printer mutated controller graph");out.put("controller_export",writeJson("controller.json",after));out.put("status","JOB_CONTROLLER_PRINTED");
          pairedDiagnostics(mem,gm,controller);
        }
      }
      validationHealthy();checkOrigins(Paths.get(args[3]));extraOrigins();checkpoint("JOB_COMPLETE");
    }catch(Throwable e){exit=2;out.put("failed_stage",stage);out.put("status","UNKNOWN_RUNTIME_EXCEPTION");out.put("exception",e.toString());StringWriter sw=new StringWriter();e.printStackTrace(new PrintWriter(sw));out.put("stacktrace",sw.toString());checkpoint("UNKNOWN");}
    finally{checkpoint("TEARDOWN");try{if(game!=null)game.free();if(gm!=null)gm.free();if(factory!=null)factory.done();out.put("teardown","COMPLETED");}catch(Throwable t){exit=3;out.put("status","UNKNOWN_TEARDOWN_EXCEPTION");out.put("teardown","FAILED");out.put("teardown_error",t.toString());}if(heapSampler!=null)heapSampler.cancel();checkpoint("PROCESS_FINISHED");}System.exit(exit);
  }

  static void collectMemory(String label,Object value,Map<String,BDD> saved) {
    if(value==null)return;
    if(value instanceof BDD){saved.put(label,((BDD)value).id());return;}
    if(value.getClass().isArray()) {
      for(int i=0;i<java.lang.reflect.Array.getLength(value);i++)
        collectMemory(label+"_"+i,java.lang.reflect.Array.get(value,i),saved);
    } else throw new IllegalArgumentException("Unexpected memory field "+label);
  }
  static Map<String,BDD> captureMemoryAndModel(GR1Memory mem,GameModel gm)throws Exception {
    Map<String,BDD> saved=new LinkedHashMap<>();
    for(String field:Arrays.asList("x_mem","y_mem","z_mem")) {
      java.lang.reflect.Field f=GR1Memory.class.getDeclaredField(field);
      f.setAccessible(true);collectMemory(field,f.get(mem),saved);
    }
    saved.put("win",mem.getWin().id());
    for(boolean e:Arrays.asList(true,false)) {
      PlayerModule p=e?gm.getEnv():gm.getSys();String side=e?"ENV":"SYS";
      saved.put(side+"_initial",p.initial().id());saved.put(side+"_trans",p.trans().id());
      for(int i=0;i<p.justiceNum();i++)saved.put(side+"_justice_"+i,p.justiceAt(i).id());
    }
    return saved;
  }
  static List<Integer> variableOrder(BDD b) {
    List<Integer> order=new ArrayList<>();
    for(int i=0;i<b.getFactory().varNum();i++)order.add(b.getFactory().level2Var(i));
    return order;
  }
  static void pairedDiagnostics(GR1Memory mem,GameModel gm,EnumStrategyI nativeController)throws Exception {
    checkpoint("PAIRED_OBSERVER_SAME_MEMORY_AND_MODEL");
    Map<String,BDD> before=captureMemoryAndModel(mem,gm);
    List<Integer> order=variableOrder(mem.getWin());
    GR1ObservedControllerConstructionSkip observer=new GR1ObservedControllerConstructionSkip(mem,gm);
    EnumStrategyI observedController=observer.calculateConcreteController();
    Map<String,Object> original=controllerSnapshot(nativeController,gm);
    Map<String,Object> observed=controllerSnapshot(observedController,gm);
    Object originalID=original.remove("controller_identity");
    Object observedID=observed.remove("controller_identity");
    boolean graphParity=json(original).equals(json(observed));
    original.put("controller_identity",originalID);observed.put("controller_identity",observedID);
    out.put("observer_controller_export",writeJson("observer_controller.json",observed));
    Map<String,BDD> after=captureMemoryAndModel(mem,gm);
    Map<String,Object> checks=new LinkedHashMap<>();
    boolean memoryParity=before.keySet().equals(after.keySet());
    for(String name:before.keySet()) {
      boolean same=after.containsKey(name)&&before.get(name).equals(after.get(name));
      checks.put(name,same);memoryParity &= same;
    }
    boolean orderParity=order.equals(variableOrder(mem.getWin()));
    Path memoryDir=receipt.getParent().resolve("paired_memory");Files.createDirectory(memoryDir);
    Map<String,Object> memoryFiles=new LinkedHashMap<>();
    for(Map.Entry<String,BDD> entry:before.entrySet()) {
      Path dest=memoryDir.resolve(entry.getKey()+".bdd");
      Env.saveBDD(dest.toString(),entry.getValue(),false);
      memoryFiles.put(entry.getKey(),m("file",dest.getFileName().toString(),"bytes",Files.size(dest),
        "sha256",sha(Files.readAllBytes(dest)),"nodes",entry.getValue().nodeCount()));
    }
    Map<String,Object> diagnostic=m("mode","observer_only_paired_after_unmodified_native_extraction",
      "same_memory_object",true,"same_model_object",true,
      "graph_parity_excluding_only_controller_object_identity",graphParity,
      "memory_and_model_all_BDDs_equal",memoryParity,"BDD_equality_checks",checks,
      "variable_order_unchanged",orderParity,"bdd_variable_order",order,
      "observer_class",identity(observer.getClass()),"observer_helper_class",identity(Class.forName("tau.smlab.syntech.games.gr1.GR1ExtractionObserver")),
      "memory_snapshots",memoryFiles,"native_graph_states",nativeController.numOfStates(),
      "native_graph_edges",nativeController.numOfTransitions(),"observed_graph_states",observedController.numOfStates(),
      "observed_graph_edges",observedController.numOfTransitions(),
      "trace_path",System.getProperty("lift.trace.path"));
    out.put("paired_observer",writeJson("paired_observer.json",diagnostic));
    for(BDD b:before.values())b.free();for(BDD b:after.values())b.free();
    require(graphParity&&memoryParity&&orderParity,"Paired observer parity failed");
  }
}
