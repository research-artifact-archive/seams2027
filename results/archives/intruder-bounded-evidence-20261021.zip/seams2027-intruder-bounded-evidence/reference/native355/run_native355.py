"""Exactly one frozen corpus355 pair and normalized comparison; no implicit retries."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import base64
import hashlib
import importlib.util
import json
import os
import sys
import traceback
from urllib.parse import unquote, urlparse

sys.dont_write_bytecode = True
B = Path(__file__).resolve().parent
PARENT = B.parent
PAIR_CLASS = "PairedContinuationWithRle"
NORMAL_CLASS = "InitialGraphWithRle"
PREFERENCE = "tau.smlab.syntech.games.gr1.GR1ContinuationPreferenceConstruction"
SOURCE_SHA = "6203bdf9a0e65726aa2d46503ae935ba2ac4e9fa27f00650ded83a25a5318c10"
PREP_END = "2026-10-21T09:16:09+00:00"
SCIENCE_END = "2026-10-21T10:06:09+00:00"
PAIR_SOURCES = ["ReleasedKindJobProducer.java", "PairedLiftDiagnostic.java",
    "tau/smlab/syntech/games/gr1/GR1ExtractionObserver.java",
    "tau/smlab/syntech/games/gr1/GR1ObservedControllerConstructionSkip.java",
    "PairedContinuationDiagnostic.java", "tau/smlab/syntech/games/gr1/GR1ContinuationPreferenceConstruction.java",
    "PairedContinuationWithRle.java", "LosslessStdoutRle.java"]
NORMAL_SOURCES = ["InitialGraphProducer.java", "InitialGraphWithRle.java", "LosslessStdoutRle.java"]
PAIR_CLASSES = [name + suffix + ".class" for name in ["ReleasedKindJobProducer", "PairedLiftDiagnostic", "PairedContinuationDiagnostic"]
    for suffix in ["", "$1", "$InvariantMismatch", "$UnsupportedDomain", "$ValidationLogWatch"]] + [
    "PairedContinuationDiagnostic$SavedState.class", "PairedContinuationWithRle.class", "LosslessStdoutRle.class",
    "tau/smlab/syntech/games/gr1/GR1ExtractionObserver.class", "tau/smlab/syntech/games/gr1/GR1ExtractionObserver$Snapshot.class",
    "tau/smlab/syntech/games/gr1/GR1ObservedControllerConstructionSkip.class", "tau/smlab/syntech/games/gr1/GR1ContinuationPreferenceConstruction.class"]
NORMAL_CLASSES = ["InitialGraphProducer" + suffix + ".class" for suffix in ["", "$1", "$InvariantMismatch", "$UnsupportedDomain", "$ValidationLogWatch"]] + ["InitialGraphWithRle.class", "LosslessStdoutRle.class"]


def need(ok, message):
    if not ok:
        raise ValueError(message)


def unique(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, "Duplicate JSON key")
        result[key] = value
    return result


def read(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=unique)


def pin(path):
    path = Path(path).resolve()
    h = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
            size += len(block)
    return {"path": str(path), "bytes": size, "sha256": h.hexdigest()}


def verify(refs):
    for ref in refs:
        need(pin(ref["path"]) == {key: ref[key] for key in ("path", "bytes", "sha256")}, "Frozen input changed: " + ref["path"])


def save_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def now():
    return datetime.now(timezone.utc)


def utc(value):
    return datetime.fromisoformat(value[:-1] + "+00:00" if value.endswith("Z") else value)


def clean_end(process):
    return (process.get("owned_child_reaped") is True and process.get("receipt_persisted") is True
        and process.get("parent_finalization_completed") is True and not process.get("parent_aborted")
        and not (process.get("exact_child_wait4") or {}).get("authority_lost")
        and (not process.get("process_started") or ((process.get("exact_child_wait4") or {}).get("exact_child_reaped") is True
            and (process.get("final_group_observation") or {}).get("state") == "ABSENT")))


def completed(process):
    return (clean_end(process) and process["status"] == "PROCESS_COMPLETED" and process["exit_code"] == 0
        and not process["fatal_reasons"] and not process["resource_reasons"]
        and all(item["complete"] for item in process["capture"].values()))


def verify_jdk(runtime):
    root = Path(runtime["java_home"])
    expected = {item["relative"]: item for item in runtime["jdk_inventory"]}
    actual = {str(path.relative_to(root)): path for path in root.rglob("*") if path.is_file() or path.is_symlink()}
    need(set(actual) == set(expected), "JDK inventory changed")
    for name, ref in expected.items():
        path = actual[name]
        if "symlink" in ref:
            need(path.is_symlink() and str(path.readlink()) == ref["symlink"], "JDK symlink changed")
        else:
            need(not path.is_symlink(), "JDK regular file became symlink")


def prepare():
    runtime, source = read(B / "RUNTIME_INPUTS.json"), read(B / "SOURCE_PREPARATION.json")
    need(source["candidate_id"] == "corpus355__original" and source["source_count"] == 1, "Exactly one candidate source")
    verify(runtime["all_runtime_refs"] + runtime["copied_process_supervisor"] + source["candidate_sources"])
    verify_jdk(runtime)
    for item in source["input_closure"]:
        verify([item["origin"], item["copied"]])
        need(item["origin"]["sha256"] == item["copied"]["sha256"], "Input was changed")
    need(pin(B / "inputs/1673286053.spectra")["sha256"] == SOURCE_SHA, "Exact selected source")
    protected = read(PARENT / "V47_PROTECTED_INPUTS.json")
    verify(protected["files"])
    removed = "JDK_JAVAC_OPTIONS" in os.environ
    os.environ.pop("JDK_JAVAC_OPTIONS", None)
    spec = importlib.util.spec_from_file_location("v48_owned_bounded_process", B / "code/dispatch/bounded_process.py")
    supervisor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(supervisor)
    return runtime, source, protected, supervisor, removed


def invoke(stage, argv, folder, tree, wall, hard_stop, watch=()):
    hard = utc(hard_stop)
    need((hard - now()).total_seconds() > wall + 25, "Insufficient bounded launch and cleanup reserve")
    deadline = min(hard - timedelta(seconds=20), now() + timedelta(seconds=wall + 20))
    return stage.run_bounded(argv, folder, deadline.isoformat(), wall_seconds=wall,
        rss_bytes=1073741824, stream_bytes=8388608, file_bytes=16777216,
        watch_files=watch, output_tree=tree, output_tree_bytes=536870912,
        aggregate_tree=B, aggregate_tree_bytes=1073741824, min_free_bytes=1073741824)


def classpath(runtime, kind):
    return ":".join([str(B / ("build_" + kind) / "classes")] + [ref["path"] for ref in runtime["ordered_jars"]])


def verify_static(runtime, source, protected, built=()):
    verify(runtime["all_runtime_refs"] + runtime["copied_process_supervisor"] + source["candidate_sources"] + protected["files"])
    verify_jdk(runtime)
    for item in source["input_closure"]:
        verify([item["origin"], item["copied"]])
    verify(built)


def build():
    runtime, source, protected, stage, removed = prepare()
    need(now() < utc(PREP_END), "Preparation deadline")
    need(not (B / "BUILD_RECEIPT.json").exists(), "No repeated candidate build")
    result = {"schema": "v48-fresh-two-build-receipt-v1", "status": "RUNNING", "started_utc": now().isoformat(),
        "source_preparation": pin(B / "SOURCE_PREPARATION.json"), "runtime": pin(B / "RUNTIME_INPUTS.json"),
        "runner": pin(Path(__file__)), "JDK_JAVAC_OPTIONS_removed": removed, "builds": {}, "errors": []}
    try:
        for kind, names, expected in [("pair", PAIR_SOURCES, PAIR_CLASSES), ("normalized", NORMAL_SOURCES, NORMAL_CLASSES)]:
            folder = B / ("build_" + kind)
            folder.mkdir(exist_ok=False)
            (folder / "classes").mkdir()
            (folder / "empty_sourcepath").mkdir()
            argv = [runtime["javac"]["path"], "-J-Xmx512m", "-encoding", "UTF-8", "-proc:none", "-implicit:none",
                "-sourcepath", str(folder / "empty_sourcepath"), "-cp", ":".join(ref["path"] for ref in runtime["ordered_jars"]),
                "-d", str(folder / "classes")] + [str(B / "src" / name) for name in names]
            process = invoke(stage, argv, folder / "compile_process", folder, 120, PREP_END)
            row = {"attempts": 1, "process": pin(folder / "compile_process/PROCESS_RECEIPT.json"),
                "sources": [pin(B / "src" / name) for name in names], "status": "UNKNOWN_BUILD"}
            result["builds"][kind] = row
            need(completed(process), "Compile must complete cleanly")
            classes = sorted((folder / "classes").rglob("*.class"))
            need({str(path.relative_to(folder / "classes")) for path in classes} == set(expected), "Exact custom class roster")
            row["classes"] = [pin(path) for path in classes]
            row["status"] = "PASS_FRESH_BUILD"
        result["status"] = "PASS_FRESH_PAIR_AND_NORMALIZED_BUILDS"
    except BaseException as error:
        result["status"] = "UNKNOWN_BUILD_FAILURE"
        result["errors"].append({"type": type(error).__name__, "message": str(error), "traceback": traceback.format_exc()})
    finally:
        try:
            verify_static(runtime, source, protected)
            result["input_integrity"] = "PASS"
        except BaseException as error:
            result["status"] = "UNKNOWN_INPUT_MUTATION"
            result["errors"].append({"message": str(error)})
        result["finished_utc"] = now().isoformat()
        save_new(B / "BUILD_RECEIPT.json", result)
    print(json.dumps({"status": result["status"], "receipt": pin(B / "BUILD_RECEIPT.json"), "errors": result["errors"]}))


def verify_rle(folder, hard_stop=SCIENCE_END):
    boundary = utc(hard_stop)
    need(now() < boundary, "RLE audit hard stop reached")
    repeat = b"lookup, class net.sf.javabdd.JTLVJavaFactory$BddCache\n"
    h = hashlib.sha256()
    total = records = repeated = 0
    end = None
    with (folder / "stdout.txt").open("r", encoding="ascii") as stream:
        for line in stream:
            need(now() < boundary, "RLE audit hard stop reached")
            need(end is None, "Data after RLE end")
            need(len(line) <= 100000, "RLE record length")
            item = json.loads(line, object_pairs_hook=unique)
            if item.get("kind") == "end":
                end = item
                continue
            need(set(item) in ({"kind", "data"}, {"kind", "data", "count"}), "RLE record keys")
            data = base64.b64decode(item["data"], validate=True)
            if item["kind"] == "repeat":
                count = item["count"]
                need(type(count) is int and 1 <= count <= 1000000 and data == repeat, "RLE repeat semantics")
                repeated += count
            else:
                need(item["kind"] == "bytes" and "count" not in item and 0 < len(data) <= 65536, "RLE literal semantics")
                count = 1
            total += len(data) * count
            need(total <= 8589934592, "Decoded stdout cap")
            while count:
                need(now() < boundary, "RLE audit hard stop reached")
                batch = min(count, 1024)
                h.update(data * batch)
                count -= batch
            records += 1
    need(now() < boundary, "RLE audit hard stop reached")
    need(end is not None and end == read(folder / "RLE_STDOUT_RECEIPT.json"), "Exact final RLE receipt")
    need(end["schema"] == "lossless-exact-line-rle-v1" and end["cap_reached"] is False
        and end["decoded_cap_bytes"] == 8589934592 and end["raw_bytes"] == total
        and end["raw_sha256"] == h.hexdigest() and end["data_records"] == records
        and end["repeated_lines"] == repeated, "Lossless complete stdout decode and hash")
    result = {"status": "PASS_COMPLETE_LOSSLESS_STDOUT", "raw_bytes": total, "raw_sha256": h.hexdigest(),
        "decoded_cap_bytes": 8589934592, "repeated_lines": repeated, "records": records,
        "encoded_stdout": pin(folder / "stdout.txt"), "producer_receipt": pin(folder / "RLE_STDOUT_RECEIPT.json")}
    save_new(folder / "RLE_VERIFICATION.json", result)
    return pin(folder / "RLE_VERIFICATION.json")


def class_origins(log, kind, built, require_preference):
    classes_root = B / ("build_" + kind) / "classes"
    expected = {str(Path(ref["path"]).relative_to(classes_root))[:-6].replace("/", "."): ref for ref in built["classes"]}
    observed = {}
    for line in log.read_text().splitlines():
        if "[class,load] " not in line or " source: " not in line:
            continue
        name, origin = line.split("[class,load] ", 1)[1].split(" source: ", 1)
        if name in expected:
            parsed = urlparse(origin)
            need(parsed.scheme == "file" and not parsed.netloc and Path(unquote(parsed.path)).samefile(classes_root), "Fresh custom class origin")
            need(name not in observed or observed[name] == origin, "Inconsistent custom class origin")
            observed[name] = origin
    required = {"LosslessStdoutRle", PAIR_CLASS, "PairedContinuationDiagnostic"} if kind == "pair" else {"LosslessStdoutRle", NORMAL_CLASS, "InitialGraphProducer"}
    if require_preference:
        required.add(PREFERENCE)
    need(required <= set(observed), "Missing actual custom class load evidence")
    verify(built["classes"])
    result = {"status": "PASS_ACTUAL_FRESH_CLASS_ORIGINS", "classes": observed, "expected_class_bytes": built["classes"], "log": pin(log)}
    save_new(log.parent / "CLASS_ORIGIN_CHECK.json", result)
    return pin(log.parent / "CLASS_ORIGIN_CHECK.json")


def execute():
    runtime, source, protected, stage, removed = prepare()
    plan, freeze, go = read(B / "EXPERIMENT_PLAN.json"), read(B / "EXECUTABLE_FREEZE.json"), read(B / "ROOT_EXECUTION_GO.json")
    need(plan["source_id"] == "corpus355__original" and plan["source_count"] == 1 and plan["outputs"] == ["native", "variant", "normalized"], "Fixed source/output roster")
    need(plan["science_hard_stop_utc"] == SCIENCE_END, "Fixed science hard stop")
    need(go["status"] == "GO_EXACT_355_NATIVE_TWO_JVMS_THREE_OUTPUTS" and go["plan"] == pin(B / "EXPERIMENT_PLAN.json")
        and go["freeze"] == pin(B / "EXECUTABLE_FREEZE.json") and go["build"] == pin(B / "BUILD_RECEIPT.json"), "Exact root native GO")
    verify(freeze["files"])
    for ref in go["independent_static_reviews"]:
        verify([ref])
        review = read(ref["path"])
        need(review["status"].startswith("PASS") and review["executable_freeze"] == pin(B / "EXECUTABLE_FREEZE.json")
            and not review.get("blocking_issues"), "Exact independent static PASS")
    need(len(go["independent_static_reviews"]) >= 1, "Independent review required")
    for ref in go["qualification_results"]:
        verify([ref])
        need(read(ref["path"])["status"].startswith("PASS"), "Qualification PASS required")
    need(len(go["qualification_results"]) >= 2, "Producer transport/launcher and independent oracle qualifications required")
    built = read(B / "BUILD_RECEIPT.json")
    need(built["status"] == "PASS_FRESH_PAIR_AND_NORMALIZED_BUILDS", "Fresh builds must pass")
    all_classes = [ref for row in built["builds"].values() for ref in row["classes"]]
    verify(all_classes)
    runs = B / "runs"
    runs.mkdir(exist_ok=False)
    rows = [{"id": "paired_01", "kind": "pair", "status": "NOT_ATTEMPTED", "native_attempts": 0},
            {"id": "normalized_01", "kind": "normalized", "status": "NOT_ATTEMPTED", "native_attempts": 0}]
    result = {"schema": "v48-native355-three-output-run-v1", "status": "RUNNING", "started_utc": now().isoformat(),
        "go": pin(B / "ROOT_EXECUTION_GO.json"), "source_preparation": pin(B / "SOURCE_PREPARATION.json"),
        "JDK_JAVAC_OPTIONS_removed": removed, "rows": rows, "errors": [], "scientific_adoption": "PENDING_INDEPENDENT_AUDITS"}
    fatal = False
    try:
        for row in rows:
            if fatal:
                row["status"] = "UNKNOWN_NOT_ATTEMPTED_AFTER_PROCESS_INTEGRITY_FAILURE"
                continue
            if (utc(SCIENCE_END) - now()).total_seconds() <= 75:
                row["status"] = "UNKNOWN_NOT_ATTEMPTED_DEADLINE_RESERVE"
                continue
            verify_static(runtime, source, protected, all_classes)
            verify(freeze["files"])
            run = runs / row["id"]
            run.mkdir(exist_ok=False)
            folder = run / ("native" if row["kind"] == "pair" else "normalized")
            log = run / "native_class_load.log"
            argv = [runtime["java"]["path"], "-Xmx512m", "-XX:MaxDirectMemorySize=128m"]
            if row["kind"] == "normalized":
                # Preserve the previously qualified normalized pipeline's BDD table/cache options.
                argv += ["-Dbdd=jtlv", "-Dbddver=default", "-Dbdd_table_size=10000", "-Dbdd_cache_size=1000"]
            argv += ["-Xlog:class+load=info:file=" + str(log), "-cp", classpath(runtime, row["kind"]),
                PAIR_CLASS if row["kind"] == "pair" else NORMAL_CLASS, "corpus355__original"]
            if row["kind"] == "normalized":
                argv += ["normalized_kind", "4fp"]
            argv += [str(B / "inputs/1673286053.spectra"), str(folder / "result.json"), runtime["origins"]["path"]]
            save_new(run / "INPUTS.json", {"source": pin(B / "inputs/1673286053.spectra"), "command": argv,
                "attempts": 1, "automatic_retries": 0, "hard_stop_utc": SCIENCE_END, "build": pin(B / "BUILD_RECEIPT.json")})
            row["native_attempts"] = 1
            row["status"] = "UNKNOWN_NATIVE_INCOMPLETE"
            watched = [f / name for f in [folder, run / "variant"] for name in ["result.json", "model.json", "controller.json", "controller.txt", "RLE_STDOUT_RECEIPT.json"]] + [log]
            process = invoke(stage, argv, folder, run, 44, SCIENCE_END, watched)
            row["process"] = pin(folder / "PROCESS_RECEIPT.json")
            row["process_complete"] = completed(process)
            if not clean_end(process):
                fatal = True
                row["status"] = "UNKNOWN_PROCESS_INTEGRITY_GLOBAL_STOP"
            elif not completed(process):
                row["status"] = "UNKNOWN_NATIVE_PROCESS_OR_RESOURCE"
            else:
                row["rle_verification"] = verify_rle(folder)
                require_preference = row["kind"] == "pair" and (run / "variant/controller.json").exists()
                row["class_origins"] = class_origins(log, row["kind"], built["builds"][row["kind"]], require_preference)
                arms = [folder, run / "variant"] if row["kind"] == "pair" else [folder]
                row["producer_outcomes"] = {arm.name: read(arm / "result.json").get("status") for arm in arms if (arm / "result.json").exists()}
                row["status"] = "COMPLETE_NATIVE_PROCESS_PENDING_INDEPENDENT_SEMANTIC_AUDITS"
            save_new(run / "ROW_RESULT.json", row)
        result["status"] = "COMPLETE_FIXED_ATTEMPTS_PENDING_INDEPENDENT_AUDITS"
    except BaseException as error:
        result["status"] = "UNKNOWN_RUNNER_FAILURE_NO_RETRY"
        result["errors"].append({"type": type(error).__name__, "message": str(error), "traceback": traceback.format_exc()})
    finally:
        try:
            verify_static(runtime, source, protected, all_classes)
            verify(freeze["files"])
            result["input_integrity"] = "PASS"
        except BaseException as error:
            result["status"] = "UNKNOWN_INPUT_MUTATION"
            result["errors"].append({"message": str(error)})
        result["finished_utc"] = now().isoformat()
        save_new(B / "RUN_RECEIPT.json", result)
    print(json.dumps({"status": result["status"], "rows": rows, "receipt": pin(B / "RUN_RECEIPT.json"), "errors": result["errors"]}))


if __name__ == "__main__":
    need(len(sys.argv) == 2 and sys.argv[1] in ("build", "execute"), "Mode build or execute")
    (build if sys.argv[1] == "build" else execute)()
