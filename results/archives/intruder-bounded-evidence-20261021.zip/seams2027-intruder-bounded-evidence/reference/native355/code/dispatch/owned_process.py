"""Exact-child reaping and tri-state group observation for the separate study.

No operation in this module authorizes a scientific run. EPERM never proves
absence. Process-table helpers are separate children; native RSS comes only
from the exact native PID's wait4 result, never cumulative child accounting.
"""
from datetime import datetime, timezone
import errno
import hashlib
import os
import signal
import subprocess
import tempfile
import time


class ChildAuthorityError(RuntimeError):
    pass


class ExactChild:
    def __init__(self, popen):
        self.raw = popen
        self.pid = popen.pid
        self.stdout = popen.stdout
        self.returncode = None
        self.exact_reaped = False
        self.authority_lost = False
        self.exact_usage = None
        self.wait_status = None
        self.reaped_utc = None
        self.wait_errors = []

    def poll(self):
        if self.exact_reaped:
            return self.returncode
        if self.authority_lost:
            raise ChildAuthorityError('Exact child wait authority was lost')
        try:
            pid, status, usage = os.wait4(self.pid, os.WNOHANG)
        except OSError as error:
            self.authority_lost = True
            self.wait_errors.append({'errno': error.errno, 'error': repr(error)})
            # ECHILD is not a fabricated successful exit.
            raise ChildAuthorityError('Exact wait4 failed: ' + repr(error)) from error
        if pid == 0:
            return None
        if pid != self.pid or not (os.WIFEXITED(status) or os.WIFSIGNALED(status)):
            self.authority_lost = True
            raise ChildAuthorityError('Unexpected exact child wait4 result')
        self.wait_status = status
        self.returncode = os.waitstatus_to_exitcode(status)
        self.exact_usage = {key: getattr(usage, key) for key in dir(usage) if key.startswith('ru_')}
        self.exact_reaped = True
        self.reaped_utc = datetime.now(timezone.utc).isoformat()
        # Prevent Popen's destructor from performing a second reaping path.
        self.raw.returncode = self.returncode
        return self.returncode

    def signal_owned_group(self, signum):
        event = {'signal': signal.Signals(signum).name, 'sent': False, 'target_pgid': self.pid}
        if self.poll() is not None:
            event['reason'] = 'EXACT_CHILD_ALREADY_REAPED_NO_SIGNAL'
            return event
        try:
            pgid = os.getpgid(self.pid)
            if pgid != self.pid:
                raise ChildAuthorityError('Exact child left its initial own process group')
            # This sole direct child has not been reaped, so its PID cannot be
            # reused. start_new_session binds this group to the spawned child.
            os.killpg(self.pid, signum)
            event['sent'] = True
        except ProcessLookupError:
            event['reason'] = 'GROUP_NO_LONGER_PRESENT_NOT_A_REAP_PROOF'
        except PermissionError as error:
            event['reason'] = 'SIGNAL_PERMISSION_UNKNOWN'
            event['error'] = repr(error)
        return event

    def evidence(self):
        return {'pid': self.pid, 'exact_child_reaped': self.exact_reaped,
                'returncode': self.returncode, 'wait_status': self.wait_status,
                'reaped_utc': self.reaped_utc, 'authority_lost': self.authority_lost,
                'wait_errors': self.wait_errors, 'exact_child_rusage': self.exact_usage}


def bounded_ps(fields, timeout=0.5):
    """Bound both the ps observation and its own cleanup without communicate.

    Unlinked file descriptors avoid pipe-holder waits. A timeout is UNKNOWN
    even when the helper is subsequently reaped. Native rusage is unrelated.
    """
    started = time.monotonic()
    value = {'status': 'UNKNOWN', 'command': ['/bin/ps', '-axo', fields],
             'observation_seconds': timeout, 'cleanup_seconds': 0.5,
             'stdout': '', 'stderr': '', 'exact_helper_wait4': None}
    helper = None
    with tempfile.TemporaryFile() as stdout, tempfile.TemporaryFile() as stderr:
        try:
            helper = ExactChild(subprocess.Popen(value['command'], stdin=subprocess.DEVNULL,
                stdout=stdout, stderr=stderr, start_new_session=True))
            until = time.monotonic() + timeout
            reason = None
            while helper.poll() is None:
                if time.monotonic() >= until:
                    reason = 'OBSERVATION_TIMEOUT'
                    break
                if os.fstat(stdout.fileno()).st_size > 1024 * 1024 or os.fstat(stderr.fileno()).st_size > 65536:
                    reason = 'OBSERVATION_CAPTURE_CAP'
                    break
                time.sleep(0.01)
            if reason:
                value['reason'] = reason
            if not helper.exact_reaped:
                value['cleanup_signal'] = helper.signal_owned_group(signal.SIGKILL)
                until = time.monotonic() + 0.5
                while not helper.exact_reaped and time.monotonic() < until:
                    helper.poll()
                    if not helper.exact_reaped:
                        time.sleep(0.01)
            value['exact_helper_wait4'] = helper.evidence()
            if os.fstat(stdout.fileno()).st_size > 1024 * 1024 or os.fstat(stderr.fileno()).st_size > 65536:
                value['reason'] = 'OBSERVATION_CAPTURE_CAP'
            stdout.seek(0); stderr.seek(0)
            value['stdout'] = stdout.read(1024 * 1024 + 1).decode('utf-8', errors='strict')
            value['stderr'] = stderr.read(65537).decode('utf-8', errors='replace')
            value['returncode'] = helper.returncode
            if helper.exact_reaped and helper.returncode == 0 and 'reason' not in value:
                value['status'] = 'COMPLETE'
        except Exception as error:
            value['error'] = repr(error)
            if helper is not None:
                if not helper.exact_reaped and not helper.authority_lost:
                    try:
                        value['exception_cleanup_signal'] = helper.signal_owned_group(signal.SIGKILL)
                        until = started + timeout + 0.5
                        while not helper.exact_reaped and time.monotonic() < until:
                            helper.poll()
                            if not helper.exact_reaped:
                                time.sleep(0.01)
                    except Exception as cleanup_error:
                        value['exception_cleanup_error'] = repr(cleanup_error)
                value['exact_helper_wait4'] = helper.evidence()
    value['elapsed_seconds'] = time.monotonic() - started
    return value


class GroupObserver:
    def __init__(self):
        self.helper_calls = 0
        self.observations = []
        self.observation_count = 0
        self.integrity_errors = []

    def observe(self, child, final=False):
        started = time.monotonic()
        value = {'pgid': child.pid, 'state': 'UNKNOWN', 'final': bool(final),
                 'exact_child_reaped_at_start': child.exact_reaped}
        try:
            os.killpg(child.pid, 0)
            value['zero_signal_probe'] = 'PRESENT'
        except ProcessLookupError:
            value['zero_signal_probe'] = 'ABSENT'
        except PermissionError as error:
            value['zero_signal_probe'] = 'UNKNOWN_PERMISSION'
            value['probe_error'] = repr(error)
        except OSError as error:
            value['zero_signal_probe'] = 'UNKNOWN_ERROR'
            value['probe_error'] = repr(error)

        if not final and value['zero_signal_probe'] == 'ABSENT':
            value.update(state='ABSENT', basis='ZERO_SIGNAL_ESRCH')
        elif not final and not child.exact_reaped and value['zero_signal_probe'] == 'PRESENT':
            value.update(state='PRESENT', basis='ZERO_SIGNAL_PRESENT_UNREAPED_OWN_CHILD')
        else:
            self.helper_calls += 1
            try:
                checked = bounded_ps('pid=,ppid=,pgid=,uid=')
                value['helper_receipt'] = {k: v for k, v in checked.items() if k not in ('stdout', 'stderr')}
                if checked['status'] != 'COMPLETE' or checked.get('returncode') != 0:
                    raise ValueError('Process-table command did not complete successfully')
                raw = checked['stdout'].encode('utf-8')
                if len(raw) > 1024 * 1024:
                    raise ValueError('Process-table output exceeds observation cap')
                rows = {}
                for line in checked['stdout'].splitlines():
                    fields = line.split()
                    if len(fields) != 4 or any(not item.isdecimal() for item in fields):
                        raise ValueError('Malformed complete process-table row')
                    pid, ppid, pgid, uid = map(int, fields)
                    if pid <= 0 or pid in rows:
                        raise ValueError('Duplicate or invalid process-table PID')
                    rows[pid] = {'pid': pid, 'ppid': ppid, 'pgid': pgid, 'uid': uid}
                own = rows.get(os.getpid())
                if own is None or own['uid'] != os.getuid():
                    raise ValueError('Process-table observation lacks the correct observer')
                members = [row for row in rows.values() if row['pgid'] == child.pid]
                observed_child = rows.get(child.pid)
                value['process_table'] = {'returncode': checked['returncode'], 'rows': len(rows),
                    'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                    'observer': own, 'target_group_members': members, 'target_pid_row': observed_child}
                if not child.exact_reaped and observed_child is not None and (
                        observed_child['ppid'] != os.getpid() or observed_child['uid'] != os.getuid()
                        or observed_child['pgid'] != child.pid):
                    value.update(state='UNKNOWN', basis='OWN_CHILD_IDENTITY_MISMATCH', unexpected_members=True)
                elif members:
                    value.update(state='PRESENT', basis='SUCCESSFUL_PROCESS_TABLE')
                    value['unexpected_members'] = child.exact_reaped or any(
                        row['pid'] != child.pid or row['uid'] != os.getuid() for row in members)
                else:
                    value.update(state='ABSENT', basis='SUCCESSFUL_PROCESS_TABLE_NO_GROUP_MEMBERS')
            except Exception as error:
                value.update(state='UNKNOWN', basis='PROCESS_TABLE_UNCONFIRMED', observation_error=repr(error))
                self.integrity_errors.append({'observation': self.observation_count + 1, 'error': repr(error)})
        value['elapsed_seconds'] = time.monotonic() - started
        self.observation_count += 1
        # Bounded supervisor metadata, not a replacement for native stdout.
        self.observations.append(value)
        if len(self.observations) > 256:
            self.observations = self.observations[:128] + self.observations[-128:]
        return value
