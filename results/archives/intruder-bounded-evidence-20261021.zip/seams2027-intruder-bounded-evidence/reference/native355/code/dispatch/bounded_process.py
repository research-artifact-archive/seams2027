"""Version 2 exact-child supervisor; local prelaunch tree-entry cap is 32768.

Parent interruption, child exit, capture, and receipt persistence are separate
facts. Tree byte thresholds are sampled, not claimed as an exact disk quota.
"""
from datetime import datetime, timezone
from pathlib import Path
import hashlib,json,math,os,resource,selectors,signal,stat,subprocess,sys,time,shutil
RECOVERY=Path(__file__).resolve().parent
sys.path.insert(0,str(RECOVERY))
from owned_process import ExactChild,bounded_ps
import owned_process
if Path(owned_process.__file__).resolve()!=RECOVERY/'owned_process.py':raise RuntimeError('Unexpected frozen owned_process import')

def now(): return datetime.now(timezone.utc).isoformat()
def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_name(path.name+'.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');os.replace(tmp,path)
def pin(path):
    path=Path(path).resolve();h=hashlib.sha256();size=0
    with path.open('rb') as f:
        for part in iter(lambda:f.read(1024*1024),b''):h.update(part);size+=len(part)
    return {'path':str(path),'bytes':size,'sha256':h.hexdigest()}
def output_pin(path):
    value=pin(path);value['file']=Path(path).name;del value['path'];return value

def tree_usage(root,entry_limit=32768):
    """Count regular output bytes without traversing symlinks or special files."""
    root=Path(root).absolute();total=0;entries=0;pending=[root]
    if root.is_symlink() or not root.is_dir():raise ValueError('Invalid output tree root')
    while pending:
        folder=pending.pop()
        for child in folder.iterdir():
            entries+=1
            if entries>entry_limit:raise ValueError('Output tree entry cap')
            info=child.lstat()
            if stat.S_ISREG(info.st_mode):total+=info.st_size
            elif stat.S_ISDIR(info.st_mode):pending.append(child)
            else:raise ValueError('Nonregular output entry: '+str(child))
    return {'path':str(root),'bytes':total,'entries':entries}

def child_environment():
    """Remove runtime-injection variables only from the child environment."""
    exact={'JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','PYTHONPATH','PYTHONHOME'}
    removed=sorted(key for key in os.environ if key in exact or key.startswith(('DYLD_','LD_')))
    child={key:value for key,value in os.environ.items() if key not in removed}
    if any(key in exact or key.startswith(('DYLD_','LD_')) for key in child):raise RuntimeError('Child environment sanitation failed')
    return child,removed

def run_bounded(argv,folder,deadline,wall_seconds=60,rss_bytes=1024*1024*1024,
                stream_bytes=8*1024*1024,file_bytes=16*1024*1024,watch_files=(),
                output_tree=None,output_tree_bytes=None,aggregate_tree=None,
                aggregate_tree_bytes=None,min_free_bytes=0):
    """Never touches an unrelated PID/group. No shell. Captured prefixes are marked."""
    boundary=datetime.fromisoformat(deadline)
    if boundary.tzinfo is None:raise ValueError('Timezone-aware deadline required')
    if not argv or not all(isinstance(a,str) and a for a in argv):raise ValueError('Nonempty argv strings required')
    if isinstance(wall_seconds,bool) or not isinstance(wall_seconds,(int,float)) or not math.isfinite(wall_seconds) or wall_seconds<=0:raise ValueError('Positive finite wall cap required')
    for value in (rss_bytes,stream_bytes,file_bytes):
        if isinstance(value,bool) or not isinstance(value,int) or value<=0:raise ValueError('Positive integer byte cap required')
    if isinstance(min_free_bytes,bool) or not isinstance(min_free_bytes,int) or min_free_bytes<0:raise ValueError('Nonnegative free-disk floor required')
    for tree,cap in ((output_tree,output_tree_bytes),(aggregate_tree,aggregate_tree_bytes)):
        if (tree is None)!=(cap is None) or cap is not None and (isinstance(cap,bool) or not isinstance(cap,int) or cap<=0):raise ValueError('Tree/cap must be a valid pair')
    folder=Path(folder).absolute()
    if folder.exists() or folder.is_symlink():raise FileExistsError('Fresh output folder required')
    folder.mkdir(parents=True,exist_ok=False);started=time.monotonic()
    result={'schema':'contained-stage-process-v2','parent_aborted':False,
            'parent_internal_exception':None,'parent_finalization_completed':False,'receipt_persisted':False,
            'argv':list(argv),'started_utc':now(),
            'limits':{'wall_seconds':wall_seconds,'rss_bytes':rss_bytes,'stdout_bytes':stream_bytes,
                      'stderr_bytes':stream_bytes,'each_watched_file_bytes':file_bytes,'rss_poll_seconds':0.2,
                      'output_tree_bytes':output_tree_bytes,'aggregate_tree_bytes':aggregate_tree_bytes,
                      'min_free_bytes':min_free_bytes,'tree_poll_seconds':0.2,
                      'tree_cap_semantics':'sampled termination threshold plus final postcheck; bounded overshoot is not an exact quota'},
            'process_started':False,'pid':None,'process_group_id':None,'exit_code':None,
            'status':'NOT_STARTED','resource_reasons':[],'fatal_reasons':[],
            'sampled_peak_group_rss_bytes':0,'wait4_peak_rss_bytes':None,'group_members_observed':[],
            'capture':{},'termination_signals':[],'exact_child_wait4':None,'final_group_observation':None,
            'rss_observation_count':0,'rss_observations':[],
            'tree_observations':[],'tree_observation_count':0,
            'supervisor_source_pins':[pin(Path(__file__)),pin(RECOVERY/'owned_process.py'),pin('/bin/ps'),pin(Path(sys.executable).resolve())]}
    save(folder/'PROCESS_REQUEST.json',{'argv':list(argv),'deadline_utc':deadline,'limits':result['limits']})
    streams={name:(folder/(name+'.txt')).open('xb',buffering=0) for name in ('stdout','stderr')}
    counts={name:{'observed_bytes':0,'captured_bytes':0,'complete':True} for name in streams}
    process=None;selector=selectors.DefaultSelector();done=False;usage=None;term_at=None;last_rss=-1
    watched=[Path(p).resolve() for p in watch_files];members=set();old_handlers={};cancelled=[]
    def mark(name,value):
        if value not in result[name]:result[name].append(value)
    def synchronize_exit():
        nonlocal done,usage
        if process is not None and process.exact_reaped and not done:
            done=True;usage=process.exact_usage;result['exit_code']=process.returncode
            result['leader_finished_utc']=now();result['leader_elapsed_seconds']=time.monotonic()-started
            result['leader_done_monotonic']=time.monotonic()
    def poll_child():
        process.poll();synchronize_exit()
    def stop_owned(sig):
        if process is None or process.exact_reaped:return
        if process.authority_lost:
            mark('fatal_reasons','EXACT_WAIT_AUTHORITY_LOST_NO_SIGNAL');return
        try:
            event=process.signal_owned_group(sig);event['signal_name']=event['signal'];event['signal']=int(sig);event['utc']=now()
            result['termination_signals'].append(event);synchronize_exit()
        except Exception as error:
            mark('fatal_reasons','OWNED_SIGNAL_UNCONFIRMED:'+repr(error))
    def group_snapshot(final=False):
        checked=bounded_ps('pid=,ppid=,pgid=,uid=,rss=')
        evidence={k:v for k,v in checked.items() if k not in ('stdout','stderr')}
        if checked['status']!='COMPLETE' or checked.get('returncode')!=0:
            raise RuntimeError('Bounded process-table helper failed: '+json.dumps(evidence))
        rows={}
        for line in checked['stdout'].splitlines():
            parts=line.split()
            if len(parts)!=5 or any(not x.isdecimal() for x in parts):raise ValueError('Malformed complete RSS table')
            pid,ppid,pgid,uid,rss=map(int,parts)
            if pid<=0 or pid in rows:raise ValueError('Duplicate or invalid RSS PID')
            rows[pid]={'pid':pid,'ppid':ppid,'pgid':pgid,'uid':uid,'rss_bytes':rss*1024}
        if os.getpid() not in rows or rows[os.getpid()]['uid']!=os.getuid():raise ValueError('RSS observation lacks its owner')
        group=[row for row in rows.values() if row['pgid']==process.pid]
        own=rows.get(process.pid)
        if not process.exact_reaped and own is not None and (own['ppid']!=os.getpid() or own['uid']!=os.getuid() or own['pgid']!=process.pid):
            mark('fatal_reasons','OWNED_PROCESS_LIVE_IDENTITY_MISMATCH')
        if any(row['pid']!=process.pid or row['uid']!=os.getuid() for row in group):
            mark('fatal_reasons','UNEXPECTED_OWNED_GROUP_DESCENDANT')
        evidence.update(group=group,table_sha256=hashlib.sha256(checked['stdout'].encode()).hexdigest(),table_rows=len(rows))
        if final:
            result['final_group_observation']={'state':'ABSENT' if not group else 'PRESENT','basis':'SUCCESSFUL_BOUNDED_PROCESS_TABLE','evidence':evidence}
        else:
            result['rss_observation_count']+=1;result['rss_observations'].append(evidence)
            if len(result['rss_observations'])>256:result['rss_observations']=result['rss_observations'][:128]+result['rss_observations'][-128:]
        return group
    def handler(sig,frame):cancelled.append(sig)
    def observe_trees(final=False):
        event={'utc':now(),'final':final,'trees':[]}
        for label,tree,cap in [('OUTPUT_TREE',output_tree,output_tree_bytes),('AGGREGATE_TREE',aggregate_tree,aggregate_tree_bytes)]:
            if tree is not None:
                sample=tree_usage(tree);sample['label']=label;sample['cap']=cap;event['trees'].append(sample)
                if sample['bytes']>=cap:mark('resource_reasons',label+'_CAP'+('_FINAL' if final else ''))
        if min_free_bytes:
            event['free_bytes']=shutil.disk_usage(folder).free
            if event['free_bytes']<min_free_bytes:mark('resource_reasons','FREE_DISK_FLOOR'+('_FINAL' if final else ''))
        result['tree_observation_count']+=1;result['tree_observations'].append(event)
        if len(result['tree_observations'])>256:result['tree_observations']=result['tree_observations'][:128]+result['tree_observations'][-128:]
    def preexec():
        resource.setrlimit(resource.RLIMIT_CORE,(0,0))
        resource.setrlimit(resource.RLIMIT_FSIZE,(file_bytes,file_bytes))
        cpu=int(math.ceil(wall_seconds))+2;resource.setrlimit(resource.RLIMIT_CPU,(cpu,cpu))
    try:
        observe_trees()
        if datetime.now(timezone.utc)>=boundary:
            mark('resource_reasons','ABSOLUTE_DEADLINE_BEFORE_START')
        if not result['resource_reasons']:
            if signal.getsignal(signal.SIGCHLD)!=signal.SIG_DFL:raise RuntimeError('Default SIGCHLD disposition required')
            for sig in (signal.SIGTERM,signal.SIGINT):old_handlers[sig]=signal.signal(sig,handler)
            environment,removed_names=child_environment()
            result['child_environment_removed_names']=removed_names
            result['child_environment_values_recorded']=False
            process=ExactChild(subprocess.Popen(list(argv),stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                                     cwd=folder,start_new_session=True,preexec_fn=preexec,env=environment))
            result.update(process_started=True,pid=process.pid,process_group_id=process.pid,status='RUNNING')
            save(folder/'CHILD_IDENTITY.json',{'owner_pid':os.getpid(),'child_pid':process.pid,'process_group_id':process.pid,'argv':list(argv),'created_utc':now()})
            for name,fd in [('stdout',process.stdout),('stderr',process.raw.stderr)]:
                os.set_blocking(fd.fileno(),False);selector.register(fd,selectors.EVENT_READ,name)
            while not done or selector.get_map():
                elapsed=time.monotonic()-started
                if cancelled:
                    result['parent_aborted']=True
                    mark('fatal_reasons','RUNNER_SIGNAL_'+str(cancelled[0]))
                if not done:
                    if elapsed>=wall_seconds:mark('resource_reasons','WALL_TIME_CAP')
                    if datetime.now(timezone.utc)>=boundary:mark('resource_reasons','ABSOLUTE_DEADLINE')
                    if elapsed-last_rss>=0.2:
                        last_rss=elapsed
                        try:observe_trees()
                        except Exception as exc:mark('fatal_reasons','OUTPUT_TREE_MONITOR_FAILURE:'+repr(exc))
                        try:
                            group=group_snapshot()
                            members.update(x['pid'] for x in group);sample=sum(x['rss_bytes'] for x in group)
                            result['sampled_peak_group_rss_bytes']=max(result['sampled_peak_group_rss_bytes'],sample)
                            if sample>rss_bytes:mark('resource_reasons','RSS_CAP')
                        except Exception as exc:mark('fatal_reasons','RSS_MONITOR_FAILURE:'+type(exc).__name__+':'+str(exc))
                    for p in watched:
                        if p.exists() and (p.is_symlink() or not p.is_file()):mark('fatal_reasons','INVALID_WATCHED_OUTPUT:'+p.name)
                        elif p.exists() and p.stat().st_size>=file_bytes:mark('resource_reasons','OUTPUT_FILE_CAP:'+p.name)
                    if result['resource_reasons'] or result['fatal_reasons']:
                        if term_at is None:stop_owned(signal.SIGTERM);term_at=time.monotonic()
                        elif time.monotonic()-term_at>=0.5:stop_owned(signal.SIGKILL)
                        if term_at is not None and time.monotonic()-term_at>2.5:
                            raise RuntimeError('Owned child failed bounded termination/reaping')
                for event,_ in selector.select(0.025):
                    fd=event.fileobj;name=event.data
                    try:part=os.read(fd.fileno(),65536)
                    except BlockingIOError:continue
                    if not part:selector.unregister(fd);fd.close();continue
                    counts[name]['observed_bytes']+=len(part)
                    room=max(0,stream_bytes-counts[name]['captured_bytes']);kept=part[:room]
                    streams[name].write(kept);counts[name]['captured_bytes']+=len(kept)
                    if len(kept)!=len(part):
                        counts[name]['complete']=False;mark('resource_reasons',name.upper()+'_CAP')
                if not done:poll_child()
                if done and selector.get_map() and time.monotonic()-result['leader_done_monotonic']>2:
                    mark('fatal_reasons','INCOMPLETE_PIPE_DRAIN')
                    for event in list(selector.get_map().values()):counts[event.data]['complete']=False;selector.unregister(event.fileobj);event.fileobj.close()
    except BaseException as exc:
        result['parent_internal_exception']=repr(exc)
        if isinstance(exc,(KeyboardInterrupt,SystemExit)):result['parent_aborted']=True
        mark('fatal_reasons','SUPERVISOR_EXCEPTION:'+repr(exc))
        if process is not None and not done:
            stop_owned(signal.SIGKILL)
            try:
                reap_deadline=time.monotonic()+1
                while not process.authority_lost and time.monotonic()<reap_deadline:
                    poll_child()
                    if done:break
                    time.sleep(0.025)
                if not done:mark('fatal_reasons','OWNED_CHILD_UNREAPED_OR_AUTHORITY_LOST')
            except Exception as error:mark('fatal_reasons','EXACT_REAP_FAILED:'+repr(error))
    finally:
        for event in list(selector.get_map().values()):
            counts[event.data]['complete']=False;selector.unregister(event.fileobj);event.fileobj.close()
        selector.close()
        for name,f in streams.items():f.close();result['capture'][name]=counts[name]|output_pin(folder/(name+'.txt'))
        for sig,previous in old_handlers.items():signal.signal(sig,previous)
        if cancelled:
            result['parent_aborted']=True
            mark('fatal_reasons','RUNNER_SIGNAL_'+str(cancelled[0]))
        result['parent_received_signals']=list(cancelled)
        try:observe_trees(final=True)
        except Exception as exc:mark('fatal_reasons','FINAL_OUTPUT_TREE_MONITOR_FAILURE:'+repr(exc))
        if usage is not None:
            result['wait4_peak_rss_bytes']=int(usage['ru_maxrss'])*(1 if sys.platform=='darwin' else 1024)
            result['cpu_user_seconds']=usage['ru_utime'];result['cpu_system_seconds']=usage['ru_stime']
            if result['wait4_peak_rss_bytes']>rss_bytes:mark('resource_reasons','RSS_CAP_FINAL_RUSAGE')
        for watched_file in watched:
            if watched_file.exists() and (watched_file.is_symlink() or not watched_file.is_file()):mark('fatal_reasons','INVALID_FINAL_WATCHED_OUTPUT:'+watched_file.name)
            elif watched_file.exists() and watched_file.stat().st_size>=file_bytes:mark('resource_reasons','OUTPUT_FILE_CAP_FINAL:'+watched_file.name)
        if process is not None:
            result['exact_child_wait4']=process.evidence()
            if process.authority_lost:mark('fatal_reasons','EXACT_WAIT_AUTHORITY_LOST')
            try:
                if group_snapshot(final=True):mark('fatal_reasons','FINAL_GROUP_MEMBERS_REMAIN')
            except Exception as error:
                result['final_group_observation']={'state':'UNKNOWN','error':repr(error)}
                mark('fatal_reasons','FINAL_GROUP_OBSERVATION_FAILED:'+repr(error))
        for ref in result['supervisor_source_pins']:
            try:
                if pin(ref['path'])!=ref:mark('fatal_reasons','SUPERVISOR_SOURCE_PIN_CHANGED:'+ref['path'])
            except Exception as error:mark('fatal_reasons','SUPERVISOR_SOURCE_PIN_FAILED:'+repr(error))
        result['owned_child_reaped']=done or not result['process_started']
        result['group_members_observed']=sorted(members);result.pop('leader_done_monotonic',None)
        result['finished_utc']=now();result['elapsed_seconds']=time.monotonic()-started
        if result['fatal_reasons']:result['status']='FATAL_SUPERVISOR_INTEGRITY'
        elif result['resource_reasons']:result['status']='UNKNOWN_RESOURCE'
        elif not result['process_started']:result['status']='NOT_STARTED'
        elif done and result['final_group_observation']['state']=='ABSENT' and all(c['complete'] for c in counts.values()):result['status']='PROCESS_COMPLETED'
        else:result['status']='FATAL_INCOMPLETE_PROCESS'
        result['parent_finalization_completed']=True;result['receipt_persisted']=True
        try:save(folder/'PROCESS_RECEIPT.json',result)
        except BaseException as error:
            result['parent_finalization_completed']=False;result['receipt_persisted']=False
            result['status']='FATAL_RECEIPT_RECORDING_FAILURE'
            mark('fatal_reasons','FINAL_RECEIPT_SAVE_FAILED:'+repr(error))
            # No fabricated successful receipt; an optional failure sidecar is
            # diagnostic only. Callers must reject this in-memory result.
            try:
                with (folder/'PROCESS_RECORDING_FAILURE.json').open('x') as fallback:
                    json.dump(result,fallback,ensure_ascii=False,indent=2);fallback.write('\n')
            except BaseException as fallback_error:
                result['recording_failure_sidecar_error']=repr(fallback_error)
    return result
