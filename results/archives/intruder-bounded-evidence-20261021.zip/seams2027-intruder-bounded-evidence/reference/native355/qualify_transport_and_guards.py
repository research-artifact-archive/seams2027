"""Synthetic transport and wrong-source refusal only; never pass actual355 to Java."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
B = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("v48_candidate_runner", B / "run_native355.py")
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)


def main():
    runtime, source, protected, stage, removed = r.prepare()
    built = r.read(B / "BUILD_RECEIPT.json")
    r.need(built["status"] == "PASS_FRESH_PAIR_AND_NORMALIZED_BUILDS", "Fresh build pass")
    class_refs = [ref for row in built["builds"].values() for ref in row["classes"]]
    r.verify(class_refs)
    q = B / "qualification_transport_01"
    q.mkdir(exist_ok=False)
    result = {"schema": "v48-transport-source-gate-qualification-v1", "status": "RUNNING", "actual355_source_passed_to_native": False,
        "build": r.pin(B / "BUILD_RECEIPT.json"), "runner": r.pin(B / "run_native355.py"), "qualification_script": r.pin(Path(__file__)),
        "started_utc": r.now().isoformat(), "checks": [], "errors": []}
    try:
        wrong = q / "WrongScope.spectra"
        wrong.write_text("spec WrongScope\nenv boolean e;\nsys boolean s;\ngar ini !s;\ngar alwEv !s;\n")
        for kind, main_class in [("pair", r.PAIR_CLASS), ("normalized", r.NORMAL_CLASS)]:
            folder = q / (kind + "_source_refusal")
            log = q / (kind + "_class_load.log")
            args = [runtime["java"]["path"], "-Xmx512m", "-XX:MaxDirectMemorySize=128m",
                "-Xlog:class+load=info:file=" + str(log), "-cp", r.classpath(runtime, kind), main_class, "corpus355__original"]
            if kind == "normalized":
                args += ["normalized_kind", "4fp"]
            args += [str(wrong), str(folder / "result.json"), runtime["origins"]["path"]]
            process = r.invoke(stage, args, folder, q, 15, r.PREP_END, [folder / "result.json", log])
            r.need(r.clean_end(process) and process["exit_code"] == 2 and not process["resource_reasons"] and not process["fatal_reasons"], "Clean wrong-source refusal")
            saved = r.read(folder / "result.json")
            r.need("Only exact unchanged corpus355 is supported" in saved.get("exception", ""), "Exact source gate fired")
            r.need(saved.get("native_solver_calls", 0) == 0 and saved.get("native_solver_called", False) is False, "No solver executed")
            r.need(saved.get("controller_extraction_calls", 0) == 0 and saved.get("controller_extraction_called", False) is False, "No extraction executed")
            r.need(not (folder / "model.json").exists(), "No source model was constructed")
            transport = r.verify_rle(folder)
            result["checks"].append({"name": kind + "_rejects_wrong_source_before_parse", "status": "PASS",
                "wrong_source": r.pin(wrong), "process": r.pin(folder / "PROCESS_RECEIPT.json"), "producer_result": r.pin(folder / "result.json"), "transport": transport})
        harness = q / "RleTransportQualification.java"
        harness.write_text('''import java.io.*;
import java.nio.file.*;
public final class RleTransportQualification {
  public static void main(String[] a) throws Exception {
    LosslessStdoutRle r=new LosslessStdoutRle(System.out,Paths.get(a[1]));
    byte[] data=Files.readAllBytes(Paths.get(a[0]));
    for(int at=0;at<data.length;){int n=Math.min(data.length-at,1+(at%127));r.write(data,at,n);at+=n;if(at%7==0)r.flush();}
    r.write('\\n');
    for(int i=0;i<1000007;i++)r.write(LosslessStdoutRle.REPEAT);
    r.finish();r.finish();
  }
}
''')
        payload = q / "payload.bin"
        payload.write_bytes(bytes(range(256))*273 + "\r\nあλ\n{\"kind\":\"repeat\"}\n".encode() + b'partial-without-newline')
        classes = q / "classes"
        classes.mkdir()
        empty = q / "empty_sourcepath"
        empty.mkdir()
        argv = [runtime["javac"]["path"], "-encoding", "UTF-8", "-proc:none", "-implicit:none", "-sourcepath", str(empty),
            "-cp", str(B / "build_pair/classes"), "-d", str(classes), str(harness)]
        process = r.invoke(stage, argv, q / "compile_transport_fixture", q, 30, r.PREP_END)
        r.need(r.completed(process), "Synthetic transport fixture compile")
        folder = q / "mixed_bytes_and_million_repeat_boundary"
        argv = [runtime["java"]["path"], "-Xmx128m", "-cp", str(classes) + ":" + str(B / "build_pair/classes"),
            "RleTransportQualification", str(payload), str(folder / "RLE_STDOUT_RECEIPT.json")]
        process = r.invoke(stage, argv, folder, q, 30, r.PREP_END)
        r.need(r.completed(process), "Synthetic transport fixture run")
        transport = r.verify_rle(folder)
        actual = r.read(transport["path"])
        expected = hashlib.sha256(payload.read_bytes() + b"\n")
        repeat = b"lookup, class net.sf.javabdd.JTLVJavaFactory$BddCache\n"
        left = 1000007
        while left:
            count = min(left, 1024)
            expected.update(repeat * count)
            left -= count
        r.need(actual["raw_sha256"] == expected.hexdigest()
            and actual["raw_bytes"] == payload.stat().st_size + 1 + len(repeat)*1000007, "Independent expected raw stream")
        result["checks"].append({"name": "lossless_mixed_bytes_chunk_split_unicode_and_million_repeat_boundary", "status": "PASS",
            "fixture_source": r.pin(harness), "fixture_class": r.pin(classes / "RleTransportQualification.class"), "payload": r.pin(payload),
            "process": r.pin(folder / "PROCESS_RECEIPT.json"), "transport": transport, "independent_expected_raw_sha256": expected.hexdigest()})
        result["status"] = "PASS_SYNTHETIC_TRANSPORT_AND_EXACT_SOURCE_GATES"
    except BaseException as error:
        result["status"] = "FAIL_SYNTHETIC_QUALIFICATION"
        result["errors"].append({"type": type(error).__name__, "message": str(error)})
    finally:
        r.verify_static(runtime, source, protected, class_refs)
        result["input_integrity"] = "PASS"
        result["finished_utc"] = r.now().isoformat()
        r.save_new(q / "RESULT.json", result)
    print(json.dumps({"status": result["status"], "checks": len(result["checks"]), "errors": result["errors"], "report": r.pin(q / "RESULT.json")}))

if __name__ == "__main__":
    main()
