"""Synthetic postprocess deadline controls; no native process or scientific model."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import base64
import hashlib
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
B = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("v48_deadline_runner", B / "run_native355.py")
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
q = B / "qualification_rle_deadline_01"
q.mkdir(exist_ok=False)
repeat = b"lookup, class net.sf.javabdd.JTLVJavaFactory$BddCache\n"
raw = repeat * 2048
end = {"kind": "end", "schema": "lossless-exact-line-rle-v1", "raw_bytes": len(raw),
    "raw_sha256": hashlib.sha256(raw).hexdigest(), "repeated_lines": 2048, "data_records": 1,
    "decoded_cap_bytes": 8589934592, "cap_reached": False}
encoded = json.dumps({"kind": "repeat", "count": 2048, "data": base64.b64encode(repeat).decode()}) + "\n" + json.dumps(end) + "\n"
checks = []
original_now = r.now
fixed = datetime(2026, 10, 21, 8, 50, tzinfo=timezone.utc)
boundary = fixed + timedelta(seconds=5)
for label, expire_on in [("before_parse", 1), ("record_boundary", 2), ("second_hash_batch", 4), ("positive_complete", None)]:
    folder = q / label
    folder.mkdir()
    (folder / "stdout.txt").write_text(encoded)
    (folder / "RLE_STDOUT_RECEIPT.json").write_text(json.dumps(end) + "\n")
    calls = [0]
    def clock():
        calls[0] += 1
        return fixed if expire_on is None or calls[0] < expire_on else boundary
    r.now = clock
    try:
        output = r.verify_rle(folder, boundary.isoformat())
        r.need(expire_on is None, "Expired audit unexpectedly passed")
        saved = r.read(output["path"])
        r.need(saved["raw_sha256"] == hashlib.sha256(raw).hexdigest() and saved["raw_bytes"] == len(raw), "Complete positive decode")
        checks.append({"name": label, "status": "PASS", "verification": output, "clock_calls": calls[0]})
    except ValueError as error:
        r.need(expire_on is not None and str(error) == "RLE audit hard stop reached", "Expected precise deadline refusal")
        r.need(not (folder / "RLE_VERIFICATION.json").exists(), "No completed verification after deadline refusal")
        checks.append({"name": label, "status": "PASS", "expected_refusal": str(error), "clock_calls": calls[0]})
    finally:
        r.now = original_now
result = {"schema": "v48-rle-cooperative-deadline-qualification-v1", "status": "PASS_SYNTHETIC_RLE_DEADLINE_AND_COMPLETE_HASH",
    "runner": r.pin(B / "run_native355.py"), "postbuild_correction": r.pin(B / "RUNNER_POSTBUILD_CORRECTION.json"),
    "prior_transport_and_source_gate_qualification": r.pin(B / "qualification_transport_01/RESULT.json"),
    "qualifier": r.pin(Path(__file__)), "checks": checks, "native_processes": 0, "scientific_execution": False,
    "java_sources_or_classes_modified": False, "finished_utc": r.now().isoformat()}
r.save_new(q / "RESULT.json", result)
print(json.dumps({"status": result["status"], "checks": len(checks), "report": r.pin(q / "RESULT.json")}))
