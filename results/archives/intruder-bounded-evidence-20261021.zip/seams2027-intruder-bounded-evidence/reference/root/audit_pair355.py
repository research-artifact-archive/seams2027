"""Independent paired snapshot/provenance reconciliation; no science on import.

Actual use: python -I -S -B audit_pair355.py ROOT_GO PAIR_INPUTS NEW_REPORT
Synthetic use: python -I -S -B audit_pair355.py --self-test NEW_REPORT
Full source correspondence, Q_impl equality, and controller semantics belong to
oracle355/audit355.py. This module neither solves a game nor repairs an output.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import re
import sys
import tempfile
import zipfile
from urllib.parse import unquote, urlparse

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
CORE = HERE / 'oracle355/independent_core.py'
spec = importlib.util.spec_from_file_location('pair355_independent_core', CORE)
core = importlib.util.module_from_spec(spec)
spec.loader.exec_module(core)
need, pin, read_pin, decode_json, save_new, SavedDag = (
    core.need, core.pin, core.read_pin, core.decode_json, core.save_new, core.SavedDag)
SOURCE_SHA = '6203bdf9a0e65726aa2d46503ae935ba2ac4e9fa27f00650ded83a25a5318c10'
IMPORT_SHA = '5c45b64f7b9b9f4f480d3cb485adcd8a772bce6d6c11356345386c5f143333cc'
PREFERENCE = 'tau.smlab.syntech.games.gr1.GR1ContinuationPreferenceConstruction'
HARD_STOP = datetime.fromisoformat('2026-10-21T10:06:09+00:00')


def integer(x):
    return type(x) is int and x >= 0


def now():
    return datetime.now(timezone.utc).isoformat()


def deadline():
    need(datetime.now(timezone.utc) < HARD_STOP, 'Pair audit hard stop')


def codes():
    return [pin(Path(__file__)), pin(CORE)]


def local_ref(ref, external):
    need(ref['file'] == Path(external['path']).name and
         all(ref[k] == external[k] for k in ('bytes', 'sha256')), 'Local/external file pin mismatch')


def samefile(path, other):
    need(Path(path).samefile(Path(other)), 'Observed file identity mismatch')


def class_location(text):
    matches = re.findall(r'file:[^\s\)]+', text)
    need(len(matches) == 1, 'One file CodeSource required')
    parsed = urlparse(matches[0])
    need(parsed.scheme == 'file' and not parsed.netloc, 'Local file CodeSource')
    return Path(unquote(parsed.path))


class SnapshotAudit:
    def __init__(self, model, files):
        self.n = model['bdd_variable_count']
        self.order = model['bdd_variable_order']
        need(type(self.n) is int and 0 < self.n <= 64 and len(self.order) == self.n
             and set(self.order) == set(range(self.n)), 'Exact snapshot BDD bit order')
        self.files = files
        self.cache = {}
        self.references = 0

    def inspect(self, ref, side):
        name = ref['file']
        need(type(name) is str and Path(name).name == name and name.endswith('.bdd'), 'Local BDD basename')
        need(name in self.files[side], 'BDD missing from frozen pair input roster')
        external = self.files[side][name]
        local_ref(ref, external)
        raw = read_pin(external)
        digest = ref['sha256']
        if digest not in self.cache:
            self.cache[digest] = SavedDag(raw, self.n, self.order)
        dag = self.cache[digest]
        need(ref['support'] == sorted(dag.support) and ref['node_count'] == len(dag.nodes)
             and ref['zero'] is (dag.root == 0) and ref['one'] is (dag.root == 1),
             'Snapshot saved DAG metadata mismatch')
        self.references += 1
        return digest, ref['bytes']

    def compare(self, before, after, side):
        need(type(before['bdds']) is dict and 0 < len(before['bdds']) <= 8192, 'Snapshot BDD key cap')
        need(before['bdd_count'] == len(before['bdds']) == after['bdd_count'] == len(after['bdds'])
             and set(before['bdds']) == set(after['bdds']), 'Exact complete snapshot BDD key roster')
        need(before['structure'] == after['structure'], 'Complete memory/model structure changed')
        for name, ref in before['bdds'].items():
            need(self.inspect(ref, 'baseline') == self.inspect(after['bdds'][name], side),
                 'Snapshot bytes changed; no canonicalization rescue: ' + name)
        return len(before['bdds'])


def complete_process(ref):
    p = decode_json(read_pin(ref))
    need(p['status'] == 'PROCESS_COMPLETED' and p['exit_code'] == 0
         and p['process_started'] is True and p['owned_child_reaped'] is True
         and p['receipt_persisted'] is True and p['parent_finalization_completed'] is True
         and p['parent_aborted'] is False and not p['parent_internal_exception']
         and not p['resource_reasons'] and not p['fatal_reasons'], 'Complete clean pair process required')
    child = p['exact_child_wait4']
    need(child['exact_child_reaped'] is True and child['authority_lost'] is False
         and child['pid'] == p['pid'] == p['process_group_id'] and child['returncode'] == 0
         and p['final_group_observation']['state'] == 'ABSENT', 'Exact child/process group proof')
    need(set(p['capture']) == {'stdout', 'stderr'} and all(x['complete'] is True for x in p['capture'].values()),
         'Both pair streams complete')
    return p


def inspect_class(identity, jar_refs, custom):
    name = identity['class']
    relative = name.replace('.', '/') + '.class'
    location = class_location(identity['code_source'])
    if name in custom:
        ref = custom[name]
        samefile(location / relative, ref['path'])
        raw = read_pin(ref)
    else:
        matches = [r for r in jar_refs if Path(r['path']).samefile(location)]
        need(len(matches) == 1, 'Runtime class outside exact ordered JAR closure')
        jar = matches[0]
        read_pin(jar)
        with zipfile.ZipFile(jar['path']) as archive:
            need(archive.namelist().count(relative) == 1, 'Unique exact runtime class entry')
            raw = archive.read(relative)
    need(hashlib.sha256(raw).hexdigest() == identity['class_sha256'], 'Actual runtime class bytes')
    return name


def audit(manifest):
    deadline()
    refs = manifest['files']
    source, imported = read_pin(refs['source']), read_pin(refs['import'])
    need(len(source) == 2071 and hashlib.sha256(source).hexdigest() == SOURCE_SHA
         and len(imported) == 49400 and hashlib.sha256(imported).hexdigest() == IMPORT_SHA, 'Exact unchanged source/import')
    process = complete_process(refs['process'])
    run = decode_json(read_pin(refs['run_receipt']))
    need(run['input_integrity'] == 'PASS', 'Final native input integrity')
    run_rows = [r for r in run['rows'] if r['id'] == 'paired_01']
    need(len(run_rows) == 1 and run_rows[0]['native_attempts'] == 1
         and run_rows[0]['status'] == 'COMPLETE_NATIVE_PROCESS_PENDING_INDEPENDENT_SEMANTIC_AUDITS'
         and run_rows[0]['process'] == refs['process'], 'One exact completed paired attempt')
    base = decode_json(read_pin(refs['baseline_result']))
    need(base['fixture_id'] == 'corpus355__original' and base['input_sha256'] == SOURCE_SHA
         and base['schema'] == 'released-kind-job-native-result-v1'
         and base['pipeline'] == 'released_syntactic_kind_job_equivalent'
         and base['solver'] == '4fp' and base['native_solver_calls'] == 1
         and base['teardown'] == 'COMPLETED' and base['stage'] == 'PROCESS_FINISHED', 'Complete paired native identity')
    samefile(base['input'], refs['source']['path'])
    if base['status'] in ('JOB_UNREALIZABLE_NO_CONTROLLER', 'JOB_EMPTY_MEMORY_NO_CONTROLLER'):
        need(base['controller_extraction_calls'] == base['native_printer_calls'] == 0,
             'No controller operations on native short circuit')
        need(not any(k.startswith('variant_') or k == 'paired_intervention' for k in refs),
             'No variant evidence for short-circuited native extraction')
        need(base['native_initial_verdict'] is (base['status'] == 'JOB_EMPTY_MEMORY_NO_CONTROLLER'), 'Native short-circuit verdict')
        return {'status': 'PASS_NATIVE_NO_CONTROLLER_DECLARATION_ONLY', 'native_outcome': base['status'],
                'pair_parity_established': False, 'losing_region_independently_proven': False,
                'scope': 'Completed native declaration only; no paired extraction or source impossibility inferred.'}
    need(base['status'] == 'JOB_CONTROLLER_PRINTED', 'Complete baseline graph required')
    variant = decode_json(read_pin(refs['variant_result']))
    diagnostic = decode_json(read_pin(refs['paired_intervention']))
    models_raw = [read_pin(refs[k]) for k in ('baseline_model', 'variant_model')]
    need(models_raw[0] == models_raw[1], 'Paired model files must be byte-identical')
    model = decode_json(models_raw[0])
    need(model['input']['bytes'] == 2071 and model['input']['sha256'] == SOURCE_SHA
         and model['fixture_id'] == 'corpus355__original', 'Paired model source binding')
    samefile(model['input']['path'], refs['source']['path'])
    graphs = {}
    for side, result in [('baseline', base), ('variant', variant)]:
        deadline()
        need(result['input_sha256'] == SOURCE_SHA and result['fixture_id'] == 'corpus355__original'
             and result['status'] == 'JOB_CONTROLLER_PRINTED' and result['teardown'] == 'COMPLETED'
             and result['stage'] == 'PROCESS_FINISHED' and result['solver'] == '4fp'
             and result['native_solver_calls'] == 1 and result['controller_extraction_calls'] == 1
             and result['native_printer_calls'] == 1 and result['paired_process_total_controller_extractions'] == 2
             and result['native_initial_verdict'] is True and result['memory_complete'] is True
             and result['memory_empty_guard_called'] is True and result['memory_empty'] is False
             and result['same_native_memory_passed_to_constructor'] is True
             and result['same_native_model_passed_to_constructor'] is True, 'Paired completed extraction metadata')
        need(result['initializers_replaced'] is False and result['semantic_reduction_used'] is False
             and result['ENV_justice_normalization_used'] is False and result['helper_added'] is True
             and result['helper_is_native_nonaux_ENV'] is True, 'Unchanged paired syntactic pipeline')
        samefile(result['input'], refs['source']['path'])
        local_ref(result['model_export'], refs[side + '_model'])
        local_ref(result['controller_export'], refs[side + '_controller'])
        local_ref(result['printed_controller'], refs[side + '_printer'])
        read_pin(refs[side + '_printer'])
        raw = read_pin(refs[side + '_controller']); graph = decode_json(raw)
        need(raw.endswith(b'\n') and hashlib.sha256(raw[:-1]).hexdigest() == result['controller_before_print_sha256']
             == result['controller_after_print_sha256'], 'Pre/post printer exact complete graph bytes')
        need(graph['model_sha256'] == refs[side + '_model']['sha256'] and graph['complete'] is True
             and graph['native_memory_identity'] == result['native_memory_identity'], 'Graph/model/memory identity')
        need(integer(graph['api_state_count']) and graph['api_state_count'] == len(graph['nodes'])
             and integer(graph['api_transition_count']) and graph['api_transition_count'] == len(graph['edges']), 'Exact raw graph counts')
        graphs[side] = graph
    need(variant['schema'] == 'experimental-extractor-native-result-v1'
         and variant['pipeline'] == 'released_syntactic_4fp_experimental_extractor'
         and variant['nonrelease_extractor'] is True, 'Explicit experimental variant identity')
    base_configuration = dict(base['configuration']); variant_configuration = dict(variant['configuration'])
    need(base_configuration.pop('extractor_strategy') == 'native_two_argument_default_ZYX'
         and variant_configuration.pop('extractor_strategy') == 'experimental:' + diagnostic['variant_name']
         and base_configuration == variant_configuration, 'Only declared extractor strategy configuration differs')
    samefile(base['paired_intervention_result'], refs['variant_result']['path'])
    local_ref(variant['paired_intervention'], refs['paired_intervention'])
    local_ref(variant['baseline_controller_pin'], refs['baseline_controller'])
    shared = decode_json(read_pin(refs['shared_teardown']))
    need(shared['teardown'] == 'COMPLETED' and shared['paired_process_total_controller_extractions'] == 2
         and shared['process_exit_code'] == 0, 'Single clean shared teardown')
    local_ref(shared['primary_result'], refs['baseline_result'])
    local_ref(variant['shared_teardown_primary_result'], refs['baseline_result'])
    identities = ['native_memory_identity', 'native_model_identity']
    need(all(type(base[k]) is int and base[k] == variant[k] for k in identities), 'Same live native memory/game identity records')
    before = base['before_any_extraction']
    s = before['structure']
    need(s['memory_identity'] == base['native_memory_identity'] and s['model_identity'] == base['native_model_identity']
         and s['bdd_variable_order'] == model['bdd_variable_order'], 'Prebaseline snapshot live identity and order')
    snapshot = SnapshotAudit(model, manifest['bdd_files'])
    count = None
    for side, result in [('baseline', base), ('variant', variant)]:
        snapshot.compare(before, result['before_any_extraction'], side)
        need(result['baseline_memory_model_parity'] == result['after_baseline_extraction'], 'Baseline parity aliases exact')
        for phase in ('after_baseline_extraction', 'after_variant_extraction'):
            value = result[phase]
            need(value['equal'] is True and value['structure_equal'] is True
                 and set(value['BDD_equality_checks']) == set(before['bdds'])
                 and all(v is True for v in value['BDD_equality_checks'].values()), 'Every declared BDD parity check true')
            count = snapshot.compare(before, value['snapshot'], side)
    need(diagnostic['same_memory_object'] is True and diagnostic['same_model_object'] is True
         and diagnostic['memory_and_model_all_BDDs_equal'] is True and diagnostic['variable_order_unchanged'] is True
         and diagnostic['comparison_reference'] == 'before_any_extraction'
         and diagnostic['bdd_variable_order'] == model['bdd_variable_order'], 'Paired diagnostic exact comparison scope')
    need(diagnostic['baseline_parity'] == base['after_baseline_extraction']
         and diagnostic['variant_parity'] == base['after_variant_extraction']
         and diagnostic['baseline_BDD_equality_checks'] == base['after_baseline_extraction']['BDD_equality_checks']
         and diagnostic['BDD_equality_checks'] == base['after_variant_extraction']['BDD_equality_checks'], 'Diagnostic/full snapshot binding')
    need(all(diagnostic[k] == count for k in ('before_baseline_snapshot_BDD_count',
         'after_baseline_snapshot_BDD_count', 'after_variant_snapshot_BDD_count')), 'All three complete snapshot counts')
    names = ('examined_candidates', 'refined_candidates', 'no_preferred_candidate_fallbacks')
    need(all(integer(diagnostic[k]) for k in names)
         and diagnostic[names[1]] + diagnostic[names[2]] <= diagnostic[names[0]], 'Consistent aggregate selection counters')
    for prefix, side in [('native', 'baseline'), ('variant', 'variant')]:
        need(diagnostic[prefix + '_graph_states'] == graphs[side]['api_state_count']
             and diagnostic[prefix + '_graph_edges'] == graphs[side]['api_transition_count'], 'Diagnostic/raw graph count binding')
    preference_ref = variant['selection_preference']
    snapshot.inspect(preference_ref, 'variant')
    need(diagnostic['experimental_extractor_class'] == variant['experimental_extractor_class_identity']
         and variant['experimental_class_identities'] == [diagnostic['experimental_extractor_class']]
         and diagnostic['experimental_extractor_class']['class'] == PREFERENCE, 'Exact one experimental extractor class')
    build = decode_json(read_pin(refs['build'])); runtime = decode_json(read_pin(refs['runtime']))
    need(build['status'] == 'PASS_FRESH_PAIR_AND_NORMALIZED_BUILDS', 'Fresh compiled class receipt')
    class_refs = build['builds']['pair']['classes']
    root = Path(class_refs[0]['path'])
    while root.name != 'classes' and root.parent != root:
        root = root.parent
    need(root.name == 'classes', 'Fresh class root')
    custom = {str(Path(r['path']).relative_to(root))[:-6].replace('/', '.'): r for r in class_refs}
    for ref in class_refs: read_pin(ref)
    identities_to_check = base['class_identities'] + base['extractor_printer_origins'] + [base['solver_class_identity'], diagnostic['experimental_extractor_class']]
    origin_rows = [line.split('=', 1) for line in read_pin(runtime['origins']).decode().splitlines() if line and not line.startswith('#')]
    need(len(origin_rows) == 22 and all(len(row) == 2 for row in origin_rows)
         and len({row[0] for row in origin_rows}) == 22, 'Exact declared release class origin roster')
    expected_origins = dict(origin_rows)
    need(len(base['class_identities']) == 22 and {v['class'] for v in base['class_identities']} == set(expected_origins),
         'Complete actual release class identity roster')
    for value in base['class_identities']:
        samefile(class_location(value['code_source']), expected_origins[value['class']])
    expected_extraction = {'tau.smlab.syntech.games.gr1.GR1ConceteControllerConstructionSkip',
        'tau.smlab.syntech.games.gr1.GR1Memory', 'tau.smlab.syntech.games.gr1.GR1RankInfo',
        'tau.smlab.syntech.games.controller.enumerate.EnumStrategyImpl',
        'tau.smlab.syntech.games.controller.enumerate.EnumStateI',
        'tau.smlab.syntech.games.controller.enumerate.printers.SimpleTextPrinter'}
    need(len(base['extractor_printer_origins']) == 6 and {v['class'] for v in base['extractor_printer_origins']} == expected_extraction
         and base['solver_class_identity']['class'] == 'tau.smlab.syntech.games.gr1.GR1SeparatedGame',
         'Exact native extractor/printer/solver class roster')
    need(variant['class_identities'] == base['class_identities'] and variant['extractor_printer_origins'] == base['extractor_printer_origins']
         and variant['solver_class_identity'] == base['solver_class_identity'], 'Paired runtime identity inventory unchanged')
    class_names = [inspect_class(v, runtime['ordered_jars'], custom) for v in identities_to_check]
    origin = decode_json(read_pin(refs['class_origin_check']))
    need(origin['status'] == 'PASS_ACTUAL_FRESH_CLASS_ORIGINS' and origin['expected_class_bytes'] == class_refs,
         'Actual fresh custom class audit binding')
    raw_log = read_pin(origin['log']).decode()
    observed = {}
    for line in raw_log.splitlines():
        if '[class,load] ' in line and ' source: ' in line:
            name, location = line.split('[class,load] ', 1)[1].split(' source: ', 1)
            if name in custom:
                parsed = urlparse(location)
                need(parsed.scheme == 'file' and not parsed.netloc, 'Actual custom class local origin')
                samefile(unquote(parsed.path), root)
                need(name not in observed or observed[name] == location, 'One actual origin per custom class')
                observed[name] = location
    need(observed == origin['classes'] and {PREFERENCE, 'PairedContinuationWithRle', 'PairedContinuationDiagnostic', 'LosslessStdoutRle'} <= set(observed),
         'Actual loaded custom class log exact')
    need(run_rows[0]['class_origins'] == refs['class_origin_check'] and run_rows[0]['rle_verification'] == refs['rle_verification'],
         'Final process/runtime audit reference binding')
    rle = decode_json(read_pin(refs['rle_verification']))
    need(rle['status'] == 'PASS_COMPLETE_LOSSLESS_STDOUT', 'Completed lossless RLE verification')
    local_ref(process['capture']['stdout'], rle['encoded_stdout'])
    read_pin(rle['encoded_stdout']); read_pin(rle['producer_receipt'])
    deadline()
    return {'status': 'PASS_EXACT_PAIRED_SNAPSHOTS_RUNTIME_AND_PROVENANCE',
            'snapshot_BDD_keys': count, 'snapshot_reference_checks': snapshot.references,
            'unique_saved_DAGs_validated': len(snapshot.cache), 'snapshot_equality_basis': 'Exact bytes/hash identity on the same native variable order plus independent saved-DAG structural/support validation; no canonicalization rescue.',
            'native_memory_identity': base['native_memory_identity'], 'native_model_identity': base['native_model_identity'],
            'model_bytes_equal': True, 'all_three_snapshots_equal': True, 'ordered_justice_rosters_preserved': True,
            'actual_runtime_class_checks': len(class_names), 'runtime_class_names': class_names,
            'actual_custom_class_log_checked': sorted(observed), 'selection_preference_pin': manifest['bdd_files']['variant'][preference_ref['file']],
            'selection_counters': {n: diagnostic[n] for n in names},
            'graph_counts': {k: {'states': g['api_state_count'], 'edges': g['api_transition_count']} for k, g in graphs.items()},
            'Q_function_identity_scope': 'Exported preference bytes are bound here; equality to independently derived Q_impl belongs to the separate oracle355 report.',
            'candidate_event_causality_established': False,
            'counter_scope': 'Native aggregate counters only; no exact retained-candidate event trace is claimed.',
            'trust_boundary': 'Exact child process and loaded class bytes checked here. Root frozen source/runtime closure and authorization review, independent source/controller semantics, and final scientific adoption remain separate gates.'}


def self_test(path):
    checks = []
    with tempfile.TemporaryDirectory(prefix='v48-pair-synthetic-') as temp:
        folder = Path(temp)
        raw = b'2\n0 1\n2 1 0 1\n3 0 0 2\n'
        files = {'baseline': {}, 'variant': {}}
        for side in files:
            p = folder / (side + '.bdd'); p.write_bytes(raw)
            files[side][p.name] = pin(p)
        def ref(side):
            p = files[side][side + '.bdd']
            return {'file': Path(p['path']).name, 'bytes': p['bytes'], 'sha256': p['sha256'],
                    'node_count': 2, 'support': [0, 1], 'zero': False, 'one': False}
        model = {'bdd_variable_count': 2, 'bdd_variable_order': [0, 1]}
        before = {'structure': {'array': {'length': 2}, 'nullable': 'null', 'flag': True}, 'bdd_count': 1, 'bdds': {'x': ref('baseline')}}
        after = {'structure': before['structure'].copy(), 'bdd_count': 1, 'bdds': {'x': ref('variant')}}
        SnapshotAudit(model, files).compare(before, after, 'variant'); checks.append('positive_complete_snapshot')
        for name, mutate in [('structure', lambda x: x['structure'].update(flag=False)),
                             ('missing_key', lambda x: x['bdds'].clear()),
                             ('count', lambda x: x.update(bdd_count=2)),
                             ('support', lambda x: x['bdds']['x'].update(support=[0]))]:
            altered = json.loads(json.dumps(after)); mutate(altered)
            try: SnapshotAudit(model, files).compare(before, altered, 'variant')
            except (ValueError, KeyError): checks.append('reject_' + name)
            else: raise AssertionError('Accepted synthetic ' + name)
        broken = folder / 'bad.bdd'; broken.write_bytes(b'2\n0 1\n2 0 0 1\n3 1 2 1\n')
        try: SavedDag(broken.read_bytes(), 2, [0, 1])
        except ValueError: checks.append('reject_bad_native_order')
        else: raise AssertionError('Accepted bad native order')
        other = folder / 'variant.bdd'; other.write_bytes(b'2\n0 1\n2 0 0 1\n')
        files['variant']['variant.bdd'] = pin(other)
        different = json.loads(json.dumps(after)); different['bdds']['x'].update(bytes=other.stat().st_size,
            sha256=pin(other)['sha256'], node_count=1, support=[0])
        try: SnapshotAudit(model, files).compare(before, different, 'variant')
        except ValueError: checks.append('reject_wellformed_different_function')
        else: raise AssertionError('Accepted changed function')
    report = {'status': 'PASS_SYNTHETIC_PAIR_SNAPSHOT_QUALIFICATION', 'checks': checks,
              'check_count': len(checks), 'code': codes(), 'actual355_inputs_read': False,
              'native_or_compiler_calls': 0, 'created_utc': now()}
    save_new(path, report)
    print(json.dumps({'status': report['status'], 'report': pin(path)}))


def main():
    if len(sys.argv) == 3 and sys.argv[1] == '--self-test':
        self_test(Path(sys.argv[2])); return 0
    need(len(sys.argv) == 4, 'ROOT_GO PAIR_INPUTS NEW_REPORT required')
    go_path, input_path, output = map(lambda x: Path(x).resolve(), sys.argv[1:])
    need(not output.exists() and not output.is_symlink(), 'New report only')
    manifest = decode_json(input_path.read_bytes())
    need(manifest['schema'] == 'v48-pair355-audit-inputs-v1' and manifest['authorization'] == pin(go_path), 'Exact root authorization binding')
    go = decode_json(read_pin(manifest['authorization']))
    need(go.get('start_authorized') is True and go.get('pair355_worker_budget') == 1
         and go.get('pair355_code') == codes(), 'Root one-worker exact code authorization')
    report = {'schema': 'v48-pair355-independent-reconciliation-v1', 'started_utc': now(),
              'authorization': manifest['authorization'], 'input_manifest': pin(input_path), 'code': codes()}
    try:
        report.update(audit(manifest))
    except Exception as error:
        report.update(status='UNKNOWN_PAIR355_RECONCILIATION', error_type=type(error).__name__, error=str(error))
    report.update(finished_utc=now(), native_calls=0, compiler_calls=0, fixed_point_solves=0, raw_outputs_modified=False, full_reset_uses=0)
    save_new(output, report)
    print(json.dumps({'status': report['status'], 'report': pin(output)}))
    return 0 if report['status'].startswith('PASS_') else 2


if __name__ == '__main__':
    sys.exit(main())
