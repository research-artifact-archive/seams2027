"""Root-authorized exact two-worker audit launcher. Parent imports only stdlib and the pinned owned-process supervisor.

Two-level binding avoids a cycle: worker GO is pinned by both input manifests;
then the parent launch GO pins worker GO and both finalized manifests.
Usage: python -I -S -B run_independent355.py LAUNCH_GO ORACLE_INPUTS PAIR_INPUTS NEW_OUTPUT_ROOT
"""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib
import importlib.util
import json
import os
import sys
import traceback

sys.dont_write_bytecode = True
B = Path(__file__).resolve().parent
NATIVE = B / "native355"
HARD_STOP_TEXT = "2026-10-21T10:06:09+00:00"
HARD_STOP = datetime.fromisoformat(HARD_STOP_TEXT)
ORACLE_NAMES = ("audit355.py", "independent_core.py", "bdd_core.py", "source_semantics.py",
                "symbolic_source.py", "model355.py", "graph355.py", "activity.py")
PAIR_NAMES = ("audit_pair355.py", "oracle355/independent_core.py")
DISPATCH_NAMES = ("bounded_process.py", "owned_process.py")
EXPECTED_LIMITS = {
    "source_graph_oracle_wall_seconds": 180, "source_graph_oracle_rss_bytes": 2147483648,
    "pair_parity_wall_seconds": 60, "pair_parity_rss_bytes": 1073741824,
    "stdout_bytes": 8388608, "stderr_bytes": 8388608, "each_file_bytes": 16777216,
    "worker_tree_bytes": 268435456, "aggregate_tree_bytes": 536870912,
    "min_free_bytes": 1073741824, "tree_entry_cap": 32768,
    "cleanup_reserve_seconds": 20, "automatic_retries": 0}


def need(value, message):
    if not value:
        raise ValueError(message)


def now():
    return datetime.now(timezone.utc)


def deadline():
    need(now() < HARD_STOP, "Independent launcher hard stop")


def unique(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, "Duplicate JSON key")
        result[key] = value
    return result


def read(path):
    path = Path(path)
    need(path.is_file() and not path.is_symlink() and path.stat().st_size <= 16777216, "Bounded regular JSON input")
    return json.loads(path.read_text(), object_pairs_hook=unique)


def pin(path):
    path = Path(path).resolve()
    need(path.is_file(), "Regular pinned file required")
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            deadline()
            digest.update(chunk)
            size += len(chunk)
    return {"path": str(path), "bytes": size, "sha256": digest.hexdigest()}


def verify(refs):
    for ref in refs:
        deadline()
        need(Path(ref["path"]).is_absolute() and not Path(ref["path"]).is_symlink(), "Absolute nonsymlink input pin")
        actual = pin(ref["path"])
        need(actual == {key: ref[key] for key in ("path", "bytes", "sha256")}, "Exact input pin mismatch: " + ref["path"])


def nested_refs(value):
    if isinstance(value, dict):
        if all(key in value for key in ("path", "bytes", "sha256")):
            yield {key: value[key] for key in ("path", "bytes", "sha256")}
        for child in value.values():
            yield from nested_refs(child)
    elif isinstance(value, list):
        for child in value:
            yield from nested_refs(child)


def save_new(path, value):
    deadline()
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()
    need(len(raw) <= 16777216, "Parent receipt file cap")
    with Path(path).open("xb") as stream:
        stream.write(raw)


def clean_end(process):
    return (process.get("owned_child_reaped") is True and process.get("receipt_persisted") is True
        and process.get("parent_finalization_completed") is True and process.get("parent_aborted") is False
        and not (process.get("exact_child_wait4") or {}).get("authority_lost")
        and (not process.get("process_started") or ((process.get("exact_child_wait4") or {}).get("exact_child_reaped") is True
            and (process.get("final_group_observation") or {}).get("state") == "ABSENT")))


def completed(process):
    return (clean_end(process) and process.get("status") == "PROCESS_COMPLETED" and process.get("exit_code") == 0
        and not process.get("fatal_reasons") and not process.get("resource_reasons")
        and set(process.get("capture", {})) == {"stdout", "stderr"}
        and all(item["complete"] for item in process["capture"].values()))


def authorize(launch_path, oracle_path, pair_path, output):
    deadline()
    launch_path, oracle_path, pair_path, output = [Path(path).resolve() for path in (launch_path, oracle_path, pair_path, output)]
    need(launch_path.exists(), "Missing root audit launch GO")
    go = read(launch_path)
    need(go.get("status") == "GO_EXACT_355_TWO_INDEPENDENT_WORKERS" and go.get("start_authorized") is True,
         "Root exact audit launch authorization")
    need(go.get("launcher") == pin(Path(__file__)), "Exact launcher pin mismatch")
    interpreter = pin(Path(sys.executable).resolve())
    need(go.get("python") == interpreter, "Exact current parent Python interpreter")
    need(go.get("hard_stop_utc") == HARD_STOP_TEXT and go.get("limits") == EXPECTED_LIMITS, "Fixed independent worker limits/deadline")
    need(go.get("worker_order") == ["source_graph_oracle", "pair_parity"] and go.get("attempts_each") == 1, "Fixed one-attempt worker roster")
    need(output == (B / "independent_execution_01").resolve() and go.get("output_root") == str(output), "Exact fresh output scope")
    need(not output.exists() and not output.is_symlink(), "Fresh output only; no repeats")
    need(go.get("oracle_inputs") == pin(oracle_path) and go.get("pair_inputs") == pin(pair_path), "Exact manifest pins")
    oracle = read(oracle_path)
    pair = read(pair_path)
    worker_ref = go["worker_go"]
    verify([worker_ref])
    worker = read(worker_ref["path"])
    need(worker.get("start_authorized") is True and worker.get("oracle355_worker_budget") == 1
        and worker.get("pair355_worker_budget") == 1, "Root exact worker authorization budgets")
    need(oracle.get("schema") == "v48-independent355-inputs-v1" and pair.get("schema") == "v48-pair355-audit-inputs-v1"
        and oracle.get("authorization") == worker_ref and pair.get("authorization") == worker_ref, "Both manifests bind exact worker GO")
    oracle_code = [pin(B / "oracle355" / name) for name in ORACLE_NAMES]
    pair_code = [pin(B / name) for name in PAIR_NAMES]
    dispatch = [pin(NATIVE / "code/dispatch" / name) for name in DISPATCH_NAMES]
    need(worker.get("oracle355_code") == oracle_code and worker.get("pair355_code") == pair_code,
         "Exact ordered worker code rosters")
    need(go.get("oracle355_code") == oracle_code and go.get("pair355_code") == pair_code
        and go.get("supervisor") == dispatch, "Parent exact code/supervisor bindings")
    native_freeze_ref = go["native_freeze"]
    need(native_freeze_ref == pin(NATIVE / "EXECUTABLE_FREEZE.json"), "Exact native input freeze")
    native_freeze = read(native_freeze_ref["path"])
    frozen = {ref["path"]: ref for ref in native_freeze["files"]}
    need(all(ref["path"] in frozen and frozen[ref["path"]] == ref for ref in dispatch), "Supervisor is in native freeze")
    launcher_freeze_ref = go["launcher_freeze"]
    verify([launcher_freeze_ref])
    launcher_freeze = read(launcher_freeze_ref["path"])
    need(launcher_freeze.get("status") == "FROZEN_INDEPENDENT_PARENT_LAUNCHER", "Launcher freeze status")
    frozen_parent = {ref["path"]: ref for ref in launcher_freeze["files"]}
    need(all(frozen_parent.get(ref["path"]) == ref for ref in [pin(Path(__file__)), interpreter] + dispatch), "Complete frozen parent executable roster")
    verify(launcher_freeze["files"])
    reviews = go["independent_static_reviews"]
    need(len(reviews) >= 1, "Independent launcher review required")
    for ref in reviews:
        verify([ref])
        review = read(ref["path"])
        need(review["status"].startswith("PASS") and review.get("launcher_freeze") == launcher_freeze_ref
            and not review.get("blocking_issues"), "Independent exact frozen launcher PASS")
    need(len(go["qualification_results"]) >= 3, "Launcher, source oracle and pair qualification evidence required")
    for ref in go["qualification_results"]:
        verify([ref])
        need(read(ref["path"])["status"].startswith("PASS"), "Synthetic qualification PASS required")
    protected = read(B / "V47_PROTECTED_INPUTS.json")
    all_refs = [pin(launch_path), pin(oracle_path), pin(pair_path), worker_ref, native_freeze_ref,
        launcher_freeze_ref, pin(B / "V47_PROTECTED_INPUTS.json"), interpreter] + oracle_code + pair_code + dispatch
    all_refs += list(nested_refs(oracle)) + list(nested_refs(pair)) + protected["files"]
    all_refs += native_freeze["files"] + launcher_freeze["files"]
    dedup = {}
    for ref in all_refs:
        need(ref["path"] not in dedup or dedup[ref["path"]] == ref, "Conflicting input pins")
        dedup[ref["path"]] = ref
    verify(list(dedup.values()))
    spec = importlib.util.spec_from_file_location("v48_independent_owned_supervisor", NATIVE / "code/dispatch/bounded_process.py")
    supervisor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(supervisor)
    return go, worker_ref, output, supervisor, list(dedup.values()), interpreter


def run(launch_path, oracle_path, pair_path, output):
    go, worker, output, supervisor, inputs, interpreter = authorize(launch_path, oracle_path, pair_path, output)
    output.mkdir(exist_ok=False)
    rows = [
        {"id": "source_graph_oracle", "wall_seconds": 180, "rss_bytes": 2147483648, "attempts": 0, "status": "NOT_ATTEMPTED"},
        {"id": "pair_parity", "wall_seconds": 60, "rss_bytes": 1073741824, "attempts": 0, "status": "NOT_ATTEMPTED"}]
    result = {"schema": "v48-independent355-two-worker-parent-v1", "status": "RUNNING", "started_utc": now().isoformat(),
        "launch_go": pin(launch_path), "worker_go": worker, "python": interpreter, "input_pins": inputs,
        "limits": EXPECTED_LIMITS, "hard_stop_utc": HARD_STOP_TEXT, "rows": rows, "errors": [], "scientific_adoption": "ROOT_REVIEW_REQUIRED"}
    save_new(output / "STARTED.json", {key: result[key] for key in ("schema", "started_utc", "launch_go", "worker_go", "python", "limits", "hard_stop_utc")})
    fatal = False
    try:
        for row in rows:
            if fatal:
                row["status"] = "UNKNOWN_NOT_ATTEMPTED_AFTER_PROCESS_INTEGRITY_FAILURE"
                continue
            if (HARD_STOP - now()).total_seconds() <= row["wall_seconds"] + 25:
                row["status"] = "UNKNOWN_NOT_ATTEMPTED_DEADLINE_RESERVE"
                continue
            verify(inputs)
            if (HARD_STOP - now()).total_seconds() <= row["wall_seconds"] + 25:
                row["status"] = "UNKNOWN_NOT_ATTEMPTED_DEADLINE_AFTER_INPUT_VERIFICATION"
                continue
            root = output / row["id"]
            root.mkdir(exist_ok=False)
            process_dir = root / "process"
            if row["id"] == "source_graph_oracle":
                code, manifest, target = B / "oracle355/audit355.py", Path(oracle_path).resolve(), root / "audit"
                watched = [target / "RESULT.json"] + [target / (arm + "_RESULT.json") for arm in ("baseline", "preference", "normalized")]
            else:
                code, manifest, target = B / "audit_pair355.py", Path(pair_path).resolve(), root / "PAIR_RESULT.json"
                watched = [target]
            argv = [interpreter["path"], "-I", "-S", "-B", str(code), worker["path"], str(manifest), str(target)]
            row["attempts"] = 1
            row["status"] = "UNKNOWN_WORKER_INCOMPLETE"
            row["command"] = argv
            row["output"] = str(target)
            boundary = min(HARD_STOP - timedelta(seconds=20), now() + timedelta(seconds=row["wall_seconds"] + 20))
            process = supervisor.run_bounded(argv, process_dir, boundary.isoformat(),
                wall_seconds=row["wall_seconds"], rss_bytes=row["rss_bytes"], stream_bytes=8388608,
                file_bytes=16777216, watch_files=watched, output_tree=root, output_tree_bytes=268435456,
                aggregate_tree=output, aggregate_tree_bytes=536870912, min_free_bytes=1073741824)
            row["process"] = pin(process_dir / "PROCESS_RECEIPT.json")
            row["clean_process_end"] = clean_end(process)
            row["worker_exit_code"] = process.get("exit_code")
            if not clean_end(process):
                row["status"] = "UNKNOWN_PROCESS_INTEGRITY_GLOBAL_STOP"
                fatal = True
            elif completed(process):
                row["status"] = "COMPLETE_WORKER_PROCESS_PENDING_ROOT_RECONCILIATION"
            else:
                row["status"] = "UNKNOWN_WORKER_RESOURCE_PROCESS_OR_REPORTED_FAILURE"
            final_path = target / "RESULT.json" if row["id"] == "source_graph_oracle" else target
            if final_path.is_file():
                row["report"] = pin(final_path)
                row["reported_status"] = read(final_path).get("status")
            verify(inputs)
            save_new(root / "ROW_RESULT.json", row)
        result["status"] = "COMPLETE_FIXED_TWO_WORKER_ACCOUNTING_PENDING_ROOT_REVIEW"
    except BaseException as error:
        result["status"] = "UNKNOWN_PARENT_FAILURE_NO_RETRY"
        result["errors"].append({"type": type(error).__name__, "message": str(error), "traceback": traceback.format_exc()})
    finally:
        try:
            verify(inputs)
            result["input_integrity"] = "PASS"
        except BaseException as error:
            result["input_integrity"] = "UNKNOWN_OR_FAILED"
            result["errors"].append({"message": str(error)})
            result["status"] = "UNKNOWN_PARENT_INPUT_INTEGRITY"
        result["finished_utc"] = now().isoformat()
        # Persist bounded accounting even if a cooperative deadline was reached.
        raw = (json.dumps(result, ensure_ascii=False, indent=2) + "\n").encode()
        need(len(raw) <= 16777216, "Final parent receipt cap")
        with (output / "PARENT_RECEIPT.json").open("xb") as stream:
            stream.write(raw)
    print(json.dumps({"status": result["status"], "rows": [{key: row[key] for key in ("id", "attempts", "status")} for row in rows],
        "receipt_path": str(output / "PARENT_RECEIPT.json")}))
    return 0 if all(row["status"] == "COMPLETE_WORKER_PROCESS_PENDING_ROOT_RECONCILIATION" for row in rows) else 2


if __name__ == "__main__":
    need(len(sys.argv) == 5, "LAUNCH_GO ORACLE_INPUTS PAIR_INPUTS NEW_OUTPUT_ROOT required")
    sys.exit(run(*sys.argv[1:]))
