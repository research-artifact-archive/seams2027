"""Reconcile already finished, bounded UNKNOWN outputs. No scientific recomputation."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

B = Path(__file__).resolve().parent
N = B / 'native355'
I = B / 'independent_execution_01'

def need(v, msg):
    if not v:
        raise ValueError(msg)

def pin(p):
    p = Path(p).resolve()
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def read(p):
    return json.loads(Path(p).read_text())

def verify(ref):
    need(pin(ref['path']) == {k: ref[k] for k in ('path', 'bytes', 'sha256')}, 'Pin mismatch: ' + ref['path'])

def nested(v):
    if isinstance(v, dict):
        if all(k in v for k in ('path', 'bytes', 'sha256')):
            yield v
        for value in v.values():
            yield from nested(value)
    elif isinstance(v, list):
        for value in v:
            yield from nested(value)

def save(p, d):
    with p.open('x') as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
        f.write('\n')

native = read(N / 'RUN_RECEIPT.json')
parent = read(I / 'PARENT_RECEIPT.json')
source = read(I / 'source_graph_oracle/audit/RESULT.json')
pair = read(I / 'pair_parity/PAIR_RESULT.json')
review_ref = pin(B / 'V48_INDEPENDENT_SCIENTIFIC_RECONCILIATION.json')
review = read(review_ref['path'])
need(review['status'].startswith('PASS') and not review.get('blocking_issues'), 'Independent recorded-result review')
need(native['status'] == 'COMPLETE_FIXED_ATTEMPTS_PENDING_INDEPENDENT_AUDITS'
     and native['input_integrity'] == 'PASS' and native['errors'] == [], 'Native input/accounting integrity')
need(parent['status'] == 'COMPLETE_FIXED_TWO_WORKER_ACCOUNTING_PENDING_ROOT_REVIEW'
     and parent['input_integrity'] == 'PASS' and parent['errors'] == [], 'Independent parent input/accounting integrity')
need(native['go'] == parent['worker_go'] == source['authorization'] == pair['authorization']
     == pin(N / 'ROOT_EXECUTION_GO.json'), 'Single frozen worker authorization')
need(source['input_manifest'] == pin(B / 'ORACLE_INPUTS.json')
     and pair['input_manifest'] == pin(B / 'PAIR_INPUTS.json'), 'Exact worker manifests')
checked = {}
for ref in parent['input_pins'] + read(N / 'EXECUTABLE_FREEZE.json')['files'] + read(B / 'V47_PROTECTED_INPUTS.json')['files']:
    verify(ref)
    checked[ref['path']] = ref
for ref in nested(review):
    if Path(ref['path']).is_absolute():
        verify(ref)
        checked[ref['path']] = ref
process_rows = []
for kind, rows in [('native', native['rows']), ('independent', parent['rows'])]:
    for row in rows:
        need(row.get('native_attempts', row.get('attempts')) == 1, 'Exactly one attempt')
        verify(row['process'])
        p = read(row['process']['path'])
        need(p['process_started'] is True and p['owned_child_reaped'] is True
             and p['receipt_persisted'] is True and p['parent_finalization_completed'] is True
             and p['parent_aborted'] is False and not p['parent_internal_exception']
             and p['exact_child_wait4']['exact_child_reaped'] is True
             and p['exact_child_wait4']['authority_lost'] is False
             and p['final_group_observation']['state'] == 'ABSENT' and not p['fatal_reasons'], 'Clean owned process closure')
        folder = Path(row['process']['path']).parent
        request = read(folder / 'PROCESS_REQUEST.json')
        need(request['argv'] == p['argv'], 'Process argv binding')
        for channel in ('stdout', 'stderr'):
            cap = p['capture'][channel]
            actual = pin(folder / cap['file'])
            need(cap['complete'] is True and cap['bytes'] == cap['captured_bytes'] == cap['observed_bytes'] == actual['bytes']
                 and cap['sha256'] == actual['sha256'], 'Exact complete captured stream')
        process_rows.append({'kind': kind, 'id': row['id'], 'process': row['process'],
            'status': p['status'], 'exit_code': p['exit_code'], 'elapsed_seconds': p['elapsed_seconds'],
            'resource_reasons': p['resource_reasons'], 'fatal_reasons': p['fatal_reasons'],
            'exact_child_reaped': True, 'final_group_absent': True, 'captured_streams_complete': True})
need([r['id'] for r in native['rows']] == ['paired_01', 'normalized_01'], 'Native roster')
need(process_rows[0]['status'] == 'UNKNOWN_RESOURCE' and process_rows[0]['resource_reasons'] == ['WALL_TIME_CAP']
     and process_rows[0]['exit_code'] == 143, 'Pair observed wall cap')
need(process_rows[1]['status'] == 'PROCESS_COMPLETED' and process_rows[1]['exit_code'] == 2
     and process_rows[1]['resource_reasons'] == [], 'Normalized completed error')
bp = N / 'runs/paired_01/native/result.json'
np = N / 'runs/normalized_01/normalized/result.json'
baseline, normalized = read(bp), read(np)
need(baseline['status'] == 'RUNNING' and baseline['stage'] == 'NATIVE_KIND_SOLVER'
     and baseline['controller_extraction_calls'] == 0, 'Incomplete native checkpoint, no extraction')
need(normalized['status'] == 'ERROR' and normalized['exception_class'] == 'java.io.IOException'
     and normalized['exception'] == 'java.io.IOException: File too large'
     and normalized['failed_stage'] == 'VIABILITY_FIXED_POINT'
     and normalized['native_solver_called'] is False and normalized['controller_extraction_called'] is False
     and normalized['teardown'] == 'COMPLETED', 'Normalized failed export before native solve')
partial = pin(np.with_name('restricted_rhoS.bdd'))
need(partial['bytes'] == 16777216 and 'InitialGraphProducer.snapshot' in normalized['stacktrace'], 'Partial restricted relation file cap')
need(not list((N / 'runs').rglob('controller.json')) and not (N / 'runs/paired_01/variant').exists(), 'No returned controllers or variant extraction')
need(source['original_source_model']['status'] == 'PASS_FULL_SOURCE_NATIVE_CORRESPONDENCE'
     and source['original_source_model']['full_typed_state_count'] == 524288,
     'Original historical reference source correspondence independently passed')
need([r['label'] for r in source['rows']] == ['baseline', 'preference', 'normalized']
     and all(r['status'] == 'UNKNOWN_INDEPENDENT_AUDIT' and r['error'] == 'Incomplete bounded native process' for r in source['rows'])
     and source['saved_V_steps_recomputed'] == 0, 'All three scientific arms remain UNKNOWN')
need(pair['status'] == 'UNKNOWN_PAIR355_RECONCILIATION' and pair['error'] == 'Complete clean pair process required', 'Pair provenance remains unknown')
files = [pin(p) for root in (N / 'runs', I) for p in sorted(root.rglob('*')) if p.is_file()]
freeze = {'schema': 'v48-completed-scientific-output-freeze-v1',
          'status': 'FROZEN_ALL_NATIVE_AND_INDEPENDENT_OUTPUTS_INCLUDING_PARTIAL_FAILURE_FILES',
          'files': files, 'native_run_receipt': pin(N / 'RUN_RECEIPT.json'),
          'scientific_recomputation': False, 'automatic_retries': 0}
save(B / 'SCIENTIFIC_OUTPUT_FREEZE.json', freeze)
result = {'schema': 'v48-scientific-adoption-v1', 'status': 'ADOPTED_BOUNDED_UNKNOWN_AND_LIMITED_SOURCE_CORRESPONDENCE',
    'created_utc': datetime.now(timezone.utc).isoformat(), 'selection': pin(B / 'SELECTION_AND_BOUNDED_RESEARCH_PROTOCOL.json'),
    'native_go': pin(N / 'ROOT_EXECUTION_GO.json'), 'audit_go': pin(B / 'ROOT_AUDIT_LAUNCH_GO.json'),
    'native_run_receipt': pin(N / 'RUN_RECEIPT.json'), 'independent_parent': pin(I / 'PARENT_RECEIPT.json'),
    'source_graph_audit': pin(I / 'source_graph_oracle/audit/RESULT.json'), 'pair_audit': pin(I / 'pair_parity/PAIR_RESULT.json'),
    'independent_reconciliation': review_ref, 'output_freeze': pin(B / 'SCIENTIFIC_OUTPUT_FREEZE.json'),
    'original_model_reference': pin(B / 'ORIGINAL_MODEL_REFERENCE.json'), 'source_semantics_review': pin(B / 'SOURCE355_INDEPENDENT_SEMANTIC_REVIEW.json'),
    'processes': process_rows, 'source_model_correspondence': source['original_source_model'],
    'outcomes': {'baseline': 'UNKNOWN_WALL_TIME_BEFORE_SOLVER_RETURN',
       'preference': 'NOT_REACHED_WITHIN_UNKNOWN_PAIRED_ATTEMPT',
       'normalized': 'UNKNOWN_FILE_SIZE_EXCEPTION_BEFORE_NATIVE_SOLVER',
       'source_graph_verdicts': 'UNKNOWN_ALL_THREE_ARMS', 'pair_parity': 'UNKNOWN',
       'preference_activity': 'NOT_OBSERVED_NO_EXTRACTION', 'cooperative_feasibility': 'UNCLASSIFIED',
       'original_strict_feasibility': 'UNCLASSIFIED'},
    'partial_normalized_relation': dict(partial, complete=False, certified=False),
    'native_recorded_V_iterations': len(normalized['viability_iterations']),
    'native_recorded_V_last_equal': normalized['viability_iterations'][-1]['equal'],
    'native_V_independently_certified': False, 'native_K_independently_certified': False,
    'same_memory_pair_established': False, 'transformed_source_BDD_correspondence_established': False,
    'Q_impl_Q_original_BDD_comparison_executed': False,
    'static_translation_scope': 'Source/translator and emitted AST timing are inspected separately. A manually derived typed-state availability counterexample is a static argument, not an observed controller state or BDD-qualified actual model result.',
    'increment_relative_to_v47': 'One preselected original public source beyond the qualified59 was attempted without modifying the fixed preference. It gives a reproducible resource UNKNOWN and narrows the universal-sounding interpretation of Q; it supplies no second active rescue.',
    'residual_concerns': {'N1_other_model_effectiveness': 'REMAINS_UNRESOLVED', 'N2_exact_preservation_practical_significance': 'NOT_EXECUTED_REMAINS_UNRESOLVED'},
    'cohorts': {'existing_11_replacements_unchanged': True, 'existing_14_controls_unchanged': True,
       'existing_59_qualified_public_models_unchanged': True, 'additional_selected_source_count': 1, 'added_qualified_controllers': 0},
    'all_pinned_inputs_verified': len(checked), 'protected_v47_files_verified': len(read(B / 'V47_PROTECTED_INPUTS.json')['files']),
    'native_JVM_attempts': 2, 'independent_worker_attempts': 2, 'automatic_retries': 0,
    'other_model_switches': 0, 'postoutcome_heuristic_changes': 0, 'full_reset_uses': 0,
    'remaining_work': 'Integrate precise scope/UNKNOWN result in a new v48 manuscript, supplement and auditable public snapshot; preserve full proofs and all v47 artifacts.'}
save(B / 'SCIENTIFIC_ADOPTION.json', result)
print(json.dumps({'status': result['status'], 'adoption': pin(B / 'SCIENTIFIC_ADOPTION.json'), 'frozen_output_files': len(files)}))
