"""Bind the sole native batch to exact worker manifests and root launch GO."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys

B = Path(__file__).resolve().parent
N = B / 'native355'

def need(v, message):
    if not v:
        raise ValueError(message)

def pin(p):
    p = Path(p).resolve()
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def read(p):
    return json.loads(Path(p).read_text())

def save(p, v):
    with p.open('x') as f:
        json.dump(v, f, ensure_ascii=False, indent=2)
        f.write('\n')

need(datetime.now(timezone.utc) < datetime.fromisoformat('2026-10-21T10:06:09+00:00'), 'Science hard stop')
worker_ref = pin(N / 'ROOT_EXECUTION_GO.json')
worker = read(worker_ref['path'])
run = read(N / 'RUN_RECEIPT.json')
need(run['go'] == worker_ref and run['input_integrity'] == 'PASS', 'Exact native run and unchanged inputs')
need([r['id'] for r in run['rows']] == ['paired_01', 'normalized_01'], 'Fixed native roster')
original_ref = pin(B / 'ORIGINAL_MODEL_REFERENCE.json')
need(worker['original_model_reference'] == original_ref, 'Original reference fixed before native outcomes')
original = read(original_ref['path'])
source = pin(N / 'inputs/1673286053.spectra')
imported = pin(N / 'inputs/imports/DwyerPatterns.spectra')
pair = N / 'runs/paired_01'
normal = N / 'runs/normalized_01/normalized'

def bdds(folder):
    return {p.name: pin(p) for p in sorted(folder.glob('*.bdd'))}

def job(label, mode, folder, process):
    row = {'label': label, 'mode': mode}
    if process.is_file():
        row['process'] = pin(process)
    else:
        row['native_process_missing'] = True
    if (folder / 'model.json').is_file():
        row.update(model=pin(folder / 'model.json'), bdd_files=bdds(folder))
    if (folder / 'result.json').is_file():
        row['result'] = pin(folder / 'result.json')
        result = read(folder / 'result.json')
        if result['status'] in ('JOB_CONTROLLER_PRINTED', 'COMPLETE_CONTROLLER_EXPORTED'):
            if (folder / 'controller.json').is_file():
                row['controller'] = pin(folder / 'controller.json')
            if mode == 'syntactic' and (folder / 'controller.txt').is_file():
                row['printer'] = pin(folder / 'controller.txt')
    return row

baseline = job('baseline', 'syntactic', pair / 'native', pair / 'native/PROCESS_RECEIPT.json')
preference = job('preference', 'syntactic', pair / 'variant', pair / 'native/PROCESS_RECEIPT.json')
if 'result' in baseline:
    base = read(baseline['result']['path'])
    if base['status'] in ('JOB_UNREALIZABLE_NO_CONTROLLER', 'JOB_EMPTY_MEMORY_NO_CONTROLLER'):
        preference = {'label': 'preference', 'mode': 'syntactic', 'status': 'NOT_RUN', 'reason': 'PAIR_BASELINE_NO_CONTROLLER'}
normalized = job('normalized', 'normalized', normal, normal / 'PROCESS_RECEIPT.json')
oracle = {'schema': 'v48-independent355-inputs-v1', 'authorization': worker_ref,
          'source': source, 'import': imported, 'original_model_reference': original_ref,
          'original_model': {'model': original['model'], 'bdd_files': original['bdd_files']},
          'jobs': [baseline, preference, normalized], 'native_run_receipt': pin(N / 'RUN_RECEIPT.json'),
          'binding_scope': 'All three predeclared arms, including incomplete or missing outputs. Worker failures remain UNKNOWN; no outcome-based omission.'}
files = {'source': source, 'import': imported, 'run_receipt': pin(N / 'RUN_RECEIPT.json'),
         'build': pin(N / 'BUILD_RECEIPT.json'), 'runtime': pin(N / 'RUNTIME_INPUTS.json')}
paths = {'process': pair / 'native/PROCESS_RECEIPT.json',
         'baseline_result': pair / 'native/result.json', 'baseline_model': pair / 'native/model.json',
         'baseline_controller': pair / 'native/controller.json', 'baseline_printer': pair / 'native/controller.txt',
         'variant_result': pair / 'variant/result.json', 'variant_model': pair / 'variant/model.json',
         'variant_controller': pair / 'variant/controller.json', 'variant_printer': pair / 'variant/controller.txt',
         'paired_intervention': pair / 'variant/paired_intervention.json',
         'shared_teardown': pair / 'variant/SHARED_TEARDOWN.json',
         'class_origin_check': pair / 'CLASS_ORIGIN_CHECK.json',
         'rle_verification': pair / 'native/RLE_VERIFICATION.json'}
for name, path in paths.items():
    if path.is_file():
        files[name] = pin(path)
pair_manifest = {'schema': 'v48-pair355-audit-inputs-v1', 'authorization': worker_ref,
                 'files': files, 'bdd_files': {'baseline': bdds(pair / 'native'), 'variant': bdds(pair / 'variant')},
                 'native_outcome_roster': run['rows'], 'manifest_writer': pin(Path(__file__))}
save(B / 'ORACLE_INPUTS.json', oracle)
save(B / 'PAIR_INPUTS.json', pair_manifest)
launcher_freeze = pin(B / 'INDEPENDENT_LAUNCHER_FREEZE.json')
launcher_review = pin(B / 'INDEPENDENT355_LAUNCHER_STATIC_REVIEW.json')
need(worker['launcher_freeze'] == launcher_freeze and worker['launcher_review'] == launcher_review, 'Pre-outcome launcher review/freeze unchanged')
review = read(launcher_review['path'])
need(review['status'].startswith('PASS') and not review.get('blocking_issues')
     and review['launcher_freeze'] == launcher_freeze, 'Exact independent launcher PASS')
limits = {'source_graph_oracle_wall_seconds': 180, 'source_graph_oracle_rss_bytes': 2147483648,
    'pair_parity_wall_seconds': 60, 'pair_parity_rss_bytes': 1073741824,
    'stdout_bytes': 8388608, 'stderr_bytes': 8388608, 'each_file_bytes': 16777216,
    'worker_tree_bytes': 268435456, 'aggregate_tree_bytes': 536870912,
    'min_free_bytes': 1073741824, 'tree_entry_cap': 32768,
    'cleanup_reserve_seconds': 20, 'automatic_retries': 0}
go = {'schema': 'v48-independent355-root-launch-go-v1',
      'status': 'GO_EXACT_355_TWO_INDEPENDENT_WORKERS', 'start_authorized': True,
      'created_utc': datetime.now(timezone.utc).isoformat(), 'worker_go': worker_ref,
      'launcher': pin(B / 'run_independent355.py'), 'python': pin(Path(sys.executable).resolve()),
      'launcher_freeze': launcher_freeze, 'native_freeze': pin(N / 'EXECUTABLE_FREEZE.json'),
      'oracle_inputs': pin(B / 'ORACLE_INPUTS.json'), 'pair_inputs': pin(B / 'PAIR_INPUTS.json'),
      'oracle355_code': worker['oracle355_code'], 'pair355_code': worker['pair355_code'],
      'supervisor': [pin(N / 'code/dispatch' / n) for n in ('bounded_process.py', 'owned_process.py')],
      'limits': limits, 'worker_order': ['source_graph_oracle', 'pair_parity'], 'attempts_each': 1,
      'hard_stop_utc': '2026-10-21T10:06:09+00:00', 'output_root': str(B / 'independent_execution_01'),
      'independent_static_reviews': [launcher_review],
      'qualification_results': [pin(B / 'qualification_independent_launcher_01/RESULT.json'),
          pin(B / 'oracle355/QUALIFICATION_03.json'), pin(B / 'PAIR355_SYNTHETIC_QUALIFICATION_02.json')],
      'manifest_writer': pin(Path(__file__)), 'full_reset_uses': 0}
save(B / 'ROOT_AUDIT_LAUNCH_GO.json', go)
print(json.dumps({'status': go['status'], 'oracle_inputs': go['oracle_inputs'], 'pair_inputs': go['pair_inputs'],
                  'go': pin(B / 'ROOT_AUDIT_LAUNCH_GO.json')}))
