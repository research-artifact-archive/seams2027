"""AST and prelaunch rejection controls only; no worker imports or child processes."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
B = Path(__file__).resolve().parent
p = B / "run_independent355.py"
tree = ast.parse(p.read_text())
imports = set()
for node in ast.walk(tree):
    if isinstance(node, ast.Import): imports.update(alias.name.split('.')[0] for alias in node.names)
    if isinstance(node, ast.ImportFrom): imports.add(node.module.split('.')[0])
allowed = {'pathlib', 'datetime', 'hashlib', 'importlib', 'json', 'os', 'sys', 'traceback'}
if not imports <= allowed:
    raise ValueError('Non-stdlib parent import')
spec = importlib.util.spec_from_file_location('v48_synthetic_independent_parent', p)
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
q = B / 'qualification_independent_launcher_01'
q.mkdir(exist_ok=False)
output = B / 'independent_execution_01'
r.need(not output.exists(), 'No actual independent output may preexist this prelaunch qualification')
checks = [{'name': 'stdlib_only_parent_AST', 'status': 'PASS', 'import_modules': sorted(imports)}]
for label, path in [('missing_GO', q / 'ABSENT_ROOT_GO.json'), ('stale_launcher_hash', q / 'STALE_ROOT_GO.json')]:
    if label == 'stale_launcher_hash':
        bad = r.pin(p)
        bad['sha256'] = '0' * 64
        # Intentionally invalid synthetic authorization. It cannot pass the exact launcher hash gate.
        path.write_text(json.dumps({'status': 'GO_EXACT_355_TWO_INDEPENDENT_WORKERS', 'start_authorized': True,
            'launcher': bad, 'synthetic_negative_only': True}) + '\n')
    try:
        r.authorize(path, q / 'NO_ORACLE_INPUTS.json', q / 'NO_PAIR_INPUTS.json', output)
    except ValueError as error:
        expected = 'Missing root audit launch GO' if label == 'missing_GO' else 'Exact launcher pin mismatch'
        r.need(str(error) == expected, 'Exact expected prelaunch refusal')
        r.need(not output.exists(), 'Refusal created actual output')
        checks.append({'name': label, 'status': 'PASS', 'expected_refusal': str(error), 'child_processes_started': 0})
    else:
        raise AssertionError('Invalid synthetic GO accepted')
report = {'schema': 'v48-independent-launcher-synthetic-qualification-v1', 'status': 'PASS_STDLIB_AST_AND_PRELAUNCH_REFUSALS',
    'launcher': r.pin(p), 'qualifier': r.pin(Path(__file__)), 'python': r.pin(Path(sys.executable).resolve()),
    'checks': checks, 'actual355_inputs_read': False, 'worker_modules_imported': False,
    'native_or_compiler_or_worker_processes': 0, 'created_utc': datetime.now(timezone.utc).isoformat()}
r.save_new(q / 'RESULT.json', report)
print(json.dumps({'status': report['status'], 'report': r.pin(q / 'RESULT.json'), 'launcher': r.pin(p)}))
