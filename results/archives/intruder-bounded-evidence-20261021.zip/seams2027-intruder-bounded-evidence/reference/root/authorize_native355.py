"""Persist root's reviewed, exact one-batch scientific authorization. No science."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

B = Path(__file__).resolve().parent
N = B / 'native355'

def need(v, message):
    if not v:
        raise ValueError(message)

def pin(p):
    p = Path(p).resolve()
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def read(p):
    return json.loads(Path(p).read_text())

def verify(ref):
    need(pin(ref['path']) == {k: ref[k] for k in ('path', 'bytes', 'sha256')}, 'Exact pin: ' + ref['path'])

def nested(v):
    if isinstance(v, dict):
        if all(k in v for k in ('path', 'bytes', 'sha256')):
            yield v
        for child in v.values():
            yield from nested(child)
    elif isinstance(v, list):
        for child in v:
            yield from nested(child)

def save(p, v):
    with p.open('x') as f:
        json.dump(v, f, ensure_ascii=False, indent=2)
        f.write('\n')

now = datetime.now(timezone.utc)
need(now < datetime.fromisoformat('2026-10-21T09:16:09+00:00'), 'Preparation cutoff')
need(not (N / 'runs').exists() and not (N / 'ROOT_EXECUTION_GO.json').exists(), 'First exact native batch only')
freeze = pin(N / 'EXECUTABLE_FREEZE.json')
oracle_freeze = pin(B / 'oracle355/FROZEN.json')
launcher_freeze = pin(B / 'INDEPENDENT_LAUNCHER_FREEZE.json')
native_review = pin(B / 'NATIVE355_INDEPENDENT_STATIC_REVIEW.json')
oracle_review = pin(B / 'ORACLE355_INDEPENDENT_STATIC_REVIEW.json')
launcher_review = pin(B / 'INDEPENDENT355_LAUNCHER_STATIC_REVIEW.json')
second_review = pin(B / 'ORACLE355_PAIR_SECOND_STATIC_REVIEW.json')
second = read(second_review['path'])
need(second['status'].startswith('PASS') and not second.get('blocking_issues'), 'Second oracle and pair review')
for ref in nested(second):
    verify(ref)
scope_correction = pin(B / 'oracle355/QUALIFICATION_03_SCOPE_CORRECTION.json')
original_reference = pin(B / 'ORIGINAL_MODEL_REFERENCE.json')
for ref in nested(read(original_reference['path'])):
    verify(ref)
for ref, key, target in [(native_review, 'executable_freeze', freeze),
                         (oracle_review, 'oracle_freeze', oracle_freeze),
                         (launcher_review, 'launcher_freeze', launcher_freeze)]:
    report = read(ref['path'])
    need(report['status'].startswith('PASS') and report[key] == target and not report.get('blocking_issues'), 'Exact independent review')
    for r in nested(report):
        verify(r)
for filename in ('EXECUTABLE_FREEZE.json',):
    for ref in read(N / filename)['files']:
        verify(ref)
for ref in read(B / 'INDEPENDENT_LAUNCHER_FREEZE.json')['files']:
    verify(ref)
of = read(B / 'oracle355/FROZEN.json')
for ref in nested(of):
    verify(ref)
for ref in read(B / 'V47_PROTECTED_INPUTS.json')['files']:
    verify(ref)
quals = [pin(N / 'qualification_transport_01/RESULT.json'),
         pin(N / 'qualification_rle_deadline_01/RESULT.json'),
         pin(B / 'oracle355/QUALIFICATION_03.json'),
         pin(B / 'PAIR355_SYNTHETIC_QUALIFICATION_02.json'),
         pin(B / 'qualification_independent_launcher_01/RESULT.json')]
for ref in quals:
    need(read(ref['path'])['status'].startswith('PASS'), 'Qualification PASS')
pair_code = [pin(B / 'audit_pair355.py'), pin(B / 'oracle355/independent_core.py')]
qpair = read(B / 'PAIR355_SYNTHETIC_QUALIFICATION_02.json')
need(qpair['code'] == pair_code, 'Final pair auditor qualified code')
qoracle = read(B / 'oracle355/QUALIFICATION_03.json')
qualified = {r['path']: r for r in qoracle['files']}
need(all(qualified[r['path']] == r for r in of['code']), 'Exact qualified oracle closure')
root_review = {'schema': 'v48-root-final-worker-static-review-v1',
    'status': 'PASS_EXACT_FROZEN_SOURCE_GRAPH_PAIR_AND_PARENT_REVIEW', 'created_utc': now.isoformat(),
    'oracle_freeze': oracle_freeze, 'oracle355_code': of['code'], 'pair355_code': pair_code,
    'launcher_freeze': launcher_freeze, 'launcher': pin(B / 'run_independent355.py'),
    'independent_reviews': [native_review, oracle_review, launcher_review, second_review],
    'qualification_results': quals, 'blocking_issues': [],
    'qualification_scope_correction': scope_correction,
    'original_model_reference': original_reference,
    'root_full_read': ['All eight oracle source modules, final qualification source and results.',
        'Whole pair auditor and final explicit class roster/configuration delta changes; all seven synthetic controls.',
        'Whole two-worker parent launcher, synthetic qualifier and results; fixed owned-child supervisor previously qualified and frozen.',
        'Native source semantics, modified producer paths and all changes, runtime/build/native runner and both native qualifications as recorded in ROOT_NATIVE355_STATIC_REVIEW.json.'],
    'adoption_limits': ['Original source and actual transformed relation are checked separately.',
        'Raw graphs remain complete; original-source view requires full original ENV coverage, SYS/ONCE safety and strict/cooperative verification.',
        'Exact three-snapshot byte/structure parity is separate from semantic graph correctness.',
        'Saved V proof is checked; native negative and region are not independently certified as original K.',
        'No candidate-event causality, necessity, performance, random sampling or general reliability inference.'],
    'science_executed_before_this_authorization': False, 'full_reset_uses': 0}
save(B / 'ROOT_FINAL_PREPARATION_REVIEW.json', root_review)
go = {'schema': 'v48-native355-root-execution-go-v1',
    'status': 'GO_EXACT_355_NATIVE_TWO_JVMS_THREE_OUTPUTS', 'created_utc': now.isoformat(),
    'plan': pin(N / 'EXPERIMENT_PLAN.json'), 'freeze': freeze, 'build': pin(N / 'BUILD_RECEIPT.json'),
    'independent_static_reviews': [native_review], 'qualification_results': quals,
    'root_final_review': pin(B / 'ROOT_FINAL_PREPARATION_REVIEW.json'),
    'root_native_review': pin(B / 'ROOT_NATIVE355_STATIC_REVIEW.json'),
    'oracle_freeze': oracle_freeze, 'oracle_review': oracle_review,
    'launcher_freeze': launcher_freeze, 'launcher_review': launcher_review,
    'qualification_scope_correction': scope_correction,
    'original_model_reference': original_reference,
    'authorization_writer': pin(Path(__file__)),
    'selection': pin(B / 'SELECTION_AND_BOUNDED_RESEARCH_PROTOCOL.json'),
    'protected_v47': pin(B / 'V47_PROTECTED_INPUTS.json'),
    'start_authorized': True, 'oracle355_worker_budget': 1, 'oracle355_code': of['code'],
    'pair355_worker_budget': 1, 'pair355_code': pair_code,
    'science_hard_stop_utc': '2026-10-21T10:06:09+00:00',
    'attempts': {'paired_native_JVM': 1, 'normalized_native_JVM': 1, 'source_graph_worker': 1, 'pair_parity_worker': 1},
    'scope': 'Exact unchanged original355 only. No source, preference, native solver or model switch, no postoutcome retuning or retries. Separate exact manifest-bound ROOT_AUDIT_LAUNCH_GO required for worker launch.',
    'full_reset_uses': 0, 'conference_submission': False}
save(N / 'ROOT_EXECUTION_GO.json', go)
print(json.dumps({'status': go['status'], 'go': pin(N / 'ROOT_EXECUTION_GO.json')}))
