Fixed-seven native saved-data evidence

Run with Python 3.9 or later on a POSIX system:
  python3 -B replay.py --output ../replay-output
The output directory must not already exist and must be outside this payload.
No dependency installation, network access, JVM or native solver is required.
Each of seven saved-data workers has a 120-second wall cap and 1 GiB RSS cap.
The complete replay has a 1 GiB output cap. The first failure is preserved and
stops the remaining cases; the runner never retries.

Scope and selection
The fixed IDs are 039, 040, 041, 135, 148, 150 and 187. They were intentionally
selected from already successful symbolic inputs with I_M(K)=true and typed
carrier at most 65,536; old W=K and literal-model preservation were known.
This is a disclosed positive-control set, not a blind or random sample and not
evidence of an incidence, probability or general preservation rate. Exactly
14 scientific native arms (original then route for each case) were completed.
There are no UNKNOWN or unattempted scientific arms. There were no retries.

The helper is active on three GyroAspect variants from the same family. On the
other four inputs the released syntactic route skips; those are identity
controls, not four additional active transformations. The comparison uses
the exact helper=false source view only when helper exists. A skipped case
uses the whole route W and has helper-slice N/A. No helper was forced.

Exact results (carrier / old W = native original W = K = route source view):
039: 11,520 / 2,304; 040: 11,520 / 2,528; 041: 11,520 / 2,528;
135: 65,520 / 63,312; 148: 21,600 / 4,032; 150: 43,200 / 9,440;
187: 33,792 / 7,680. Every source-view loss, gain and K-intersect-loss is zero.
The three complete helper-arena W counts are 13,824, 14,048 and 14,048;
each includes 11,520 helper=true states. These are distinct from source-view W.
All four quantified initial checks (native original, native route, saved W,
saved K) are true. Legal ENV fibers are respectively 1, 1, 1, 60, 36, 36, 1024,
with zero missing fibers. Initialization is forall legal ENV initial values,
exists SYS including AUX satisfying thetaS and region membership. Source
initializers and monitor states were not reset or replaced.

What replay establishes
The byte-identical qualified independent_auditor.py checks typed field/AUX
and encoding bijections, full original predicates and ordered justices,
helper=false correspondence, helper initialization and persistence, exact
before/constructor/after-solve arena equality, saved raw/typed/source-view W,
all 198,672 source-typed state rows, old symbolic W/K memberships, differences,
and quantified initialization witnesses. Replayed audit objects and CSV bytes
must match the independent saved results exactly. It makes no reachability,
one-controller coverage, strategy construction, or deployment claim.

Portable qualification history
Attempt01 stopped on case039 at the portable wrapper's direct Python-object
comparison: integer bit-map keys returned by the unchanged core differed from
the string keys loaded from JSON. The already written audit JSON and typed CSV
were byte-identical to the independent originals; the remaining six cases were
not attempted. The first failure and its analysis are preserved in
provenance/attempt01/. Attempt02 compares the serialized saved audit JSON to the
serialized expectation and extends only location-metadata anonymization. The
qualified mathematical core remains byte-identical. The two attempts are
separate packaging qualifications and do not add scientific native observations.
An attempt02 pre-ZIP static scan also stopped before any replay because it
mistook the unchanged standard Python shebang for private origin metadata. The
exact first shebang line in the two Python files is the sole allowed portable
interpreter directive; absolute filesystem/runtime metadata paths remain
normalized or rejected. The preflight stop is retained separately.

This is saved-data replay. It does not independently regenerate native solves,
reparse source text, reproduce compiler correctness, or prove the correctness
of the original solver. The old symbolic certificate and native query share
the trusted source/parser-export arena and encoding provenance. The copied
models, exact source/import hashes, original/copy ledger and historical freeze
make those dependencies explicit. Full old/native provenance hashes remain
historical attestations; normalized JSON copies have their own manifest hashes.
External dependency locations are opaque metadata references, not files needed
for replay. No runtime, upstream JAR, compiled class, paper or main document is
included. The mathematical core has no changes; replay.py only supplies portable
I/O, binding checks, result comparison and resource supervision.

Source specifications/imports and BDD exports are byte-identical. Only declared
JSON location strings are anonymized. See ORIGINAL_COPY_LEDGER.json and the
independent package review for the original-to-copy binding boundary.
