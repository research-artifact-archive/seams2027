# Third-party notices

The included corpus specifications and DwyerPatterns imports are unchanged bytes
from Zenodo record 10553249, archive SHA-256
65abe41fcca3694a31967d409e642cb2b5785156aed5f464db380c7e3bb98712.
The exact established BSD 3-Clause corpus notice is retained unchanged in
licenses/zenodo10553249-LICENSE.txt (SHA-256
b5391db405b7121333f9e3b26ca4d29144aee3f3cd2a6e0bb41ac05e68a197ec).
Original source comments and attribution remain unchanged.

Original code, documentation and research outputs retain the unchanged
LICENSE-original.txt. No installed runtime, upstream JAR, class, native binary,
upstream Java source or third-party paper is distributed or relicensed here.
Saved exports and historical class hashes do not reproduce those dependencies.
