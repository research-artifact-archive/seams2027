import java.io.*;
import java.nio.file.*;
import java.util.*;
import com.google.gson.*;
import net.sf.javabdd.*;
import org.apache.log4j.Logger;
import tau.smlab.syntech.spectragameinput.SpectraInputProviderNoIDE;
import tau.smlab.syntech.gameinput.model.*;
import tau.smlab.syntech.gameinputtrans.TranslationProvider;
import tau.smlab.syntech.gameinputtrans.translator.DefaultTranslators;
import tau.smlab.syntech.bddgenerator.BDDGenerator;
import tau.smlab.syntech.bddgenerator.BDDGenerator.TraceInfo;
import tau.smlab.syntech.gamemodel.*;
import tau.smlab.syntech.jtlv.*;

/** Two frozen original-source exports only. No solver import, constructor or call.
 * The new input's sole switch declaration is projected to separate metadata;
 * the projection is byte-pinned before launch and no initialization is inserted.
 */
public final class PublishedUpdateExportOnly {
  static void need(boolean b,String message){ReleasedKindJobProducer.require(b,message);}
  static JsonObject read(Path p)throws Exception{return JsonParser.parseString(Files.readString(p)).getAsJsonObject();}
  public static void main(String[]args)throws Exception{
    if(args.length!=3)throw new IllegalArgumentException("case-config output-json origins");
    Path config=Paths.get(args[0]),out=Paths.get(args[1]),origins=Paths.get(args[2]);JsonObject c=read(config);
    String id=c.get("id").getAsString();need(id.equals("OBSTACLE_OLD")||id.equals("OBSTACLE_NEW"),"Only frozen published source pair");
    Path input=Paths.get(c.getAsJsonObject("source").get("path").getAsString());
    Files.createDirectories(out.toAbsolutePath().getParent());ReleasedKindJobProducer.receipt=out;ReleasedKindJobProducer.fixtureId=id+"__source_export";ReleasedKindJobProducer.caseId=id;ReleasedKindJobProducer.variant="source_export_only";
    ReleasedKindJobProducer.start=System.nanoTime();ReleasedKindJobProducer.startHeapSampler();
    ExactDiagnosticPrintStream capture=new ExactDiagnosticPrintStream(System.out,out.resolveSibling("EXACT_DIAGNOSTIC_RECEIPT.json"));
    Runtime.getRuntime().addShutdownHook(new Thread(()->{try{capture.finish();}catch(Exception e){e.printStackTrace(System.err);}},"published-export-lossless-capture"));System.setOut(capture);
    Map<String,Object> r=ReleasedKindJobProducer.out;r.put("schema","v71-published-source-export-only-v1");r.put("status","RUNNING");r.put("id",id);
    r.put("native_strict_solver_calls",0);r.put("solver_constructions",0);r.put("raw_four_fixed_point_calls",0);r.put("controller_extraction_calls",0);r.put("syntactic_reduction_calls",0);r.put("semantic_reduction_calls",0);r.put("source_initializers_changed",false);r.put("source_or_monitor_reset",false);r.put("extra_transition_restrictions",false);r.put("GUI_execution",false);
    r.put("source_projection",new Gson().fromJson(c.getAsJsonObject("projection_metadata"),Map.class));r.put("switch_metadata_inserted_as_initializer",false);
    Logger.getRootLogger().addAppender(new ReleasedKindJobProducer.ValidationLogWatch());GameModel gm=null;BDDFactory factory=null;int exit=0;
    try{
      ReleasedKindJobProducer.checkOrigins(origins);r.put("export_class",ReleasedKindJobProducer.identity(PublishedUpdateExportOnly.class));r.put("serializer_class",ReleasedKindJobProducer.identity(ReleasedKindJobProducer.class));r.put("capture_class",ReleasedKindJobProducer.identity(ExactDiagnosticPrintStream.class));
      String sha=ReleasedKindJobProducer.sha(Files.readAllBytes(input));need(sha.equals(c.getAsJsonObject("source").get("sha256").getAsString()),"Exact frozen projected source");r.put("input_sha256",sha);r.put("case_config_sha256",ReleasedKindJobProducer.sha(Files.readAllBytes(config)));
      ReleasedKindJobProducer.checkpoint("PARSE_FROZEN_SOURCE_PROJECTION");GameInput gi=new SpectraInputProviderNoIDE().getGameInput(input.toString());ReleasedKindJobProducer.validationHealthy();Object parsed=ReleasedKindJobProducer.inventory(gi);r.put("parsed_before_translation",parsed);
      Set<String> pe=new LinkedHashSet<>(Arrays.asList("obstacle[0]","obstacle[1]","obsWait")),ps=new LinkedHashSet<>(Arrays.asList("robot[0]","robot[1]"));
      r.put("source_array_element_binding","exact five names declared by frozen source equations, not inferred from output");
      TranslationProvider.translate(gi,DefaultTranslators.getDefaultTranslators());ReleasedKindJobProducer.validationHealthy();ReleasedKindJobProducer.auditTranslated(gi);Object translated=ReleasedKindJobProducer.inventory(gi);
      BDDPackage.setCurrPackage(BDDPackage.JTLV,BDDPackage.BBDPackageVersion.DEFAULT);Env.disableReorder();BDD one=Env.TRUE();factory=one.getFactory();one.free();r.put("observed_backend",ReleasedKindJobProducer.backend());
      ReleasedKindJobProducer.checkpoint("GENERATE_ORIGINAL_MODEL_ONLY");r.put("model_generations",1);gm=BDDGenerator.generateGameModel(gi,TraceInfo.NONE,false,PlayerModule.TransFuncType.SINGLE_FUNC);
      Map<String,Object> model=ReleasedKindJobProducer.modelExport(gm,pe,ps,parsed,translated,input);r.put("model_export",ReleasedKindJobProducer.writeJson("model.json",model));
      need(!Env.hasVars(gm.getEnv().trans(),gm.getSys().modulePrimeVars()),"ENV next-SYS independence");
      r.put("typed_domain_states",ReleasedKindJobProducer.carrierSize.toString());r.put("helper_introduced",Env.getVar("~envHelp")!=null);need(Env.getVar("~envHelp")==null,"Original export has no helper");
      r.put("independent_source_equation_binding","PENDING_EXTERNAL_AUDIT_NO_SOLVER_ADOPTION");
      ReleasedKindJobProducer.checkOrigins(origins);ReleasedKindJobProducer.validationHealthy();r.put("status","PASS_EXPORTED_SOURCE_MODEL");ReleasedKindJobProducer.checkpoint("SOURCE_EXPORT_DONE_NO_SOLVER");
    }catch(Throwable e){exit=2;r.put("status","UNKNOWN_EXPORT_EXCEPTION");r.put("failed_stage",ReleasedKindJobProducer.stage);r.put("exception",e.toString());StringWriter sw=new StringWriter();e.printStackTrace(new PrintWriter(sw));r.put("traceback",sw.toString());
    }finally{
      try{if(gm!=null)gm.free();if(factory!=null)factory.done();r.put("teardown","COMPLETED");}catch(Throwable e){exit=3;r.put("status","UNKNOWN_EXPORT_TEARDOWN");r.put("teardown_exception",e.toString());}
      if(ReleasedKindJobProducer.heapSampler!=null)ReleasedKindJobProducer.heapSampler.cancel();ReleasedKindJobProducer.checkpoint("PROCESS_FINISHED");
    }
    System.exit(exit);
  }
}
