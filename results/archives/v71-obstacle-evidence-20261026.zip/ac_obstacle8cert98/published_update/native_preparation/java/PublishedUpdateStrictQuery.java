import java.io.*;
import java.nio.file.*;
import java.util.*;
import com.google.gson.*;
import net.sf.javabdd.*;
import org.apache.log4j.Logger;
import tau.smlab.syntech.spectragameinput.SpectraInputProviderNoIDE;
import tau.smlab.syntech.gameinput.model.*;
import tau.smlab.syntech.gameinput.kind.PitermanSyntacticReduction;
import tau.smlab.syntech.gameinputtrans.TranslationProvider;
import tau.smlab.syntech.gameinputtrans.translator.DefaultTranslators;
import tau.smlab.syntech.bddgenerator.BDDGenerator;
import tau.smlab.syntech.bddgenerator.BDDGenerator.TraceInfo;
import tau.smlab.syntech.gamemodel.*;
import tau.smlab.syntech.gamemodel.util.PitermanSemanticReduction;
import tau.smlab.syntech.games.gr1.GR1Game;
import tau.smlab.syntech.jtlv.*;

/** Four frozen compiled arms; one strict solver call in a fresh process.
 * No target restriction, controller extraction, raw4FP or initializer reset.
 * Native constructor padding of empty justice lists is explicit and audited.
 * Every source field, including AUX, must bind before the sole solver call.
 */
public final class PublishedUpdateStrictQuery {
  static final String H="~envHelp";
  static final String[] META={"fields","public_fields","all_current_bits","all_next_bits","bdd_variable_count","bdd_variable_order"};
  static final Set<String> CASES=new LinkedHashSet<>(Arrays.asList("OBSTACLE_OLD","OBSTACLE_NEW"));
  static final Set<String> MODES=new LinkedHashSet<>(Arrays.asList("original","syntactic","first_flip","complete"));
  static void need(boolean ok,String label){ReleasedKindJobProducer.require(ok,label);}
  static JsonObject read(Path p)throws Exception{return JsonParser.parseString(Files.readString(p)).getAsJsonObject();}
  static JsonObject object(Object x){return JsonParser.parseString(ReleasedKindJobProducer.json(x)).getAsJsonObject();}
  static void equal(String label,BDD a,BDD b){
    boolean ok=a.equals(b);ReleasedKindJobProducer.out.put(label,ok);need(ok,"Correspondence: "+label);
  }
  static Map<String,JsonObject> fields(JsonObject m){
    Map<String,JsonObject> out=new LinkedHashMap<>();
    for(JsonElement e:m.getAsJsonArray("fields")){JsonObject f=e.getAsJsonObject();need(out.put(f.get("name").getAsString(),f)==null,"Unique field names");}
    return out;
  }
  static int integer(JsonElement e){return e.getAsInt();}
  static void validateFieldMetadata(JsonObject m){
    Set<Integer> all=new HashSet<>(),curr=new HashSet<>(),next=new HashSet<>();int n=m.get("bdd_variable_count").getAsInt();
    JsonArray order=m.getAsJsonArray("bdd_variable_order");need(order.size()==n,"Complete variable order");for(int i=0;i<n;i++)need(order.get(i).getAsInt()==i,"Natural variable order");
    for(JsonObject field:fields(m).values()){
      String owner=field.get("owner").getAsString(),role=field.get("role").getAsString();need((owner.equals("ENV")&&role.equals("ENV"))||(owner.equals("SYS")&&(role.equals("SYS")||role.equals("AUX"))),"Exact declared ownership/role");
      JsonArray values=field.getAsJsonArray("values");Set<String> names=new LinkedHashSet<>();for(JsonElement v:values)need(names.add(v.getAsString()),"Distinct field values");need(values.size()==field.get("domain_size").getAsInt(),"Complete value domain");
      need(field.getAsJsonObject("encoding").keySet().equals(names),"Every and only declared value encoded");
      List<String> codesCurrent=new ArrayList<>(),codesNext=new ArrayList<>();
      for(String phase:new String[]{"current","next"}){
        Set<String> keys=new LinkedHashSet<>();for(JsonElement e:field.getAsJsonArray(phase+"_bits")){int bit=e.getAsInt();need(bit>=0&&bit<n&&all.add(bit),"Each field bit has exactly one owner/phase");keys.add(String.valueOf(bit));(phase.equals("current")?curr:next).add(bit);}
        Set<String> codes=new HashSet<>();
        for(JsonElement value:values){JsonObject enc=field.getAsJsonObject("encoding").getAsJsonObject(value.getAsString()).getAsJsonObject(phase);need(enc.keySet().equals(keys),"Encoding covers exactly field bits");StringBuilder code=new StringBuilder();
          for(JsonElement bit:field.getAsJsonArray(phase+"_bits")){JsonElement v=enc.get(String.valueOf(bit.getAsInt()));need(v.isJsonPrimitive()&&v.getAsJsonPrimitive().isBoolean(),"Boolean encoding literal");code.append(v.getAsBoolean()?'1':'0');}
          need(codes.add(code.toString()),"Injective value encoding");(phase.equals("current")?codesCurrent:codesNext).add(code.toString());
        }
      }
      need(codesCurrent.equals(codesNext),"Current/next value codes agree");
    }
    need(all.size()==n,"All BDD bits covered");for(int i=0;i<n;i++)need(all.contains(i),"No undeclared bit");
    Set<Integer> declaredCurrent=new HashSet<>(),declaredNext=new HashSet<>();for(JsonElement x:m.getAsJsonArray("all_current_bits"))need(declaredCurrent.add(x.getAsInt()),"Distinct declared current bits");for(JsonElement x:m.getAsJsonArray("all_next_bits"))need(declaredNext.add(x.getAsInt()),"Distinct declared next bits");need(curr.equals(declaredCurrent)&&next.equals(declaredNext),"Declared field bit unions exact");
  }

  /** Maps all source bits by exact field name and value encoding, including AUX.
   * No name heuristics, changed monitor rosters, or partial field projection.
   */
  static Map<Integer,Integer> fullBitMap(JsonObject old,JsonObject fresh,boolean helper){
    validateFieldMetadata(old);validateFieldMetadata(fresh);
    Map<String,JsonObject>a=fields(old),b=fields(fresh);
    need(!a.containsKey(H),"Original model has no helper");
    Set<String> expected=new LinkedHashSet<>(a.keySet());if(helper)expected.add(H);
    need(b.keySet().equals(expected),"Exactly source fields plus actual helper; AUX names preserved");
    if(helper){JsonObject h=b.get(H);need(h.get("owner").getAsString().equals("ENV")&&h.get("role").getAsString().equals("ENV"),"Helper ENV ownership");need(h.get("domain_size").getAsInt()==2&&h.getAsJsonArray("values").toString().equals("[\"false\",\"true\"]"),"Boolean helper domain");for(String phase:new String[]{"current","next"}){need(h.getAsJsonArray(phase+"_bits").size()==1,"One bit per helper phase");String bit=h.getAsJsonArray(phase+"_bits").get(0).getAsString();need(!h.getAsJsonObject("encoding").getAsJsonObject("false").getAsJsonObject(phase).get(bit).getAsBoolean()&&h.getAsJsonObject("encoding").getAsJsonObject("true").getAsJsonObject(phase).get(bit).getAsBoolean(),"Helper false/true codes 0/1");}}
    Map<Integer,Integer> map=new LinkedHashMap<>();Set<Integer> targets=new HashSet<>();
    for(String name:a.keySet()){
      JsonObject x=a.get(name),y=b.get(name);
      for(String k:new String[]{"owner","role","domain_size","values"})need(x.get(k).equals(y.get(k)),"Field metadata "+name+"/"+k);
      for(String phase:new String[]{"current","next"}){
        JsonArray xb=x.getAsJsonArray(phase+"_bits"),yb=y.getAsJsonArray(phase+"_bits");need(xb.size()==yb.size(),"Field bit width "+name);
        for(int j=0;j<xb.size();j++){
          int u=integer(xb.get(j)),v=integer(yb.get(j));need(map.put(u,v)==null&&targets.add(v),"Full injective bit map");
          for(JsonElement value:x.getAsJsonArray("values")){
            String val=value.getAsString();JsonObject xe=x.getAsJsonObject("encoding").getAsJsonObject(val).getAsJsonObject(phase),ye=y.getAsJsonObject("encoding").getAsJsonObject(val).getAsJsonObject(phase);
            need(xe.get(String.valueOf(u)).equals(ye.get(String.valueOf(v))),"Value encoding "+name+"/"+val+"/"+phase);
          }
        }
      }
    }
    need(map.size()==old.get("bdd_variable_count").getAsInt(),"Every old bit mapped");
    for(int i=0;i<map.size();i++)need(map.containsKey(i),"No unmapped old bit");
    need(fresh.get("bdd_variable_count").getAsInt()==map.size()+(helper?2:0),"No undeclared fresh bits");
    ReleasedKindJobProducer.out.put("source_to_actual_bit_map",map);return map;
  }

  /** Read the prior pinned node-table into the current manager under a bit map.
   * ITE permits non-monotone renaming; raw node IDs are never reused as functions.
   */
  static BDD mapped(JsonObject ref,Path directory,Map<Integer,Integer> map,BDDFactory f)throws Exception{
    Path p=directory.resolve(ref.get("file").getAsString());byte[] data=Files.readAllBytes(p);
    need(data.length==ref.get("bytes").getAsLong()&&ReleasedKindJobProducer.sha(data).equals(ref.get("sha256").getAsString()),"Saved predicate hash "+p.getFileName());
    List<int[]> lines=new ArrayList<>();
    for(String line:new String(data,java.nio.charset.StandardCharsets.US_ASCII).split("\\R"))if(!line.trim().isEmpty())lines.add(Arrays.stream(line.trim().split("\\s+")).mapToInt(Integer::parseInt).toArray());
    if(lines.size()==1){int[]c=lines.get(0);need(c.length==2&&c[0]==0&&(c[1]==0||c[1]==1)&&ref.get("node_count").getAsInt()==0,"Saved constant syntax");return c[1]==0?f.zero():f.one();}
    need(lines.size()>=3&&lines.get(0).length==1&&lines.get(0)[0]==map.size(),"Saved BDD variable count");
    int[]order=lines.get(1);need(order.length==map.size(),"Saved BDD order width");for(int i=0;i<order.length;i++)need(order[i]==i,"Saved natural order");
    need(lines.size()-2==ref.get("node_count").getAsInt(),"Saved BDD node count");
    Map<Integer,BDD> nodes=new LinkedHashMap<>();nodes.put(0,f.zero());nodes.put(1,f.one());int last=-1;
    try{
      for(int k=2;k<lines.size();k++){
        int[]r=lines.get(k);need(r.length==4&&r[0]>1&&!nodes.containsKey(r[0])&&map.containsKey(r[1])&&nodes.containsKey(r[2])&&nodes.containsKey(r[3]),"Saved node table topology");
        BDD bit=f.ithVar(map.get(r[1]));BDD n=bit.ite(nodes.get(r[3]),nodes.get(r[2]));bit.free();nodes.put(r[0],n);last=r[0];
      }
      need(last>1,"Saved root exists");return nodes.get(last).id();
    }finally{for(BDD b:nodes.values())b.free();}
  }

  static void compareMapped(String label,BDD actual,JsonObject ref,Path dir,Map<Integer,Integer> map,BDD restrict,BDD typedMask)throws Exception{
    BDD expected=mapped(ref,dir,map,actual.getFactory());BDD view=restrict==null?actual.id():actual.restrict(restrict);
    try{ReleasedKindJobProducer.out.put(label+"_raw_boolean_equal",view.equals(expected));BDD a=view.and(typedMask),b=expected.and(typedMask);try{equal(label,a,b);}finally{a.free();b.free();}}finally{view.free();expected.free();}
  }
  static Map<String,BDD> fullFunctions(GameModel gm){
    Map<String,BDD> a=new LinkedHashMap<>();a.put("thetaE",gm.getEnv().initial());a.put("thetaS",gm.getSys().initial());a.put("rhoE",gm.getEnv().trans());a.put("rhoS",gm.getSys().trans());
    for(int i=0;i<gm.getEnv().justiceNum();i++)a.put("ENV_justice_"+i,gm.getEnv().justiceAt(i));
    for(int i=0;i<gm.getSys().justiceNum();i++)a.put("SYS_justice_"+i,gm.getSys().justiceAt(i));return a;
  }
  static Map<String,Object> unchangedFull(GameModel gm,Map<String,BDD> baseline,String prefix)throws Exception{
    Map<String,BDD> actual=fullFunctions(gm);need(actual.keySet().equals(baseline.keySet()),"Full ordered function roster unchanged");Map<String,Object> refs=new LinkedHashMap<>();
    for(String k:actual.keySet()){equal(prefix+"_full_"+k,actual.get(k),baseline.get(k));refs.put(k,ReleasedKindJobProducer.snapshot(prefix+"_full_"+k,actual.get(k)));}return refs;
  }
  static void gate(GameModel gm,JsonObject old,JsonObject fresh,Path dir,boolean helper,String prefix,boolean normalized)throws Exception{
    Map<Integer,Integer> map=fullBitMap(old,fresh,helper);
    if(!helper)for(String key:META)need(old.get(key).equals(fresh.get(key)),"Exact original/skip metadata "+key);
    BDD h0=helper?Env.getBDDValue(H,"false").id():null;
    BDD h00=null;if(helper){BDD p0=Env.prime(h0);h00=h0.and(p0);p0.free();}
    JsonObject refs=old.getAsJsonObject("original_bdds");
    BDD currentFull=ReleasedKindJobProducer.domain(gm.getEnv(),false).andWith(ReleasedKindJobProducer.domain(gm.getSys(),false));
    BDD edgeFull=currentFull.id();edgeFull.andWith(ReleasedKindJobProducer.domain(gm.getEnv(),true));edgeFull.andWith(ReleasedKindJobProducer.domain(gm.getSys(),true));
    BDD typedCurrent=helper?currentFull.restrict(h0):currentFull.id(),typedEdge=helper?edgeFull.restrict(h00):edgeFull.id();currentFull.free();edgeFull.free();
    try{
      compareMapped(prefix+"thetaE",gm.getEnv().initial(),refs.getAsJsonObject("thetaE"),dir,map,h0,typedCurrent);
      compareMapped(prefix+"thetaS",gm.getSys().initial(),refs.getAsJsonObject("thetaS"),dir,map,h0,typedCurrent);
      compareMapped(prefix+"rhoE_00",gm.getEnv().trans(),refs.getAsJsonObject("rhoE"),dir,map,h00,typedEdge);
      compareMapped(prefix+"rhoS_00",gm.getSys().trans(),refs.getAsJsonObject("rhoS"),dir,map,h00,typedEdge);
      BDD d=ReleasedKindJobProducer.domain(gm.getEnv(),false).andWith(ReleasedKindJobProducer.domain(gm.getSys(),false));
      BDD en=ReleasedKindJobProducer.domain(gm.getEnv(),true),sn=ReleasedKindJobProducer.domain(gm.getSys(),true);
      try{
        compareMapped(prefix+"domain",d,refs.getAsJsonObject("domain"),dir,map,h0,typedCurrent);
        compareMapped(prefix+"domain_ENV_next",en,refs.getAsJsonObject("domain_ENV_next"),dir,map,h00,typedEdge);
        compareMapped(prefix+"domain_SYS_next",sn,refs.getAsJsonObject("domain_SYS_next"),dir,map,h00,typedEdge);
      }finally{d.free();en.free();sn.free();}
      JsonObject just=old.getAsJsonObject("original_justices");JsonArray ej=just.getAsJsonArray("ENV"),sj=just.getAsJsonArray("SYS");
      int expectedE=ej.size()+(helper?1:0),expectedS=sj.size();
      boolean paddedE=normalized&&expectedE==0,paddedS=normalized&&expectedS==0;
      need(gm.getEnv().justiceNum()==(paddedE?1:expectedE)&&gm.getSys().justiceNum()==(paddedS?1:expectedS),"Complete ordered justice counts with explicit constructor-only TRUE padding");
      if(paddedE)need(gm.getEnv().justiceAt(0).isOne(),"Empty ENV justice padded only TRUE");
      if(paddedS)need(gm.getSys().justiceAt(0).isOne(),"Empty SYS justice padded only TRUE");
      int added=-1;
      if(helper){
        BDD h1init=Env.getBDDValue(H,"true").id(),illegalInit=gm.getEnv().initial().restrict(h1init);need(illegalInit.isZero(),"ENV initializer forbids helper=true");h1init.free();illegalInit.free();
        for(int i=0;i<gm.getEnv().justiceNum();i++)if(gm.getEnv().justiceAt(i).equals(h0)){need(added<0,"Unique added helper justice");added=i;}
        need(added>=0,"Added justice is exactly !helper");ReleasedKindJobProducer.out.put("added_helper_justice_index",added);
        BDD h1=Env.getBDDValue(H,"true").id(),p0=Env.prime(h0),edge=h1.and(p0),reverse=gm.getEnv().trans().restrict(edge);
        need(reverse.isZero(),"One-way helper: E10 false");h1.free();p0.free();edge.free();reverse.free();
      }
      for(int i=0,j=0;i<gm.getEnv().justiceNum();i++)if(i!=added&&!paddedE)compareMapped(prefix+"ENV_justice_"+(j),gm.getEnv().justiceAt(i),ej.get(j++).getAsJsonObject(),dir,map,h0,typedCurrent);
      for(int i=0;i<sj.size();i++)compareMapped(prefix+"SYS_justice_"+i,gm.getSys().justiceAt(i),sj.get(i).getAsJsonObject(),dir,map,h0,typedCurrent);
    }finally{typedCurrent.free();typedEdge.free();if(h00!=null)h00.free();if(h0!=null)h0.free();}
  }

  static Map<String,Object> exportAt(GameModel gm,Set<String>pe,Set<String>ps,Object parsed,Object translated,Path input,String directory)throws Exception{
    Path previous=ReleasedKindJobProducer.receipt;
    Path folder=previous.getParent().resolve(directory);Files.createDirectories(folder);
    try{
      ReleasedKindJobProducer.receipt=folder.resolve("RESULT.json");
      Map<String,Object> model=ReleasedKindJobProducer.modelExport(gm,pe,ps,parsed,translated,input);
      Map<String,Object> result=new LinkedHashMap<>();result.put("directory",directory);result.put("model",ReleasedKindJobProducer.writeJson("model.json",model));return result;
    }finally{ReleasedKindJobProducer.receipt=previous;}
  }

  /** The intervention changes only valid typed 0->1 SYS transitions. */
  static void applyFirstFlip(GameModel gm)throws Exception{
    need(Env.getVar(H)!=null,"First-flip intervention requires actual syntactic helper");
    BDD h0=Env.getBDDValue(H,"false").id(),h1=Env.getBDDValue(H,"true").id(),hp1=Env.prime(h1);
    BDD release=h0.and(hp1);
    release.andWith(ReleasedKindJobProducer.domain(gm.getEnv(),false));
    release.andWith(ReleasedKindJobProducer.domain(gm.getSys(),false));
    release.andWith(ReleasedKindJobProducer.domain(gm.getEnv(),true));
    release.andWith(ReleasedKindJobProducer.domain(gm.getSys(),true));
    ReleasedKindJobProducer.out.put("first_flip_release_predicate",ReleasedKindJobProducer.snapshot("first_flip_release_predicate",release));
    gm.getSys().trans().orWith(release);h0.free();h1.free();hp1.free();
    ReleasedKindJobProducer.out.put("first_flip_release_calls",1);
  }

  static Map<String,Object> quadrants(GameModel gm,boolean helper)throws Exception{
    Map<String,Object> result=new LinkedHashMap<>();if(!helper)return result;
    for(int h=0;h<2;h++)for(int p=0;p<2;p++){
      String key=""+h+p;BDD current=Env.getBDDValue(H,h==0?"false":"true").id();
      BDD next=Env.prime(Env.getBDDValue(H,p==0?"false":"true")),cube=current.and(next);
      BDD e=gm.getEnv().trans().restrict(cube),s=gm.getSys().trans().restrict(cube);
      Map<String,Object> row=new LinkedHashMap<>();row.put("rhoE",ReleasedKindJobProducer.snapshot("quadrant_"+key+"_rhoE",e));row.put("rhoS",ReleasedKindJobProducer.snapshot("quadrant_"+key+"_rhoS",s));result.put(key,row);
      current.free();next.free();cube.free();e.free();s.free();
    }return result;
  }

  /** GR1Game may append precisely one TRUE justice only to an empty owner list.
   * Preserve the raw pre-constructor snapshot and update the post-constructor
   * comparison baseline only after this exact permitted mutation is checked.
   */
  static Map<String,Object> acceptConstructorPadding(GameModel gm,Map<String,BDD> baseline)throws Exception{
    Map<String,BDD> actual=fullFunctions(gm);Set<String> expected=new LinkedHashSet<>(baseline.keySet());
    Map<String,Object> record=new LinkedHashMap<>();
    for(String owner:new String[]{"ENV","SYS"}){
      String prefix=owner+"_justice_";int before=0;for(String key:baseline.keySet())if(key.startsWith(prefix))before++;
      PlayerModule module=owner.equals("ENV")?gm.getEnv():gm.getSys();int after=module.justiceNum();boolean padded=before==0;
      need(after==(padded?1:before),"Constructor justice count only empty-list TRUE padding");
      if(padded){need(module.justiceAt(0).isOne(),"Constructor empty justice adds only TRUE");expected.add(prefix+"0");}
      Map<String,Object> row=new LinkedHashMap<>();row.put("before_count",before);row.put("after_count",after);row.put("added_true",padded);record.put(owner,row);
    }
    need(actual.keySet().equals(expected),"Constructor exact function roster including explicit TRUE padding");
    for(String key:baseline.keySet())equal("constructor_preserved_"+key,actual.get(key),baseline.get(key));
    for(String key:expected)if(!baseline.containsKey(key))baseline.put(key,actual.get(key).id());
    return record;
  }

  public static void main(String[]args)throws Exception{
    if(args.length!=4)throw new IllegalArgumentException("case-config mode output-json origins");
    Path config=Paths.get(args[0]),out=Paths.get(args[2]),origins=Paths.get(args[3]);JsonObject c=read(config);
    String id=c.get("id").getAsString(),mode=args[1];boolean qualification=false;
    need(CASES.contains(id),"Frozen published old/new source identity");need(MODES.contains(mode),"Only fixed four arms");
    need(qualification==(c.has("qualification_only")&&c.get("qualification_only").getAsBoolean()),"Qualification/corpus scope cannot be relabeled");
    boolean route=mode.equals("syntactic")||mode.equals("first_flip");boolean expectedHelper=route&&c.get("expected_helper_introduced_on_route").getAsBoolean();
    Path input=Paths.get(c.getAsJsonObject("source").get("path").getAsString()),saved=Paths.get(c.get("saved_original_directory").getAsString());
    Files.createDirectories(out.toAbsolutePath().getParent());ReleasedKindJobProducer.receipt=out;ReleasedKindJobProducer.fixtureId=id+"__"+mode;ReleasedKindJobProducer.caseId=id;ReleasedKindJobProducer.variant=mode;
    ReleasedKindJobProducer.start=System.nanoTime();ReleasedKindJobProducer.startHeapSampler();
    ExactDiagnosticPrintStream capture=new ExactDiagnosticPrintStream(System.out,out.resolveSibling("EXACT_DIAGNOSTIC_RECEIPT.json"));
    Runtime.getRuntime().addShutdownHook(new Thread(()->{try{capture.finish();}catch(Exception e){e.printStackTrace(System.err);}},"compiled-cohort-lossless-capture"));System.setOut(capture);
    Map<String,Object>r=ReleasedKindJobProducer.out;r.put("schema","v71-published-update-full-native-strict-v1");r.put("status","RUNNING");r.put("id",id);r.put("mode",mode);r.put("qualification_only",qualification);
    r.put("prior_binding_scope","FRESH_EXPORT_REQUIRES_INDEPENDENT_SOURCE_EQUATION_BINDING");
    r.put("native_strict_solver_calls",0);r.put("controller_extraction_calls",0);r.put("raw_four_fixed_point_calls",0);r.put("extra_transition_restrictions",false);r.put("source_initializers_changed",false);r.put("source_or_monitor_reset",false);r.put("GUI_execution",false);
    r.put("query_scope","Full declared arm arena; no retained-state or layout restriction; helper=false and typed winning masks are post-solve views");r.put("intervention",mode.equals("first_flip")?"typed_SYS01_release_only":mode.equals("complete")?"released_posttranslation_semantic_reduction":"none");
    Logger.getRootLogger().addAppender(new ReleasedKindJobProducer.ValidationLogWatch());GameModel gm=null;GR1Game game=null;BDDFactory factory=null;int exit=0;Map<String,BDD> fullBaseline=new LinkedHashMap<>();
    try{
      ReleasedKindJobProducer.checkOrigins(origins);r.put("query_class",ReleasedKindJobProducer.identity(PublishedUpdateStrictQuery.class));r.put("strict_solver_class",ReleasedKindJobProducer.identity(GR1Game.class));r.put("semantic_reduction_class",ReleasedKindJobProducer.identity(PitermanSemanticReduction.class));need(PitermanSemanticReduction.class.getProtectionDomain().getCodeSource().getLocation().equals(GameModel.class.getProtectionDomain().getCodeSource().getLocation()),"Semantic reduction exact gamemodel bundle");r.put("serializer_class",ReleasedKindJobProducer.identity(ReleasedKindJobProducer.class));r.put("capture_class",ReleasedKindJobProducer.identity(ExactDiagnosticPrintStream.class));
      String sha=ReleasedKindJobProducer.sha(Files.readAllBytes(input));r.put("input_sha256",sha);need(sha.equals(c.getAsJsonObject("source").get("sha256").getAsString()),"Exact frozen source");
      r.put("case_config_sha256",ReleasedKindJobProducer.sha(Files.readAllBytes(config)));ReleasedKindJobProducer.checkpoint("PARSE_UNCHANGED_SOURCE");
      GameInput gi=new SpectraInputProviderNoIDE().getGameInput(input.toString());ReleasedKindJobProducer.validationHealthy();Object parsed=ReleasedKindJobProducer.inventory(gi);r.put("parsed_before_reduction",parsed);
      Set<String>pe=new LinkedHashSet<>(),ps=new LinkedHashSet<>();for(Variable v:gi.getEnv().getVars())pe.add(v.getName());for(Variable v:gi.getSys().getVars())ps.add(v.getName());need(!pe.contains(H)&&!ps.contains(H),"No source helper");
      pe=new LinkedHashSet<>(Arrays.asList("obstacle[0]","obstacle[1]","obsWait"));ps=new LinkedHashSet<>(Arrays.asList("robot[0]","robot[1]"));r.put("source_array_element_binding","exact frozen source names; no heuristic alias or projection");
      boolean activation=gi.getEnv().getConstraints().stream().anyMatch(x->x.getKind()==Constraint.Kind.SAFETY||x.getKind()==Constraint.Kind.STATE_INV);
      need(activation==c.get("expected_helper_introduced_on_route").getAsBoolean(),"Parsed activation matches frozen pre-source inventory");
      if(route)PitermanSyntacticReduction.doReduction(gi);r.put("syntactic_reduction_calls",route?1:0);r.put("semantic_reduction_calls",0);r.put("first_flip_release_calls",0);r.put("parsed_after_reduction",ReleasedKindJobProducer.inventory(gi));
      boolean afterHelper=gi.getEnv().getVars().stream().anyMatch(v->v.getName().equals(H));need(afterHelper==expectedHelper,"Actual parsed helper introduction/skip");
      TranslationProvider.translate(gi,DefaultTranslators.getDefaultTranslators());ReleasedKindJobProducer.validationHealthy();Object translated=ReleasedKindJobProducer.inventory(gi);ReleasedKindJobProducer.auditTranslated(gi);
      BDDPackage.setCurrPackage(BDDPackage.JTLV,BDDPackage.BBDPackageVersion.DEFAULT);Env.disableReorder();BDD one=Env.TRUE();factory=one.getFactory();one.free();r.put("observed_backend",ReleasedKindJobProducer.backend());
      gm=BDDGenerator.generateGameModel(gi,TraceInfo.NONE,false,PlayerModule.TransFuncType.SINGLE_FUNC);
      if(mode.equals("first_flip")||mode.equals("complete")){
        Set<String>beforePe=new LinkedHashSet<>(pe);if(Env.getVar(H)!=null)beforePe.add(H);
        r.put("intervention_before_model",exportAt(gm,beforePe,ps,parsed,translated,input,"pre_intervention"));
        if(mode.equals("first_flip"))applyFirstFlip(gm);
        else {boolean semanticSkip=gm.getEnv().trans().isOne();r.put("semantic_skip_precondition",semanticSkip);expectedHelper=!semanticSkip;PitermanSemanticReduction.doReduction(gm);r.put("semantic_reduction_calls",1);}
      }
      boolean helper=Env.getVar(H)!=null;need(helper==expectedHelper,"Exported helper matches declared reduction behavior");if(helper)pe.add(H);
      Map<String,Object>export=ReleasedKindJobProducer.modelExport(gm,pe,ps,parsed,translated,input);r.put("model_export",ReleasedKindJobProducer.writeJson("model.json",export));JsonObject fresh=object(export),old=read(saved.resolve("model.json"));
      need(old.getAsJsonObject("input").get("sha256").getAsString().equals(sha),"Prior certified model source identity");need(!Env.hasVars(gm.getEnv().trans(),gm.getSys().modulePrimeVars()),"ENV next-SYS independence");
      r.put("helper_quadrants",quadrants(gm,helper));r.put("helper_introduced",helper);r.put("conversion_skipped",(route||mode.equals("complete"))&&!helper);r.put("complete_semantic_identity_skip",mode.equals("complete")&&!helper);r.put("helper_false_slice",helper?"PRESENT":"N/A");r.put("typed_domain_states",ReleasedKindJobProducer.carrierSize.toString());
      gate(gm,old,fresh,saved,helper,"pre_",false);
      for(Map.Entry<String,BDD> e:fullFunctions(gm).entrySet())fullBaseline.put(e.getKey(),e.getValue().id());
      r.put("full_model_before_constructor",unchangedFull(gm,fullBaseline,"before_constructor"));
      r.put("solver_rhoE",ReleasedKindJobProducer.snapshot("solver_rhoE",gm.getEnv().trans()));r.put("solver_rhoS",ReleasedKindJobProducer.snapshot("solver_rhoS",gm.getSys().trans()));
      ReleasedKindJobProducer.checkpoint("CONSTRUCT_UNCHANGED_GR1GAME");game=new GR1Game(gm);r.put("constructor_justice_normalization",acceptConstructorPadding(gm,fullBaseline));r.put("full_model_after_constructor",unchangedFull(gm,fullBaseline,"after_constructor"));gate(gm,old,fresh,saved,helper,"postconstructor_",true);r.put("all_prequery_gates_pass",true);r.put("native_strict_solver_calls",1);
      ReleasedKindJobProducer.checkpoint("NATIVE_STRICT_THREE_FIXED_POINT_FULL_ARENA");boolean init=game.checkRealizability();BDD w=game.sysWinningStates();need(game.getMem().isComplete(),"Complete native memory");ReleasedKindJobProducer.currentOnly("Full W",w);
      BDD d=ReleasedKindJobProducer.domain(gm.getEnv(),false).andWith(ReleasedKindJobProducer.domain(gm.getSys(),false)),wt=w.and(d),view=helper?wt.restrict(Env.getBDDValue(H,"false")):wt.id();
      r.put("actual_initializer_realizable",init);r.put("strict_memory_complete",true);r.put("winning_region_raw",ReleasedKindJobProducer.snapshot("native_strict_W_raw",w));r.put("winning_region_typed",ReleasedKindJobProducer.snapshot("native_strict_W_typed",wt));r.put("winning_region_source_view",ReleasedKindJobProducer.snapshot("native_strict_W_source_view",view));view.free();wt.free();d.free();
      r.put("full_model_after_solve",unchangedFull(gm,fullBaseline,"after_solve"));gate(gm,old,fresh,saved,helper,"postsolve_",true);ReleasedKindJobProducer.checkOrigins(origins);ReleasedKindJobProducer.validationHealthy();r.put("status","PASS_COMPLETE");ReleasedKindJobProducer.checkpoint("DONE");
    }catch(Throwable e){exit=2;r.put("failed_stage",ReleasedKindJobProducer.stage);r.put("status",e instanceof ReleasedKindJobProducer.InvariantMismatch?"UNKNOWN_CORRESPONDENCE":"UNKNOWN_NATIVE_EXCEPTION");r.put("exception",e.toString());StringWriter sw=new StringWriter();e.printStackTrace(new PrintWriter(sw));r.put("traceback",sw.toString());
    }finally{
      try{for(BDD x:fullBaseline.values())x.free();if(game!=null)game.free();if(gm!=null)gm.free();if(factory!=null)factory.done();r.put("teardown","COMPLETED");}catch(Throwable e){r.put("teardown_exception",e.toString());r.put("teardown","FAILED");r.put("status","UNKNOWN_TEARDOWN_EXCEPTION");exit=3;}
      if(ReleasedKindJobProducer.heapSampler!=null)ReleasedKindJobProducer.heapSampler.cancel();ReleasedKindJobProducer.checkpoint("PROCESS_FINISHED");
    }
    System.exit(exit);
  }
}
