#!/usr/bin/env python3
"""Independent equations for the exact published obstacle update. No compiler inputs."""
from __future__ import annotations
import argparse
from collections import deque
from dataclasses import dataclass
import gzip
import hashlib
import itertools
import json
from pathlib import Path
import time

HERE = Path(__file__).resolve().parent
O71 = HERE.parent.parent
PROV = O71 / 'positioning' / 'provenance_sources'
SOURCES = PROV / 'Specifications' / 'Obstacle Evasion'
PINS = {'old': ('MovingObstacleEvasion.spectra', '19c71d970b05fec41f0fa60fce155bf136b33836ffd785a65c2c436a712c3ac1'),
        'new': ('MovingObstacleEvasionUpdate.spectra', 'bf2836d68e9a7b019b8f2c9499ccf1ad8dccdc56f5c31ff78ea7d80e45b1a228')}
ROSTER_SHA = 'bcbccc0fa89e3da07b756c9d954ce74df4a79c59db8f2bf0937af29d7885d8ad'
N = 6272
FORBIDDEN = {'old': {(3, 5), (4, 5)}, 'new': {(6, 4), (8, 7)}}
GOALS = {'old': ((5, 2), (2, 3)), 'new': ((3, 7), (4, 8))}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def verify_pins():
    for name, expected in PINS.values():
        assert sha(SOURCES / name) == expected, name
    assert sha(PROV / 'OBSTACLE_BOUNDARY_ALL98_FROZEN.json') == ROSTER_SHA


def state_id(s):
    ox, oy, w, rx, ry = s
    assert 1 <= ox <= 7 and 1 <= oy <= 7 and w in (False, True)
    assert 1 <= rx <= 8 and 1 <= ry <= 8
    return (((ox - 1) * 7 + oy - 1) * 2 + int(w)) * 64 + (rx - 1) * 8 + ry - 1


def state(i):
    assert 0 <= i < N
    a, ry0 = divmod(i, 8)
    a, rx0 = divmod(a, 8)
    a, w = divmod(a, 2)
    ox0, oy0 = divmod(a, 7)
    return (ox0 + 1, oy0 + 1, bool(w), rx0 + 1, ry0 + 1)


def typed_state(s):
    ox, oy, w, rx, ry = s
    return 1 <= ox <= 7 and 1 <= oy <= 7 and w in (False, True) and 1 <= rx <= 8 and 1 <= ry <= 8


def outside(rx, ry, ox, oy):
    # Exact four source conjuncts; current robot, specified obstacle.
    return ((rx != ox or ry != oy) and (rx != ox + 1 or ry != oy)
            and (rx != ox or ry != oy + 1) and (rx != ox + 1 or ry != oy + 1))


def env_legal(s, e):
    ox, oy, w, rx, ry = s
    nx, ny, nw = e
    if not (1 <= nx <= 7 and 1 <= ny <= 7 and nw in (False, True)):
        return False
    if nw == w or abs(nx - ox) > 1 or abs(ny - oy) > 1:
        return False
    if w:
        return nx == ox and ny == oy
    return ((ox <= rx or nx == ox - 1) and (ox >= rx - 1 or nx == ox + 1)
            and (oy <= ry or ny == oy - 1) and (oy >= ry - 1 or ny == oy + 1))


def sys_safe(s, e, output, variant):
    ox, oy, w, rx, ry = s
    nx, ny, nw = e
    nrx, nry = output
    return (1 <= nrx <= 8 and 1 <= nry <= 8
            and abs(nrx - rx) <= 1 and abs(nry - ry) <= 1
            and outside(rx, ry, nx, ny) and outside(rx, ry, ox, oy)
            and (rx, ry) not in FORBIDDEN[variant])


def env_options(s):
    ox, oy, w, _, _ = s
    return [e for e in itertools.product(range(max(1, ox - 1), min(7, ox + 1) + 1),
                                          range(max(1, oy - 1), min(7, oy + 1) + 1),
                                          (not w,)) if env_legal(s, e)]


def output_options(s):
    rx, ry = s[3:]
    return list(itertools.product(range(max(1, rx - 1), min(8, rx + 1) + 1),
                                  range(max(1, ry - 1), min(8, ry + 1) + 1)))


def ids(mask):
    while mask:
        low = mask & -mask
        yield low.bit_length() - 1
        mask ^= low


def mask_of(values):
    value = 0
    for i in values:
        value |= 1 << i
    return value


@dataclass
class Game:
    blocks: list[tuple[int, ...]]  # each block is one ENV move's safe SYS successors
    inputs: list[tuple[tuple, ...]] | None = None
    variant: str | None = None

    @property
    def n(self):
        return len(self.blocks)

    def pre(self, target):
        ans = 0
        for i, blocks in enumerate(self.blocks):
            if all(block & target for block in blocks):
                ans |= 1 << i
        return ans


def build_game(variant):
    blocks, inputs = [], []
    e_count = edge_count = dead_blocks = 0
    total = True
    for i in range(N):
        s = state(i)
        es = env_options(s)
        total &= bool(es)
        bs = []
        for e in es:
            b = mask_of(state_id((*e, *o)) for o in output_options(s) if sys_safe(s, e, o, variant))
            bs.append(b)
            e_count += 1
            edge_count += b.bit_count()
            dead_blocks += not bool(b)
        inputs.append(tuple(es))
        blocks.append(tuple(bs))
    assert total, 'Source ENV totality failed; do not infer W=K.'
    return Game(blocks, inputs, variant), {'typed_states': N, 'env_total': total,
          'legal_env_blocks': e_count, 'safe_edges': edge_count, 'zero_response_legal_env_blocks': dead_blocks}


def attractor(game, within, goal):
    # Least fixed point inside within. A target state must still have a next response.
    target = within & goal & game.pre(within)
    reached = 0
    rounds = 0
    while True:
        nxt = target | (within & game.pre(reached))
        rounds += 1
        if nxt == reached:
            return reached, rounds
        assert reached & ~nxt == 0
        reached = nxt


def generalized_buchi(game, goals):
    z = (1 << game.n) - 1
    outer = 0
    log = []
    while True:
        out = z
        per_goal = []
        for goal in goals:
            attr, rounds = attractor(game, z, goal)
            out &= attr
            per_goal.append(rounds)
        outer += 1
        log.append({'outer': outer, 'before': z.bit_count(), 'after': out.bit_count(), 'attractor_rounds': per_goal})
        assert out & ~z == 0
        if out == z:
            return z, log
        z = out


def two_phase_buchi_check(game, goals):
    assert len(goals) == 2
    n = game.n
    prod = []
    for phase in (0, 1):
        for s, blocks in enumerate(game.blocks):
            following = 1 - phase if (goals[phase] >> s) & 1 else phase
            prod.append(tuple(block << (following * n) for block in blocks))
    # Acceptance marks completion of the second outstanding goal, not merely phase zero.
    accept = goals[1] << n
    win, log = generalized_buchi(Game(prod), [accept])
    universe = (1 << n) - 1
    return win & universe, (win >> n) & universe, log


def source_goals(variant):
    return [mask_of(i for i in range(N) if state(i)[3:] == target) for target in GOALS[variant]]


def old_reachability(game, win):
    root = state_id((7, 7, False, 1, 1))
    if not ((win >> root) & 1):
        return [], None, {'initial_state': root, 'initial_winning': False, 'target_found': False}
    prev = {root: None}
    queue = deque([root])
    target = None
    while queue:
        s = queue.popleft()
        if target is None and state(s)[3:] == (5, 5):
            target = s
        # env_options is lexicographic; ids order is lexicographic SYS for fixed ENV.
        for e, successors in zip(game.inputs[s], game.blocks[s]):
            for nxt in ids(successors & win):
                if nxt not in prev:
                    prev[nxt] = s
                    queue.append(nxt)
    path = None
    if target is not None:
        path = []
        now = target
        while now is not None:
            path.append(now)
            now = prev[now]
        path.reverse()
        for a, b in zip(path, path[1:]):
            old, new = state(a), state(b)
            assert env_legal(old, new[:3]) and sys_safe(old, new[:3], new[3:], 'old')
            assert (win >> a) & 1 and (win >> b) & 1
        assert all(state(i)[3:] != (5, 5) for i in path[:-1])
    return sorted(prev), path, {'initial_state': root, 'initial_winning': True, 'target_found': target is not None,
                               'target_state': target, 'path_transitions': None if path is None else len(path)-1}


def source_record(i):
    ox, oy, w, rx, ry = state(i)
    return {'state_id': i, 'obstacle[0]': ox, 'obstacle[1]': oy, 'obsWait': w, 'robot[0]': rx, 'robot[1]': ry}


def export_game(game, out):
    # Complete legal-ENV blocks including empty response blocks; no illegal input is hidden.
    with gzip.open(out / 'SOURCE_GAME.jsonl.gz', 'wt') as f:
        for i, (es, blocks) in enumerate(zip(game.inputs, game.blocks)):
            f.write(json.dumps({'state': source_record(i), 'blocks': [
                {'next_env': list(e), 'safe_successor_ids': list(ids(b))} for e, b in zip(es, blocks)]}) + '\n')


def fixtures(out):
    verify_pins()
    checks = []
    def check(name, condition):
        assert condition, name
        checks.append(name)
    samples = [(7, 7, False, 1, 1), (1, 1, True, 8, 8), (4, 4, False, 5, 5),
               (1, 7, False, 8, 1), (7, 1, False, 1, 8), (3, 6, True, 5, 5)]
    for s in samples:
        check('encoding_'+str(s), state(state_id(s)) == s)
        all_e = [e for e in itertools.product(range(1, 8), range(1, 8), (False, True)) if env_legal(s, e)]
        check('env_complete_'+str(s), env_options(s) == all_e and bool(all_e))
        for variant in ('old', 'new'):
            for e in all_e:
                fast = [o for o in output_options(s) if sys_safe(s, e, o, variant)]
                slow = [o for o in itertools.product(range(1, 9), repeat=2) if sys_safe(s, e, o, variant)]
                check('output_complete_'+variant+str(s)+str(e), fast == slow)
    check('diagonal_robot_move_allowed', sys_safe((7,7,True,1,1), (7,7,False), (2,2), 'old'))
    check('current_robot_next_obstacle_collision', not sys_safe((7,7,False,5,5), (5,5,True), (4,4), 'new'))
    check('wait_freezes_obstacle', not env_legal((3,3,True,8,8), (4,4,False)))
    abstract = [
        ('alternating_goals', Game([(2,), (1,)]), [1,2], 3),
        ('cannot_reach_second', Game([(1,), (2,)]), [1,2], 0),
        ('system_can_alternate', Game([(3,), (3,)]), [1,2], 3),
        ('environment_can_avoid', Game([(1,2), (1,2)]), [1,2], 0),
        ('safety_dead_end', Game([(0,), (2,)]), [3,3], 2),
        ('finite_env_dead_end_is_vacuous', Game([()]), [0,0], 1),
    ]
    for name, game, goals, expected in abstract:
        got, _ = generalized_buchi(game, goals)
        p0, p1, _ = two_phase_buchi_check(game, goals)
        check(name, got == expected and p0 == got and p1 == got)
    # Exhaustive 2-state, one-ENV-move games (16 transition relations), all goal pairs.
    count = 0
    for a,b in itertools.product(range(4), repeat=2):
        for g0,g1 in itertools.product(range(4), repeat=2):
            game = Game([(a,), (b,)])
            got,_=generalized_buchi(game,[g0,g1]);p0,p1,_=two_phase_buchi_check(game,[g0,g1])
            assert got == p0 == p1, (a,b,g0,g1)
            count += 1
    check('all_256_tiny_relation_goal_combinations', count == 256)
    out.mkdir(parents=True, exist_ok=True)
    receipt = {'status':'PASS','scope':'tiny abstract fixtures and six named source valuations only; no full source game or primary winning computation',
               'checks':checks,'abstract_exhaustive_cases':count,'source_eval_sha256':sha(__file__),
               'source_pins':PINS,'all98_roster_sha256':ROSTER_SHA}
    dump(out/'FIXTURE_QUALIFICATION.json',receipt)
    print(json.dumps({'status':'PASS','named_checks':len(checks),'tiny_cases':count}))


def primary(phase, out, old_out):
    verify_pins()
    if out.exists():
        raise RuntimeError('Refuse to overwrite a consumed primary phase directory')
    if phase == 'new':
        seal = json.loads((old_out/'OLD_ONLY_BOUNDARY_SEAL.json').read_text())
        assert seal['old_source_sha256'] == PINS['old'][1]
        for name, digest in seal['output_pins'].items():
            assert sha(old_out/name) == digest, name
        assert seal['new_source_winning_not_computed_here'] is True
    out.mkdir(parents=True)
    start=time.monotonic()
    game,stats=build_game(phase);goals=source_goals(phase)
    win,log=generalized_buchi(game,goals)
    p0,p1,plog=two_phase_buchi_check(game,goals)
    assert win == p0 == p1, 'Direct generalized-Buchi / product-Buchi disagreement'
    export_game(game,out)
    result={'status':'COMPLETE','variant':phase,'semantics':'environment-first strict safety and two SYS Buchi goals; no ENV justice',
            'stats':stats,'winning_ids':list(ids(win)),'winning_count':win.bit_count(),
            'strict_equals_legal_prefix_cooperative':stats['env_total'],
            'generalized_buchi_iterations':log,'product_buchi_iterations':plog,'product_phase_regions_identical':True,
            'source_eval_sha256':sha(__file__),'source_sha256':PINS[phase][1], 'elapsed_seconds':time.monotonic()-start}
    dump(out/'SOURCE_RESULT.json',result)
    if phase=='old':
        reachable,path,reach=old_reachability(game,win)
        dump(out/'OLD_REACHABILITY.json',{'reachable_ids':reachable,'count':len(reachable),**reach,
             'meaning':'union of finite legal prefixes staying in old W; not a single extracted controller graph'})
        dump(out/'OLD_ONLY_SELECTED_PREFIX.json',{'selection':'first dequeued target in FIFO BFS with lex ENV/SYS edges; OLD source/W only',
             'records':None if path is None else [source_record(i) for i in path],
             'old_controller_private_memory':None,'private_memory_note':'no extracted controller; finite prefix inside W admits a winning continuation',
             'published_execution':False,'new_outcomes_used':False,**reach})
        names=['SOURCE_RESULT.json','SOURCE_GAME.jsonl.gz','OLD_REACHABILITY.json','OLD_ONLY_SELECTED_PREFIX.json']
        dump(out/'OLD_ONLY_BOUNDARY_SEAL.json',{'phase':'OLD complete before NEW invocation','old_source_sha256':PINS['old'][1],
             'source_eval_sha256':sha(__file__),'all98_roster_sha256':ROSTER_SHA,'new_source_winning_not_computed_here':True,
             'output_pins':{name:sha(out/name) for name in names}})
    else:
        old=json.loads((old_out/'SOURCE_RESULT.json').read_text());oldwin=set(old['winning_ids'])
        reach=set(json.loads((old_out/'OLD_REACHABILITY.json').read_text())['reachable_ids'])
        roster=json.loads((PROV/'OBSTACLE_BOUNDARY_ALL98_FROZEN.json').read_text());rows=[]
        for row in roster['rows']:
            s=row['source_state'];i=state_id((s['obstacle[0]'],s['obstacle[1]'],s['obsWait'],s['robot[0]'],s['robot[1]']))
            rows.append({'id':row['id'],**source_record(i),'old_W':i in oldwin,'old_W_prefix_reachable':i in reach,'new_W':bool((win>>i)&1)})
        dump(out/'ALL98_SOURCE_MEMBERSHIP.json',{'rows':rows,'count':len(rows),'roster_sha256':ROSTER_SHA,'none_filtered':True,
             'old_only_prefix_file_sha256':sha(old_out/'OLD_ONLY_SELECTED_PREFIX.json')})
    print(json.dumps({'phase':phase,'status':'COMPLETE','elapsed_seconds':time.monotonic()-start}))


def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['fixtures','old','new'],required=True)
    p.add_argument('--out',type=Path,required=True);p.add_argument('--old-out',type=Path)
    p.add_argument('--primary-token',default='')
    a=p.parse_args()
    if a.mode=='fixtures':fixtures(a.out)
    else:
        if a.primary_token!='ROOT_PROTOCOL_GO_REQUIRED':raise RuntimeError('Primary phases require the bounded root-authorized supervisor')
        primary(a.mode,a.out,a.old_out)
if __name__=='__main__':main()
