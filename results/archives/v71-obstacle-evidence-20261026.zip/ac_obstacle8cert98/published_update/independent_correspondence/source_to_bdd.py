"""Independent equation-to-BDD binding for the exact published Obstacle pair.

No compiler/parser implementation or source-game derived regions are imported.
Fresh native metadata supplies only declared value encodings; every logical
predicate below is constructed from the pinned published source equations.
Functions are inert until explicitly invoked by an authorized caller.
"""
import gzip
import itertools
import json
from pathlib import Path

import audit_core as c
from symbolic import count, root_digest

FIELDS = ('obstacle[0]', 'obstacle[1]', 'obsWait', 'robot[0]', 'robot[1]')
ORIGINAL_SHA = {'old': '19c71d970b05fec41f0fa60fce155bf136b33836ffd785a65c2c436a712c3ac1', 'new': 'bf2836d68e9a7b019b8f2c9499ccf1ad8dccdc56f5c31ff78ea7d80e45b1a228'}
ROSTER_SHA = 'bcbccc0fa89e3da07b756c9d954ce74df4a79c59db8f2bf0937af29d7885d8ad'
SWITCH_BYTES = b'switch robotLoc:\nrobot[0] = 5 & robot[1] = 5;'


def verify_projection(manifest_path, variant):
    manifest = c.read(manifest_path)
    rows = [row for row in manifest['source_rows'] if row['phase'] == variant]
    c.require(len(rows) == 1, 'unique source projection row')
    row = rows[0]
    for key in ('original_source', 'projected_source'):
        c.require(c.pin(row[key]['path']) == row[key], 'source projection byte/hash drift')
    c.require(row['original_source']['sha256'] == ORIGINAL_SHA[variant], 'unexpected published source revision')
    original, projected = (Path(row[key]['path']).read_bytes() for key in ('original_source', 'projected_source'))
    if variant == 'old':
        c.require(original == projected and row['removed_span'] is None, 'old source must be identity projection')
    else:
        c.require(original.count(SWITCH_BYTES) == 1, 'exact unique published switch declaration')
        offset = original.index(SWITCH_BYTES)
        c.require(projected == original[:offset] + original[offset + len(SWITCH_BYTES):], 'new projection removes more than exact metadata declaration')
        span = row['removed_span']
        c.require(span['byte_start_zero_based'] == offset and span['byte_end_exclusive'] == offset + len(SWITCH_BYTES), 'metadata span mismatch')
    boundary = manifest['all98_boundary']
    c.require(c.pin(boundary['path']) == boundary and boundary['sha256'] == ROSTER_SHA, 'all98 roster pin')
    c.require(row['imports'] == [], 'unexpected imports')
    return row, boundary


class EquationBuilder:
    def __init__(self, arena, published=True):
        self.a, self.b = arena, arena.b
        self.fields = {f['name']: f for f in arena.model['fields']}
        c.require(set(self.fields) == set(FIELDS), 'source has extra/missing field; no AUX projection permitted')
        self.values = {}
        self.cubes = {}
        for name in FIELDS:
            f = self.fields[name]
            owner = 'ENV' if name in FIELDS[:3] else 'SYS'
            c.require(f['owner'] == f['role'] == owner, 'literal source ownership/role: ' + name)
            if name == 'obsWait':
                c.require(set(f['values']) == {'false', 'true'}, 'Boolean wait domain')
                values = [False, True]
            else:
                values = sorted(int(v) for v in f['values'])
                c.require({str(v) for v in values} == set(f['values']), 'numeric source value encoding')
                expected = list(range(1, 8 if name.startswith('obstacle') else 9))
                if published:
                    c.require(values == expected, 'exact published integer domain: ' + name)
            self.values[name] = values
            for phase in ('current', 'next'):
                for value in values:
                    label = str(value).lower() if name == 'obsWait' else str(value)
                    self.cubes[name, phase, value] = self.b.cube({int(k): v for k, v in f['encoding'][label][phase].items()})
        if published:
            c.require(arena.carrier == 6272, 'complete published typed carrier')

    def eq(self, name, value, phase='current'):
        return self.cubes[name, phase, value]

    def pair_relation(self, left, right, predicate, lp='current', rp='next'):
        b = self.b
        return b.disj(*(b.conj(self.eq(left, x, lp), self.eq(right, y, rp)) for x in self.values[left] for y in self.values[right] if predicate(x, y)))

    def smart_axis(self, obstacle, robot):
        b = self.b
        cubes = []
        for old_o in self.values[obstacle]:
            for old_r in self.values[robot]:
                for next_o in self.values[obstacle]:
                    # The two source implications are separate; their false
                    # antecedents add no chase equality.
                    if (old_o <= old_r or next_o == old_o - 1) and (old_o >= old_r - 1 or next_o == old_o + 1):
                        cubes.append(b.conj(self.eq(obstacle, old_o), self.eq(robot, old_r), self.eq(obstacle, next_o, 'next')))
        return b.disj(*cubes)

    def obstacle_collision(self, phase):
        b = self.b
        x = self.pair_relation('obstacle[0]', 'robot[0]', lambda o, r: r == o or r == o + 1, phase, 'current')
        y = self.pair_relation('obstacle[1]', 'robot[1]', lambda o, r: r == o or r == o + 1, phase, 'current')
        return b.conj(x, y)

    def build(self, forbidden, goals, initializer):
        b, a = self.b, self.a
        wait, next_wait = self.eq('obsWait', True), self.eq('obsWait', True, 'next')
        hold_x = self.pair_relation('obstacle[0]', 'obstacle[0]', lambda x, y: x == y)
        hold_y = self.pair_relation('obstacle[1]', 'obstacle[1]', lambda x, y: x == y)
        components = {
            'ENV_obsWaitSwitches': b.iff(next_wait, b.neg(wait)),
            'ENV_obstacleDoesNotMoveWhenObsWait': b.implies(wait, b.conj(hold_x, hold_y)),
            'ENV_obstacleMovesAtMostOne_x': self.pair_relation('obstacle[0]', 'obstacle[0]', lambda x, y: abs(y-x) <= 1),
            'ENV_obstacleMovesAtMostOne_y': self.pair_relation('obstacle[1]', 'obstacle[1]', lambda x, y: abs(y-x) <= 1),
            'ENV_obstacleIsSmart': b.implies(b.neg(wait), b.conj(self.smart_axis('obstacle[0]', 'robot[0]'), self.smart_axis('obstacle[1]', 'robot[1]'))),
            'SYS_robotMovesAtMostOne_x': self.pair_relation('robot[0]', 'robot[0]', lambda x, y: abs(y-x) <= 1),
            'SYS_robotMovesAtMostOne_y': self.pair_relation('robot[1]', 'robot[1]', lambda x, y: abs(y-x) <= 1),
            'SYS_robotNotOnObstacle': b.neg(self.obstacle_collision('current')),
            # Source robot coordinates are CURRENT here; only obstacle is next.
            'SYS_robotAvoidsNextObstacle': b.neg(self.obstacle_collision('next')),
            'SYS_forbiddenCells': b.neg(b.disj(*(b.conj(self.eq('robot[0]', x), self.eq('robot[1]', y)) for x, y in forbidden))),
        }
        e = b.conj(*(value for key, value in components.items() if key.startswith('ENV_')))
        s = b.conj(*(value for key, value in components.items() if key.startswith('SYS_')))
        if initializer is None:
            thetae = thetas = 1
        else:
            ox, oy, wait0, rx, ry = initializer
            thetae = b.conj(self.eq('obstacle[0]', ox), self.eq('obstacle[1]', oy), self.eq('obsWait', wait0))
            thetas = b.conj(self.eq('robot[0]', rx), self.eq('robot[1]', ry))
        forms = {'thetaE': thetae, 'thetaS': thetas, 'rhoE': e, 'rhoS': s, 'domain': a.q, 'domain_ENV_next': a.den, 'domain_SYS_next': a.dsn}
        justices = {'ENV': [], 'SYS': [b.conj(self.eq('robot[0]', x), self.eq('robot[1]', y)) for x, y in goals]}
        return forms, justices, components

    def published(self, variant):
        c.require(variant in ('old', 'new'), 'source variant')
        if variant == 'old':
            return self.build([(3, 5), (4, 5)], [(5, 2), (2, 3)], (7, 7, False, 1, 1))
        return self.build([(6, 4), (8, 7)], [(3, 7), (4, 8)], None)

    def assignment(self, state, phase='current'):
        result = {}
        for name, value in zip(FIELDS, state):
            label = str(value).lower() if name == 'obsWait' else str(value)
            result.update({int(k): v for k, v in self.fields[name]['encoding'][label][phase].items()})
        return result

    def decode(self, bits, phase):
        state = {}
        for name in FIELDS:
            f = self.fields[name]
            labels = [label for label in f['values'] if all(bits[int(k)] == v for k, v in f['encoding'][label][phase].items())]
            c.require(len(labels) == 1, 'typed witness decode')
            state[name] = labels[0] == 'true' if name == 'obsWait' else int(labels[0])
        return state


def compare_predicate(builder, actual, expected, mask, variables, label):
    b, a = builder.b, builder.a
    left, right = b.conj(actual, mask), b.conj(expected, mask)
    missing, excess = b.conj(right, b.neg(left)), b.conj(left, b.neg(right))
    result = {'label': label, 'typed_equal': left == right, 'raw_boolean_equal': actual == expected, 'expected_typed_count': count(b, right, variables), 'actual_typed_count': count(b, left, variables), 'missing_typed_count': count(b, missing, variables), 'excess_typed_count': count(b, excess, variables), 'expected_digest': root_digest(b, right), 'actual_digest': root_digest(b, left)}
    for key, root in [('missing', missing), ('excess', excess)]:
        if root:
            allbits = a.current + a.en + a.sn
            bits = b.satone(root, allbits)
            # Fill unused bits with a known typed value before decoding;
            # the mismatch mask already types every relevant phase.
            for name in FIELDS:
                for phase in ('current', 'next'):
                    fb = builder.fields[name][phase + '_bits']
                    if not set(fb) <= set(variables):
                        label = builder.fields[name]['values'][0]
                        bits.update({int(k): v for k, v in builder.fields[name]['encoding'][label][phase].items()})
            result[key + '_witness'] = {'current': builder.decode(bits, 'current'), 'next': builder.decode(bits, 'next')}
    return result


def audit_export(variant, export_folder, projection_manifest, output):
    row, boundary_pin = verify_projection(projection_manifest, variant)
    folder = Path(export_folder)
    native_result = c.read(folder / 'RESULT.json')
    c.require(native_result['status'] == 'PASS_EXPORTED_SOURCE_MODEL', 'export-only native result incomplete')
    c.require(all(native_result[key] == 0 for key in ('native_strict_solver_calls', 'solver_constructions', 'raw_four_fixed_point_calls', 'controller_extraction_calls', 'syntactic_reduction_calls', 'semantic_reduction_calls')), 'export-only stage invoked solver/reduction')
    m = c.read(folder / 'model.json')
    c.require(m['input']['sha256'] == row['projected_source']['sha256'], 'native export source projection hash')
    a = c.Arena(m)
    native = c.Bundle(folder, a, helper=False)
    builder = EquationBuilder(a, published=True)
    expected, justices, components = builder.published(variant)
    b = a.b
    comparisons = {}
    for key, mask, variables in [('thetaE', a.de, a.ec), ('thetaS', a.q, a.current), ('rhoE', b.conj(a.q, a.den), a.current + a.en), ('rhoS', b.conj(a.q, a.den, a.dsn), a.current + a.en + a.sn)]:
        comparisons[key] = compare_predicate(builder, native.forms[key], expected[key], mask, variables, key)
    c.require(len(native.justices['ENV']) == 0 and len(native.justices['SYS']) == 2, 'source justice counts changed')
    for i in range(2):
        key = 'SYS_justice_' + str(i)
        comparisons[key] = compare_predicate(builder, native.justices['SYS'][i], justices['SYS'][i], a.q, a.current, key)
    status = 'PASS' if all(x['typed_equal'] for x in comparisons.values()) else 'SOURCE_COMPILED_RELATION_MISMATCH'
    boundary = c.read(boundary_pin['path'])
    c.require(len(boundary['rows']) == 98 and boundary['source_initializer_reapplied_at_boundary'] is False, 'all98 roster scope')
    expected_rows = [(x, y, w, 5, 5) for x in range(1, 8) for y in range(1, 8) for w in (False, True)]
    c.require([tuple(row['source_state'][name] for name in FIELDS) for row in boundary['rows']] == expected_rows, 'all98 complete order')
    boundary_rows = []
    for boundary_row in boundary['rows']:
        state = tuple(boundary_row['source_state'][name] for name in FIELDS)
        bits = builder.assignment(state)
        boundary_rows.append({'id': boundary_row['id'], 'source_state': boundary_row['source_state'], 'source_current_collision_safe': b.evaluate(components['SYS_robotNotOnObstacle'], bits), 'source_current_forbidden_cells_safe': b.evaluate(components['SYS_forbiddenCells'], bits), 'source_thetaE': b.evaluate(expected['thetaE'], bits), 'source_thetaS': b.evaluate(expected['thetaS'], bits), 'initializer_reapplied': False, 'winning_or_reachability_filter': False})
    out = Path(output)
    out.mkdir(parents=True, exist_ok=False)
    roots = dict(components)
    roots.update({'source_' + key: value for key, value in expected.items()})
    roots.update({'native_' + key: value for key, value in native.forms.items()})
    roots.update({'source_SYS_justice_' + str(i): value for i, value in enumerate(justices['SYS'])})
    c.export_regions(out / 'SOURCE_AND_NATIVE_PREDICATES.json.gz', a, roots)
    c.save(out / 'ALL98_SOURCE_BINDING_ROWS.json', {'variant': variant, 'rows': boundary_rows, 'count': 98, 'membership_claim': 'No winning region computed in this correspondence stage'})
    result = {'schema': 'v71-independent-published-source-equation-binding-v1', 'status': status, 'variant': variant, 'typed_carrier': a.carrier, 'source_equation_comparisons': comparisons, 'source_projection': row, 'all98_roster': boundary_pin, 'no_AUX_or_public_projection': True, 'source_init_preserved': True, 'source_primary_fixed_points_computed_here': 0, 'new_native_calls': 0, 'source_game_derived_regions_used_as_oracle': False, 'logic_origin': 'Manually derived from exact pinned published Spectra source equations; native metadata supplies value encodings only', 'native_primitive_pins': native.pins, 'native_result': c.pin(folder / 'RESULT.json'), 'predicate_artifact': c.pin(out / 'SOURCE_AND_NATIVE_PREDICATES.json.gz'), 'all98_artifact': c.pin(out / 'ALL98_SOURCE_BINDING_ROWS.json'), 'canonical_nodes_created': len(b.nodes)}
    c.save(out / 'SOURCE_EXPORT_CORRESPONDENCE.json', result)
    return result
