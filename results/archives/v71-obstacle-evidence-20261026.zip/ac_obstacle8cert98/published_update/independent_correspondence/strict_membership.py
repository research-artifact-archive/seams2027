"""Read-only projections of independently derived strict regions; no fixed points."""
import csv
import gzip
import itertools
from pathlib import Path
import audit_core as c

H = Path(__file__).resolve().parent
NAMES = ('obstacle[0]', 'obstacle[1]', 'obsWait', 'robot[0]', 'robot[1]')


def states():
    return (dict(zip(NAMES, s)) for s in itertools.product(range(1, 8), range(1, 8), (False, True), range(1, 9), range(1, 9)))


def state_id(s):
    return (((s[NAMES[0]] - 1) * 7 + s[NAMES[1]] - 1) * 2 + int(s[NAMES[2]])) * 64 + (s[NAMES[3]] - 1) * 8 + s[NAMES[4]] - 1


def assignment(fields, state, helper_bit, helper_value=False):
    c.require(set(state) == {f['name'] for f in fields}, 'membership state field roster')
    out = {helper_bit: bool(helper_value)}
    for field in fields:
        value = state[field['name']]
        key = str(value).lower() if isinstance(value, bool) else str(value)
        c.require(key in field['encoding'], 'membership typed value')
        out.update({int(k): flag for k, flag in field['encoding'][key]['current'].items()})
    return out


def evaluate(nodes, root, bits):
    while root >= 2:
        v, lo, hi = nodes[root]
        c.require(v in bits, 'membership root has unassigned or next variable')
        root = hi if bits[v] else lo
    return bool(root)


def export_membership(variant, mode, output, audit):
    # All independent derivation has completed before opening peer verdicts.
    region_path = output / 'REGIONS.json.gz'
    c.require(c.pin(region_path) == audit['regions_file'], 'regions export drift')
    obj = __import__('json').loads(gzip.decompress(region_path.read_bytes()))
    c.require(obj['schema'] == 'v71-independent-canonical-regions-v1', 'regions schema')
    fields, helper = obj['source_fields'], obj['helper_current_bit']
    c.require({f['name']: f['role'] for f in fields} == {n: ('ENV' if i < 3 else 'SYS') for i, n in enumerate(NAMES)}, 'exact public field roles/no AUX')
    nodes = {n: (v, lo, hi) for n, v, lo, hi in obj['nodes']}
    roots = obj['roots']
    def row_for(state):
        bits = assignment(fields, state, helper)
        columns = {k: evaluate(nodes, r, bits) for k, r in roots.items() if not (k[0] in 'ES' and len(k) == 3)}
        for k in ('native_full_W', 'independent_full_W'):
            if k in roots:
                columns[k + '_at_helper_true'] = evaluate(nodes, roots[k], assignment(fields, state, helper, True))
                columns[k + '_at_helper_false'] = columns.pop(k)
        return columns
    expected_file = H.parent / ('independent_source/run_' + variant + '/data/SOURCE_RESULT.json')
    expected = c.read(expected_file)
    c.require(expected['status'] == 'COMPLETE' and expected['variant'] == variant and expected['stats']['typed_states'] == 6272, 'peer source result incomplete')
    freeze = c.read(H.parent / 'native_preparation/INPUT_PROJECTION_FREEZE.json')
    source = next(r for r in freeze['source_rows'] if r['phase'] == variant)
    c.require(expected['source_sha256'] == source['original_source']['sha256'], 'peer source identity')
    expected_ids = set(expected['winning_ids'])
    c.require(len(expected_ids) == expected['winning_count'] and expected_ids <= set(range(6272)), 'peer source IDs')
    actual_ids, native_ids = set(), set()
    for sid, state in enumerate(states()):
        c.require(state_id(state) == sid, 'peer state ID binding')
        bits = assignment(fields, state, helper)
        if evaluate(nodes, roots['source_W'], bits): actual_ids.add(sid)
        if evaluate(nodes, roots['native_source_W'], bits): native_ids.add(sid)
    comparisons = {'independent_primitive_vs_independent_equation_W': {'equal': actual_ids == expected_ids, 'left_minus_right_ids': sorted(actual_ids - expected_ids), 'right_minus_left_ids': sorted(expected_ids - actual_ids)}, 'native_source_vs_independent_equation_W': {'equal': native_ids == expected_ids, 'left_minus_right_ids': sorted(native_ids - expected_ids), 'right_minus_left_ids': sorted(expected_ids - native_ids)}}
    roster_path = Path(freeze['all98_boundary']['path'])
    c.require(c.pin(roster_path) == freeze['all98_boundary'], 'all98 roster pin drift')
    roster = c.read(roster_path)
    c.require(roster['boundary_count'] == 98 and len(roster['rows']) == 98, 'all98 roster length')
    peer_boundary_path = H.parent / 'independent_source/run_new/data/ALL98_SOURCE_MEMBERSHIP.json'
    peer_boundary = c.read(peer_boundary_path)
    c.require(peer_boundary['count'] == 98 and peer_boundary['none_filtered'] is True and peer_boundary['roster_sha256'] == freeze['all98_boundary']['sha256'], 'peer boundary roster')
    peer_rows = {r['id']: r for r in peer_boundary['rows']}
    c.require(len(peer_rows) == 98, 'duplicate peer boundary ID')
    rows = []
    for original in roster['rows']:
        state = original['source_state']; sid = state_id(state); peer = peer_rows[original['id']]
        c.require(peer['state_id'] == sid and all(peer[n] == state[n] for n in NAMES), 'peer boundary exact state binding')
        columns = row_for(state)
        rows.append({'id': original['id'], 'source_state': state, 'state_id': sid, **columns, 'independent_equation_source_W': sid in expected_ids, 'peer_all98_source_W': peer[variant + '_W'], 'initializer_reapplied': False, 'eligibility_filter_applied': False})
    comparisons['all98_three_source_views_equal'] = {'equal': all(r['source_W'] == r['native_source_W'] == r['independent_equation_source_W'] == r['peer_all98_source_W'] for r in rows)}
    report = {'schema': 'v71-published-independent-strict-all98-v1', 'variant': variant, 'mode': mode, 'count': 98, 'none_filtered': True, 'region_derivation': 'audit_core fixed points from qualified exported primitives; peer source regions read after derivation and used only as additional consistency targets', 'source_initializers_reapplied_at_boundary': False, 'helper_entry': False, 'rows': rows, 'comparisons': comparisons, 'source_W_all6272_counts': {'independent_primitive': len(actual_ids), 'native_source': len(native_ids), 'independent_equations': len(expected_ids)}, 'inputs': [c.pin(region_path), c.pin(expected_file), c.pin(peer_boundary_path), c.pin(roster_path)], 'new_native_calls': 0}
    c.save(output / 'ALL98_MEMBERSHIP.json', report)
    flat = [{'id': r['id'], **r['source_state'], **{k: v for k, v in r.items() if k not in ('id', 'source_state')}} for r in rows]
    with (output / 'ALL98_MEMBERSHIP.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(flat[0])); writer.writeheader(); writer.writerows(flat)
    return {'all_comparisons_equal': all(v['equal'] for v in comparisons.values()), 'comparisons': comparisons, 'source_W_all6272_counts': report['source_W_all6272_counts'], 'all98': c.pin(output / 'ALL98_MEMBERSHIP.json'), 'all98_csv': c.pin(output / 'ALL98_MEMBERSHIP.csv')}
