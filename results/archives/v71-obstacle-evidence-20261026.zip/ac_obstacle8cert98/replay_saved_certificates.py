#!/usr/bin/env python3
"""Unexecuted publication entrypoint for an opt-in bounded saved-certificate replay."""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

ROOT = Path(__file__).resolve().parent
MODES = ('original','syntactic','first_flip','complete')
WALL = 180
RSS_BYTES = 1073741824
STREAM_BYTES = 16*1024*1024


def worker(variant, mode, output):
    os.chdir(ROOT)
    sys.path.insert(0,str(ROOT/'published_update/direct_certificate_check/amendment_01'))
    import check_saved
    result = check_saved.check(variant,mode,output)
    print(json.dumps({'variant':variant,'mode':mode,'status':result['status']}))
    return 0 if result['status']=='PASS_SAVED_CERTIFICATE' else 2


def kill_group(process):
    if process.poll() is None:
        try:
            os.killpg(process.pid,signal.SIGKILL)
        except ProcessLookupError:
            pass


def replay(output):
    if output.exists():
        raise FileExistsError('Use a new output directory; saved evidence is never overwritten')
    if output.resolve().is_relative_to(ROOT):
        raise ValueError('Replay output must be outside the frozen package tree')
    output.mkdir(parents=True)
    rows=[]
    halted=False
    for variant in ('old','new'):
        for mode in MODES:
            if halted:
                rows.append({'variant':variant,'mode':mode,'status':'NOT_ATTEMPTED_AFTER_HALT'})
                continue
            folder=output/variant/mode
            folder.parent.mkdir(exist_ok=True,parents=True)
            stdout=folder.with_suffix('.stdout');stderr=folder.with_suffix('.stderr')
            start=time.monotonic();reason=None;peak=0
            with stdout.open('wb') as out,stderr.open('wb') as err:
                proc=subprocess.Popen([sys.executable,'-I','-S','-B',str(Path(__file__).resolve()),
                                       '--worker',variant,mode,str(folder)],
                                      cwd=ROOT,stdout=out,stderr=err,start_new_session=True)
                watchdog=threading.Timer(WALL,kill_group,args=(proc,));watchdog.start()
                try:
                    while proc.poll() is None:
                        if time.monotonic()-start>=WALL:
                            reason='WALL_LIMIT';kill_group(proc);break
                        try:
                            sample=subprocess.run(['ps','-o','rss=','-p',str(proc.pid)],
                                                  capture_output=True,text=True,timeout=2)
                            if sample.returncode==0 and sample.stdout.strip():
                                rss=int(sample.stdout.strip())*1024;peak=max(peak,rss)
                                if rss>RSS_BYTES:
                                    reason='RSS_LIMIT';kill_group(proc);break
                            elif proc.poll() is None:
                                reason='RSS_SUPERVISION_FAILURE';kill_group(proc);break
                        except (ValueError,subprocess.TimeoutExpired,OSError):
                            reason='RSS_SUPERVISION_FAILURE';kill_group(proc);break
                        if max(stdout.stat().st_size,stderr.stat().st_size)>STREAM_BYTES:
                            reason='STREAM_LIMIT';kill_group(proc);break
                        time.sleep(0.25)
                    code=proc.wait(timeout=5)
                finally:
                    watchdog.cancel();kill_group(proc)
            record={'variant':variant,'mode':mode,'returncode':code,'reason':reason,
                    'elapsed_seconds':time.monotonic()-start,'peak_sampled_RSS_bytes':peak}
            result=folder/'CERTIFICATE.json'
            if reason or code!=0 or not result.is_file():
                record['status']='UNKNOWN_REPLAY_FAILURE';halted=True
            else:
                actual=json.loads(result.read_text())
                saved=ROOT/'published_update/direct_certificate_check/amendment_01/runs'/variant/mode
                wanted=json.loads((saved/'CERTIFICATE.json').read_text())
                keys=('status','variant','mode','gates','U_certificate','F_certificate','WF_certificate',
                      'native_typed_counts','mismatches','all_typed_state_checks','all_boolean_mask_checks',
                      'one_step_predecessor_calls','fixedpoint_calls','native_calls',
                      'actual_initializer_realizable_by_enumeration')
                same=all(actual[k]==wanted[k] for k in keys)
                same &= all(json.loads((folder/n).read_text())==json.loads((saved/n).read_text())
                            for n in ('ALL98_MEMBERSHIP.json','ALL_TYPED_MEMBERSHIP.json'))
                record['status']='PASS_REPLAY_MATCHES_SAVED' if same else 'MISMATCH_REPLAY'
                halted=not same
            rows.append(record)
    report={'scope':'Separate local replay; does not retroactively replace any historical status',
            'rows':rows,'native_calls':0,'transformed_fixedpoint_calls':0,
            'limits':{'wall_seconds_per_arm':WALL,'rss_bytes':RSS_BYTES,'canonical_nodes':500000}}
    (output/'REPLAY_REPORT.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    return 0 if all(r['status']=='PASS_REPLAY_MATCHES_SAVED' for r in rows) else 2


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-saved-certificates',action='store_true',help='Explicit opt-in; runs the scientific saved-certificate checker')
    parser.add_argument('--output',type=Path,help='New directory outside the frozen package')
    parser.add_argument('--worker',nargs=3,metavar=('VARIANT','MODE','OUTPUT'),help=argparse.SUPPRESS)
    args=parser.parse_args()
    if args.worker:
        variant,mode,dest=args.worker
        if variant not in ('old','new') or mode not in MODES:
            raise ValueError('Unregistered arm')
        return worker(variant,mode,Path(dest))
    if not args.run_saved_certificates or args.output is None:
        parser.error('No science runs by default. Explicit opt-in and a new output directory are required.')
    return replay(args.output.resolve())


if __name__=='__main__':
    raise SystemExit(main())
