Published Obstacle pair: saved eight-arm certificates and all 98 switch states

This archive contains the accepted saved-certificate evidence for the published
Obstacle pair. The separate GUI observation bundle has its own evidence scope.
Packaging performs no solver, native, source-equation, certificate replay or
fixed-point execution. Relocated replay has NOT been run.

Start with published_update/direct_certificate_check/amendment_01/
FINAL_CERTIFICATE_SUMMARY.json, FINAL_CERTIFICATE_TABLE.csv and
ALL98_FIXED8_MEMBERSHIP.json. There are eight accepted theorem-based saved
certificates: old/new times original/syntactic/first_flip/complete. The source
carrier has 6,272 states. All 98 published switch-state completions remain in
their original order. The three old-prefix/shared-winning groups contain
48, 30 and 20 states. The selected old-only prefix has seven transitions.

These are post-hoc theorem-based certificates using independently precomputed
source W. They do not replace the eight earlier exported-game independent
fixed-point attempts (two source and six helper variants), all of which remain
UNKNOWN at 500,000 canonical nodes.
The initial distinct certificate protocol retains one serialization UNKNOWN
and seven NOT_ATTEMPTED slots. Those histories are under
published_update/independent_correspondence/FINAL_STRICT_AUDIT_SUMMARY.json and
published_update/direct_certificate_check/HISTORICAL_PROTOCOL_01.json.
The old and amended check_saved.py files are both retained. The single
scientific amendment removed a duplicated state_id keyword in row assembly;
no failed slot was overwritten or relabeled PASS.

The syntactic arm loses every helper-false winner in BOTH source variants.
The update is not shown to create this obstruction. First-change release and
the existing complete semantic correction preserve the source regions here.
No installed controller, private-memory handoff, GUI/default execution, raw
four-fixed-point verdict, comparative performance, universal repair, external
reproduction or prevalence claim is made.

Contents and dependency boundary
  - Two native source exports and all eight complete native arms include their
    typed metadata, primitive BDDs, three snapshot phases and saved W masks.
  - Independent source results, saved games, the old-only boundary seal and
    prefix, all98 roster and equation-to-export correspondence are included.
  - Scientific importers, Boolean code and saved-certificate code are included.
    REUSED_PUBLIC_CODE.json binds three small shared modules to byte-identical
    members of existing public archives; these copies keep the saved-certificate
    closure self-contained without duplicating any existing archive.
    Native Java query source is an inspection aid; this is not a complete
    compiler/native regeneration distribution. Upstream runtimes are omitted.
  - Historic receipts have private location/admin metadata removed. All
    retained counts, Booleans, memberships, BDD bytes and error statuses are
    unchanged. PROCESS_PUBLIC.json is an explicitly declared field subset.
  - Parsed/translated inventories are machine-generated exports. Original
    third-party .spectra files, distributor ZIP and publisher paper are absent.

Every copied file has original/public hashes in TRANSFORMATION_LEDGER.json.
Embedded historical pin hashes remain hashes of the original records; do not
misinterpret them as hashes of a relocated metadata derivative. The ledger
maps included records to their public hashes. MANIFEST.json binds every file
in this package except itself. HISTORICAL_INPUT_CLOSURE.json classifies all
567 frozen historical input pins; it includes administrative history that is
neither distributed nor a runtime dependency of the saved-certificate entry.
Nonincluded preparation/driver/review/runtime records are explicitly scoped
out, rather than silently treated as locally present files.

Source restoration
SOURCE_RESTORATION.json records the official distributor URL, exact ZIP/member
hashes and the 45-byte metadata projection. No license notice was present in
the inspected ZIP; this package grants no rights to that third-party text.
Acquire it independently under the distributor's terms, then optionally run:
  python3 -I -S -B restore_sources.py /path/to/Specifications.zip
The script performs only exact hash-checked member restoration and projection,
without network access or science. It has NOT been run during packaging.
The source files are needed for source/projection byte checks and a future
source-equation rerun. The saved-certificate check reads saved source results
and does not need to distribute or restore the original text.

Static integrity and future replay
  python3 -I -S -B verify_candidate.py
This validates roster/hashes, BDD file pins, safe paths and a limited privacy
scan. It imports no scientific module and performs no BDD operation.

An unexecuted, explicit-opt-in entrypoint is provided for a future bounded
saved-certificate replay. Run its --help for the interface. It must be used
from a separate copy of this package; it never overwrites saved results.
The packaging check has only parsed its syntax and verified its dependencies.
Success of this preparation is not success of that scientific replay.

The only code relocation change in audit_core.py makes newly emitted input
pin paths relative to this package root; the transformation ledger records
its original and public hashes. The checker logic and BDD importer are
unchanged. Source files and original experimental records remain intact in
the private evidence store.

Packaging history
Historical records retain their original preparation statuses, including private
staging labels. Those labels describe the time of those records. The current
README and PUBLIC_PACKAGING_AMENDMENT.json describe the packaging-only changes.
Scientific values, UNKNOWN outcomes and historical receipt statuses are unchanged.
