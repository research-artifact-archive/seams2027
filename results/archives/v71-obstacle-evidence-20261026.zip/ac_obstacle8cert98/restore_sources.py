#!/usr/bin/env python3
"""Restore omitted source bytes from a locally acquired, hash-pinned ZIP. No network/science."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def checked_target(root, relative):
    rel = PurePosixPath(relative)
    if rel.is_absolute() or '..' in rel.parts or '\\' in relative:
        raise ValueError('Unsafe restoration destination')
    target = root.joinpath(*rel.parts)
    if not target.resolve().is_relative_to(root) or target.is_symlink():
        raise ValueError('Escaping/symlink restoration destination')
    return target


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path, help='Specifications.zip acquired independently from its distributor')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    plan = json.loads((root/'SOURCE_RESTORATION.json').read_text())
    raw = args.archive.read_bytes()
    if len(raw) != plan['archive']['bytes'] or digest(raw) != plan['archive']['sha256']:
        raise ValueError('Distributor ZIP differs from the frozen source archive')
    staged = []
    with zipfile.ZipFile(args.archive) as archive:
        for row in plan['members']:
            if archive.namelist().count(row['member']) != 1:
                raise ValueError('Missing/duplicate source member')
            source = archive.read(row['member'])
            if len(source) != row['bytes'] or digest(source) != row['sha256']:
                raise ValueError('Source member pin mismatch')
            if row['projection'] == 'identity':
                projected = source
            elif row['projection'] == 'remove_exact_last_45_bytes':
                a, b = row['removed_start'], row['removed_end']
                if b != len(source) or b-a != 45 or digest(source[a:b]) != row['removed_sha256']:
                    raise ValueError('Exact switch metadata span mismatch')
                projected = source[:a] + source[b:]
            else:
                raise ValueError('Unrecognized projection')
            if len(projected) != row['projected_bytes'] or digest(projected) != row['projected_sha256']:
                raise ValueError('Projected source pin mismatch')
            staged.extend([(checked_target(root,row['restore_to']),source),
                           (checked_target(root,row['project_to']),projected)])
    for target, data in staged:
        if target.exists() and target.read_bytes() != data:
            raise FileExistsError('Refusing to replace a different existing source: '+target.name)
    for target, data in staged:
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            target.write_bytes(data)
    print(json.dumps({'status':'RESTORED_EXACT_SOURCE_AND_DECLARED_PROJECTION',
                      'files':len(staged),'network_calls':0,'scientific_calls':0},indent=2))


if __name__ == '__main__':
    main()
