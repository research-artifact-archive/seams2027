# Third-party scope

The original code, documentation and research-output contributions retain
LICENSE-original.txt. This does not grant rights to externally restored inputs.

The Obstacle Evasion specifications are identified by the official distributor
URL and exact member/hash pins in SOURCE_RESTORATION.json. The inspected source
ZIP contains no license/readme/notice member. No original specification text,
distributor archive or publisher paper is included. Obtain the text independently
under its distributor's terms. Its 45-byte switch metadata projection is declared
exactly and does not add any initializer.

Included model inventories are saved machine-generated parsed/translated
research outputs; primitive BDDs and membership records retain their original
scientific content. External runtime JARs, native libraries and compiled classes
are not distributed. Their historical class and archive identities are metadata
only, with personal locations removed.
