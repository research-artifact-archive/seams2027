#!/usr/bin/env python3
"""Static publication-candidate checks only; never import scientific code."""
import ast
import base64
import gzip
import hashlib
import json
from pathlib import Path,PurePosixPath
import re

ROOT=Path(__file__).resolve().parent


def digest(data):
    return hashlib.sha256(data).hexdigest()


def require(ok,label):
    if not ok:
        raise ValueError(label)


def safe(relative):
    rel=PurePosixPath(relative)
    require(not rel.is_absolute() and '..' not in rel.parts and '\\' not in relative,'unsafe path')
    p=ROOT.joinpath(*rel.parts)
    require(p.resolve().is_relative_to(ROOT) and not p.is_symlink(),'escaping path')
    return p


def references(value):
    if isinstance(value,dict):
        if isinstance(value.get('file'),str) and value['file'].endswith('.bdd'):
            yield value
        for child in value.values():
            yield from references(child)
    elif isinstance(value,list):
        for child in value:
            yield from references(child)


def main():
    manifest=json.loads((ROOT/'MANIFEST.json').read_text())
    rows=manifest['files'];expected={row['path'] for row in rows}
    require(len(expected)==len(rows),'duplicate manifest path')
    actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p.name!='MANIFEST.json'}
    restored=set()
    plan_path=ROOT/'SOURCE_RESTORATION.json'
    if plan_path.is_file():
        plan=json.loads(plan_path.read_text())
        for item in plan.get('members',[]):
            for key in ('restore_to','project_to'):
                if key in item:
                    target=safe(item[key])
                    if target.is_file():
                        pref='projected_' if key=='project_to' else ''
                        data=target.read_bytes()
                        require(len(data)==item[pref+'bytes'] and digest(data)==item[pref+'sha256'],'restored source pin')
                        restored.add(item[key])
    require(actual==expected|restored,'file roster differs')
    bdd_pins=python_syntax=base64_chunks=0
    private_pattern=re.compile('/'+'Users'+'/'+r'[^/\s]+')
    thread_pattern=re.compile(r'\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b',re.I)
    for row in rows:
        path=safe(row['path']);data=path.read_bytes()
        require(len(data)==row['bytes'] and digest(data)==row['sha256'],'file hash drift: '+row['path'])
        require(path.suffix not in {'.class','.jar','.dll','.dylib','.pyc','.spectra','.pdf'},'unexpected binary/source member')
        require('RESERVED' not in path.name and not (path.name.startswith('ROOT_') and 'GO' in path.name),'private administrative file')
        plain=gzip.decompress(data) if path.suffix=='.gz' else data
        text=plain.decode('utf-8',errors='replace')
        if path.suffix=='.jsonl':
            for line in text.splitlines():
                obj=json.loads(line)
                if isinstance(obj.get('data'),str):
                    text+='\n'+base64.b64decode(obj['data'],validate=True).decode('utf-8',errors='replace')
                    base64_chunks+=1
        require(not private_pattern.search(text),'private user location: '+row['path'])
        require(not thread_pattern.search(text),'private identifier: '+row['path'])
        if path.suffix=='.py':
            ast.parse(text,filename=row['path']);python_syntax+=1
        if path.suffix=='.json' and path.name in {'model.json','RESULT.json'} and 'native_result' in path.parts:
            for ref in references(json.loads(data)):
                require(Path(ref['file']).name==ref['file'],'unsafe BDD reference')
                target=path.parent/ref['file'];raw=target.read_bytes()
                require(len(raw)==ref['bytes'] and digest(raw)==ref['sha256'],'BDD file pin drift')
                bdd_pins+=1
    certificate_path=ROOT/'published_update/direct_certificate_check/amendment_01'
    if certificate_path.is_dir():
        rows2=[]
        for variant in ('old','new'):
            for mode in ('original','syntactic','first_flip','complete'):
                folder=certificate_path/'runs'/variant/mode
                result=json.loads((folder/'CERTIFICATE.json').read_text())
                all98=json.loads((folder/'ALL98_MEMBERSHIP.json').read_text())
                require(result['status']=='PASS_SAVED_CERTIFICATE','saved certificate status')
                require(all98['count']==len(all98['rows'])==98,'all98 registration roster')
                rows2.append((variant,mode))
        require(len(rows2)==8,'registered certificate count')
        prior=json.loads((ROOT/'published_update/independent_correspondence/FINAL_STRICT_AUDIT_SUMMARY.json').read_text())
        old=json.loads((ROOT/'published_update/direct_certificate_check/HISTORICAL_PROTOCOL_01.json').read_text())
        require(prior['fixed_arm_denominator']==8 and prior['accepted_strict_arms']==0,'prior UNKNOWN boundary')
        require(old['certificate_status_counts']=={'UNKNOWN_CERTIFICATE_EXCEPTION':1,'NOT_ATTEMPTED_AFTER_HALT':7},'original certificate history')
    print(json.dumps({'status':'PASS_STATIC_CANDIDATE_ONLY','files_verified':len(rows),
                      'byte_pinned_BDD_references':bdd_pins,'python_files_syntax_parsed':python_syntax,
                      'base64_chunks_privacy_scanned':base64_chunks,'restored_source_files_present':len(restored),
                      'scientific_module_imports':0,'BDD_operations':0,'replay_executed':False,
                      'native_or_solver_calls':0},indent=2))


if __name__=='__main__':
    main()
