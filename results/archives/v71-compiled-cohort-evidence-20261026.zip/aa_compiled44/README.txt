AA COMPILED COHORT: SAVED EVIDENCE

This archive contains the fixed compiled-cohort saved-evidence scope.
It registers 11 sources and 44 arms: 43 saved native candidates, 40 independently
accepted PASS arms, and four preserved UNKNOWN arms. Corpus003 B/C/D have saved
native candidates but no accepted independent result (BDD node budget refusal).
Corpus059 C has no native result; its supervisor failure is not unrealizability.
No new experiment, solver, replay, compile, native execution, GUI, or download was
performed to package these saved records.

COHORT_INDEX.json navigates the 44 arms. summary/ preserves the saved independent
cohort summary. native/ contains only the JSON/model/BDD dependency closure of 43
saved candidates; expected/ contains all 44 audit verdicts and 40 exact saved
canonical-region gzip payloads. All .bdd and .json.gz bytes are unchanged. JSON
location strings are anonymized; numbers, arrays, field encodings, relations,
region digests, statuses, and scientific values remain unchanged. Model exports
retain parsed/translated formula inventories as saved research outputs.

Historical hashes inside copied records still identify the original execution
files. They are not hashes of anonymized public metadata. The per-file and
per-pointer TRANSFORMATION_LEDGER.json records original versus staged identities.
Historical location strings are provenance identities, not runtime file paths.
MANIFEST.json binds this package payload; its own hash is reported by the outer release.

SOURCE_RESTORATION.json identifies exact members of two existing archives from
the 17-archive public set. Restore required dependencies to each restore_to path:
Core provides 11 saved source primitive bundles, symbolic.py and bdd_core.py;
FixedSevenNative provides byte-identical prior_binding.py. Archive SHA-256 and
member SHA-256 must both match. Old source model public copies differ only in
input.path and serialization; all remaining parsed values match their historical
counterparts. Corpus source/import text is referenced, not duplicated; exact
upstream archive/member/hash and the original BSD notice are supplied. No
third-party paper, unlicensed source text, runtime, JAR or compiled class is here.

replay_saved.py is a newly prepared relative-path adapter, not a previously
executed receipt. It exposes only the 40 accepted arms after dependency restoration
and keeps all four UNKNOWN arms outside replay. The unchanged audit_core.py
implements the saved-data check. Its transitive modules are archive references.
The adapter and imports were inspected statically only; no relocated or fresh-host
qualification has occurred. Python 3.9+ syntax is used. An external supervisor
would be needed to recreate historical wall/RSS limits for any future execution.
No new scientific execution is claimed by this packaging. build_staging.py
is the static packaging recipe, not a scientific runner or a restoration helper.

OMITTED_FILES.json accounts for private authorizations/reservations, control and
review records, compiled/cache files, duplicate captures, intermediate snapshots,
producer orchestration and qualification branches outside the minimal saved-claim
closure. Native regeneration is outside this package scope. Historical case
configs also refer to earlier symbolic certificates and canonical regions; those
prior outcomes informed selection but are not consumed by the saved checker.

Original contributions use LICENSE-original.txt; corpus-derived exported metadata
retains the attribution in licenses/zenodo10553249-LICENSE.txt. The license does
not extend to omitted externally obtained dependencies. No relocated or fresh-host
reader replay is claimed.

Packaging history
Historical records retain their original preparation statuses, including private
staging labels. Those labels describe the time of those records. The current
README and PUBLIC_PACKAGING_AMENDMENT.json describe the packaging-only changes.
Scientific values, UNKNOWN outcomes and historical receipt statuses are unchanged.
