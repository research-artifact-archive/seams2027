"""Prepared saved-data checker entry point; no native calls. Not run for packaging."""
import argparse
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "checkers"))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("case")
    parser.add_argument("mode", choices=["original", "syntactic", "first_flip", "complete"])
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    rows = json.loads((HERE / "COHORT_INDEX.json").read_text())["rows"]
    matches = [r for r in rows if r["case_id"] == args.case and r["mode"] == args.mode]
    if len(matches) != 1 or not matches[0]["accepted"]:
        parser.error("Only 40 historically accepted arms are eligible; UNKNOWNs remain UNKNOWN.")
    if args.output.exists() or args.output.resolve().is_relative_to(HERE):
        parser.error("Output must be a new directory outside this evidence tree.")
    row = matches[0]
    import audit_core
    native = HERE / "native" / args.case
    result = audit_core.audit_arm(HERE / row["source_directory"], native / "original",
                                 native / args.mode, row["arm"], args.output,
                                 native / "syntactic" if args.mode == "first_flip" else None)
    return 0 if result["status"] == "PASS" else 2

if __name__ == "__main__":
    raise SystemExit(main())
