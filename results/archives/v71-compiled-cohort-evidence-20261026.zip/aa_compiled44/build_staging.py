"""Static packaging only: copy, anonymize metadata, hash, inspect; never run science."""
from pathlib import Path
import ast
import gzip
import hashlib
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parents[4]
BASE = ROOT / 'experiment/v71_acceptance_cycle_20261025/compiled_cohort'
STAGE = Path(__file__).resolve().parent
ledger, deps, omitted, checks = [], [], [], []
copied = set()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def write(name, raw):
    p = STAGE / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(raw)


def identity(path):
    return str(Path(path).relative_to(ROOT))


def anonymize(value, pointer='', changes=None):
    if isinstance(value, dict):
        return {k: anonymize(v, pointer + '/' + k.replace('~', '~0').replace('/', '~1'), changes) for k, v in value.items()}
    if isinstance(value, list):
        return [anonymize(v, pointer + '/' + str(i), changes) for i, v in enumerate(value)]
    if not isinstance(value, str):
        return value
    original = value
    value = re.sub(r'(?:file:)?/' + 'Users' + r'/[^/\s]+/Research/[^\n]*?/(experiment|output|artifact-public)/', lambda m: 'historical:' + m.group(1) + '/', value)
    value = re.sub(r'(?:file:)?/(?:Users|home)/[^\s\"\'<>\)]+', lambda m: 'external-runtime:' + m.group(0).rsplit('/', 1)[-1], value)
    if value != original:
        changes.append({'pointer': pointer, 'rule': 'LOCAL_LOCATION_TO_HISTORICAL_ID', 'original_value_sha256': digest(original.encode()), 'public_value': value})
    return value


def take(source, destination, projection=None):
    source = Path(source)
    original = source.read_bytes()
    public = original
    changes = []
    if source.suffix == '.json':
        original_value = json.loads(original)
        value = original_value
        if projection is not None:
            changes.append({'pointer': '', 'rule': 'SELECT_SCIENTIFIC_FAILURE_FIELDS', 'omitted_keys': sorted(set(value) - set(projection))})
            value = {k: value[k] for k in projection if k in value}
        value = anonymize(value, changes=changes)
        if changes:
            if projection is not None:
                public = dump(value)
            else:
                # Preserve every non-location byte, including numeric lexemes
                # and the complete serialized scientific structures.
                text = original.decode()
                for change in changes:
                    old = original_value
                    for part in change['pointer'].split('/')[1:]:
                        part = part.replace('~1', '/').replace('~0', '~')
                        old = old[int(part)] if isinstance(old, list) else old[part]
                    replacement = json.dumps(change['public_value'], ensure_ascii=False)
                    for encoding in (False, True):
                        text = text.replace(json.dumps(old, ensure_ascii=encoding), replacement)
                public = text.encode()
                assert json.loads(public) == value, source
    write(destination, public)
    copied.add(str(source))
    ledger.append({'source': identity(source), 'destination': destination, 'original_bytes': len(original), 'original_sha256': digest(original), 'public_bytes': len(public), 'public_sha256': digest(public), 'byte_identical': original == public, 'changes': changes})


INDEX = json.loads((ROOT / 'artifact-public/results/EVIDENCE_INDEX.json').read_text())['archive_roots']
archives, opened = {}, {}
for key in ['Core', 'FixedSevenNative']:
    name = INDEX[key]['archive']
    path = ROOT / 'artifact-public/results/archives' / name
    archives[key] = {'archive': name, 'repository_path': 'results/archives/' + name, 'bytes': path.stat().st_size, 'sha256': digest(path.read_bytes())}
    opened[key] = zipfile.ZipFile(path)
PREFIX = 'seams2027-saved-evidence/package/base/evidence/'


def dependency(key, member, target, original_path):
    public = opened[key].read(member)
    original = Path(original_path).read_bytes()
    record = {'archive_id': key, 'archive_member': member, 'bytes': len(public), 'sha256': digest(public), 'restore_to': target, 'required_for_saved_checker': True, 'historical_source': identity(original_path), 'historical_bytes': len(original), 'historical_sha256': digest(original), 'historical_byte_identical': original == public}
    if original != public:
        a, b = json.loads(original), json.loads(public)
        differences = sorted(k for k in set(a) | set(b) if a.get(k) != b.get(k))
        assert differences == ['input'], (original_path, differences)
        aa, bb = dict(a['input']), dict(b['input'])
        aa.pop('path'); bb.pop('path')
        assert aa == bb
        record['difference_scope'] = 'Only input.path string and JSON serialization; all other parsed values equal.'
    deps.append(record)


for key, member, target, local in [
    ('Core', PREFIX + 'experiment/seams_research_reframing_20261017/kind_corpus_symbolic_independent/symbolic.py', 'checkers/symbolic.py', 'symbolic.py'),
    ('Core', PREFIX + 'experiment/seams_research_reframing_20261017/kind_corpus_symbolic_independent/vendor/bdd_core.py', 'checkers/vendor/bdd_core.py', 'vendor/bdd_core.py'),
    ('FixedSevenNative', 'fixed-seven-native/independent_auditor.py', 'checkers/prior_binding.py', 'prior_binding.py'),
]:
    dependency(key, member, target, BASE / 'independent_audit' / local)
take(BASE / 'independent_audit/audit_core.py', 'checkers/audit_core.py')

freeze = json.loads((BASE / 'preparation/ROSTER_FREEZE.json').read_text())
ids, modes = freeze['fixed_order'], freeze['modes']
assert len(ids) == 11 and len(modes) == 4
specs, armrows = {}, []
bdd_count = region_count = native_count = 0
for case in ids:
    config_file = BASE / 'preparation/case_configs' / (case + '.json')
    config = json.loads(config_file.read_text())
    take(config_file, 'provenance/case_configs/' + case + '.json')
    sourcefiles = [Path(config['saved_original_model']['path'])] + [Path(p['path']) for p in config['saved_original_predicates']]
    for source in sourcefiles:
        dependency('Core', PREFIX + identity(source), 'dependencies/prior_source/' + case + '/' + source.name, source)
    for source in config['source_and_imports']:
        rel = identity(source['path'])
        member = PREFIX + rel
        raw = opened['Core'].read(member)
        assert digest(raw) == source['sha256'] and len(raw) == source['bytes']
        upstream = rel.split('/kind_corpus/original/', 1)[1]
        specs[upstream] = {'upstream_member': upstream, 'bytes': len(raw), 'sha256': digest(raw), 'archive_id': 'Core', 'archive_member': member, 'restore_to': 'dependencies/source/' + upstream, 'required_for_saved_checker': False, 'license': 'BSD-3-Clause; exact notice in licenses/zenodo10553249-LICENSE.txt'}
    for mode, arm in zip(modes, 'ABCD'):
        native = BASE / 'preparation/execution' / case / mode / 'native_result'
        audit = BASE / 'independent_audit/cases' / case / mode
        result = json.loads((audit / 'AUDIT_RESULT.json').read_text())
        present = (native / 'RESULT.json').exists()
        row = {'case_id': case, 'mode': mode, 'arm': arm, 'audit_status': result['status'], 'accepted': result['status'] == 'PASS', 'native_candidate_present': present, 'native_candidate_is_independently_accepted': result['status'] == 'PASS', 'audit_result': 'expected/' + case + '/' + mode + '/AUDIT_RESULT.json', 'native_directory': 'native/' + case + '/' + mode if present else None, 'source_directory': 'dependencies/prior_source/' + case}
        take(audit / 'AUDIT_RESULT.json', row['audit_result'])
        if (audit / 'REGIONS.json.gz').exists():
            take(audit / 'REGIONS.json.gz', 'expected/' + case + '/' + mode + '/REGIONS.json.gz')
            region_count += 1
        if present:
            nr = json.loads((native / 'RESULT.json').read_text())
            assert nr['status'] == 'PASS_COMPLETE'
            row['native_status'] = nr['status']
            native_count += 1
            references = set()

            def collect(value):
                if isinstance(value, dict):
                    if isinstance(value.get('file'), str) and value['file'].endswith('.bdd'):
                        payload = (native / value['file']).read_bytes()
                        assert len(payload) == value['bytes'] and digest(payload) == value['sha256']
                        references.add(value['file'])
                    for item in value.values():
                        collect(item)
                elif isinstance(value, list):
                    for item in value:
                        collect(item)

            collect(nr)
            collect(json.loads((native / 'model.json').read_text()))
            for name in ['model.json', 'RESULT.json'] + sorted(references):
                assert Path(name).name == name
                take(native / name, 'native/' + case + '/' + mode + '/' + name)
                bdd_count += name.endswith('.bdd')
            checks.append({'case_id': case, 'mode': mode, 'referenced_BDD_count': len(references), 'all_references_present': True})
        else:
            assert case == 'corpus059__original' and mode == 'first_flip'
            row['native_status'] = 'NO_NATIVE_RESULT'
            row['missing_result_is_not_unrealizability'] = True
            take(native.parent / 'PROCESS.json', 'provenance/corpus059_first_flip_failure.json', projection=['schema', 'phase', 'status', 'id', 'mode', 'started_utc', 'finished_utc', 'limits', 'reasons', 'supervisor_exception', 'elapsed_seconds', 'returncode', 'max_sampled_rss_bytes', 'native_result_status', 'native_solver_calls', 'final_stored_sizes', 'capture_verification'])
        armrows.append(row)
assert native_count == 43 and region_count == 40 and sum(r['accepted'] for r in armrows) == 40

for name in ['FINAL_COHORT_SUMMARY.json', 'FINAL_COHORT_TABLE.csv']:
    take(BASE / 'independent_audit' / name, 'summary/' + name)
take(BASE / 'preparation/ROSTER_FREEZE.json', 'provenance/ROSTER_FREEZE.json')
take(BASE.parent / 'experiment_strategy/SMALL_REMAINING_HELPER_COHORT_CANDIDATE.json', 'provenance/SELECTION_CANDIDATE.json')
take(ROOT / 'artifact-public/LICENSE', 'LICENSE-original.txt')
take(ROOT / 'artifact-public/docs/licenses/zenodo10553249-LICENSE.txt', 'licenses/zenodo10553249-LICENSE.txt')
write('COHORT_INDEX.json', dump({'schema': 'v71-aa-private-preparation-index-v1', 'publication_status': 'PRIVATE_STAGING_ONLY', 'adopted_scope': 'r3 fixed saved-evidence claims; no new outcomes', 'registered_source_count': 11, 'registered_arm_count': 44, 'native_candidate_count': 43, 'independent_PASS_count': 40, 'UNKNOWN_count': 4, 'missing_native_result_count': 1, 'new_scientific_executions': 0, 'rows': armrows}))
write('SOURCE_RESTORATION.json', dump({'schema': 'v71-aa-source-restoration-v1', 'status': 'STATIC_PREPARATION_NOT_EXECUTED', 'archive_count_existing_public_set': 17, 'required_archive_count_for_this_closure': 2, 'archive_reference_base': 'Existing artifact repository; no archive duplication in this staging tree.', 'archives': archives, 'dependencies': deps, 'corpus_source_references': list(specs.values()), 'upstream_corpus': {'record_url': 'https://zenodo.org/records/10553249', 'archive_url': 'https://zenodo.org/api/records/10553249/files/artifact.zip/content', 'bytes': 47253431, 'sha256': '65abe41fcca3694a31967d409e642cb2b5785156aed5f464db380c7e3bb98712', 'operation': 'Extract only the listed upstream_member paths and verify bytes/hash. No source modifications.', 'license_notice': 'licenses/zenodo10553249-LICENSE.txt'}, 'not_required_for_saved_checker': ['Spectra/JDK/JTLV runtime, JARs, compiled classes, original source specifications, native-generation wrappers, original authorization and reservation records', 'Earlier symbolic certificate and derived regions named in historical case configs; retained prior-outcome counts are selection context, not saved-checker inputs.'], 'restoration_execution': 'No extraction into this stage, downloads, import, checker invocation, native invocation or compile was performed.'}))

write('replay_saved.py', b'''"""Prepared saved-data checker entry point; no native calls. Not run for packaging."""
import argparse
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "checkers"))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("case")
    parser.add_argument("mode", choices=["original", "syntactic", "first_flip", "complete"])
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    rows = json.loads((HERE / "COHORT_INDEX.json").read_text())["rows"]
    matches = [r for r in rows if r["case_id"] == args.case and r["mode"] == args.mode]
    if len(matches) != 1 or not matches[0]["accepted"]:
        parser.error("Only 40 historically accepted arms are eligible; UNKNOWNs remain UNKNOWN.")
    if args.output.exists() or args.output.resolve().is_relative_to(HERE):
        parser.error("Output must be a new directory outside this evidence tree.")
    row = matches[0]
    import audit_core
    native = HERE / "native" / args.case
    result = audit_core.audit_arm(HERE / row["source_directory"], native / "original",
                                 native / args.mode, row["arm"], args.output,
                                 native / "syntactic" if args.mode == "first_flip" else None)
    return 0 if result["status"] == "PASS" else 2

if __name__ == "__main__":
    raise SystemExit(main())
''')

write('README.txt', b'''AA COMPILED COHORT: PRIVATE PUBLICATION PREPARATION

This is an unpublished static staging tree for the fixed r3 saved-evidence scope.
It registers 11 sources and 44 arms: 43 saved native candidates, 40 independently
accepted PASS arms, and four preserved UNKNOWN arms. Corpus003 B/C/D have saved
native candidates but no accepted independent result (BDD node budget refusal).
Corpus059 C has no native result; its supervisor failure is not unrealizability.
No new experiment, solver, replay, compile, native execution, GUI, or download was
performed to prepare this tree. No public repository was changed or pushed.

COHORT_INDEX.json navigates the 44 arms. summary/ preserves the saved independent
cohort summary. native/ contains only the JSON/model/BDD dependency closure of 43
saved candidates; expected/ contains all 44 audit verdicts and 40 exact saved
canonical-region gzip payloads. All .bdd and .json.gz bytes are unchanged. JSON
location strings are anonymized; numbers, arrays, field encodings, relations,
region digests, statuses, and scientific values remain unchanged. Model exports
retain parsed/translated formula inventories as saved research outputs.

Historical hashes inside copied records still identify the original execution
files. They are not hashes of anonymized public metadata. The per-file and
per-pointer TRANSFORMATION_LEDGER.json records original versus staged identities.
Historical location strings are provenance identities, not runtime file paths.
MANIFEST.json binds final staged payload; its own hash is separately reported.

SOURCE_RESTORATION.json identifies exact members of two existing archives from
the 17-archive public set. Restore required dependencies to each restore_to path:
Core provides 11 saved source primitive bundles, symbolic.py and bdd_core.py;
FixedSevenNative provides byte-identical prior_binding.py. Archive SHA-256 and
member SHA-256 must both match. Old source model public copies differ only in
input.path and serialization; all remaining parsed values match their historical
counterparts. Corpus source/import text is referenced, not duplicated; exact
upstream archive/member/hash and the original BSD notice are supplied. No
third-party paper, unlicensed source text, runtime, JAR or compiled class is here.

replay_saved.py is a newly prepared relative-path adapter, not a previously
executed receipt. It exposes only the 40 accepted arms after dependency restoration
and keeps all four UNKNOWN arms outside replay. The unchanged audit_core.py
implements the saved-data check. Its transitive modules are archive references.
The adapter and imports were inspected statically only; no relocated or fresh-host
qualification has occurred. Python 3.9+ syntax is used. An external supervisor
would be needed to recreate historical wall/RSS limits for any future execution.
No new execution is authorized or claimed by this preparation. build_staging.py
is the static packaging recipe, not a scientific runner or a restoration helper.

OMITTED_FILES.json accounts for private authorizations/reservations, control and
review records, compiled/cache files, duplicate captures, intermediate snapshots,
producer orchestration and qualification branches outside the minimal saved-claim
closure. Native regeneration is outside this package scope. Historical case
configs also refer to earlier symbolic certificates and canonical regions; those
prior outcomes informed selection but are not consumed by the saved checker.

Original contributions use LICENSE-original.txt; corpus-derived exported metadata
retains the attribution in licenses/zenodo10553249-LICENSE.txt. The license does
not extend to omitted externally obtained dependencies. Remaining gate: independent
static review of packaging. This tree is not published and claims no reader replay.
''')

for p in sorted(BASE.rglob('*')):
    if not p.is_file() or str(p) in copied:
        continue
    r = str(p.relative_to(BASE))
    if p.suffix in ('.class', '.pyc') or '__pycache__' in p.parts:
        reason = 'COMPILED_OR_CACHE_EXCLUDED'
    elif 'ROOT_' in p.name or 'RESERV' in p.name or 'AUTHORIZ' in p.name:
        reason = 'PRIVATE_AUTHORIZATION_OR_RESERVATION_EXCLUDED'
    elif 'snapshot' in r or 'pre_intervention' in r:
        reason = 'INTERMEDIATE_SNAPSHOT_OUTSIDE_MINIMAL_CLOSURE'
    elif '/execution/' in str(p) and p.name in ('stdout.jsonl', 'stderr.txt', 'PROCESS.json', 'CAPTURE_VERIFICATION.json', 'EXACT_DIAGNOSTIC_RECEIPT.json'):
        reason = 'DUPLICATE_CAPTURE_OR_CONTROL_RECORD_OUTSIDE_MINIMAL_CLOSURE'
    elif 'qualification' in r.lower():
        reason = 'QUALIFICATION_BRANCH_OUTSIDE_FIXED_44_CLOSURE'
    elif 'producer_summary' in r:
        reason = 'REDUNDANT_PRODUCER_AGGREGATION_OUTSIDE_INDEPENDENT_CLOSURE'
    elif any(d['historical_source'] == identity(p) for d in deps):
        reason = 'EXISTING_PUBLIC_ARCHIVE_DEPENDENCY_NO_DUPLICATE'
    else:
        reason = 'CONTROL_PROVENANCE_OR_UNUSED_FILE_OUTSIDE_MINIMAL_SAVED_CLAIM_CLOSURE'
    raw = p.read_bytes()
    omitted.append({'source': identity(p), 'bytes': len(raw), 'sha256': digest(raw), 'reason': reason})
write('OMITTED_FILES.json', dump({'schema': 'v71-aa-omissions-v1', 'files': omitted, 'missing_native_result': 'corpus059__original first_flip: no RESULT.json existed; not an omission.'}))
write('TRANSFORMATION_LEDGER.json', dump({'schema': 'v71-aa-transformations-v1', 'original_files_edited': False, 'historical_pin_policy': 'Existing inner bytes/SHA-256 values are historical and never rebound silently to staged copies.', 'rules': {'LOCAL_LOCATION_TO_HISTORICAL_ID': 'Replace host project root by historical: and retain project-relative suffix; other host paths become external-runtime basename.', 'SELECT_SCIENTIFIC_FAILURE_FIELDS': 'Retain named scientific failure fields; omit private authority, process ownership and command/runtime details.'}, 'copied_files': ledger, 'new_files': ['README.txt', 'COHORT_INDEX.json', 'SOURCE_RESTORATION.json', 'OMITTED_FILES.json', 'TRANSFORMATION_LEDGER.json', 'PRIVACY_SCAN.json', 'STATIC_VALIDATION.json', 'MANIFEST.json', 'replay_saved.py', 'build_staging.py'], 'code_changes': [{'path': 'replay_saved.py', 'kind': 'NEW_UNEXECUTED_RELATIVE_PATH_ADAPTER', 'scientific_core_changed': False, 'source_core': 'checkers/audit_core.py', 'unknown_arms_excluded': True, 'nonPASS_exit_nonzero': True}, {'path': 'build_staging.py', 'kind': 'NEW_STATIC_PACKAGING_RECIPE', 'scientific_execution': False}]}))
for record in ledger:
    assert digest((ROOT / record['source']).read_bytes()) == record['original_sha256']
    assert digest((STAGE / record['destination']).read_bytes()) == record['public_sha256']
for record in omitted:
    assert digest((ROOT / record['source']).read_bytes()) == record['sha256']
for record in deps:
    if record['restore_to'].endswith('.py'):
        ast.parse(opened[record['archive_id']].read(record['archive_member']))
write('STATIC_VALIDATION.json', dump({'schema': 'v71-aa-static-validation-v1', 'status': 'PASS_STATIC_ONLY', 'registered_arms': len(armrows), 'native_candidates': native_count, 'accepted_arms': sum(r['accepted'] for r in armrows), 'unknown_arms': sum(not r['accepted'] for r in armrows), 'exact_BDD_files': bdd_count, 'exact_region_gzip_files': region_count, 'archive_member_references': len(deps), 'archive_references_checked_by_bytes_hash': True, 'native_BDD_reference_hashes_checked': True, 'copied_originals_unchanged': len(ledger), 'omitted_originals_unchanged': len(omitted), 'anonymization_scope': 'JSON string literals only; all non-location serialized bytes unchanged, except the expressly projected failure record.', 'source_model_public_differences': 'input.path only; other parsed values equal', 'native_BDD_closure': checks, 'checker_execution_count': 0, 'native_execution_count': 0, 'compiled_modules': 0, 'code_syntax': 'AST parsing only, including archive-referenced checker imports; no import/exec/compile', 'runtime_qualification': 'NOT_PERFORMED', 'remaining_blockers': ['Unpublished staging; publication requires parent release workflow.', 'Relocated/fresh-host replay has not been run or authorized.', 'Restoration dependencies intentionally referenced, not materialized.']}))

patterns = {'local_user_root': re.compile(rb'/(?:Users|home)/[^/\s]+'), 'account_identifier': re.compile(re.escape(Path.home().name).encode(), re.I), 'private_url_scheme': re.compile(rb'(?:file|vscode)://'), 'secret_material': re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{20,}|sk-proj-[A-Za-z0-9_-]{20,}')}
hits = []
scan_count = gzip_count = 0
for p in sorted(STAGE.rglob('*')):
    if not p.is_file() or p.name in ('MANIFEST.json', 'PRIVACY_SCAN.json'):
        continue
    raw = p.read_bytes()
    scan_count += 1
    if p.suffix == '.gz':
        raw = gzip.decompress(raw)
        gzip_count += 1
    for rule, pattern in patterns.items():
        if pattern.search(raw):
            hits.append({'file': str(p.relative_to(STAGE)), 'rule': rule})
    if p.suffix == '.py':
        ast.parse(raw)
assert not hits, hits
write('PRIVACY_SCAN.json', dump({'schema': 'v71-aa-privacy-scan-v1', 'status': 'PASS_STATIC_SCAN', 'files_scanned': scan_count, 'gzip_payloads_decoded': gzip_count, 'rules': list(patterns), 'hits': hits, 'excluded_content_types': ['private authorization and reservation files', 'compiled/cache files', 'third-party papers', 'upstream runtime binaries'], 'scope': 'All staged payloads before this report and final manifest; generator metadata contains only relative identities. Existing external archives were not repackaged or requalified.'}))
manifest = []
for p in sorted(STAGE.rglob('*')):
    if p.is_file() and p.name != 'MANIFEST.json':
        raw = p.read_bytes()
        manifest.append({'path': str(p.relative_to(STAGE)), 'bytes': len(raw), 'sha256': digest(raw)})
write('MANIFEST.json', dump({'schema': 'v71-aa-staged-manifest-v1', 'status': 'PRIVATE_UNPUBLISHED_STATIC_PREPARATION', 'self_excluded': True, 'file_count': len(manifest), 'bytes_total': sum(x['bytes'] for x in manifest), 'files': manifest}))
print(json.dumps({'stage': identity(STAGE), 'files': len(manifest) + 1, 'bytes_in_manifest': sum(x['bytes'] for x in manifest), 'bdd_files': bdd_count, 'regions': region_count, 'dependencies': len(deps), 'spec_references': len(specs), 'omitted_files': len(omitted), 'transformed_files': sum(not x['byte_identical'] for x in ledger), 'manifest_sha256': digest((STAGE / 'MANIFEST.json').read_bytes())}, indent=2))
