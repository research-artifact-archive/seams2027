Historical report on the unchanged Patrolling input

This archive preserves the historical Patrol evidence and its source bindings.
This is a provenance and static-inspection supplement, not a new experiment.
No artifact execution, native call, bytecode disassembly or download occurred
during this packaging work. Third-party source, README, JAR, DLL, class and
publisher documents are omitted; SOURCE_RESTORATION.json gives exact pins.

The original Kind artifact reports, on CSV line 40:
  Filename,4FP,R+4FP
  1670358790.spectra,TRUE,FALSE
The unchanged source hash matches corpus277__original. R+4FP means reduction
plus four fixed points; it is not the manuscript's preserving R^+ construction.
The archive README identifies both columns as algorithm realizability outputs.

historical/ORIGINAL_ARTIFACT_PATROL_EVIDENCE.json binds the source, archive and
named CSV/README members. historical/AUDIT.json and REPORT.txt contain the
previously saved static interpretation of the packaged Java driver. The
dedicated true,false branch follows two Boolean checkRealizability answers;
caught exceptions have a separate record. The Java path has no timeout-to-
false branch. This does not determine the native cause of the historical false.

The historical driver changes ENV SAFETY to STATE_INV, runs DefaultTranslators,
then reduction, and uses CUDD 3.0/SIFT/optimized four-fixed-point games. Its
loaded-factory/runtime identity was not recorded. The archive CSV has uppercase
Booleans while the packaged driver emits lowercase. Therefore the row is
historical reported data, not a byte-identical raw execution receipt, and it
does not establish equivalence to the present fixed-option diagnostic harness.
No GUI/default, strict-semantic-cause or comparative timing conclusion follows.

All included records are the original authored analyses or location-only
metadata derivatives. TRANSFORMATION_LEDGER.json binds both identities;
embedded historical hashes continue to describe the original records.
References to withheld bytecode/disassembly are historical evidence pins,
not files claimed to be included. Follow SOURCE_RESTORATION.json to inspect
the original archive independently under its distributor's terms.

Static verification, with no scientific imports:
  python3 -I -S -B verify_candidate.py
This separate archive does not modify any of the 17 preexisting public scientific
archives and adds no execution of the historical artifact.

Packaging history
Historical records retain their original preparation statuses, including private
staging labels. Those labels describe the time of those records. The current
README and PUBLIC_PACKAGING_AMENDMENT.json describe the packaging-only changes.
Scientific values, UNKNOWN outcomes and historical receipt statuses are unchanged.
