# Third-party scope

The included original analysis and documentation retain LICENSE-original.txt.
The historical Kind artifact is distributed independently from
https://zenodo.org/records/10553249 by its original authors. The record lists
artifact.zip and a separate LICENSE.txt. This candidate redistributes neither
the source specification, archive README, JAR/class/native code nor paper.
SOURCE_RESTORATION.json identifies exact hashes and archive members for readers
who acquire them under the distributor's terms. Historical reported Boolean
values and authored static-analysis descriptions are preserved as evidence.
