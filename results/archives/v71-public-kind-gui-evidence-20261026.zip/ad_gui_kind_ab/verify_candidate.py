#!/usr/bin/env python3
"""Static file, metadata, privacy and syntax checks. No scientific code imports."""
import ast,base64,gzip,hashlib,json,re
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parent

def need(ok,label):
 if not ok:raise ValueError(label)
def digest(raw):return hashlib.sha256(raw).hexdigest()
def local(relative):
 p=PurePosixPath(relative);need(not p.is_absolute() and '..' not in p.parts and '\\' not in relative,'unsafe package path')
 result=ROOT.joinpath(*p.parts);need(result.resolve().is_relative_to(ROOT) and not result.is_symlink(),'escaping package path');return result

def sibling(relative,packages=('ac_obstacle8cert98',)):
 p=PurePosixPath(relative);need(len(p.parts)>=3 and p.parts[0]=='..' and p.parts[1] in packages and '..' not in p.parts[2:] and '\\' not in relative,'unsafe declared dependency path')
 result=ROOT.parent.joinpath(*p.parts[1:]);need(result.resolve().is_relative_to(ROOT.parent/p.parts[1]) and not result.is_symlink(),'escaping sibling path');return result

def check_pin(path,ref):
 raw=path.read_bytes();need(len(raw)==ref['bytes'] and digest(raw)==ref['sha256'],'pin mismatch: '+path.name);return raw

def refs(value):
 if isinstance(value,dict):
  if isinstance(value.get('file'),str) and value['file'].endswith('.bdd'):yield value
  for x in value.values():yield from refs(x)
 elif isinstance(value,list):
  for x in value:yield from refs(x)

def scan(text,label):
 private=re.compile('/'+'Users'+r'/[^/\s]+|/'+r'home/[^/\s]+')
 uuid=re.compile(r'\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b',re.I)
 token=re.compile(r'\b(?:ghp|github_pat|sk-proj)[_-][A-Za-z0-9_-]{15,}\b')
 need(not private.search(text),'personal path: '+label);need(not uuid.search(text),'private identifier: '+label);need(not token.search(text),'targeted credential pattern: '+label)

def main():
 manifest=json.loads((ROOT/'MANIFEST.json').read_text());rows=manifest['files'];names={r['path'] for r in rows};need(len(names)==len(rows),'duplicate manifest member')
 actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p.name!='MANIFEST.json'};need(actual==names,'manifest roster differs')
 bdd_count=python_count=base64_count=0
 for row in rows:
  path=local(row['path']);raw=check_pin(path,row)
  need(path.suffix not in {'.png','.jpg','.jpeg','.pdf','.jar','.class','.dylib','.dll','.pyc','.spectra','.spectraArxived'},'forbidden redistributed member')
  need(not any(token in path.name.upper() for token in ['LSOF','RAW_AX','GUI_FIRST_RESULT','ROOT_SCIENCE_GO']),'private raw/control member')
  plain=gzip.decompress(raw) if path.suffix=='.gz' else raw;text=plain.decode('utf-8',errors='replace');scan(text,row['path'])
  if path.suffix=='.py':ast.parse(text,filename=row['path']);python_count+=1
  if path.suffix=='.jsonl':
   for line in text.splitlines():
    obj=json.loads(line)
    if isinstance(obj.get('data'),str):scan(base64.b64decode(obj['data'],validate=True).decode('utf-8',errors='replace'),row['path']+' decoded');base64_count+=1
  if path.suffix=='.json' and path.name in {'model.json','RESULT.json'} and 'native_result' in path.parts:
   for ref in refs(json.loads(raw)):
    need(Path(ref['file']).name==ref['file'],'unsafe BDD member');check_pin(path.parent/ref['file'],ref);bdd_count+=1
 deps=json.loads((ROOT/'DEPENDENCIES.json').read_text());seen=set()
 for row in deps['files']:
  need(row['path'] not in seen,'duplicate sibling dependency');seen.add(row['path']);check_pin(sibling(row['path']),row)
 check_pin(sibling(deps['AC_manifest']['path']),deps['AC_manifest'])
 baseline=json.loads((ROOT/'EXISTING_PACKAGE_BASELINES.json').read_text())
 for row in baseline['manifests']:check_pin(sibling(row['path'],('aa_compiled44','ac_obstacle8cert98','z_historical_patrol')),row)
 for row in json.loads((ROOT/'TRANSFORMATION_LEDGER.json').read_text())['files']:
  check_pin(local(row['public_path']),row['public'])
  if row['disposition']=='byte_preserved':need(row['public']==row['original'],'byte-preserved identity differs')
 for letter,ms in [('A',1011),('B',745)]:
  data=json.loads((ROOT/'gui'/letter/'RESULT.json').read_text());need(data['status']=='COMPLETE_FALSE' and data['boolean_answer'] is False and data['scientific_action_count']==1,'GUI outcome scope');need(data['plugin_reported_timing_ms']['computation']==ms,'GUI reported time')
 need(json.loads((ROOT/'preparation/EXPORT_SUPERVISOR_PUBLIC.json').read_text())['status']=='UNKNOWN_SUPERVISOR_EXCEPTION','original export supervisor status')
 need(json.loads((ROOT/'preparation/SAVED_GATE_ADOPTION.json').read_text())['status']=='ADOPT_SEPARATE_SAVED_PREDICATE_GATE_ONLY','separate gate status')
 config=json.loads((ROOT/'SAVED_PREDICATE_INPUTS.json').read_text())
 for key in ['fresh_model','fresh_result','prior_source_model','prior_helper_model']:
  row=config[key];check_pin(sibling(row['path']) if row['path'].startswith('../') else local(row['path']),row)
 plan=json.loads((ROOT/'SOURCE_RESTORATION.json').read_text());append=plan['fixed_B_appendix'];check_pin(local(append['path']),append)
 need(append['bytes']==124 and append['output_bytes']==2026,'point appendix scope')
 for row in plan['members']:need(not local(row['restore_to']).exists() and not local(row['project_to']).exists(),'third-party source unexpectedly restored')
 print(json.dumps({'status':'PASS_STATIC_CANDIDATE_ONLY','files_verified':len(rows),'sibling_dependency_files_verified':len(seen),'existing_package_manifests_verified':len(baseline['manifests']),'BDD_pin_references_verified':bdd_count,'Python_files_syntax_parsed':python_count,'Base64_chunks_privacy_scanned':base64_count,'privacy':'PASS_LIMITED_STATIC_SCAN','scientific_module_imports':0,'BDD_operations':0,'fixed_point_CPre_model_solver_calls':0,'Java_or_compile_calls':0,'source_restore_or_network_calls':0,'relocated_or_fresh_host_replay':False},indent=2))

if __name__=='__main__':main()
