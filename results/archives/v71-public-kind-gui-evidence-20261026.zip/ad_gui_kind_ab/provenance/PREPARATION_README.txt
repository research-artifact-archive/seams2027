PUBLIC GUI KIND A/B: ANONYMOUS SAVED-EVIDENCE ADDITION

This is an unpublished static publication candidate for the later v71-r4
observations. ad_gui_kind_ab is a technical package identifier, not a final
manuscript appendix number. Manuscript navigation must follow the final paper.
No Java, compiler, model generator, solver, fixed point, CPre, scientific replay,
source restoration or network access was performed to assemble this candidate.
Existing AA, AC, Z, scientific originals and the public repository were not edited.

Read SCIENTIFIC_DISPOSITION.json, gui/A/RESULT.json and gui/B/RESULT.json first.
The two fixed, single-attempt public Check Realizability actions returned false:
  A: unchanged published old source and its original initialization; 1011 ms.
  B: updated ordinary projection plus the disclosed 124-byte point initializer
     at r2404=(obstacle0=3, obstacle1=5, obsWait=true, robot0=5, robot1=5); 745 ms.
Both used release 1.0.0.202402072123, selected Kind/synthesisPitermanReduction,
JTLV, no optimizations and no reorder. The selected public Kind checking path
uses PitermanSyntacticReduction followed by GR1SeparatedGame. The observed
console identified GR1SeparatedGame and JTLVJavaFactory 1.3. Each public action ran once: two total,
no retries or controller extraction. These are selected nondefault settings.
The reported times are plugin diagnostics, not comparative performance data.

Source strict-winning existence comes from the separately accepted AC source
certificates. theory/SOURCE_KIND_LEMMA.txt supplies the adopted mathematical
bridge to source-kind existence: next-SYS-independent ENV safety, ENV totality
at every typed state, empty/true ENV justice, and a typed-total completion of the
same residual SYS strategy that preserves its original strict obligations.
The lemma retains the whole history and does not reset private memory. It does
not apply to the transformed helper game, whose ENV justice includes GF(!h).
Q from the public four-fixed-point solver is not identified with strict W or
legal-prefix K. In preserved historical records, the shorthand R+4FP means
syntactic reduction followed by four fixed points; it is not the paper's
complete semantic correction R^+. Maintained package guidance uses the
explicit selected-path names. An all-state GUI Q was not exported.

The narrow decision consequence is conditional: if this selected public path
is used as a source-level continuation-feasibility gate, its false answer would
reject the separately proved feasible continuation at the fixed state. No actual
deployed adaptation rejection was observed. B is a new point-initialized query,
not the unchanged public update text or a live switch of a running controller.
Private controller memory is unrecorded, not zero. No controller extraction,
installation, memory transfer or end-to-end adaptation execution is claimed.
A is already false; the update is not shown to create the obstruction. This
comparison does not establish a particular internal defect as its exclusive
cause, or the tool authors' intended contract. No default/all-backend, incidence,
robustness, general repair or performance conclusion follows.

Three distinct evidence layers
1. GUI observations. Authored result derivatives, independent completion-audit
   subsets, manually transcribed seven-line consoles, and byte-preserved logger
   XML records are in gui/A and gui/B. Each transcription was read from the
   original unedited screenshot; it is not an AX-exported console or a raw
   workbench stdout/stderr capture. Raw screenshots and AX are intentionally
   withheld for anonymous publication. The logger action ID and Done false
   records corroborate the action. A retained two source snapshots, at start
   and done. B's append-mode XML has both records using one integer-second
   name and one final archived source snapshot: do not infer two independent
   B snapshots. Source text is omitted; exact hashes remain. Sampled RSS is
   reported as sampled RSS, not an instantaneous peak. The whole workbench
   stdout/stderr was not captured.
2. B preparation. One no-solver Java model export finished its own checks and
   teardown, but the external supervisor encountered a final-snapshot process
   exit race. preparation/EXPORT_SUPERVISOR_PUBLIC.json remains
   UNKNOWN_SUPERVISOR_EXCEPTION; OS exit code was not recorded and is not
   reconstructed as zero. No additional export/compile attempt followed.
3. Separate saved predicate gate. preparation/SAVED_EXPORT_VERIFICATION.json
   records independently compared saved Boolean predicates: full rhoE/rhoS,
   domains, four helper quadrants, ordered justice, source00 and exact nonempty
   point initializers. preparation/SAVED_GATE_ADOPTION.json adopts only that
   separate mathematical input-binding gate, before GUI B. The historical
   258-check report includes one process-absence check; the separate root
   saved-data recheck reports 257 checks plus 55 input pins. It does not turn
   the supervisor into PASS. NoIDE used Java 17.0.19 and a file-URI standalone
   provider; GUI used Eclipse Java 17.0.9 and a project/platform-URI provider.
   Shared pinned translator code is not an observed equality of live GUI and
   NoIDE model exports. This boundary remains explicit.

The mathematical lemma adoption predates A/B. Its historical 'claims not
adopted' concern that earlier lemma-only stage. Similarly the preserved B
preparation handoff was ready for a later adoption decision. Later GUI results
and SCIENTIFIC_DISPOSITION supply the subsequent observations; historical
statuses are not rewritten. AC still retains eight earlier independent fixed-
point UNKNOWNs (two source/original plus six helper arms), the initial separate
certificate serialization UNKNOWN and seven then-unattempted slots, and the
later eight theorem-based saved certificates. These are different histories.

Layout and dependencies
Keep this directory beside the unchanged ac_obstacle8cert98 directory. Every
required sibling path in DEPENDENCIES.json is an actual file with its current
size/hash; its MANIFEST is pinned. No existing evidence archive is duplicated.
AC supplies prior new source/helper predicates, old/new source results and saved
games, the old-only seven-edge prefix, all98 membership/summary, and prior
UNKNOWN history. New B primitive BDDs in preparation/export/native_result retain
exact bytes. JSON location changes are derivatives. The original and current
identities, declared field subsets and individual location changes are recorded
in TRANSFORMATION_LEDGER.json. Historical hashes inside records still refer to
historical execution files, not automatically to relocated metadata. MANIFEST
binds this current candidate; DEPENDENCIES binds current AC metadata.

Reconstruction and code
SOURCE_RESTORATION.json gives the official 6,517-byte ZIP URL, member hashes,
45-byte metadata projection and exact 124-byte appendix. Only our appendix is
included. The upstream ZIP had no identified license/readme/notice member;
no .spectra, .spectraArxived, publisher paper, JAR, class or native runtime is
redistributed. Independently obtain sources under their distributor's terms,
verify every archive/member hash, apply the stated projection, append the
provided bytes, and verify the 2,026-byte B hash. No restoration has been run.
RUNTIME_RESTORATION.json lists release JAR/member pins and the selected runtime
and settings. It is not a fully restored host image. The pre-action release
record distinguishes installed byte identity, registration and open handles
from actual class definitions, provider instances and method-call traces.

inspection/ contains the historical guard, bounded preparation supervisor,
producer/serializer/capture and saved predicate checker source for inspection.
Their original private layout/control/runtime dependencies are not shipped;
these historical programs are not advertised as portable entrypoints.
checkers/check_saved_predicates.py is a newly authored relative-path adapter for
future explicit use with this candidate and its sibling AC. It checks saved
predicates only, writes to a new output outside both evidence directories, and
has NOT been executed here. It is not native regeneration or external replay.

Static integrity only
  python3 -I -S -B verify_candidate.py
This verifies the exact manifest, current AC dependency pins, BDD file-reference
hashes, safe paths, Python syntax and a limited privacy scan including gzip and
Base64 diagnostic chunks. It imports no scientific checker and performs no
BDD operation. STATIC_VALIDATION.json records static assembly checks only.
Neither this candidate nor its checker adapter has had relocated/fresh-host
scientific replay. Original contributions use LICENSE-original.txt; rights to
externally obtained material remain with its distributor.
