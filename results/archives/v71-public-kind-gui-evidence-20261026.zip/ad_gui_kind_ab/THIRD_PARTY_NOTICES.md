Third-party material and original contributions

The original code, documentation and generated research outputs in this candidate
use LICENSE-original.txt. This does not grant rights to external software, source
specifications or literature.

The Obstacle inputs are identified by the official distributor ZIP and exact
member hashes in SOURCE_RESTORATION.json. No source or archived source text is
redistributed. Only the authored 124-byte point-query appendix is included.
Machine-generated parsed inventories and primitive BDDs are saved research outputs.

Spectra/Eclipse/Java artifacts and the Kind publisher PDF are not bundled.
RUNTIME_RESTORATION.json and PRIMARY_REFERENCES.json identify them for independent
acquisition under their own terms. The existing sibling AC package retains its
own notices and provenance. No new network acquisition occurred during packaging.
