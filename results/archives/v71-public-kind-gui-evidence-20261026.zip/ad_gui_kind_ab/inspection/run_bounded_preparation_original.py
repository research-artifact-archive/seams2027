#!/usr/bin/env python3
"""One serial compile or one no-solver export under root's fixed preparation scope."""
import argparse,datetime,hashlib,importlib.util,json,os,signal,subprocess,threading,time
from pathlib import Path
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('owned_guard',P/'owned_eclipse_guard.py')
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def put(path,value):
    temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');temp.replace(path)
def check(pin):
    path=Path(pin['path']);g.require(path.stat().st_size==pin['bytes'] and sha(path)==pin['sha256'],'Pin mismatch '+str(path))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['compile','export']);a=ap.parse_args()
    authority=json.loads((P/'ROOT_MESSAGE_PREPARATION_SCOPE.json').read_text())
    g.require(authority['status']=='AUTHORIZED_PREPARATION_ONLY_AFTER_A_COMPLETE','Wrong preparation scope')
    for pin in authority['pins']:check(pin)
    a_monitor=json.loads(Path(authority['A_completion']['path']).read_text())
    g.require(a_monitor['status']=='FINISH_REPORTED_BY_ROOT_NO_SIGNAL','A not complete')
    plan=json.loads((P/'PREPARATION_COMMANDS.json').read_text());step=plan[a.stage]
    if a.stage=='export':
        prev=json.loads((P/'runs/compile/SUPERVISOR_RESULT.json').read_text())
        g.require(prev['status']=='COMPLETE_COMPILE','Compile gate failed')
    output=P/'runs'/a.stage;output.mkdir(parents=True,exist_ok=True)
    with (output/'RESERVATION.json').open('x') as stream:json.dump({'stage':a.stage,'attempt':1,'created_utc':now(),'scope_sha256':sha(P/'ROOT_MESSAGE_PREPARATION_SCOPE.json')},stream)
    lock=P/'LOCK_B_PREPARATION.json'
    with lock.open('x') as stream:json.dump({'stage':a.stage,'supervisor_pid':os.getpid(),'created_utc':now()},stream)
    state={'schema':'v71-bounded-no-solver-preparation-v1','stage':a.stage,'status':'STARTING','created_utc':now(),'argv':step['argv'],'limits':plan['limits'],'signals':[],'peak_rss_bytes':0,'solver_calls':0,'fixed_point_calls':0,'controller_extraction_calls':0}
    proc=None;threads=[];failure=threading.Event();stream_sizes={'stdout':0,'stderr':0};known={};root=None;reason=None;began=time.monotonic();limit=plan['limits']
    def reader(pipe,name):
        try:
            with (output/(name+'.txt')).open('wb') as out:
                while True:
                    chunk=pipe.read(65536)
                    if not chunk:break
                    before=stream_sizes[name];stream_sizes[name]+=len(chunk)
                    allowed=max(0,limit['per_stream_bytes']-before)
                    out.write(chunk[:allowed])
                    if stream_sizes[name]>limit['per_stream_bytes']:failure.set()
        except Exception as exc:
            state[name+'_capture_error']=repr(exc);failure.set()
        finally:pipe.close()
    def stop_owned():
        nonlocal reason
        targets=list(known.values())
        if root is not None and root['pid'] not in known:targets.append(root)
        if not targets:
            # Popen retains ownership of this unreaped direct child; no arbitrary PID tree.
            if proc.poll() is None:proc.terminate();state['signals'].append({'pid':proc.pid,'action':'SIGTERM_OWN_DIRECT_CHILD_NO_KERNEL_ID'})
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill();state['signals'].append({'pid':proc.pid,'action':'SIGKILL_OWN_DIRECT_CHILD_NO_KERNEL_ID'});proc.wait(timeout=5)
            return
        for sig,grace in [(signal.SIGTERM,5),(signal.SIGKILL,2)]:
            state['signals'].extend(g.signal_targets(targets,proc.pid,sig))
            end=time.monotonic()+grace
            while time.monotonic()<end:
                remaining=[]
                for old in targets:
                    actual=g.identity(old['pid'])
                    if actual is not None:
                        g.require(g.same_process(old,actual),'Identity changed during preparation cleanup')
                        remaining.append(old)
                if not remaining:return
                targets=remaining;time.sleep(.1)
        raise RuntimeError('Owned preparation process stop unconfirmed')
    try:
        proc=subprocess.Popen(step['argv'],cwd=P,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        state['pid']=proc.pid;root=g.identity(proc.pid)
        if root is not None:known[root['pid']]=root;state['owned_root']=root
        for name,pipe in [('stdout',proc.stdout),('stderr',proc.stderr)]:
            t=threading.Thread(target=reader,args=(pipe,name),daemon=True);t.start();threads.append(t)
        put(output/'SUPERVISOR_RESULT.json',state)
        while proc.poll() is None:
            elapsed=time.monotonic()-began
            if failure.is_set():reason='output_capture_or_size'
            elif elapsed>=limit['wall_seconds']:reason='wall_seconds'
            if root is not None:
                snap=g.snapshot(root);state['last_snapshot']=snap;known.update({x['pid']:x for x in snap['processes']})
                state['peak_rss_bytes']=max(state['peak_rss_bytes'],snap['rss_bytes'])
                if snap['rss_bytes']>limit['rss_bytes']:reason='rss_bytes'
            count=total=0
            for dirpath,dirs,files in os.walk(output,followlinks=False):
                for name in dirs:
                    if (Path(dirpath)/name).is_symlink():raise RuntimeError('Output symlink directory')
                for name in files:
                    path=Path(dirpath)/name;g.require(not path.is_symlink(),'Output symlink file');count+=1;total+=path.stat().st_size
            if count>1000 or total>limit['artifact_bytes']:reason='artifact_size_or_count'
            if reason:stop_owned();break
            with (output/'RSS_SAMPLES.jsonl').open('a') as stream:stream.write(json.dumps({'at':now(),'elapsed':elapsed,'rss_bytes':state.get('last_snapshot',{}).get('rss_bytes')})+'\n')
            time.sleep(limit['poll_seconds'])
        state['return_code']=proc.wait(timeout=5)
        for t in threads:t.join(3)
        if any(t.is_alive() for t in threads):reason='capture_thread_unfinished'
        if failure.is_set():reason=reason or 'output_capture_or_size'
        state['stream_bytes']=stream_sizes
        if reason or state['return_code']!=0:
            state['status']='UNKNOWN_PREPARATION';state['reason']=reason or 'nonzero_exit'
        elif a.stage=='compile':
            g.require((P/'classes/RetainedBoundaryExportOnly.class').exists(),'Missing compiled class')
            state['status']='COMPLETE_COMPILE'
        else:
            result_path=Path(step['result']);g.require(result_path.exists(),'Missing exporter RESULT.json: UNKNOWN')
            result=json.loads(result_path.read_text());state['export_status']=result.get('status')
            g.require(result.get('status')=='PASS_EXPORTED_AND_BOUND_NO_SOLVER','Exporter did not pass')
            g.require(all(result.get(k)==0 for k in ['solver_constructions','native_strict_solver_calls','raw_four_fixed_point_calls','winning_region_computations','controller_extraction_calls']),'Unexpected scientific computation')
            g.require(result.get('model_generations')==1,'Model generation scope')
            state['status']='COMPLETE_EXPORT_BINDING_NO_SOLVER'
    except BaseException as exc:
        state['status']='UNKNOWN_SUPERVISOR_EXCEPTION';state['exception']=repr(exc)
        if proc is not None and proc.poll() is None:
            try:stop_owned()
            except BaseException as cleanup:state['status']='EMERGENCY_OWNED_PREPARATION_STOP_UNCONFIRMED';state['cleanup_error']=repr(cleanup)
    finally:
        state['finished_utc']=now();state['elapsed_seconds']=time.monotonic()-began
        put(output/'SUPERVISOR_RESULT.json',state)
        if not state['status'].startswith('EMERGENCY') and lock.exists():lock.unlink()
        print(json.dumps({k:state.get(k) for k in ['stage','status','return_code','elapsed_seconds','peak_rss_bytes','reason','exception']},ensure_ascii=False))
    raise SystemExit(0 if state['status'].startswith('COMPLETE_') else 2)

if __name__=='__main__':main()
