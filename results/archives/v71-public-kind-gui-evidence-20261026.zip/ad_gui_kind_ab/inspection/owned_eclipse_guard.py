#!/usr/bin/env python3
"""Attach a bounded observer to one explicitly identified dedicated Eclipse tree.

No GUI actions, solver calls or process launches. Signals require a separate
pinned science GO naming this dedicated process identity and cleanup policy.
"""
from __future__ import annotations
import argparse
import ctypes
import datetime as dt
import errno
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import time

SCHEMA = "v71-owned-eclipse-science-go-v1"
CASES = {"A_OLD_PUBLIC_INITIAL", "B_NEW_POINT_R2404"}
UTC = dt.timezone.utc


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def now() -> str:
    return dt.datetime.now(UTC).isoformat()


def stamp(value: str) -> float:
    parsed = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("A timezone is required")
    return parsed.timestamp()


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path: Path, data: dict) -> None:
    raw = (json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode()
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("wb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


class BSDInfo(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint32) for name in (
        "flags", "status", "xstatus", "pid", "ppid", "uid", "gid", "ruid", "rgid",
        "svuid", "svgid", "reserved")]
    _fields_ += [("comm", ctypes.c_char * 16), ("name", ctypes.c_char * 32)]
    _fields_ += [(name, ctypes.c_uint32) for name in ("nfiles", "pgid", "pjobc", "tdev", "tpgid")]
    _fields_ += [("nice", ctypes.c_int32), ("start_sec", ctypes.c_uint64), ("start_usec", ctypes.c_uint64)]


def identity(pid: int) -> dict | None:
    """Use the kernel's microsecond process birth time, not PID alone."""
    lib = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
    lib.proc_pidinfo.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint64, ctypes.c_void_p, ctypes.c_int]
    lib.proc_pidinfo.restype = ctypes.c_int
    lib.proc_pidpath.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
    lib.proc_pidpath.restype = ctypes.c_int
    info = BSDInfo()
    ctypes.set_errno(0)
    result = lib.proc_pidinfo(pid, 3, 0, ctypes.byref(info), ctypes.sizeof(info))
    if result == 0:
        error = ctypes.get_errno()
        if error in (errno.ESRCH, errno.ENOENT):
            return None
        raise RuntimeError(f"Cannot distinguish absent/unreadable process {pid}: errno={error}")
    if result != ctypes.sizeof(info) or info.pid != pid:
        raise RuntimeError("Incomplete or mismatched proc_bsdinfo")
    path = ctypes.create_string_buffer(4096)
    n = lib.proc_pidpath(pid, path, len(path))
    if n <= 0:
        raise RuntimeError("Cannot identify owned process executable")
    return {"pid": pid, "ppid": info.ppid, "uid": info.uid,
            "start_sec": info.start_sec, "start_usec": info.start_usec,
            "executable": path.value.decode("utf-8")}


def same_process(expected: dict, actual: dict | None, *, executable: bool = True) -> bool:
    keys = ["pid", "uid", "start_sec", "start_usec"] + (["executable"] if executable else [])
    return actual is not None and all(actual.get(key) == expected.get(key) for key in keys)


def tree_ids(rows: dict[int, dict], root_pid: int) -> set[int]:
    if root_pid not in rows:
        return set()
    chosen = {root_pid}
    while True:
        new = {pid for pid, row in rows.items() if row["ppid"] in chosen} - chosen
        if not new:
            return chosen
        chosen.update(new)


def snapshot(expected_root: dict) -> dict:
    actual_root = identity(expected_root["pid"])
    if actual_root is None:
        return {"root_exited": True, "rss_bytes": 0, "processes": []}
    if not same_process(expected_root, actual_root):
        raise RuntimeError("Root identity changed; no signal is permitted")
    result = subprocess.run(["/bin/ps", "-axo", "pid=,ppid=,rss="], capture_output=True,
                            text=True, timeout=2, check=True, env={**os.environ, "LC_ALL": "C"})
    rows = {}
    for line in result.stdout.splitlines():
        values = line.split()
        if len(values) != 3:
            raise RuntimeError("Incomplete ps row")
        pid, ppid, rss_kib = map(int, values)
        rows[pid] = {"ppid": ppid, "rss_bytes": rss_kib * 1024}
    selected = tree_ids(rows, expected_root["pid"])
    if not selected:
        raise RuntimeError("Root disappeared during snapshot")
    processes = []
    root_birth = (expected_root["start_sec"], expected_root["start_usec"])
    for pid in sorted(selected):
        found = identity(pid)
        if found is None:
            if pid == expected_root["pid"]:
                raise RuntimeError("Root exited during snapshot")
            continue
        if found["uid"] != expected_root["uid"]:
            raise RuntimeError("Foreign UID within tree: do not signal")
        if pid != expected_root["pid"] and (found["start_sec"], found["start_usec"]) < root_birth:
            raise RuntimeError("Unexpected older descendant")
        if pid != expected_root["pid"] and found["ppid"] != rows[pid]["ppid"]:
            raise RuntimeError("Descendant reparented during snapshot")
        found["rss_bytes"] = rows[pid]["rss_bytes"]
        processes.append(found)
    return {"root_exited": False, "rss_bytes": sum(p["rss_bytes"] for p in processes), "processes": processes}


def validate_go(path: Path, case: str, enforce: bool) -> tuple[dict, str]:
    go = json.loads(path.read_text())
    require(go["schema"] == SCHEMA and go["status"] == "GO_FIXED_OBSTACLE_PUBLIC_ACTIONS", "Wrong GO schema/status")
    require(case in CASES and case in go["allowed_cases"], "Case not authorized")
    require(go["attempts_per_case"] == 1 and go["maximum_concurrency"] == 1, "Attempt/concurrency scope")
    require(go["monitor_sha256"] == digest(Path(__file__)), "Monitor code pin mismatch")
    require(stamp(go["created_utc"]) <= time.time() + 5 < stamp(go["expires_utc"]), "Expired/future GO")
    limits = go["limits"]
    require(1 <= limits["wall_seconds"] <= 600, "Wall cap exceeds scope")
    require(1 <= limits["rss_process_tree_bytes"] <= 4 * 1024 ** 3, "RSS cap exceeds scope")
    require(0.25 <= limits["poll_seconds"] <= 1, "Sampling interval outside scope")
    require(limits["gui_cancel_grace_seconds"] == 10, "GUI cancellation grace must be ten seconds")
    require(limits["sigterm_grace_seconds"] == 10, "SIGTERM grace must be ten seconds")
    root = go["owned_root"]
    require(root["pid"] > 1 and root["uid"] == os.getuid(), "Not an owned PID")
    require("Eclipse.app/Contents/MacOS/eclipse" in root["executable"], "Unexpected executable")
    require(same_process(root, identity(root["pid"])), "Root process identity mismatch")
    if enforce:
        permissions = go["signal_permissions"]
        require(permissions["sigterm_owned_tree_on_limit_or_monitor_failure"] is True, "Explicit SIGTERM grant required")
        require(permissions["sigkill_owned_tree_after_sigterm_grace"] is True, "Explicit bounded SIGKILL grant required")
        require(permissions["cleanup_authority_survives_expiry_for_started_case"] is True, "Cleanup authority must cover an expiring active case")
    return go, digest(path)


def check_event(path: Path, case: str, go_sha: str, expected_event: str) -> dict | None:
    if not path.exists():
        return None
    event = json.loads(path.read_text())
    require(event["event"] == expected_event and event["case_id"] == case and event["go_sha256"] == go_sha,
            "Event does not match this case and authorization")
    require(stamp(event["created_utc"]) <= time.time() + 2, "Future event")
    return event


def signal_targets(processes: list[dict], root_pid: int, signum: int, identity_fn=identity, kill_fn=os.kill) -> list[dict]:
    """Called only after authorization checks. PID reuse never inherits ownership."""
    actions = []
    ordered = sorted(processes, key=lambda p: (p["pid"] == root_pid, p["start_sec"], p["start_usec"]))
    for expected in ordered:
        actual = identity_fn(expected["pid"])
        if actual is None:
            actions.append({"pid": expected["pid"], "action": "already_exited"})
        elif not same_process(expected, actual):
            actions.append({"pid": expected["pid"], "action": "identity_changed_no_signal"})
        else:
            kill_fn(expected["pid"], signum)
            actions.append({"pid": expected["pid"], "action": signal.Signals(signum).name, "identity": expected})
    return actions


class NativeBackend:
    clock = staticmethod(time.monotonic)
    sleep = staticmethod(time.sleep)
    identity = staticmethod(identity)
    snapshot = staticmethod(snapshot)
    kill = staticmethod(os.kill)


def cleanup_authorized(go_path: Path, go_sha: str, go: dict, backend) -> None:
    require(digest(go_path) == go_sha, "GO changed: no signal authority")
    require(go["monitor_sha256"] == digest(Path(__file__)), "Monitor changed during case")
    permissions = go["signal_permissions"]
    require(permissions["sigterm_owned_tree_on_limit_or_monitor_failure"] is True, "SIGTERM not authorized")
    require(permissions["sigkill_owned_tree_after_sigterm_grace"] is True, "SIGKILL not authorized")
    require(permissions["cleanup_authority_survives_expiry_for_started_case"] is True, "Expired-case cleanup not authorized")
    actual = backend.identity(go["owned_root"]["pid"])
    require(actual is None or same_process(go["owned_root"], actual), "Root PID reused or identity changed: no signal")


def bounded_cleanup(go_path: Path, go_sha: str, go: dict, case: str, output: Path,
                    state: dict, reason: str, backend=None) -> None:
    """An absent GUI ACK cannot leave an authorized owned computation running."""
    backend = backend or NativeBackend()
    state.update(status="ROOT_GUI_CANCEL_REQUIRED", limit_reason=reason, cancel_requested_utc=now())
    print(json.dumps({"status": state["status"], "case_id": case, "reason": reason,
                      "cancel_grace_seconds": 10, "ACK_required_for_escalation": False}), flush=True)
    try:
        save(output / "CANCEL_REQUIRED.json", {"event": "ROOT_GUI_CANCEL_REQUIRED", "created_utc": now(),
             "case_id": case, "go_sha256": go_sha, "reason": reason, "mode": state["mode"]})
    except Exception as exc:
        state["cancel_receipt_error"] = repr(exc)
    if state["mode"] == "observe":
        state["status"] = "LIMIT_OR_FAILURE_OBSERVE_ONLY_ROOT_ACTION_REQUIRED"
        return
    try:
        cleanup_authorized(go_path, go_sha, go, backend)
        grace_end = backend.clock() + 10
        while backend.clock() < grace_end:
            try:
                finished = check_event(output / "FINISH.json", case, go_sha, "CASE_FINISHED")
            except Exception as exc:
                state["finish_validation_error"] = repr(exc)
                finished = None
            if finished is not None:
                state.update(status="FINISH_DURING_GUI_CANCEL_GRACE_NO_SIGNAL", completion=finished)
                return
            backend.sleep(0.25)
        cleanup_authorized(go_path, go_sha, go, backend)
        targets = {p["pid"]: p for p in state.get("last_snapshot", {}).get("processes", [])}
        targets[go["owned_root"]["pid"]] = go["owned_root"]
        try:
            fresh = backend.snapshot(go["owned_root"])
            targets.update({p["pid"]: p for p in fresh["processes"]})
        except Exception as exc:
            # Only already established identities plus the exact owned root may be signalled.
            state["tree_refresh_error"] = repr(exc)
        owned = list(targets.values())
        state["signals"].extend(signal_targets(owned, go["owned_root"]["pid"], signal.SIGTERM,
                                                backend.identity, backend.kill))
        grace_end = backend.clock() + 10
        while backend.clock() < grace_end:
            remaining = []
            for expected in owned:
                actual = backend.identity(expected["pid"])
                if actual is not None:
                    require(same_process(expected, actual), "Owned PID identity changed after SIGTERM")
                    remaining.append(expected)
            if not remaining:
                state["status"] = "STOP_CONFIRMED_SIGTERM"
                return
            backend.sleep(0.25)
        cleanup_authorized(go_path, go_sha, go, backend)
        state["signals"].extend(signal_targets(remaining, go["owned_root"]["pid"], signal.SIGKILL,
                                                backend.identity, backend.kill))
        confirmation_end = backend.clock() + 2
        while backend.clock() < confirmation_end:
            alive = []
            for expected in remaining:
                actual = backend.identity(expected["pid"])
                if actual is not None:
                    require(same_process(expected, actual), "Owned PID identity changed after SIGKILL")
                    alive.append(expected)
            if not alive:
                state["status"] = "STOP_CONFIRMED_SIGKILL"
                return
            backend.sleep(0.25)
        state.update(status="EMERGENCY_STOP_NOT_CONFIRMED", remaining_owned_identities=alive)
    except Exception as exc:
        state.update(status="EMERGENCY_IDENTITY_OR_AUTHORITY_UNVERIFIABLE_NO_FURTHER_SIGNAL", cleanup_error=repr(exc))
    print(json.dumps({"status": state["status"], "case_id": case,
                      "urgent_root_action_required": True}), flush=True)


LOG_MAX_ENTRIES = 4096
LOG_MAX_DEPTH = 8
LOG_MAX_PATH_BYTES = 1024 ** 2
LOG_MAX_SCAN_SECONDS = 0.5
LOG_PER_FILE_BYTES = 16 * 1024 ** 2
LOG_TOTAL_BYTES = 64 * 1024 ** 2


def absolute_parts(value: str) -> tuple[str, ...]:
    path = Path(value)
    require(path.is_absolute() and ".." not in path.parts, "Log path must be absolute without parent traversal")
    require(len(path.parts) > 1, "Filesystem root cannot be a log target")
    return path.parts[1:]


def open_parent_nofollow(value: str) -> tuple[int, str]:
    """Every parent component is opened without following symbolic links."""
    parts = absolute_parts(value)
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    parent = os.open("/", flags)
    try:
        for part in parts[:-1]:
            child = os.open(part, flags, dir_fd=parent)
            os.close(parent)
            parent = child
        return parent, parts[-1]
    except BaseException:
        os.close(parent)
        raise


def log_snapshot(go: dict) -> dict:
    """Stat only explicitly pinned log paths, using bounded no-follow traversal."""
    files, directories, excluded = {}, {}, []
    entry_count, path_bytes = 0, 0
    began = time.monotonic()

    def charge(path: str) -> None:
        nonlocal entry_count, path_bytes
        entry_count += 1
        path_bytes += len(path.encode("utf-8"))
        require(entry_count <= LOG_MAX_ENTRIES, "Log scan entry limit exceeded")
        require(path_bytes <= LOG_MAX_PATH_BYTES, "Log scan path-byte limit exceeded")
        require(time.monotonic() - began <= LOG_MAX_SCAN_SECONDS, "Log scan duration limit exceeded")

    def record(path: str, meta) -> None:
        require(stat.S_ISREG(meta.st_mode), "Nonregular log file or symbolic link rejected: " + path)
        require(meta.st_nlink == 1, "Hardlinked log file rejected: " + path)
        files[path] = {"bytes": meta.st_size, "dev": meta.st_dev, "ino": meta.st_ino}

    def walk(fd: int, path: str, depth: int) -> None:
        require(depth <= LOG_MAX_DEPTH, "Log scan depth limit exceeded")
        meta = os.fstat(fd)
        directories[path] = {"dev": meta.st_dev, "ino": meta.st_ino}
        with os.scandir(fd) as entries:
            for entry in entries:
                # Names supplied by scandir cannot contain separators; recheck anyway.
                require(entry.name not in (".", "..") and "/" not in entry.name, "Unsafe log entry name")
                child_path = path + "/" + entry.name
                charge(child_path)
                meta = os.stat(entry.name, dir_fd=fd, follow_symlinks=False)
                if stat.S_ISDIR(meta.st_mode):
                    child_fd = os.open(entry.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                    try:
                        opened = os.fstat(child_fd)
                        require((opened.st_dev, opened.st_ino) == (meta.st_dev, meta.st_ino), "Log directory changed during scan")
                        walk(child_fd, child_path, depth + 1)
                    finally:
                        os.close(child_fd)
                else:
                    if entry.name.endswith(".lck"):
                        require(stat.S_ISREG(meta.st_mode) and meta.st_nlink == 1,
                                "Nonregular or linked logger lock rejected: " + child_path)
                        excluded.append({"path": child_path, "bytes": meta.st_size,
                                         "reason": "java.util.logging.FileHandler transient lock; scoped to explicit log_roots"})
                    else:
                        record(child_path, meta)

    fixed = go.get("log_files", [])
    roots = go.get("log_roots", [])
    require(isinstance(fixed, list) and isinstance(roots, list) and len(fixed) + len(roots) <= 16,
            "Invalid or excessive log targets")
    for value, is_root in [(v, False) for v in fixed] + [(v, True) for v in roots]:
        require(isinstance(value, str), "Log target must be a string")
        absolute_parts(value)
        value = str(Path(value))  # Lexical normalization only; never resolve symlinks.
        charge(value)
        try:
            parent, leaf = open_parent_nofollow(value)
        except FileNotFoundError:
            continue
        try:
            try:
                meta = os.stat(leaf, dir_fd=parent, follow_symlinks=False)
            except FileNotFoundError:
                continue
            if is_root:
                require(stat.S_ISDIR(meta.st_mode), "Log root must be a real directory")
                fd = os.open(leaf, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
                try:
                    opened = os.fstat(fd)
                    require((opened.st_dev, opened.st_ino) == (meta.st_dev, meta.st_ino), "Log root changed during scan")
                    walk(fd, value, 0)
                finally:
                    os.close(fd)
            else:
                record(value, meta)
        finally:
            os.close(parent)
    return {"files": files, "directories": directories, "scan_entries": entry_count,
            "scan_path_bytes": path_bytes, "scan_seconds": time.monotonic() - began,
            "excluded_transient_lock_count": len(excluded), "excluded_transient_locks": excluded}


def log_growth(initial: dict, previous: dict, current: dict) -> tuple[dict, str | None]:
    for section in ("files", "directories"):
        for path, old in previous[section].items():
            new = current[section].get(path)
            if new is None or (old["dev"], old["ino"]) != (new["dev"], new["ino"]):
                return {}, "log_rotation_or_disappearance"
            if section == "files" and new["bytes"] < old["bytes"]:
                return {}, "log_truncation"
    growth = {path: meta["bytes"] - initial["files"].get(path, {"bytes": 0})["bytes"]
              for path, meta in current["files"].items()}
    if any(n > LOG_PER_FILE_BYTES for n in growth.values()) or sum(growth.values()) > LOG_TOTAL_BYTES:
        return growth, "log_output_limit"
    return growth, None


def watch(args) -> None:
    go_path = Path(args.go).resolve()
    go, go_sha = validate_go(go_path, args.case, args.mode == "enforce")
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    reserve = output / "RESERVATION.json"
    with reserve.open("x") as stream:
        json.dump({"schema": "v71-guard-reservation-v1", "case_id": args.case,
                   "go_sha256": go_sha, "created_utc": now(), "mode": args.mode}, stream)
    root = go["owned_root"]
    lock_path = Path(__file__).resolve().parent / f"LOCK_ECLIPSE_{root['pid']}_{root['start_sec']}_{root['start_usec']}.json"
    lock_raw = json.dumps({"monitor_pid": os.getpid(), "go_sha256": go_sha, "case_id": args.case}).encode()
    with lock_path.open("xb") as stream:
        stream.write(lock_raw)
    state = {"schema": "v71-owned-eclipse-observation-v1", "case_id": args.case,
             "go_sha256": go_sha, "mode": args.mode, "status": "INITIALIZING_NOT_READY",
             "created_utc": now(), "owned_root": go["owned_root"], "signals": [],
             "solver_calls_by_guard": 0, "GUI_actions_by_guard": 0, "peak_rss_bytes": 0,
             "cleanup_policy": "GUI cancel request 10s, identity-checked SIGTERM 10s, identity-checked SIGKILL",
             "signals_require_new_explicit_GO": True}
    state_file = output / "MONITOR_RESULT.json"
    armed_at, started_at = time.monotonic(), None
    sample_file = output / "RSS_SAMPLES.jsonl"
    try:
        initial_processes = snapshot(go["owned_root"])
        require(not initial_processes["root_exited"], "Owned root exited before ready")
        initial_logs = log_snapshot(go)
        previous_logs = initial_logs
        state.update(status="ARMED_WAITING_FOR_START", last_snapshot=initial_processes,
                     initial_log_snapshot=initial_logs, peak_rss_bytes=initial_processes["rss_bytes"])
        save(state_file, state)
        print(json.dumps({"status": state["status"], "mode": args.mode, "output": str(output),
                          "initial_identity_RSS_and_log_checks": "PASS"}), flush=True)
        armed_at = time.monotonic()
        while True:
            if digest(go_path) != go_sha:
                state["status"] = "EMERGENCY_GO_CHANGED_NO_SIGNAL_ROOT_ACTION_REQUIRED"
                print(json.dumps({"status": state["status"], "urgent_root_action_required": True}), flush=True)
                break
            if time.time() >= stamp(go["expires_utc"]):
                if started_at is not None:
                    bounded_cleanup(go_path, go_sha, go, args.case, output, state, "GO_expired")
                else:
                    state["status"] = "NOT_STARTED_GO_EXPIRED_NO_SIGNAL"
                break
            completed = check_event(output / "FINISH.json", args.case, go_sha, "CASE_FINISHED")
            if completed is not None:
                state.update(status="FINISH_REPORTED_BY_ROOT_NO_SIGNAL", completion=completed)
                break
            if started_at is None:
                event = check_event(output / "START.json", args.case, go_sha, "START_CASE")
                if event is None:
                    if time.monotonic() - armed_at > 120:
                        state["status"] = "NOT_STARTED_ARM_TIMEOUT_NO_SIGNAL"
                        break
                    time.sleep(go["limits"]["poll_seconds"])
                    continue
                age = time.time() - stamp(event["created_utc"])
                if not 0 <= age <= 60:
                    raise RuntimeError("Stale or future START event")
                started_at = time.monotonic() - age
                state.update(status="OBSERVING", start_event=event)
            current = snapshot(go["owned_root"])
            elapsed = time.monotonic() - started_at
            state["elapsed_seconds"] = elapsed
            state["peak_rss_bytes"] = max(state["peak_rss_bytes"], current["rss_bytes"])
            state["last_snapshot"] = current
            with sample_file.open("a") as stream:
                stream.write(json.dumps({"at": now(), "elapsed_seconds": elapsed,
                                         "rss_bytes": current["rss_bytes"],
                                         "pids": [p["pid"] for p in current["processes"]]}) + "\n")
            if current["root_exited"]:
                state["status"] = "OWNED_ROOT_EXITED_NO_FURTHER_SIGNAL"
                break
            reason = None
            if elapsed >= go["limits"]["wall_seconds"]:
                reason = "wall_seconds"
            elif current["rss_bytes"] > go["limits"]["rss_process_tree_bytes"]:
                reason = "rss_process_tree_bytes"
            current_logs = log_snapshot(go)
            growth, log_reason = log_growth(initial_logs, previous_logs, current_logs)
            previous_logs = current_logs
            state["log_growth_bytes"] = growth
            state["last_log_snapshot"] = current_logs
            if log_reason is not None:
                reason = log_reason
            if reason is not None:
                bounded_cleanup(go_path, go_sha, go, args.case, output, state, reason)
                break
            save(state_file, state)
            time.sleep(go["limits"]["poll_seconds"])
    except Exception as exc:
        state["monitor_error"] = repr(exc)
        if started_at is not None:
            bounded_cleanup(go_path, go_sha, go, args.case, output, state, "monitor_failure")
        else:
            state["status"] = "NOT_STARTED_MONITOR_EXCEPTION_NO_SIGNAL"
    finally:
        state["finished_utc"] = now()
        save(state_file, state)
        if not state["status"].startswith("EMERGENCY") and lock_path.exists() and lock_path.read_bytes() == lock_raw:
            lock_path.unlink()
        print(json.dumps({"status": state["status"], "case_id": args.case,
                          "signals": len([s for s in state["signals"] if s["action"] == "SIGTERM"])}), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    ident = sub.add_parser("identity")
    ident.add_argument("--pid", type=int, required=True)
    run = sub.add_parser("watch")
    run.add_argument("--go", required=True)
    run.add_argument("--case", choices=sorted(CASES), required=True)
    run.add_argument("--output", required=True)
    run.add_argument("--mode", choices=("observe", "enforce"), default="observe")
    args = parser.parse_args()
    if args.command == "identity":
        print(json.dumps(identity(args.pid), ensure_ascii=False, indent=2))
    else:
        watch(args)


if __name__ == "__main__":
    main()
