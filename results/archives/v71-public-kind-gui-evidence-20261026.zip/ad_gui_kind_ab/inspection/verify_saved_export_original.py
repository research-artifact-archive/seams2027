#!/usr/bin/env python3
"""Read saved JSON/BDD node tables only: no solver, model build, FP or CPre."""
from pathlib import Path
import base64,datetime,hashlib,importlib.util,json
P=Path(__file__).resolve().parent
pins={};checks={};nodes={0:None,1:None};unique={}

def pin(path):
    path=Path(path).resolve();raw=path.read_bytes();v={'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};pins[str(path)]=v;return raw,v

def read(path):return json.loads(pin(path)[0])
def need(ok,label):
    checks[label]=bool(ok)
    if not ok:raise RuntimeError(label)

def mk(var,lo,hi):
    if lo==hi:return lo
    need(var>=0,'nonnegative_variable_'+str(var))
    for child in (lo,hi):
        if child>1:need(nodes[child][0]>var,'ordered_relabeling')
    key=(var,lo,hi)
    if key not in unique:
        k=len(nodes);nodes[k]=key;unique[key]=k
    return unique[key]

def metadata(m):
    fs={f['name']:f for f in m['fields']};need(len(fs)==len(m['fields']),'unique_fields')
    n=m['bdd_variable_count'];need(m['bdd_variable_order']==list(range(n)),'natural_order')
    allbits=[]
    for name,f in fs.items():
        need(f['domain_size']==len(f['values'])==len(set(f['values'])),'complete_values_'+name)
        need(set(f['values'])==set(f['encoding']),'complete_encoding_'+name)
        codes=[]
        for phase in ['current','next']:
            bits=f[phase+'_bits'];allbits+=bits;phasecodes=[]
            for value in f['values']:
                enc=f['encoding'][value][phase];need(set(enc)=={str(b) for b in bits},'encoding_bits_'+name+'_'+phase)
                need(all(type(v) is bool for v in enc.values()),'encoding_booleans_'+name)
                phasecodes.append(tuple(enc[str(b)] for b in bits))
            need(len(set(phasecodes))==len(phasecodes),'injective_values_'+name+'_'+phase);codes.append(phasecodes)
        need(codes[0]==codes[1],'current_next_codes_'+name)
    need(sorted(allbits)==list(range(n)),'all_bits_once')
    need(sorted(m['all_current_bits'])==sorted(b for f in fs.values() for b in f['current_bits']),'current_bit_union')
    need(sorted(m['all_next_bits'])==sorted(b for f in fs.values() for b in f['next_bits']),'next_bit_union')
    return fs

def fieldmap(old,fresh,add_helper):
    a,b=metadata(old),metadata(fresh);need(set(b)==set(a)|({'~envHelp'} if add_helper else set()),'exact_field_roster')
    mapped={}
    for name,x in a.items():
        y=b[name]
        for key in ['owner','role','domain_size','values']:need(x[key]==y[key],'field_'+name+'_'+key)
        for phase in ['current','next']:
            need(len(x[phase+'_bits'])==len(y[phase+'_bits']),'field_width_'+name+'_'+phase)
            for u,v in zip(x[phase+'_bits'],y[phase+'_bits']):
                need(u not in mapped and v not in mapped.values(),'injective_map');mapped[u]=v
                for value in x['values']:need(x['encoding'][value][phase][str(u)]==y['encoding'][value][phase][str(v)],'encoding_correspondence_'+name)
    need(len(mapped)==old['bdd_variable_count'],'complete_bit_map')
    return mapped

def load(ref,folder,mapping):
    raw,p=pin(folder/ref['file']);need(p['bytes']==ref['bytes'] and p['sha256']==ref['sha256'],'predicate_pin_'+str(folder/ref['file']))
    rows=[list(map(int,line.split())) for line in raw.decode('ascii').splitlines() if line.strip()]
    if len(rows)==1:
        need(rows[0] in ([0,0],[0,1]) and ref['node_count']==0,'constant_syntax');return rows[0][1]
    need(rows[0]==[len(mapping)] and rows[1]==list(range(len(mapping))),'saved_header')
    need(len(rows)-2==ref['node_count'],'saved_node_count');cache={0:0,1:1};last=None
    for row in rows[2:]:
        need(len(row)==4,'node_width');node,var,lo,hi=row
        need(node>1 and node not in cache and var in mapping and lo in cache and hi in cache,'node_topology')
        cache[node]=mk(mapping[var],cache[lo],cache[hi]);last=node
    need(last is not None,'root_present');return cache[last]

def restrict(root,assignments,memo=None):
    memo={} if memo is None else memo
    if root<=1:return root
    if root in memo:return memo[root]
    var,lo,hi=nodes[root]
    if var in assignments:r=restrict(hi if assignments[var] else lo,assignments,memo)
    else:r=mk(var,restrict(lo,assignments,memo),restrict(hi,assignments,memo))
    memo[root]=r;return r

def cube(bits):
    r=1
    for bit,value in sorted(bits.items(),reverse=True):r=mk(bit,0,r) if value else mk(bit,r,0)
    return r

def clean_ast(x):
    if isinstance(x,list):return [clean_ast(v) for v in x]
    if isinstance(x,dict):return {k:clean_ast(v) for k,v in x.items() if k!='trace_id'}
    return x

def inventory(m,wrapper):
    result={}
    for owner,p in m['source_inventory']['parsed'].items():
        need(p['patterns']==[] and p['triggers']==[] and p['existential_count']==0,'simple_source_'+owner)
        cs=[];inis=[]
        for c in p['constraints']:
            if c['kind']=='INI':inis.append(c['name'])
            else:cs.append({k:clean_ast(c[k]) for k in ['name','kind','spec_ast']})
        expected=[] if not wrapper or owner=='AUX' else ['retainedBoundaryEnv' if owner=='ENV' else 'retainedBoundarySys']
        need(inis==expected,'exact_initial_inventory_'+owner);result[owner]={'variables':clean_ast(p['variables']),'noninitial':cs}
    return result

config=read(P/'B_EXPORT_CONFIG.json');scope=read(P/'ROOT_MESSAGE_PREPARATION_SCOPE.json')
for x in scope['pins']:
    _,actual=pin(x['path']);need(actual==x,'frozen_scope_pin_'+x['path'])
for x in read(P/'COMPILED_CLASS_PINS.json'):
    _,actual=pin(x['path']);need(actual==x,'compiled_class_pin')
priorpath=Path(config['prior_helper_model']['path']);sourcepath=Path(config['prior_source_model']['path'])
prior=read(priorpath);source=read(sourcepath);freshpath=P/'runs/export/native_result/model.json';fresh=read(freshpath)
result=read(freshpath.with_name('RESULT.json'));supervisor=read(P/'runs/export/SUPERVISOR_RESULT.json');compiled=read(P/'runs/compile/SUPERVISOR_RESULT.json')
need(compiled['status']=='COMPLETE_COMPILE','one_compile_completed')
need(result['status']=='PASS_EXPORTED_AND_BOUND_NO_SOLVER' and result['stage']=='PROCESS_FINISHED' and result['teardown']=='COMPLETED','completed_export_receipt')
need(result['model_generations']==1 and all(result[k]==0 for k in ['solver_constructions','native_strict_solver_calls','raw_four_fixed_point_calls','winning_region_computations','controller_extraction_calls']),'one_model_zero_solver')
need(fresh['input']['sha256']==config['input']['sha256'],'fresh_input_identity')
need(inventory(source,False)==inventory(fresh,True),'parsed_noninitial_inventory_unchanged')
fmap=fieldmap(prior,fresh,False);smap=fieldmap(source,fresh,True);identity={i:i for i in range(fresh['bdd_variable_count'])};freshfields=metadata(fresh)
need(freshfields['~envHelp']['owner']=='ENV' and freshfields['~envHelp']['values']==['false','true'],'helper_owner_and_domain')
priorf={k:load(v,priorpath.parent,fmap) for k,v in prior['original_bdds'].items() if k not in ['thetaE','thetaS']}
freshf={k:load(v,freshpath.parent,identity) for k,v in fresh['original_bdds'].items()}
for key in ['rhoE','rhoS','domain','domain_ENV_next','domain_SYS_next']:need(priorf[key]==freshf[key],'raw_full_'+key)
h=freshfields['~envHelp']['current_bits'][0];hp=freshfields['~envHelp']['next_bits'][0]
for current in [False,True]:
 for nxt in [False,True]:
  q=str(int(current))+str(int(nxt));assignment={h:current,hp:nxt}
  for key in ['rhoE','rhoS']:
   expected=restrict(priorf[key],assignment);actual=restrict(freshf[key],assignment)
   exported=load(result['helper_quadrants'][q][key],freshpath.parent,identity)
   need(expected==actual==exported,'raw_quadrant_'+q+'_'+key)
for owner,expected_count in [('ENV',1),('SYS',2)]:
    old=prior['original_justices'][owner];new=fresh['original_justices'][owner]
    need(len(old)==len(new)==expected_count,'ordered_justice_count_'+owner)
    for i,(a,b) in enumerate(zip(old,new)):need(load(a,priorpath.parent,fmap)==load(b,freshpath.parent,identity),'ordered_justice_'+owner+'_'+str(i))
need(len(source['original_justices']['ENV'])==0,'source_ENV_justice_empty')
need(load(fresh['original_justices']['ENV'][0],freshpath.parent,identity)==cube({h:False}),'helper_justice_exact_not_h')
for key in ['rhoE','rhoS']:need(restrict(freshf[key],{h:False,hp:False})==load(source['original_bdds'][key],sourcepath.parent,smap),'source00_'+key)
for i,ref in enumerate(source['original_justices']['SYS']):need(restrict(load(fresh['original_justices']['SYS'][i],freshpath.parent,identity),{h:False})==load(ref,sourcepath.parent,smap),'source_SYS_justice_'+str(i))
point={'obstacle[0]':'3','obstacle[1]':'5','obsWait':'true','~envHelp':'false','robot[0]':'5','robot[1]':'5'}
need(result['point_singleton']==point,'full_point_values')
allbits={};envbits={};sysbits={}
for name,value in point.items():
    field=freshfields[name];bits={int(k):v for k,v in field['encoding'][value]['current'].items()}
    allbits.update(bits);(envbits if field['owner']=='ENV' else sysbits).update(bits)
need(freshf['thetaE']==cube(envbits),'point_thetaE_exact_nonempty');need(freshf['thetaS']==cube(sysbits),'point_thetaS_exact_nonempty')
need(load(result['point_joint'],freshpath.parent,identity)==cube(allbits),'joint_exact_singleton')
need(len(allbits)==len(fresh['all_current_bits']),'singleton_assigns_all_current_bits')
need(supervisor['status']=='UNKNOWN_SUPERVISOR_EXCEPTION' and supervisor['exception']=="RuntimeError('Root exited during snapshot')" and supervisor['signals']==[],'preserved_supervisor_completion_race')
stdout,stdout_pin=pin(P/'runs/export/stdout.txt');stderr,stderr_pin=pin(P/'runs/export/stderr.txt');capture=read(freshpath.with_name('EXACT_DIAGNOSTIC_RECEIPT.json'))
records=[json.loads(s) for s in stdout.decode().splitlines()]
need(records[-1]['kind']=='end','capture_end_present')
need(capture['capture_complete'] is True and capture['capture_error'] is None and capture['cap_reached'] is False and capture['unflushed_repeated_lines']==0,'capture_receipt_complete')
need(capture['encoded_bytes']==len(stdout) and capture['encoded_sha256']==stdout_pin['sha256'] and capture['records']==len(records),'encoded_capture_hash_size_records')
dictionary={};raw_hash=hashlib.sha256();expanded_bytes=repeated=0
for i,record in enumerate(records):
    kind=record['kind']
    if kind=='dictionary':
        need(i==0 and record['id'] not in dictionary,'initial_unique_dictionary');dictionary[record['id']]=base64.b64decode(record['data'],validate=True)
    elif kind=='bytes':
        data=base64.b64decode(record['data'],validate=True);raw_hash.update(data);expanded_bytes+=len(data)
    elif kind=='repeat':
        need(record['id'] in dictionary and type(record['count']) is int and record['count']>0,'valid_repeat_run')
        data=dictionary[record['id']];repeated+=record['count']
        for _ in range(record['count']):raw_hash.update(data)
        expanded_bytes+=len(data)*record['count']
    else:need(kind=='end' and i==len(records)-1,'one_final_capture_end')
need(expanded_bytes==capture['raw_bytes']==records[-1]['raw_bytes']<=16777216,'expanded_diagnostic_under_limit')
need(repeated==capture['repeated_lines']==records[-1]['repeated_lines'],'capture_repeat_count')
need(stderr==b'','stderr_empty')
# Re-read every finished output file to prove a stable complete observed snapshot.
output_files=[]
for path in sorted((P/'runs/export').rglob('*')):
    if path.is_file():
        _,first=pin(path);_,second=pin(path);need(first==second,'stable_output_'+str(path.relative_to(P)));output_files.append(first)
need(not any(path.suffix=='.tmp' for path in (P/'runs/export').rglob('*')),'no_unfinished_temp_output')
need(sum(x['bytes'] for x in output_files)<=268435456,'export_artifact_bytes_under_cap')
# Explicit kernel identity read only. No signals are sent by this verifier.
spec=importlib.util.spec_from_file_location('g',P/'owned_eclipse_guard.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
current=g.identity(supervisor['pid']);need(current is None or not g.same_process(supervisor['owned_root'],current),'export_owned_process_no_longer_running')
report={'schema':'v71-saved-B-export-structural-verification-v1','status':'PASS_SAVED_PREDICATE_BINDING_WITH_PRESERVED_SUPERVISOR_UNKNOWN','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'checks_count':len(checks),'canonical_saved_predicate_nodes':len(nodes)-2,'source_to_actual_bit_map':smap,'prior_helper_to_actual_bit_map':fmap,'point':point,'fresh_export_status':result['status'],'original_supervisor_status':supervisor['status'],'original_supervisor_exception':supervisor['exception'],'process_return_code':'UNRECORDED; not reconstructed or relabeled as zero','owned_export_process_running':False,'kernel_identity_observed_after_export':current,'observed_capture':{'complete':capture['capture_complete'],'encoded_sha256':stdout_pin['sha256'],'encoded_bytes':len(stdout),'reconstructed_raw_sha256':raw_hash.hexdigest(),'raw_bytes':expanded_bytes,'records':len(records),'repeated_lines':repeated,'unflushed_repeated_lines':capture['unflushed_repeated_lines']},'output_file_manifest':output_files,'completion_marker_scope':'Exporter finally frees GameModel and factory; then sets teardown COMPLETED, cancels heap sampler, checkpoint PROCESS_FINISHED writes and closes/moves RESULT.json. Only then System.exit invokes capture.finish shutdown hook, which writes end, flushes target and writes separate receipt. These observed markers do not supply the missing OS exit code or prove fsync durability.','posthoc_adoption_scope':'Read-only independent structural equality of saved Boolean predicates, field encodings, ordered justices and exact nonempty point initializers. This does not change the original supervisor UNKNOWN and is not a new model/solver/FP run. Root decides adoption before GUI B.','limits_evidence':{'observed_seconds':supervisor['elapsed_seconds'],'sampled_peak_RSS_bytes':supervisor['peak_rss_bytes'],'actual_peak_RSS':'not claimed; polling sample only','encoded_stdout_bytes':len(stdout),'expanded_stdout_bytes':records[-1]['raw_bytes'],'stderr_bytes':len(stderr),'signals':supervisor['signals']},'input_pins':list(pins.values()),'activity':{'model_builds':0,'Java_runs':0,'solver_calls':0,'fixed_point_calls':0,'CPre_calls':0,'signals':0,'GUI_actions':0},'checker':pin(Path(__file__))[1]}
(P/'SAVED_EXPORT_VERIFICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','checks_count','canonical_saved_predicate_nodes','owned_export_process_running']}))
