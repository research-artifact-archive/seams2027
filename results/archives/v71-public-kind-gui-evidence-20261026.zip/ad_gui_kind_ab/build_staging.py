#!/usr/bin/env python3
"""Static local packaging only. No scientific imports, execution or restoration."""
import copy,hashlib,json,re,unicodedata
from pathlib import Path
ROOT=Path(__file__).resolve().parent
STUDY=ROOT.parents[1]
D=STUDY/'research_strategy_after_r3/resumed_2333'
P=D/'retained_preparation'
AC=ROOT.parent/'ac_obstacle8cert98'
ledger=[];mapping={};dependencies={};omitted={};input_hashes={}

def digest(raw):return hashlib.sha256(raw).hexdigest()
def norm(x):return unicodedata.normalize('NFC',str(x))
def ident(path):
 path=Path(path)
 try:return path.resolve().relative_to(STUDY.resolve()).as_posix()
 except ValueError:return 'external-evidence/'+path.name

def source_read(path):
 path=Path(path);raw=path.read_bytes();input_hashes[str(path)]=(len(raw),digest(raw));return raw

def pin(path):
 raw=source_read(path);return {'bytes':len(raw),'sha256':digest(raw)}
def save(rel,value):
 path=ROOT/rel;path.parent.mkdir(parents=True,exist_ok=True)
 raw=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode() if not isinstance(value,(bytes,str)) else value.encode() if isinstance(value,str) else value
 path.write_bytes(raw);return {'bytes':len(raw),'sha256':digest(raw)}
def record(path,rel,raw,changes=None,disposition=None):
 old=source_read(path);pub=save(rel,raw)
 ledger.append({'source_id':ident(path),'public_path':rel,'original':{'bytes':len(old),'sha256':digest(old)},'public':pub,'disposition':disposition or ('byte_preserved' if old==raw else 'metadata_or_location_derivative'),'changes':changes or []})
 bind(path,rel)

def bind(path,rel):
 path=Path(path).resolve();mapping[norm(path)]=rel
 for base in (STUDY,STUDY.parents[1]):
  try:mapping[norm(path.relative_to(base.resolve()).as_posix())]=rel
  except ValueError:pass

def dep(path):
 path=Path(path).resolve();relative='../ac_obstacle8cert98/'+path.relative_to(AC.resolve()).as_posix();row={'path':relative,**pin(path)}
 dependencies[relative]=row;return relative

def path_location(value):
 normalized=norm(value)
 if normalized in mapping:return mapping[normalized]
 # Existing AC copies are immutable dependencies, always bound to actual files.
 path=Path(value)
 if path.is_absolute():
  try:
   rel=path.resolve().relative_to(STUDY.resolve());candidate=AC/rel
   if candidate.is_file():return dep(candidate)
  except (ValueError,OSError):pass
  if path.suffix in {'.jar','.class','.dylib'}:
   return 'external-runtime:'+path.name
  key='withheld:'+digest(value.encode())[:20]
  omitted.setdefault(key,{'id':key,'kind':'private_or_unbundled_location','basename':path.name,'not_a_runtime_dependency':True})
  return key
 return value

def clean_string(value):
 if norm(value) in mapping:return mapping[norm(value)]
 if value.startswith('/') and not value.startswith('//'):return path_location(value)
 # Class code-source descriptions and dynamic check labels can embed locations.
 result=value
 for old,new in sorted(mapping.items(),key=lambda kv:len(kv[0]),reverse=True):result=norm(result).replace(old,new)
 # Remaining personal-root text is withheld, never guessed into a local path.
 if re.search('/'+'Users'+r'/[^/\s]+',result):
  result='[withheld location-bearing metadata; original string SHA-256 '+digest(value.encode())+']'
 return result

def clean(value,pointer='',changes=None):
 changes=[] if changes is None else changes
 if isinstance(value,dict):
  out={}
  for key,v in value.items():
   nk=clean_string(key)
   if nk!=key:changes.append({'pointer':pointer+'/'+key.split('/')[-1],'change':'location-bearing object key anonymized','original_value_sha256':digest(key.encode()),'public_value':nk})
   out[nk]=clean(v,pointer+'/'+nk.replace('~','~0').replace('/','~1'),changes)
  return out
 if isinstance(value,list):return [clean(v,pointer+'/'+str(i),changes) for i,v in enumerate(value)]
 if isinstance(value,str):
  new=clean_string(value)
  if new!=value:changes.append({'pointer':pointer,'change':'nonsemantic location derivative','original_value_sha256':digest(value.encode()),'public_value':new})
  return new
 return value

def derivative(path,rel,keys=None,drop=()):
 original=json.loads(source_read(path));data=copy.deepcopy(original)
 changes=[]
 if keys is not None:
  data={k:data[k] for k in keys if k in data};changes.append({'pointer':'/','change':'declared field subset','retained_keys':list(data),'omitted_keys':sorted(set(original)-set(data))})
 for key in drop:
  if key in data:data.pop(key);changes.append({'pointer':'/'+key,'change':'private administrative/location subtree withheld'})
 data=clean(data,changes=changes)
 raw=(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode();record(path,rel,raw,changes,'declared_field_subset' if keys is not None or drop else None)
 return data

def same(path,rel):record(path,rel,source_read(path))

# Bind planned destinations before deriving any cross-referenced record.
for name,rel in {
 'ROOT_KIND_LEMMA_ADOPTION.json':'theory/LEMMA_ADOPTION.json',
 'ROOT_SAVED_B_GATE_ADOPTION.json':'preparation/SAVED_GATE_ADOPTION.json',
 'ROOT_SCIENTIFIC_DISPOSITION_R4.json':'SCIENTIFIC_DISPOSITION.json',
 'OBSTACLE_SOURCE_KIND_LEMMA_ADOPTED.txt':'theory/SOURCE_KIND_LEMMA_ADOPTED_JA.txt',
 'LOADED_RELEASE_AUDIT_CANDIDATE.json':'runtime/RELEASE_AUDIT_PUBLIC.json',
 'INDEPENDENT_KIND_LEMMA_AUDIT.json':'theory/LEMMA_AUDIT_PUBLIC.json',
}.items():bind(D/name,rel)
for name,rel in {
 'HANDOFF.json':'preparation/HANDOFF_PUBLIC.json','SAVED_EXPORT_VERIFICATION.json':'preparation/SAVED_EXPORT_VERIFICATION.json',
 'verify_saved_export.py':'inspection/verify_saved_export_original.py','owned_eclipse_guard.py':'inspection/owned_eclipse_guard.py',
 'run_bounded_preparation.py':'inspection/run_bounded_preparation_original.py','java/RetainedBoundaryExportOnly.java':'inspection/RetainedBoundaryExportOnly.java',
 'B_EXPORT_CONFIG.json':'preparation/B_EXPORT_CONFIG_HISTORICAL.json','INPUT_FREEZE.json':'inputs/INPUT_FREEZE_PUBLIC.json',
 'runs/export/SUPERVISOR_RESULT.json':'preparation/EXPORT_SUPERVISOR_PUBLIC.json','runs/compile/SUPERVISOR_RESULT.json':'preparation/COMPILE_PUBLIC.json',
 'runs/export/stdout.txt':'preparation/export/stdout.jsonl','runs/export/stderr.txt':'preparation/export/stderr.txt',
 'COMPILED_CLASS_PINS.json':'preparation/COMPILED_CLASS_PROVENANCE.json',
}.items():bind(P/name,rel)
for path in (P/'runs/export/native_result').iterdir():
 if path.is_file():bind(path,'preparation/export/native_result/'+path.name)
for case in ['A_OLD_PUBLIC_INITIAL','B_NEW_POINT_R2404']:
 label=case[0];base=D/'gui_science'/case
 for name,target in [('ROOT_RESULT.json','RESULT.json'),('CONSOLE_VISUAL_TRANSCRIPTION.txt','CONSOLE_TRANSCRIPTION.txt'),('INDEPENDENT_COMPLETION_AUDIT.json','COMPLETION_AUDIT_PUBLIC.json')]:bind(base/name,'gui/'+label+'/'+target)
 monitor=base/('MONITOR_RESULT.json' if label=='A' else 'monitor/MONITOR_RESULT.json');bind(monitor,'gui/'+label+'/MONITOR_PUBLIC.json')
 for path in base.rglob('*.spectraXML'):bind(path,'gui/'+label+'/logger/'+path.name)

# Omitted source paths are named restoration targets, never distributed text.
freeze=json.loads(source_read(P/'INPUT_FREEZE.json'))
for key,name in [('old_original','MovingObstacleEvasion.spectra'),('A_input','MovingObstacleEvasion.spectra'),('new_public_original','MovingObstacleEvasionUpdate.public.spectra'),('new_ordinary_projection','MovingObstacleEvasionUpdate.projected.spectra'),('B_input','MovingObstacleEvasionUpdate_retained_r2404.spectra')]:bind(Path(freeze[key]['path']),'restored_sources/'+name)
for name in ['MovingObstacleEvasion.spectra','MovingObstacleEvasionUpdate_retained_r2404.spectra']:bind(D/'frontend_workspace/FixedObstacleR4'/name,'restored_sources/'+name)
bind(D/'frontend_workspace/.metadata/.plugins/org.eclipse.core.runtime/.settings/tau.smlab.syntech.ui.prefs','runtime/FINAL_PREFS.txt')
bind(D/'gui_science/B_NEW_POINT_R2404/FINAL_PREFS_COPY.txt','runtime/FINAL_PREFS.txt')

# Scientific output bytes are copied unchanged. Only location-bearing JSON differs.
for path in sorted((P/'runs/export/native_result').iterdir()):
 if not path.is_file():continue
 rel='preparation/export/native_result/'+path.name
 if path.suffix=='.json':derivative(path,rel)
 else:same(path,rel)
same(P/'runs/export/stdout.txt','preparation/export/stdout.jsonl');same(P/'runs/export/stderr.txt','preparation/export/stderr.txt')
for name,rel in [('owned_eclipse_guard.py','owned_eclipse_guard.py'),('run_bounded_preparation.py','run_bounded_preparation_original.py'),('verify_saved_export.py','verify_saved_export_original.py'),('java/RetainedBoundaryExportOnly.java','RetainedBoundaryExportOnly.java')]:same(P/name,'inspection/'+rel)
same(STUDY/'published_update/native_preparation/java/ExactDiagnosticPrintStream.java','inspection/ExactDiagnosticPrintStream.java')
same(STUDY.parents[1]/'experiment/seams_submission_push_20261016/released_kind_pipeline_feasibility/src/ReleasedKindJobProducer.java','inspection/ReleasedKindJobProducer.java')
same(AC/'LICENSE-original.txt','LICENSE-original.txt')

# Public GUI records omit raw screenshots/AX, process identity, authorizations and lsof.
for case in ['A_OLD_PUBLIC_INITIAL','B_NEW_POINT_R2404']:
 label=case[0];base=D/'gui_science'/case
 derivative(base/'ROOT_RESULT.json','gui/'+label+'/RESULT.json',drop=('evidence','full_reset'))
 derivative(base/'INDEPENDENT_COMPLETION_AUDIT.json','gui/'+label+'/COMPLETION_AUDIT_PUBLIC.json',keys=('schema','status','created_utc','case_id','root_result_pin_verified','screenshot_independently_viewed','manual_transcription_matches_visible_seven_lines','visible_console_lines','checks','accepted_observation','preserved_preparation_status','scope_limits','activity'))
 same(base/'CONSOLE_VISUAL_TRANSCRIPTION.txt','gui/'+label+'/CONSOLE_TRANSCRIPTION.txt')
 monitor=base/('MONITOR_RESULT.json' if label=='A' else 'monitor/MONITOR_RESULT.json')
 derivative(monitor,'gui/'+label+'/MONITOR_PUBLIC.json',keys=('schema','case_id','mode','status','created_utc','signals','solver_calls_by_guard','GUI_actions_by_guard','peak_rss_bytes','cleanup_policy','signals_require_new_explicit_GO','elapsed_seconds','finished_utc'))
 for path in sorted(base.rglob('*.spectraXML')):same(path,'gui/'+label+'/logger/'+path.name)
same(D/'gui_science/B_NEW_POINT_R2404/FINAL_PREFS_COPY.txt','runtime/FINAL_PREFS.txt')

# Historical statuses stay unchanged even where a later gate was adopted.
derivative(P/'runs/export/SUPERVISOR_RESULT.json','preparation/EXPORT_SUPERVISOR_PUBLIC.json',keys=('schema','stage','status','created_utc','limits','signals','peak_rss_bytes','solver_calls','fixed_point_calls','controller_extraction_calls','exception','finished_utc','elapsed_seconds'))
derivative(P/'runs/compile/SUPERVISOR_RESULT.json','preparation/COMPILE_PUBLIC.json',keys=('schema','stage','status','created_utc','limits','signals','peak_rss_bytes','solver_calls','fixed_point_calls','controller_extraction_calls','return_code','stream_bytes','finished_utc','elapsed_seconds'))
derivative(P/'SAVED_EXPORT_VERIFICATION.json','preparation/SAVED_EXPORT_VERIFICATION.json',drop=('input_pins','output_file_manifest'))
derivative(P/'HANDOFF.json','preparation/HANDOFF_PUBLIC.json',keys=('schema','status','created_utc','fixed_case','input','source_state','actual_initial_joint','preparation_attempts','compile','original_export_supervisor','exporter_receipt','separate_saved_predicate_gate','completion_and_capture','scope_limits'))
derivative(P/'B_EXPORT_CONFIG.json','preparation/B_EXPORT_CONFIG_HISTORICAL.json')
derivative(P/'COMPILED_CLASS_PINS.json','preparation/COMPILED_CLASS_PROVENANCE.json')
derivative(D/'ROOT_SAVED_B_GATE_ADOPTION.json','preparation/SAVED_GATE_ADOPTION.json',drop=('owned_gui_identity_current','evidence'))
derivative(D/'ROOT_KIND_LEMMA_ADOPTION.json','theory/LEMMA_ADOPTION.json',drop=('candidate_unchanged','audit','full_reset'))
derivative(D/'ROOT_SCIENTIFIC_DISPOSITION_R4.json','SCIENTIFIC_DISPOSITION.json',drop=('evidence','root_review','remaining_work','full_reset_uses'))
derivative(D/'INDEPENDENT_KIND_LEMMA_AUDIT.json','theory/LEMMA_AUDIT_PUBLIC.json',keys=('schema','status','created_utc','decision','primary_source_checks','proof_obligations','required_findings','recommended_precision','obstacle_saved_evidence','weakened_claim_counterexamples','transformed_game_boundary','application_scope','execution'))
# Freeze derivative excludes the 45-byte upstream text itself, keeping only its hash.
f=copy.deepcopy(freeze);f['removed_switch'].pop('text');f.pop('protocol');f.pop('builder');f.pop('diff')
changes=[{'pointer':'/removed_switch/text','change':'upstream source fragment omitted; byte interval/hash retained'},{'pointer':'/','change':'preparation/control paths omitted; scientific input pins and appendix retained'}];f=clean(f,changes=changes)
record(P/'INPUT_FREEZE.json','inputs/INPUT_FREEZE_PUBLIC.json',(json.dumps(f,ensure_ascii=False,indent=2)+'\n').encode(),changes,'declared_field_subset')
append=freeze['B_append']['text'].encode();assert len(append)==124 and digest(append)==freeze['B_append']['sha256'];save('inputs/retained_point_appendix.txt',append)

# Primary literature stays external. Adopted mathematical text gets only a location appendix edit.
lemma=source_read(D/'OBSTACLE_SOURCE_KIND_LEMMA_ADOPTED.txt').decode()
start=lemma.index('local pins（workspace相対）')
lemma=lemma[:start]+'''Evidence locations in this package\nPrimary definitions: PRIMARY_REFERENCES.json (publisher paper and appendix pins; not redistributed).\nSaved source evidence: DEPENDENCIES.json identifies the exact old/new SOURCE_RESULT and SOURCE_GAME records in sibling AC.\nSource-region and retained-state results: sibling AC FINAL_CERTIFICATE_SUMMARY and ALL98_FIXED8_MEMBERSHIP (current metadata pins in DEPENDENCIES.json).\nThis is the adopted source-existence lemma. The earlier adoption record predates the later A/B GUI observations; it does not itself assert a GUI verdict or model equivalence.\n'''
record(D/'OBSTACLE_SOURCE_KIND_LEMMA_ADOPTED.txt','theory/SOURCE_KIND_LEMMA_ADOPTED_JA.txt',lemma.encode(),[{'pointer':'text/evidence_appendix','change':'workspace literature/data locations replaced by public dependency and primary-reference navigation; mathematical body unchanged'}])

# Release information is evidence extraction, not redistribution of runtimes.
release=json.loads(source_read(D/'LOADED_RELEASE_AUDIT_CANDIDATE.json'))
derivative(D/'LOADED_RELEASE_AUDIT_CANDIDATE.json','runtime/RELEASE_AUDIT_PUBLIC.json',keys=('schema','status','created_utc','scope','target_release','target_jars_verified','unique_target_registrations','duplicate_installed_target_versions','all20_installed_downloaded_and_cached_bytes_equal','static_action_mapping','provider_mapping','preference_phases','unestablished','further_execution_evidence_scope','activity'))
rows=[]
for row in release['target_jars']:
 jar=Path(row['installed']['path']).name
 rows.append({'symbolic_name':row['symbolic_name'],'version':row['version'],'basename':jar,'bytes':row['installed']['bytes'],'sha256':row['installed']['sha256'],'official_url':'https://smlab.cs.tau.ac.il/syntech/spectra/tools/update/plugins/'+jar,'installed_downloaded_cached_byte_equal':row['cached_historical_byte_identical'] and row['matches_downloaded_expected'],'registration':row['registration'],'open_handle_pre_source':row['open_handle_pre_source'],'open_handle_A_open':row['open_handle_A_open'],'actual_class_load_proven_by_this_pre_action_audit':row['actual_class_load_proven']})
rr={'schema':'v71-ad-external-runtime-restoration-reference-v1','status':'REFERENCE_ONLY_NO_DOWNLOAD_OR_INSTALL_DURING_PACKAGING','update_site':'https://smlab.cs.tau.ac.il/syntech/spectra/tools/update/','release':release['target_release'],'eclipse_dsl_distribution':'https://archive.eclipse.org/technology/epp/downloads/release/2023-12/R/eclipse-dsl-2023-12-R-macosx-cocoa-aarch64.dmg','GUI_java':'macOS ARM64 JustJ 17.0.9','NoIDE_export_java':'OpenJDK17.0.19','eclipse_build':release['eclipse_configuration']['build_id'],'Xtext_core':release['eclipse_configuration']['registered_xtext_core_version'],'configuration_file':'runtime/FINAL_PREFS.txt','jars':rows,'members':[{**x,'jar':Path(x['jar']).name} for x in release['jar_member_pins']],'boundary':'Runtime artifacts are not included. Byte identity, registration and open handles are distinct from individual method-call traces and GUI-model equality. Acquiring these pins alone does not reproduce the entire historic host.'}
save('RUNTIME_RESTORATION.json',rr)
# Record runtime extraction against the original audit as a declared subset.
ledger.append({'source_id':ident(D/'LOADED_RELEASE_AUDIT_CANDIDATE.json'),'public_path':'RUNTIME_RESTORATION.json','original':pin(D/'LOADED_RELEASE_AUDIT_CANDIDATE.json'),'public':{'bytes':(ROOT/'RUNTIME_RESTORATION.json').stat().st_size,'sha256':digest((ROOT/'RUNTIME_RESTORATION.json').read_bytes())},'disposition':'declared_field_subset_plus_official_URL_recipe','changes':[{'pointer':'/','change':'preserve JAR/member bytes and hashes; replace local paths by basenames and official restoration URLs; add runtime boundaries'}]})

# Bind the exact sibling AC closure needed by prospective saved-predicate inspection.
needed=[]
for folder in ['published_update/native_preparation/exports/OBSTACLE_NEW/native_result','published_update/native_preparation/execution/OBSTACLE_NEW/syntactic/native_result']:
 model_path=AC/folder/'model.json';model=json.loads(source_read(model_path));needed.append(model_path)
 refs=list(model['original_bdds'].values())+sum(model['original_justices'].values(),[])
 needed += [model_path.parent/x['file'] for x in refs]
for relative in [
 'published_update/independent_source/run_old/data/SOURCE_RESULT.json','published_update/independent_source/run_new/data/SOURCE_RESULT.json',
 'published_update/independent_source/run_old/data/SOURCE_GAME.jsonl.gz','published_update/independent_source/run_new/data/SOURCE_GAME.jsonl.gz',
 'published_update/independent_source/run_old/data/OLD_ONLY_SELECTED_PREFIX.json',
 'published_update/direct_certificate_check/amendment_01/FINAL_CERTIFICATE_SUMMARY.json',
 'published_update/direct_certificate_check/amendment_01/ALL98_FIXED8_MEMBERSHIP.json',
 'published_update/independent_correspondence/FINAL_STRICT_AUDIT_SUMMARY.json',
 'published_update/direct_certificate_check/HISTORICAL_PROTOCOL_01.json',
 'positioning/provenance_sources/OBSTACLE_BOUNDARY_ALL98_FROZEN.json',
 'SOURCE_RESTORATION.json','TRANSFORMATION_LEDGER.json','MANIFEST.json']:
 needed.append(AC/relative)
for path in needed:dep(path)
# Current pins for an unexecuted portable saved-predicate adapter; separate from historical pins.
public_config={'schema':'v71-ad-current-saved-predicate-inputs-v1','status':'PREPARED_NOT_REPLAYED','fresh_model':{'path':'preparation/export/native_result/model.json',**pin(ROOT/'preparation/export/native_result/model.json')},'fresh_result':{'path':'preparation/export/native_result/RESULT.json',**pin(ROOT/'preparation/export/native_result/RESULT.json')},'prior_source_model':dependencies[dep(AC/'published_update/native_preparation/exports/OBSTACLE_NEW/native_result/model.json')],'prior_helper_model':dependencies[dep(AC/'published_update/native_preparation/execution/OBSTACLE_NEW/syntactic/native_result/model.json')],'point':{'obstacle[0]':'3','obstacle[1]':'5','obsWait':'true','~envHelp':'false','robot[0]':'5','robot[1]':'5'},'scope':'Current anonymized metadata pins. Historical code/results and their original hashes remain separately identified in the ledger.'}
save('SAVED_PREDICATE_INPUTS.json',public_config)

plan=json.loads(source_read(AC/'SOURCE_RESTORATION.json'))
plan['schema']='v71-ad-source-restoration-spec-v1';plan['status']='SPECIFICATION_ONLY_NOT_EXECUTED_DURING_PACKAGING'
for member in plan['members']:
 old='Update' not in member['member'];member['restore_to']='restored_sources/'+('MovingObstacleEvasion.spectra' if old else 'MovingObstacleEvasionUpdate.public.spectra');member['project_to']='restored_sources/'+('MovingObstacleEvasion.spectra' if old else 'MovingObstacleEvasionUpdate.projected.spectra')
plan['fixed_B_appendix']={'path':'inputs/retained_point_appendix.txt','bytes':124,'sha256':freeze['B_append']['sha256'],'append_to':'restored_sources/MovingObstacleEvasionUpdate.projected.spectra','output':'restored_sources/MovingObstacleEvasionUpdate_retained_r2404.spectra','output_bytes':2026,'output_sha256':freeze['B_input']['sha256'],'meaning':'Appends exactly one ENV and one SYS point INI to a source with no original INI. This is a separate continuation query, not a reset or unchanged original source.'}
plan['switch_semantics']='Remove the last45-byte switch-entry declaration as metadata, then append only the disclosed124-byte point-query appendix. Do not conjoin old original initializers.'
plan['required_for']='Optional future source-byte checks or native setup. No restoration or native execution occurs during packaging.';plan['not_required_for']='Reading existing saved predicates and checking their hash-pinned mathematical correspondence.'
save('SOURCE_RESTORATION.json',plan)
save('DEPENDENCIES.json',{'schema':'v71-ad-existing-sibling-dependencies-v1','layout':'Place ad_gui_kind_ab next to the unchanged ac_obstacle8cert98 directory. No archive is duplicated. This candidate is an add-on, not a standalone copy of AC.','required_package':'ac_obstacle8cert98','AC_manifest':{'path':'../ac_obstacle8cert98/MANIFEST.json',**pin(AC/'MANIFEST.json')},'files':sorted(dependencies.values(),key=lambda x:x['path']),'historical_metadata_hash_rule':'Embedded historical pins refer to execution originals. Current sibling metadata bytes are the pins here; AC TRANSFORMATION_LEDGER maps its original/public identities.'})
save('OMITTED_EVIDENCE.json',{'schema':'v71-ad-withheld-evidence-v1','withheld_categories':['raw GUI screenshots and accessibility dumps','personal paths, lsof and complete workbench/host logs','administrative authorization/reservation/start/finish control files','chat/thread/browser and external-review material','original upstream .spectra and archived source text','third-party runtime/JAR/class/library and publisher PDF/text'],'omitted_location_references':sorted(omitted.values(),key=lambda x:x['id']),'source_restoration':'SOURCE_RESTORATION.json','runtime_restoration':'RUNTIME_RESTORATION.json','claims':'Private screenshot/log review is reported by authored derivatives and independent completion attestations. Raw GUI material is intentionally not part of this anonymous candidate.'})
# Every source read is checked again; builder does not write any source location.
for name,(size,expected) in input_hashes.items():
 raw=Path(name).read_bytes();assert len(raw)==size and digest(raw)==expected,(name,'source changed during assembly')
save('TRANSFORMATION_LEDGER.json',{'schema':'v71-ad-copy-and-extraction-ledger-v1','scope':'Original evidence, AA/AC/Z and public repo remain unchanged. Every copied/extracted record has original and public byte identities. Embedded historical pins remain historical.','new_scientific_executions':0,'relocated_replay_executed':False,'scientific_BDD_or_bitset_payloads_edited':False,'files':ledger,'source_files_verified_unchanged':len(input_hashes),'generated_files_rule':'Packaging-authored README, restoration specs, index, adapters, static verifier, manifests and reports are newly authored, not historical execution receipts.'})
print(json.dumps({'status':'ASSEMBLED_STATIC_FILES_ONLY','ledger_entries':len(ledger),'dependencies':len(dependencies),'source_files_unchanged':len(input_hashes),'BDD_operations':0,'science_replay':False}))
