#!/usr/bin/env python3
"""Finalize only this static candidate. Scientific checkers are never imported."""
from pathlib import Path
import ast,base64,gzip,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parent

def pin(path):
 raw=path.read_bytes();return {'path':path.relative_to(R).as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def save(name,obj):(R/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def manifest():
 save('MANIFEST.json',{'schema':'v71-ad-private-publication-candidate-v1','public_release_authorized':False,'new_scientific_executions':0,'relocated_replay_executed':False,'source_restore_executed':False,'files':[pin(p) for p in sorted(R.rglob('*')) if p.is_file() and p.name!='MANIFEST.json']})

baselines=[]
for package in ['aa_compiled44','ac_obstacle8cert98','z_historical_patrol']:
 p=R.parent/package/'MANIFEST.json';raw=p.read_bytes();baselines.append({'path':'../'+package+'/MANIFEST.json','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
save('EXISTING_PACKAGE_BASELINES.json',{'scope':'Read-only pins of existing immutable candidates; no files in them were changed by AD packaging.','manifests':baselines})
save('INDEX.json',{'schema':'v71-ad-evidence-index-v1','status':'STATIC_PUBLICATION_CANDIDATE_NOT_PUBLISHED','technical_identifier':'ad_gui_kind_ab','manuscript_section_number':'Not assigned here; align navigation with the final manuscript.','entrypoints':{'adopted_scope':'SCIENTIFIC_DISPOSITION.json','A':'gui/A/RESULT.json','B':'gui/B/RESULT.json','lemma':'theory/SOURCE_KIND_LEMMA.txt','separate_saved_gate':'preparation/SAVED_GATE_ADOPTION.json','preserved_supervisor_UNKNOWN':'preparation/EXPORT_SUPERVISOR_PUBLIC.json','inputs':'SOURCE_RESTORATION.json','runtime':'RUNTIME_RESTORATION.json','dependency_closure':'DEPENDENCIES.json','current_saved_inputs':'SAVED_PREDICATE_INPUTS.json','future_unexecuted_adapter':'checkers/check_saved_predicates.py','static_integrity':'verify_candidate.py'},'new_science_or_replay_during_packaging':False})
# Targeted scans include compressed and encoded textual payloads, never execute them.
patterns=[re.compile('/'+'Users'+r'/[^/\s]+|/'+r'home/[^/\s]+'),re.compile(r'\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b',re.I),re.compile(r'\b(?:ghp|github_pat|sk-proj)[_-][A-Za-z0-9_-]{15,}\b')]
findings=[];count=encoded=0
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.name in {'MANIFEST.json','PRIVACY_SCAN.json','STATIC_VALIDATION.json','HANDOFF.json'}:continue
 count+=1;raw=p.read_bytes();text=(gzip.decompress(raw) if p.suffix=='.gz' else raw).decode('utf-8',errors='replace');texts=[text]
 if p.suffix=='.jsonl':
  for line in text.splitlines():
   obj=json.loads(line)
   if isinstance(obj.get('data'),str):texts.append(base64.b64decode(obj['data'],validate=True).decode('utf-8',errors='replace'));encoded+=1
 if any(pattern.search(t) for pattern in patterns for t in texts):findings.append(p.relative_to(R).as_posix())
save('PRIVACY_SCAN.json',{'status':'PASS_LIMITED_STATIC_SCAN' if not findings else 'FAIL','scanned_files_before_final_bookkeeping':count,'decoded_Base64_chunks':encoded,'findings':findings,'excluded_raw_material':'No GUI PNG/AX, source/arxived, lsof, authorizations, thread/browser/external-review material is distributed.','limits':'Targeted local-path, UUID and token-pattern scan, not a proof of all possible anonymity or secret properties.'})
if findings:raise RuntimeError('Privacy findings: '+str(findings))
ledger=json.loads((R/'TRANSFORMATION_LEDGER.json').read_text());copied={x['public_path'] for x in ledger['files']};ledger['generated_files']=[p.relative_to(R).as_posix() for p in sorted(R.rglob('*')) if p.is_file() and p.relative_to(R).as_posix() not in copied and p.name not in {'MANIFEST.json','TRANSFORMATION_LEDGER.json'}];save('TRANSFORMATION_LEDGER.json',ledger)
save('STATIC_VALIDATION.json',{'status':'PENDING_FINAL_STATIC_MANIFEST_CHECK','new_science_or_replay':False})
save('HANDOFF.json',{'schema':'v71-ad-publication-candidate-handoff-v1','status':'STATIC_CANDIDATE_PENDING_FINAL_CHECK','readme':'README.txt','manifest':'MANIFEST.json','technical_identifier_not_appendix_number':'ad_gui_kind_ab','scope':'Two fixed selected public Kind checking path observations and a source-kind existence lemma, with original preparation UNKNOWN and a separate saved-predicate gate.','publication_performed':False,'additional_science_replay_restore_network_calls':0,'source_policy':'Only authored124-byte appendix; upstream sources/arxived/runtime/literature/raw GUI and administrative records omitted.','dependency_layout':'Sibling ac_obstacle8cert98 required and pinned; no existing archive duplicated.','remaining_gate':'Parent independent static review and final manuscript/publication decision.'})
manifest()
run=subprocess.run([sys.executable,'-I','-S','-B',str(R/'verify_candidate.py')],capture_output=True,text=True)
if run.returncode:raise RuntimeError(run.stdout+run.stderr)
result=json.loads(run.stdout);save('STATIC_VALIDATION.json',result)
h=json.loads((R/'HANDOFF.json').read_text());h['status']='PASS_STATIC_CANDIDATE_ONLY_PENDING_PARENT_REVIEW';h['static_validation']='STATIC_VALIDATION.json';h['validation_counts']=result;save('HANDOFF.json',h)
manifest()
# Final pass after adding the static report and handoff. No scientific code runs.
run=subprocess.run([sys.executable,'-I','-S','-B',str(R/'verify_candidate.py')],capture_output=True,text=True)
if run.returncode:raise RuntimeError(run.stdout+run.stderr)
print(run.stdout.strip());print(json.dumps({'manifest':pin(R/'MANIFEST.json'),'handoff':pin(R/'HANDOFF.json')}))
