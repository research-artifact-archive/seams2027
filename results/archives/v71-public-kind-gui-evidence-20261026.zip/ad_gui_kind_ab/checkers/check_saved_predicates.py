#!/usr/bin/env python3
"""Read saved JSON/BDD node tables only: no solver, model build, FP or CPre."""
from pathlib import Path
import argparse,base64,datetime,hashlib,json
P=Path(__file__).resolve().parents[1]
pins={};checks={};nodes={0:None,1:None};unique={}

def pin(path):
    path=Path(path).resolve();need(path.is_relative_to(P) or path.is_relative_to(P.parent/'ac_obstacle8cert98'),'read_inside_declared_packages');raw=path.read_bytes();v={'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};pins[str(path)]=v;return raw,v

def read(path):return json.loads(pin(path)[0])
def need(ok,label):
    checks[label]=bool(ok)
    if not ok:raise RuntimeError(label)

def mk(var,lo,hi):
    if lo==hi:return lo
    need(var>=0,'nonnegative_variable_'+str(var))
    for child in (lo,hi):
        if child>1:need(nodes[child][0]>var,'ordered_relabeling')
    key=(var,lo,hi)
    if key not in unique:
        need(len(nodes)<500000,'saved_node_budget')
        k=len(nodes);nodes[k]=key;unique[key]=k
    return unique[key]

def metadata(m):
    fs={f['name']:f for f in m['fields']};need(len(fs)==len(m['fields']),'unique_fields')
    n=m['bdd_variable_count'];need(m['bdd_variable_order']==list(range(n)),'natural_order')
    allbits=[]
    for name,f in fs.items():
        need(f['domain_size']==len(f['values'])==len(set(f['values'])),'complete_values_'+name)
        need(set(f['values'])==set(f['encoding']),'complete_encoding_'+name)
        codes=[]
        for phase in ['current','next']:
            bits=f[phase+'_bits'];allbits+=bits;phasecodes=[]
            for value in f['values']:
                enc=f['encoding'][value][phase];need(set(enc)=={str(b) for b in bits},'encoding_bits_'+name+'_'+phase)
                need(all(type(v) is bool for v in enc.values()),'encoding_booleans_'+name)
                phasecodes.append(tuple(enc[str(b)] for b in bits))
            need(len(set(phasecodes))==len(phasecodes),'injective_values_'+name+'_'+phase);codes.append(phasecodes)
        need(codes[0]==codes[1],'current_next_codes_'+name)
    need(sorted(allbits)==list(range(n)),'all_bits_once')
    need(sorted(m['all_current_bits'])==sorted(b for f in fs.values() for b in f['current_bits']),'current_bit_union')
    need(sorted(m['all_next_bits'])==sorted(b for f in fs.values() for b in f['next_bits']),'next_bit_union')
    return fs

def fieldmap(old,fresh,add_helper):
    a,b=metadata(old),metadata(fresh);need(set(b)==set(a)|({'~envHelp'} if add_helper else set()),'exact_field_roster')
    mapped={}
    for name,x in a.items():
        y=b[name]
        for key in ['owner','role','domain_size','values']:need(x[key]==y[key],'field_'+name+'_'+key)
        for phase in ['current','next']:
            need(len(x[phase+'_bits'])==len(y[phase+'_bits']),'field_width_'+name+'_'+phase)
            for u,v in zip(x[phase+'_bits'],y[phase+'_bits']):
                need(u not in mapped and v not in mapped.values(),'injective_map');mapped[u]=v
                for value in x['values']:need(x['encoding'][value][phase][str(u)]==y['encoding'][value][phase][str(v)],'encoding_correspondence_'+name)
    need(len(mapped)==old['bdd_variable_count'],'complete_bit_map')
    return mapped

def load(ref,folder,mapping):
    raw,p=pin(folder/ref['file']);need(p['bytes']==ref['bytes'] and p['sha256']==ref['sha256'],'predicate_pin_'+str(folder/ref['file']))
    rows=[list(map(int,line.split())) for line in raw.decode('ascii').splitlines() if line.strip()]
    if len(rows)==1:
        need(rows[0] in ([0,0],[0,1]) and ref['node_count']==0,'constant_syntax');return rows[0][1]
    need(rows[0]==[len(mapping)] and rows[1]==list(range(len(mapping))),'saved_header')
    need(len(rows)-2==ref['node_count'],'saved_node_count');cache={0:0,1:1};last=None
    for row in rows[2:]:
        need(len(row)==4,'node_width');node,var,lo,hi=row
        need(node>1 and node not in cache and var in mapping and lo in cache and hi in cache,'node_topology')
        cache[node]=mk(mapping[var],cache[lo],cache[hi]);last=node
    need(last is not None,'root_present');return cache[last]

def restrict(root,assignments,memo=None):
    memo={} if memo is None else memo
    if root<=1:return root
    if root in memo:return memo[root]
    var,lo,hi=nodes[root]
    if var in assignments:r=restrict(hi if assignments[var] else lo,assignments,memo)
    else:r=mk(var,restrict(lo,assignments,memo),restrict(hi,assignments,memo))
    memo[root]=r;return r

def cube(bits):
    r=1
    for bit,value in sorted(bits.items(),reverse=True):r=mk(bit,0,r) if value else mk(bit,r,0)
    return r

def clean_ast(x):
    if isinstance(x,list):return [clean_ast(v) for v in x]
    if isinstance(x,dict):return {k:clean_ast(v) for k,v in x.items() if k!='trace_id'}
    return x

def inventory(m,wrapper):
    result={}
    for owner,p in m['source_inventory']['parsed'].items():
        need(p['patterns']==[] and p['triggers']==[] and p['existential_count']==0,'simple_source_'+owner)
        cs=[];inis=[]
        for c in p['constraints']:
            if c['kind']=='INI':inis.append(c['name'])
            else:cs.append({k:clean_ast(c[k]) for k in ['name','kind','spec_ast']})
        expected=[] if not wrapper or owner=='AUX' else ['retainedBoundaryEnv' if owner=='ENV' else 'retainedBoundarySys']
        need(inis==expected,'exact_initial_inventory_'+owner);result[owner]={'variables':clean_ast(p['variables']),'noninitial':cs}
    return result


ap=argparse.ArgumentParser(description="Future opt-in saved-predicate check. Not executed during packaging.")
ap.add_argument('--output',required=True,help='New JSON path outside both evidence directories')
args=ap.parse_args();output=Path(args.output).resolve()
need(not output.exists() and not output.is_relative_to(P) and not output.is_relative_to(P.parent/'ac_obstacle8cert98'),'fresh_external_output')
config=read(P/'SAVED_PREDICATE_INPUTS.json')
for name in ['fresh_model','fresh_result','prior_source_model','prior_helper_model']:
    ref=config[name];raw,current=pin(P/ref['path']);need(current['bytes']==ref['bytes'] and current['sha256']==ref['sha256'],'current_metadata_pin_'+name)
priorpath=(P/config['prior_helper_model']['path']).resolve();sourcepath=(P/config['prior_source_model']['path']).resolve();freshpath=P/config['fresh_model']['path']
prior=read(priorpath);source=read(sourcepath);fresh=read(freshpath);result=read(P/config['fresh_result']['path'])
need(result['status']=='PASS_EXPORTED_AND_BOUND_NO_SOLVER' and result['stage']=='PROCESS_FINISHED' and result['teardown']=='COMPLETED','saved_export_receipt')
need(result['model_generations']==1 and all(result[k]==0 for k in ['solver_constructions','native_strict_solver_calls','raw_four_fixed_point_calls','winning_region_computations','controller_extraction_calls']),'historical_one_model_zero_solver')
need(inventory(source,False)==inventory(fresh,True),'parsed_noninitial_inventory_unchanged')
fmap=fieldmap(prior,fresh,False);smap=fieldmap(source,fresh,True);identity={i:i for i in range(fresh['bdd_variable_count'])};fields=metadata(fresh)
priorf={k:load(v,priorpath.parent,fmap) for k,v in prior['original_bdds'].items() if k not in ['thetaE','thetaS']}
freshf={k:load(v,freshpath.parent,identity) for k,v in fresh['original_bdds'].items()}
for key in ['rhoE','rhoS','domain','domain_ENV_next','domain_SYS_next']:need(priorf[key]==freshf[key],'raw_full_'+key)
h=fields['~envHelp']['current_bits'][0];hp=fields['~envHelp']['next_bits'][0]
for current in [False,True]:
 for nxt in [False,True]:
  q=str(int(current))+str(int(nxt));assignment={h:current,hp:nxt}
  for key in ['rhoE','rhoS']:
   need(restrict(priorf[key],assignment)==restrict(freshf[key],assignment)==load(result['helper_quadrants'][q][key],freshpath.parent,identity),'raw_quadrant_'+q+'_'+key)
for owner,count in [('ENV',1),('SYS',2)]:
 old=prior['original_justices'][owner];new=fresh['original_justices'][owner];need(len(old)==len(new)==count,'ordered_justice_count_'+owner)
 for i,(a,b) in enumerate(zip(old,new)):need(load(a,priorpath.parent,fmap)==load(b,freshpath.parent,identity),'ordered_justice_'+owner+'_'+str(i))
need(source['original_justices']['ENV']==[],'source_ENV_justice_empty')
need(load(fresh['original_justices']['ENV'][0],freshpath.parent,identity)==cube({h:False}),'helper_justice_exact')
for key in ['rhoE','rhoS']:need(restrict(freshf[key],{h:False,hp:False})==load(source['original_bdds'][key],sourcepath.parent,smap),'source00_'+key)
for i,ref in enumerate(source['original_justices']['SYS']):need(restrict(load(fresh['original_justices']['SYS'][i],freshpath.parent,identity),{h:False})==load(ref,sourcepath.parent,smap),'source_SYS_justice_'+str(i))
point=config['point'];need(result['point_singleton']==point,'full_point_values');allbits={};envbits={};sysbits={}
for name,value in point.items():
 field=fields[name];bits={int(k):v for k,v in field['encoding'][value]['current'].items()};allbits.update(bits);(envbits if field['owner']=='ENV' else sysbits).update(bits)
need(freshf['thetaE']==cube(envbits),'point_thetaE_exact_nonempty');need(freshf['thetaS']==cube(sysbits),'point_thetaS_exact_nonempty');need(load(result['point_joint'],freshpath.parent,identity)==cube(allbits),'joint_exact_singleton');need(len(allbits)==len(fresh['all_current_bits']),'singleton_assigns_all_current_bits')
supervisor=read(P/'preparation/EXPORT_SUPERVISOR_PUBLIC.json');need(supervisor['status']=='UNKNOWN_SUPERVISOR_EXCEPTION','historical_UNKNOWN_preserved')
report={'status':'PASS_SAVED_PREDICATE_REPLAY','scope':'This newly executed saved-data check does not change historical supervisor UNKNOWN, supply an OS exit code, or establish GUI-model equality. No source-byte or native reproduction.','checks':checks,'nodes':len(nodes)-2,'solver_calls':0,'fixed_point_calls':0,'CPre_calls':0,'model_generations':0,'metadata_locations':'Current package and declared sibling AC, as pinned by SAVED_PREDICATE_INPUTS.json.'}
output.parent.mkdir(parents=True,exist_ok=True)
with output.open('x') as stream:json.dump(report,stream,indent=2);stream.write('\n')
print(json.dumps({'status':report['status'],'checks':len(checks),'nodes':len(nodes)-2}))
