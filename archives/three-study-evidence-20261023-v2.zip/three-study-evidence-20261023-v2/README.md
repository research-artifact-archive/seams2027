# Certificate and finite-study evidence: privacy derivative v2

This archive is a metadata-only privacy derivative of the v1 evidence bundle.
It replaces private conversation/account and editorial-review metadata in two
START_PLAN.json blocks and removes five obsolete transformation-ledger entries.
All scientific code, source formulas, BDDs, tables, study rosters, results and
certificates retain their exact prior bytes. No scientific study was executed
and no new replay qualification is asserted by this derivative.

## Historical replay and current files

REPLAY_SUMMARY.json and every relocated-replay receipt retain their exact v1
bytes. They record the earlier author-run same-host relocation check: three
studies and 418 comparisons passed. Their input and manifest pins refer to
that historical bundle, not the current redacted metadata. PRIVACY_AMENDMENT.json
binds the old and current identities and lists the complete metadata delta.
historical-metadata/ retains only the two safe historical manifests. It does
not contain the superseded private metadata or its old transformation ledger.

The current saved-study-inputs/MANIFEST.json covers the current 133-file input
tree. Its ASSEMBLED_NOT_REPLAY_QUALIFIED status is the binder's required input
status and is preserved. The current outer MANIFEST.json covers every delivered
file except itself. Use current manifests to verify the delivered tree; use
the amendment when interpreting historical execution pins.

## Inspect or replay

Read PRIVACY_AMENDMENT.json, REPLAY_SUMMARY.json and saved-study-inputs/README.md.
The inner README provides the unchanged preparation command and portable
helpers. Bind the current inner manifest and a fresh output directory before
any future replay. Historical GO and process receipts are not new execution
authority. Scientific computations use Python's standard library and included
local kernels. The unchanged supervisor requires a POSIX host with ps and
sufficient memory/disk headroom. Resource failure remains incomplete.

This evidence does not establish external replication or native regeneration.
The request model is constructed; the Humanoid source family was outcome-informed
before its fixed eight-arm study and remains non-cooperative; the Guard result
is a fixed-instance causal audit. No speed, prevalence, deployment or general
synthesizer-superiority claim follows. Third-party terms and attribution remain
in LICENSE-third-party.txt and THIRD_PARTY_NOTICES.txt.
