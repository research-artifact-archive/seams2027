"""One owned process group, resource protection, no campaign wall cutoff."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

MAX_RSS = 2 * 1024**3
MAX_TREE = 256 * 1024**2
MAX_STREAM = 16 * 1024**2
MIN_FREE = 1024**3


def pin(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def snapshot(pgid):
    p = subprocess.run(['ps', '-axo', 'pid=,ppid=,pgid=,rss='],
                       text=True, capture_output=True, check=True)
    return [dict(zip(('pid', 'ppid', 'pgid', 'rss_kib'), map(int, line.split())))
            for line in p.stdout.splitlines() if len(line.split()) == 4
            and int(line.split()[2]) == pgid]


def child_limits():
    resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_TREE, MAX_TREE))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def main():
    global MAX_RSS, MAX_TREE, MAX_STREAM, MIN_FREE
    split = sys.argv.index('--') if '--' in sys.argv else -1
    if split not in (3, 4) or len(sys.argv) <= split+1:
        raise SystemExit('Usage: run_controlled.py FRESH_RECEIPT_DIR OUTPUT_TREE [LIMITS_JSON] -- COMMAND ...')
    receipt, tree = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
    argv = sys.argv[split+1:]
    limits_pin = None
    if split == 4:
        limits_pin = pin(sys.argv[3])
        limits = json.loads(Path(sys.argv[3]).read_text())
        assert set(limits) == {'rss_bytes', 'output_tree_bytes', 'stream_bytes', 'disk_floor_bytes'}
        assert all(type(v) is int and v > 0 for v in limits.values())
        MAX_RSS, MAX_TREE, MAX_STREAM, MIN_FREE = (limits[k] for k in
            ('rss_bytes', 'output_tree_bytes', 'stream_bytes', 'disk_floor_bytes'))
    assert not receipt.exists(), 'Fresh receipt directory required'
    assert shutil.disk_usage(receipt.parent).free >= MIN_FREE, 'Disk floor before launch'
    receipt.mkdir()
    start = time.monotonic()
    record = dict(status='RUNNING', started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  argv=argv, cwd=str(Path.cwd()), python=pin(argv[0]), launcher=pin(__file__),
                  limits=dict(rss_bytes=MAX_RSS, output_tree_bytes=MAX_TREE,
                              stream_bytes=MAX_STREAM, disk_floor_bytes=MIN_FREE, wall_seconds=None),
                  limits_file=limits_pin,
                  samples=[], violations=[])
    out, err = receipt/'stdout.txt', receipt/'stderr.txt'
    child = None
    try:
        with out.open('wb') as so, err.open('wb') as se:
            env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONUNBUFFERED='1')
            env.pop('PYTHONPATH', None)
            child = subprocess.Popen(argv, stdout=so, stderr=se, env=env,
                                     start_new_session=True, preexec_fn=child_limits)
            record['owned_pid'] = record['owned_pgid'] = child.pid
            (receipt/'PROCESS.json').write_text(json.dumps(record, indent=2)+'\n')
            while child.poll() is None:
                group = snapshot(child.pid)
                rss = sum(x['rss_kib'] for x in group)*1024
                size = sum(x.stat().st_size for x in tree.rglob('*') if x.is_file()) if tree.exists() else 0
                free = shutil.disk_usage(receipt).free
                record['samples'].append(dict(seconds=time.monotonic()-start, rss_bytes=rss,
                                               output_bytes=size, free_bytes=free, owned_members=group))
                for condition, label in [(rss>MAX_RSS, 'RSS_CAP'), (size>MAX_TREE, 'OUTPUT_TREE_CAP'),
                                          (free<MIN_FREE, 'DISK_FLOOR'),
                                          (max(out.stat().st_size,err.stat().st_size)>MAX_STREAM,'STREAM_CAP')]:
                    if condition: record['violations'].append(label)
                if record['violations']:
                    os.killpg(child.pid, signal.SIGTERM)
                    break
                time.sleep(0.5)
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=5)
        remaining = snapshot(child.pid)
        if remaining:
            record['violations'].append('DESCENDANTS_SURVIVED_PARENT')
            os.killpg(child.pid, signal.SIGKILL)
            time.sleep(0.1)
            remaining = snapshot(child.pid)
        size = sum(x.stat().st_size for x in tree.rglob('*') if x.is_file()) if tree.exists() else 0
        free = shutil.disk_usage(receipt).free
        stream = max(out.stat().st_size, err.stat().st_size)
        record['final_resource_observation'] = dict(output_tree_bytes=size, stream_bytes=stream, free_bytes=free)
        for condition, label in [(size>MAX_TREE, 'FINAL_OUTPUT_TREE_CAP'),
                                 (stream>MAX_STREAM, 'FINAL_STREAM_CAP'), (free<MIN_FREE, 'FINAL_DISK_FLOOR')]:
            if condition: record['violations'].append(label)
        record.update(exit_code=child.returncode, owned_child_reaped=True,
                      final_group_observation=dict(state='ABSENT' if not remaining else 'PRESENT', members=remaining),
                      status='COMPLETE' if child.returncode==0 and not record['violations'] and not remaining else 'FAILED_OR_RESOURCE_STOP')
    except BaseException as exc:
        record.update(status='LAUNCHER_EXCEPTION', exception=repr(exc))
        if child is not None:
            try: os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError: pass
            child.wait(timeout=5)
            record['owned_child_reaped'] = True
        raise
    finally:
        record.update(seconds=time.monotonic()-start, completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        record['output_pins'] = [pin(p) for p in (out,err) if p.exists()]
        (receipt/'PROCESS.json').write_text(json.dumps(record, indent=2)+'\n')
        print(json.dumps({k:record.get(k) for k in ('status','exit_code','seconds','violations','final_group_observation')}))
    return 0 if record['status']=='COMPLETE' else 1


if __name__ == '__main__':
    raise SystemExit(main())
