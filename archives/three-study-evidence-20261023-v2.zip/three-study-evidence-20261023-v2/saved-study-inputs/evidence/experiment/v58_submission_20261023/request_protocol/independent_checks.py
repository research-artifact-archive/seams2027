"""Independent explicit safety elimination and certificate validation.

No project BDD/native code is used. This file shares the finite Game data
container, not its fixed-point solver. The formal model reader and hand
equations are separately compared before any result is admitted.
"""
from itertools import combinations
import random
from finite_game import Game, require


def rank_elimination(game):
    require(not game.guarantees, "Safety-only independent oracle: no SYS justices")
    losing, certificate = set(), {}
    for rank in range(len(game.states) + 1):
        layer = {}
        for state in game.states:
            if state in losing:
                continue
            for inp in game.inputs:
                if (state, inp) not in game.legal:
                    continue
                replies = [(out, game.target[state, inp, out]) for out in game.outputs
                           if (state, inp, out) in game.safe]
                if all(target in losing for _, target in replies):
                    layer[state] = {"rank": rank, "input": inp, "all_safe_responses": replies}
                    break
        if not layer:
            return set(game.states) - losing, certificate
        certificate.update(layer)
        losing.update(layer)
    raise ValueError("Finite losing-rank bound exceeded")


def verify_rank_certificate(game, winning, certificate):
    winning = set(winning)
    require(winning <= set(game.states), "Winning certificate outside domain")
    require(set(certificate) == set(game.states) - winning, "Complete losing complement")
    checked_replies = 0
    for state in game.states:
        if state in winning:
            for inp in game.inputs:
                if (state, inp) in game.legal:
                    require(any((state, inp, out) in game.safe
                                and game.target[state, inp, out] in winning
                                for out in game.outputs), "Winning closure")
            continue
        row = certificate[state]
        require(type(row["rank"]) is int and 0 <= row["rank"] < len(game.states), "Finite losing rank")
        inp = row["input"]
        require((state, inp) in game.legal, "Spoiler must choose legal ENV input")
        replies = [(out, game.target[state, inp, out]) for out in game.outputs
                   if (state, inp, out) in game.safe]
        require(row["all_safe_responses"] == replies, "Universal safe-response coverage")
        for _, target in replies:
            require(target in certificate and certificate[target]["rank"] < row["rank"],
                    "Every safe response decreases losing rank")
            checked_replies += 1
    return {"complete": True, "winning_states": len(winning),
            "losing_states": len(certificate), "covered_safe_responses": checked_replies}


def extract_policy(game, winning):
    """Deterministic safety-policy extraction; output order is frozen."""
    winning = set(winning)
    policy = {}
    for state in game.states:
        if state not in winning:
            continue
        for inp in game.inputs:
            if (state, inp) not in game.legal:
                continue
            choices = [out for out in game.outputs if (state, inp, out) in game.safe
                       and game.target[state, inp, out] in winning]
            require(choices, "No winning response during policy extraction")
            policy[state, inp] = choices[0]
    return policy


def direct_helper_from_source(contract, route):
    """Build helper truth tables directly from formula ASTs and helper bits.

    This intentionally does not call helper_quadrants or generalized_helper.
    """
    from source_protocol import STATES, INPUTS, PHASES, ROUTES, eval_ast
    require(route in ROUTES[1:], "Direct helper route")
    states = tuple((s, h) for s in STATES for h in (False, True))
    inputs = tuple((e, hp) for e in INPUTS for hp in (False, True))
    target, legal, safe = {}, set(), set()
    for s, h in states:
        for e, hp in inputs:
            original_env = eval_ast(contract["rhoE"], s, e, PHASES[0])
            allowed = ((not h) or hp) and (original_env or hp)
            if allowed:
                legal.add(((s, h), (e, hp)))
            for out in PHASES:
                key = ((s, h), (e, hp), out)
                target[key] = ((e[0], e[1], out), hp)
                source_safe = eval_ast(contract["rhoS"], s, e, out)
                permitted = source_safe or h or (route == ROUTES[2] and hp)
                if permitted:
                    safe.add(key)
    return Game(states, inputs, PHASES, target, frozenset(legal), frozenset(safe),
                (frozenset((s, False) for s in STATES),), ()).validate()


def exhaustive_safety(game):
    """Independent tiny-game oracle: union every closed controlled subset."""
    require(len(game.states) <= 6, "Exhaustive qualification only")
    union = set()
    for width in range(len(game.states) + 1):
        for members in combinations(game.states, width):
            candidate = set(members)
            closed = True
            for state in candidate:
                for inp in game.inputs:
                    if (state, inp) in game.legal and not any(
                            (state, inp, out) in game.safe
                            and game.target[state, inp, out] in candidate
                            for out in game.outputs):
                        closed = False
            if closed:
                union.update(candidate)
    return union


def qualification():
    """Root-executed synthetic controls, never run during preparation."""
    from finite_game import strict_win, safety_win, generalized_helper, policy_certificate
    checks = []

    def test(name, function):
        try:
            function()
            checks.append({"name": name, "pass": True})
        except Exception as exc:
            checks.append({"name": name, "pass": False, "error": repr(exc)})

    def scalar(legal, safe, assumptions=(), guarantees=()):
        return Game((0,), (0,), (0,), {(0, 0, 0): 0}, frozenset(legal), frozenset(safe),
                    assumptions, guarantees).validate()

    def deadend():
        g = scalar([], [])
        require(safety_win(g) == strict_win(g) == {0}, "Strict ENV deadend vacuity")
        require(not policy_certificate(g, {}, {0})["cooperative"], "Deadend not cooperative")
    test("environment_deadend_and_cooperation", deadend)

    def no_response():
        g = scalar([(0, 0)], [])
        w, proof = rank_elimination(g)
        require(w == safety_win(g) == strict_win(g) == set(), "Legal input without response loses")
        verify_rank_certificate(g, w, proof)
    test("unanswerable_legal_input", no_response)

    def liveness():
        good = scalar([(0, 0)], [(0, 0, 0)], (), (frozenset(),))
        vacuous = scalar([(0, 0)], [(0, 0, 0)], (frozenset(),), (frozenset(),))
        require(strict_win(good) == set() and strict_win(vacuous) == {0}, "Justice implication")
        require(not policy_certificate(good, {(0, 0): 0}, {0})["strict"], "SCC liveness detection")
        require(policy_certificate(vacuous, {(0, 0): 0}, {0})["strict"], "SCC vacuity detection")
    test("strict_justice_scc_crosscheck", liveness)

    def outer_f():
        original = scalar([], [])
        result, direct = generalized_helper(original, {
            "00": (original.legal, original.safe), "01": (frozenset({(0, 0)}), frozenset()),
            "10": (frozenset(), frozenset({(0, 0, 0)})),
            "11": (frozenset({(0, 0)}), frozenset({(0, 0, 0)}))})
        require(result["F"] == result["W_F"] == result["direct_helper_false"] == set(),
                "Outer F required at original ENV deadend")
        w, proof = rank_elimination(direct)
        require(w == strict_win(direct), "Direct safety/strict equality")
        verify_rank_certificate(direct, w, proof)
    test("outer_F_at_original_deadend", outer_f)

    def retained_u():
        states, inputs, outputs = (0, 1), (0,), (0, 1)
        targets = {(s, 0, y): y for s in states for y in outputs}
        legal = frozenset((s, 0) for s in states)
        original = Game(states, inputs, outputs, targets, legal, frozenset(targets)).validate()
        result, _ = generalized_helper(original, {
            "00": (original.legal, original.safe),
            "01": (legal, frozenset((s, 0, 1) for s in states)),
            "10": (frozenset(), original.safe),
            "11": (legal, frozenset({(0, 0, 0)}))})
        require(result["U"] == {0} and result["immediate_flip_response"] == {0, 1}
                and result["F"] == result["W_F"] == set(), "Immediate reply must enter U")
    test("retained_U_unsafe_entry", retained_u)

    def propagation():
        g = Game((0, 1, 2), (0,), (0,), {(0, 0, 0): 1, (1, 0, 0): 2, (2, 0, 0): 2},
                 frozenset({(0, 0), (1, 0), (2, 0)}),
                 frozenset({(0, 0, 0), (1, 0, 0), (2, 0, 0)})).validate()
        require(safety_win(g) == {0, 1, 2}, "Original chain wins")
        require(({0, 1} & strict_win(g.restrict({0, 1}))) == set(), "Future propagation loss")
    test("restriction_propagates_backward", propagation)

    rng = random.Random(2026102301)
    for case in range(24):
        states, inputs, outputs = tuple(range(4)), (0, 1), (0, 1)
        targets = {(s, e, y): rng.randrange(4) for s in states for e in inputs for y in outputs}
        legal = frozenset((s, e) for s in states for e in inputs if rng.randrange(4) != 0)
        safe = frozenset(t for t in targets if rng.randrange(3) != 0)
        game = Game(states, inputs, outputs, targets, legal, safe).validate()

        def check_safety(game=game):
            w, proof = rank_elimination(game)
            require(w == exhaustive_safety(game) == safety_win(game) == strict_win(game),
                    "Exhaustive closed subsets / ranks / fixed points disagree")
            verify_rank_certificate(game, w, proof)
        test("small_exhaustive_safety_%02d" % case, check_safety)

    for case in range(24):
        states, inputs, outputs = tuple(range(4)), (0, 1), (0,)
        targets = {(s, e, 0): rng.randrange(4) for s in states for e in inputs}
        legal = frozenset((s, e) for s in states for e in inputs if rng.randrange(5) != 0)
        safe = frozenset(t for t in targets if rng.randrange(5) != 0)
        assumptions = tuple(frozenset(s for s in states if rng.randrange(2)) for _ in range(case % 3))
        guarantees = tuple(frozenset(s for s in states if rng.randrange(2)) for _ in range((case // 3) % 3))
        game = Game(states, inputs, outputs, targets, legal, safe, assumptions, guarantees).validate()
        policy = {(s, e): 0 for s, e in legal}

        def check_scc(game=game, policy=policy):
            independently_winning = {s for s in game.states
                                     if policy_certificate(game, policy, {s})["strict"]}
            require(strict_win(game) == independently_winning, "One-choice fixedpoint / SCC mismatch")
        test("one_choice_justice_SCC_%02d" % case, check_scc)
    return {"schema": "request-protocol-synthetic-qualification-v1",
            "status": "PASS" if all(c["pass"] for c in checks) else "FAIL",
            "checks": checks, "scientific_protocol_runs": 0}
