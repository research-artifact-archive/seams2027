"""Explicit transcription of REQUEST_ENABLE_STAGED_OPERATION_V1.

Constructed author-controlled protocol; not a natural benchmark. The formulas
come from the pinned V58 operational-study advisory. There is no compiler,
native runtime, source monitor, or hidden private controller state here.
"""
from itertools import product
from finite_game import Game, require

PHASES = ("IDLE", "PREPARE", "EXECUTE")
FIELDS = ("request", "ready", "phase")
INPUTS = tuple(product((False, True), repeat=2))
STATES = tuple((request, ready, phase)
               for request, ready in INPUTS for phase in PHASES)
MODES = ("OLD_request_disabled", "NEW_request_enabled")
ROUTES = ("ORIGINAL_strict", "COMPLETE_LITERAL_HELPER_strict",
          "COMPLETE_FIRST_FLIP_CORRECTED_HELPER_strict")
S0 = (False, True, "IDLE")
S1 = (False, False, "IDLE")
OLD_PREFIX = ((False, False),)
SUFFIX = {
    "OLD_request_disabled": ((False, False),),
    "NEW_request_enabled": ((True, False), (False, False),
                            (False, True), (False, False), (False, False)),
}


def source_dict(state):
    require(state in STATES, "State outside exact three-phase carrier")
    return dict(zip(FIELDS, state))


def source_tuple(state):
    require(isinstance(state, dict) and set(state) == set(FIELDS), "Complete source fields")
    require(type(state["request"]) is bool and type(state["ready"]) is bool,
            "Boolean source field types")
    value = tuple(state[k] for k in FIELDS)
    require(value in STATES, "Typed phase value")
    return value


def env_legal(mode, state, next_input):
    require(mode in MODES and state in STATES and next_input in INPUTS, "Typed ENV call")
    phase = state[2]
    next_request, next_ready = next_input
    shared = (phase != "EXECUTE" or next_ready) and (phase == "IDLE" or not next_request)
    return shared and (mode != "OLD_request_disabled" or not next_request)


def sys_safe(state, next_input, next_phase):
    require(state in STATES and next_input in INPUTS and next_phase in PHASES, "Typed SYS call")
    phase = state[2]
    next_request, next_ready = next_input
    if phase == "IDLE":
        return next_phase == ("PREPARE" if next_request else "IDLE")
    if phase == "PREPARE":
        return next_phase == "EXECUTE"
    return next_ready and next_phase == "IDLE"


def original_game(mode):
    target = {(s, e, y): (e[0], e[1], y)
              for s in STATES for e in INPUTS for y in PHASES}
    legal = frozenset((s, e) for s in STATES for e in INPUTS if env_legal(mode, s, e))
    safe = frozenset(t for t in target if sys_safe(*t))
    return Game(STATES, INPUTS, PHASES, target, legal, safe).validate()


def canonical_policy(mode):
    """Predetermined source response rule, only on that model's legal inputs.

    OLD off-contract request behavior is deliberately undefined and remains
    missing when this stored table is checked against NEW.
    """
    table = {}
    for s in STATES:
        for e in INPUTS:
            if env_legal(mode, s, e):
                table[s, e] = ("PREPARE" if e[0] else "IDLE") if s[2] == "IDLE" else (
                    "EXECUTE" if s[2] == "PREPARE" else "IDLE")
    return table


def helper_quadrants(game, route):
    require(route in ROUTES[1:], "Helper semantic route")
    all_inputs = frozenset((s, e) for s in STATES for e in INPUTS)
    all_replies = frozenset(game.target)
    first = game.safe if route == ROUTES[1] else all_replies
    return {"00": (game.legal, game.safe),
            "01": (all_inputs, first),
            "10": (frozenset(), all_replies),
            "11": (all_inputs, all_replies)}


def eval_ast(node, state, next_input=None, next_phase=None):
    """Declarative source reader, separately written from the hand equations."""
    require(isinstance(node, dict), "Formula AST object")
    if "const" in node:
        require(set(node) == {"const"}, "Constant node fields")
        return node["const"]
    if "var" in node:
        require(set(node) == {"var", "time"}, "Variable node fields")
        name, time = node["var"], node["time"]
        require(name in FIELDS and time in ("current", "next"), "Variable or phase")
        if time == "current":
            return source_dict(state)[name]
        require(next_input is not None and next_phase is not None, "Next value needed")
        return {"request": next_input[0], "ready": next_input[1], "phase": next_phase}[name]
    require(set(node) == {"op", "args"}, "Operator node fields")
    op, args = node["op"], node["args"]
    values = [eval_ast(n, state, next_input, next_phase) for n in args]
    if op in ("eq", "ne"):
        require(len(values) == 2 and type(values[0]) is type(values[1]), "Typed comparison")
        return values[0] == values[1] if op == "eq" else values[0] != values[1]
    require(all(type(v) is bool for v in values), "Boolean connective values")
    if op == "not":
        require(len(values) == 1, "Unary not")
        return not values[0]
    if op == "implies":
        require(len(values) == 2, "Binary implies")
        return not values[0] or values[1]
    require(op in ("and", "or") and len(values) >= 1, "Supported nonempty connective")
    return all(values) if op == "and" else any(values)


def declarative_game(contract):
    require(contract["schema"] == "constructed-request-protocol-source-v1", "Source schema")
    require(contract["mode"] in MODES, "Source mode")
    require(contract["fields"] == {"ENV": {"request": [False, True], "ready": [False, True]},
                                   "SYS": {"phase": list(PHASES)}, "AUX": []}, "Source fields")
    require(contract["justice_ENV"] == contract["justice_SYS"] == [], "Empty justices")
    target, legal, safe = {}, set(), set()
    for s in STATES:
        for e in INPUTS:
            # Check ENV next-SYS independence instead of assuming it.
            observed = [eval_ast(contract["rhoE"], s, e, y) for y in PHASES]
            require(all(type(v) is bool for v in observed) and len(set(observed)) == 1,
                    "ENV must not depend on next SYS")
            if observed[0]:
                legal.add((s, e))
            for y in PHASES:
                target[s, e, y] = (e[0], e[1], y)
                answer = eval_ast(contract["rhoS"], s, e, y)
                require(type(answer) is bool, "Boolean SYS relation")
                if answer:
                    safe.add((s, e, y))
    return Game(STATES, INPUTS, PHASES, target, frozenset(legal), frozenset(safe)).validate()


def initial_test(contract, region):
    """Keep quantified ENV/SYS initialization separate from fixed S1 queries."""
    region = set(region)
    missing, witnesses = [], []
    for request, ready in INPUTS:
        env_results = [eval_ast(contract["thetaE"], (request, ready, y)) for y in PHASES]
        require(len(set(env_results)) == 1, "ENV initializer next-SYS independence")
        if not env_results[0]:
            continue
        matching = [(request, ready, y) for y in PHASES
                    if eval_ast(contract["thetaS"], (request, ready, y)) and (request, ready, y) in region]
        witnesses.extend(matching)
        if not matching:
            missing.append((request, ready))
    return {"value": not missing, "missing_ENV": missing, "SYS_witnesses": witnesses}


def validate_source_pair(old, new):
    """Only the single request_next prohibition may differ semantically."""
    for key in ("fields", "thetaE", "thetaS", "rhoS", "justice_ENV", "justice_SYS", "timing"):
        require(old[key] == new[key], "Forbidden source change: " + key)
    require(old["rhoE"] == {"op": "and", "args": [new["rhoE"],
            {"op": "not", "args": [{"var": "request", "time": "next"}]}]},
            "OLD must add exactly not request_next")


def bind_boundary(state):
    require(source_tuple(state) == S1, "Boundary must retain all three exact S1 values")
    return S1
