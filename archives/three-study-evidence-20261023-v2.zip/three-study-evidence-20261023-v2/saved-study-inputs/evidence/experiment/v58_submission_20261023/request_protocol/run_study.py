#!/usr/bin/env python3
"""Single root-authorized finite request-protocol study; no native execution.

Prepared code only until root freezes the exact plan and writes a matching GO.
All six cells and the one predeclared routing episode are retained, including
negative conclusions and cells not attempted after an integrity failure.
"""
import sys
sys.dont_write_bytecode = True
import argparse
import hashlib
import json
import os
from pathlib import Path
import time
import traceback
from datetime import datetime, timezone

from finite_game import require, strict_win, safety_win, generalized_helper, policy_certificate
from source_protocol import (STATES, INPUTS, PHASES, MODES, ROUTES, S0, S1,
    OLD_PREFIX, SUFFIX, source_dict, source_tuple, env_legal, sys_safe,
    original_game, canonical_policy, helper_quadrants, declarative_game,
    validate_source_pair, eval_ast, initial_test, bind_boundary)
from independent_checks import (rank_elimination, verify_rank_certificate,
    direct_helper_from_source, extract_policy, qualification)

HERE = Path(__file__).resolve().parent
CODE_FILES = ("finite_game.py", "source_protocol.py", "independent_checks.py", "run_study.py")


def now():
    return datetime.now(timezone.utc).isoformat()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON key")
        result[key] = value
    return result


def read(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= 8 * 1024 * 1024,
            "Bounded regular input file")
    return json.loads(path.read_text(), object_pairs_hook=unique_object)


def pin(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def save(path, data):
    raw = (json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()
    require(len(raw) <= 8 * 1024 * 1024, "Output file cap8MiB")
    with Path(path).open("xb") as stream:
        stream.write(raw)


def regions_payload(regions):
    return {name: sorted(value, key=repr) for name, value in regions.items()}


def policy_payload(policy):
    return [{"state": state, "input": inp, "output": output}
            for (state, inp), output in sorted(policy.items(), key=lambda item: repr(item[0]))]


def rank_payload(proof):
    return [{"state": state, **row} for state, row in sorted(proof.items(), key=lambda item: repr(item[0]))]


def authority(plan_path, go_path, output):
    plan, go = read(plan_path), read(go_path)
    require(plan["schema"] == "request-protocol-study-plan-v1"
            and plan["status"] == "FROZEN_FOR_SINGLE_ROOT_EXECUTION", "Parent-frozen study plan")
    require(go.get("schema") == "request-protocol-execution-go-v1"
            and go.get("authorized") is True and go.get("scope") == "FULL_STUDY", "Exact root scope")
    require(type(go.get("attempt")) is int and go["attempt"] == 1, "One attempt")
    require(go.get("plan") == pin(plan_path), "GO binds current plan")
    require(go.get("output") == str(output.resolve()) and not output.exists(), "Fresh exact output directory")
    require(go.get("ordinary_usage_gate_confirmed") is True, "Parent ordinary-usage gate")
    require(plan["models"] == list(MODES) and plan["routes"] == list(ROUTES), "Complete source/route roster")
    require(plan["roster"] == [{"mode": m, "route": r} for m in MODES for r in ROUTES], "Six fixed cells")
    require(plan["old_prefix_inputs"] == [list(x) for x in OLD_PREFIX], "Frozen positive-length prefix")
    require(plan["suffix_inputs"] == {k: [list(x) for x in v] for k, v in SUFFIX.items()}, "Frozen suffix scripts")
    require(plan["initial_state"] == source_dict(S0) and plan["boundary"] == source_dict(S1), "Exact states")
    require(plan["routing_order"] == [ROUTES[1], ROUTES[2], ROUTES[0]], "Frozen route order")
    require(plan["episode_roster"] == "six_route_cells_plus_one_NEW_routing_episode", "Seven fixed episodes")
    mandatory = [pin(HERE / name) for name in CODE_FILES]
    mandatory += [plan["sources"][mode] for mode in MODES]
    mandatory += [plan["formal_advisory"]]
    require(isinstance(go.get("files"), list) and go["files"] == mandatory, "Exact code/source/advisory roster")
    for ref in mandatory:
        require(pin(ref["path"]) == ref, "Input bytes changed: " + ref["path"])
    return plan, mandatory + [pin(plan_path), pin(go_path)]


def source_controls(contracts):
    validate_source_pair(contracts[MODES[0]], contracts[MODES[1]])
    checks = []
    games = {}
    for mode in MODES:
        hand = original_game(mode)
        declared = declarative_game(contracts[mode])
        require(hand.target == declared.target and hand.legal == declared.legal and hand.safe == declared.safe,
                "Whole source hand-equation/AST relation equality")
        initial = {s for s in STATES if eval_ast(contracts[mode]["thetaE"], s)
                   and eval_ast(contracts[mode]["thetaS"], s)}
        require(initial == {S0} and S1 not in initial, "Exact shared initializer and noninitial boundary")
        games[mode] = hand
        checks.append({"mode": mode, "source_truth_tables_equal": True,
                       "current_input_output_combinations": len(STATES) * len(INPUTS) * len(PHASES),
                       "exact_initialized_states": sorted(initial), "S1_noninitial": True})
    negative = []

    def rejects(name, fn):
        try:
            fn()
        except (ValueError, KeyError, TypeError):
            negative.append({"name": name, "rejected": True})
            return
        raise ValueError("Negative control was not rejected: " + name)

    rejects("reset_boundary_ready", lambda: bind_boundary(source_dict(S0)))
    rejects("omitted_phase", lambda: bind_boundary({"request": False, "ready": False}))
    bad = canonical_policy(MODES[1])
    bad[S1, (True, False)] = "IDLE"
    require(not policy_certificate(games[MODES[1]], bad, {S1})["coverage_and_safety"], "Ignoring request rejected")
    negative.append({"name": "ignore_enabled_request", "rejected": True})
    bad = canonical_policy(MODES[1])
    for s in STATES:
        if s[2] == "PREPARE":
            for e in INPUTS:
                if (s, e) in bad:
                    bad[s, e] = "PREPARE"
    require(not policy_certificate(games[MODES[1]], bad, {S1})["coverage_and_safety"], "PREPARE stall rejected")
    negative.append({"name": "stall_PREPARE", "rejected": True})
    for mode, game in games.items():
        incorrect = game.pre(STATES)
        require(incorrect != game.local_total(), "Original-illegal inputs must remain in local C")
    negative.append({"name": "filter_ENV_illegal_inputs_from_C", "rejected": True})
    wrong_guard = direct_helper_from_source(contracts[MODES[1]], ROUTES[1])
    expected_guard = direct_helper_from_source(contracts[MODES[1]], ROUTES[2])
    rejects("current_helper_guard_substituted_for_complete_correction",
            lambda: require(wrong_guard.safe == expected_guard.safe,
                            "Incorrect current/next helper guard truth table"))
    return games, {"status": "PASS", "whole_source_checks": checks, "negative_controls": negative}


def project_source_policy(game, policy, helper):
    result = {}
    for state in STATES:
        for inp in INPUTS:
            key = ((state, False), (inp, False)) if helper else (state, inp)
            if key in policy:
                result[state, inp] = policy[key]
    return result


class Episode:
    """One source object and actual step/commit operations, no endpoint load."""
    def __init__(self, episode_id, events):
        self.episode_id = episode_id
        self.events = events
        self.source = source_dict(S0)
        self.source_identity = id(self.source)
        self.mode = MODES[0]
        self.policy = canonical_policy(MODES[0])
        self.controller = object()
        self.paused = False
        self.emit("start", source=self.source.copy(), controller=id(self.controller), mode=self.mode)

    def emit(self, kind, **values):
        self.events.append({"sequence": len(self.events), "episode_id": self.episode_id,
                            "event": kind, "source_object": self.source_identity,
                            "pid": os.getpid(), "monotonic_ns": time.monotonic_ns(), **values})

    def step(self, inp, stage):
        require(not self.paused and id(self.source) == self.source_identity, "Active same source object")
        before = source_tuple(self.source)
        require(env_legal(self.mode, before, inp), "Offered input violates actual source ENV relation")
        require((before, inp) in self.policy, "Installed graph lacks legal-input response")
        choice = self.policy[before, inp]
        require(sys_safe(before, inp, choice), "Installed response violates original SYS safety")
        after = (inp[0], inp[1], choice)
        self.source.clear()
        self.source.update(source_dict(after))
        self.emit("commit", stage=stage, mode=self.mode, controller=id(self.controller),
                  before=source_dict(before), offered_input=list(inp), output=choice,
                  after=self.source.copy())
        return after

    def boundary(self, mode):
        for inp in OLD_PREFIX:
            self.step(inp, "old_prefix")
        bind_boundary(self.source)
        self.paused = True
        self.emit("pause", source=self.source.copy(), controller=id(self.controller), mode=self.mode)
        old_mode = self.mode
        self.mode = mode
        self.emit("contract_update", before_mode=old_mode, after_mode=mode,
                  deleted_conjunct="not request_next" if mode == MODES[1] else None,
                  source=self.source.copy(), reinitialized=False)

    def install_and_run(self, route, policy, candidate_certificate):
        require(self.paused and bind_boundary(self.source) == S1, "Paused exact S1")
        require(candidate_certificate["strict"] and candidate_certificate["cooperative"]
                and candidate_certificate["coverage_and_safety"], "Original graph admission")
        old_controller = id(self.controller)
        self.controller = object()
        require(id(self.controller) != old_controller, "Fresh controller instance")
        self.policy = policy
        self.emit("install", route=route, old_controller=old_controller,
                  controller=id(self.controller), source=self.source.copy(), private_memory="none")
        self.paused = False
        states = [S1]
        for inp in SUFFIX[self.mode]:
            states.append(self.step(inp, "post_change"))
        require(states[-1] == states[-2], "Frozen script must traverse final self-loop to certify finite cycle")
        self.emit("completed", source=self.source.copy(), executed_transitions=len(SUFFIX[self.mode]),
                  observed_new_request=any(e[0] for e in SUFFIX[self.mode]),
                  observed_EXECUTE=any(s[2] == "EXECUTE" for s in states))
        return {"status": "EXECUTED_SOURCE_FAIR_LASSO", "route": route,
                "states": states, "post_change_commits": len(SUFFIX[self.mode]),
                "new_request_exercised": any(e[0] for e in SUFFIX[self.mode]),
                "EXECUTE_observed": any(s[2] == "EXECUTE" for s in states),
                "source_object_retained": id(self.source) == self.source_identity}


def episode(mode, route, data, events, route_order=None):
    name = mode + "__" + (route if route is not None else "ROUTING_POLICY")
    runtime = Episode(name, events)
    runtime.boundary(mode)
    choices = route_order or [route]
    considered, selected = [], None
    for choice in choices:
        row = data[mode, choice]
        admitted = row["entry_strict"] and row["source_graph_certificate"]["strict"] \
            and row["source_graph_certificate"]["cooperative"] \
            and row["source_graph_certificate"]["coverage_and_safety"]
        considered.append({"route": choice, "entry_strict": row["entry_strict"],
                           "graph_admitted": admitted})
        if admitted:
            selected = choice
            break
    runtime.emit("admission", candidates=considered, selected_route=selected,
                 source=runtime.source.copy())
    if selected is None:
        runtime.emit("remain_paused", reason="No frozen candidate satisfies exact entry and original graph checks",
                     source=runtime.source.copy())
        return {"episode_id": name, "status": "ABSTAINED_REMAINS_PAUSED",
                "considered": considered, "source_object_retained": True, "source": runtime.source.copy()}
    row = data[mode, selected]
    return {"episode_id": name, "considered": considered,
            **runtime.install_and_run(selected, row["source_policy"], row["source_graph_certificate"])}


def audit_events(events, contracts, live_data, routing_order):
    """Separate declarative-source audit; does not call Episode transitions."""
    by_id = {}
    for sequence, event in enumerate(events):
        require(event["sequence"] == sequence, "Contiguous global event sequence")
        by_id.setdefault(event["episode_id"], []).append(event)
    audited = []
    for name, rows in by_id.items():
        require(rows[0]["event"] == "start" and rows[0]["source"] == source_dict(S0), "Actual original start")
        state, mode = S0, MODES[0]
        source_id = rows[0]["source_object"]
        controller = rows[0]["controller"]
        paused, prefix_count, suffix_count, installed = False, 0, 0, False
        selected, admitted = None, False
        prior_clock = -1
        for event in rows:
            require(event["source_object"] == source_id and event["pid"] == rows[0]["pid"], "Source object/PID continuity")
            require(type(event["monotonic_ns"]) is int and event["monotonic_ns"] >= prior_clock,
                    "Monotonic episode clock order")
            prior_clock = event["monotonic_ns"]
            kind = event["event"]
            if kind == "commit":
                require(not paused and event["controller"] == controller, "Actual active controller commit")
                require(source_tuple(event["before"]) == state and event["mode"] == mode, "Event source/mode continuity")
                inp, out = tuple(event["offered_input"]), event["output"]
                require(eval_ast(contracts[mode]["rhoE"], state, inp, out), "Event ENV equation")
                require(eval_ast(contracts[mode]["rhoS"], state, inp, out), "Event SYS equation")
                later = (inp[0], inp[1], out)
                require(source_tuple(event["after"]) == later, "Event complete source update")
                state = later
                if event["stage"] == "old_prefix":
                    require(mode == MODES[0] and inp == OLD_PREFIX[prefix_count], "Fixed old prefix input")
                    prefix_count += 1
                else:
                    require(installed and inp == SUFFIX[mode][suffix_count], "Fixed actual suffix input")
                    suffix_count += 1
            elif kind == "pause":
                require(prefix_count == 1 and state == S1 and source_tuple(event["source"]) == S1, "Positive-length exact boundary")
                paused = True
            elif kind == "contract_update":
                require(paused and state == S1 and event["before_mode"] == mode and event["reinitialized"] is False,
                        "Atomic update without source reset")
                mode = event["after_mode"]
                require(mode == name.split("__", 1)[0], "Episode model fixed before execution")
                require(source_tuple(event["source"]) == state, "Source unchanged at model update")
                require(event["deleted_conjunct"] == ("not request_next" if mode == MODES[1] else None),
                        "Only frozen ENV conjunct removed")
            elif kind == "admission":
                require(paused and not admitted and source_tuple(event["source"]) == S1,
                        "One admission at retained boundary")
                choices = routing_order if name.endswith("__ROUTING_POLICY") else [name.split("__", 1)[1]]
                expected, selected = [], None
                for choice in choices:
                    data = live_data[mode, choice]
                    cert = data["source_graph_certificate"]
                    qualifies = data["entry_strict"] and cert["strict"] and cert["cooperative"] and cert["coverage_and_safety"]
                    expected.append({"route": choice, "entry_strict": data["entry_strict"], "graph_admitted": qualifies})
                    if qualifies:
                        selected = choice
                        break
                require(event["candidates"] == expected and event["selected_route"] == selected,
                        "Frozen admission order and exact certificate results")
                admitted = True
            elif kind == "install":
                require(paused and admitted and selected is not None and event["route"] == selected
                        and state == S1 and event["old_controller"] == controller, "Installation boundary and selected route")
                require(source_tuple(event["source"]) == state and event["controller"] != controller, "New controller same source")
                controller, paused, installed = event["controller"], False, True
            elif kind == "remain_paused":
                require(paused and admitted and selected is None and not installed and suffix_count == 0 and state == S1,
                        "Abstention preserves boundary")
            elif kind == "completed":
                require(installed and not paused and suffix_count == len(SUFFIX[mode]), "Every frozen suffix step actually committed")
        require(rows[-1]["event"] in ("remain_paused", "completed"), "Complete episode ending")
        audited.append({"episode_id": name, "pass": True, "prefix_commits": prefix_count,
                        "suffix_commits": suffix_count, "terminal_event": rows[-1]["event"]})
    require(len(audited) == 7, "All six route cells and one routing episode audited")
    return {"status": "PASS", "episodes": audited, "shared_source_AST_reader": True,
            "runtime_equations_are_handwritten_separately": True,
            "independent_blind_implementation": False}


def run(plan, output, refs):
    result = {"schema": "request-protocol-study-result-v1", "status": "UNKNOWN_INCOMPLETE",
              "created_utc": now(), "constructed_author_control": True, "natural_benchmark": False,
              "source_classification": plan["source_classification"], "input_pins": refs,
              "cells": [{**row, "status": "NOT_ATTEMPTED"} for row in plan["roster"]],
              "episodes": [], "native_calls": 0, "compiler_calls": 0, "BDD_calls": 0,
              "full_reset_uses": 0, "errors": []}
    events, live_data = [], {}
    start = time.monotonic()
    try:
        q = qualification()
        save(output / "QUALIFICATION.json", q)
        require(q["status"] == "PASS", "Synthetic qualification failed")
        contracts = {m: read(plan["sources"][m]["path"]) for m in MODES}
        games, source_check = source_controls(contracts)
        save(output / "SOURCE_CORRESPONDENCE.json", source_check)
        original_data = {}
        for mode in MODES:
            game = games[mode]
            w = strict_win(game)
            ranked_w, proof = rank_elimination(declarative_game(contracts[mode]))
            require(w == safety_win(game) == ranked_w, "Original three independent safety views")
            rank_check = verify_rank_certificate(game, ranked_w, proof)
            canonical = canonical_policy(mode)
            each = [{"state": s, **policy_certificate(game, canonical, {s})} for s in STATES]
            all_states = all(row["strict"] and row["cooperative"] for row in each)
            original_data[mode] = {"W": w, "C": game.local_total(), "canonical": canonical,
                                   "all_states_policy": each, "K_equals_D_certified": all_states}
            save(output / (mode + "_SOURCE_CERTIFICATE.json"), {
                "W": sorted(w), "C": sorted(game.local_total()), "safety_rank_check": rank_check,
                "canonical_policy": policy_payload(canonical), "all_root_certificates": each,
                "exact_K": list(STATES) if all_states else None,
                "exact_K_scope": "D by certified strict/cooperative strategy at every typed state" if all_states
                                 else "UNKNOWN: policy certificate is only a lower bound, exact K not solved",
                "initial": initial_test(contracts[mode], w)})
        for index, roster in enumerate(plan["roster"]):
            mode, route = roster["mode"], roster["route"]
            original = games[mode]
            w, c = original_data[mode]["W"], original_data[mode]["C"]
            regions = {"W_original": w, "C": c}
            helper = route != ROUTES[0]
            if helper:
                decomposition, direct = generalized_helper(original, helper_quadrants(original, route))
                independently_assembled = direct_helper_from_source(contracts[mode], route)
                require(direct == independently_assembled, "Whole direct helper truth-table/objective equality")
                direct_w = strict_win(direct)
                independent_w, proof = rank_elimination(independently_assembled)
                require(direct_w == independent_w, "Direct helper strict fixedpoint versus independent safety ranks")
                verify_rank_certificate(independently_assembled, independent_w, proof)
                require(decomposition["W_F"] == decomposition["direct_helper_false"]
                        and decomposition["U"] == decomposition["direct_helper_true"], "Exact decomposition equality")
                active = decomposition["W_F"]
                require(active <= w and ((active == w) == (w <= decomposition["F"])),
                        "Exact full-preservation equivalence and subset")
                regions.update(decomposition)
                if route == ROUTES[1]:
                    wc = c & strict_win(original.restrict(c))
                    require(decomposition["F"] == c and active == wc, "Complete literal W_C correspondence")
                    regions["W_C"] = wc
                policy = extract_policy(direct, direct_w)
                source_policy = project_source_policy(direct, policy, True)
                graph_certificate = policy_certificate(direct, policy, {(S1, False)})
                save(output / (mode + "__" + route + "_LOSING_CERTIFICATE.json"), {
                    "scope": "Strict safety complement; all typed safe SYS responses covered",
                    "winning": sorted(direct_w, key=repr), "losing_ranks": rank_payload(proof),
                    "checks": verify_rank_certificate(direct, direct_w, proof)})
            else:
                direct, active = original, w
                policy = extract_policy(original, w)
                source_policy = project_source_policy(original, policy, False)
                graph_certificate = policy_certificate(original, policy, {S1})
            source_certificate = policy_certificate(original, source_policy, {S1})
            entry = S1 in active
            row = {"mode": mode, "route": route, "status": "COMPLETE",
                   "entry_strict": entry, "entry_source": source_dict(S1),
                   "initializer": initial_test(contracts[mode], active),
                   "region_counts": {k: len(v) for k, v in regions.items()},
                   "regions": regions_payload(regions), "all_states": [
                       {"state": s, "source_W": s in w, "local_C": s in c, "route_strict": s in active,
                        "F": s in regions["F"] if helper else None,
                        "original_initialized": bool(eval_ast(contracts[mode]["thetaE"], s)
                                                     and eval_ast(contracts[mode]["thetaS"], s))} for s in STATES],
                   "global_W_subset_F": w <= regions["F"] if helper else None,
                   "original_full_region_preserved": active == w,
                   "entry_policy_available": entry,
                   "policy_scope": "Table is defined only on the computed safety winning region; absence at S1 is a refusal, not a returned controller at S1",
                   "actual_route_graph": {"policy": policy_payload(policy), "certificate": graph_certificate},
                   "actual_original_source_graph": {"policy": policy_payload(source_policy), "certificate": source_certificate},
                   "helper_graph_cooperation_is_not_original_cooperation": helper}
            result["cells"][index] = row
            live_data[mode, route] = {"entry_strict": entry, "source_policy": source_policy,
                                      "source_graph_certificate": source_certificate}
        comparisons = []
        for pair in plan["graph_comparisons"]:
            policy = original_data[pair["graph"]]["canonical"]
            comparisons.append({**pair, "certificate": policy_certificate(games[pair["model"]], policy, {S1})})
        result["canonical_graph_comparisons"] = comparisons
        result["old_off_contract_behavior"] = plan["old_off_contract_behavior"]
        literal = [next(row for row in result["cells"] if row["mode"] == mode and row["route"] == ROUTES[1])
                   for mode in MODES]
        result["decision_comparison"] = {
            "same_full_boundary": source_dict(S1),
            "local_C_at_boundary": [S1 in original_data[mode]["C"] for mode in MODES],
            "original_W_at_boundary": [S1 in original_data[mode]["W"] for mode in MODES],
            "literal_exact_at_boundary": [row["entry_strict"] for row in literal],
            "global_W_subset_F": [row["global_W_subset_F"] for row in literal],
            "literal_whole_F_functions_equal": literal[0]["regions"]["F"] == literal[1]["regions"]["F"],
            "literal_whole_W_F_functions_equal": literal[0]["regions"]["W_F"] == literal[1]["regions"]["W_F"],
            "original_ENV_relation_changed": games[MODES[0]].legal != games[MODES[1]].legal,
            "scope": "Equal F across different original ENV relations need not yield equal W_F. No claim of superiority to direct original solving, conservative global rejection, or full graph checking."}
        for mode in MODES:
            for route in ROUTES:
                result["episodes"].append(episode(mode, route, live_data, events))
        result["episodes"].append(episode(MODES[1], None, live_data, events, plan["routing_order"]))
        result["event_audit"] = audit_events(events, contracts, live_data, plan["routing_order"])
        result["K_equals_D_certified"] = {m: original_data[m]["K_equals_D_certified"] for m in MODES}
        result["no_favorable_outcome_acceptance_assertion"] = True
        for ref in refs:
            require(pin(ref["path"]) == ref, "Post-execution input pin drift")
        result["status"] = "COMPLETE_ALL_SIX_CELLS_AND_SEVEN_EPISODES"
    except MemoryError as exc:
        result["status"] = "UNKNOWN_RESOURCE"
        result["errors"].append(repr(exc))
    except Exception as exc:
        result["status"] = "FAIL_INTEGRITY_OR_QUALIFICATION"
        result["errors"].append(repr(exc))
        result["traceback"] = traceback.format_exc()
    finally:
        result["finished_utc"] = now()
        result["elapsed_seconds"] = time.monotonic() - start
        save(output / "EVENTS.json", events)
        save(output / "RESULT.json", result)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", required=True)
    parser.add_argument("--go", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    output = Path(args.output).resolve()
    plan, refs = authority(args.plan, args.go, output)
    output.mkdir(parents=True, exist_ok=False)
    result = run(plan, output, refs)
    total = sum(p.stat().st_size for p in output.iterdir() if p.is_file())
    require(total <= plan["resources"]["max_output_tree_bytes"], "Final output tree cap")
    print(json.dumps({"status": result["status"], "output": str(output), "bytes": total,
                      "errors": result["errors"]}, ensure_ascii=False), flush=True)
    return 0 if result["status"] == "COMPLETE_ALL_SIX_CELLS_AND_SEVEN_EPISODES" else 2


if __name__ == "__main__":
    raise SystemExit(main())
