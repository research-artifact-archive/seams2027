"""Finite-set strict-game and complete-policy checks for a frozen small arena.

This module imports no project scientific code. Relations are explicit finite
tables supplied by the protocol adapter. No work is performed at import time.
"""
from dataclasses import dataclass


def require(test, message):
    if not test:
        raise ValueError(message)


@dataclass(frozen=True)
class Game:
    states: tuple
    inputs: tuple
    outputs: tuple
    # target[(state, input, output)] is the unique typed next source state.
    target: dict
    # ENV may not depend on the next SYS choice.
    legal: frozenset
    safe: frozenset
    assumptions: tuple = ()
    guarantees: tuple = ()

    def validate(self):
        require(0 < len(self.states) <= 256, "Finite state limit")
        require(0 < len(self.inputs) <= 32, "Finite input limit")
        require(0 < len(self.outputs) <= 32, "Finite output limit")
        require(len(set(self.states)) == len(self.states), "Duplicate state")
        require(len(set(self.inputs)) == len(self.inputs), "Duplicate input")
        require(len(set(self.outputs)) == len(self.outputs), "Duplicate output")
        triples = {(s, e, y) for s in self.states for e in self.inputs for y in self.outputs}
        require(set(self.target) == triples, "Total typed target mapping")
        require(set(self.target.values()) <= set(self.states), "Target outside carrier")
        require(self.legal <= {(s, e) for s in self.states for e in self.inputs}, "Bad ENV relation")
        require(self.safe <= triples, "Bad SYS relation")
        require(all(set(j) <= set(self.states) for j in self.assumptions + self.guarantees), "Bad justice")
        return self

    def pre(self, region):
        """forall legal next ENV, exists safe next SYS into region.

        A state with no legal ENV input is a vacuous strict winner. Every typed
        input remains available to local-totality checks, including ENV-illegal
        ones. All public/history fields must already occur in each state key.
        """
        region = set(region)
        return {s for s in self.states if all(
            (s, e) not in self.legal or any(
                (s, e, y) in self.safe and self.target[s, e, y] in region
                for y in self.outputs)
            for e in self.inputs)}

    def local_total(self):
        return {s for s in self.states if all(
            any((s, e, y) in self.safe for y in self.outputs)
            for e in self.inputs)}

    def restrict(self, allowed):
        allowed = set(allowed)
        return Game(self.states, self.inputs, self.outputs, self.target,
                    self.legal, frozenset(t for t in self.safe
                        if t[0] in allowed and self.target[t] in allowed),
                    self.assumptions, self.guarantees)


def fixed(seed, step, descending, carrier_size):
    current = set(seed)
    for iteration in range(carrier_size + 2):
        later = set(step(current))
        require(later <= current if descending else current <= later,
                "Nonmonotone fixed-point ladder")
        if later == current:
            return later, iteration + 1
        current = later
    raise ValueError("Finite lattice convergence bound exceeded")


def safety_win(game):
    return fixed(game.states, game.pre, True, len(game.states))[0]


def strict_win(game):
    """nu Z / conjunction guarantees / mu Y / union assumptions / nu X.

    The generalized-Buchi implication is solved with the strict predecessor;
    missing assumptions or guarantees mean the always-true justice. This is a
    new finite-set implementation of the mathematical definition, not a call
    to a saved BDD solver or a native synthesis tool.
    """
    universe = set(game.states)
    assumptions = list(game.assumptions) or [universe]
    guarantees = list(game.guarantees) or [universe]
    n = len(universe)

    def outer(z):
        per_goal = []
        for goal in guarantees:
            reached = set(goal) & game.pre(z)

            def middle(y):
                prior = reached | game.pre(y)
                alternatives = []
                for assumption in assumptions:
                    avoid = universe - set(assumption)
                    x, _ = fixed(universe,
                                 lambda x: prior | (avoid & game.pre(x)), True, n)
                    alternatives.append(x)
                return set().union(*alternatives)

            y, _ = fixed(set(), middle, False, n)
            per_goal.append(y)
        return set.intersection(*per_goal)

    return fixed(universe, outer, True, n)[0]


def generalized_helper(original, quadrants):
    """Return exact U/F/W_F and a separately assembled direct helper game.

    Each quadrant maps '00','01','10','11' to (legal_pairs, safe_triples).
    Full original-domain identity at 00 and impossible ENV10 are mandatory.
    Original justices are lifted unchanged; ENV gains GF helper=false.
    """
    require(set(quadrants) == {"00", "01", "10", "11"}, "Four helper quadrants")
    require(quadrants["00"] == (original.legal, original.safe), "Changed original 00")
    require(not quadrants["10"][0], "ENV helper must be one-way")

    def quadrant(name):
        legal, safe = quadrants[name]
        return Game(original.states, original.inputs, original.outputs,
                    original.target, frozenset(legal), frozenset(safe)).validate()

    trap, flip = quadrant("11"), quadrant("01")
    u = safety_win(trap)
    f = flip.pre(u)
    wf = f & strict_win(original.restrict(f))  # outer F is necessary
    hstates = tuple((s, h) for s in original.states for h in (False, True))
    hinputs = tuple((e, hp) for e in original.inputs for hp in (False, True))
    target, legal, safe = {}, set(), set()
    for s, h in hstates:
        for e, hp in hinputs:
            key = str(int(h)) + str(int(hp))
            er, sr = quadrants[key]
            if (s, e) in er:
                legal.add(((s, h), (e, hp)))
            for y in original.outputs:
                triple = ((s, h), (e, hp), y)
                target[triple] = (original.target[s, e, y], hp)
                if (s, e, y) in sr:
                    safe.add(triple)
    lift = lambda region: frozenset((s, h) for s in region for h in (False, True))
    game = Game(hstates, hinputs, original.outputs, target,
                frozenset(legal), frozenset(safe),
                tuple(lift(a) for a in original.assumptions) +
                (frozenset((s, False) for s in original.states),),
                tuple(lift(g) for g in original.guarantees)).validate()
    direct = strict_win(game)
    return {"U": u, "F": f, "W_F": wf,
            "immediate_flip_response": flip.pre(original.states),
            "direct_helper_false": {s for s in original.states if (s, False) in direct},
            "direct_helper_true": {s for s in original.states if (s, True) in direct}}, game


def reachable(adjacency, starts):
    seen, todo = set(starts), list(starts)
    while todo:
        state = todo.pop()
        for target in adjacency.get(state, ()):
            if target not in seen:
                seen.add(target)
                todo.append(target)
    return seen


def components(adjacency, allowed):
    """Kosaraju SCCs on a small explicit directed graph."""
    allowed = set(allowed)
    seen, order = set(), []

    def visit(state):
        seen.add(state)
        for target in adjacency.get(state, ()):
            if target in allowed and target not in seen:
                visit(target)
        order.append(state)

    for state in sorted(allowed, key=repr):
        if state not in seen:
            visit(state)
    reverse = {s: set() for s in allowed}
    for state in allowed:
        for target in adjacency.get(state, ()):
            if target in allowed:
                reverse[target].add(state)
    result, seen = [], set()
    for state in reversed(order):
        if state in seen:
            continue
        group, todo = set(), [state]
        while todo:
            node = todo.pop()
            if node in seen:
                continue
            seen.add(node)
            group.add(node)
            todo.extend(reverse[node] - seen)
        result.append(group)
    return result


def cyclic(group, adjacency):
    return len(group) > 1 or any(s in adjacency.get(s, ()) for s in group)


def policy_certificate(game, policy, starts):
    """Check a supplied deterministic policy on every reachable legal input.

    `policy[(state,input)]` is a stored output choice, never a synthesized
    substitute. Cooperation means each finite legal prefix has an infinite
    continuation satisfying every original ENV and SYS justice.
    """
    starts = set(starts)
    require(starts <= set(game.states), "Policy root outside carrier")
    adjacency = {s: set() for s in game.states}
    defects = []
    for state in game.states:
        for inp in game.inputs:
            if (state, inp) not in game.legal:
                continue
            choice = policy.get((state, inp))
            if choice not in game.outputs or (state, inp, choice) not in game.safe:
                defects.append((state, inp, choice))
            else:
                adjacency[state].add(game.target[state, inp, choice])
    nodes = reachable(adjacency, starts)
    bad = [row for row in defects if row[0] in nodes]
    liveness_bad = []
    for index, goal in enumerate(game.guarantees):
        for group in components(adjacency, nodes - set(goal)):
            if cyclic(group, adjacency) and all(group & set(a) for a in game.assumptions):
                liveness_bad.append({"goal": index, "component": sorted(group, key=repr)})
    fair_groups = [g for g in components(adjacency, nodes)
                   if cyclic(g, adjacency) and all(g & set(j)
                       for j in game.assumptions + game.guarantees)]
    fair = set().union(*fair_groups) if fair_groups else set()
    reverse = {s: set() for s in nodes}
    for state in nodes:
        for target in adjacency[state]:
            reverse[target].add(state)
    can_continue = reachable(reverse, fair)
    return {"strict": not bad and not liveness_bad,
            "cooperative": not bad and nodes <= can_continue,
            "coverage_and_safety": not bad,
            "reachable": sorted(nodes, key=repr),
            "edges": sum(len(adjacency[s]) for s in nodes),
            "edge_count_definition": "Distinct current/next state pairs; legal input responses counted separately",
            "legal_input_response_count": sum((s, e) in game.legal for s in nodes for e in game.inputs),
            "unsafe_or_missing_responses": bad,
            "strict_liveness_countercomponents": liveness_bad,
            "no_fair_continuation": sorted(nodes - can_continue, key=repr)}
