"""Prespecified eight-arm saved-arena study. Root-owned execution only."""
import csv
import gzip
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import sys
import time
import types

sys.dont_write_bytecode = True
B = Path(__file__).resolve().parent
R = B.parents[2]
E = R / 'experiment/seams_research_reframing_20261017'
from source_model import FiniteArena, NAMES, DOMAINS, GROUPS, clauses, env_ok, next_aux, first_flip_ok, source_edge


def require(test, message):
    if not test:
        raise ValueError(message)


def pin(p):
    p = Path(p).resolve()
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(p, value):
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def verify_inputs():
    manifest = json.loads((B / 'EXECUTION_INPUTS.json').read_text())
    for ref in manifest['files']:
        require(pin(ref['path']) == ref, 'Frozen input changed: ' + ref['path'])
    return manifest


def module(name, p):
    spec = importlib.util.spec_from_file_location(name, p)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def load_kernels():
    evidence = types.ModuleType('evidence')
    evidence.S = E / 'kind_corpus_symbolic_independent'
    evidence.H = E / 'helper_quadrant_public'
    evidence.CHECK = E / 'released_kind_corpus_checker'
    evidence.require = require
    sys.modules['evidence'] = evidence
    dec = module('v58_decomposition', E / 'helper_decomposition_public/decomposition.py')
    mapping = module('v58_mapping044', E / 'released_transform_044_main/map_pair.py')
    return dec, mapping


def check_group_roster(groups, design):
    expected = {bit: tuple(row['parsed_trace_ids'])
                for bit, row in zip((1, 2, 4), design['fixed_groups'])}
    require([row['id'] for row in design['fixed_groups']] == ['O', 'H', 'M'], 'Fixed group names/order')
    require(groups == expected, 'Exact prespecified source-group membership')
    flat = list(itertools.chain.from_iterable(groups.values()))
    require(len(flat) == len(set(flat)) == 11 and set(flat) == set(range(6, 17)),
            'Each source trace belongs to exactly one group')
    for mask, row in enumerate(design['complete_parameter_roster']):
        require(row['arm'] == 'guard_' + format(mask, '03b'), 'Exact eight-arm order')
        ids = sorted(cid for bit, values in groups.items() if mask & bit for cid in values)
        require(ids == row['source_trace_ids_guarded'], 'Exact prespecified per-arm source traces')
    require(len(design['complete_parameter_roster']) == 8, 'Complete fixed arm roster')


def qualify_existing_propagation_control(dec):
    # The fixed delayed() example in preservation_loss_public/qualify.py:
    # one Boolean ENV state e, singleton SYS response, rhoE=e',
    # rhoS=not e or e'.  State e=0 passes C but its required successor
    # e=1 does not. This exercises the actual decomposition kernel.
    b = dec.BDD(4)
    e, ep, h, hp = (b.var(i) for i in range(4))
    oe, os = ep, b.disj(b.neg(e), ep)
    calc = dec.solve(b=b, q=1, de=1, den=1, dsn=1, current=(0,), en=(1,), sn=(), prime={0: 1},
                     oe=oe, os=os, oa=[], og=[], te=b.neg(e), ts=1,
                     je=b.conj(b.disj(oe, hp), b.disj(b.neg(h), hp)), js=b.disj(os, h),
                     ja=[b.neg(h)], jg=[], jte=b.conj(b.neg(e), b.neg(h)), jts=1, h=2, hp=3)
    expected = {'W_original': 1, 'C': b.neg(e), 'F': b.neg(e), 'U': 1,
                'W_F': 0, 'W_direct_0': 0, 'W_direct_1': 1, 'delayed_loss': b.neg(e)}
    require(all(calc['roots'][name] == root for name, root in expected.items()),
            'Fixed existing propagation control')
    require(calc['quant']['W_original']['value'] and not calc['quant']['W_predicted']['value'],
            'Propagation control exact quantified initializer')
    return {'status': 'PASS', 'fixture': pin(E/'preservation_loss_public/qualify.py'),
            'fixture_function': 'delayed', 'source_equations': 'rhoE=e_next; rhoS=not e or e_next',
            'original_states': 2, 'local_F_states': 1, 'exact_W_F_states': 0,
            'local_pass_rejected_by_successor_invariance': True,
            'actual_decomposition_kernel_exercised': True}


def ast_bdd(node, ctx, transfer, b):
    kind = node['kind']
    if kind == 'variable':
        ref = node['reference_name']
        return transfer(ctx.literal(node['name'], 'true', ref.endswith("'")))
    if kind == 'primitive':
        require(node['value'].lower() in ('true', 'false'), 'Boolean primitive')
        return int(node['value'].lower() == 'true')
    require(kind == 'operator', 'Unexpected AST node')
    op, args = node['operator'], node['children']
    if op == 'EQUALS':
        variable, primitive = args
        require(variable['kind'] == 'variable' and primitive['kind'] == 'primitive', 'Equality shape')
        return transfer(ctx.literal(variable['name'], primitive['value'], variable['reference_name'].endswith("'")))
    xs = [ast_bdd(x, ctx, transfer, b) for x in args]
    fn = {'NOT': b.neg, 'AND': b.conj, 'OR': b.disj, 'IMPLIES': b.implies, 'IFF': b.iff}.get(op)
    require(fn is not None, 'Unsupported AST operator ' + op)
    return fn(*xs)


def check_source_relation(pair, dec, mapping, finite):
    b, o = pair['common'], pair['original']
    transfer = mapping.transfer(o.b, b, {v: b.var(v) for v in range(o.b.n)})
    inv = o.model['source_inventory']['translated']
    source = {c['trace_id']: ast_bdd(c['spec_ast'], o, transfer, b)
              for c in inv['SYS']['constraints']}
    require(set(source) == set(range(6, 17)), 'All eleven source clauses')
    require(set(itertools.chain.from_iterable(GROUPS.values())) == set(source), 'Complete group partition')
    design = json.loads((B / 'STUDY_SPECIFICATION.json').read_text())['design']
    check_group_roster(GROUPS, design)
    wrong_group = {1: (10,), 2: (6, 8, 9), 4: GROUPS[4]}
    try:
        check_group_roster(wrong_group, design)
    except ValueError:
        wrong_group_rejected = True
    else:
        wrong_group_rejected = False
    aux = b.conj(*(ast_bdd(c['spec_ast'], o, transfer, b)
                   for c in inv['AUX']['constraints'] if c['kind'] == 'SAFETY'))
    original_system = b.conj(*source.values(), aux)
    original_environment = b.conj(*(ast_bdd(c['spec_ast'], o, transfer, b)
                                   for c in inv['ENV']['constraints'] if c['kind'] == 'SAFETY'))
    q, edge = transfer(o.domain), pair['typed_edge_mask']
    equal = lambda x, y, domain=edge: b.conj(domain, b.apply('xor', x, y)) == 0
    require(equal(original_system, pair['original_roots']['rhoS']), 'Full original SYS/source product')
    require(equal(original_environment, pair['original_roots']['rhoE']), 'Full original ENV/source product')
    h, hp = pair['helper_current_bit'], pair['helper_next_bit']
    quads = {str(i) + str(j): tuple(dec.cofactor(b, pair['job_roots'][key], h, hp, i, j)
                                   for key in ('rhoE', 'rhoS'))
             for i, j in itertools.product((0, 1), repeat=2)}
    expected = {'00': (original_environment, original_system),
                '01': (1, original_system), '10': (0, aux), '11': (1, aux)}
    # S10 is semantically irrelevant when E10=false, but it is still retained
    # byte-for-byte in every intervention and reported rather than assumed.
    quadrant_checks = {}
    for key, (ee, ss) in expected.items():
        e, s = quads[key]
        quadrant_checks[key] = {'ENV_equal': equal(e, ee), 'SYS_equal': equal(s, ss)}
        require(equal(e, ee), 'ENV quadrant factorization ' + key)
        if key != '10':
            require(equal(s, ss), 'SYS quadrant factorization ' + key)
    require(not o.justices['ENV'] and not o.justices['SYS'], 'Safety-only original game')
    require(tuple(o.by_name) == NAMES and all(tuple(o.by_name[n]['values']) == d
                for n, d in zip(NAMES, DOMAINS)), 'Independent full typed carrier')
    # Independent handwritten source predicates agree at every typed state.
    bitvals = [o.bits(dict(zip(NAMES, s))) for s in finite.states]
    for i, s in enumerate(finite.states):
        require(all(b.evaluate(root, bitvals[i]) == val for cid, val in clauses(s).items()
                    for root in [source[cid]]), 'Handwritten source clause mismatch')
        require(b.evaluate(original_environment, bitvals[i]) == env_ok(s), 'Handwritten ENV mismatch')
    # Both AUX updates and initialization are checked as complete functions.
    lit = lambda name, value, nxt=False: transfer(o.literal(name, value, nxt))
    manual_aux = b.conj(b.iff(lit('PREV_aux_0', 'true', True), lit('InputMoveMode', 'TURN_LEFT_2')),
                        b.iff(lit('PREV_aux_1', 'true', True), b.neg(lit('InputMoveMode', 'TURN_LEFT_2'))))
    require(equal(aux, manual_aux), 'Independent full history-update product')
    init = b.conj(lit('PREV_aux_0', 'false'), lit('PREV_aux_1', 'false'))
    require(equal(init, pair['original_roots']['thetaS'], q), 'Original initializer, both history bits')
    require(equal(1, pair['original_roots']['thetaE'], q), 'Original ENV initializer')
    # Nontrivial malformed controls: each changes a complete predicate.
    primed = b.rename(b.conj(*source.values()), o.prime)
    wrong_aux = b.rename(lit('InputMoveMode', 'TURN_LEFT_2'), o.prime)
    malformed = {
        'move_clause_6_from_O_to_H': wrong_group_rejected,
        'prime_current_source_clauses': not equal(original_system, b.conj(primed, aux)),
        'use_next_mode_for_history': not equal(aux, b.conj(b.iff(lit('PREV_aux_0', 'true', True), wrong_aux),
                                                              b.iff(lit('PREV_aux_1', 'true', True), b.neg(wrong_aux)))),
        'collapse_initial_history_pair': not equal(init, b.iff(lit('PREV_aux_0', 'true'), b.neg(lit('PREV_aux_1', 'true'))), q),
        'guard_00_source_clause_6': not equal(original_system, b.conj(*(v for k, v in source.items() if k != 6), aux))}
    require(all(malformed.values()), 'A malformed semantic control was not rejected')
    return source, aux, quads, bitvals, {'status': 'PASS', 'quadrants': quadrant_checks,
        'all_current_states_checked': len(finite.states), 'complete_relation_products_checked': True,
        'source_compiler_trust': 'Source clauses independently hand-coded; typed native AST and BDD exports shared with historical qualification.',
        'malformed_controls_rejected': malformed}


def vector(root, b, bits):
    return {i for i, bs in enumerate(bits) if b.evaluate(root, bs)}


def witness(ids, finite):
    return None if not ids else dict(zip(NAMES, finite.states[min(ids)]))


def main(out):
    inputs = verify_inputs()
    require(not out.exists(), 'Fresh output directory required')
    out.mkdir()
    start = time.monotonic()
    dec, mapping = load_kernels()
    small_control = qualify_existing_propagation_control(dec)
    save(out/'SMALL_PROPAGATION_CONTROL.json', small_control)
    original_dir = E / 'released_transform_044_main/runs/corpus044__original/original'
    job_dir = original_dir.parent / 'released'
    source_path = E / 'kind_corpus/original/artifact/experiments/specs/syn15/HumanoidLTL_460_Humanoid.spectra'
    profile = {'fixture_id': 'corpus044__original', 'case_id': 'corpus044', 'variant': 'original',
               'source': pin(source_path), 'bindings': {'study': pin(B / 'STUDY_SPECIFICATION.json')}}
    pair = mapping.build(original_dir, job_dir, 'corpus044__original', profile)
    finite = FiniteArena()
    source, aux, quads, bits, qualification = check_source_relation(pair, dec, mapping, finite)
    save(out / 'SOURCE_QUALIFICATION.json', qualification)
    print(json.dumps({'phase': 'SOURCE_QUALIFIED', 'states': len(bits)}), flush=True)
    b, args = pair['common'], dec.lifted_inputs(pair)
    h, hp = args['h'], args['hp']
    W, wlog = finite.greatest(finite.cpre)
    V, vlog = finite.greatest(lambda x: finite.alive & finite.cpre(x))
    require(not V, 'Fixed original V=empty scope control')
    reachable = finite.reachable()
    spec = json.loads((B / 'STUDY_SPECIFICATION.json').read_text())
    snapshots = {name: {k: ('true' if v else 'false') if type(v) is bool else v for k, v in val.items()}
                 for name, val in spec['design']['decision_roster']['fixed_snapshots'].items()}
    primary = {k: ('true' if v else 'false') if type(v) is bool else v
               for k, v in spec['design']['decision_roster']['primary_fixed_snapshot'].items()}
    require(primary == snapshots['r_one_source_transition'], 'Exact prespecified primary query identity')
    snapshot_ids = {name: finite.index[tuple(s[n] for n in NAMES)] for name, s in snapshots.items()}
    u, r = (tuple(snapshots[x][n] for n in NAMES) for x in ('u_original_initialized', 'r_one_source_transition'))
    require(finite.index[u] in finite.initial and source_edge(u, r), 'Prespecified initialized u-to-r legal source prefix')
    require(finite.index[r] not in finite.initial, 'Noninitial r history retained')
    require(finite.index[r] in W, 'Prespecified r original strict continuation')
    joined = {**pair['original'].bits(dict(zip(NAMES, u))), **pair['original'].bits(dict(zip(NAMES, r)), True)}
    require(b.evaluate(args['oe'], joined) and b.evaluate(args['os'], joined), 'Full BDD source prefix')
    arrays, results, all_roots = {}, [], {}
    for mask in range(8):
        guarded = {cid for group, ids in GROUPS.items() if group & mask for cid in ids}
        s01 = b.conj(aux, *(root for cid, root in source.items() if cid not in guarded))
        flip = b.conj(b.neg(b.var(h)), b.var(hp))
        js = b.ite(flip, s01, args['js'])
        for i, j in ((0, 0), (1, 0), (1, 1)):
            unchanged = dec.cofactor(b, js, h, hp, i, j)
            require(b.conj(pair['typed_edge_mask'], b.apply('xor', unchanged, quads[str(i)+str(j)][1])) == 0,
                    'Intervention changed non-01 quadrant')
        calc = dec.solve(**{**args, 'js': js})
        roots = calc['roots']
        observed = {name: vector(roots[name], b, bits) for name in ('W_original', 'U', 'F', 'W_F', 'C', 'W_direct_0', 'W_direct_1')}
        F = {i for i, s in enumerate(finite.states) if first_flip_ok(s, mask)}
        WF, log = finite.greatest(lambda x: F & finite.cpre(x), F)
        d0, d1, direct_log = finite.direct_helper(mask)
        expected = {'W_original': W, 'U': finite.all, 'F': F, 'W_F': WF, 'C': finite.good,
                    'W_direct_0': d0, 'W_direct_1': d1}
        require(all(observed[k] == x for k, x in expected.items()), 'Whole-function finite/BDD disagreement')
        require(WF == d0 and W == observed['W_original'], 'Direct/decomposed region disagreement')
        require(all(calc['checks'][x] for x in ('active_decomposition_equal', 'trap_decomposition_equal',
                    'subset_original', 'full_preservation_iff_W_subset_F', 'initial_quantification_equal')),
                'Strict region structural control')
        quantified = finite.quantify(WF)
        require(quantified['value'] == calc['quant']['W_predicted']['value'], 'Independent full initializer quantification')
        loss, delayed = W - WF, (W & F) - WF
        row = {'mask': mask, 'guarded_source_trace_ids': sorted(guarded), 'source_clause_cost': len(guarded),
               'counts': {k: len(v) for k, v in observed.items()}, 'original_initializer': finite.quantify(W),
               'transformed_initializer': quantified, 'local_initializer': finite.quantify(W & F),
               'whole_region_preserved': WF == W, 'W_subset_F': W <= F,
               'exact_loss': len(loss), 'propagated_loss': len(delayed), 'first_propagated_witness': witness(delayed, finite),
               'snapshot_queries': {name: {k: i in v for k, v in observed.items()} for name, i in snapshot_ids.items()},
               'BDD_checks': calc['checks'], 'finite_restricted_iterations': log, 'finite_direct_iterations': direct_log,
               'status': 'PASS_EXACT_FULL_FUNCTION_AGREEMENT'}
        arrays[mask] = observed
        all_roots.update({str(mask) + ':' + k: v for k, v in roots.items()})
        results.append(row)
        save(out / ('ARM_' + format(mask, '03b') + '.json'), row)
        print(json.dumps({'phase': 'ARM_COMPLETE', 'mask': mask, 'F': len(F), 'W_F': len(WF),
                          'initializer': quantified['value'], 'propagated_loss': len(delayed)}), flush=True)
    require(arrays[0]['W_F'] == set() and arrays[0]['F'] == finite.good, 'Historical empty-mask endpoint')
    require(arrays[7]['F'] == finite.all and arrays[7]['W_F'] == W, 'All-source-group endpoint')
    pairs = []
    for i, j in itertools.combinations(range(8), 2):
        a, c = arrays[i], arrays[j]
        difference = a['W_F'] ^ c['W_F']
        same_local_different_exact = W & a['F'] & c['F'] & difference
        difference_name = 'pair_' + str(i) + '_' + str(j) + ':W_F_xor'
        all_roots[difference_name] = b.apply('xor', all_roots[str(i)+':W_F'], all_roots[str(j)+':W_F'])
        require(a['F'] != c['F'] or a['W_F'] == c['W_F'], 'Equal complete F functions, unequal W_F')
        if i & j == i:
            require(a['F'] <= c['F'] and a['W_F'] <= c['W_F'], 'Guard-superset monotonicity')
        pairs.append({'masks': [i, j], 'F_equal_as_functions': a['F'] == c['F'],
                      'W_F_symmetric_difference': len(difference),
                      'symmetric_difference_function': difference_name,
                      'symmetric_difference_sha256': dec.digest(b, all_roots[difference_name]),
                      'first_symmetric_difference_witness': witness(difference, finite),
                      'same_local_true_different_exact': len(same_local_different_exact),
                      'first_witness': witness(same_local_different_exact, finite),
                      'same_initializer': results[i]['transformed_initializer']['value'] == results[j]['transformed_initializer']['value']})
    order = sorted(range(8), key=lambda m: (results[m]['source_clause_cost'], m))
    decisions = []
    for i, s in enumerate(finite.states):
        local = next((m for m in order if i in W and i in arrays[m]['F']), None)
        exact = next((m for m in order if i in arrays[m]['W_F']), None)
        decisions.append((local, exact))
    with gzip.open(out / 'ALL_STATES.csv.gz', 'wt', newline='') as f:
        w = csv.writer(f)
        w.writerow([*NAMES, 'W', 'C', 'initial', 'existentially_reachable', 'local_selected_mask', 'exact_selected_mask',
                    *[str(m) + ':' + k for m in range(8) for k in ('F', 'W_F')]])
        for i, s in enumerate(finite.states):
            w.writerow([*s, int(i in W), int(i in finite.good), int(i in finite.initial), int(i in reachable),
                        *decisions[i], *[int(i in arrays[m][k]) for m in range(8) for k in ('F', 'W_F')]])
    with gzip.open(out / 'FUNCTIONS.json.gz', 'wt') as f:
        json.dump({'variable_count': b.n, 'nodes': b.nodes, 'roots': all_roots}, f, separators=(',', ':'))
    summary = {'status': 'PASS_COMPLETE_PRESPECIFIED_EIGHT_ARM_CENSUS', 'study': pin(B / 'STUDY_SPECIFICATION.json'),
               'small_propagation_control': pin(out/'SMALL_PROPAGATION_CONTROL.json'),
               'frozen_execution_inputs': pin(B / 'EXECUTION_INPUTS.json'), 'source_qualification': pin(out / 'SOURCE_QUALIFICATION.json'),
               'source': profile['source'], 'states': len(finite.states), 'original_W': len(W), 'original_V': len(V),
               'original_K': 0, 'cooperative_admission': False, 'scope': spec['purpose'], 'source_00_unchanged': True,
               'fixed_source_prefix': {'u': snapshots['u_original_initialized'], 'r': snapshots['r_one_source_transition'],
                                       'legal': True, 'r_noninitial': True, 'r_in_original_W': True},
               'arms': results, 'pairs': pairs, 'pair_count': len(pairs), 'all_outcomes_retained': True,
               'decision_differences': sum(a != c for a, c in decisions),
               'fixed_snapshot_decisions': {name: {'local_mask': decisions[i][0], 'exact_mask': decisions[i][1],
                                                  'cooperative_admission': False} for name, i in snapshot_ids.items()},
               'finite_original_iterations': wlog, 'finite_viability_iterations': vlog,
               'stronger_initializer_gap_observed': any(row['transformed_initializer']['value'] and row['propagated_loss'] for row in results),
               'limitations': spec['scope_limits'], 'seconds': time.monotonic() - start,
               'artifacts': [pin(out / name) for name in ('ALL_STATES.csv.gz', 'FUNCTIONS.json.gz')],
               'shared_dependencies': 'Typed native model exports and shared BDD kernel in symbolic routes; finite source evaluator and finite safety iteration separately implemented.',
               'native_runs': 0, 'source_contract_changes': 0, 'full_reset_uses': 0}
    verify_inputs()
    save(out / 'RESULT.json', summary)
    print(json.dumps({'status': summary['status'], 'seconds': summary['seconds'],
                      'decisions': summary['fixed_snapshot_decisions']}), flush=True)


if __name__ == '__main__':
    require(len(sys.argv) == 2, 'Usage: census.py FRESH_OUTPUT_DIRECTORY')
    output = Path(sys.argv[1]).resolve()
    try:
        main(output)
    except Exception as exc:
        if output.is_dir():
            save(output / 'FAILURE.json', {'status': 'UNKNOWN_EXECUTION_OR_QUALIFICATION_FAILURE',
                                         'type': type(exc).__name__, 'error': str(exc)})
        raise
