"""Finite source semantics for the fixed Humanoid044 study; no BDD dependency.

All guarantees are CURRENT-state predicates in the pinned translator.
The two PREV variables are distinct, including initialized (false,false).
"""
from itertools import product

NAMES = ('Obstacle', 'InputMoveMode', 'LeftMotor', 'RightMotor',
         'HeadMotor', 'OutputMoveMode', 'PREV_aux_0', 'PREV_aux_1')
DOMAINS = (
    ('BLOCKED', 'CLEAR'), ('BWD', 'FWD', 'TURN_LEFT_1', 'TURN_LEFT_2'),
    ('BWD', 'CALIB_FWD', 'CALIB_TURN', 'FWD', 'STOP', 'TURN_BWD', 'TURN_FWD'),
    ('BWD', 'CALIB_FWD', 'CALIB_TURN', 'FWD', 'STOP', 'TURN_BWD', 'TURN_FWD'),
    ('BWD', 'FWD', 'STOP'), ('BWD', 'FWD', 'TURN_LEFT_1', 'TURN_LEFT_2'),
    ('false', 'true'), ('false', 'true'))
GROUPS = {1: (6, 10), 2: (8, 9), 4: (7, 11, 12, 13, 14, 15, 16)}


def clauses(s):
    obstacle, mode, left, right, head, output, prev0, prev1 = s
    blocked = obstacle == 'BLOCKED'
    forward, backward = mode == 'FWD', mode == 'BWD'
    turn1, turn2 = mode == 'TURN_LEFT_1', mode == 'TURN_LEFT_2'
    implies = lambda a, b: not a or b
    return {
        6: implies(forward and blocked,
                   output == 'TURN_LEFT_1' and left == right == 'CALIB_TURN'),
        7: implies(backward and not blocked,
                   output == 'FWD' and left == 'FWD' and right == 'BWD'),
        8: implies(forward and prev0 == 'true', left == right == 'CALIB_FWD'),
        9: implies(forward and not blocked and prev1 == 'true', left == right == 'FWD'),
        10: implies(blocked, output != 'FWD'),
        11: turn1 == (output == 'TURN_LEFT_2'),
        12: implies(turn1, left == 'FWD' and right == 'TURN_FWD'),
        13: implies(turn2, left == 'BWD' and right == 'TURN_BWD'),
        14: implies(not (turn1 or turn2),
                    not (left == 'TURN_BWD' or right == 'TURN_BWD'
                         or (left == 'TURN_FWD' and right == 'TURN_FWD'))),
        15: implies(turn1 or turn2, head == 'STOP'),
        16: implies(turn2 and not blocked, output == 'FWD')}


def env_ok(s):
    return not (s[1] == 'FWD' and s[6] == 'true') or s[0] == 'CLEAR'


def next_aux(s):
    return ('true', 'false') if s[1] == 'TURN_LEFT_2' else ('false', 'true')


def initial(s):
    return s[6:] == ('false', 'false')


def first_flip_ok(s, mask):
    cs = clauses(s)
    return all(cs[c] for group, ids in GROUPS.items() if not mask & group for c in ids)


def source_edge(s, t):
    return env_ok(s) and all(clauses(s).values()) and t[6:] == next_aux(s)


class FiniteArena:
    """Exact successor buckets, retaining all 18,816 states and typed outputs.

    Every next output is unconstrained except for its declared type and the
    two deterministic history updates. Current-state source clauses remain
    an edge obligation. Thus a bucket is the full successor response set,
    not a state-space projection or sampled successor relation.
    """
    def __init__(self):
        self.states = list(product(*DOMAINS))
        self.index = {s: i for i, s in enumerate(self.states)}
        self.all = set(range(len(self.states)))
        self.envs = list(product(*DOMAINS[:2]))
        self.buckets = {}
        for i, s in enumerate(self.states):
            self.buckets.setdefault((s[:2], s[6:]), set()).add(i)
        self.good = {i for i, s in enumerate(self.states) if all(clauses(s).values())}
        self.alive = {i for i, s in enumerate(self.states) if env_ok(s)}
        self.initial = {i for i, s in enumerate(self.states) if initial(s)}

    def available(self, region):
        return {key: bool(indices & region) for key, indices in self.buckets.items()}

    def all_responses(self, region):
        available = self.available(region)
        return {i for i, s in enumerate(self.states)
                if all(available[e, next_aux(s)] for e in self.envs)}

    def cpre(self, region):
        return (self.all - self.alive) | (self.good & self.all_responses(region))

    def greatest(self, step, seed=None):
        current = set(self.all if seed is None else seed)
        rounds = []
        while True:
            new = step(current)
            assert new <= current, 'Non-descending finite safety iteration'
            rounds.append(len(new))
            if new == current:
                return new, rounds
            current = new

    def direct_helper(self, mask):
        """Direct two-slice safety game; no W_F region is used here.

        Original guarantees have no justice, hence strict liveness is true
        regardless of the added ENV justice. Safety is the whole objective.
        """
        zero, one = set(self.all), set(self.all)
        flip_safe = {i for i, s in enumerate(self.states) if first_flip_ok(s, mask)}
        rounds = []
        while True:
            next_one = self.all_responses(one)
            next_zero = self.cpre(zero) & flip_safe & next_one
            assert next_zero <= zero and next_one <= one
            rounds.append([len(next_zero), len(next_one)])
            if (next_zero, next_one) == (zero, one):
                return zero, one, rounds
            zero, one = next_zero, next_one

    def quantify(self, region):
        choices = []
        for e in self.envs:
            ids = sorted(i for i in region & self.initial if self.states[i][:2] == e)
            choices.append({'env': dict(zip(NAMES[:2], e)), 'exists': bool(ids),
                            'first_witness': dict(zip(NAMES, self.states[ids[0]])) if ids else None})
        return {'value': all(x['exists'] for x in choices), 'environment_choices': choices,
                'missing_environment_count': sum(not x['exists'] for x in choices)}

    def reachable(self):
        reached, frontier = set(self.initial), set(self.initial)
        while frontier:
            nxt = set()
            for i in frontier & self.alive & self.good:
                aux = next_aux(self.states[i])
                for e in self.envs:
                    nxt.update(self.buckets[e, aux])
            frontier = nxt - reached
            reached.update(frontier)
        return reached
