"""Independent typed symbolic fixed points; no native solver/library imports.

The canonical ROBDD implementation is separately vendored. All fixed points
below use Boolean-function equality, not producer ranks or native iterations.
"""
from functools import lru_cache
from hashlib import sha256
import sys
sys.dont_write_bytecode = True
from vendor.bdd_core import BDD, Invalid, ResourceRefusal, require


def count(b, root, variables):
    variables = tuple(sorted(variables))
    index = {v: i for i, v in enumerate(variables)}
    require(b.support(root) <= set(variables), 'count support')
    @lru_cache(None)
    def visit(u, pos):
        if u < 2:
            return u << (len(variables) - pos)
        v, lo, hi = b.nodes[u]
        k = index[v]
        return (visit(lo, k + 1) + visit(hi, k + 1)) << (k - pos)
    return visit(root, 0)


def root_digest(b, root):
    @lru_cache(None)
    def visit(u):
        if u < 2:
            return sha256(str(u).encode()).hexdigest()
        v, lo, hi = b.nodes[u]
        return sha256(f'{v}:{visit(lo)}:{visit(hi)}'.encode()).hexdigest()
    return visit(root)


class Operations:
    """Round predecessor: forall legal E' exists S'; domains are explicit."""
    def __init__(self, b, q, rhoe, rhos, den, dsn, current, env_next,
                 sys_next, prime):
        self.b, self.q = b, q
        self.current, self.en, self.sn = tuple(current), tuple(env_next), tuple(sys_next)
        self.next = self.en + self.sn
        self.prime, self.unprime = dict(prime), {v: k for k, v in prime.items()}
        self.allowed = b.conj(rhoe, den)
        self.response = b.conj(rhos, dsn)
        self.joint = b.conj(self.allowed, self.response)
        require(b.support(self.allowed) <= set(current) | set(env_next),
                'ENV relation has next SYS dependencies')
        self.alive = b.conj(q, b.exists(self.allowed, self.en))
        self.rename = lru_cache(maxsize=50000)(lambda x: b.rename(x, self.prime))
        self.cpre = lru_cache(maxsize=50000)(self._cpre)
        self.epre = lru_cache(maxsize=50000)(self._epre)
        self.post = lru_cache(maxsize=50000)(self._post)

    def _cpre(self, x):
        b = self.b
        response_exists = b.exists(b.conj(self.response, self.rename(x)), self.sn)
        bad_input = b.exists(b.conj(self.allowed, b.neg(response_exists)), self.en)
        return b.conj(self.q, b.neg(bad_input))

    def _epre(self, x):
        b = self.b
        return b.conj(self.q, b.exists(b.conj(self.joint, self.rename(x)), self.next))

    def condpre(self, u, reserve):
        return self.b.conj(self.epre(u), self.cpre(self.b.disj(u, reserve)))

    def _post(self, x):
        b = self.b
        return b.conj(self.q, b.rename(b.exists(b.conj(x, self.joint), self.current), self.unprime))


def fixed(b, seed, step, descending, label, log):
    x, steps = seed, 0
    entry = log.setdefault(label, {'calls': 0, 'steps': 0, 'max_steps': 0})
    entry['calls'] += 1
    while True:
        y = step(x)
        require(b.conj(y, b.neg(x)) == 0 if descending else b.conj(x, b.neg(y)) == 0,
                label + ' monotonic ladder')
        steps += 1
        entry['steps'] += 1
        entry['max_steps'] = max(entry['max_steps'], steps)
        if x == y:
            return y
        x = y


def gr1_three(b, q, assumptions, guarantees, pre, log):
    aa = [b.conj(q, x) for x in assumptions] or [q]
    gg = [b.conj(q, x) for x in guarantees] or [q]
    def outer(z):
        targets = []
        for g in gg:
            goal = b.conj(g, pre(z))
            def ystep(y):
                base = b.disj(goal, pre(y))
                branches = []
                for a in aa:
                    na = b.conj(q, b.neg(a))
                    branches.append(fixed(b, q,
                        lambda x: b.disj(base, b.conj(na, pre(x))),
                        True, 'X', log))
                return b.disj(*branches)
            targets.append(fixed(b, 0, ystep, False, 'Y', log))
        return b.conj(*targets)
    return fixed(b, q, outer, True, 'Z', log)


def kind_four(b, q, assumptions, guarantees, ops, log):
    """Eq.15 vector nu Z, mu Y, union_a nu X, mu U on typed rounds.

    Callers explicitly normalize guarantees by adding the effective original
    assumptions, and restrict q/responses to independently calculated V.
    """
    if q == 0:
        return 0
    aa = [b.conj(q, x) for x in assumptions] or [q]
    gg = [b.conj(q, x) for x in guarantees] or [q]
    require(all(a in gg for a in aa), 'Kind normalization premise A included in G')
    z = [q] * len(gg)
    log['Z_vector_iterations'] = 0
    while True:
        new = []
        for j, g in enumerate(gg):
            goal = b.conj(g, ops.cpre(z[(j + 1) % len(gg)]))
            def ystep(y):
                base = b.disj(goal, ops.cpre(y))
                branches = []
                for a in aa:
                    na = b.conj(q, b.neg(a))
                    def xstep(x):
                        reserve = b.conj(x, na)
                        return fixed(b, 0,
                            lambda u: b.disj(base, b.conj(na, ops.condpre(u, reserve))),
                            False, 'U', log)
                    branches.append(fixed(b, q, xstep, True, 'X', log))
                return b.disj(*branches)
            new.append(fixed(b, 0, ystep, False, 'Y', log))
        require(all(b.conj(n, b.neg(o)) == 0 for n, o in zip(new, z)),
                'Kind vector greatest fixed point monotonicity')
        log['Z_vector_iterations'] += 1
        if new == z:
            return b.disj(*new)
        z = new


def initial_quantification(b, domain_env, thetae, thetas, region, sys_current):
    witness = b.conj(thetas, region)
    missing = b.conj(domain_env, thetae, b.neg(b.exists(witness, sys_current)))
    return {'value': missing == 0, 'system_witness': witness, 'missing_environment_initials': missing}


def calculate(b, q, domain_env, rhoe, rhos, den, dsn, current, env_next,
              sys_next, prime, assumptions, guarantees, thetae, thetas,
              ws_thetae, ws_thetas, ws_rhoe, ws_rhos):
    args = (den, dsn, current, env_next, sys_next, prime)
    original = Operations(b, q, rhoe, rhos, *args)
    logs = {k: {} for k in ('W', 'V', 'WV', 'K', 'WS', 'REACH', 'WS_REACH')}
    a = [b.conj(q, x) for x in assumptions] or [q]
    g = [b.conj(q, x) for x in guarantees] or [q]
    w = gr1_three(b, q, a, g, original.cpre, logs['W'])
    v = fixed(b, q, lambda x: b.conj(original.alive, original.cpre(x)), True, 'V', logs['V'])
    restricted = Operations(b, v, rhoe, rhos, *args)
    av, gv = [b.conj(v, x) for x in a], [b.conj(v, x) for x in g]
    wv = gr1_three(b, v, av, gv, restricted.cpre, logs['WV']) if v else 0
    k = kind_four(b, v, av, gv + av, restricted, logs['K']) if v else 0
    require(b.conj(k, b.neg(wv)) == 0, 'Independently derived K outside WV')
    ws = Operations(b, q, ws_rhoe, ws_rhos, *args)
    nws = gr1_three(b, q, a, [0], ws.cpre, logs['WS'])
    initial = b.conj(q, thetae, thetas)
    ws_initial = b.conj(q, ws_thetae, ws_thetas)
    reach = fixed(b, initial, lambda x: b.disj(x, original.post(x)), False, 'reach', logs['REACH'])
    wsreach = fixed(b, ws_initial, lambda x: b.disj(x, ws.post(x)), False, 'reach', logs['WS_REACH'])
    precise = b.conj(wv, b.neg(k))
    delta = b.conj(w, v, b.neg(k))
    regions = {'original_initialized': initial, 'alive': original.alive,
        'W': w, 'V': v, 'WV': wv, 'K': k, 'WV_minus_K': precise,
        'K_minus_WV': b.conj(k, b.neg(wv)), 'W_intersect_V_minus_K': delta,
        'reachable': reach, 'reachable_delta': b.conj(reach, delta),
        'reachable_WV_minus_K': b.conj(reach, precise),
        'reachable_WV': b.conj(reach, wv), 'reachable_K': b.conj(reach, k),
        'WS_NWS_region': nws, 'WS_definition_reach': wsreach,
        'WS_definition_reachable_NWS': b.conj(wsreach, nws),
        'WS_original_reachable_NWS': b.conj(reach, nws),
        'WS_original_reachable_NWS_and_K': b.conj(reach, nws, k)}
    sys_current = [x for x in current if prime[x] in set(sys_next)]
    quant = {name: initial_quantification(b, domain_env, thetae, thetas, regions[name], sys_current)
             for name in ('W', 'V', 'WV', 'K')}
    quant['WS'] = initial_quantification(b, domain_env, ws_thetae, ws_thetas, nws, sys_current)
    return regions, quant, logs
