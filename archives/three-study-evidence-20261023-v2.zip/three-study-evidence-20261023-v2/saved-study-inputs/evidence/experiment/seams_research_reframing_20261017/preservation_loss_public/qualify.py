"""Synthetic finite-set oracle and literal-helper theorem qualification only."""
from pathlib import Path
from types import SimpleNamespace
from itertools import product
import copy,gzip,importlib.util,json,random,signal,sys,tempfile
from unittest.mock import patch
sys.dont_write_bytecode=True
from evidence import B,S,read,save,pin,require,now
from loss import BDD,compute,summarize,load_independent,count,root_digest
spec=importlib.util.spec_from_file_location('loss_finite_oracle',S/'vendor/finite_sets_v1.py')
finite=importlib.util.module_from_spec(spec);spec.loader.exec_module(finite)
tests=[];fixture_count=0;exhaustive_count=0


def test(name,fn):
    try:fn();tests.append({'name':name,'pass':True})
    except Exception as ex:tests.append({'name':name,'pass':False,'error':repr(ex)})


def rejects(fn):
    try:fn()
    except (ValueError,KeyError,TypeError):return
    raise AssertionError('Expected rejection')


def fixture(ne,ns,erel,srel,assumptions=(),guarantees=(),env_init=None,sys_init=None,sys_aux=False):
    global fixture_count
    require(ne>0 and ns>0,'Qualification typed carriers are nonempty')
    vals=list(product(range(ne),range(ns)));Q=set(range(len(vals)))
    eb,sb=(ne-1).bit_length(),(ns-1).bit_length()
    ec=[2*i for i in range(eb)];en=[x+1 for x in ec]
    sc=[2*(eb+i) for i in range(sb)];sn=[x+1 for x in sc]
    current=ec+sc;prime=dict(zip(current,en+sn));b=BDD(2*(eb+sb))
    bits=lambda value,vs:{v:bool(value>>i&1) for i,v in enumerate(vs)}
    domain=lambda n,vs:b.disj(*(b.cube(bits(i,vs)) for i in range(n)))
    de,ds,den,dsn=domain(ne,ec),domain(ns,sc),domain(ne,en),domain(ns,sn)
    q=b.conj(de,ds);cubes={i:b.cube(bits(e,ec)|bits(y,sc)) for i,(e,y) in enumerate(vals)}
    region=lambda states:b.disj(*(cubes[i] for i in states))
    rhoe=b.disj(*(b.conj(cubes[i],b.cube(bits(e,en))) for i,e in erel))
    rhos=b.disj(*(b.conj(cubes[i],b.cube(bits(e,en)|bits(y,sn))) for i,e,y in srel))
    inputs={i:{e for j,e in erel if j==i} for i in Q}
    replies={(i,e):{j for j,(je,jy) in enumerate(vals) if je==e and (i,e,jy) in srel} for i in Q for e in range(ne)}
    pre=lambda states:{i for i in Q if all(replies[i,e]&states for e in inputs[i])}
    aa,gg=[set(x) for x in assumptions] or [Q.copy()],[set(x) for x in guarantees] or [Q.copy()]
    W=finite.gr1_three(Q,aa,gg,pre,[])
    C={i for i in Q if all(any((i,e,y) in srel for y in range(ns)) for e in range(ne))}
    restricted_pre=lambda states:{i for i in Q if all((replies[i,e]&states&C) if i in C else set() for e in inputs[i])}
    raw_wc=finite.gr1_three(Q,aa,gg,restricted_pre,[]);WC=C&raw_wc
    ei=set(range(ne)) if env_init is None else set(env_init)
    si=Q.copy() if sys_init is None else set(sys_init)
    initial={i for i,(e,_) in enumerate(vals) if e in ei and i in si}
    reachable=finite.fixed(initial,lambda x:x|{j for i in x for e in inputs[i] for j in replies[i,e]},False,'reach',[])
    thetae=b.disj(*(b.cube(bits(e,ec)) for e in ei));thetas=region(si)
    roots,quant,log=compute(b,q,de,rhoe,rhos,den,dsn,current,en,sn,prime,
        [region(x) for x in assumptions],[region(x) for x in guarantees],thetae,thetas,region(W),region(reachable))
    expected={'C':C,'W':W,'W_C':WC,'W_minus_C':W-C,'W_minus_W_C':W-WC,
        'delayed_loss':(W-WC)&C,'original_reachable':reachable,'original_reachable_loss':reachable&(W-WC),'original_initialized':initial}
    require(all(roots[k]==region(v) for k,v in expected.items()),'Finite original/C-restricted region mismatch')
    for name,R in (('W',W),('W_C',WC)):
        missing={e for e in ei if not any(i in si&R and vals[i][0]==e for i in Q)}
        require(quant[name]['value']==(not missing),'Original forall ENV exists SYS initializer')
        require(count(b,quant[name]['missing_environment_initials'],ec)==len(missing),'Missing initial ENV count')
        require(count(b,quant[name]['system_witness'],current)==len(si&R),'Initial SYS witness count')

    # Independently construct the complete literal-helper arena in finite sets.
    # Its active winning region must equal C intersect the guarded original game.
    H=set(range(2*len(vals)));active=Q.copy()
    hin={};hrep={}
    for h in H:
        i=h%len(vals);helper=h//len(vals);hin[h]=set()
        for e,bnext in product(range(ne),(0,1)):
            if not ((e in inputs[i] or bnext==1) and (helper==0 or bnext==1)):continue
            choice=(e,bnext);hin[h].add(choice)
            hrep[h,choice]={j+bnext*len(vals) for j,(je,jy) in enumerate(vals)
                if je==e and (helper==1 or (i,e,jy) in srel)}
    hpre=lambda states:{h for h in H if all(hrep[h,e]&states for e in hin[h])}
    lift=lambda states:{i+helper*len(vals) for i in states for helper in (0,1)}
    hw=finite.gr1_three(H,[lift(a) for a in aa]+[active],[lift(g) for g in gg],hpre,[])
    require(hw&active==WC and H-active<=hw,'Literal helper / W_C exact theorem')

    def field(name,owner,role,n,cb,nb):
        return {'name':name,'owner':owner,'role':role,'values':[str(x) for x in range(n)],'domain_size':n,
            'current_bits':cb,'next_bits':nb,'encoding':{str(x):{'current':{str(k):v for k,v in bits(x,cb).items()},
            'next':{str(k):v for k,v in bits(x,nb).items()}} for x in range(n)}}
    model=SimpleNamespace(b=b,q=q,de=de,ds=ds,den=den,dsn=dsn,current=current,ec=ec,sc=sc,en=en,sn=sn,prime=prime,
        forms={'thetaE':thetae,'thetaS':thetas,'rhoE':rhoe,'rhoS':rhos},
        fields=[field('e','ENV','ENV',ne,ec,en),field('aux' if sys_aux else 'y','SYS','AUX' if sys_aux else 'SYS',ns,sc,sn)])
    out=summarize(model,roots,quant)
    require(all(out['counts'][k]==len(v) for k,v in expected.items()),'Summary exact cardinalities')
    for name,witness in out['state_witnesses'].items():
        require((witness is None)==(not expected[name]),'Witness existence')
        if witness is not None:require(set(witness['state'])=={'e','aux' if sys_aux else 'y'},'Complete typed witness including AUX')
    fixture_count+=1
    return expected,raw_wc,out,model,roots


def exhaustive(ne,ns):
    global exhaustive_count
    Q=set(range(ne*ns));es=list(product(sorted(Q),range(ne)));ss=list(product(sorted(Q),range(ne),range(ns)))
    justice=[{i for i in Q if mask>>i&1} for mask in range(1<<len(Q))]
    for emask in range(1<<len(es)):
        er={edge for i,edge in enumerate(es) if emask>>i&1}
        for smask in range(1<<len(ss)):
            sr={edge for i,edge in enumerate(ss) if smask>>i&1}
            for a,g in product(justice,repeat=2):
                fixture(ne,ns,er,sr,[a],[g]);exhaustive_count+=1


def guard():
    Q=set(range(2));er={(i,1) for i in Q};sr={(i,1,0) for i in Q}
    got,_,out,_,_=fixture(2,1,er,sr)
    require(got['W']==Q and got['C']==got['W_C']==set() and out['initial_verdict_changed'],'Guard immediate and initial loss')


def delayed():
    Q=set(range(2));er={(i,1) for i in Q};sr={(0,0,0),(0,1,0),(1,1,0)}
    got,_,_,_,_=fixture(2,1,er,sr,env_init={0})
    require(got['W']==Q and got['C']=={0} and got['W_minus_C']=={1} and got['delayed_loss']=={0} and got['W_C']==set(),'Exact loss exceeds immediate totality failure')


def env_dead():
    Q=set(range(4));sr=set()
    got,raw,out,_,_=fixture(2,2,set(),sr)
    require(got['W']==raw==Q and got['C']==got['W_C']==set(),'Outer C removes env-dead vacuity')
    require(out['initial_verdict_changed'],'Vacuous original initializer differs from guarded helper active region')


def additional():
    rng=random.Random(20261017);Q=set(range(4));es=list(product(sorted(Q),range(2)));ss=list(product(sorted(Q),range(2),range(2)))
    for index in range(96):
        er={e for e in es if rng.random()<0.75};sr={e for e in ss if rng.random()<0.62}
        aa=[{i for i in Q if rng.random()<0.5} for _ in range(index%3)]
        gg=[{i for i in Q if rng.random()<0.5} for _ in range((index//3)%3)]
        fixture(2,2,er,sr,aa,gg,env_init=({0} if index%4==0 else None),sys_init=({0,2} if index%5==0 else None),sys_aux=index%2==0)
    Q6=set(range(6));er={(i,e) for i in Q6 for e in range(3)};sr={(i,e,y) for i in Q6 for e in range(3) for y in range(2)}
    fixture(3,2,er,sr,[{0,2,4}],[{1,3,5}],sys_aux=True)
    fixture(1,1,{(0,0)},{(0,0,0)})
    Q=set(range(4));er={(i,e) for i in Q for e in range(2)};sr={(i,e,y) for i in Q for e in range(2) for y in range(2)}
    _,_,out,_,_=fixture(2,2,er,sr,env_init=set())
    require(out['initial_quantification']['W']['value'] and not out['initial_ENV_nonempty'],'Empty ENV initializer distinct vacuity')
    fixture(2,2,er,sr,sys_init=set())


def importer():
    _,_,_,model,roots=fixture(2,1,{(i,1) for i in range(2)},{(i,1,0) for i in range(2)})
    names={'W':roots['W'],'reachable':roots['original_reachable']};b=model.b
    payload={'schema':'independent-canonical-robdd-region-set-v1','variable_count':b.n,
        'canonical_variable_order':list(range(b.n)),'fields':model.fields,'roots':names,
        'nodes':[[i,*row] for i,row in enumerate(b.nodes) if i>1]}
    proof={'counts':{k:count(b,v,model.current) for k,v in names.items()},
        'comparisons':{k:{'equal':True,'independent_count':count(b,v,model.current),'canonical_sha256':root_digest(b,v)} for k,v in names.items()}}
    with tempfile.TemporaryDirectory(dir=B,prefix='qualification-') as td:
        path=Path(td)/'regions.json.gz'
        with gzip.open(path,'wb') as f:f.write(json.dumps(payload).encode())
        require(load_independent(model,path,proof)==names,'Two imported original region functions')
        for name in ('W','reachable'):
            p=copy.deepcopy(proof);p['comparisons'][name]['canonical_sha256']='0'*64
            rejects(lambda:load_independent(model,path,p))
        p=copy.deepcopy(payload);p['fields']=[]
        with gzip.open(path,'wb') as f:f.write(json.dumps(p).encode())
        rejects(lambda:load_independent(model,path,proof))


def runner_accounting():
    spec=importlib.util.spec_from_file_location('loss_runner_qualification',B/'run.py')
    runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
    for started in (False,True,None):
        v={'status':'UNKNOWN_NOT_ATTEMPTED','BDD_worker_started':started}
        require(runner.preserve_interrupted_attempt(v)['status']==('UNKNOWN_NOT_ATTEMPTED' if started is False else 'UNKNOWN_RUNNER_FAILURE'),'Interrupted exact start accounting')
    for value in ('UNRECOGNIZED','UNKNOWN_INCOMPLETE'):
        rejects(lambda:runner.admit_pass({'id':'synthetic','schema':'preservation-loss-case-v1','status':value},'synthetic',{}, {}, {}))
    with patch.object(runner,'pin',return_value={'path':'synthetic','bytes':0,'sha256':'0'*64}),patch.object(runner,'verify',return_value=None):
        row={'proof':{},'process':{},'condition_proof':{},'condition_process':{},'input_pins':[]};freeze={'code_files':[]};decision={}
        base={'id':'synthetic','schema':'preservation-loss-case-v1','status':'PASS','root_authorization':decision,'parent_aborted':True,
            'native_runs':0,'full_reset_uses':0,'complete_semantic_literal_only':True,'released_syntactic_loss_conclusion':None,
            'runtime_or_controller_reachability_conclusion':None,'W_subset_C':False,'full_region_preserved':False,
            'counts':{'C':1,'W':2,'W_C':0,'W_minus_C':1,'W_minus_W_C':2,'delayed_loss':1,'original_reachable':2,'original_reachable_loss':2,'original_initialized':1},
            'original_reachable_loss_nonempty':True,'initial_quantification':{'W':{'value':True,'missing_environment_initial_count':0},'W_C':{'value':False,'missing_environment_initial_count':1}},
            'initial_verdict_changed':True,'original_independent_proof':{},'original_independent_process':{},'condition_proof':{},'condition_process':{},
            'input_pins':[runner.pin(None),runner.pin(None),decision],'functions':{}}
        runner.admit_pass(base,'synthetic',row,freeze,decision)
        for mutation in ('loss_count','initial','reach','scope','authority'):
            v=copy.deepcopy(base)
            if mutation=='loss_count':v['counts']['W_minus_W_C']=1
            elif mutation=='initial':v['initial_verdict_changed']=False
            elif mutation=='reach':v['original_reachable_loss_nonempty']=False
            elif mutation=='scope':v['released_syntactic_loss_conclusion']='loss'
            else:v['original_independent_process']={'changed':True}
            rejects(lambda:runner.admit_pass(v,'synthetic',row,freeze,decision))


if __name__=='__main__':
    require(not (B/'FROZEN.json').exists() and not (B/'RUN_STARTED.json').exists(),'Qualification before freeze only')
    signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('Synthetic qualification 60s cap')));signal.alarm(60)
    test('exhaustive_ENV1_SYS2_64_relations_all16_single_justice_pairs',lambda:exhaustive(1,2))
    test('exhaustive_ENV2_SYS1_256_relations_all16_single_justice_pairs',lambda:exhaustive(2,1))
    test('Guard_first_flip_loss_and_initial_change',guard)
    test('delayed_loss_strictly_larger_than_W_minus_C',delayed)
    test('outer_C_required_for_environment_dead_end_vacuity',env_dead)
    test('multiple_justices_AUX_typed_ternary_zero_ownerbits_empty_initials',additional)
    test('W_and_reachable_import_exact_counts_digests_and_tamper_rejection',importer)
    test('outer_process_admission_scope_and_interrupted_accounting',runner_accounting)
    signal.alarm(0)
    result={'schema':'preservation-loss-offline-qualification-v1','created_utc':now(),
        'status':'PASS' if all(t['pass'] for t in tests) else 'FAIL','tests':tests,
        'passed':sum(t['pass'] for t in tests),'total':len(tests),'finite_arenas_checked':fixture_count,
        'exhaustive_arenas_checked':exhaustive_count,'corpus_BDD_computations':0,'native_runs':0,'full_reset_uses':0,
        'oracle':'Independent finite sets plus explicit literal-helper finite arena; original and guarded strict regions, initial quantification, reachable intersections.',
        'source_pins':[pin(B/n) for n in ('evidence.py','loss.py','measure.py','run.py','qualify.py','PROTOCOL_JA.txt')]}
    save(B/'OFFLINE_QUALIFICATION.json',result)
    print(json.dumps({k:result[k] for k in ('status','passed','total','finite_arenas_checked','exhaustive_arenas_checked','corpus_BDD_computations')}))
    require(result['status']=='PASS','Synthetic mathematical qualification failed')
