"""One-way-helper safety/GR1 decomposition and direct full-helper reference."""
import importlib.util,sys
sys.dont_write_bytecode=True
from evidence import S,H,require
sys.path.insert(0,str(S))
spec=importlib.util.spec_from_file_location('decomposition_frozen_symbolic',S/'symbolic.py')
symbolic=importlib.util.module_from_spec(spec);spec.loader.exec_module(symbolic)
Operations,gr1_three,fixed,count,digest,initial_quantification=(getattr(symbolic,n) for n in ('Operations','gr1_three','fixed','count','root_digest','initial_quantification'))
spec=importlib.util.spec_from_file_location('decomposition_frozen_pair',H/'map_pair.py')
pair_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(pair_module)
build,BDD,ResourceRefusal=pair_module.build,pair_module.BDD,pair_module.ResourceRefusal

def cofactor(b,u,h,hp,x,y):
    return b.exists(b.conj(u,b.cube({h:bool(x),hp:bool(y)})),(h,hp))

def solve(b,q,de,den,dsn,current,en,sn,prime,oe,os,oa,og,te,ts,je,js,ja,jg,jte,jts,h=None,hp=None):
    current,en,sn=tuple(current),tuple(en),tuple(sn);prime=dict(prime)
    require(set(prime)==set(current) and set(prime.values())==set(en+sn) and len(set(prime.values()))==len(prime),'Complete original prime bijection')
    require(b.support(q)<=set(current) and b.support(den)<=set(en) and b.support(dsn)<=set(sn),'Typed domain support')
    require(set(current).isdisjoint(en+sn),'Original current/next disjoint')
    require(b.support(oe)<=set(current+en),'Original ENV next-SYS independence')
    edge=b.conj(q,b.rename(q,prime));logs={k:{} for k in ('W_original','U','W_F','W_direct')}
    ops=Operations(b,q,oe,os,den,dsn,current,en,sn,prime)
    w=gr1_three(b,q,oa,og,ops.cpre,logs['W_original'])
    roots={'D':q,'W_original':w};checks={};helper=h is not None or hp is not None
    def eq(x,y,mask=edge):return b.conj(mask,b.apply('xor',x,y))==0
    if helper:
        require(type(h) is int and type(hp) is int and h!=hp and not {h,hp}&set(current+en+sn),'Two fresh helper bits')
        require(b.support(je)<=set(current+en+(h,hp)),'Actual ENV next-SYS independence')
        require(b.support(js)<=set(current+en+sn+(h,hp)),'Actual SYS support')
        quads={str(x)+str(y):(cofactor(b,je,h,hp,x,y),cofactor(b,js,h,hp,x,y)) for x,y in ((0,0),(0,1),(1,0),(1,1))}
        e00,s00=quads['00'];e01,s01=quads['01'];e10,s10=quads['10'];e11,s11=quads['11']
        checks.update(original_ENV_00_equal=eq(e00,oe),original_SYS_00_equal=eq(s00,os),helper_ENV_10_impossible=eq(e10,0))
        require(all(checks.values()),'Generalized one-way theorem structural premise')
        # The actual saved justices/initializers are compared on both helper slices.
        bv=b.var(h);hpv=b.var(hp)
        indices=[i for i,u in enumerate(ja) if eq(u,b.neg(bv),q)]
        require(len(indices)==1,'Unique actual helper justice GF not-b')
        remaining=[u for i,u in enumerate(ja) if i!=indices[0]]
        require(len(remaining)==len(oa) and len(jg)==len(og) and all(eq(a,c,q) for a,c in zip(remaining,oa)) and all(eq(a,c,q) for a,c in zip(jg,og)),'Actual full-domain original justice identity/order')
        require(eq(jte,b.conj(te,b.neg(bv)),q) and eq(jts,ts,q),'Actual full-domain original initializers with b=false')
        trap=Operations(b,q,e11,s11,den,dsn,current,en,sn,prime)
        u=fixed(b,q,trap.cpre,True,'U_safety',logs['U'])
        flip=Operations(b,q,e01,s01,den,dsn,current,en,sn,prime);f=flip.cpre(u)
        guarded=b.conj(f,os,b.rename(f,prime))
        restricted=Operations(b,q,oe,guarded,den,dsn,current,en,sn,prime)
        wf=b.conj(f,gr1_three(b,q,oa,og,restricted.cpre,logs['W_F']))
        total=Operations(b,q,1,os,den,dsn,current,en,sn,prime);c=total.cpre(q)
        hc=current+(h,);he=en+(hp,);hprime={**prime,h:hp}
        direct=Operations(b,q,je,js,den,dsn,hc,he,sn,hprime)
        full=gr1_three(b,q,ja,jg,direct.cpre,logs['W_direct'])
        d0=b.exists(b.conj(full,b.neg(bv)),(h,));d1=b.exists(b.conj(full,bv),(h,))
        roots.update(U=u,F=f,C=c,W_F=wf,W_direct_full=full,W_direct_0=d0,W_direct_1=d1,
            active_difference=b.apply('xor',wf,d0),trap_difference=b.apply('xor',u,d1),
            U_missing=b.conj(q,b.neg(u)),F_xor_C=b.apply('xor',f,c),F_missing=b.conj(q,b.neg(f)),
            W_minus_F=b.conj(w,b.neg(f)),W_loss=b.conj(w,b.neg(wf)),delayed_loss=b.conj(w,b.neg(wf),f))
        checks.update(U_equals_D=u==q,F_equals_C=f==c,F_equals_D=f==q,
            active_decomposition_equal=wf==d0,trap_decomposition_equal=u==d1,W_subset_F=roots['W_minus_F']==0,
            original_full_region_preserved=w==wf,subset_original=b.conj(wf,b.neg(w))==0,
            full_preservation_iff_W_subset_F=(w==wf)==(roots['W_minus_F']==0))
        quant_regions={'W_original':w,'W_predicted':wf,'W_direct_active':d0}
        job_quant=initial_quantification(b,de,jte,jts,full,tuple(x for x in current if prime[x] in set(sn)))
        roots['job_initial_SYS_witness']=job_quant['system_witness'];roots['job_missing_initial_ENV']=job_quant['missing_environment_initials']
        checks['literal_preservation_corollary_applicable']=u==q and f==c
        checks['corrected_preservation_corollary_applicable']=f==q
        branch='ONE_WAY_HELPER'
    else:
        require(eq(je,oe) and eq(js,os),'No-helper full relation identity')
        require(len(ja)==len(oa) and len(jg)==len(og) and all(eq(a,c,q) for a,c in zip(ja,oa)) and all(eq(a,c,q) for a,c in zip(jg,og)),'No-helper justice identity')
        require(eq(jte,te,q) and eq(jts,ts,q),'No-helper original initializers')
        direct=Operations(b,q,je,js,den,dsn,current,en,sn,prime)
        full=gr1_three(b,q,ja,jg,direct.cpre,logs['W_direct'])
        roots.update(W_direct_full=full,W_direct_0=full,W_F=w,active_difference=b.apply('xor',w,full),W_loss=b.conj(w,b.neg(full)))
        checks.update(no_helper_identity=True,active_decomposition_equal=w==full,trap_decomposition_equal=None,
            original_full_region_preserved=w==full,subset_original=b.conj(full,b.neg(w))==0,full_preservation_iff_W_subset_F=None)
        quant_regions={'W_original':w,'W_predicted':w,'W_direct_active':full}
        job_quant=initial_quantification(b,de,jte,jts,full,tuple(x for x in current if prime[x] in set(sn)))
        roots['job_initial_SYS_witness']=job_quant['system_witness'];roots['job_missing_initial_ENV']=job_quant['missing_environment_initials']
        branch='NO_HELPER_IDENTITY'
    quant={}
    for name,x in quant_regions.items():
        quant[name]=initial_quantification(b,de,te,ts,x,tuple(v for v in current if prime[v] in set(sn)))
        roots[name+'_initial_SYS_witness']=quant[name]['system_witness'];roots[name+'_missing_initial_ENV']=quant[name]['missing_environment_initials']
    checks['initial_quantification_equal']=quant['W_predicted']['value']==quant['W_direct_active']['value']==job_quant['value']
    return {'branch':branch,'roots':roots,'checks':checks,'quant':quant,'actual_job_quant':job_quant,'logs':logs}

def lifted_inputs(pair):
    """Lift actual saved justice functions, without substituting expected justices."""
    b=pair['common'];o,j=pair['original'],pair['job']
    ot=pair_module.transfer(o.b,b,{v:b.var(v) for v in range(o.b.n)})
    replacements={}
    for name,field in j.by_name.items():
        for nxt,key in ((False,'current_bits'),(True,'next_bits')):
            for v in field[key]:
                if name==pair_module.HELPER:
                    bv=b.var(pair['helper_next_bit'] if nxt else pair['helper_current_bit'])
                    replacements[v]=b.ite(bv,int(j.enc[name]['true'][int(nxt)][v]),int(j.enc[name]['false'][int(nxt)][v]))
                else:replacements[v]=b.disj(*(ot(o.literal(name,value,nxt)) for value in field['values'] if j.enc[name][value][int(nxt)][v]))
    jt=pair_module.transfer(j.b,b,replacements)
    args=dict(b=b,q=ot(o.domain),de=ot(o.domain_ec),den=ot(o.domain_en),dsn=ot(o.domain_sn),current=o.current,en=o.env_next,sn=o.sys_next,prime=o.prime,
        oe=pair['original_roots']['rhoE'],os=pair['original_roots']['rhoS'],oa=[ot(u) for u in o.justices['ENV']],og=[ot(u) for u in o.justices['SYS']],te=pair['original_roots']['thetaE'],ts=pair['original_roots']['thetaS'],
        je=pair['job_roots']['rhoE'],js=pair['job_roots']['rhoS'],ja=[jt(u) for u in j.justices['ENV']],jg=[jt(u) for u in j.justices['SYS']],jte=pair['job_roots']['thetaE'],jts=pair['job_roots']['thetaS'],h=pair['helper_current_bit'],hp=pair['helper_next_bit'])
    return args
