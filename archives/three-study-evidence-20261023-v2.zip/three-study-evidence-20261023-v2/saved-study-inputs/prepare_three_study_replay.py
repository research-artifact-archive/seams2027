#!/usr/bin/env python3
"""Bind a fresh three-study replay workspace without executing study code.

The archived evidence is read-only. Only allowlisted location/pin fields in
derived runtime metadata change. Every original/public/runtime pin and every
changed value is recorded. No scientific module is imported or launched here.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

BASE = "experiment/v58_submission_20261023"
OLD = "experiment/seams_research_reframing_20261017"
REQUEST = BASE + "/request_protocol"
CENSUS = BASE + "/guard_census"
GUARD = BASE + "/guard_audit"
HUMANOID_SOURCE = OLD + "/kind_corpus/original/artifact/experiments/specs/syn15/HumanoidLTL_460_Humanoid.spectra"
GUARD_SOURCE = "experiment/seams_establishment_20261013/degradation_gate_v2/qualification/transition_guard.spectra"
ARENAS = [
    (OLD + "/released_transform_044_main/runs/corpus044__original/original", HUMANOID_SOURCE),
    (OLD + "/released_transform_044_main/runs/corpus044__original/released", HUMANOID_SOURCE),
    (OLD + "/released_transform_probe_public/qualification/guard/original", GUARD_SOURCE),
    ("experiment/seams_submission_push_20261016/released_kind_pipeline_feasibility/runs/guard", GUARD_SOURCE),
]


def require(test, message):
    if not test:
        raise ValueError(message)


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()


def size_hash(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def pin(path):
    path = path.resolve()
    return {"path": str(path), **size_hash(path.read_bytes())}


def relative(value):
    if value.startswith("<WORKSPACE_ROOT>/"):
        value = value[len("<WORKSPACE_ROOT>/"):]
    p = Path(value)
    require(not p.is_absolute() and str(p) == value and all(x not in (".", "..") for x in p.parts),
            "Noncanonical or unresolved workspace-relative reference: " + value)
    return value


def differences(before, after, pointer=""):
    if type(before) is type(after) and isinstance(before, dict) and before.keys() == after.keys():
        return [row for key in before for row in differences(before[key], after[key], pointer + "/" + key)]
    if type(before) is type(after) and isinstance(before, list) and len(before) == len(after):
        return [row for i in range(len(before)) for row in differences(before[i], after[i], pointer + "/" + str(i))]
    return [] if type(before) is type(after) and before == after else [{"pointer": pointer, "before": before, "after": after}]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle-root", type=Path, required=True)
    parser.add_argument("--expected-manifest-sha256", required=True)
    parser.add_argument("--replay-root", type=Path, required=True)
    parser.add_argument("--python", type=Path, required=True)
    parser.add_argument("--confirmed-root-controlled-binding", action="store_true", required=True)
    parser.add_argument("--ordinary-usage-gate-confirmed", action="store_true", required=True)
    args = parser.parse_args()
    bundle, root = args.bundle_root.resolve(), args.replay_root.resolve()
    require(not root.exists() and root.parent.is_dir(), "Replay root must be fresh with an existing parent")
    require(not root.is_relative_to(bundle) and not bundle.is_relative_to(root), "Replay root must be separate from the archive")
    manifest_path = bundle / "MANIFEST.json"
    require(pin(manifest_path)["sha256"] == args.expected_manifest_sha256, "Root-adopted public manifest pin")
    manifest = json.loads(manifest_path.read_text())
    require(manifest["status"] == "ASSEMBLED_NOT_REPLAY_QUALIFIED", "Use the assembled evidence manifest, not a preview")
    delivered = {}
    for ref in manifest["files"]:
        name = relative(ref["path"])
        path = bundle / name
        require(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(bundle), "Regular delivered file required")
        raw = path.read_bytes()
        require(size_hash(raw) == {k: ref[k] for k in ("bytes", "sha256")}, "Delivered file pin mismatch: " + name)
        require(name not in delivered, "Duplicate public manifest path")
        delivered[name] = raw
    require(manifest["file_count_excluding_manifest"] == len(delivered), "Public manifest file count")
    bridge_rows = json.loads(delivered["PUBLIC_PIN_MAP.json"])["files"]
    transformation_rows = {row["public_path"]: row["changes"]
                           for row in json.loads(delivered["TRANSFORMATIONS.json"])["files"]}
    origins, working, changes = {}, {}, []
    for row in bridge_rows:
        name = relative(row["origin_relative"])
        require(row["public_path"] == "evidence/" + name and name not in origins, "Public/origin mapping identity")
        raw = delivered[row["public_path"]]
        require(size_hash(raw) == row["public"], "Public pin bridge mismatch")
        if name.endswith((".py", ".java", ".bdd", ".spectra", ".gz")):
            require(row["original"] == row["public"], "Scientific/source/BDD/gzip bytes must be exact: " + name)
        if name.endswith(".contract.json"):
            delta = transformation_rows.get(row["public_path"], [])
            require(all(d.get("json_pointer") == "/authority/path" for d in delta),
                    "Contract transformation must be limited to /authority/path")
            contract = json.loads(raw)
            contract["authority"] = dict(contract["authority"])
            contract["authority"].pop("path")
            invariant = size_hash(encoded(contract))["sha256"]
            proof = row["contract_preservation"]
            require(proof["excluded_pointer"] == "/authority/path"
                    and proof["all_other_contract_values_unchanged"] is True
                    and invariant == proof["original_invariant_sha256"] == proof["public_invariant_sha256"],
                    "Every other request contract value must be preserved")
        origins[name], working[name] = row, raw
    runtime_python = pin(args.python)

    def read(name):
        return json.loads(working[name])

    def runtime_pin(name):
        require(name in working, "Missing runtime closure file: " + name)
        return {"path": str(root / name), **size_hash(working[name])}

    def edit(name, value, allowed, kind="LOCATION_AND_PIN_ONLY_DERIVED_METADATA"):
        before = read(name)
        delta = differences(before, value)
        require(all(allowed(d["pointer"]) for d in delta), "Non-allowlisted metadata edit: " + name)
        if delta:
            working[name] = encoded(value)
            changes.append({"origin_relative": name, "kind": kind, "changes": delta})

    def fresh(name, value, kind):
        require(name in working, "Fresh binding replaces only a mapped runtime-copy metadata file")
        before = read(name)
        working[name] = encoded(value)
        changes.append({"origin_relative": name, "kind": kind, "changes": differences(before, value)})

    # Each original native receipt must bind the original model bytes before
    # the explicit original -> redacted public -> runtime metadata bridge.
    for directory, source_name in ARENAS:
        model_name, result_name = directory + "/model.json", directory + "/result.json"
        model, result = read(model_name), read(result_name)
        require({k: model["input"][k] for k in ("bytes", "sha256")} == origins[source_name]["original"],
                "Historical model/source binding")
        require({k: result["model_export"][k] for k in ("bytes", "sha256")} == origins[model_name]["original"],
                "Historical receipt/model binding")
        require(result["model_export"]["file"] == "model.json", "Expected model basename")
        model["input"]["path"] = str(root / source_name)
        edit(model_name, model, lambda p: p == "/input/path")
        bound_model = runtime_pin(model_name)
        result["model_export"].update({k: bound_model[k] for k in ("bytes", "sha256")})
        edit(result_name, result, lambda p: p in ("/model_export/bytes", "/model_export/sha256"))
        require(read(model_name)["input"]["path"] == str(root / source_name), "Source identity bound to the fresh workspace")

    # Request study: preserve every scientific specification field and roster.
    request_plan = read(REQUEST + "/STUDY_SPECIFICATION.json")
    modes = ["OLD_request_disabled", "NEW_request_enabled"]
    require(request_plan["models"] == modes, "Fixed request model roster")
    code = [runtime_pin(REQUEST + "/" + n) for n in ("finite_game.py", "source_protocol.py", "independent_checks.py", "run_study.py")]
    sources = {m: runtime_pin(REQUEST + "/" + m + ".contract.json") for m in modes}
    advisory = runtime_pin("experiment/seams_submission_supervision_20261021/V58_ROOT_OPERATIONAL_STUDY_DESIGN_REVIEW.json")
    request_plan.update(code_files=code, sources=sources, formal_advisory=advisory)
    edit(REQUEST + "/STUDY_SPECIFICATION.json", request_plan,
         lambda p: p.startswith(("/code_files/", "/sources/", "/formal_advisory/")))
    request_output = root / REQUEST / "replay_results_01"
    request_go = {"schema": "request-protocol-execution-go-v1", "authorized": True, "scope": "FULL_STUDY",
                  "attempt": 1, "ordinary_usage_gate_confirmed": True,
                  "plan": runtime_pin(REQUEST + "/STUDY_SPECIFICATION.json"), "output": str(request_output),
                  "files": code + [sources[m] for m in modes] + [advisory],
                  "binding_kind": "FRESH_ROOT_CONTROLLED_PORTABLE_REPLAY_NOT_HISTORICAL_GO"}
    fresh(REQUEST + "/ROOT_GO.json", request_go, "FRESH_REQUEST_REPLAY_AUTHORITY")

    # Guard inputs: every consumed manifest pin is rebound to the exact runtime
    # bytes; historical native-result claims and all scientific values persist.
    guard_manifest = read(GUARD + "/INPUT_MANIFEST.json")
    for ref in guard_manifest["inputs"]:
        name = relative(ref["path"])
        ref.update({k: runtime_pin(name)[k] for k in ("bytes", "sha256")})
    source = guard_manifest["source"]
    require(relative(source["path"]) == GUARD_SOURCE, "Fixed Guard source identity")
    source.update({k: runtime_pin(GUARD_SOURCE)[k] for k in ("bytes", "sha256")})
    edit(GUARD + "/INPUT_MANIFEST.json", guard_manifest,
         lambda p: (p.startswith("/inputs/") or p.startswith("/source/")) and p.rsplit("/", 1)[-1] in ("bytes", "sha256"))
    guard_freeze = {"schema": "v58-guard-execution-freeze-v1", "execution_owner": "root_main_scientific_owner",
                    "checker_sha256": runtime_pin(GUARD + "/check_guard_saved_arena.py")["sha256"],
                    "manifest_sha256": runtime_pin(GUARD + "/INPUT_MANIFEST.json")["sha256"],
                    "preexecution_spec_sha256": runtime_pin(GUARD + "/PREEXECUTION_SPEC.json")["sha256"],
                    "binding_kind": "FRESH_ROOT_CONTROLLED_PORTABLE_REPLAY_NOT_HISTORICAL_FREEZE"}
    fresh(GUARD + "/EXECUTION_FREEZE.json", guard_freeze, "FRESH_GUARD_REPLAY_AUTHORITY")

    # Census imports and source locations keep their original repository shape.
    census_manifest = read(CENSUS + "/EXECUTION_INPUTS.json")
    for ref in census_manifest["files"]:
        name = relative(ref["path"])
        ref.update(runtime_pin(name))
    census_manifest["python"] = runtime_python
    edit(CENSUS + "/EXECUTION_INPUTS.json", census_manifest,
         lambda p: p.startswith(("/files/", "/python/")) and p.rsplit("/", 1)[-1] in ("path", "bytes", "sha256"))
    census_output = root / CENSUS / "replay_results_01"
    fresh(CENSUS + "/ROOT_GO.json", {"schema": "portable-census-root-go-v1", "authorized": True,
          "execution_owner": "root_main_scientific_owner", "allowed_runs": 1,
          "frozen_inputs": runtime_pin(CENSUS + "/EXECUTION_INPUTS.json"), "output_directory": str(census_output),
          "binding_kind": "FRESH_ROOT_CONTROLLED_PORTABLE_REPLAY_NOT_HISTORICAL_GO"}, "FRESH_CENSUS_REPLAY_AUTHORITY")

    # Materialize once into the new workspace. No archived file is overwritten.
    root.mkdir()
    for name, raw in working.items():
        target = root / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(raw)
    control = root / "_portable_replay"
    control.mkdir()
    (control / "receipts").mkdir()
    guard_output_dir = root / GUARD / "replay_results_01"
    guard_output_dir.mkdir()
    guard_output = guard_output_dir / "RESULT.json"
    py = runtime_python["path"]
    commands = {
        "request_protocol": {"scientific_argv": [py, "-B", str(root / REQUEST / "run_study.py"), "--plan", str(root / REQUEST / "STUDY_SPECIFICATION.json"), "--go", str(root / REQUEST / "ROOT_GO.json"), "--output", str(request_output)], "output_tree": str(request_output), "new_result": str(request_output / "RESULT.json")},
        "guard_census": {"scientific_argv": [py, "-B", str(root / CENSUS / "census.py"), str(census_output)], "output_tree": str(census_output), "new_result": str(census_output / "RESULT.json")},
        "guard_audit": {"scientific_argv": [py, "-I", "-S", "-B", str(root / GUARD / "check_guard_saved_arena.py"), "--root", str(root), "--manifest", str(root / GUARD / "INPUT_MANIFEST.json"), "--freeze", str(root / GUARD / "EXECUTION_FREEZE.json"), "--output", str(guard_output)], "output_tree": str(guard_output_dir), "new_result": str(guard_output)},
    }
    for study, command in commands.items():
        command["receipt_directory"] = str(control / "receipts" / study)
        command["supervised_argv"] = [py, "-B", str(root / BASE / "run_controlled.py"),
                                      command["receipt_directory"], command["output_tree"], "--", *command["scientific_argv"]]
    bridge = {"schema": "three-study-portable-binding-bridge-v1", "status": "BOUND_NOT_EXECUTED",
              "archive_manifest": pin(manifest_path), "archive_unchanged": True,
              "scientific_code_changed": False, "scientific_imports": 0, "scientific_executions": 0,
              "historical_result_scope": "Old evidence remains in the archive. Runtime result.json files are location/pin-only derived native-input metadata, not new native runs or new outcomes.",
              "files": [{"origin_relative": name, "original": origins[name]["original"],
                         "delivered_public": origins[name]["public"], "runtime": runtime_pin(name),
                         "runtime_byte_identical_to_public": working[name] == delivered[origins[name]["public_path"]]}
                        for name in sorted(working)], "metadata_changes": changes}
    (control / "BINDING_BRIDGE.json").write_bytes(encoded(bridge))
    go = {"schema": "three-study-root-replay-go-v1", "authorized": True,
          "execution_owner": "root_main_scientific_owner", "allowed_runs_per_study": 1,
          "ordinary_usage_gate_confirmed": True, "root": str(root),
          "python": runtime_python, "archive_manifest": pin(manifest_path),
          "binding_bridge": pin(control / "BINDING_BRIDGE.json"),
          "runner": pin(bundle / "run_bound_study.py"), "binder": pin(bundle / "prepare_three_study_replay.py"),
          "comparer": pin(bundle / "compare_three_study_replays.py"),
          "inputs": [runtime_pin(name) for name in sorted(working)], "studies": commands,
          "created_utc": datetime.now(timezone.utc).isoformat()}
    go_path = control / "ROOT_REPLAY_GO.json"
    go_path.write_bytes(encoded(go))
    plan = {"schema": "three-study-root-replay-command-plan-v1", "status": "BOUND_NOT_EXECUTED",
            "science_commands": [{"study": name, "argv": [py, "-I", "-S", "-B", str(bundle / "run_bound_study.py"),
                                 "--go", str(go_path), "--expected-go-sha256", pin(go_path)["sha256"], "--study", name]}
                                for name in commands],
            "comparison_argv_after_all_three": [py, "-I", "-S", "-B", str(bundle / "compare_three_study_replays.py"),
                                               "--bundle-root", str(bundle), "--go", str(go_path),
                                               "--expected-go-sha256", pin(go_path)["sha256"],
                                               "--output", str(control / "REPLAY_COMPARISON.json")],
            "scientific_execution_owner": "root only", "additional_user_approval_required": False}
    (control / "REPLAY_PLAN.json").write_bytes(encoded(plan))
    # Confirm the archive manifest and all delivered byte pins again after binding.
    require(pin(manifest_path)["sha256"] == args.expected_manifest_sha256, "Archive manifest changed")
    for name, raw in delivered.items():
        require((bundle / name).read_bytes() == raw, "Archive evidence changed during binding")
    print(json.dumps({"status": "BOUND_NOT_EXECUTED", "go": pin(go_path),
                      "plan": pin(control / "REPLAY_PLAN.json"), "scientific_executions": 0}))


if __name__ == "__main__":
    main()
