#!/usr/bin/env python3
"""Compare saved old/new results only; do not import or execute scientific code."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path


def pin(path):
    path = Path(path).resolve(); raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def normalized_events(events, owned_pid, expected_episodes):
    def require(test, message):
        if not test:
            raise ValueError(message)
    require(len(events) == 66 and [e["sequence"] for e in events] == list(range(66)), "Complete ordered 66-event sequence")
    require(all(type(e["pid"]) is int and e["pid"] == owned_pid for e in events), "Single recorded owned PID")
    clocks = [e["monotonic_ns"] for e in events]
    require(all(type(t) is int and t >= 0 for t in clocks)
            and all(a <= b for a, b in zip(clocks, clocks[1:])), "Monotone recorded clock")
    episodes, normalized = {}, []
    for event in events:
        eid = event["episode_id"]
        if event["event"] == "start":
            require(eid not in episodes and type(event["source_object"]) is int
                    and type(event["controller"]) is int, "Unique episode start with object/controller tokens")
            episodes[eid] = {"source": event["source_object"], "old": event["controller"],
                             "active": event["controller"], "installed": None, "terminal": None}
        require(eid in episodes, "Event before episode start")
        state = episodes[eid]
        require(state["terminal"] is None and event["source_object"] == state["source"], "Episode source-object continuity")
        if event["event"] == "install":
            require(state["installed"] is None and event["old_controller"] == state["active"]
                    and type(event["controller"]) is int and event["controller"] != state["active"],
                    "Exactly one actual controller replacement")
            state["active"] = state["installed"] = event["controller"]
        else:
            require("old_controller" not in event, "Old controller token outside installation")
            if "controller" in event:
                require(event["controller"] == state["active"], "Episode controller continuity")
        if event["event"] in ("completed", "remain_paused"):
            state["terminal"] = event["event"]
            require((state["installed"] is not None) == (event["event"] == "completed"), "Installation/terminal-state consistency")
        value = dict(event)
        value["source_object"] = "SOURCE:" + eid
        value["pid"] = "OWNED_PROCESS"
        value["monotonic_ns"] = "MONOTONIC_VALUE_CHECKED"
        if "controller" in value:
            value["controller"] = ("INSTALLED:" if event["controller"] == state["installed"] else "ORIGINAL:") + eid
        if "old_controller" in value:
            value["old_controller"] = "ORIGINAL:" + eid
        normalized.append(value)
    require(list(episodes) == expected_episodes and all(s["terminal"] for s in episodes.values()), "Seven complete prespecified episodes")
    return normalized


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle-root", type=Path, required=True)
    parser.add_argument("--go", type=Path, required=True)
    parser.add_argument("--expected-go-sha256", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("Fresh comparison output required")
    if pin(args.go)["sha256"] != args.expected_go_sha256:
        raise ValueError("Root-adopted GO pin mismatch")
    go = json.loads(args.go.read_text()); bundle = args.bundle_root.resolve()
    if go["schema"] != "three-study-root-replay-go-v1" or set(go["studies"]) != {"request_protocol", "guard_census", "guard_audit"}:
        raise ValueError("Exact three-study root authority required")
    if pin(__file__) != go["comparer"] or pin(bundle / "MANIFEST.json") != go["archive_manifest"]:
        raise ValueError("Comparison code or immutable archive manifest binding mismatch")
    base = bundle / "evidence/experiment/v58_submission_20261023"
    exclusions = {
        "request_protocol": {"created_utc", "finished_utc", "elapsed_seconds", "input_pins"},
        "guard_census": {"study", "small_propagation_control", "frozen_execution_inputs", "source_qualification", "source", "seconds", "artifacts"},
        "guard_audit": {"checker_sha256", "manifest_sha256"},
    }
    checks = []
    def check(name, value): checks.append({"name": name, "pass": bool(value)})
    check("root authority schema", go["schema"] == "three-study-root-replay-go-v1")
    archive_manifest = json.loads((bundle / "MANIFEST.json").read_text())
    for ref in archive_manifest["files"]:
        current = pin(bundle / ref["path"])
        check("immutable archive " + ref["path"], {k: current[k] for k in ("bytes", "sha256")} == {k: ref[k] for k in ("bytes", "sha256")})
    for ref in go["inputs"] + [go["archive_manifest"], go["binding_bridge"]]:
        check("unchanged input " + ref["path"], pin(ref["path"]) == ref)
    for study, command in go["studies"].items():
        old_path = base / study / ("RESULT_01.json" if study == "guard_audit" else "results_01/RESULT.json")
        new_path = Path(command["new_result"])
        old, new = json.loads(old_path.read_text()), json.loads(new_path.read_text())
        semantic_old = {k: v for k, v in old.items() if k not in exclusions[study]}
        semantic_new = {k: v for k, v in new.items() if k not in exclusions[study]}
        check(study + " complete semantic result equality", semantic_old == semantic_new)
        process = json.loads((Path(command["receipt_directory"]) / "PROCESS.json").read_text())
        check(study + " process owned, reaped, absent", process["status"] == "COMPLETE" and process["exit_code"] == 0
              and process["owned_child_reaped"] is True and not process["violations"]
              and process["final_group_observation"] == {"state": "ABSENT", "members": []})
        if study == "guard_census":
            for name in ("ALL_STATES.csv.gz", "FUNCTIONS.json.gz"):
                a = gzip.decompress((old_path.parent / name).read_bytes())
                b = gzip.decompress((new_path.parent / name).read_bytes())
                check("guard_census exact decoded " + name, a == b)
            for name in ["ARM_" + format(i, "03b") + ".json" for i in range(8)] + ["SOURCE_QUALIFICATION.json"]:
                check("guard_census complete saved " + name,
                      json.loads((old_path.parent / name).read_text()) == json.loads((new_path.parent / name).read_text()))
            a = json.loads((old_path.parent / "SMALL_PROPAGATION_CONTROL.json").read_text())
            b = json.loads((new_path.parent / "SMALL_PROPAGATION_CONTROL.json").read_text())
            a["fixture"].pop("path"); b["fixture"].pop("path")
            check("guard_census complete small propagation control except relocated fixture path", a == b)
        if study == "request_protocol":
            certificate_names = [p.name for p in old_path.parent.glob("*CERTIFICATE.json")]
            for name in ("QUALIFICATION.json", "SOURCE_CORRESPONDENCE.json", *sorted(certificate_names)):
                check("request_protocol complete " + name,
                      json.loads((old_path.parent / name).read_text()) == json.loads((new_path.parent / name).read_text()))
            events_a = json.loads((old_path.parent / "EVENTS.json").read_text())
            events_b = json.loads((new_path.parent / "EVENTS.json").read_text())
            old_process = json.loads((base / study / "execution_01/PROCESS.json").read_text())
            expected_episodes = [e["episode_id"] for e in old["episodes"]]
            try:
                a = normalized_events(events_a, old_process["owned_pid"], expected_episodes)
                b = normalized_events(events_b, process["owned_pid"], expected_episodes)
                check("request_protocol 66 events with PID/source/controller/clock validation and symbolic IDs", a == b)
            except (ValueError, KeyError, TypeError) as error:
                checks.append({"name": "request_protocol event continuity and normalized equality", "pass": False, "error": str(error)})
    check("GO unchanged after comparison", pin(args.go)["sha256"] == args.expected_go_sha256)
    check("archive manifest unchanged after comparison", pin(bundle / "MANIFEST.json") == go["archive_manifest"])
    for ref in archive_manifest["files"]:
        current = pin(bundle / ref["path"])
        check("post-comparison immutable archive " + ref["path"],
              {k: current[k] for k in ("bytes", "sha256")} == {k: ref[k] for k in ("bytes", "sha256")})
    report = {"schema": "three-study-relocated-replay-comparison-v1", "status": "PASS" if all(c["pass"] for c in checks) else "FAIL",
              "go": pin(args.go), "checks": checks, "exclusions": {k: sorted(v) for k, v in exclusions.items()},
              "scope": "Exact saved semantic JSON comparisons plus decoded complete census tables/functions; excludes only declared runtime provenance/timing pins. No scientific code was imported by this comparison.",
              "scientific_executions_by_comparison": 0}
    with args.output.open("x") as stream:
        stream.write(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "checks": len(checks), "failures": [c["name"] for c in checks if not c["pass"]], "report": pin(args.output)}))
    if report["status"] != "PASS":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
