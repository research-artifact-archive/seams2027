#!/usr/bin/env python3
"""Root-invoked dispatcher for one exact, once-only, resource-supervised study."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


def require(test, message):
    if not test:
        raise ValueError(message)


def pin(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--go", type=Path, required=True)
    parser.add_argument("--expected-go-sha256", required=True)
    parser.add_argument("--study", choices=("request_protocol", "guard_census", "guard_audit"), required=True)
    args = parser.parse_args()
    require(pin(args.go)["sha256"] == args.expected_go_sha256, "Root-adopted GO pin")
    go = json.loads(args.go.read_text())
    require(go["schema"] == "three-study-root-replay-go-v1" and go["authorized"] is True
            and go["execution_owner"] == "root_main_scientific_owner"
            and go["ordinary_usage_gate_confirmed"] is True and go["allowed_runs_per_study"] == 1,
            "Fresh exact root replay authority")
    require(pin(__file__) == go["runner"], "Dispatcher pin")
    require(set(go["studies"]) == {"request_protocol", "guard_census", "guard_audit"}, "Exact three-study roster")
    for ref in go["inputs"] + [go["python"], go["binding_bridge"], go["archive_manifest"], go["binder"]]:
        require(pin(ref["path"]) == ref, "Fresh runtime/archive binding changed: " + ref["path"])
    root = Path(go["root"])
    command = go["studies"][args.study]
    require(not Path(command["new_result"]).exists() and not Path(command["receipt_directory"]).exists(),
            "Fresh result and receipt required")
    active = args.go.parent / "ACTIVE_STUDY.json"
    with active.open("x") as stream:
        json.dump({"study": args.study, "go_sha256": args.expected_go_sha256, "owner_pid": os.getpid()}, stream)
        stream.write("\n")
    attempt = args.go.parent / ("ATTEMPT_" + args.study + ".json")
    with attempt.open("x") as stream:
        json.dump({"status": "DISPATCHED_ONCE", "go": pin(args.go), "study": args.study,
                   "supervised_argv": command["supervised_argv"]}, stream, indent=2)
        stream.write("\n")
    process = subprocess.run(command["supervised_argv"], cwd=root, check=False)
    require(process.returncode == 0, "Owned supervisor did not complete successfully; preserve attempt and outputs")
    receipt = json.loads((Path(command["receipt_directory"]) / "PROCESS.json").read_text())
    require(receipt["status"] == "COMPLETE" and receipt["exit_code"] == 0
            and receipt["owned_child_reaped"] is True and not receipt["violations"]
            and receipt["final_group_observation"] == {"state": "ABSENT", "members": []},
            "Owned process-group completion")
    require(Path(command["new_result"]).is_file(), "Study result missing")
    active.unlink()
    print(json.dumps({"status": "OWNED_STUDY_REPLAY_COMPLETED", "study": args.study,
                      "result": pin(command["new_result"]), "process": pin(Path(command["receipt_directory"]) / "PROCESS.json")}))


if __name__ == "__main__":
    main()
