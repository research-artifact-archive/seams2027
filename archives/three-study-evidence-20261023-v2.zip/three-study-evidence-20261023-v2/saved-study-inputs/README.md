# Saved evidence for three supplementary studies

This package retains the saved outputs, executed scientific code, source inputs,
saved native arenas, BDD payloads, finite-state tables and execution records for
the finite request protocol, eight-arm Humanoid guard census, and Guard fixture
audit. The Humanoid study includes its local decomposition, qualification,
mapping and vendored BDD dependencies. Native arena production is historical
input provenance; this is not a Java/native-toolchain regeneration package.

The delivered package supports static inspection of all included records.
It is **not replay-qualified as delivered yet**. Private execution locations
were anonymized, and historical nested pins still refer to the original bytes.
The public pin map distinguishes those original hashes from delivered hashes.
Do not treat an old GO, freeze, process receipt, status field, or model input path
as a fresh execution binding. These records describe their historical run.

Replay requires fresh local binding of source/model paths,
changed metadata and their dependent hashes, a fresh output location, and the
existing execution safeguards. The local operator confirms the fixed inputs
and output destination before running each replay. In
particular, the Humanoid loaders check the identity of the source file, and the
Guard checker binds model exports to result metadata. Those bindings must be
updated consistently before replay; changing a manifest alone is insufficient.

`prepare_three_study_replay.py` prepares a separate, fresh runtime tree for all
three studies without importing or running scientific code. Supply the exact
assembled MANIFEST.json SHA-256, a fresh replay root outside this archive, the
chosen Python executable, and the two confirmation flags shown below. It checks every delivered file before copying, changes
only declared location/pin metadata, and records original/public/runtime hashes
and every changed value in `_portable_replay/BINDING_BRIDGE.json`. The archive
is read-only. Four derived model input paths and their dependent native receipt
model hashes are explicitly rebound; these are metadata copies of historical
native results, not fresh native production.

The generated `_portable_replay/REPLAY_PLAN.json` contains exactly three future
scientific commands, one per study, followed by a saved-output comparison
command. The local operator reviews the bridge and fresh
`ROOT_REPLAY_GO.json`, then invokes each generated command once in sequence.
`run_bound_study.py` enforces that frozen GO, all runtime inputs, a per-study
single-attempt record and a single active-study lock. The original unchanged
owned-process supervisor requires a POSIX host with `ps` and enforces
collection, memory/disk limits and process-group cleanup. `compare_three_study_replays.py` compares the complete retained
scientific results, certificates, qualification records, census state/BDD
tables and request events. It validates event identity continuity before
symbolizing process/object IDs and excluding clock values. It checks the GO
and archive pins before and after comparison. Generated argv and static code
validation are not execution or successful replay qualifications.

Example binding command (substitute the five local values):
```
<PYTHON> -I -S -B <BUNDLE>/prepare_three_study_replay.py --bundle-root <BUNDLE> --expected-manifest-sha256 <MANIFEST_SHA256> --replay-root <FRESH_ROOT> --python <PYTHON> --confirmed-root-controlled-binding --ordinary-usage-gate-confirmed
```
The flags record confirmation of the local input binding and execution
resources. The original studies and original results stay intact.

`PUBLIC_PIN_MAP.json` maps relative provenance identifiers and original hashes
to the delivered paths, bytes and hashes. `TRANSFORMATIONS.json` lists retained path transformations using the original
value hash and public value. This privacy derivative additionally replaces the
complete `/authority` and `/latest_review` metadata blocks in START_PLAN.json
and removes five obsolete editorial-path ledger entries. Their replacement
descriptors and canonical prior/current block hashes are recorded separately.
Every value and structure outside these two blocks is retained exactly.
All scientific BDDs, source formulas and table entries are retained. Scientific Python, Java, Spectra, BDD and gzip
payloads are byte-identical. In the two request source-contract JSON files,
only `/authority/path` may be anonymized; the pin map records a common original
and public invariant hash for every other value. The binder retains those
public contract bytes exactly. Changed metadata is distinct from those sources.
`PRIVACY_SCAN.json` covers decoded text, including both gzip payloads. This
path/token scan is not a proof of anonymity against all possible inference.

The request protocol is author-constructed. The Humanoid source family was
outcome-informed and fixed before its eight new arms; its cooperative-admission
result remains negative. The Guard comparison is a saved-instance causal audit,
not general equivalence of a native objective to strict semantics. No external
replication, fresh native synthesis, performance advantage or deployment result
is asserted by packaging these records.

The included Humanoid corpus specification retains its publisher's BSD
3-Clause terms in `LICENSE-third-party.txt`; see `THIRD_PARTY_NOTICES.txt` for
the exact source and archive boundary. No external runtime or native library
is redistributed in this package.

The enclosing `PRIVACY_AMENDMENT.json` distinguishes this current metadata
derivative from the historical relocated replay. No scientific study was
executed when preparing this derivative.
