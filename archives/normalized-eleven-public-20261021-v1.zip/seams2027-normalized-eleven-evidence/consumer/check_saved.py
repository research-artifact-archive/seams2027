#!/usr/bin/env python3
"""Recheck the fixed eleven saved exports using separately supplied sources.

Usage: python3 -I -B consumer/check_saved.py --source-root SOURCES --work-dir NEW
Add --preflight-only to check all input/derived pins without importing science.
Requires Python 3.10+ and a POSIX interval timer. No producer is run. A PASS is
about these saved inputs, the same graph judge, and shared translated BDDs;
it is not independent source compilation or a new regression qualification.
"""
import sys

sys.dont_write_bytecode = True

import argparse
import base64
import collections
import datetime
import functools
import gzip
import hashlib
import importlib.util
import itertools
import json
import math
import os
from pathlib import Path, PurePosixPath
import posixpath
import re
import signal
import stat
import sysconfig
import time
import zipfile

try:
    import resource
except ImportError:
    resource = None


START = time.monotonic()
MAX_SECONDS = 60
MAX_FILE_BYTES = 64 * 1024 * 1024
MAX_BUNDLE_BYTES = 256 * 1024 * 1024
MAX_MEMBERS = 4096
ORDER = [
    "arbiter__preferred", "arbiter__trivial_1", "lift__preferred",
    "lift__trivial_1", "minepump__preferred", "minepump__trivial_1",
    "minepump__trivial_2", "traffic_single__preferred", "traffic_single__trivial_1",
    "traffic_updated__preferred", "traffic_updated__trivial_1",
]
REFUSALS = {"arbiter__preferred", "lift__preferred", "minepump__preferred"}
FLAGS = ("strict_controller_pass", "nonconflicting_pass", "kind_controller_pass")
PROVENANCE_KEYS = {
    "checker_sha256", "source_freeze_sha256", "model_sha256", "result_sha256",
    "controller_sha256", "source_bindings",
}
CODE_PINS = {
    "experiment/seams_research_reframing_20261017/initial_graph_checker/initial_graph_checker.py": "3c465e4253712c6f021920e6a164ef48c63c5bf6cfb3432d17ab95fb5778ebda",
    "experiment/seams_research_reframing_20261017/initial_graph_checker/vendor/bdd_core.py": "f9497519b8a073a29e5748c908cadc804f437080cf12d36558d9e0210462dbac",
    "experiment/seams_research_reframing_20261017/initial_graph_checker/vendor/graph_fairness.py": "3da6d64631bd88ae0bda4ad71ccc37c46f48de233a51dcc843a476e391981d45",
    "experiment/normalized_eleven_preparation_20261021/adapters_r2/common.py": "3460abd02acc56293cdbc06a7829c988779df7026b832f99285a4dcfb54da80a",
    "experiment/normalized_eleven_preparation_20261021/adapters_r2/join.py": "a524d9338826fec48d8f7a9614474dab352b0052e9374fdef11c5aca8404b473",
    "experiment/seams_research_reframing_20261017/corpus_comparison/model_join.py": "86d0ee01bd8f1465dab64d701ef74bd72ae8a74c347321585411abba0d8265ee",
    "experiment/seams_research_reframing_20261017/kind_corpus_rle/semantic_qualification.py": "32a38d5881a1f544b83f4c382ca34e72792dc08dd7804d0b0183d7aafe033c71",
    "experiment/seams_establishment_20261013/k7_controller_independent_preparation/bdd_core.py": "f9497519b8a073a29e5748c908cadc804f437080cf12d36558d9e0210462dbac",
    "experiment/seams_submission_push_20261016/v_restricted_strict/model_identity.py": "3d128f879cdfbf5d731e24b14504b3a1aedba22dfd8bcabdc076b243dc5373c6",
    "experiment/seams_research_reframing_20261017/kind_corpus_rle/decode.py": "6e3b2313c5a48206d91cee4c416ede5ddb6c98539a35a0073e584e780d9227a4",
}


class BudgetExceeded(BaseException):
    """Bypass scientific code's ordinary integrity-error handlers on timeout."""


def need(value, message):
    if not value:
        raise ValueError(message)


def budget():
    if time.monotonic() - START >= MAX_SECONDS:
        raise BudgetExceeded("Whole-consumer wall-clock cap reached")


def timeout_handler(signum, frame):
    raise BudgetExceeded("Whole-consumer time cap reached")


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, "Duplicate JSON key: " + key)
        result[key] = value
    return result


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def relative_name(name):
    need(type(name) is str and name and "\\" not in name, "Relative POSIX member required")
    path = PurePosixPath(name)
    need(not path.is_absolute() and str(path) == name
         and all(part not in (".", "..") for part in path.parts), "Unsafe relative member")
    return path


def member(root, name):
    path = root
    for part in relative_name(name).parts:
        path = path / part
        need(not path.is_symlink(), "Symlink in member: " + name)
    need(path.resolve().is_relative_to(root), "Member escapes root")
    return path


def pin(path, name=None):
    budget()
    info = path.lstat()
    need(stat.S_ISREG(info.st_mode) and not path.is_symlink(), "Regular non-symlink file required")
    need(info.st_size <= MAX_FILE_BYTES, "File exceeds 64 MiB cap")
    digest = hashlib.sha256()
    count = 0
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            budget()
            count += len(chunk)
            need(count <= MAX_FILE_BYTES, "File grew beyond byte cap")
            digest.update(chunk)
    need(count == info.st_size, "File changed while reading")
    result = {"bytes": count, "sha256": digest.hexdigest()}
    if name is not None:
        result = {"file": name, **result}
    return result


def read_json(path):
    need(path.is_file() and not path.is_symlink() and path.stat().st_size <= MAX_FILE_BYTES,
         "JSON file type or size")
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=unique_object,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Non-finite JSON number")))


def verify_ref(root, ref):
    need(type(ref) is dict and set(ref) >= {"file", "bytes", "sha256"}, "Malformed file pin")
    need(type(ref["bytes"]) is int and 0 <= ref["bytes"] <= MAX_FILE_BYTES
         and type(ref["sha256"]) is str and re.fullmatch(r"[0-9a-f]{64}", ref["sha256"]), "Malformed pin identity")
    path = member(root, ref["file"])
    need(pin(path) == {key: ref[key] for key in ("bytes", "sha256")}, "Pin mismatch: " + ref["file"])
    return path


def verify_manifest(bundle):
    manifest_path = member(bundle, "MANIFEST.json")
    manifest = read_json(manifest_path)
    need(manifest.get("schema") == "normalized-eleven-member-manifest-v1", "Member manifest schema")
    need(manifest.get("self_excluded") == ["MANIFEST.json"], "Explicit manifest self-exclusion required")
    refs = manifest.get("members")
    need(type(refs) is list and 0 < len(refs) <= MAX_MEMBERS, "Member count cap")
    expected = {}
    for ref in refs:
        name = str(relative_name(ref["file"]))
        need(name not in expected and name != "MANIFEST.json", "Duplicate or self member")
        expected[name] = ref
    found = set()
    for folder, directories, files in os.walk(bundle, followlinks=False):
        budget()
        for name in directories:
            path = Path(folder) / name
            need(not path.is_symlink() and path.is_dir(), "Nonregular directory in bundle")
        for name in files:
            path = Path(folder) / name
            need(not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode), "Nonregular bundle member")
            found.add(path.relative_to(bundle).as_posix())
    need(found == set(expected) | {"MANIFEST.json"}, "Complete member closure mismatch")
    total = 0
    for name, ref in expected.items():
        verify_ref(bundle, ref)
        total += ref["bytes"]
        need(total <= MAX_BUNDLE_BYTES, "Bundle exceeds 256 MiB cap")
    return expected, {"manifest": pin(manifest_path, "MANIFEST.json"),
                      "members": len(expected), "member_bytes": total,
                      "closure_complete": True, "self_excluded": ["MANIFEST.json"]}


def verify_metadata(bundle, members):
    need("CONSUMER.json" in members and "consumer/check_saved.py" in members, "Missing consumer members")
    need(Path(__file__).resolve() == bundle / "consumer/check_saved.py", "Run the wrapper from this exact bundle")
    consumer = read_json(verify_ref(bundle, members["CONSUMER.json"]))
    need(consumer.get("schema") == "normalized-eleven-public-saved-consumer-manifest-v1", "Consumer schema")
    need(consumer.get("member_manifest") == "MANIFEST.json", "Member manifest binding")
    need(consumer.get("fixed_order") == ORDER and consumer.get("denominator") == 11, "Exact eleven roster")
    need(consumer.get("producer_reexecution") is False and consumer.get("independent_source_compiler") is False
         and consumer.get("graph_judge_implementations") == 1, "Consumer scope changed")
    source_ref = consumer["source_binding_manifest"]
    need(source_ref == members.get("SOURCE_BINDINGS.json"), "Source manifest/member pin mismatch")
    sources = read_json(verify_ref(bundle, source_ref))
    need(sources.get("schema") == "normalized-eleven-public-source-bindings-v1"
         and sources.get("fixed_order") == ORDER and sources.get("denominator") == 11
         and sources.get("source_bytes_distributed") is False, "Source roster scope")
    need([row["id"] for row in consumer["rows"]] == ORDER
         and [row["id"] for row in sources["rows"]] == ORDER, "Exact row order")
    recipe_ref = sources["source_recipe"]
    need(recipe_ref == members.get(recipe_ref["file"]), "Recipe/member binding")
    recipe = read_json(verify_ref(bundle, recipe_ref))
    need(recipe.get("schema") == "paper-source-fetch-v1", "Source recipe schema")
    listings = {row["id"]: row for row in recipe["listings"]}
    need(len(listings) == len(recipe["listings"]), "Duplicate recipe listing")
    code = consumer["code_files"]
    expected_code = {"code/" + name: digest for name, digest in CODE_PINS.items()}
    need(type(code) is list and len(code) == 10 and {ref["file"] for ref in code} == set(expected_code), "Exact ten consumer modules")
    for ref in code:
        need(ref == members.get(ref["file"]) and ref["sha256"] == expected_code[ref["file"]], "Code/member/original pin mismatch")
        verify_ref(bundle, ref)
    expected_entrypoints = {
        "graph": "code/experiment/seams_research_reframing_20261017/initial_graph_checker/initial_graph_checker.py",
        "join": "code/experiment/normalized_eleven_preparation_20261021/adapters_r2/join.py",
        "decoder": "code/experiment/seams_research_reframing_20261017/kind_corpus_rle/decode.py",
    }
    need(consumer["code"] == expected_entrypoints, "Consumer entrypoints changed")
    for row, source in zip(consumer["rows"], sources["rows"]):
        ident = row["id"]
        need(row["pipeline"] == "normalized_kind" and row["source"] == source["source"], "Source/row binding")
        need(row["source"]["file"] == "sources/" + ident + ".spectra", "Source filename")
        need(row["source"]["file"] not in members, "Paper source bytes must be supplied separately")
        listing = listings[ident]
        for key in ("listing_id", "source_url", "raw", "reconstructed", "diff"):
            need(source[key] == listing[key], "Recipe source identity: " + key)
        need(source["reconstruction_operations"] == listing["edits"], "Recipe operations")
        need(source["reconstructed"] == {key: row["source"][key] for key in ("bytes", "sha256")}, "Reconstructed source pin")
        arm = "data/runs/" + ident + "/normalized_kind"
        need(row["arm"] == arm and row["historical_certificate"] == arm + "/certificate.json", "Saved arm paths")
        need(row["capture"] == {"stream": arm + "/stdout.txt.gz", "receipt": arm + "/RLE_STDOUT_RECEIPT.json", "stderr": arm + "/stderr.txt"}, "Capture paths")
        for label, region in (("V", "V.bdd"), ("K", "final_region.bdd")):
            need(row["comparators"][label] == {"directory": "data/comparators/" + ident + "/" + label, "region": region}, "Comparator paths")
        refusal = ident in REFUSALS
        need(row["expected_status"] == ("VALID_SEMANTIC_REFUSAL" if refusal else "VALID_EXPORT_CERTIFICATE")
             and row["expected_controller_flags"] == dict.fromkeys(FLAGS, None if refusal else True)
             and row["expected_original_initializer_verdict"] is (not refusal), "Fixed expected results")
    return consumer, sources


def install_limits():
    need(hasattr(signal, "setitimer") and hasattr(signal, "ITIMER_REAL"), "A POSIX wall-clock timer is required")
    signal.signal(signal.SIGALRM, timeout_handler)
    signal.setitimer(signal.ITIMER_REAL, max(0.001, MAX_SECONDS - (time.monotonic() - START)))
    applied = {"wall_seconds": MAX_SECONDS, "wall_timer": "SIGALRM/ITIMER_REAL",
               "file_bytes": MAX_FILE_BYTES, "bundle_bytes": MAX_BUNDLE_BYTES}
    if resource is not None:
        if hasattr(signal, "SIGXCPU"):
            signal.signal(signal.SIGXCPU, timeout_handler)
        for name, cap in (("RLIMIT_CPU", MAX_SECONDS), ("RLIMIT_FSIZE", MAX_FILE_BYTES),
                          ("RLIMIT_AS", 2 * 1024 ** 3), ("RLIMIT_CORE", 0)):
            if not hasattr(resource, name):
                continue
            key = getattr(resource, name)
            try:
                soft, hard = resource.getrlimit(key)
                value = cap if soft == resource.RLIM_INFINITY else min(soft, cap)
                if hard != resource.RLIM_INFINITY:
                    value = min(value, hard)
                resource.setrlimit(key, (value, hard))
                applied[name] = value
            except (OSError, ValueError):
                applied[name] = "unavailable; wall and explicit byte caps remain"
    return applied


def install_guard(bundle, source_root, work):
    # Defense in depth for these pinned modules, not a hostile-code sandbox.
    stdlib = {Path(sysconfig.get_path(key)).resolve() for key in ("stdlib", "platstdlib")}
    code = {bundle / ("code/" + name) for name in CODE_PINS}
    allowed_exec = code | {Path(__file__).resolve()}

    def standard(path):
        return any(path.is_relative_to(root) for root in stdlib) and not ({"site-packages", "dist-packages"} & set(path.parts))

    def resolved(value):
        need(not isinstance(value, int), "Descriptor-based filesystem operation blocked")
        return Path(os.fsdecode(value)).resolve()

    def writable(value):
        need(resolved(value).is_relative_to(work), "Write outside new work directory blocked")

    def hook(event, args):
        if event.startswith(("socket.", "subprocess.", "ctypes.")) or event in {
            "os.system", "os.fork", "os.forkpty", "os.posix_spawn", "os.posix_spawnp",
            "os.exec", "os.spawn", "pty.spawn", "os.startfile", "os.startfile/2",
        }:
            raise RuntimeError("Network/process/native-library operation blocked: " + event)
        if event == "open":
            path, mode, flags = args
            writes = bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND))
            if writes:
                writable(path)
            elif not isinstance(path, int):
                path = resolved(path)
                need(any(path.is_relative_to(root) for root in (bundle, source_root, work)) or standard(path), "Read outside verified inputs/runtime blocked")
        elif event in {"os.remove", "os.rmdir", "os.mkdir", "os.chmod", "os.chown", "os.utime", "os.truncate"}:
            writable(args[0])
        elif event in {"os.rename", "os.replace"}:
            writable(args[0]); writable(args[1])
        elif event in {"os.symlink", "os.link"}:
            raise RuntimeError("Filesystem links blocked")
        elif event == "os.chdir":
            need(resolved(args[0]) == work, "Working directory must be the new work root")
        elif event == "exec":
            filename = args[0].co_filename
            if filename.startswith("<frozen "):
                return
            need(not filename.startswith("<"), "Unbound dynamic code execution blocked")
            path = resolved(filename)
            need(path in allowed_exec or standard(path), "Imported code outside exact consumer/runtime blocked")
        elif event == "import" and len(args) > 1 and args[1] is not None:
            path = resolved(args[1])
            need(path in code or standard(path), "Import origin outside exact consumer/runtime blocked")

    need("common" not in sys.modules and "bdd_core" not in sys.modules, "Use a fresh Python process")
    adapter = bundle / "code/experiment/normalized_eleven_preparation_20261021/adapters_r2"
    sys.path[:] = [str(adapter)] + sorted({str(path) for root in stdlib for path in (root, root / "lib-dynload") if path.is_dir()})
    sys.addaudithook(hook)
    return {"writes": "new work directory only", "network_process_and_ctypes": "blocked by audit hook",
            "code_origins": "ten pinned modules and Python standard library",
            "scope": "Defense in depth for pinned code; not a hostile-code sandbox"}


def copy_verified(source, destination, ref):
    need(not destination.exists(), "Copy destination already exists")
    need(pin(source) == {key: ref[key] for key in ("bytes", "sha256")}, "Input copy source pin")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with source.open("rb") as src, destination.open("xb") as dst:
        for chunk in iter(lambda: src.read(1024 * 1024), b""):
            budget()
            dst.write(chunk)
    need(pin(destination) == {key: ref[key] for key in ("bytes", "sha256")}, "Copied input pin")


def reject_imports(path):
    # Exact lexical rule used by the original eleven-source binding adapter.
    tokens = re.findall(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[A-Za-z_]\w*|\S', path.read_text(encoding="utf-8"), re.S)
    need("import" not in [token for token in tokens if not token.startswith(("/*", "//"))], "Unexpected source import")


def stage_inputs(bundle, source_root, work, consumer, members):
    copied = []
    for row in consumer["rows"]:
        ref = row["source"]
        external = member(source_root, row["id"] + ".spectra")
        need(pin(external) == {key: ref[key] for key in ("bytes", "sha256")}, "External reconstructed source pin: " + row["id"])
        reject_imports(external)
        copy_verified(external, member(work, ref["file"]), ref)
        copied.append(ref)
    prefixes = tuple(directory + "/" for row in consumer["rows"] for directory in
                     [row["arm"], row["comparators"]["V"]["directory"], row["comparators"]["K"]["directory"]])
    for name, ref in members.items():
        if name.startswith(prefixes):
            copy_verified(member(bundle, name), member(work, name), ref)
            copied.append(ref)
    for row in consumer["rows"]:
        for folder in (row["arm"], row["comparators"]["V"]["directory"], row["comparators"]["K"]["directory"]):
            model = read_json(member(work, folder + "/model.json"))
            case, variant = row["id"].split("__")
            need((model["fixture_id"], model["case_id"], model["variant"]) == (row["id"], case, variant), "Copied model identity")
            need(model["input"]["path"] == row["source"]["file"] and all(model["input"][key] == row["source"][key] for key in ("bytes", "sha256")), "Copied model/source binding")
    return copied


def preflight_saved_bindings(work, consumer):
    """Check identity and transitive pins only; no BDD or graph calculation."""
    checks = []

    def local_ref(folder, ref):
        need(PurePosixPath(ref["file"]).name == ref["file"], "Saved pin must be a basename")
        return verify_ref(folder, ref)

    for row in consumer["rows"]:
        ident = row["id"]
        case, variant = ident.split("__")
        identity = (ident, case, variant)
        source = member(work, row["source"]["file"])
        for folder in (row["arm"], row["comparators"]["V"]["directory"], row["comparators"]["K"]["directory"]):
            directory = member(work, folder)
            model = read_json(directory / "model.json")
            need(model["schema"] == "k7-native-model-export-v1", "Saved model schema")
            need(tuple(model[key] for key in ("fixture_id", "case_id", "variant")) == identity, "Model fixture/case/variant")
            need(model["input"]["path"] == row["source"]["file"]
                 and member(work, model["input"]["path"]).samefile(source), "Model must name the exact copied source")
            need(all(model["input"][key] == row["source"][key] for key in ("bytes", "sha256")), "Model source identity")
            for ref in model["original_bdds"].values():
                local_ref(directory, ref)
            for refs in model["original_justices"].values():
                for ref in refs:
                    local_ref(directory, ref)
        arm = member(work, row["arm"])
        result = read_json(arm / "result.json")
        need(tuple(result[key] for key in ("fixture_id", "case_id", "variant")) == identity
             and result["pipeline"] == "normalized_kind" and result["solver"] == "4fp", "Result identity/pipeline")
        need(result["schema"] == "k7-native-admission-production-v1"
             and result["input"] == row["source"]["file"] and result["input_sha256"] == row["source"]["sha256"], "Result source binding")
        need(result["model_export"]["file"] == "model.json", "Current model export filename")
        current_model = local_ref(arm, result["model_export"])
        for key in ("V", "final_region"):
            local_ref(arm, result[key])
        if ident in REFUSALS:
            need(result["controller_export"] is None, "Refusal must have no exported controller")
        else:
            need(result["controller_export"]["file"] == "controller.json", "Current controller filename")
            graph = read_json(local_ref(arm, result["controller_export"]))
            need(tuple(graph[key] for key in ("fixture_id", "case_id", "variant")) == identity
                 and graph["pipeline"] == "normalized_kind" and graph["solver"] == "4fp", "Controller identity/pipeline")
            need(graph["model_sha256"] == pin(current_model)["sha256"], "Current controller/model hash binding")
        for label in ("V", "K"):
            comparator = row["comparators"][label]
            need(member(work, comparator["directory"] + "/" + comparator["region"]).is_file(), "Missing comparator region")
        checks.append({"id": ident, "status": "PASS_INPUT_BINDINGS", "models": 3,
                       "source_identity_and_location": True, "original_predicate_pins": True,
                       "current_result_model_controller_pins": True})
    return {"schema": "normalized-eleven-public-preflight-v1", "status": "PASS_PREFLIGHT_ONLY",
            "scientific_modules_imported": 0, "scientific_checks_executed": 0,
            "rows": checks, "scope": "Input closure, source identity, metadata and current derived byte/hash bindings only"}


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    need(Path(module.__file__).resolve() == path, "Loaded module origin")
    return module


def relative_output(value, work, location=()):
    # These are JSON pointers emitted by the unchanged diagnostic comparator,
    # not filesystem locations. Only this exact output context is exempt.
    if (len(location) == 3 and location[0] == "diagnostic_identity_differences"
            and type(location[1]) is int and location[2] == "path"):
        need(type(value) is str and re.fullmatch(
            r"/source_inventory/parsed/(ENV|SYS|AUX)/patterns/[0-9]+/(pattern|text)", value),
            "Unexpected diagnostic JSON pointer")
        return value
    if isinstance(value, dict):
        return {key: relative_output(item, work, location + (key,)) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [relative_output(item, work, location + (index,)) for index, item in enumerate(value)]
    if isinstance(value, Path):
        value = str(value)
    if isinstance(value, str) and Path(value).is_absolute():
        path = Path(value).resolve()
        need(path.is_relative_to(work), "Generated output contains path outside work")
        return path.relative_to(work).as_posix()
    return value


def write_json(work, name, value, replace=False):
    path = member(work, name)
    path.parent.mkdir(parents=True, exist_ok=True)
    need(replace or not path.exists(), "No output overwrite")
    raw = (json.dumps(relative_output(value, work), ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")
    need(len(raw) <= MAX_FILE_BYTES, "Output JSON byte cap")
    temporary = path.with_name(path.name + ".partial")
    with temporary.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)
    return name


def semantic_certificate(certificate):
    return {key: value for key, value in certificate.items() if key not in PROVENANCE_KEYS}


def inspect_certificate(row, certificate, historical):
    actual = canonical(semantic_certificate(certificate))
    expected = canonical(semantic_certificate(historical))
    checks = {
        "all_semantic_fields_equal": actual == expected,
        "status": certificate.get("status") == row["expected_status"],
        "controller_flags": all(certificate.get(key) is row["expected_controller_flags"][key] for key in FLAGS),
        "model_audit": certificate.get("original_model_audit", {}).get("status") == "PASS" and certificate.get("model_validated") is True,
        "normalization_audit": certificate.get("normalization_audit", {}).get("status") == "PASS" and certificate.get("normalization_audit", {}).get("source_initializers_preserved") is True,
        "original_initializer": certificate.get("initial_quantification_audit", {}).get("status") == "PASS"
            and certificate.get("initial_quantification_audit", {}).get("verdict") is row["expected_original_initializer_verdict"]
            and certificate.get("initial_quantification_audit", {}).get("quantifier") == "forall_ENV_exists_SYS_AUX",
        "failure_stage_clear": certificate.get("failure_stage") is None,
    }
    if row["id"] in REFUSALS:
        checks["independent_empty_V_refusal"] = certificate.get("refusal_kind") == "EMPTY_V_INDEPENDENTLY_CHECKED" and certificate.get("normalization_audit", {}).get("V_empty") is True
    else:
        audit = certificate.get("controller_audit", {})
        checks["complete_controller_audit"] = audit.get("structural_safety_coverage_determinism") == "PASS" and all(audit.get(key) is True for key in FLAGS)
    return {"status": "PASS" if all(checks.values()) else "FAIL", "checks": checks,
            "comparison": "Entire canonical semantic JSON; only listed top-level provenance fields omitted",
            "omitted_top_level_fields": sorted(PROVENANCE_KEYS),
            "generated_semantic_sha256": hashlib.sha256(actual).hexdigest(),
            "historical_semantic_sha256": hashlib.sha256(expected).hexdigest()}


def run_checks(bundle, work, consumer, sources, summary):
    checker = load_module("public_saved_initial_graph_checker", member(bundle, consumer["code"]["graph"]))
    join = load_module("public_saved_eleven_join", member(bundle, consumer["code"]["join"]))
    decoder = load_module("public_saved_lossless_decode", member(bundle, consumer["code"]["decoder"]))
    source_rows = {row["id"]: row for row in sources["rows"]}
    source_manifest = consumer["source_binding_manifest"]

    def public_load_profile(ident):
        need(ident in source_rows, "Fixture outside fixed eleven")
        row = source_rows[ident]
        source = verify_ref(work, row["source"])
        reject_imports(source)
        case, variant = ident.split("__")
        return {"fixture_id": ident, "case_id": case, "variant": variant,
                "source": {"path": row["source"]["file"], "bytes": row["source"]["bytes"], "sha256": row["source"]["sha256"]},
                "bindings": {"scope": "exact_eleven_saved_inputs_separately_supplied_sources",
                             "public_source_binding_manifest": source_manifest,
                             "source_recipe": sources["source_recipe"], "external_source_bytes_verified": True,
                             "historical_source_profile_pin": row["historical_profile"],
                             "historical_raw_diff_profile_reexecuted": False,
                             "producer_reexecution": False, "independent_source_compiler": False}}

    # These are the only two changed attributes of the scientific checker.
    checker.load_profile = public_load_profile
    checker.FREEZE_SHA256 = source_manifest["sha256"]
    common = sys.modules["common"]
    need(Path(common.__file__).resolve() == member(bundle, "code/experiment/normalized_eleven_preparation_20261021/adapters_r2/common.py"), "Common module origin")
    for row in consumer["rows"]:
        budget()
        ident = row["id"]
        output = "results/" + ident + "/"
        record = {"id": ident, "status": "INCOMPLETE", "outputs": {}}
        summary["rows"].append(record)
        summary["phase"] = ident + ":graph"
        write_json(work, "CONSUMER_RESULT.json", summary, replace=True)
        arm = member(work, row["arm"])
        summary["scope"]["scientific_checks_executed"] = True
        certificate = checker.check_arm(arm, ident, row["pipeline"])
        record["outputs"]["certificate"] = write_json(work, output + "certificate.json", certificate)
        historical = read_json(member(work, row["historical_certificate"]))
        comparison = inspect_certificate(row, certificate, historical)
        record["outputs"]["certificate_comparison"] = write_json(work, output + "certificate_comparison.json", comparison)
        need(comparison["status"] == "PASS", "Generated certificate or full semantic comparison failed: " + ident)
        record["certificate_status"] = certificate["status"]
        record["original_initializer_verdict"] = certificate["initial_quantification_audit"]["verdict"]
        result = read_json(arm / "result.json")
        model = read_json(arm / "model.json")
        need(result.get("initial_in_region") is row["expected_original_initializer_verdict"], "Saved result initializer verdict")
        summary["phase"] = ident + ":arena"
        for label in ("V", "K"):
            comparator = member(work, row["comparators"][label]["directory"])
            arena_module, arena = join.model_join(comparator, arm)
            record["outputs"]["arena_" + label] = write_json(work, output + "arena_" + label + ".json", arena)
            need(arena["status"] == "EXACT_ORIGINAL_ARENA_MATCH"
                 and arena["typed_metadata_exact"] is True and arena["ordered_justice_lists_preserved"] is True
                 and arena["comparisons"] and all(item["exact_function_equal"] is True for item in arena["comparisons"]), "Original arena mismatch: " + ident + ":" + label)
        summary["phase"] = ident + ":regions"
        manager = arena_module.sem.BDD(model["bdd_variable_count"])
        thetaE = manager.read_native(common.verify(join.native_ref(arm, model["original_bdds"]["thetaE"])).read_bytes())[0]
        thetaS = manager.read_native(common.verify(join.native_ref(arm, model["original_bdds"]["thetaS"])).read_bytes())[0]
        for label, result_key in (("V", "V"), ("K", "final_region")):
            comparator = row["comparators"][label]
            left = common.pin(member(work, comparator["directory"] + "/" + comparator["region"]))
            right = join.native_ref(arm, result[result_key])
            region = join.compare_regions(manager, model, left, right, thetaE, thetaS, result["initial_in_region"])
            record["outputs"]["region_" + label] = write_json(work, output + "region_" + label + ".json", region)
            need(region["status"] == "EXACT_REGION_MATCH" and region["exact_function_equal"] is True and region["witness"] is None, "Full region mismatch: " + ident + ":" + label)
        summary["phase"] = ident + ":capture"
        capture = decoder.verify_stream(member(work, row["capture"]["stream"]))
        receipt = read_json(member(work, row["capture"]["receipt"]))
        capture["receipt_matches"] = all(capture[key] == receipt[key] for key in ("raw_bytes", "raw_sha256", "repeated_lines", "data_records", "cap_reached"))
        capture["stderr"] = pin(member(work, row["capture"]["stderr"]), row["capture"]["stderr"])
        record["outputs"]["capture"] = write_json(work, output + "capture_verification.json", capture)
        need(capture["status"] == "PASS" and capture["cap_reached"] is False
             and capture["all_raw_bytes_recoverable"] is True and capture["receipt_matches"], "Saved capture mismatch: " + ident)
        record["status"] = "PASS"
        write_json(work, output + "ROW_RESULT.json", record)
        write_json(work, "CONSUMER_RESULT.json", summary, replace=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--source-root", required=True, type=Path, help="Directory containing the eleven exact <id>.spectra files")
    parser.add_argument("--work-dir", required=True, type=Path, help="New nonexistent directory; its parent must already exist")
    parser.add_argument("--preflight-only", action="store_true", help="Validate all input and derived pins without importing scientific modules")
    args = parser.parse_args()
    need(sys.version_info >= (3, 10), "Python 3.10 or later required")
    for path in (args.bundle, args.source_root):
        need(path.is_dir() and not path.is_symlink(), "Real input directory required")
    need(not args.work_dir.exists() and not args.work_dir.is_symlink()
         and args.work_dir.parent.is_dir(), "New work directory with existing parent required")
    bundle, source_root, work = args.bundle.resolve(), args.source_root.resolve(), args.work_dir.resolve()
    need(not work.is_relative_to(bundle) and not bundle.is_relative_to(work)
         and not work.is_relative_to(source_root) and not source_root.is_relative_to(work), "Work must be outside bundle and source root")
    summary = {"schema": "normalized-eleven-public-saved-consumer-result-v1", "status": "INCOMPLETE",
               "phase": "integrity", "fixed_order": ORDER, "rows": [],
               "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "runtime": {"python": sys.version, "implementation": sys.implementation.name,
                           "os": dict(zip(("sysname", "nodename", "release", "version", "machine"), os.uname())) if hasattr(os, "uname") else {"platform": sys.platform}},
               "scope": {"producer_reexecution": False, "native_invocations": 0, "network_operations": 0,
                         "scientific_checks_executed": False,
                         "independent_source_compiler": False, "graph_judge_implementations": 1,
                         "fourteen_model_regression_requalified": False,
                         "source_precondition": "Separately supplied exact reconstructed source files",
                         "interpretation": "Rechecks fixed saved inputs; historical process/runtime evidence is not reexecution"}}
    # The host name is unnecessary provenance and may identify a private machine.
    summary["runtime"]["os"].pop("nodename", None)
    summary["controls"] = install_guard(bundle, source_root, work)
    work.mkdir()
    exit_code = 2
    try:
        summary["limits"] = install_limits()
        write_json(work, "CONSUMER_RESULT.json", summary)
        members, integrity = verify_manifest(bundle)
        consumer, sources = verify_metadata(bundle, members)
        summary["integrity"] = integrity
        summary["input_metadata"] = {name: members[name] for name in ("CONSUMER.json", "SOURCE_BINDINGS.json", "consumer/check_saved.py")}
        summary["phase"] = "copy_inputs"
        copied = stage_inputs(bundle, source_root, work, consumer, members)
        summary["copied_inputs"] = {"file": write_json(work, "COPIED_INPUTS.json", {"files": copied}), "count": len(copied)}
        os.chdir(work)
        summary["phase"] = "preflight_bindings"
        preflight = preflight_saved_bindings(work, consumer)
        summary["preflight"] = write_json(work, "PREFLIGHT_RESULT.json", preflight)
        if not args.preflight_only:
            summary["phase"] = "saved_checks"
            run_checks(bundle, work, consumer, sources, summary)
        summary["phase"] = "final_integrity"
        for ref in copied:
            verify_ref(work, ref)
        final_members, final_integrity = verify_manifest(bundle)
        need(final_members == members and final_integrity == integrity, "Bundle changed during consumer")
        budget()
        if args.preflight_only:
            summary.update(status="PASS_PREFLIGHT_ONLY", phase="complete", final_input_integrity=True,
                           counts={"input_rows": 11, "scientific_checks": 0})
        else:
            need(len(summary["rows"]) == 11 and all(row["status"] == "PASS" for row in summary["rows"]), "Incomplete fixed cohort")
            summary["counts"] = {"rows": 11, "export_certificates": sum(row["certificate_status"] == "VALID_EXPORT_CERTIFICATE" for row in summary["rows"]),
                                 "semantic_refusals": sum(row["certificate_status"] == "VALID_SEMANTIC_REFUSAL" for row in summary["rows"]),
                                 "arena_comparisons": 22, "full_region_comparisons": 22, "lossless_captures": 11}
            need(summary["counts"]["export_certificates"] == 8 and summary["counts"]["semantic_refusals"] == 3, "Fixed outcomes")
            summary.update(status="PASS", phase="complete", final_input_integrity=True)
        exit_code = 0
    except (Exception, BudgetExceeded, KeyboardInterrupt) as error:
        summary["status"] = "RESOURCE_LIMIT" if isinstance(error, (BudgetExceeded, MemoryError)) else "FAIL_OR_INCOMPLETE"
        detail = type(error).__name__ + ": " + str(error)
        for root, replacement in ((work, "<work>"), (bundle, "<bundle>"), (source_root, "<sources>")):
            detail = detail.replace(str(root), replacement)
        summary["error"] = detail
        if summary["rows"] and summary["rows"][-1]["status"] != "PASS":
            summary["rows"][-1]["error"] = detail
        summary["completed_rows"] = sum(row["status"] == "PASS" for row in summary["rows"])
    finally:
        if hasattr(signal, "setitimer"):
            signal.setitimer(signal.ITIMER_REAL, 0)
        summary["elapsed_seconds"] = time.monotonic() - START
        summary["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        # An interrupted temporary file is retained; use a distinct recovery file
        # instead of deleting it or mistaking it for a completed observation.
        final_name = "CONSUMER_RESULT.json" if not (work / "CONSUMER_RESULT.json.partial").exists() else "CONSUMER_FAILURE_RECOVERY.json"
        try:
            write_json(work, final_name, summary, replace=True)
        except Exception as error:
            print("Could not finish consumer receipt: " + type(error).__name__, file=sys.stderr)
            exit_code = 2
        print(json.dumps({"status": summary["status"], "result": final_name,
                          "completed_rows": sum(row["status"] == "PASS" for row in summary["rows"]),
                          "elapsed_seconds": summary["elapsed_seconds"]}))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
