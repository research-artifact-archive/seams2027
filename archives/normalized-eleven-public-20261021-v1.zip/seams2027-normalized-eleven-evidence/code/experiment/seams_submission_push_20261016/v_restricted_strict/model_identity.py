"""Allow only Java Pattern object's unstable diagnostic identity suffix.

No formula, AST, parsed actual argument, BDD, field, encoding, order, source pin,
justice, transition, replay or entry is excluded from exact equality.
"""
import re
from common import need
PATTERN=re.compile(r'tau\.smlab\.syntech\.gameinput\.model\.Pattern@[0-9a-f]+')
ALLOWED_PATH=re.compile(r'/source_inventory/parsed/(ENV|SYS|AUX)/patterns/[0-9]+/(pattern|text)')
def compare_models(a,b):
 differences=[]
 def visit(x,y,path):
  need(type(x)==type(y),'Model type differs: '+path)
  if isinstance(x,dict):
   need(x.keys()==y.keys(),'Model keys differ: '+path)
   for k in x:visit(x[k],y[k],path+'/'+k)
  elif isinstance(x,list):
   need(len(x)==len(y),'Model list length differs: '+path)
   for i,(u,v) in enumerate(zip(x,y)):visit(u,v,path+'/'+str(i))
  elif x!=y:
   need(isinstance(x,str) and ALLOWED_PATH.fullmatch(path) and PATTERN.search(x) and PATTERN.search(y) and PATTERN.sub('tau.smlab.syntech.gameinput.model.Pattern@OBJECT_ID',x)==PATTERN.sub('tau.smlab.syntech.gameinput.model.Pattern@OBJECT_ID',y),'Model non-diagnostic content differs: '+path)
   differences.append({'path':path,'new':x,'prior':y,'allowed_change':'Java Pattern object diagnostic identity only'})
 visit(a,b,'')
 return differences
