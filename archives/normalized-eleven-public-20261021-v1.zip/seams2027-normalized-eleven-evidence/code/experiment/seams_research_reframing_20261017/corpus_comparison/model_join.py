"""Join separately emitted original arenas by exact Boolean function equality.

This does not certify the Spectra compiler or infer controller existence. It
prevents combining two source-labelled results without checking their arenas.
"""
from pathlib import Path
import argparse,hashlib,importlib.util,json,sys,time
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
E=HERE.parent
spec=importlib.util.spec_from_file_location('corpus_semantic_qualification',E/'kind_corpus_rle/semantic_qualification.py')
sem=importlib.util.module_from_spec(spec);spec.loader.exec_module(sem)

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def pin(path):
    p=Path(path).resolve();return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def require(value,message):
    if not value:raise ValueError(message)
def read(path):return json.loads(Path(path).read_text())

def independent_binding_checks(model_pin,result_pin,proof,proof_pin,process):
    """The enclosing process receipt is authoritative over a child result.

    A child can write PASS and still time out or fail during shutdown. Keep
    each condition visible rather than treating the child's status as enough.
    """
    independent_pins=proof.get('input_pins',[])
    return {
        'child_status_pass':proof.get('status')=='PASS',
        'native_model_bound':model_pin in independent_pins,
        'native_result_bound':result_pin in independent_pins,
        'process_status_pass':process.get('status')=='PASS',
        'process_no_hard_timeout':process.get('hard_timeout') is False,
        'process_exit_zero':process.get('process_exit_code')==0,
        'process_binds_exact_child':proof_pin is not None and process.get('child_result')==proof_pin,
    }

def original_model_join(left_dir,right_dir):
    left_dir,right_dir=Path(left_dir),Path(right_dir)
    lp,rp=left_dir/'model.json',right_dir/'model.json'
    pins=[pin(lp),pin(rp)];left,right=read(lp),read(rp)
    for key in ['schema','fields','public_fields','all_current_bits','all_next_bits','bdd_variable_count','bdd_variable_order']:
        require(left[key]==right[key],'Original model metadata differs: '+key)
    require(left['input']['sha256']==right['input']['sha256'] and left['input']['bytes']==right['input']['bytes'], 'Original source differs')
    require(sem.scrub_pattern_identity(left['source_inventory'])==sem.scrub_pattern_identity(right['source_inventory']),
            'Parsed/translated source inventory differs')
    require(set(left['original_bdds'])==set(right['original_bdds']), 'Original predicate roster differs')
    require(set(left['original_justices'])==set(right['original_justices']), 'Original justice owner roster differs')
    b=sem.BDD(left['bdd_variable_count']);pairs=[]
    for key in sorted(left['original_bdds']):pairs.append((key,left['original_bdds'][key],right['original_bdds'][key]))
    for owner in sorted(left['original_justices']):
        a,z=left['original_justices'][owner],right['original_justices'][owner]
        require(len(a)==len(z),'Original ordered justice length differs: '+owner)
        pairs.extend((owner+'_justice_'+str(i),x,y) for i,(x,y) in enumerate(zip(a,z)))
    rows=[]
    for key,x,y in pairs:
        loaded=[]
        for directory,ref in [(left_dir,x),(right_dir,y)]:
            require(Path(ref['file']).name==ref['file'],'BDD basename')
            path=directory/ref['file'];p=pin(path)
            require(p['sha256']==ref['sha256'] and p['bytes']==ref['bytes'],'BDD byte pin mismatch')
            pins.append(p);u,_=b.read_native(path.read_bytes());loaded.append(u)
        rows.append({'predicate':key,'exact_function_equal':loaded[0]==loaded[1]})
    require(pins==[pin(p['path']) for p in pins],'Join input changed')
    return {'status':'EXACT_ORIGINAL_ARENA_MATCH' if all(r['exact_function_equal'] for r in rows) else 'ORIGINAL_ARENA_FUNCTION_MISMATCH',
            'source_sha256':left['input']['sha256'],'typed_metadata_exact':True,'ordered_justice_lists_preserved':True,
            'comparisons':rows,'input_pins':pins,'method':'Canonical ROBDD equality in common saved bit encoding; no independent source compiler.'}

def phase2_case(ident,pipeline):
    first=E/'kind_corpus_rle/runs'/ident
    second=E/'initial_graph_native/runs'/ident/pipeline
    record={'id':ident,'pipeline':pipeline,'status':'UNKNOWN_NOT_JOINED'}
    if not (second/'OUTCOME.json').exists():return record
    outcome=read(second/'OUTCOME.json');record['native_outcome']=outcome['outcome']
    record['outcome_pin']=pin(second/'OUTCOME.json')
    if not (second/'model.json').exists():return record
    try:
        record['original_arena']=original_model_join(first,second)
        if record['original_arena']['status']!='EXACT_ORIGINAL_ARENA_MATCH':
            record['status']='ORIGINAL_ARENA_FUNCTION_MISMATCH';return record
        record['status']='EXACT_ORIGINAL_ARENA_MATCH'
        # Absence/incompleteness of phase1 mathematics does not invalidate a
        # separately certified emitted graph. Keep region evidence separate.
        if not (first/'result.json').exists() or not (second/'result.json').exists():return record
        a,z=read(first/'result.json'),read(second/'result.json')
        region='WV' if pipeline=='v_restricted_strict' else 'K'
        if a.get('regions_complete') is not True or region not in a or 'final_region' not in z:return record
        b=sem.BDD(read(first/'model.json')['bdd_variable_count'])
        roots=[];region_pins=[]
        for directory,ref in [(first,a[region]),(second,z['final_region'])]:
            require(Path(ref['file']).name==ref['file'],'Region basename')
            path=directory/ref['file'];p=pin(path)
            require(p['sha256']==ref['sha256'] and p['bytes']==ref['bytes'],'Region byte pin mismatch')
            roots.append(b.read_native(path.read_bytes())[0]);region_pins.append(p)
        independent=E/'kind_corpus_symbolic_independent/runs/v2'/ident/'RESULT.json'
        proof=read(independent) if independent.exists() else {}
        process_path=independent.with_name('PROCESS_RESULT.json')
        process=read(process_path) if process_path.exists() else {}
        proof_pin=pin(independent) if independent.exists() else None
        process_pin=pin(process_path) if process_path.exists() else None
        # Verify that the independent calculation actually bound the current
        # native result and model, and that its enclosing process succeeded.
        checks=independent_binding_checks(pin(first/'model.json'),pin(first/'result.json'),proof,proof_pin,process)
        bound=all(checks.values())
        record['region_comparison']={'phase1_region':region,'phase2_region':'final_region',
            'exact_function_equal':roots[0]==roots[1],'phase1_independently_certified':bound,
            'independent_authority_checks':checks,
            'independent_certificate':proof_pin,'independent_process_receipt':process_pin,
            'region_pins':region_pins,'result_pins':[pin(first/'result.json'),pin(second/'result.json')]}
        require(region_pins==[pin(p['path']) for p in region_pins],'Region input changed')
        require(all(p==pin(p['path']) for p in [proof_pin,process_pin] if p),'Independent evidence changed')
    except Exception as error:record.update(status='UNKNOWN_JOIN_INTEGRITY_OR_RESOURCE',error=repr(error))
    return record

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True);args=parser.parse_args()
    output=Path(args.output).resolve();require(output.parent==HERE.resolve() and not output.exists(),'New comparison output required')
    receipt=E/'initial_graph_native/RUN_RECEIPT.json';r=read(receipt)
    require(not r['global_stop'] and not r['pin_errors'],'Phase2 run integrity')
    selection=read(E/'initial_graph_native/SELECTION.json')
    rows=[phase2_case(row['id'],pipeline) for row in selection['rows'] if row['eligible'] for pipeline in ['v_restricted_strict','normalized_kind']]
    result={'schema':'all-eligible-original-arena-join-v1','native_runs':0,'rows':rows,'source_roster_total':425,
            'phase2_selection':pin(E/'initial_graph_native/SELECTION.json'),'phase2_receipt':pin(receipt),
            'joiner':pin(__file__),'meaning':'Source and exact original predicates are joined before comparing independent regions to emitted graphs. Unknowns remain separate.'}
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'rows':len(rows),'output':str(output)}))

if __name__=='__main__':main()
