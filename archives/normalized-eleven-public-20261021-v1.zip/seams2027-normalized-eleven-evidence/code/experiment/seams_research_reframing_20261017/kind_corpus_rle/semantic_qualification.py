"""Exact saved-function comparison for transport qualification; no native calls."""
from pathlib import Path
import hashlib,json,re,sys
CORE=Path(__file__).resolve().parents[2]/'seams_establishment_20261013/k7_controller_independent_preparation'
sys.path.insert(0,str(CORE))
from bdd_core import BDD

def read(p):return json.loads(Path(p).read_text())
def pin(p):
    p=Path(p).resolve()
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def require(x,msg):
    if not x:raise ValueError(msg)

def scrub_pattern_identity(x,path=()):
    # Only diagnostic Java Pattern.toString identity. AST and actual parameters
    # remain exact. This is not a generic address/text normalization.
    if isinstance(x,dict):return {k:scrub_pattern_identity(v,path+(k,)) for k,v in x.items()}
    if isinstance(x,list):return [scrub_pattern_identity(v,path+(str(i),)) for i,v in enumerate(x)]
    if isinstance(x,str) and 'patterns' in path and path[-1] in ('pattern','text'):
        return re.sub(r'tau\.smlab\.syntech\.gameinput\.model\.Pattern@[0-9a-f]+',
                      'tau.smlab.syntech.gameinput.model.Pattern@<JVM-object-identity>',x)
    return x

def compare(before,after):
    before,after=Path(before),Path(after)
    a,b=read(before/'result.json'),read(after/'result.json')
    require(a['status']==b['status']=='COMPLETE_CORPUS_REGION_PROBE','producer completion')
    keys=['counts','primary_counts','well_separation','initial_ENV_empty','initial_joint_empty',
          'W_original_initial_quantified','V_original_initial_quantified',
          'WV_original_initial_quantified','K_original_initial_quantified']
    require(all(a.get(k)==b.get(k) for k in keys),'semantic result fields differ')
    ma,mb=read(before/'model.json'),read(after/'model.json')
    model_keys=['fixture_id','case_id','variant','schema','fields','public_fields',
                'all_current_bits','all_next_bits','bdd_variable_count','bdd_variable_order']
    require(all(ma[k]==mb[k] for k in model_keys),'typed schema differs')
    require(ma['input']['sha256']==mb['input']['sha256'],'source differs')
    require(scrub_pattern_identity(ma['source_inventory'])==scrub_pattern_identity(mb['source_inventory']),
            'parsed/translated AST or behavior inventory differs beyond Pattern object identity')
    require({k:[v['file'] for v in vs] for k,vs in ma['original_justices'].items()}==
            {k:[v['file'] for v in vs] for k,vs in mb['original_justices'].items()},'justice roster/order differs')
    names=sorted(p.name for p in before.glob('*.bdd'))
    require(names==sorted(p.name for p in after.glob('*.bdd')),'saved BDD roster differs')
    manager=BDD(ma['bdd_variable_count']);rows=[]
    for name in names:
        p,q=before/name,after/name
        u,_=manager.read_native(p.read_bytes());v,_=manager.read_native(q.read_bytes())
        require(u==v,'BDD function differs: '+name)
        rows.append({'file':name,'byte_identical':p.read_bytes()==q.read_bytes(),
                     'exact_function_equal':True,'before':pin(p),'after':pin(q)})
    # Nontrivial inequality control on an actual nonconstant imported function.
    nonconstant=next((manager.read_native((before/n).read_bytes())[0] for n in names
                      if manager.read_native((before/n).read_bytes())[0] not in (0,1)),None)
    require(nonconstant is not None and nonconstant!=manager.neg(nonconstant),'inequality control')
    return {'id':ma['fixture_id'],'status':'PASS','comparison':'independent canonical ROBDD exact root identity',
            'all_saved_bdds_logically_equal':True,'all_saved_bdds_byte_identical':all(r['byte_identical'] for r in rows),
            'bdd_file_count':len(rows),'semantic_fields_exact':keys,'model_fields_exact':model_keys,
            'diagnostic_exception':'Java Pattern object identity strings only, within parsed patterns/pattern or text',
            'negative_control':'an actual nonconstant BDD and its complement differ',
            'bdd_comparisons':rows,'checker_source':pin(CORE/'bdd_core.py'),
            'before_result':pin(before/'result.json'),'after_result':pin(after/'result.json')}
