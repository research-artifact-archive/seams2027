from pathlib import Path
import base64, gzip, hashlib, json

def verify_stream(path, expected=None):
    path=Path(path);opener=gzip.open if path.suffix=='.gz' else open
    digest=hashlib.sha256();n=0;repeats=0;records=0;end=None
    with opener(path,'rt',encoding='ascii') as f:
        for line in f:
            if end is not None:raise ValueError('data after final record')
            x=json.loads(line)
            if x['kind']=='end':end=x;continue
            data=base64.b64decode(x['data'],validate=True)
            count=1 if x['kind']=='bytes' else x['count'] if x['kind']=='repeat' else None
            if type(count) is not int or not 0<count<=1000000:raise ValueError('bad repeat count')
            if x['kind']=='repeat':
                if data!=b'lookup, class net.sf.javabdd.JTLVJavaFactory$BddCache\n':raise ValueError('unexpected repeated line')
                repeats+=count
            # Bound auxiliary memory while verifying the digest of every byte.
            batch=max(1,min(count,1048576//max(1,len(data))))
            piece=data*batch
            q,r=divmod(count,batch)
            for _ in range(q):digest.update(piece)
            if r:digest.update(data*r)
            n+=len(data)*count;records+=1
            if n>8*1024**3:raise ValueError('decoded cap exceeded')
    if end is None:raise ValueError('missing final record')
    if end['raw_bytes']!=n or end['raw_sha256']!=digest.hexdigest():raise ValueError('raw digest or byte count mismatch')
    if end['repeated_lines']!=repeats or end['data_records']!=records:raise ValueError('record count mismatch')
    if expected is not None:
        raw=Path(expected).read_bytes()
        if len(raw)!=n or hashlib.sha256(raw).hexdigest()!=digest.hexdigest():raise ValueError('expected raw bytes mismatch')
    return {'status':'PASS','raw_bytes':n,'raw_sha256':digest.hexdigest(),'repeated_lines':repeats,'data_records':records,'cap_reached':end['cap_reached'],'all_raw_bytes_recoverable':True}

if __name__=='__main__':
    import sys
    print(json.dumps(verify_stream(sys.argv[1],sys.argv[2] if len(sys.argv)>2 else None)))
