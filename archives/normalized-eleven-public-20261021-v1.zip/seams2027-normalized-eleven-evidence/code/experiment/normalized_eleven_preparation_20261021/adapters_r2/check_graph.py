"""Production original-initializer certificate; no native solver invocation."""
import sys
import json
from common import frozen_inputs, owned_arm, PIPELINE, need, read, pin
from source_binding import checker


def main():
    need(len(sys.argv) == 3, 'Usage: check_graph.py exact_arm fixture_id')
    frozen_inputs()
    arm = owned_arm(sys.argv[1], sys.argv[2])
    joined = read(arm / 'MODEL_JOIN.json')
    need(joined['id'] == sys.argv[2] and joined['pipeline'] == PIPELINE, 'Join identity')
    need(joined['status'] in ('EXACT_ORIGINAL_ARENA_MATCH', 'EXACT_ORIGINAL_ARENA_AND_REGIONS_MATCH', 'SAME_MODEL_REGION_MISMATCH')
         and joined['stop_continuation'] is False, 'Qualified original arena required before graph audit')
    need(joined['original_arena']['status'] == joined['saved_K_arena']['status'] == 'EXACT_ORIGINAL_ARENA_MATCH', 'Exact original arena joins')
    need(joined['new_result'] == pin(arm / 'result.json'), 'Joined producer-result pin')
    result = checker().check_arm(arm, sys.argv[2], PIPELINE)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['status'] in ('VALID_EXPORT_CERTIFICATE', 'VALID_SEMANTIC_REFUSAL', 'VALID_VACUOUS_INITIALIZER') else 2


if __name__ == '__main__':
    raise SystemExit(main())
