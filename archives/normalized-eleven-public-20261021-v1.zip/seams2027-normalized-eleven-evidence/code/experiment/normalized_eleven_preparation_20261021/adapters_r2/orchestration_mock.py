"""Artificial in-process controls of the actual runner; no science or children.

Only the separately authorized offline qualification calls run_mocks. All files
and mocked native-call fields below are test data, never study observations.
"""
from datetime import datetime, timezone
from pathlib import Path
from common import A, PIPELINE, load, need, pin, read, roster, save


def run_mocks(out):
    out = Path(out)
    need(not out.exists(), 'Fresh artificial mock scope required')
    out.mkdir(parents=True)
    run = load('exact_eleven_actual_runner_under_artificial_mocks', A / 'run.py')
    saved_execution = run.EXECUTION
    checks = []
    ids = roster()['fixed_order']

    def check(name, condition, **evidence):
        checks.append(dict(name=name, pass_=bool(condition), **evidence))

    def fresh(name, left=1000):
        root = out / name
        root.mkdir()
        run.EXECUTION = root
        runner = run.Runner.__new__(run.Runner)
        runner.ids = list(ids)
        runner.rows = [dict(id=ident, pipeline=PIPELINE, native_called=False,
                            outcome='UNKNOWN_NOT_ATTEMPTED', strict_controller_pass=None,
                            nonconflicting_pass=None, kind_controller_pass=None,
                            mock_only=True) for ident in ids]
        runner.refs, runner.source_refs = {}, []
        runner.stop, runner.reasons, runner.audit_count = False, [], 0
        runner.deadline = datetime(2099, 1, 1, tzinfo=timezone.utc)
        runner.native_deadline = runner.deadline.isoformat()
        runner.left = lambda: left
        calls, audits = [], []

        def audit(label):
            audits.append(label)
            return True

        runner.audit = audit
        runner.command = lambda ident, arm: ['ARTIFICIAL_MOCK_ONLY', ident]

        def launch(command, arm, deadline, refs):
            calls.append(command[1])
            arm.mkdir()
            parent = dict(status='UNKNOWN_RESOURCE', global_stop=False,
                          native_called=True, worker_receipt=None, mock_only=True,
                          real_native_calls=0, real_child_processes=0)
            save(arm / 'PARENT_RECEIPT.json', parent)
            return parent

        runner.launch = launch
        return runner, root, calls, audits

    def fake_observation(runner, arm, phase, ident):
        # These files deliberately are not BDDs. Only pin propagation is under
        # test here; scientific equality is covered by separate saved controls.
        evidence = arm / 'ARTIFICIAL_PIN_EVIDENCE.json'
        left = arm / 'ARTIFICIAL_LEFT_REGION.json'
        right = arm / 'ARTIFICIAL_RIGHT_REGION.json'
        for path, label in [(evidence, 'model provenance'), (left, 'left'), (right, 'right')]:
            save(path, dict(mock_only=True, meaning=label, is_scientific_evidence=False))
        producer = pin(arm / 'result.json')
        runner.add_refs([producer])
        observation = dict(status='SAME_MODEL_REGION_MISMATCH', left=pin(left), right=pin(right),
                           exact_function_equal=False, witness={'ARTIFICIAL_MOCK_ONLY': True})
        record = dict(id=ident, pipeline=PIPELINE, original_model_identity_established=True,
                      new_result=producer, mock_only=True,
                      original_arena=dict(status='EXACT_ORIGINAL_ARENA_MATCH', input_pins=[pin(evidence)]),
                      saved_K_arena=dict(status='EXACT_ORIGINAL_ARENA_MATCH', input_pins=[pin(evidence)]),
                      region_observations={phase: observation})
        save(arm / ('REGION_OBSERVATION_' + phase + '.json'),
             dict(schema='normalized-eleven-durable-region-observation-v1', phase=phase, record=record,
                  mock_only=True, scope='Artificial pin/classification propagation only; no BDD computation.'))

    def install_complete_launch(runner, calls):
        def launch(command, arm, deadline, refs):
            calls.append(command[1])
            arm.mkdir()
            save(arm / 'result.json', dict(status='COMPLETE_CONTROLLER_EXPORTED', teardown='COMPLETED',
                                         native_solver_called=False, mock_only=True))
            parent = dict(status='COMPLETE_PROCESS_AND_CAPTURE', global_stop=False, native_called=True,
                          worker_receipt={'artifacts': {'result': pin(arm / 'result.json')}},
                          mock_only=True, real_native_calls=0, real_child_processes=0)
            save(arm / 'PARENT_RECEIPT.json', parent)
            return parent
        runner.launch = launch

    try:
        runner, root, calls, audits = fresh('start_reserve', 239)
        runner.execute()
        check('deadline_start_reserve_keeps_fixed_eleven_unknown', not calls and not audits
              and [x['id'] for x in runner.rows] == ids
              and all(x['outcome'] == 'UNKNOWN_NOT_ATTEMPTED' and x['native_called'] is False for x in runner.rows),
              rows=runner.rows, mock_calls=calls)

        runner, root, calls, audits = fresh('post_audit_reserve')
        remaining = iter([241, 239] + [239] * 11)
        runner.left = lambda: next(remaining)
        runner.execute()
        check('deadline_rechecked_after_pin_audit', not calls and len(audits) == 1
              and all(x['outcome'] == 'UNKNOWN_NOT_ATTEMPTED' for x in runner.rows), audits=audits)

        runner, root, calls, audits = fresh('native_integrity_stop')
        def fatal_launch(command, arm, deadline, refs):
            calls.append(command[1])
            arm.mkdir()
            parent = dict(status='UNKNOWN_INTEGRITY', global_stop=True, native_called=None,
                          worker_receipt=None, mock_only=True, real_native_calls=0)
            save(arm / 'PARENT_RECEIPT.json', parent)
            return parent
        runner.launch = fatal_launch
        runner.execute()
        check('global_stop_retains_uncertain_call_and_remaining_unknown', calls == ids[:1] and runner.stop
              and runner.rows[0]['native_called'] is None
              and runner.rows[0]['outcome'] == 'UNKNOWN_NATIVE_PROCESS'
              and all(x['native_called'] is False and x['outcome'] == 'UNKNOWN_NOT_ATTEMPTED' for x in runner.rows[1:]),
              rows=runner.rows, mock_calls=calls, stop_reasons=runner.reasons)

        runner, root, calls, audits = fresh('resource_no_retry')
        runner.execute()
        check('resource_unknown_continues_fixed_order_once_without_retry', calls == ids and len(set(calls)) == 11
              and not runner.stop and all(x['outcome'] == 'UNKNOWN_RESOURCE' for x in runner.rows),
              rows=runner.rows, mock_calls=calls)

        runner, root, calls, audits = fresh('stage_lineage')
        def fatal_bound(command, folder, deadline, **caps):
            folder.mkdir()
            result = dict(status='FATAL_ARTIFICIAL_CONTROL', exit_code=None, parent_aborted=True,
                          mock_only=True, real_child_processes=0)
            save(folder / 'PROCESS_RECEIPT.json', result)
            return result
        runner.bound = fatal_bound
        run.Runner.stage(runner, ['ARTIFICIAL_NO_CHILD'], root / 'stage', [])
        lineage = read(root / 'stage/RECEIPT_LINEAGE.json')
        check('stage_integrity_stop_and_inherited_aborted_field_namespaced', runner.stop
              and lineage['raw_stage_parent_aborted_value'] is True
              and lineage['this_study_resumes_aborted_public425'] is False,
              lineage=lineage, stop_reasons=runner.reasons)

        for phase, failure in [('V', 'resource'), ('V', 'runner_exception'), ('K', 'resource')]:
            runner, root, calls, audits = fresh('durable_' + phase + '_' + failure)
            install_complete_launch(runner, calls)
            def stopped_join(command, folder, watched, phase=phase, failure=failure):
                folder.mkdir()
                fake_observation(runner, folder.parent, phase, folder.parent.parent.name)
                if failure == 'runner_exception':
                    raise RuntimeError('ARTIFICIAL runner failure after durable observation')
                result = dict(status='UNKNOWN_RESOURCE', exit_code=None, mock_only=True, real_child_processes=0)
                save(folder / 'PROCESS_RECEIPT.json', result)
                return result
            runner.stage = stopped_join
            if phase == 'V':
                runner.execute()
            else:
                runner.attempt(runner.rows[0])
            value = runner.rows[0]
            completion = 'UNKNOWN_RUNNER_INTEGRITY' if failure == 'runner_exception' else 'UNKNOWN_JOIN_RESOURCE'
            check('durable_' + phase + '_mismatch_survives_' + failure,
                  value['outcome'] == 'SAME_MODEL_REGION_MISMATCH'
                  and value['completion_outcome'] == completion
                  and len(value['durable_region_observations']) == 1
                  and value['durable_region_observations'][0]['phase'] == phase
                  and not value['observation_read_errors']
                  and (runner.stop is (phase == 'V'))
                  and (phase != 'V' or calls == ids[:1]),
                  row=value, mock_calls=calls, stop_reasons=runner.reasons)
            run.set_outcome(value, 'UNKNOWN_LATER_ARTIFICIAL_COMPLETION')
            check('durable_' + phase + '_' + failure + '_remains_after_further_unknown',
                  value['outcome'] == 'SAME_MODEL_REGION_MISMATCH'
                  and value['completion_outcome'] == 'UNKNOWN_LATER_ARTIFICIAL_COMPLETION')

        runner, root, calls, audits = fresh('atomic_no_overwrite')
        path = root / 'ATOMIC.json'
        save(path, {'mock_only': True, 'first': True})
        before = pin(path)
        try:
            save(path, {'mock_only': True, 'first': False})
        except ValueError as error:
            rejected = 'No output overwrite' in str(error)
        else:
            rejected = False
        check('atomic_completed_record_cannot_be_overwritten', rejected and pin(path) == before
              and not path.with_name(path.name + '.tmp').exists(), first_record=before)
    finally:
        run.EXECUTION = saved_execution

    result = dict(schema='normalized-eleven-artificial-orchestration-controls-v1',
                  status='PASS' if all(x['pass_'] for x in checks) else 'FAIL',
                  checks=checks, fixed_order=ids, denominator=11, real_native_calls=0,
                  real_child_processes=0, BDD_imports=0, graph_computations=0,
                  scope='In-process artificial orchestration data; not native, graph, region, or controller evidence.')
    save(out / 'MOCK_RESULT.json', result)
    return result
