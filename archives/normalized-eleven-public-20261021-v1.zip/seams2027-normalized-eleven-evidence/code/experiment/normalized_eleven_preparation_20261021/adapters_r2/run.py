"""Bounded exact11 orchestration. No launch without exact-freeze Root decision."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import argparse
import hashlib
import json
import sys
import time
from common import A, P, E, EXECUTION, PIPELINE, check_decision, load, need, now, pin, read, roster, save, supervisor_lineage, verify


def classify_certificate(cert):
    status = cert['status']
    if status == 'VALID_EXPORT_CERTIFICATE':
        return 'COMPLETE_GRAPH_CHECKED', False
    if status == 'VALID_VACUOUS_INITIALIZER':
        return 'VALID_VACUOUS_INITIALIZER', False
    if status == 'VALID_SEMANTIC_REFUSAL':
        if cert.get('refusal_kind') == 'EMPTY_V_INDEPENDENTLY_CHECKED':
            return 'EMPTY_V_INDEPENDENT_REFUSAL', False
        return 'SOURCE_BOUND_NATIVE_REGION_REFUSAL', False
    if status == 'RESOURCE_REFUSAL':
        return 'UNKNOWN_CHECKER_RESOURCE', False
    if cert.get('refusal_scope') == 'CANDIDATE_CONTROLLER':
        return 'EXPORTED_GRAPH_CONTROLLER_DEFECT', False
    if cert.get('refusal_scope') == 'CANDIDATE_TECHNICAL':
        return 'UNKNOWN_EXTRACTION_OR_EXPORT', False
    return 'UNKNOWN_CHECKER_INTEGRITY', True


def set_outcome(value, outcome):
    """Preserve a qualified observation independently of later completion."""
    value['completion_outcome'] = outcome
    mismatch = value.get('comparison_status') == 'SAME_MODEL_REGION_MISMATCH'
    mismatch |= any(item.get('observation', {}).get('status') == 'SAME_MODEL_REGION_MISMATCH'
                    for item in value.get('durable_region_observations', []))
    value['outcome'] = 'SAME_MODEL_REGION_MISMATCH' if mismatch else outcome


class Runner:
    def __init__(self, decision_path):
        self.started = time.monotonic()
        self.start_utc = now()
        self.decision, authorized_deadline = check_decision(decision_path, 'NATIVE_ELEVEN')
        self.deadline = min(authorized_deadline, datetime.now(timezone.utc) + timedelta(seconds=max(0, 3600 - (time.monotonic() - self.started))))
        self.native_deadline = (self.deadline - timedelta(seconds=90)).isoformat()
        need(not EXECUTION.exists(), 'Fresh execution scope required; no resume or retries')
        EXECUTION.mkdir()
        self.ids = roster()['fixed_order']
        self.sources = {row['id']: row for row in roster()['rows']}
        self.rows = [{'id': ident, 'pipeline': PIPELINE, 'native_called': False, 'outcome': 'UNKNOWN_NOT_ATTEMPTED',
                      'strict_controller_pass': None, 'nonconflicting_pass': None, 'kind_controller_pass': None} for ident in self.ids]
        self.refs = {}
        for ref in [x['pin'] for x in read(P / 'INPUT_MANIFEST.json')['files']] + read(A / 'ADAPTER_FREEZE.json')['files'] + [pin(A / 'ADAPTER_FREEZE.json'), pin(decision_path)]:
            self.add_refs([ref])
        self.source_refs = list(self.refs.values())
        self.stop, self.reasons, self.audit_count = False, [], 0
        sys.path.insert(0, str(E / 'contained_recovery'))
        self.launch = load('eleven_exact_owned_native_launcher', E / 'contained_recovery/launcher.py').launch_native
        self.bound = load('eleven_exact_owned_stage_launcher', E / 'contained_stage_process/bounded_process.py').run_bounded
        self.prefix = read(P / 'RUNTIME_TEMPLATE.json')['command_prefix_unchanged']
        self.origins = read(P / 'RUNTIME_TEMPLATE.json')['origins']['path']
        save(EXECUTION / 'RUN_STARTED.json', {'started_utc': self.start_utc, 'deadline_utc': self.deadline.isoformat(),
            'decision': pin(decision_path), 'adapter_freeze': pin(A / 'ADAPTER_FREEZE.json'),
            'source_denominator': 11, 'fixed_order': self.ids, 'native_concurrency': 1, 'retries': 0,
            'supervisor_lineage': supervisor_lineage(), 'is_resumption': False})

    def add_refs(self, refs):
        for ref in refs:
            value = {k: ref[k] for k in ('path', 'bytes', 'sha256')}
            need(value['path'] not in self.refs or self.refs[value['path']] == value, 'Conflicting result pin')
            self.refs[value['path']] = value

    def fail(self, reason):
        self.stop = True
        self.reasons.append(reason)

    def left(self):
        return (self.deadline - datetime.now(timezone.utc)).total_seconds()

    def audit(self, label):
        errors = []
        for ref in self.refs.values():
            try:
                verify(ref)
            except Exception as error:
                errors.append({'pin': ref, 'error': repr(error)})
        self.audit_count += 1
        save(EXECUTION / 'audits' / (str(self.audit_count).zfill(3) + '_' + label + '.json'),
             {'created_utc': now(), 'checked': len(self.refs), 'errors': errors})
        if errors:
            self.fail('PIN_INTEGRITY')
        return not errors

    def command(self, ident, arm):
        return self.prefix + [ident, PIPELINE, '4fp', self.sources[ident]['source']['path'], str(arm / 'result.json'), self.origins]

    def stage(self, command, folder, watched):
        result = self.bound(command, folder, self.deadline.isoformat(), wall_seconds=60,
                            file_bytes=16 * 1024 * 1024, watch_files=watched)
        self.add_refs([pin(folder / 'PROCESS_RECEIPT.json')])
        save(folder / 'RECEIPT_LINEAGE.json', supervisor_lineage())
        if result['status'].startswith('FATAL_'):
            self.fail('STAGE_PROCESS_INTEGRITY')
        return result

    def collect_observations(self, arm, value):
        """Read completed atomic records even when the child hit a later cap."""
        observations = value.setdefault('durable_region_observations', [])
        errors = value.setdefault('observation_read_errors', [])
        for phase in ('V', 'K'):
            if phase in {item['phase'] for item in observations}:
                continue
            path = arm / ('REGION_OBSERVATION_' + phase + '.json')
            if not path.exists():
                continue
            try:
                saved = read(path)
                need(saved['schema'] == 'normalized-eleven-durable-region-observation-v1' and saved['phase'] == phase, 'Observation schema/phase')
                record = saved['record']
                need(record['id'] == value['id'] and record['pipeline'] == PIPELINE, 'Observation fixture identity')
                need(record['original_model_identity_established'] is True, 'Observation requires established original identity')
                need(record['new_result'] in self.refs.values(), 'Observation must bind producer-time result')
                verify(record['new_result'])
                for key in ('original_arena', 'saved_K_arena'):
                    need(record[key]['status'] == 'EXACT_ORIGINAL_ARENA_MATCH', 'Observation original-arena identity')
                    for ref in record[key]['input_pins']:
                        verify(ref)
                observation = record['region_observations'][phase]
                need(observation['status'] in ('EXACT_REGION_MATCH', 'SAME_MODEL_REGION_MISMATCH'), 'Observation region status')
                verify(observation['left'])
                verify(observation['right'])
                ref = pin(path)
                self.add_refs([ref])
                observations.append({'phase': phase, 'record': ref, 'observation': observation,
                                     'scope': 'Durable qualified region observation; join/checker completion is reported separately.'})
                if observation['status'] == 'SAME_MODEL_REGION_MISMATCH':
                    value['comparison_status'] = 'SAME_MODEL_REGION_MISMATCH'
                    if phase == 'V':
                        self.fail('OBSERVED_SAME_MODEL_V_REGION_MISMATCH')
            except Exception as error:
                errors.append({'phase': phase, 'error': type(error).__name__ + ': ' + str(error)})
                self.fail('REGION_OBSERVATION_INTEGRITY')

    def attempt(self, value):
        ident = value['id']
        if self.stop or self.left() < 240:
            value['reason'] = 'GLOBAL_STOP_OR_DEADLINE_START_RESERVE'
            return
        if not self.audit(ident + '_before') or self.left() < 240:
            value['reason'] = 'PIN_AUDIT_OR_DEADLINE_START_RESERVE'
            return
        arm = EXECUTION / 'runs' / ident / PIPELINE
        arm.parent.mkdir(parents=True)
        command = self.command(ident, arm)
        value.update(command_sha256=hashlib.sha256(json.dumps(command, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest(),
                     native_called=None, outcome='UNKNOWN_NATIVE_INVOCATION_PENDING')
        parent = self.launch(command, arm, self.native_deadline, self.source_refs)
        value.update(native_called=parent['native_called'], parent_status=parent['status'], parent_receipt=pin(arm / 'PARENT_RECEIPT.json'))
        if parent['global_stop']:
            self.fail('NATIVE_PARENT_INTEGRITY')
        # Producer-time artifact bytes are admitted before any consumer stage.
        refs = [value['parent_receipt']] + [parent[k] for k in ('worker_receipt_pin', 'child_identity_pin', 'worker_stdout', 'worker_stderr') if parent.get(k)]
        refs += list((parent.get('worker_receipt') or {}).get('artifacts', {}).values())
        self.add_refs(refs)
        if not self.audit(ident + '_producer_time_binding'):
            set_outcome(value, 'UNKNOWN_INTEGRITY_GLOBAL_STOP')
            return
        if parent['status'] != 'COMPLETE_PROCESS_AND_CAPTURE':
            set_outcome(value, 'UNKNOWN_RESOURCE' if 'RESOURCE' in parent['status'] else 'UNKNOWN_NATIVE_PROCESS')
            return
        native = read(arm / 'result.json')
        value.update(native_status=native.get('status'), native_solver_called=native.get('native_solver_called'),
            controller_extraction_called=native.get('controller_extraction_called'), initial_in_region=native.get('initial_in_region'),
            initial_ENV_empty=native.get('initial_ENV_empty'), initial_joint_empty=native.get('initial_joint_empty'))
        if native.get('teardown') != 'COMPLETED' or not native.get('status', '').startswith('COMPLETE_'):
            set_outcome(value, 'UNKNOWN_TECHNICAL_OR_UNSUPPORTED')
            return
        # Capture decode and exact original-model join share one bounded60s stage.
        joined = self.stage([sys.executable, '-B', str(A / 'join.py'), ident, str(arm)], arm / 'join',
                            [arm / 'MODEL_JOIN.json', arm / 'RLE_CAPTURE_VERIFICATION.json',
                             arm / 'REGION_OBSERVATION_V.json', arm / 'REGION_OBSERVATION_K.json'])
        value['join_process'] = pin(arm / 'join/PROCESS_RECEIPT.json')
        value.update(join_process_status=joined['status'], comparison_complete=False)
        self.collect_observations(arm, value)
        if value['observation_read_errors']:
            set_outcome(value, 'UNKNOWN_REGION_OBSERVATION_INTEGRITY')
            return
        if joined['status'] != 'PROCESS_COMPLETED' or joined['exit_code'] not in (0, 2) or not (arm / 'MODEL_JOIN.json').exists():
            set_outcome(value, 'UNKNOWN_JOIN_RESOURCE' if joined['status'] == 'UNKNOWN_RESOURCE' else 'UNKNOWN_JOIN_PROCESS')
            return
        comparison = read(arm / 'MODEL_JOIN.json')
        value.update(comparison_status='SAME_MODEL_REGION_MISMATCH' if value.get('comparison_status') == 'SAME_MODEL_REGION_MISMATCH' else comparison['status'],
            comparison_complete=comparison.get('comparison_complete', False), model_join=pin(arm / 'MODEL_JOIN.json'),
            V_comparison=comparison.get('V_comparison'), native_region_join_saved_K=comparison.get('native_region_join_saved_K'))
        self.add_refs([value['model_join']] + ([pin(arm / 'RLE_CAPTURE_VERIFICATION.json')] if (arm / 'RLE_CAPTURE_VERIFICATION.json').exists() else []))
        if comparison['stop_continuation']:
            set_outcome(value, comparison.get('completion_status', comparison['status']))
            self.fail('JOIN_STOP: ' + comparison['status'])
            return
        if comparison['status'].startswith('UNKNOWN'):
            set_outcome(value, comparison['status'])
            return
        if comparison.get('completion_status', '').startswith('UNKNOWN'):
            set_outcome(value, comparison['completion_status'])
            return
        need(joined['exit_code'] == 0, 'Join exit/status authority')
        if not self.audit(ident + '_joined'):
            set_outcome(value, 'UNKNOWN_INTEGRITY_GLOBAL_STOP')
            return
        checked = self.stage([sys.executable, '-B', str(A / 'check_graph.py'), str(arm), ident], arm / 'checker', [])
        value['checker_process'] = pin(arm / 'checker/PROCESS_RECEIPT.json')
        if checked['status'] != 'PROCESS_COMPLETED' or checked['exit_code'] not in (0, 2):
            set_outcome(value, 'UNKNOWN_CHECKER_RESOURCE' if checked['status'] == 'UNKNOWN_RESOURCE' else 'UNKNOWN_CHECKER_PROCESS')
            return
        cert = read(arm / 'checker/stdout.txt')
        expected_exit = 0 if cert['status'] in ('VALID_EXPORT_CERTIFICATE', 'VALID_SEMANTIC_REFUSAL', 'VALID_VACUOUS_INITIALIZER') else 2
        need(checked['exit_code'] == expected_exit, 'Checker exit/status authority')
        save(arm / 'certificate.json', cert)
        value['certificate'] = pin(arm / 'certificate.json')
        self.add_refs([value['certificate']])
        graph_outcome, fatal = classify_certificate(cert)
        value.update(graph_outcome=graph_outcome, certificate_status=cert['status'],
            strict_controller_pass=cert.get('strict_controller_pass'), nonconflicting_pass=cert.get('nonconflicting_pass'),
            kind_controller_pass=cert.get('kind_controller_pass'), witnesses=cert.get('witnesses'), controller_defects=cert.get('controller_defects'))
        set_outcome(value, graph_outcome)
        if fatal:
            self.fail('CHECKER_INTEGRITY')
        if not self.audit(ident + '_after'):
            set_outcome(value, 'UNKNOWN_INTEGRITY_GLOBAL_STOP')

    def execute(self):
        for value in self.rows:
            try:
                self.attempt(value)
            except Exception as error:
                arm = EXECUTION / 'runs' / value['id'] / PIPELINE
                if arm.is_dir() and (arm / 'join').exists():
                    try:
                        self.collect_observations(arm, value)
                    except Exception as observation_error:
                        value.setdefault('observation_read_errors', []).append({'error': repr(observation_error)})
                value.update(error=type(error).__name__ + ': ' + str(error))
                set_outcome(value, 'UNKNOWN_RUNNER_INTEGRITY')
                self.fail('RUNNER_EXCEPTION')
            arm = EXECUTION / 'runs' / value['id'] / PIPELINE
            if arm.is_dir():
                save(arm / 'OUTCOME.json', value)
                self.add_refs([pin(p) for p in sorted(arm.rglob('*')) if p.is_file()])

    def finish(self):
        self.audit('final')
        save(EXECUTION / 'RUN_RECEIPT.json', {'schema': 'normalized-eleven-original-initializer-run-v1',
            'started_utc': self.start_utc, 'finished_utc': now(), 'elapsed_seconds': time.monotonic() - self.started,
            'deadline_utc': self.deadline.isoformat(), 'adapter_freeze': pin(A / 'ADAPTER_FREEZE.json'),
            'source_denominator': 11, 'fixed_order': self.ids, 'rows': self.rows, 'global_stop': self.stop,
            'stop_reasons': self.reasons, 'confirmed_native_calls': sum(r['native_called'] is True for r in self.rows),
            'uncertain_native_calls': sum(r['native_called'] is None for r in self.rows),
            'native_concurrency': 1, 'retries': 0, 'unknown_is_negative': False, 'performance_comparison': False,
            'supervisor_lineage': supervisor_lineage(), 'is_resumption': False, 'full_reset_uses': 0})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--decision', type=Path, required=True)
    args = parser.parse_args()
    runner = Runner(args.decision)
    try:
        runner.execute()
    finally:
        runner.finish()


if __name__ == '__main__':
    main()
