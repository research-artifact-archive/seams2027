"""Shared provenance helpers. This module performs no science or process launch."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
A = Path(__file__).resolve().parent
P = A.parent
R = P.parents[1]
E = R / 'experiment/seams_research_reframing_20261017'
F = R / 'experiment/seams_submission_push_20261016/v_restricted_strict'
EXECUTION = P.parent / 'normalized_eleven_execution_20261021'
QUALIFICATION = P / 'adapter_qualification'
PIPELINE = 'normalized_kind'


def need(test, message):
    if not test:
        raise ValueError(message)


def now():
    return datetime.now(timezone.utc).isoformat()


def unique_object(pairs):
    out = {}
    for key, value in pairs:
        need(key not in out, 'Duplicate JSON key: ' + key)
        out[key] = value
    return out


def read(path, limit=64 * 1024 * 1024):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), 'Regular non-symlink file required: ' + str(path))
    need(path.stat().st_size <= limit, 'JSON byte cap: ' + str(path))
    return json.loads(path.read_text(), object_pairs_hook=unique_object)


def pin(path):
    path = Path(path).resolve()
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': h.hexdigest()}


def verify(ref):
    need(set(ref) >= {'path', 'bytes', 'sha256'}, 'Malformed absolute file pin')
    path = Path(ref['path'])
    need(path.is_absolute() and path.is_file() and not path.is_symlink(), 'Pinned file type')
    need(pin(path) == {key: ref[key] for key in ('path', 'bytes', 'sha256')}, 'PIN_CHANGED: ' + str(path))
    return path


def save(path, value):
    path = Path(path)
    need(path.resolve().is_relative_to(P) or path.resolve().is_relative_to(EXECUTION), 'Output outside owned new scope')
    path.parent.mkdir(parents=True, exist_ok=True)
    need(not path.exists(), 'No output overwrite: ' + str(path))
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    # Atomic visibility without replacing any prior output. Interrupted temp
    # files are not accepted as completed observations by a later reader.
    os.link(temporary, path)
    temporary.unlink()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def frozen_inputs():
    frozen = read(A / 'ADAPTER_FREEZE.json')
    need(frozen['schema'] == 'normalized-eleven-adapter-freeze-v1', 'Adapter freeze schema')
    need(pin(sys.executable) == frozen['python'], 'Exact qualified Python interpreter required')
    for ref in frozen['files']:
        verify(ref)
    for ref in read(A / 'ADAPTER_INPUTS.json')['files']:
        verify(ref)
    for item in read(P / 'INPUT_MANIFEST.json')['files']:
        verify(item['pin'])
    return frozen


def roster():
    frozen = read(A / 'SOURCE_BINDINGS.json')
    ids = frozen['fixed_order']
    need(len(ids) == len(set(ids)) == 11, 'Exact11 order')
    need([row['id'] for row in frozen['rows']] == ids, 'Exact11 row order')
    return frozen


def row_for(ident):
    rows = [row for row in roster()['rows'] if row['id'] == ident]
    need(len(rows) == 1, 'Fixture outside exact frozen eleven')
    return rows[0]


def check_decision(path, operation):
    """A reviewable exact-freeze decision is required; this code creates none."""
    decision = read(path)
    need(decision.get('authorized') is True and decision.get('operation') == operation, 'No authority for this operation')
    need(decision.get('adapter_freeze') == pin(A / 'ADAPTER_FREEZE.json'), 'Decision does not bind current adapter freeze')
    deadline = datetime.fromisoformat(decision['deadline_utc'])
    need(deadline.tzinfo is not None and deadline > datetime.now(timezone.utc), 'Expired/naive decision deadline')
    review_path = verify(decision['independent_static_review'])
    review = read(review_path)
    need(review.get('status') == 'PASS' and review.get('adapter_freeze') == pin(A / 'ADAPTER_FREEZE.json'), 'Missing independent exact-freeze static PASS')
    frozen_inputs()
    if operation == 'NATIVE_ELEVEN':
        proof_path = verify(decision['offline_qualification'])
        proof = read(proof_path)
        need(proof.get('status') == 'PASS' and proof.get('adapter_freeze') == pin(A / 'ADAPTER_FREEZE.json'), 'Missing exact-freeze offline PASS')
        need(decision.get('max_native_calls') == 11 and decision.get('max_wall_seconds') == 3600, 'Unexpected native budget')
    else:
        need(operation == 'OFFLINE_QUALIFICATION' and decision.get('max_wall_seconds') == 300, 'Unexpected offline budget')
        need(decision.get('max_native_calls') == 0, 'Offline authorization must prohibit native')
    return decision, deadline


def owned_arm(path, ident):
    expected = EXECUTION / 'runs' / ident / PIPELINE
    need(Path(path).resolve() == expected and expected.is_dir() and not expected.is_symlink(), 'Exact owned arm required')
    return expected


def supervisor_lineage():
    return {'raw_stage_parent_aborted_value': True,
            'meaning': 'Inherited hardcoded field from the frozen contained_stage_process implementation; not a fact about this study.',
            'this_study_resumes_aborted_public425': False,
            'historical_supervisor_source': pin(E / 'contained_stage_process/bounded_process.py')}
