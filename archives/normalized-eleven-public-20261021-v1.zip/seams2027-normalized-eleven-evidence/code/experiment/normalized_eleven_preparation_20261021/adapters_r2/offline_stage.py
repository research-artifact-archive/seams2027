"""Fixed offline checks, callable only after independent static PASS and Root GO.

All historical files remain read-only. Existing scientific checker functions are
reused; only output location and exact source/evidence binding are adapted.
"""
from pathlib import Path
from copy import deepcopy
import argparse
import json
import shutil
import sys
from common import A, E, F, QUALIFICATION, check_decision, load, need, pin, read, roster, save, verify
import source_binding
from join import join_saved, compare_regions, historical_authority, model_join, native_ref


def existing_checker():
    return load('offline_original_public_graph_checker', E / 'initial_graph_checker/initial_graph_checker.py')


def controls(out):
    q = load('offline_existing_26_controls', E / 'initial_graph_checker/qualify.py')
    # The existing module's science and production-binder rejection remain exact.
    # Redirect only its output globals; this never runs its historical main path.
    q.HERE, q.OUT = out, out / 'fixtures'
    shutil.copyfile(E / 'initial_graph_checker/initial_graph_checker.py', out / 'initial_graph_checker.py')
    rc = q.main()
    result = read(out / 'QUALIFICATION.json')
    need(rc == 0 and result['status'] == 'PASS' and len(result['cases']) == 26, 'Existing26 controls failed')
    return {'status': 'PASS', 'cases': result['cases'], 'reused_qualification_source': pin(E / 'initial_graph_checker/qualify.py'),
            'qualification': pin(out / 'QUALIFICATION.json'), 'output_redirection_only': True}


def models(out):
    original = read(E / 'initial_graph_checker/SAVED_MODEL_REGRESSION.json')
    need(len(original['cases']) == 14, 'Exactly14 saved model regression cases')
    c = existing_checker()
    results = []
    for old in original['cases']:
        model_path = Path(old['model_path'])
        need(pin(model_path)['sha256'] == old['model_sha256'], 'Saved14 model changed')
        model = c.read_json(model_path)
        ctx = c.Context(model_path.parent, c.load_profile(old['fixture']), model)
        audit = ctx.audit_model()
        v, alive, rounds = ctx.viability()
        results.append({'id': old['fixture'], 'status': 'PASS', 'model': pin(model_path), 'model_audit': audit,
                        'V_empty': v == 0, 'V_iterations': rounds, 'original_ENV_initializer_empty': ctx.formulas['thetaE'] == 0})
    return {'status': 'PASS', 'model_exports': 14, 'cases': results, 'historical_scope': 'Original public425 binder retained only for its existing14 regression cases.'}


def eleven(out):
    sys.path.insert(0, str(F / 'checker'))
    original = load('offline_existing_eleven_source_formula_checker', F / 'checker/admission_checker.py')
    c = source_binding.checker()
    results = []
    for row in roster()['rows']:
        profile = source_binding.load_profile(row['id'])
        model_path = verify(row['original_model'])
        model = read(model_path)
        # Reuse the existing source-profile compiler, including original monitors.
        old = original.Context(model_path.parent, original.load_profile(row['id']), model)
        formula_audit = old.audit_model()
        current = c.Context(model_path.parent, profile, model)
        model_audit = current.audit_model()
        join = join_saved(row, model_path.parent)
        need(join['status'] == 'EXACT_ORIGINAL_ARENA_AND_REGIONS_MATCH', 'Fixed saved11 positive join control failed')
        result = {'id': row['id'], 'status': 'PASS', 'formula_audit': formula_audit, 'model_audit': model_audit,
                  'source_bindings': profile['bindings'], 'saved_schema_and_evidence_join': join,
                  'scope': 'Saved residual-result schema is used only as a positive full-region/evidence binding control. This is not a new original-initializer native or graph result.'}
        save(out / (row['id'] + '.json'), result)
        results.append({'id': row['id'], 'status': 'PASS', 'result': pin(out / (row['id'] + '.json'))})
    return {'status': 'PASS', 'denominator': 11, 'rows': results, 'new_native_calls': 0}


def negative(out):
    checks = []

    def rejected(name, action, expected_cause):
        try:
            action()
        except Exception as error:
            checks.append({'name': name, 'pass': expected_cause in str(error), 'expected_cause': expected_cause,
                           'rejection': type(error).__name__ + ': ' + str(error)})
        else:
            checks.append({'name': name, 'pass': False, 'rejection': None})

    rejected('foreign_ID_rejected', lambda: source_binding.load_profile('corpus002__original'), 'Fixture outside exact frozen eleven')
    rejected('synthetic_ID_rejected', lambda: source_binding.load_profile('synthetic__qualification'), 'Fixture outside exact frozen eleven')
    row = roster()['rows'][0]
    binder = source_binding.row_for
    altered = deepcopy(row)
    altered['source']['sha256'] = '0' * 64
    source_binding.row_for = lambda ident: altered
    try:
        rejected('source_pin_mutation_rejected', lambda: source_binding.load_profile(row['id']), 'PIN_CHANGED')
    finally:
        source_binding.row_for = binder
    original_model = read(row['original_model']['path'])
    for name, mutation, expected_cause in [
        ('field_owner_change_rejected', lambda m: m['fields'][0].update(owner='SYS'), 'Original model metadata differs: fields'),
        ('lost_AUX_field_rejected', lambda m: m['fields'].pop(), 'Original model metadata differs: fields'),
        ('initializer_roster_change_rejected', lambda m: m['original_bdds'].pop('thetaS'), 'Original predicate roster differs'),
        ('justice_loss_rejected', lambda m: m['original_justices']['SYS'].pop(), 'Original ordered justice length differs: SYS'),
    ]:
        target = out / name
        target.mkdir()
        altered_model = deepcopy(original_model)
        mutation(altered_model)
        save(target / 'model.json', altered_model)
        rejected(name, lambda: model_join(Path(row['original_model']['path']).parent, target), expected_cause)

    # A fixed historical V-versus-K inequality checks the observation classifier.
    # It is a qualification fixture, not a new normalized-run measurement.
    lift = next(row for row in roster()['rows'] if row['id'] == 'lift__trivial_1')
    c = source_binding.checker()
    model_path = Path(lift['original_model']['path'])
    model = read(model_path)
    ctx = c.Context(model_path.parent, source_binding.load_profile(lift['id']), model)
    coop = next(item for item in lift['saved_comparator_inputs'] if item['policy'] == 'cooperative')
    difference = compare_regions(ctx.b, model, lift['saved_V'], coop['region'], ctx.formulas['thetaE'], ctx.formulas['thetaS'], None)
    checks.append({'name': 'same_model_region_difference_retains_typed_witness_and_initial_relation',
        'pass': difference['status'] == 'SAME_MODEL_REGION_MISMATCH' and difference['witness'] is not None
                and difference['witness']['left_region'] != difference['witness']['right_region'],
        'fixed_fixture': 'Saved lift__trivial_1 V versus saved K, deliberately unequal; no new-run claim.', 'result': difference})
    altered = deepcopy(lift)
    altered['existing_model_certificate'] = row['existing_model_certificate']
    rejected('cross_source_historical_certificate_rejected', lambda: historical_authority(altered), 'Historical eleven evidence authority failed')

    run = load('offline_eleven_accounting_only', A / 'run.py')
    expected = [
        ({'status': 'VALID_SEMANTIC_REFUSAL', 'refusal_kind': 'EMPTY_V_INDEPENDENTLY_CHECKED'}, 'EMPTY_V_INDEPENDENT_REFUSAL', False),
        ({'status': 'VALID_SEMANTIC_REFUSAL', 'refusal_kind': 'SOURCE_BOUND_NATIVE_REGION_REFUSAL'}, 'SOURCE_BOUND_NATIVE_REGION_REFUSAL', False),
        ({'status': 'RESOURCE_REFUSAL'}, 'UNKNOWN_CHECKER_RESOURCE', False),
        ({'status': 'INVALID', 'refusal_scope': 'CANDIDATE_CONTROLLER'}, 'EXPORTED_GRAPH_CONTROLLER_DEFECT', False),
        ({'status': 'INVALID', 'refusal_scope': 'CANDIDATE_TECHNICAL'}, 'UNKNOWN_EXTRACTION_OR_EXPORT', False),
        ({'status': 'INVALID', 'refusal_scope': 'QUALIFICATION_INTEGRITY'}, 'UNKNOWN_CHECKER_INTEGRITY', True),
    ]
    for cert, outcome, stop in expected:
        checks.append({'name': 'accounting_' + outcome, 'pass': run.classify_certificate(cert) == (outcome, stop)})
    mocks = load('eleven_artificial_orchestration_mocks', A / 'orchestration_mock.py').run_mocks(out / 'runner_mocks')
    need(all(item['pass'] for item in checks) and mocks['status'] == 'PASS', 'Fixed negative/accounting controls failed')
    return {'status': 'PASS', 'checks': checks, 'orchestration_mocks': mocks, 'new_native_calls': 0, 'new_scientific_source_cases': 0}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=['controls', 'models', 'eleven', 'negative'])
    parser.add_argument('--decision', type=Path, required=True)
    args = parser.parse_args()
    check_decision(args.decision, 'OFFLINE_QUALIFICATION')
    out = QUALIFICATION / args.stage
    need(not out.exists(), 'Fresh offline stage output required')
    out.mkdir(parents=True)
    try:
        result = globals()[args.stage](out)
    except Exception as error:
        result = {'status': 'FAIL', 'error': type(error).__name__ + ': ' + str(error), 'new_native_calls': 0}
    result.update(stage=args.stage, adapter_freeze=pin(A / 'ADAPTER_FREEZE.json'), native_calls=0)
    save(out / 'RESULT.json', result)
    print(json.dumps({'stage': args.stage, 'status': result['status']}))
    return 0 if result['status'] == 'PASS' else 2


if __name__ == '__main__':
    raise SystemExit(main())
