"""Exact11 source binder; only provenance seams of the frozen checker change.

The production CLI has no synthetic bypass, field mapping or semantic fallback.
"""
import re
from common import A, E, need, pin, read, row_for, verify, load


def load_profile(ident):
    row = row_for(ident)
    source = verify(row['source'])
    profile_file = verify(row['source_profile']['file'])
    audited = read(profile_file)['profiles'][row['source_profile']['profile_key']]
    need(audited['fixture_id'] == ident, 'Source profile ID')
    need(all(audited['source'][key] == row['source'][key] for key in ('bytes', 'sha256')), 'Source profile pin')
    need(row['declared_reconstruction']['selected_source'] == row['source'], 'Declared reconstruction/source')
    for key in ('raw_source', 'selected_source', 'declared_reconstruction', 'declared_diff'):
        verify(row['declared_reconstruction'][key])
    tokens = re.findall(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[A-Za-z_]\w*|\S', source.read_text(), re.S)
    need('import' not in [token for token in tokens if not token.startswith(('/*', '//'))], 'Unexpected source import')
    case, variant = ident.split('__')
    return {'fixture_id': ident, 'case_id': case, 'variant': variant, 'source': row['source'],
            'bindings': {'scope': 'exact_eleven_replacements_original_initializer',
                'source_binding_manifest': pin(A / 'SOURCE_BINDINGS.json'),
                'source_profile': row['source_profile'], 'declared_reconstruction': row['declared_reconstruction'],
                'closure': [row['source']], 'original_model': row['original_model'],
                'public425_membership_claimed': False}}


def checker():
    """Only these two documented globals differ; scientific functions are loaded unchanged."""
    c = load('exact_eleven_frozen_original_graph_checker', E / 'initial_graph_checker/initial_graph_checker.py')
    c.load_profile = load_profile
    c.FREEZE_SHA256 = pin(A / 'SOURCE_BINDINGS.json')['sha256']
    return c
