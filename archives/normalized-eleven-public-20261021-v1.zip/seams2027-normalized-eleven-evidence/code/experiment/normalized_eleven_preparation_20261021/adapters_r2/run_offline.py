"""At most300 seconds of fixed offline qualification, never native execution."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import argparse
import sys
import time
from common import A, E, QUALIFICATION, check_decision, load, need, now, pin, read, save, supervisor_lineage, frozen_inputs


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--decision', type=Path, required=True)
    args = parser.parse_args()
    start = time.monotonic()
    decision, authorized = check_decision(args.decision, 'OFFLINE_QUALIFICATION')
    deadline = min(authorized, datetime.now(timezone.utc) + timedelta(seconds=max(0, 300 - (time.monotonic() - start))))
    need(not QUALIFICATION.exists(), 'Fresh offline scope required; no retry')
    QUALIFICATION.mkdir()
    sys.path.insert(0, str(E / 'contained_recovery'))
    bounded = load('eleven_offline_owned_stage_supervisor', E / 'contained_stage_process/bounded_process.py').run_bounded
    rows, stopped = [], False
    for stage, cap in [('controls', 60), ('models', 60), ('eleven', 120), ('negative', 60)]:
        row = {'stage': stage, 'status': 'UNKNOWN_NOT_ATTEMPTED', 'native_calls': 0}
        rows.append(row)
        if stopped or datetime.now(timezone.utc) >= deadline:
            continue
        try:
            command = [sys.executable, '-B', str(A / 'offline_stage.py'), stage, '--decision', str(args.decision.resolve())]
            folder = QUALIFICATION / 'processes' / stage
            process = bounded(command, folder, deadline.isoformat(), wall_seconds=cap,
                              file_bytes=16 * 1024 * 1024, watch_files=[QUALIFICATION / stage / 'RESULT.json'])
            save(folder / 'RECEIPT_LINEAGE.json', supervisor_lineage())
            row['process'] = pin(folder / 'PROCESS_RECEIPT.json')
            if process['status'] == 'PROCESS_COMPLETED' and process['exit_code'] == 0:
                result_path = QUALIFICATION / stage / 'RESULT.json'
                result = read(result_path)
                need(result['status'] == 'PASS' and result['adapter_freeze'] == pin(A / 'ADAPTER_FREEZE.json'), 'Offline child authority')
                row.update(status='PASS', result=pin(result_path))
            else:
                row.update(status='UNKNOWN_RESOURCE' if process['status'] == 'UNKNOWN_RESOURCE' else 'FAIL_PROCESS', process_status=process['status'])
                stopped = True
        except Exception as error:
            row.update(status='FAIL', error=type(error).__name__ + ': ' + str(error))
            stopped = True
    pin_error = None
    try:
        frozen_inputs()
    except Exception as error:
        pin_error = repr(error)
    result = {'schema': 'normalized-eleven-offline-qualification-v1', 'status': 'PASS' if not pin_error and all(row['status'] == 'PASS' for row in rows) else 'FAIL_OR_INCOMPLETE',
        'finished_utc': now(), 'elapsed_seconds': time.monotonic() - start, 'deadline_utc': deadline.isoformat(),
        'adapter_freeze': pin(A / 'ADAPTER_FREEZE.json'), 'decision': pin(args.decision), 'rows': rows, 'input_pin_error': pin_error,
        'native_calls': 0, 'compiler_calls': 0, 'retries': 0, 'supervisor_lineage': supervisor_lineage(), 'full_reset_uses': 0}
    save(QUALIFICATION / 'RESULT.json', result)
    print(result['status'])
    return 0 if result['status'] == 'PASS' else 2


if __name__ == '__main__':
    raise SystemExit(main())
