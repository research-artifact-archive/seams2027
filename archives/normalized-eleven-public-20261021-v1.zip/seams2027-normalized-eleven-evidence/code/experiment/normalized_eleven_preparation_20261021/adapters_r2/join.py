"""Bind exact saved arenas before comparing complete region functions.

All BDD loading/equality/witness operations use the frozen existing BDD core.
A same-model region difference is an explicit observation, never UNKNOWN.
"""
from pathlib import Path
import json
import sys
from common import A, R, E, F, PIPELINE, frozen_inputs, load, need, owned_arm, pin, read, row_for, save, verify


def model_join(left, right):
    j = load('eleven_existing_arena_join', E / 'corpus_comparison/model_join.py')
    a, b = read(Path(left) / 'model.json'), read(Path(right) / 'model.json')
    for key in ('fixture_id', 'case_id', 'variant'):
        need(a[key] == b[key], 'Model identity mismatch: ' + key)
    need(Path(a['input']['path']).samefile(b['input']['path']), 'Model source location mismatch')
    # Retain the narrower, already qualified diagnostic exception and its list.
    identity = load('eleven_existing_diagnostic_identity', F / 'model_identity.py')
    diagnostics = identity.compare_models({'source_inventory': a['source_inventory']}, {'source_inventory': b['source_inventory']})
    result = j.original_model_join(left, right)
    result['diagnostic_identity_differences'] = diagnostics
    return j, result


def native_ref(folder, ref):
    need(Path(ref['file']).name == ref['file'], 'Native BDD basename')
    p = pin(Path(folder) / ref['file'])
    need(all(p[key] == ref[key] for key in ('bytes', 'sha256')), 'Native BDD byte pin')
    return p


def historical_authority(row):
    """Do not reinterpret eleven certificates as the public425 proof schema."""
    cp = verify(row['existing_model_certificate'])
    pp = verify(row['existing_native_process'])
    rp = verify(row['existing_runtime_binding'])
    certificate, process, runtime = read(cp), read(pp), read(rp)
    folder = Path(row['original_model']['path']).parent
    result = pin(folder / 'result.json')
    equality = read(verify(row['existing_full_region_equality']))
    cooperative = next(item for item in row['saved_comparator_inputs'] if item['policy'] == 'cooperative')
    matched = [item for item in equality['original_inputs_matched'] if item['policy'] == 'cooperative']
    need(len(matched) == 1, 'Historical comparison needs one cooperative input binding')
    bound_result = dict(matched[0]['result'])
    bound_result['path'] = str((R / bound_result['path']).resolve())
    verify(bound_result)
    checks = {
        'certificate_exact_model': certificate['model_sha256'] == row['original_model']['sha256'],
        'certificate_exact_result': certificate['result_sha256'] == result['sha256'],
        'original_model_audit_pass': certificate['original_model_audit']['status'] == 'PASS',
        'process_completed': process['status'] == 'PROCESS_COMPLETED' and process['returncode'] == 0,
        'child_reaped_and_contained': process['child_reaped'] is True and process['process_group_contained'] is True,
        'process_binds_model': row['original_model'] in process['artifacts'].values(),
        'process_binds_result': result in process['artifacts'].values(),
        'runtime_origins_pass': runtime['status'] == 'PASS_OBSERVED_RUNTIME_ORIGINS' and runtime['complete_production_identity_check'] is True,
        'historical_full_region_comparison': equality['status'] == 'PASS' and equality['full_region_comparison'] is True,
        'historical_comparison_binds_exact_saved_K_result': bound_result == cooperative['result'],
    }
    need(all(checks.values()), 'Historical eleven evidence authority failed: ' + repr(checks))
    return {'checks': checks, 'certificate': row['existing_model_certificate'], 'process': row['existing_native_process'],
            'runtime': row['existing_runtime_binding'], 'full_region_comparison': row['existing_full_region_equality'],
            'scope': 'Saved original-model certificate, source-qualified native regions and exact historical full-region comparison. Not an independent proof that no cooperative controller exists.',
            'public425_PROCESS_RESULT_schema_claimed': False}


def compare_regions(b, model, left_pin, right_pin, thetaE, thetaS, new_initial):
    # Fixed cohort boundary: all original fields (including enum AUX) have two
    # values and one current/next bit with both Boolean encodings represented.
    # Thus raw XOR states are typed. No broader-domain mapping is implemented.
    for field in model['fields']:
        need(field['domain_size'] == len(field['values']) == 2
             and len(field['current_bits']) == len(field['next_bits']) == 1, 'Outside fixed two-valued single-bit carrier')
        for phase, bits in [('current', field['current_bits']), ('next', field['next_bits'])]:
            encodings = [field['encoding'][value][phase] for value in field['values']]
            need(all(set(item) == {str(bits[0])} and type(item[str(bits[0])]) is bool for item in encodings)
                 and {item[str(bits[0])] for item in encodings} == {False, True}, 'Incomplete Boolean encoding of typed carrier')
    current = model['all_current_bits']
    field_bits = [bit for field in model['fields'] for bit in field['current_bits']]
    need(len(field_bits) == len(set(field_bits)) == len(current) and set(field_bits) == set(current),
         'Typed fields must partition every original current bit')
    roots = []
    for ref in (left_pin, right_pin):
        path = verify(ref)
        root, meta = b.read_native(path.read_bytes())
        need(b.support(root) <= set(current), 'Region next/unowned support')
        need(meta['order'] is None or meta['order'] == model['bdd_variable_order'], 'Region encoding order')
        roots.append(root)
    difference = b.apply('xor', roots[0], roots[1])
    result = {'left': left_pin, 'right': right_pin, 'exact_function_equal': difference == 0,
              'status': 'EXACT_REGION_MATCH' if difference == 0 else 'SAME_MODEL_REGION_MISMATCH',
              'new_native_original_initializer_verdict': new_initial, 'witness': None,
              'typed_XOR_scope': 'Fixed11 full two-valued single-bit carrier, including all AUX values; no untyped encoding exists.'}
    if difference:
        bits = b.satone(difference, current)
        valuation = {}
        for field in model['fields']:
            values = [value for value, encoding in field['encoding'].items()
                      if all(bits[int(bit)] == bit_value for bit, bit_value in encoding['current'].items())]
            need(len(values) == 1, 'Difference witness outside exact original typed domain')
            valuation[field['name']] = values[0]
        result['witness'] = {'valuation': valuation, 'current_bits': {str(k): v for k, v in bits.items()},
            'left_region': b.evaluate(roots[0], bits), 'right_region': b.evaluate(roots[1], bits),
            'original_thetaE': b.evaluate(thetaE, bits), 'original_thetaS': b.evaluate(thetaS, bits),
            'original_joint_initializer': b.evaluate(thetaE, bits) and b.evaluate(thetaS, bits),
            'scope': 'One full typed/AUX difference state. This witness does not replace forall_ENV_exists_SYS_AUX initial quantification.'}
    return result


def join_saved(row, second, record=None, observation_sink=None):
    first = verify(row['original_model']).parent
    if record is None:
        record = {}
    record.update(schema='normalized-eleven-original-model-region-join-v1', id=row['id'], pipeline=PIPELINE,
                  status='UNKNOWN_JOIN_INCOMPLETE', stop_continuation=False, native_calls=0,
                  region_observations={}, comparison_complete=False)
    j, record['original_arena'] = model_join(first, second)
    if record['original_arena']['status'] != 'EXACT_ORIGINAL_ARENA_MATCH':
        record.update(status='SOURCE_MODEL_IDENTITY_MISMATCH', stop_continuation=True)
        return record
    cooperative = next(item for item in row['saved_comparator_inputs'] if item['policy'] == 'cooperative')
    cooperative_model = verify(cooperative['model']).parent
    _, record['saved_K_arena'] = model_join(cooperative_model, second)
    if record['saved_K_arena']['status'] != 'EXACT_ORIGINAL_ARENA_MATCH':
        record.update(status='SOURCE_MODEL_IDENTITY_MISMATCH', stop_continuation=True)
        return record
    record['historical_authority'] = historical_authority(row)
    record['original_model_identity_established'] = True
    old_cooperative = read(verify(cooperative['result']))
    need(native_ref(cooperative_model, old_cooperative['final_region']) == cooperative['region'], 'Saved K/result pin binding')
    new = read(Path(second) / 'result.json')
    model = read(Path(second) / 'model.json')
    record['new_result'] = pin(Path(second) / 'result.json')
    record['new_original_initializer_verdict'] = new.get('initial_in_region')
    if new['status'] == 'COMPLETE_VACUOUS_INITIALIZER':
        record.update(status='EXACT_ORIGINAL_ARENA_MATCH', region_comparison='NOT_APPLICABLE_VACUOUS_INITIALIZER')
        return record
    b = j.sem.BDD(model['bdd_variable_count'])
    thetaE = b.read_native(verify(native_ref(second, model['original_bdds']['thetaE'])).read_bytes())[0]
    thetaS = b.read_native(verify(native_ref(second, model['original_bdds']['thetaS'])).read_bytes())[0]
    record['V_comparison'] = compare_regions(b, model, row['saved_V'], native_ref(second, new['V']), thetaE, thetaS, new.get('initial_in_region'))
    record['region_observations']['V'] = record['V_comparison']
    if not record['V_comparison']['exact_function_equal']:
        record.update(status='SAME_MODEL_REGION_MISMATCH', stop_continuation=True, differing_regions=['V_comparison'])
    if observation_sink:
        observation_sink('V', record)
    record['native_region_join_saved_K'] = compare_regions(b, model, cooperative['region'], native_ref(second, new['final_region']), thetaE, thetaS, new.get('initial_in_region'))
    record['region_observations']['K'] = record['native_region_join_saved_K']
    differences = [key for key in ('V_comparison', 'native_region_join_saved_K') if not record[key]['exact_function_equal']]
    record['status'] = 'SAME_MODEL_REGION_MISMATCH' if differences else 'EXACT_ORIGINAL_ARENA_AND_REGIONS_MATCH'
    record['differing_regions'] = differences
    record['stop_continuation'] = 'V_comparison' in differences
    record['comparison_complete'] = True
    record['continuation_policy'] = 'A V difference stops for cause review; final/K difference is retained as an observation and does not reorder, retry or reconfigure any cell.'
    if observation_sink:
        observation_sink('K', record)
    return record


def main():
    need(len(sys.argv) == 3, 'Usage: join.py fixture_id exact_arm')
    frozen_inputs()
    row = row_for(sys.argv[1])
    arm = owned_arm(sys.argv[2], row['id'])
    result = {'schema': 'normalized-eleven-original-model-region-join-v1', 'id': row['id'], 'pipeline': PIPELINE,
              'status': 'UNKNOWN_JOIN_INCOMPLETE', 'stop_continuation': False, 'region_observations': {}, 'native_calls': 0}
    def observation_sink(phase, record):
        save(arm / ('REGION_OBSERVATION_' + phase + '.json'),
             {'schema': 'normalized-eleven-durable-region-observation-v1', 'phase': phase, 'record': record,
              'scope': 'Observation saved after exact source/model identity. Process/stage completion remains a separate condition.'})
    try:
        decode = load('eleven_existing_lossless_decode', E / 'kind_corpus_rle/decode.py')
        capture = decode.verify_stream(arm / 'stdout.txt.gz')
        end = read(arm / 'RLE_STDOUT_RECEIPT.json')
        need(capture['status'] == 'PASS' and capture['cap_reached'] is False, 'Incomplete native RLE capture')
        need(all(capture[key] == end[key] for key in ('raw_bytes', 'raw_sha256', 'repeated_lines', 'data_records', 'cap_reached')), 'Native RLE receipt mismatch')
        save(arm / 'RLE_CAPTURE_VERIFICATION.json', capture)
        join_saved(row, arm, result, observation_sink)
    except Exception as error:
        resource = type(error).__name__ == 'ResourceRefusal'
        mismatch = any(item['status'] == 'SAME_MODEL_REGION_MISMATCH' for item in result.get('region_observations', {}).values())
        failure = 'UNKNOWN_JOIN_RESOURCE' if resource else 'UNKNOWN_JOIN_INTEGRITY'
        result.update(completion_status=failure, comparison_complete=False,
                      error=type(error).__name__ + ': ' + str(error),
                      stop_continuation=result.get('stop_continuation', False) or not resource)
        result['status'] = 'SAME_MODEL_REGION_MISMATCH' if mismatch else failure
    save(arm / 'MODEL_JOIN.json', result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 2 if result['stop_continuation'] or result['status'].startswith('UNKNOWN') else 0


if __name__ == '__main__':
    raise SystemExit(main())
