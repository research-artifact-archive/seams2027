# Source and license boundaries

The accompanying BSD license covers original artifact contributions. It does not supply an aggregate license for third-party material named by historical records.

The eleven reconstructed specifications derive from publisher listings in [arXiv:2609.12231v1](https://arxiv.org/abs/2609.12231v1). Their source bytes, the shared donor listing, raw listings and diffs are omitted. `tools/PAPER_SOURCE_FETCH_MANIFEST.json` identifies twelve listings and the operations needed to reconstruct the eleven exact external inputs. The unchanged helper obtains them directly from the publisher and checks the recorded identities. Retrieval and reconstruction do not extend redistribution rights.

No JDK/Python installation, third-party JAR, native library, compiled class, upstream source tree or paper PDF is distributed here. Historical class namespaces, URLs and hashes record provenance; they do not imply inclusion or regeneration of those dependencies.

The saved models, BDDs, controller graphs, original checkers and experiment records are artifact evidence. The explicit original/copy ledger documents presentation changes without replacing the historical record. Public source-binding and consumer code is original artifact code; its scope is the saved-input check documented in README.md.
