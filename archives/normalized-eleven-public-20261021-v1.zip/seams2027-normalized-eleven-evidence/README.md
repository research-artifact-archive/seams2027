# Normalized eleven: saved evidence and consumer

This archive records the existing original-V-restricted normalized four-fixed-point route with its unchanged generic construction on eleven replacement contracts. Eight cooperatively feasible contracts produced graphs accepted by the existing graph checker; three empty-V contracts received independently checked semantic refusals. The original initializers were retained. All eleven original arenas and full V/K functions match their saved comparators.

The alternative route is a whole-route result. It is not an algorithm ablation, a paired success-rate or timing comparison with residual-entry runs, a deployment experiment, or evidence that an extraction intervention is necessary. The separate same-game/same-memory final-selection intervention remains a sufficient local rescue. This extension does not enlarge the original fourteen-model regression qualification.

| Contract | Saved result | Graph nodes / edges |
|---|---|---:|
| Arbiter preferred | Empty V; controller flags null | — |
| Arbiter trivial 1 | Strict, nonconflicting and kind accepted | 56 / 448 |
| Lift preferred | Empty V; controller flags null | — |
| Lift trivial 1 | Strict, nonconflicting and kind accepted | 154 / 1176 |
| Minepump preferred | Empty V; controller flags null | — |
| Minepump trivial 1 | Strict, nonconflicting and kind accepted | 12 / 40 |
| Minepump trivial 2 | Strict, nonconflicting and kind accepted | 4 / 16 |
| Traffic single preferred | Strict, nonconflicting and kind accepted | 28 / 152 |
| Traffic single trivial 1 | Strict, nonconflicting and kind accepted | 20 / 120 |
| Traffic updated preferred | Strict, nonconflicting and kind accepted | 116 / 546 |
| Traffic updated trivial 1 | Strict, nonconflicting and kind accepted | 84 / 640 |

`RESULTS.json` indexes the adopted historical results. New consumer receipts are written to a separate work directory; the outer repository's `NORMALIZED_ELEVEN_VALIDATION.json` records the release qualification. Historical records inside `evidence/` retain their original stage and approval language. They are evidence of prior work, not current execution or publication authority.

## Restore the external source files

The eleven paper-derived specifications are intentionally omitted. The unchanged source-only helper retrieves the versioned publisher HTML, reconstructs the specified listings and enforces exact raw, reconstructed, diff and source byte identities. It reports whether the whole HTML hash matches the historical snapshot; that whole-HTML match is not required. Its manifest contains twelve listings because one additional original listing supplies the shared pattern text. No checker or synthesis process is invoked by this helper.

From the extracted archive directory, run:

```sh
python3 -I -B tools/fetch_paper_sources.py --output-root ../normalized-eleven-restored
```

The eleven consumer source files will be under `../normalized-eleven-restored/sources/`. A previously obtained exact publisher HTML can be supplied with `--html /path/to/publisher-v1.html`. Downloaded material remains under its publisher's terms; see `THIRD_PARTY_NOTICES.md`. Source-fetch success is a separate operation from the saved consumer check. The release qualification uses separately prepared exact source files and does not claim a new fetch of those files.

## Check saved semantics

Use Python 3.10 or later on a POSIX platform with `setitimer`. No external Python package, Java runtime, compiler or native synthesis library is required. Use a new work directory whose parent exists, outside both the extracted archive and source directory:

```sh
python3 -I -B consumer/check_saved.py \
  --source-root ../normalized-eleven-restored/sources \
  --work-dir ../normalized-eleven-check
```

The consumer checks the complete `MANIFEST.json` closure, the exact eleven-source roster, ten original scientific module identities and all current model/result/controller byte bindings before scientific imports. It copies the saved inputs and external sources into the new directory and checks all 33 model-to-source identities. The source file shared by each new arm and its V/K comparators is the same copied file, with exact bytes, fixture, case and variant.

It then invokes the unchanged graph checker on eleven arms, compares 22 original arenas, compares 22 full typed V/K functions by XOR emptiness, and verifies eleven lossless stdout captures. All fields of each newly generated semantic certificate must match the historical certificate, except six explicitly listed top-level provenance fields. Graph checks retain ordered fields, logical AUX, original initial/safety predicates, ordered justices and the quantified `forall_ENV_exists_SYS_AUX` original-initialization obligation. Null controller flags for empty-V refusals remain distinct from a rejected graph.

`CONSUMER_RESULT.json` reports `PASS` only after all eleven rows and a final input-integrity check succeed. Per-row certificates, comparisons and capture receipts remain under `results/`. Failures and partial output are retained; use a different new work directory for any deliberately authorized later run. The wrapper has a 60-second whole-invocation wall cap, a 64 MiB individual-file cap and a 256 MiB input-bundle cap, with additional resource limits where supported. A resource limit or incomplete run is not a scientific refusal.

Adding `--preflight-only` validates closure, source identity and current dependent pins without importing scientific modules or running BDD/graph checks. This mode is useful for the release's isolated malformed-input controls. Its `PASS_PREFLIGHT_ONLY` status is not a semantic qualification.

## Identity and evidence boundaries

All 760 saved execution-output files are included as exact copies or explicitly declared presentation copies. Comparator models, original predicates/justices, V/K exports, the ten existing scientific modules, adapter provenance, selected original review records and source-restoration code are also included. BDDs, mathematical data and existing scientific code retain their bytes. No graph nodes, edges, valuations, ranks, flags, source AST, initializer, justice, count, verdict, solver result or historical timing was altered.

`ORIGINAL_COPY_LEDGER.json` binds every exported original file and current public copy and records every changed JSON leaf. `METADATA_ALLOWLIST.json` lists the exact allowed pointers and confirms equality of all other JSON structure and values. Known private path prefixes become neutral `origin:` or `host:` provenance labels. Current model source locations become `sources/<id>.spectra`; current controller and result hashes bind the derived public files. These current identities are distinct from preserved historical certificate, runtime and process hashes. The latter are attestations about original files and do not imply that every referenced dependency is distributed. `SOURCE_PIN_MANIFEST.json` and `OMISSIONS.json` make this distinction explicit.

The new portable source binder verifies exact separately supplied source bytes and absence of imports. It replaces only the original checker's `load_profile` and `FREEZE_SHA256` bindings. It does not rerun the private raw/diff/profile binder, independently compile source semantics, validate a new producer installation, or supply a second graph-judge implementation. The checkers share the parser-translated BDD model. All generic construction and scientific checker code is unchanged; the new wrapper supplies portable input bindings and bounded orchestration only.

The archive contains no producer runtime, Java bytecode, upstream JARs/native libraries, publisher source payloads, main manuscript, main title or private inventory. This saved-input qualification establishes reproducibility of the listed checks on the released inputs, within those stated boundaries.
