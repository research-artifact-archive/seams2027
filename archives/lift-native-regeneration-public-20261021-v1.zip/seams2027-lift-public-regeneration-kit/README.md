# Lift public regeneration kit

This kit exposes the controls for one bounded Lift regeneration and a separate saved node 680 certificate. The scientific source, dependency, profile and checker identities are fixed. The experimental continuation-preference extractor remains a nonrelease variant for the declared Lift instance.

The preceding local run obtained 165 public payloads, restored 14 source files, compiled all six custom Java sources to the expected 19 classes, checked 164 dependency JARs and class origins, and generated one pair from the same model and memory. Both complete graph checkers agreed: baseline 154 states / 1170 edges, strict true and cooperative false; variant 154 / 1176, both true. Anonymous copies under `evidence/local_qualification` attest to that prior local run. They are not results of this newly configured kit.

**This distributed control copy requires its own qualification at a declared placement.** Static checks, copying, anonymous path labels and a configuration receipt do not establish an executed regeneration. A separate execution decision must bind the exact generated plan and freeze.

## Runtime and isolation

Supply the exact installed JDK tree and Python executable identified by `host_runtime/INSTALLED_RUNTIME_PINS.json`. The configurator verifies all 565 JDK entries, internal symlink targets and executable hashes. A different JDK distribution or version is an identity mismatch. No public JDK restoration is supplied.

Python's standard library, macOS, the CA store and platform libraries remain host supplied. The sandbox excludes old-workspace file contents, allows only required ancestor metadata and denies directory listings. It is not an OS hermeticity claim. The parent supervisor samples filesystem metadata within the fresh run for its aggregate cap.

macOS `/usr/bin/sandbox-exec` is required by this implementation. Other operating systems have not been qualified. Use the pinned Python with `-I -S -B`; do not enable optimization. Run directories must be fresh and disjoint from the immutable kit.

## Prepare one regeneration

Use explicit paths; the following command only verifies identities and creates configuration files. Each `--deny-probe` is an existing file in the denied workspace that the sandbox must later reject. Include old custom classes, JARs, sources and prior result or cache files when they exist.

```sh
"$PINNED_PYTHON" -I -S -B configure_run.py \
  --jdk-home "$JDK_HOME_FOR_THIS_RUN" \
  --python "$PINNED_PYTHON" \
  --workspace-deny-root "$EXCLUDED_WORKSPACE" \
  --deny-probe "$EXISTING_EXCLUDED_FILE" \
  --output "$FRESH_RUN" \
  --deadline-utc "$UTC_DEADLINE"
```

Inspect `PLAN.json`, both sandbox profiles, `ISOLATION_CONTROLS.json` and `FROZEN_LAUNCHER.json` in that output. A new `EXECUTION_AUTHORIZATION.json` is required before execution: status `GO`, and `plan` and `freeze` equal to the actual `{path, bytes, sha256}` pins of those two files. The completed author's authorization is deliberately absent.

After independent review and that run-specific decision, the single execution command is:

```sh
"$PINNED_PYTHON" -I -S -B "$FRESH_RUN/launch_public.py" execute
```

The launcher makes 165 serial initial HTTPS requests, each with exact length/hash and a 30-second worker cap, within a 600-second acquisition cap. It records redirects, limits them to three validated HTTPS destinations, reads no redirect/error bodies, and never retries. The fixed response-body retention allowance is 128 MiB; this is not a wire-byte quota. All acquisition finishes before offline restoration, compilation, one native pair and four checker jobs. The whole run is limited to 30 minutes or the supplied hard deadline, whichever is earlier. Per-child RSS and the fresh-run tree have the fixed limits in the plan. Any mismatch, limit or incomplete process remains failure or UNKNOWN with retained evidence.

Historical controller/model/BDD members of the public archive are excluded from native regeneration. The 18 selected source/metadata/checker members supply 23 destinations; the raw ZIP becomes unreadable to offline children. No private historical output is an input to generation or checking.

## Saved node 680 certificate

This mode reads the fixed saved public evidence in the separately obtained base package `seams2027-lift-causal-extension`, plus its exact restored source tree. Its base ZIP identity is 2,986,678 bytes, SHA256 `64ba40d58edd2b5b04a7583c4e5ee32fe184b9d5c264026201fcfa5b4b747d07`. Its immutable public URL is recorded in `manifests/FETCH_MANIFEST.json`.

The public model has an anonymous input label and a distinct digest. The saved controller still binds the historical digest. The wrapper verifies the public manifest and original/copy ledger, uses the pinned existing metadata bridge, and permits only the declared model/export digest updates. It checks that every model byte, BDD, node, edge, valuation, rank, successor and typed predicate is unchanged. It then explicitly checks every node's typed valuation/current-bit correspondence and that the sole original/solver ENV justice is exactly NOT helper.

The finite residual establishes strict winning from the complete source valuation at node 680 with helper false. All 16 original source inputs have three safe responses, but no original-legal next input; all 16 native-legal inputs flip helper. The 321-state / 5136-edge residual covers every legal input and remains safe with helper true, falsifying the sole ENV justice forever. This is a state-winning certificate. It does not equate the entire raw core to the strict winning region, require initial reachability, identify extraction as the unique root cause, or establish a general repair.

Use a fresh output and a separate authorization with status `GO`, `inputs` equal to the ordered actual pins of `focused/check_node680.py`, `focused/model_bindings.py`, and `focused/INPUTS.json`, and `output` equal to the resolved fresh output path. Run under the reviewed supervisor with network denied, 60 seconds wall time, 512 MiB RSS, 16 MiB file cap, 8 MiB per stream and 64 MiB output cap:

```sh
"$PINNED_PYTHON" -I -S -B focused/check_node680.py \
  --bundle "$VERIFIED_PUBLIC_BASE" --sources "$PUBLIC_RESTORED_SOURCES" \
  --out "$FRESH_FOCUSED_OUTPUT" --authorization "$FOCUSED_AUTHORIZATION"
```

The wrapper does not fetch, compile, solve or extract a controller. Its BDD decoder is the same pinned public decoder; the certificate is not an independent compiler. Archived presentation files under `evidence/focused_original` preserve the original hashes and conclusion in the original/copy ledger. A new check produces a distinct receipt.

## Static checks and identity records

The synthetic guard command reads no public data and creates only a fresh report directory:

```sh
"$PINNED_PYTHON" -I -S -B regenerate/qualify_public_guards.py "$FRESH_GUARD_OUTPUT"
"$PINNED_PYTHON" -I -S -B tests/check_static.py "$FRESH_STATIC_OUTPUT"
```

`MANIFEST.json` lists every distributed file. `ORIGINAL_COPY_LEDGER.json` records original and public identities separately, including explicit path-label transformations. `OMISSIONS.json` records the omitted local runtime, caches, permissions and private evidence. A digest for historical author bytes is an attestation and must not be presented as the digest of an anonymously reserialized file.
