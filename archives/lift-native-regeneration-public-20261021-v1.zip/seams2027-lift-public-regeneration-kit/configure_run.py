"""Materialize a fresh, machine-bound control directory; never execute it."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import argparse
import copy
import hashlib
import json
import shutil
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent


def need(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    def unique(pairs):
        out = {}
        for key, value in pairs:
            need(key not in out, 'Duplicate JSON key: ' + key)
            out[key] = value
        return out
    return json.loads(Path(path).read_text(), object_pairs_hook=unique)


def pin(path):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), 'Regular file required: ' + str(path))
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def matches(path, ref):
    got = pin(path)
    need(all(got[k] == ref[k] for k in ('bytes', 'sha256')), 'Identity mismatch: ' + str(path))
    return got


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def relative(name):
    value = PurePosixPath(name)
    need(name and not value.is_absolute() and '\\' not in name
         and all(x not in ('', '.', '..') for x in name.split('/')), 'Unsafe relative path')
    return value


def verify_kit():
    manifest = load(HERE / 'MANIFEST.json')
    need(manifest['schema'] == 'public-reproduction-kit-manifest-v1', 'Kit manifest schema')
    declared = set()
    for row in manifest['files']:
        name = row['path']
        need(name not in declared, 'Duplicate kit member')
        declared.add(name)
        path = HERE.joinpath(*relative(name).parts)
        need(path.resolve().is_relative_to(HERE), 'Kit member escape')
        matches(path, row)
    actual = {p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file() or p.is_symlink()}
    need(actual == declared | {'MANIFEST.json'}, 'Unexpected or absent kit member')
    return pin(HERE / 'MANIFEST.json')


def sbpl_path(path):
    value = str(path)
    need(not any(ord(ch) < 32 for ch in value), 'Control character in sandbox path')
    return json.dumps(value, ensure_ascii=False)


def sandbox(workspace, output, offline):
    need(output != workspace and output.is_relative_to(workspace), 'Fresh run must be a strict child of denied workspace')
    ancestors = []
    item = output.parent
    while item.is_relative_to(workspace):
        ancestors.append(item)
        if item == workspace:
            break
        item = item.parent
    base = '(require-all (subpath ' + sbpl_path(workspace) + ') (require-not (subpath ' + sbpl_path(output) + '))'
    text = '(version 1)\n(allow default)\n'
    text += '(deny file-read-data ' + base + '))\n'
    text += '(deny file-read-metadata ' + base
    text += ''.join(' (require-not (literal ' + sbpl_path(p) + '))' for p in ancestors) + '))\n'
    if offline:
        text += '(deny network*)\n(deny file-read-data (literal ' + sbpl_path(output / 'downloads/source-package.zip') + '))\n'
    return text, ancestors


def bind_runtime(jdk, python, pins):
    need(len(pins['jdk_inventory']) == pins['jdk_entry_count'] == 565, 'Expected565 JDK entries')
    actual = {p.relative_to(jdk).as_posix(): p for p in jdk.rglob('*') if p.is_file() or p.is_symlink()}
    expected = {row['relative']: row for row in pins['jdk_inventory']}
    need(len(expected) == 565 and set(actual) == set(expected), 'Installed JDK roster differs')
    inventory = []
    for name, row in expected.items():
        path = jdk.joinpath(*relative(name).parts)
        entry = {'relative': name}
        if 'symlink' in row:
            need(path.is_symlink() and str(path.readlink()) == row['symlink'], 'JDK symlink identity differs')
            target = path.resolve(strict=True)
            need(target.is_relative_to(jdk), 'Unpinned external JDK symlink')
            need(target == jdk.joinpath(*relative(row['resolved']['relative']).parts), 'JDK resolved target differs')
            entry['symlink'] = row['symlink']
            entry['resolved'] = matches(target, row['resolved'])
        else:
            need(not path.is_symlink() and row['file']['relative'] == name, 'JDK regular-file role differs')
            entry['file'] = matches(path, row['file'])
        inventory.append(entry)
    return dict(java=matches(jdk/'bin/java', pins['java']), javac=matches(jdk/'bin/javac', pins['javac']),
                python=matches(python, pins['python']), java_home=str(jdk), jdk_inventory=inventory)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--jdk-home', type=Path, required=True)
    parser.add_argument('--python', type=Path, required=True)
    parser.add_argument('--workspace-deny-root', type=Path, required=True)
    parser.add_argument('--deny-probe', type=Path, action='append', required=True,
                        help='Existing file in denied workspace, outside fresh output; repeat for class/JAR/source controls')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--deadline-utc', required=True)
    args = parser.parse_args()
    manifest = verify_kit()
    jdk = args.jdk_home.resolve(strict=True)
    python = args.python.resolve(strict=True)
    workspace = args.workspace_deny_root.resolve(strict=True)
    need(not args.output.exists() and not args.output.is_symlink(), 'Fresh output required')
    output = args.output.resolve()
    need(output.parent.is_dir(), 'Output parent must already exist')
    need(workspace.is_dir() and jdk.is_dir() and python.is_file(), 'Runtime/workspace roles')
    need(not HERE.is_relative_to(output) and not output.is_relative_to(HERE), 'Kit and generated run must be disjoint')
    need(not jdk.is_relative_to(workspace) and not python.is_relative_to(workspace), 'Supplied runtime must be outside denied workspace')
    deadline = datetime.fromisoformat(args.deadline_utc)
    need(deadline.tzinfo is not None and deadline.utcoffset().total_seconds() == 0, 'UTC deadline required')
    need(datetime.now(timezone.utc) < deadline, 'Future hard deadline required')
    acquisition, ancestors = sandbox(workspace, output, False)
    offline, _ = sandbox(workspace, output, True)
    denied = []
    for candidate in args.deny_probe:
        path = candidate.resolve(strict=True)
        need(path.is_file() and path.is_relative_to(workspace) and not path.is_relative_to(output), 'Denied probe must exist in excluded workspace')
        need(path not in denied, 'Duplicate denied probe')
        denied.append(path)
    runtime = bind_runtime(jdk, python, load(HERE/'host_runtime/INSTALLED_RUNTIME_PINS.json'))
    need(pin(Path(sys.executable).resolve()) == runtime['python'], 'Configurator must run under exact declared Python')
    runtime.update(load(HERE/'manifests/RUNTIME_SCIENCE_EXPECTATIONS.json'))
    plan = copy.deepcopy(load(HERE/'manifests/PLAN_TEMPLATE.json'))
    plan.update(schema='public-regeneration-machine-bound-plan-v1', status='PREPARED_NOT_EXECUTED',
                created_utc=datetime.now(timezone.utc).isoformat(), hard_stop_utc=deadline.isoformat(),
                planned_execution_directory=str(output), aggregate_container=str(output),
                entrypoint_scope='New anonymous control copy; no execution or portability claim before its own qualification.',
                execution_prerequisites=['Independent review of exact new kit and generated configuration',
                    'New EXECUTION_AUTHORIZATION.json status GO bound to exact PLAN and FROZEN_LAUNCHER pins',
                    'One fresh run only; no automatic retry'],
                qualification_phase_commands=['pinned Python -I -S -B launch_public.py execute'],
                bootstrap_files=[p.relative_to(HERE/'regenerate').as_posix() for p in sorted((HERE/'regenerate').rglob('*')) if p.is_file()])
    plan['isolation'].update(workspace=str(workspace), allowed_run=str(output), ancestor_metadata_only=[str(x) for x in ancestors],
                             negative_control_files=[str(x) for x in denied])
    output.mkdir()
    for source in sorted((HERE/'regenerate').rglob('*')):
        if source.is_file():
            dest = output / source.relative_to(HERE/'regenerate')
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, dest)
    for name in ['FETCH_MANIFEST.json', 'ARCHIVE_SELECTION.json', 'PUBLIC_PAYLOAD_MAP.json', 'ORIGIN_ROSTER.txt']:
        shutil.copyfile(HERE/'manifests'/name, output/name)
    controls = [dict(path=str(x), operation='read', expected_allowed=False) for x in denied]
    controls += [dict(path=str(jdk/'bin/java'), operation='read', expected_allowed=True),
                 dict(path=str(output/'OriginProbe.java'), operation='read', expected_allowed=True)]
    controls += [dict(path=str(x), operation=op, expected_allowed=op=='stat') for x in ancestors for op in ['stat','list']]
    save(output/'RUNTIME_EXPECTATIONS.json', runtime)
    save(output/'PLAN.json', plan)
    save(output/'ISOLATION_CONTROLS.json', controls)
    (output/'acquisition.sb').write_text(acquisition)
    (output/'isolation.sb').write_text(offline)
    save(output/'CONFIGURATION_RECEIPT.json', dict(status='PREPARED_MACHINE_BINDING_ONLY', kit_manifest=manifest,
         configurator=pin(Path(__file__).resolve()), denied_probe_count=len(denied), network_calls=0,
         Java_invocations=0, science_invocations=0, native_entrypoint_qualified=False,
         runtime_scope=load(HERE/'host_runtime/INSTALLED_RUNTIME_PINS.json')['scope']))
    freeze = dict(schema='public-regeneration-frozen-entrypoint-v2', status='FROZEN_PENDING_INDEPENDENT_REVIEW_AND_EXECUTION_DECISION',
                  created_utc=datetime.now(timezone.utc).isoformat(), plan=pin(output/'PLAN.json'),
                  files=[pin(path) for path in sorted(output.rglob('*')) if path.is_file()],
                  network_fetches_performed=0, java_invocations=0, scientific_checkers_invoked=0)
    save(output/'FROZEN_LAUNCHER.json', freeze)
    print(json.dumps(dict(status='PREPARED_NOT_EXECUTED', plan=pin(output/'PLAN.json'), freeze=pin(output/'FROZEN_LAUNCHER.json'))))


if __name__ == '__main__':
    main()
