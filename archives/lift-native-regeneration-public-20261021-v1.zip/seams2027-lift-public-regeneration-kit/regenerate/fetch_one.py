"""One HTTPS GET, fixed identity, no retry, bounded body, receipt on failure."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import hashlib, json, sys, traceback, urllib.error, urllib.parse, urllib.request

def require(value, message):
    if not value: raise ValueError(message)

def validate_url(url, allowed):
    parsed = urllib.parse.urlsplit(url)
    require(parsed.scheme == 'https' and parsed.hostname in allowed and parsed.port in (None, 443), 'Undeclared URL authority')
    require(parsed.username is None and parsed.password is None and not parsed.fragment, 'URL credentials/fragment forbidden')

class ReturnRedirect(urllib.request.HTTPRedirectHandler):
    """Return redirects without urllib's inherited unbounded fp.read()."""
    def http_error_302(self, req, fp, code, msg, headers):
        return urllib.error.HTTPError(req.full_url, code, msg, headers, fp)
    http_error_301 = http_error_302
    http_error_303 = http_error_302
    http_error_307 = http_error_302
    http_error_308 = http_error_302

def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / 'FETCH_MANIFEST.json').read_text())
    require(len(sys.argv) == 3, 'Fetch id and remaining total body allowance required')
    matches = [x for x in manifest['requests'] if x['id'] == sys.argv[1]]
    require(len(matches) == 1, 'Exact known request required')
    row = matches[0]; policy = manifest['redirects']; allowed = policy['allowed_hosts']
    limit = min(row['max_response_bytes'], int(sys.argv[2]))
    require(limit >= row['bytes'] + 1, 'Insufficient whole-request body budget')
    rel = PurePosixPath(row['destination'])
    require(not rel.is_absolute() and all(x not in ('', '.', '..') for x in row['destination'].split('/')) and '\\' not in row['destination'], 'Unsafe destination')
    target = root.joinpath(*rel.parts)
    require(target.resolve().is_relative_to(root) and not target.exists() and not target.is_symlink(), 'Fresh contained payload required')
    receipt = dict(schema='bounded-public-fetch-v2', id=row['id'], request=row, status='UNKNOWN', started_utc=datetime.now(timezone.utc).isoformat(), automatic_retries=0, redirects=[], body_bytes_read=0, redirect_body_bytes_read=0, http_get_attempts=0, response_body_cap_bytes=limit, errors=[])
    try:
        validate_url(row['url'], allowed)
        target.parent.mkdir(parents=True, exist_ok=True)
        digest = hashlib.sha256()
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), ReturnRedirect())
        current_url = row['url']
        with target.open('xb') as output:
            while True:
                request = urllib.request.Request(current_url, headers={'User-Agent':'Lift-Public-Qualification/1.0', 'Accept-Encoding':'identity'})
                receipt['http_get_attempts'] += 1
                with opener.open(request, timeout=25) as response:
                    receipt.update(http_status=response.status, final_url=response.geturl(), content_length=response.headers.get('Content-Length'), content_encoding=response.headers.get('Content-Encoding'))
                    validate_url(response.geturl(), allowed)
                    if response.status in (301, 302, 303, 307, 308):
                        location = response.headers.get('Location')
                        require(isinstance(location, str) and location, 'Redirect Location required')
                        next_url = urllib.parse.urljoin(current_url, location)
                        receipt['redirects'].append(dict(source=current_url, status=response.status, destination=next_url))
                        require(len(receipt['redirects']) <= policy['maximum'], 'Redirect count cap')
                        validate_url(next_url, allowed)
                        current_url = next_url
                        # Leaving this context closes the redirect without reading its body.
                        continue
                    require(response.status == 200, 'HTTP 200 required')
                    while receipt['body_bytes_read'] < limit:
                        chunk = response.read(min(65536, limit - receipt['body_bytes_read']))
                        if not chunk: break
                        output.write(chunk); output.flush(); digest.update(chunk)
                        receipt['body_bytes_read'] += len(chunk)
                    break
        receipt['sha256'] = digest.hexdigest()
        require(receipt['body_bytes_read'] == row['bytes'], 'Exact response byte count mismatch or body cap')
        require(receipt['sha256'] == row['sha256'], 'Exact response SHA-256 mismatch')
        receipt['status'] = 'PASS_FRESH_HTTPS_BYTES'
    except BaseException as exc:
        receipt['errors'].append(dict(type=type(exc).__name__, message=str(exc), traceback=traceback.format_exc()))
        if isinstance(exc, urllib.error.HTTPError): receipt['http_status'] = exc.code
    finally:
        if target.is_file():
            receipt['persisted_body_bytes'] = target.stat().st_size
            receipt['persisted_sha256'] = hashlib.sha256(target.read_bytes()).hexdigest()
        receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
        with Path('FETCH_RECEIPT.json').open('x') as output: json.dump(receipt, output, ensure_ascii=False, indent=2); output.write('\n')
        print(json.dumps({k:receipt[k] for k in ('id', 'status', 'body_bytes_read', 'redirects')}))
    return 0 if receipt['status'] == 'PASS_FRESH_HTTPS_BYTES' else 1

if __name__ == '__main__': sys.exit(main())
