"""One bounded fresh-public acquisition, source restoration, build, pair, and four audits.

The installed JDK/Python and host OS remain explicitly outside public restoration.
"""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import copy, hashlib, importlib.util, json, os, shutil, sys, time, traceback, zipfile
from urllib.parse import unquote, urlparse
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('clean_helpers',B/'bootstrap/dispatch.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
pin,read,verify,save=h.pin,h.read,h.verify,h.save_new
P=read(B/'PLAN.json');C=read(B/'RUNTIME_EXPECTATIONS.json');F=read(B/'FETCH_MANIFEST.json');M=read(B/'PUBLIC_PAYLOAD_MAP.json')
I=C;EFFECTIVE_STOP=None
spec2=importlib.util.spec_from_file_location('public_payload',B/'public_payload.py')
payload=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(payload)
stage=h.load_stage()
VARIANT='final_candidate_original_env_continuation_preference_v1'
CANDIDATE='lift__trivial_1'
def check(condition,message):
    if not condition:raise ValueError(message)
def deadline(seconds):
    return min(datetime.fromisoformat(P['hard_stop_utc']),EFFECTIVE_STOP or datetime.fromisoformat(P['hard_stop_utc']),datetime.now(timezone.utc)+timedelta(seconds=seconds)).isoformat()
def invoke(label,argv,wall,folder=None,tree=None,tree_limit=67108864,stream=8388608,watched=(),network=False,until=None):
    folder=folder or B/'processes'/label;tree=tree or B/'build'
    limit=min(datetime.fromisoformat(deadline(wall+30)),until or datetime.fromisoformat(deadline(wall+30)))
    check(datetime.now(timezone.utc)<limit,'stage deadline expired')
    return stage.run_bounded(['/usr/bin/sandbox-exec','-f',str(B/('acquisition.sb' if network else 'isolation.sb'))]+argv,folder,limit.isoformat(),wall_seconds=wall,rss_bytes=1073741824,stream_bytes=stream,file_bytes=16777216,watch_files=watched,output_tree=tree,output_tree_bytes=tree_limit,aggregate_tree=Path(P['aggregate_container']),aggregate_tree_bytes=2147483648,min_free_bytes=1073741824)
def require_process(result,label):check(h.valid_process(result),label+' process incomplete; preserved receipt')
def staged_refs():
    refs=list(I.get('input_files',[]))+[I[k] for k in ('java','javac','python')]
    refs += [x['file'] for x in I['jdk_inventory'] if 'file' in x]
    refs += [x['resolved'] for x in I['jdk_inventory'] if x.get('resolved')]
    return list({x['path']:x for x in refs}.values())
def verify_jdk_tree():
    root=Path(I['java_home']);expected={x['relative']:x for x in I['jdk_inventory']}
    actual={str(p.relative_to(root)):p for p in root.rglob('*') if p.is_file() or p.is_symlink()}
    check(set(actual)==set(expected),'JDK file/symlink roster changed')
    for name,row in expected.items():
        path=actual[name]
        if 'symlink' in row:check(path.is_symlink() and str(path.readlink())==row['symlink'],'JDK symlink target changed: '+name)
        else:check(not path.is_symlink(),'JDK regular file became symlink: '+name)
def manifest(folder,process):
    return dict(schema='remaining-nine-independent-audit-inputs-v1',candidate_id=CANDIDATE,inputs=dict(source=I['candidate']['source'],profile=I['profiles'],native_result=pin(folder/'result.json'),model=pin(folder/'model.json'),native_process=process,controller=pin(folder/'controller.json'),printer=pin(folder/'controller.txt')),bdd_files={p.name:pin(p) for p in sorted(folder.glob('*.bdd'))})
def acquire_and_restore(result):
    global I
    network_stop=min(datetime.fromisoformat(deadline(F['network_total_wall_seconds'])),datetime.now(timezone.utc)+timedelta(seconds=F['network_total_wall_seconds']))
    check(len(F['requests'])==165 and len({x['id'] for x in F['requests']})==165 and len({x['destination'] for x in F['requests']})==165,'Exactly 165 unique planned requests')
    check(sum(x['max_response_bytes'] for x in F['requests'])<=F['total_response_body_cap_bytes'],'Worst-case declared response caps fit total body allowance')
    acquisition=[];received=0;http_attempts=0
    for row in F['requests']:
        check(datetime.now(timezone.utc)<network_stop,'Total fetch deadline')
        result['fetch_attempts']+=1
        folder=B/'processes'/('fetch_'+row['id'])
        proc=invoke('fetch_'+row['id'],[C['python']['path'],'-I','-S','-B',str(B/'fetch_one.py'),row['id'],str(F['total_response_body_cap_bytes']-received)],row['hard_process_wall_seconds'],folder=folder,tree=B,tree_limit=2147483648,network=True,until=network_stop)
        path=B/row['destination'];observed=pin(path) if path.is_file() else None
        received+=observed['bytes'] if observed else 0
        entry=dict(id=row['id'],process=pin(folder/'PROCESS_RECEIPT.json'),complete_process=h.valid_process(proc),payload=observed)
        if (folder/'FETCH_RECEIPT.json').is_file():entry['fetch_receipt']=pin(folder/'FETCH_RECEIPT.json')
        acquisition.append(entry)
        h.save_atomic(B/'ACQUISITION_PROGRESS.json',dict(status='RUNNING',requests=acquisition,persisted_body_bytes=received,network_deadline_utc=network_stop.isoformat()))
        require_process(proc,'fresh public '+row['id'])
        check(observed and observed['bytes']==row['bytes'] and observed['sha256']==row['sha256'],'Fresh fetched payload identity')
        fetch_receipt=read(folder/'FETCH_RECEIPT.json');check(fetch_receipt['status']=='PASS_FRESH_HTTPS_BYTES','Complete fresh fetch receipt')
        http_attempts+=fetch_receipt['http_get_attempts']
        check(received<=F['total_response_body_cap_bytes'],'Total response body cap')
    result['fresh_public_payload_bytes']=received;result['http_get_attempts']=http_attempts
    check(received==F['expected_network_payload_bytes'],'Total exact network payload')
    save(B/'ACQUISITION_RESULT.json',dict(status='PASS_ALL_165_FRESH_PUBLIC_PAYLOAD_REQUESTS',initial_payload_requests=165,http_get_attempts_including_redirects=http_attempts,requests=acquisition,persisted_body_bytes=received,finished_utc=datetime.now(timezone.utc).isoformat(),network_deadline_utc=network_stop.isoformat()))
    extracted=payload.extract_selected(B,P,read(B/'ARCHIVE_SELECTION.json'),h)
    gr1=next(x for x in F['requests'] if x['id']=='jar_009')
    fresh_gr1=B/gr1['destination'];cache=B/'source_cache'/fresh_gr1.name.split('_',1)[1]
    with cache.open('xb') as stream:stream.write(fresh_gr1.read_bytes())
    check(pin(cache)['sha256']==gr1['sha256'],'Fresh in-attempt source JAR cache')
    recipe=B/'public_payload'/M['source_recipe']['member']
    proc=invoke('restore_public_sources',[C['python']['path'],'-I','-S','-B',str(recipe),'--output-root',str(B/'restored'),'--cache',str(B/'source_cache')],60,tree=B,tree_limit=2147483648)
    require_process(proc,'offline public source restoration')
    restoration=read(B/'restored/SOURCE_RESTORATION_RECEIPT.json')
    check(restoration['status']=='PASS_EXACT_SOURCE_BYTE_RESTORATION_ONLY' and restoration['source_files_restored']==14,'Complete 14 public restored sources')
    check(len(restoration['acquisition'])==2 and all(x['mode']=='VERIFIED_CACHE' for x in restoration['acquisition']),'Restoration uses only current-attempt verified downloads')
    I=payload.materialize_inventory(B,C,F,M,h)
    I['input_files']+=extracted+[pin(B/x['destination']) for x in F['requests']]+[pin(cache),pin(B/'restored/SOURCE_RESTORATION_RECEIPT.json')]
    save(B/'INPUT_INVENTORY.json',I)
    save(B/'SOURCE_PROVENANCE.json',dict(status='PASS_PUBLIC_SOURCE_AND_DEPENDENCIES_UNDER_INSTALLED_JDK',fresh_fetches=pin(B/'ACQUISITION_RESULT.json'),selective_extraction=pin(B/'ARCHIVE_EXTRACTION_RECEIPT.json'),source_restoration=pin(B/'restored/SOURCE_RESTORATION_RECEIPT.json'),inventory=pin(B/'INPUT_INVENTORY.json'),historical_scientific_payload_copied_into_run=False,host_supplied_runtime=P['isolation']['runtime'],not_hermetic=P['isolation']['not_hermetic']))
    return staged_refs()

def main():
    global EFFECTIVE_STOP
    check(len(sys.argv)==2 and sys.argv[1]=='execute','explicit execute required')
    go=read(B/'EXECUTION_AUTHORIZATION.json');check(go['status']=='GO' and go['plan']==pin(B/'PLAN.json') and go['freeze']==pin(B/'FROZEN_LAUNCHER.json'),'Fresh execution authorization bound to exact plan and freeze required')
    freeze=read(B/'FROZEN_LAUNCHER.json');verify(freeze['files']);refs=staged_refs();verify(refs);verify_jdk_tree()
    check(pin(Path(sys.executable).resolve())==C['python'],'Exact pinned launcher Python required')
    javac_injection_removed='JDK_JAVAC_OPTIONS' in os.environ
    os.environ.pop('JDK_JAVAC_OPTIONS',None)
    EFFECTIVE_STOP=min(datetime.fromisoformat(P['hard_stop_utc']),datetime.now(timezone.utc)+timedelta(seconds=P['maximum_whole_qualification_seconds']))
    check(datetime.now(timezone.utc)<EFFECTIVE_STOP,'investigation hard stop reached')
    check(not (B/'SUMMARY.json').exists() and not (B/'RUN_STARTED.json').exists(),'no retries')
    save(B/'RUN_STARTED.json',dict(started_utc=datetime.now(timezone.utc).isoformat(),effective_deadline_utc=EFFECTIVE_STOP.isoformat(),root_go=pin(B/'EXECUTION_AUTHORIZATION.json'),native_attempt_limit=1,fetch_attempt_limit=165,owner_pid=os.getpid()))
    result=dict(schema='public-source-dependency-regeneration-result-v1',status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),effective_deadline_utc=EFFECTIVE_STOP.isoformat(),fetch_attempts=0,native_pair_attempts=0,audit_attempts=0,JDK_JAVAC_OPTIONS_removed_from_this_launcher_environment=javac_injection_removed,host_supplied_runtime=P['isolation']['runtime'],not_hermetic=P['isolation']['not_hermetic'],errors=[])
    generated_refs=[]
    try:
        proc=invoke('initial_isolation_controls',[C['python']['path'],'-I','-S','-B',str(B/'qualify_isolation.py'),str(B/'ISOLATION_CONTROLS.json')],30,tree=B,tree_limit=2147483648)
        require_process(proc,'initial isolation controls');checks=json.loads((B/'processes/initial_isolation_controls/stdout.txt').read_text());check(all(x['pass_check'] for x in checks),'initial isolation controls failed')
        save(B/'INITIAL_ISOLATION_RESULT.json',dict(status='PASS',checks=checks,process=pin(B/'processes/initial_isolation_controls/PROCESS_RECEIPT.json')))
        refs=acquire_and_restore(result);verify(refs);verify_jdk_tree()
        final_controls=read(B/'ISOLATION_CONTROLS.json')+[dict(path=str(B/'downloads/source-package.zip'),operation='read',expected_allowed=False),dict(path=I['sources'][0]['path'],operation='read',expected_allowed=True)]
        save(B/'OFFLINE_ISOLATION_CONTROLS.json',final_controls)
        proc=invoke('offline_isolation_controls',[I['python']['path'],'-I','-S','-B',str(B/'qualify_isolation.py'),str(B/'OFFLINE_ISOLATION_CONTROLS.json')],30,tree=B,tree_limit=2147483648)
        require_process(proc,'offline isolation controls');checks=json.loads((B/'processes/offline_isolation_controls/stdout.txt').read_text());check(all(x['pass_check'] for x in checks),'offline isolation controls failed')
        save(B/'ISOLATION_RESULT.json',dict(status='PASS',checks=checks,process=pin(B/'processes/offline_isolation_controls/PROCESS_RECEIPT.json')))
        build=B/'build';build.mkdir(exist_ok=False);classes=build/'classes';classes.mkdir();empty=build/'empty_sourcepath';empty.mkdir()
        run=B/'run_01';run.mkdir(exist_ok=False)
        cp=':'.join(p['path'] for p in I['ordered_jars'])
        compile_cmd=[I['javac']['path'],'-J-Xmx512m','-encoding','UTF-8','-proc:none','-implicit:none','-sourcepath',str(empty),'-cp',cp,'-d',str(classes)]+[x['path'] for x in I['sources']]
        proc=invoke('compile_all_six',compile_cmd,120);require_process(proc,'compile all six')
        actual={str(p.relative_to(classes)):pin(p) for p in sorted(classes.rglob('*.class'))}
        generated_refs=list(actual.values())
        expected={x['relative']:x for x in I['custom_class_roster']};check(set(actual)==set(expected),'exact 19 fresh-class roster')
        matches={k:actual[k]['sha256']==v['historical']['sha256'] for k,v in expected.items()}
        compiled=dict(status='PASS' if all(matches.values()) else 'UNKNOWN_CLASS_BYTE_MISMATCH',sources=I['sources'],classes=actual,historical_byte_parity=matches,command=compile_cmd,process=pin(B/'processes/compile_all_six/PROCESS_RECEIPT.json'))
        save(B/'BUILD_RECEIPT.json',compiled);check(all(matches.values()),'fresh class bytes differ; inspect before any generation')
        verify(refs);verify_jdk_tree();verify(generated_refs)
        # A separate, non-initializing class loader probe is excluded from the actual producer classpath.
        probe=build/'probe_classes';probe.mkdir()
        proc=invoke('compile_origin_probe',[I['javac']['path'],'-J-Xmx128m','-encoding','UTF-8','-proc:none','-implicit:none','-sourcepath',str(empty),'-d',str(probe),str(B/'OriginProbe.java')],30)
        require_process(proc,'compile origin probe')
        proc=invoke('origin_probe',[I['java']['path'],'-Xmx128m','-cp',str(probe)+':'+':'.join(I['classpath_entries']),'OriginProbe',str(B/'ORIGIN_ROSTER.txt')],30)
        require_process(proc,'class origin probe')
        observed={}
        for line in (B/'processes/origin_probe/stdout.txt').read_text().splitlines():
            name,path,digest=line.split('\t');check(name not in observed,'duplicate origin');observed[name]=dict(path=path,sha256=digest)
        expected_origins=read(B/'ORIGIN_EXPECTATIONS.json')
        for row in I['custom_class_roster']:expected_origins[row['name']]=dict(path=str(classes),sha256=actual[row['relative']]['sha256'])
        check(set(observed)==set(expected_origins),'exact observed origin roster')
        origin_checks={name:dict(same_file=Path(observed[name]['path']).samefile(ref['path']),same_class_bytes=observed[name]['sha256']==ref['sha256'],raw_path_string_equal=observed[name]['path']==ref['path']) for name,ref in expected_origins.items()}
        check(all(x['same_file'] and x['same_class_bytes'] for x in origin_checks.values()),'actual class filesystem objects or bytes differ from fresh inputs')
        save(B/'CLASS_ORIGIN_RESULT.json',dict(status='PASS',actual=observed,expected=expected_origins,checks=origin_checks,process=pin(B/'processes/origin_probe/PROCESS_RECEIPT.json')))
        native,variant=run/'native',run/'variant'
        native_cmd=[I['java']['path'],'-Xmx512m','-XX:MaxDirectMemorySize=128m','-Xlog:class+load=info:file='+str(run/'native_class_load.log'),'-cp',':'.join(I['classpath_entries']),'PairedContinuationDiagnostic',CANDIDATE,I['candidate']['source']['path'],str(native/'result.json'),I['origins']['path']]
        result['native_pair_attempts']=1
        proc=invoke('matched_pair',native_cmd,30,folder=native,tree=run,tree_limit=805306368,stream=536870912,watched=[f/n for f in (native,variant) for n in ('result.json','model.json','controller.json','controller.txt')]);require_process(proc,'matched pair')
        process=pin(native/'PROCESS_RECEIPT.json');nr=read(native/'result.json');vr=read(variant/'result.json')
        h.validate_native(nr,dict(runtime=dict(native_configuration=I['native_configuration'])),I['candidate'])
        check(vr['status']=='JOB_CONTROLLER_PRINTED' and vr['teardown']=='COMPLETED' and vr['nonrelease_extractor'] is True and vr['extractor_variant']==VARIANT,'variant completion')
        # Actual native class loading is independent evidence in addition to the non-initializing probe.
        loadtext=(run/'native_class_load.log').read_text();loaded={}
        for line in loadtext.splitlines():
            if '[class,load]' in line and ' source: ' in line:
                name,origin=line.split('[class,load] ',1)[1].split(' source: ',1);loaded[name]=origin
        custom_loaded={n:o for n,o in loaded.items() if any(n==t or n.startswith(t+'$') for t in P['custom_top_level_classes'])}
        check('PairedContinuationDiagnostic' in custom_loaded and 'tau.smlab.syntech.games.gr1.GR1ContinuationPreferenceConstruction' in custom_loaded,'native custom class evidence')
        check(all(urlparse(o).scheme=='file' and Path(unquote(urlparse(o).path)).samefile(classes) for o in custom_loaded.values()),'native custom classes came from new class directory')
        released_loaded={name:loaded.get(name) for name in C['released_origin_classes']}
        check(all(o and urlparse(o).scheme=='file' and Path(unquote(urlparse(o).path)).samefile(expected_origins[name]['path']) for name,o in released_loaded.items()),'actual native 28 released class origins match freshly downloaded JARs')
        save(run/'NATIVE_CLASS_ORIGINS.json',dict(status='PASS',released_classes=released_loaded,custom_classes=custom_loaded,complete_log=pin(run/'native_class_load.log'),producer_class_identities=nr['class_identities'],producer_extractor_printer_origins=nr['extractor_printer_origins'],experimental_class_identities=vr['experimental_class_identities']))
        diag=read(variant/'paired_intervention.json')
        for key in ('memory_and_model_all_BDDs_equal','variable_order_unchanged','same_memory_object','same_model_object'):check(diag[key] is True,'pairing '+key)
        check(all(diag['BDD_equality_checks'].values()) and len(diag['BDD_equality_checks'])==36,'complete 36-value memory/model equality')
        parity={p.name:pin(p)['sha256']==pin(variant/p.name)['sha256'] for p in sorted(native.glob('*.bdd'))};parity['model.json']=pin(native/'model.json')['sha256']==pin(variant/'model.json')['sha256'];check(all(parity.values()),'same-pair model/region bytes')
        baseline_manifest=run/'baseline_inputs.json';save(baseline_manifest,manifest(native,process))
        pair=dict(schema='same-memory-extraction-pair-evidence-v1',candidate_id=CANDIDATE,variant_name=VARIANT,baseline_result=pin(native/'result.json'),variant_result=pin(variant/'result.json'),producer_evidence=pin(variant/'paired_intervention.json'),BDD_equality_checks=diag['BDD_equality_checks'],expected_BDD_keys=list(diag['BDD_equality_checks']),BDD_roster_source='Freshly compiled unchanged producer enumerates all nonnull X/Y/Z entries, win, ENV/SYS initial/trans and ordered justices.',model_region_byte_parity=parity,memory_equality_evidence_kind='Fresh producer BDD semantic equality; not independent memory-array recomputation')
        for key in ('same_memory_object','same_model_object','memory_and_model_all_BDDs_equal','variable_order_unchanged'):pair[key]=diag[key]
        save(run/'PAIRED_EVIDENCE.json',pair)
        extractor='tau.smlab.syntech.games.gr1.GR1ContinuationPreferenceConstruction'
        binding=dict(schema='experimental-extractor-binding-v1',candidate_id=CANDIDATE,variant_name=VARIANT,nonrelease_extractor=True,upstream_transformation_unchanged=True,upstream_raw_core_unchanged=True,baseline_manifest=pin(baseline_manifest),variant_result=pin(variant/'result.json'),source_files=I['sources'],class_files={extractor:actual[extractor.replace('.','/')+'.class']},extractor_class=extractor,paired_evidence=pin(run/'PAIRED_EVIDENCE.json'))
        save(run/'VARIANT_BINDING.json',binding);vm=manifest(variant,process);vm['bdd_files'].pop('selection_preference.bdd');vm['schema']='experimental-extractor-independent-audit-inputs-v1';vm['variant_binding']=pin(run/'VARIANT_BINDING.json');save(run/'variant_inputs.json',vm)
        save(run/'PAIR_RESULT.json',dict(status='COMPLETE_PAIRED_INTERVENTION_AWAITING_SEMANTIC_AUDITS',process=process,paired_BDD_checks=diag['BDD_equality_checks'],model_region_byte_parity=parity,observation={k:diag[k] for k in ('examined_candidates','refined_candidates','no_preferred_candidate_fallbacks','native_graph_states','native_graph_edges','variant_graph_states','variant_graph_edges')}))
        # Both checkers run on each completed arm even if historical semantic parity differs.
        audits=run/'audits';audits.mkdir();py=I['python']['path'];prefix=[py,'-I','-S','-B']
        jobs=[('baseline_production',60,prefix+[str(B/'code/baseline/production/certify.py'),str(native),CANDIDATE,'--profiles',I['profiles']['path'],'--profile-sha256',I['profiles']['sha256'],'--output-dir',str(audits/'baseline_production')],'certificate.json'),('baseline_independent',180,prefix+[str(B/'code/baseline/independent/audit_worker.py'),str(baseline_manifest),str(audits/'baseline_independent')],'AUDIT_RESULT.json'),('variant_production',60,prefix+[str(B/'code/variant/production/audit_variant.py'),str(run/'variant_inputs.json'),str(audits/'variant_production')],'certificate.json'),('variant_independent',180,prefix+[str(B/'code/variant/independent/audit_worker.py'),str(run/'variant_inputs.json'),str(audits/'variant_independent')],'AUDIT_RESULT.json')]
        audit_refs=[pin(p) for p in run.rglob('*') if p.is_file()];save(audits/'INPUTS.json',dict(inputs=audit_refs,attempts_per_checker=1,automatic_retries=0));checks=[]
        for name,wall,cmd,outname in jobs:
            result['audit_attempts']+=1;proc=invoke(name,cmd,wall,folder=audits/(name+'_process'),tree=audits,tree_limit=67108864,watched=[audits/name/outname]);entry=dict(name=name,process_complete=h.valid_process(proc),process=pin(audits/(name+'_process')/'PROCESS_RECEIPT.json'))
            if (audits/name/outname).is_file():
                output=read(audits/name/outname);entry.update(status=output['status'],output=pin(audits/name/outname))
                if 'production' in name and output['status']=='COMPLETE_DERIVED_ORIGINAL_CERTIFICATE':entry.update(strict=output['derived_fairness']['strict_liveness']['pass'],cooperative=output['derived_fairness']['nonconflicting']['pass'],original_states=output['original_view_mapping']['states'],original_edges=output['original_view_mapping']['edges'])
                elif 'independent' in name and output['status']=='COMPLETE_INDEPENDENT_RAW_GRAPH_AUDIT':entry.update(strict=output['independent_strict'],cooperative=output['independent_cooperative'],original_states=output['original_view']['states'],original_edges=output['original_view']['edges'])
            checks.append(entry);h.save_atomic(audits/'PROGRESS.json',dict(checks=checks))
        verify(audit_refs);result['checks']=checks;keys=('strict','cooperative','original_states','original_edges')
        for arm in ('baseline','variant'):
            selected=[x for x in checks if x['name'].startswith(arm)];check(len(selected)==2 and all(x['process_complete'] for x in selected),arm+' processes incomplete');check(all(k in x for x in selected for k in keys),arm+' audits incomplete');check(all(selected[0][k]==selected[1][k] for k in keys),arm+' checkers disagree');result[arm]={k:selected[0][k] for k in keys}
        save(audits/'RESULT.json',dict(status='COMPLETE_BOTH_ARMS_BOTH_AUDITS_AGREE',checks=checks,baseline=result['baseline'],variant=result['variant']))
        result['status']='COMPLETE_PUBLIC_SOURCE_DEPENDENCY_REGENERATION_INSTALLED_JDK_BOTH_AUDITS_AGREE'
    except BaseException as exc:
        result['status']='UNKNOWN_PUBLIC_REGENERATION_INCOMPLETE';result['errors'].append(dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc()))
    finally:
        try:verify(refs);verify_jdk_tree();verify(generated_refs);verify(freeze['files']);result['input_integrity']='PASS'
        except BaseException as exc:result['input_integrity']='FAIL';result['status']='UNKNOWN_INPUT_MUTATION';result['errors'].append(dict(message=str(exc)))
        result['finished_utc']=datetime.now(timezone.utc).isoformat();save(B/'SUMMARY.json',result);print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
