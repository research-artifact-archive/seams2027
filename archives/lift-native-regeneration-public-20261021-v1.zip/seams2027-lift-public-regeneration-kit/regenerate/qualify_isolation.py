from pathlib import Path
import json,os,sys
checks=[]
for x in json.loads(Path(sys.argv[1]).read_text()):
 try:
  if x['operation']=='read':
   with open(x['path'],'rb') as f:f.read(1)
  elif x['operation']=='stat':os.stat(x['path'])
  else:list(os.scandir(x['path']))
  allowed=True;error=None
 except PermissionError as exc:allowed=False;error=type(exc).__name__
 checks.append(dict(**x,observed_allowed=allowed,error=error,pass_check=allowed==x['expected_allowed']))
print(json.dumps(checks))
assert all(x['pass_check'] for x in checks)
