"""Synthetic-only validation: no sockets, public fetches, Java or science."""
from pathlib import Path
import contextlib, hashlib, importlib.util, io, json, os, sys, tempfile, urllib.request, zipfile
sys.dont_write_bytecode = True
B = Path(__file__).resolve().parent

def module(name, path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value

fetch=module('guard_fetch',B/'fetch_one.py')
payload=module('guard_payload',B/'public_payload.py')
def pin(path):
    data=path.read_bytes();return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())

class Response:
    def __init__(self, status, data=b'', location=None):
        self.status=status;self.data=data;self.headers={} if location is None else {'Location':location}
        self.reads=[];self.closed=False;self.url='https://arxiv.org/synthetic'
    def read(self, size=-1):
        assert size > 0, 'Unbounded response read forbidden'
        assert self.status == 200, 'Redirect/error body read forbidden'
        self.reads.append(size);value=self.data[:size];self.data=self.data[size:];return value
    def close(self):self.closed=True
    def geturl(self):return self.url
    def __enter__(self):return self
    def __exit__(self,*args):self.close()

class Opener:
    def __init__(self,responses):self.responses=responses;self.calls=[]
    def open(self,request,timeout):
        self.calls.append(request.full_url)
        assert self.responses, 'Undeclared synthetic request'
        response=self.responses.pop(0);response.url=request.full_url;return response

class Helpers:
    pin=staticmethod(pin)
    @staticmethod
    def save_new(path,value):
        with path.open('x') as stream:json.dump(value,stream)

def main():
    if len(sys.argv)!=2: raise ValueError('Usage: qualify_public_guards.py FRESH_OUTPUT_DIRECTORY')
    output=Path(sys.argv[1]).resolve();output.mkdir()
    checks=[];data=b'synthetic bounded payload';digest=hashlib.sha256(data).hexdigest()
    original_builder=urllib.request.build_opener;original_file=fetch.__file__;original_argv=sys.argv[:];original_cwd=Path.cwd()
    # Directly exercise every redirect handler override. Any body read would fail.
    handler=fetch.ReturnRedirect()
    for status in (301,302,303,307,308):
        response=Response(status,b'never read',location='/next')
        returned=getattr(handler,'http_error_'+str(status))(urllib.request.Request(response.url),response,status,'redirect',response.headers)
        assert returned.status==status
        returned.close();assert response.closed and not response.reads
        checks.append(dict(case='handler_'+str(status)+'_closes_without_read',pass_check=True))
    with tempfile.TemporaryDirectory(prefix='public-guards-',dir=output) as temp:
        root=Path(temp)
        def fetch_case(name,responses,expected_pass,expected_requests,expected_bytes=None,url='https://arxiv.org/synthetic',sha=digest):
            case=root/name;case.mkdir();(case/'process').mkdir()
            row=dict(id='fixture',url=url,destination='payload.bin',bytes=len(data),sha256=sha,max_response_bytes=len(data)+1)
            (case/'FETCH_MANIFEST.json').write_text(json.dumps(dict(requests=[row],redirects=dict(maximum=3,allowed_hosts=['arxiv.org']))))
            seen=list(responses);opener=Opener(list(responses));urllib.request.build_opener=lambda *args:opener
            fetch.__file__=str(case/'fetch_one.py');sys.argv=['fetch_one.py','fixture','1024'];os.chdir(case/'process')
            with contextlib.redirect_stdout(io.StringIO()):exit_code=fetch.main()
            receipt=json.loads(Path('FETCH_RECEIPT.json').read_text())
            assert (exit_code==0)==expected_pass and len(opener.calls)==expected_requests
            assert receipt['http_get_attempts']==expected_requests and receipt['redirect_body_bytes_read']==0
            assert all(not response.reads for response in seen if response.status!=200)
            assert all(response.closed for response in seen[:expected_requests])
            assert receipt['body_bytes_read']<=len(data)+1
            if expected_bytes is not None:assert receipt['body_bytes_read']==expected_bytes
            checks.append(dict(case=name,pass_check=True,http_attempts=expected_requests,body_bytes=receipt['body_bytes_read'],redirect_body_bytes=0))
        try:
            fetch_case('direct200',[Response(200,data)],True,1,len(data))
            for status in (301,302,303,307,308):fetch_case('redirect_'+str(status),[Response(status,b'x'*100,location='/next'),Response(200,data)],True,2,len(data))
            fetch_case('three_redirects',[Response(301,location='/one'),Response(302,location='/two'),Response(308,location='/three'),Response(200,data)],True,4,len(data))
            fetch_case('fourth_redirect_rejected',[Response(302,location='/'+str(i)) for i in range(4)],False,4,0)
            fetch_case('redirect_host_rejected',[Response(302,location='https://example.com/x')],False,1,0)
            fetch_case('redirect_http_rejected',[Response(307,location='http://arxiv.org/x')],False,1,0)
            fetch_case('redirect_missing_location',[Response(301)],False,1,0)
            fetch_case('initial_host_rejected',[],False,0,0,url='https://example.com/x')
            fetch_case('oversize_capped',[Response(200,data+b'extra')],False,1,len(data)+1)
            fetch_case('truncated_body',[Response(200,data[:-1])],False,1,len(data)-1)
            fetch_case('hash_mismatch',[Response(200,data)],False,1,len(data),sha='0'*64)
            fetch_case('http_error_body_not_read',[Response(503,b'x'*100)],False,1,0)
        finally:
            urllib.request.build_opener=original_builder;fetch.__file__=original_file;sys.argv=original_argv;os.chdir(original_cwd)
        # One archive member deliberately supplies two distinct destination files.
        case=root/'archive';(case/'downloads').mkdir(parents=True)
        with zipfile.ZipFile(case/'downloads/source-package.zip','w') as archive:archive.writestr('pkg/shared.py',data)
        row=dict(member='pkg/shared.py',bytes=len(data),sha256=digest)
        selection=[dict(row,destination='code/baseline/shared.py'),dict(row,destination='code/variant/shared.py')]
        plan=dict(acquisition=dict(archive_expansion=dict(max_entries=2,expected_entries=1,max_member_bytes=1024,max_total_bytes=1024,expected_bytes=len(data))))
        refs=payload.extract_selected(case,plan,selection,Helpers)
        receipt=json.loads((case/'ARCHIVE_EXTRACTION_RECEIPT.json').read_text())
        assert len(refs)==2 and receipt['unique_selected_source_members']==1 and receipt['selected_destination_files']==2
        assert all(Path(x['path']).read_bytes()==data for x in refs)
        checks.append(dict(case='shared_archive_member_two_destinations',pass_check=True))
        for name,rows in [('conflicting_shared_identity',[selection[0],dict(selection[1],sha256='0'*64)]),('duplicate_destination',[selection[0],selection[0]])]:
            try:payload.extract_selected(case,plan,rows,Helpers);raise AssertionError('Selection accepted: '+name)
            except ValueError:checks.append(dict(case=name,pass_check=True))
        for name in ('../x','/absolute','a/../b','a//b','a/./b','a\\b',''):
            try:payload.relative(name);raise AssertionError('Unsafe path accepted')
            except ValueError:checks.append(dict(case='unsafe_path:'+name,pass_check=True))
    report=dict(schema='public-guard-synthetic-qualification-v1',status='PASS',checks=checks,network_calls=0,java_invocations=0,scientific_checker_invocations=0,python=pin(Path(sys.executable).resolve()),source_files=[pin(B/x) for x in ('qualify_public_guards.py','fetch_one.py','public_payload.py')])
    with (output/'GUARD_QUALIFICATION.json').open('x') as stream:json.dump(report,stream,ensure_ascii=False,indent=2);stream.write('\n')
    print(json.dumps(dict(status='PASS_SYNTHETIC_GUARDS',checks=len(checks),network_calls=0,java_invocations=0)))

if __name__=='__main__':main()
