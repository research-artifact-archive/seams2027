"""Fixed-nine metadata dispatcher. Native execution requires a frozen Root GO.

No solver/checker is imported here. Output metadata never converts a missing,
unsupported, truncated, or failed execution into a scientific negative result.
"""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib, importlib.util, json, math, os, shutil, sys, time
sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
ORDER = ['arbiter__trivial_1', 'lift__preferred', 'lift__trivial_1',
         'minepump__preferred', 'minepump__trivial_1', 'minepump__trivial_2',
         'traffic_single__trivial_1', 'traffic_updated__preferred', 'traffic_updated__trivial_1']
NATIVE_OUTCOMES = ['JOB_UNREALIZABLE_NO_CONTROLLER', 'JOB_EMPTY_MEMORY_NO_CONTROLLER', 'JOB_CONTROLLER_PRINTED']
NATIVE_CONFIGURATION = {'release':'1.0.0.202402072123','BDDPackage':'JTLV','BDDPackageVersion':'DEFAULT',
    'synthesisMethod':'synthesisPitermanReduction','ConcreteControllerFormat':'JTLV','optChoice':'none','reorderChoice':'none',
    'groupVars':False,'TraceInfo':'NONE','TransFuncType':'SINGLE_FUNC','extractor_strategy':'native_two_argument_default_ZYX'}
SESSION_STOP = datetime(2026, 10, 18, 13, tzinfo=timezone.utc)


def require(value, why):
    if not value: raise ValueError(why)


def unique_json(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key: ' + key)
        result[key] = value
    return result


def read(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=unique_json)


def pin(path):
    path = Path(path).resolve(strict=True)
    require(path.is_file(), 'Regular pinned file required: ' + str(path))
    h = hashlib.sha256(); n = 0
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            n += len(chunk); h.update(chunk)
    return {'path': str(path), 'bytes': n, 'sha256': h.hexdigest()}


def triple(ref):
    return {key: ref[key] for key in ('path', 'bytes', 'sha256')}


def verify(refs):
    for ref in refs:
        require(pin(ref['path']) == triple(ref), 'Frozen input changed: ' + ref['path'])


def save_new(path, value):
    path = Path(path)
    data = json_bytes(value)
    require(len(data) <= 16777216, 'Parent metadata exceeds fixed 16 MiB file threshold')
    with path.open('xb') as stream: stream.write(data)


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def save_atomic(path, value):
    path = Path(path); tmp = path.with_name(path.name + '.tmp')
    require(not tmp.exists() and not tmp.is_symlink(), 'Unexpected metadata temporary file')
    save_new(tmp, value); os.replace(tmp, path)


def now(): return datetime.now(timezone.utc)


def exact_abs(path):
    p = Path(path)
    require(p.is_absolute() and str(p) == str(p.absolute()), 'Absolute canonical path required')
    require('..' not in p.parts, 'Parent path traversal forbidden')
    return p


def positive(value, name):
    require(not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value) and value > 0, 'Positive finite ' + name)


def load_stage():
    name = 'remaining_nine_contained_stage'
    spec = importlib.util.spec_from_file_location(name, BASE / 'bounded_process.py')
    stage = importlib.util.module_from_spec(spec); spec.loader.exec_module(stage)
    return stage


def closure_members(frozen):
    result = {}
    for ref in frozen['files']:
        value = triple(ref); path = value['path']
        require(path not in result or result[path] == value, 'Conflicting frozen pins')
        result[path] = value
    return result


def preflight(config_path, frozen_path, *, check_destination=True, check_disk=True):
    c = read(config_path); f = read(frozen_path)
    require(c['schema'] == 'remaining-nine-execution-config-v1', 'Config schema')
    require(f['schema'] == 'remaining-nine-frozen-execution-v1' and f['status'] == 'QUALIFIED_FROZEN', 'Qualified freeze required')
    require(triple(f['config']) == pin(config_path), 'Config/freeze identity')
    require(c['order'] == ORDER and [row['id'] for row in c['candidates']] == ORDER, 'Exact fixed nine order and rows')
    require(len(c['candidates']) == 9, 'Exactly nine rows')
    verify(f['files']); frozen = closure_members(f)
    needed = [pin(config_path), pin(__file__), pin(BASE / 'bounded_process.py'), pin(BASE / 'owned_process.py'),
              c['profiles'], c['original_profiles'], c['runtime']['java'], c['runtime']['python'], c['runtime']['origins'],
              c['production']['script'], c['independent']['script']]
    require(f.get('qualification_refs'), 'Qualification references required')
    needed += f['qualification_refs']
    for row in c['candidates']:
        needed.append(row['source']); needed += row['source_import_closure']
        require(row['source_import_closure'] and triple(row['source']) in [triple(x) for x in row['source_import_closure']], 'Source must belong to its exact import closure')
    needed += c['runtime']['class_files']
    for ref in needed:
        require(frozen.get(ref['path']) == triple(ref), 'Required input absent from freeze: ' + ref['path'])
    require(pin(Path(sys.executable).resolve()) == triple(c['runtime']['python']), 'Exact dispatcher Python')
    require(c['runtime']['native_configuration'] == NATIVE_CONFIGURATION, 'Unchanged released native configuration')
    require(c['runtime']['classpath_entries'] and len(c['runtime']['classpath_entries']) == len(set(c['runtime']['classpath_entries'])), 'Unique ordered classpath entries')
    for entry in c['runtime']['classpath_entries']:
        p = exact_abs(entry)
        if p.is_file(): require(str(p.resolve()) in frozen, 'Classpath jar absent from freeze')
        else: require(str(p) == c['runtime']['classes_directory'] and p.is_dir(), 'Only declared classes directory in classpath')
    actual_classes = [str(p.resolve()) for p in sorted(Path(c['runtime']['classes_directory']).rglob('*')) if p.is_file()]
    require(actual_classes == [ref['path'] for ref in c['runtime']['class_files']], 'Exact class directory inventory')
    adapted = read(c['profiles']['path'])['profiles']; original = read(c['original_profiles']['path'])['profiles']
    require(set(adapted) == set(ORDER), 'Exact nine adapted profiles')
    for row in c['candidates']:
        ident = row['id']; p = adapted[ident]
        require(p == dict(original[ident], case_id=ident, variant='initializers'), 'Only case_id/variant metadata may change: ' + ident)
        require(p['fixture_id'] == ident and p['source']['sha256'] == row['source']['sha256'] and p['source']['bytes'] == row['source']['bytes'], 'Profile/source identity: ' + ident)
    limits = c['limits']
    required = ['native_wall_seconds', 'native_stream_bytes', 'rss_bytes', 'file_bytes', 'per_case_wall_seconds',
                'batch_wall_seconds', 'case_output_bytes', 'batch_output_bytes', 'min_free_bytes', 'cleanup_reserve_seconds']
    require(set(limits) == set(required), 'Exact explicit limits contract')
    for name in required: positive(limits[name], name)
    require(limits['native_wall_seconds'] == 10 and limits['native_stream_bytes'] == 67108864, 'Unchanged native wall/stream caps')
    require(limits['rss_bytes'] == 1073741824 and limits['file_bytes'] == 16777216, 'Unchanged RSS/file caps')
    require(limits['case_output_bytes'] == 134217728 and limits['batch_output_bytes'] == 1342177280, 'Declared case and batch output thresholds')
    require(limits['min_free_bytes'] >= 1073741824 and limits['cleanup_reserve_seconds'] >= 10, 'Disk floor and cleanup reserve')
    for name in ('production', 'independent'):
        positive(c[name]['wall_seconds'], name + ' wall'); positive(c[name]['stream_bytes'], name + ' stream')
        require(c[name]['stream_bytes'] == 8388608, 'Checker capture threshold')
    require(c['production']['wall_seconds'] == 60, 'Production checker wall cap')
    reserve = limits['native_wall_seconds'] + c['production']['wall_seconds'] + c['independent']['wall_seconds'] + limits['cleanup_reserve_seconds']
    require(limits['per_case_wall_seconds'] >= reserve and limits['batch_wall_seconds'] >= reserve, 'Case/batch wall must cover all declared stages and cleanup')
    batch = exact_abs(c['batch_dir'])
    require(batch.parent.is_dir() and not batch.parent.is_symlink(), 'Existing regular batch parent')
    if check_destination: require(not batch.exists() and not batch.is_symlink(), 'Fresh unique batch output required')
    for ref in f['files']:
        require(not Path(ref['path']).is_relative_to(batch), 'Immutable input inside mutable output tree')
    if check_disk: require(shutil.disk_usage(batch.parent).free >= limits['batch_output_bytes'] + limits['min_free_bytes'], 'Insufficient free disk for batch allowance and floor')
    return c, f


def authorize(config_path, frozen_path, go_path, c):
    go = read(go_path)
    require(go['schema'] == 'remaining-nine-root-start-v1' and go.get('start_authorized') is True, 'Root start authorization')
    require(triple(go['freeze']) == pin(frozen_path) and triple(go['config']) == pin(config_path), 'Exact Root config/freeze authorization')
    require(go['candidate_order'] == ORDER, 'Root fixed candidate order')
    for name, value in [('native_attempt_limit', 9), ('per_candidate_native_attempt_limit', 1), ('production_attempt_limit', 9), ('independent_attempt_limit', 9)]:
        require(go.get(name) == value, 'Root exact attempt bound: ' + name)
    deadline = datetime.fromisoformat(go['deadline_utc'])
    require(deadline.tzinfo is not None and deadline <= SESSION_STOP, 'Absolute Root deadline no later than user stop')
    reserve = c['limits']['native_wall_seconds'] + c['production']['wall_seconds'] + c['independent']['wall_seconds'] + c['limits']['cleanup_reserve_seconds']
    require((deadline - now()).total_seconds() >= reserve, 'Insufficient authorized time for a whole case')
    return go, pin(go_path), deadline


def clean_owned_end(process):
    return (process.get('owned_child_reaped') is True and process.get('receipt_persisted') is True
            and process.get('parent_finalization_completed') is True
            and not process.get('parent_aborted')
            and (not process.get('process_started') or process.get('exact_child_wait4', {}).get('exact_child_reaped') is True)
            and not (process.get('exact_child_wait4') or {}).get('authority_lost')
            and (not process.get('process_started') or (process.get('final_group_observation') or {}).get('state') == 'ABSENT'))


def valid_process(process):
    return (clean_owned_end(process) and process['status'] == 'PROCESS_COMPLETED' and process['exit_code'] == 0
            and not process['fatal_reasons'] and not process['resource_reasons']
            and all(x['complete'] for x in process['capture'].values()))


def native_command(c, row, native_dir):
    rt = c['runtime']
    return [rt['java']['path'], '-Xmx512m', '-XX:MaxDirectMemorySize=128m', '-cp', ':'.join(rt['classpath_entries']),
            'ReleasedKindJobProducer', row['id'], row['source']['path'], str(native_dir / 'result.json'), rt['origins']['path']]


def validate_native(result, c, row):
    ident = row['id']
    require(result['fixture_id'] == result['case_id'] == ident and result['variant'] == 'initializers', 'Native identity')
    require(result['input_sha256'] == row['source']['sha256'], 'Native source hash')
    require(result['initializers_replaced'] is False and result['semantic_reduction_used'] is False and result['ENV_justice_normalization_used'] is False, 'Original initialization and released syntactic route')
    require(result['configuration'] == c['runtime']['native_configuration'], 'Exact native configuration')
    require(result['native_solver_calls'] == 1 and result['teardown'] == 'COMPLETED', 'One native call and completed teardown')
    require(type(result['helper_added']) is bool and type(result['helper_is_native_nonaux_ENV']) is bool, 'Observed helper booleans')
    require(result['helper_added'] == result['helper_is_native_nonaux_ENV'], 'Observed helper/ENV ownership consistency')
    require(result['status'] in NATIVE_OUTCOMES, 'Completed native outcome')
    if result['status'] == 'JOB_UNREALIZABLE_NO_CONTROLLER':
        require(result['native_initial_verdict'] is False and result['memory_empty_guard_called'] is False, 'Native false short circuit')
        require(result['controller_extraction_calls'] == result['native_printer_calls'] == 0, 'No false-verdict extraction')
    elif result['status'] == 'JOB_EMPTY_MEMORY_NO_CONTROLLER':
        require(result['native_initial_verdict'] is True and result['memory_empty_guard_called'] is True and result['memory_empty'] is True, 'Empty-memory short circuit')
        require(result['controller_extraction_calls'] == result['native_printer_calls'] == 0, 'No empty-memory extraction')
    else:
        require(result['native_initial_verdict'] is True and result['memory_empty_guard_called'] is True and result['memory_empty'] is False and result['memory_complete'] is True, 'Returned native graph gate')
        require(result['controller_extraction_calls'] == result['native_printer_calls'] == 1, 'One native extraction and printer')
    return result['status']


def audit_manifest(c, row, native_dir):
    result = read(native_dir / 'result.json')
    inputs = {'source': triple(row['source']), 'profile': triple(c['profiles']), 'native_result': pin(native_dir / 'result.json'),
              'model': pin(native_dir / 'model.json'), 'native_process': pin(native_dir / 'PROCESS_RECEIPT.json')}
    if result['status'] == 'JOB_CONTROLLER_PRINTED':
        inputs.update(controller=pin(native_dir / 'controller.json'), printer=pin(native_dir / 'controller.txt'))
    bdds = {p.name: pin(p) for p in sorted(native_dir.glob('*.bdd'))}
    require(bdds, 'Native BDD exports required')
    return {'schema': 'remaining-nine-independent-audit-inputs-v1', 'candidate_id': row['id'], 'inputs': inputs, 'bdd_files': bdds}


def classify(row):
    p = row.get('production_status'); independent = row.get('independent_status')
    native = row.get('native_observed_outcome')
    if p == 'COMPLETE_NO_CONTROLLER' and independent == 'COMPLETE_INDEPENDENT_NO_CONTROLLER':
        if native == 'JOB_UNREALIZABLE_NO_CONTROLLER': return 'COMPLETE_NATIVE_REFUSAL_MODEL_CHECKED'
        if native == 'JOB_EMPTY_MEMORY_NO_CONTROLLER': return 'COMPLETE_NATIVE_EMPTY_MEMORY_MODEL_CHECKED'
    if p == 'COMPLETE_DERIVED_ORIGINAL_CERTIFICATE' and independent == 'COMPLETE_INDEPENDENT_RAW_GRAPH_AUDIT' and native == 'JOB_CONTROLLER_PRINTED':
        return 'COMPLETE_RETURNED_GRAPH_SEPARATE_AUDITS'
    return 'UNKNOWN_AUDIT_OR_MAPPING'


def execute(c, frozen, go_ref, deadline, *, stage=None):
    stage = load_stage() if stage is None else stage
    batch = Path(c['batch_dir']); batch.mkdir(exist_ok=False)
    started = time.monotonic(); effective = min(deadline, now() + timedelta(seconds=c['limits']['batch_wall_seconds']))
    rows = [{'candidate': ident, 'sequence': i + 1, 'status': 'NOT_RUN', 'native_launch_calls': 0, 'native_process_started': False,
             'production_launch_calls': 0, 'independent_launch_calls': 0, 'native_observed_outcome': None,
             'semantic_status': 'NOT_EVALUATED', 'integrity_status': 'NOT_CHECKED', 'errors': []}
            for i, ident in enumerate(ORDER)]
    ledger = {'schema': 'remaining-nine-batch-receipt-v1', 'started_utc': now().isoformat(), 'effective_deadline_utc': effective.isoformat(),
              'fixed_denominator': 11, 'batch_denominator': 9, 'candidate_order': ORDER, 'rows': rows,
              'root_go': go_ref, 'status': 'RUNNING', 'full_reset_uses': 0, 'automatic_retries': 0,
              'new_repair_generation': False, 'adaptation_or_deployment_episode': False, 'stop_reason': None}
    save_new(batch / 'RUN_STARTED.json', {'started_utc': ledger['started_utc'], 'root_go': go_ref, 'candidate_order': ORDER,
                                       'owner_pid': os.getpid(), 'native_attempt_limit': 9, 'per_candidate_limit': 1})
    save_atomic(batch / 'RUN_PROGRESS.json', ledger)
    limits = c['limits']; base_refs = frozen['files'] + [go_ref]
    required_all = limits['native_wall_seconds'] + c['production']['wall_seconds'] + c['independent']['wall_seconds'] + limits['cleanup_reserve_seconds']

    def remaining(until): return (until - now()).total_seconds()
    def input_check(): verify(base_refs)
    def budget_check(until, required):
        require(remaining(until) >= required, 'Insufficient remaining stage and cleanup time')
        usage = stage.tree_usage(batch)
        require(usage['bytes'] < limits['batch_output_bytes'], 'Batch output threshold reached')
        reserve = limits['batch_output_bytes'] - usage['bytes'] + limits['min_free_bytes']
        require(shutil.disk_usage(batch).free >= reserve, 'Insufficient remaining disk allowance and floor')
    def invoke(command, process_dir, case_dir, until, wall, stream, watched):
        return stage.run_bounded(command, process_dir, until.isoformat(), wall_seconds=wall, rss_bytes=limits['rss_bytes'],
            stream_bytes=stream, file_bytes=limits['file_bytes'], watch_files=watched, output_tree=case_dir,
            output_tree_bytes=limits['case_output_bytes'], aggregate_tree=batch, aggregate_tree_bytes=limits['batch_output_bytes'],
            min_free_bytes=limits['min_free_bytes'])

    stop = False
    try:
        for config_row, row in zip(c['candidates'], rows):
            if stop: break
            case = batch / row['candidate']; native = case / 'native'
            case_deadline = min(effective, now() + timedelta(seconds=limits['per_case_wall_seconds']))
            try:
                input_check(); budget_check(case_deadline, required_all)
            except BaseException as exc:
                ledger['stop_reason'] = 'PRELAUNCH:' + type(exc).__name__ + ':' + str(exc)
                break
            case.mkdir(exist_ok=False)
            save_new(case / 'CASE_START.json', {'candidate': row['candidate'], 'sequence': row['sequence'], 'started_utc': now().isoformat(),
                                              'deadline_utc': case_deadline.isoformat(), 'native_attempt_limit': 1})
            row['started_utc'] = now().isoformat(); row['status'] = 'UNKNOWN_NATIVE_PROCESS'
            try:
                row['native_launch_calls'] = 1; row['native_process_started'] = None
                n = invoke(native_command(c, config_row, native), native, case, case_deadline,
                           limits['native_wall_seconds'], limits['native_stream_bytes'], [native / x for x in ['result.json', 'model.json', 'controller.json', 'controller.txt']])
                row['native_process_started'] = bool(n['process_started'])
                row['native_process'] = pin(native / 'PROCESS_RECEIPT.json') if n.get('receipt_persisted') else None
                if (native / 'result.json').is_file():
                    try:
                        row['native_result'] = pin(native / 'result.json')
                        row['native_observed_outcome'] = read(native / 'result.json').get('status')
                    except Exception as exc: row['errors'].append('UNREADABLE_NATIVE_RESULT:' + repr(exc))
                require(clean_owned_end(n), 'Native ownership/finalization incomplete; halt batch')
                if not valid_process(n):
                    row['errors'].append('Native process not complete under all bounds')
                    if n.get('fatal_reasons'): stop = True
                    continue
                nr = read(native / 'result.json'); validate_native(nr, c, config_row)
                row['native_result'] = pin(native / 'result.json'); row['native_metadata_validation'] = 'PASS'
                native_pins = [pin(path) for path in sorted(native.rglob('*')) if path.is_file()]
                row['native_output_snapshot'] = native_pins
                def native_output_check(boundary):
                    nonlocal stop
                    try:
                        verify(native_pins)
                        require([str(path.resolve()) for path in sorted(native.rglob('*')) if path.is_file()] == [ref['path'] for ref in native_pins], 'Native output inventory changed ' + boundary)
                    except BaseException:
                        row['status'] = row['integrity_status'] = 'UNKNOWN_NATIVE_OUTPUT_MUTATION'
                        stop = True
                        raise
                row['status'] = 'UNKNOWN_AUDIT_OR_MAPPING'
                input_check(); budget_check(case_deadline, c['production']['wall_seconds'] + c['independent']['wall_seconds'] + limits['cleanup_reserve_seconds'])
                production_out = case / 'production'; production_process = case / 'production_process'
                command = [c['runtime']['python']['path'], '-I', '-S', '-B', c['production']['script']['path'], str(native), row['candidate'],
                           '--profiles', c['profiles']['path'], '--profile-sha256', c['profiles']['sha256'], '--output-dir', str(production_out)]
                row['production_launch_calls'] = 1
                p = invoke(command, production_process, case, case_deadline, c['production']['wall_seconds'], c['production']['stream_bytes'],
                           [production_out / x for x in ['certificate.json', 'derived_original_graph.json', 'derived_original_fairness.json']])
                row['production_process'] = pin(production_process / 'PROCESS_RECEIPT.json') if p.get('receipt_persisted') else None
                require(clean_owned_end(p), 'Production ownership/finalization incomplete; halt batch')
                if (production_out / 'certificate.json').is_file(): row['observed_production_certificate'] = pin(production_out / 'certificate.json')
                if valid_process(p) and (production_out / 'certificate.json').is_file():
                    try:
                        cert = read(production_out / 'certificate.json')
                        require(cert['fixture_id'] == row['candidate'] and cert['native_result_sha256'] == row['native_result']['sha256'], 'Production/native binding')
                        require(cert['original_profiles_sha256'] == c['profiles']['sha256'] and cert['checker_sha256'] == c['production']['script']['sha256'], 'Production profile/code binding')
                        require(cert.get('native_outcome') == row['native_observed_outcome'], 'Production/native outcome binding')
                        row['production_status'] = cert['status']; row['production_certificate'] = pin(production_out / 'certificate.json')
                    except Exception as exc:
                        row['production_status'] = 'UNKNOWN_PRODUCTION_BINDING'
                        row['errors'].append('PRODUCTION_BINDING:' + repr(exc))
                else:
                    row['production_status'] = 'UNKNOWN_PRODUCTION_PROCESS'
                    if p.get('fatal_reasons'): stop = True; continue
                input_check(); native_output_check('after production checker')
                budget_check(case_deadline, c['independent']['wall_seconds'] + limits['cleanup_reserve_seconds'])
                manifest = case / 'independent_inputs.json'; save_new(manifest, audit_manifest(c, config_row, native))
                independent_out = case / 'independent'; independent_process = case / 'independent_process'
                command = [c['runtime']['python']['path'], '-I', '-S', '-B', c['independent']['script']['path'], str(manifest), str(independent_out)]
                row['independent_launch_calls'] = 1
                a = invoke(command, independent_process, case, case_deadline, c['independent']['wall_seconds'], c['independent']['stream_bytes'],
                           [independent_out / x for x in ['AUDIT_RESULT.json', 'INDEPENDENT_VIEW.json']])
                row['independent_process'] = pin(independent_process / 'PROCESS_RECEIPT.json') if a.get('receipt_persisted') else None
                require(clean_owned_end(a), 'Independent ownership/finalization incomplete; halt batch')
                if (independent_out / 'AUDIT_RESULT.json').is_file(): row['observed_independent_audit'] = pin(independent_out / 'AUDIT_RESULT.json')
                if valid_process(a) and (independent_out / 'AUDIT_RESULT.json').is_file():
                    audit = read(independent_out / 'AUDIT_RESULT.json')
                    require(audit['candidate_id'] == row['candidate'], 'Independent candidate binding')
                    require(audit['native_outcome'] == row['native_observed_outcome'], 'Independent/native outcome binding')
                    if audit['status'] in ('COMPLETE_INDEPENDENT_RAW_GRAPH_AUDIT', 'COMPLETE_INDEPENDENT_NO_CONTROLLER'):
                        require(audit['input_manifest_pin'] == pin(manifest), 'Independent manifest identity')
                        require(audit['input_bindings'] == read(manifest)['inputs'], 'Independent exact source/model/native bindings')
                        if audit['status'] == 'COMPLETE_INDEPENDENT_RAW_GRAPH_AUDIT':
                            require(audit['view_pin'] == pin(independent_out / 'INDEPENDENT_VIEW.json'), 'Independent raw-view identity')
                    row['independent_status'] = audit['status']; row['independent_audit'] = pin(independent_out / 'AUDIT_RESULT.json')
                    row['independent_inputs'] = pin(manifest)
                else:
                    row['independent_status'] = 'UNKNOWN_INDEPENDENT_PROCESS'
                    if a.get('fatal_reasons'): stop = True
                row['semantic_status'] = row['status'] = classify(row)
                row['cross_audit_semantic_comparison'] = 'NOT_PERFORMED_BY_DISPATCHER'
                native_output_check('after independent audit')
            except BaseException as exc:
                row['errors'].append(type(exc).__name__ + ':' + str(exc))
                if row['status'].startswith('COMPLETE_'): row['status'] = 'UNKNOWN_CASE_EXCEPTION'; stop = True
                if isinstance(exc, (KeyboardInterrupt, SystemExit)) or 'ownership/finalization' in str(exc): stop = True
            finally:
                row['finished_utc'] = now().isoformat()
                try:
                    input_check(); usage = stage.tree_usage(case)
                    row['output_bytes_before_final_receipt'] = usage['bytes']
                    row['post_input_pin_check'] = 'PASS'
                    row['final_metadata_reserve_bytes'] = len(json_bytes(row)) + 4096
                    require(usage['bytes'] + row['final_metadata_reserve_bytes'] < limits['case_output_bytes'], 'Case final output threshold including metadata reserve reached')
                    require(stage.tree_usage(batch)['bytes'] + 2 * len(json_bytes(ledger)) + row['final_metadata_reserve_bytes'] + 4096 < limits['batch_output_bytes'], 'Batch output threshold including metadata reserve reached')
                    if row['integrity_status'] == 'NOT_CHECKED': row['integrity_status'] = 'PASS'
                except BaseException as exc:
                    row['status'] = row['integrity_status'] = 'UNKNOWN_POSTCHECK'; row['errors'].append('POSTCHECK:' + repr(exc)); stop = True
                if now() > case_deadline: row['status'] = row['integrity_status'] = 'UNKNOWN_CASE_DEADLINE'; stop = True
                save_new(case / 'CASE_RECEIPT.json', row)
                save_atomic(batch / 'RUN_PROGRESS.json', ledger)
            if stop: ledger['stop_reason'] = 'CASE_INTEGRITY_OR_FINALIZATION:' + row['candidate']
    except BaseException as exc:
        ledger['stop_reason'] = 'DISPATCH_EXCEPTION:' + repr(exc)
    finally:
        if stop and ledger['stop_reason'] is None:
            attempted = [r['candidate'] for r in rows if r['status'] != 'NOT_RUN']
            ledger['stop_reason'] = 'CASE_INTEGRITY_OR_FINALIZATION:' + (attempted[-1] if attempted else 'PRESTART')
        ledger['finished_utc'] = now().isoformat(); ledger['elapsed_seconds'] = time.monotonic() - started
        ledger['native_launch_calls'] = sum(row['native_launch_calls'] for row in rows)
        ledger['production_launch_calls'] = sum(row['production_launch_calls'] for row in rows)
        ledger['independent_launch_calls'] = sum(row['independent_launch_calls'] for row in rows)
        ledger['native_process_started_known'] = sum(row['native_process_started'] is True for row in rows)
        ledger['native_process_started_unknown'] = sum(row['native_process_started'] is None for row in rows)
        ledger['not_run_count'] = sum(row['status'] == 'NOT_RUN' for row in rows)
        ledger['status'] = 'BATCH_FINISHED_ALL_ROWS_RETAINED' if ledger['not_run_count'] == 0 else 'BATCH_STOPPED_ALL_ROWS_RETAINED'
        if ledger['elapsed_seconds'] > limits['batch_wall_seconds'] or now() > effective: ledger['stop_reason'] = 'BATCH_DEADLINE'
        try:
            input_check(); usage = stage.tree_usage(batch)
            ledger['final_output_bytes_before_receipt'] = usage['bytes']
            ledger['final_metadata_reserve_bytes'] = 2 * len(json_bytes(ledger)) + 4096
            require(usage['bytes'] + ledger['final_metadata_reserve_bytes'] < limits['batch_output_bytes'], 'Batch final output threshold including metadata reserve reached')
            ledger['post_input_pin_check'] = 'PASS'
        except BaseException as exc:
            ledger['post_input_pin_check'] = 'FAIL'; ledger['stop_reason'] = 'FINAL_POSTCHECK:' + repr(exc)
            for row in rows:
                if row['status'].startswith('COMPLETE_'): row['status_before_batch_postcheck'] = row['status']; row['status'] = row['integrity_status'] = 'UNKNOWN_BATCH_POSTCHECK'
        save_new(batch / 'RUN_RECEIPT.json', ledger)
        save_atomic(batch / 'RUN_PROGRESS.json', ledger)
    return ledger


def main():
    require(len(sys.argv) in (4, 5) and sys.argv[1] in ('preflight', 'run'), 'Usage: dispatch.py preflight CONFIG FROZEN [ROOT_GO] | run CONFIG FROZEN ROOT_GO')
    require(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode, 'Use Python -I -S -B')
    mode, config_path, frozen_path = sys.argv[1:4]
    # Three fixed positional inputs plus optional Root GO; no hidden commands.
    if mode == 'run': require(len(sys.argv) == 5, 'Run requires CONFIG FROZEN ROOT_GO')
    c, f = preflight(config_path, frozen_path)
    if mode == 'preflight':
        print(json.dumps({'status': 'METADATA_PREFLIGHT_PASS', 'candidate_order': ORDER, 'native_processes': 0, 'BDD_imports': 0, 'SCC_runs': 0})); return
    _, go_ref, deadline = authorize(config_path, frozen_path, sys.argv[4], c)
    result = execute(c, f, go_ref, deadline)
    print(json.dumps({key: result[key] for key in ('status', 'native_launch_calls', 'production_launch_calls', 'independent_launch_calls', 'not_run_count', 'stop_reason')}, ensure_ascii=False))


if __name__ == '__main__': main()
