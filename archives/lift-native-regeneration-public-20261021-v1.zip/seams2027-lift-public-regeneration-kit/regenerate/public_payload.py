"""Non-scientific public payload validation and selective extraction."""
from pathlib import Path, PurePosixPath
import hashlib, json, stat, zipfile

def check(value, message):
    if not value: raise ValueError(message)

def relative(value):
    path = PurePosixPath(value)
    check(value and not path.is_absolute() and '\\' not in value and all(x not in ('', '.', '..') for x in value.split('/')), 'Unsafe relative path: ' + value)
    return path

def contained(root, value):
    target = root.joinpath(*relative(value).parts)
    check(target.resolve().is_relative_to(root.resolve()), 'Path escapes root')
    return target

def identity(data, expected):
    check(len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256'], 'Payload identity mismatch')

def put(root, name, data, expected):
    identity(data, expected)
    path = contained(root, name)
    check(not path.exists() and not path.is_symlink(), 'Fresh payload path required')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream: stream.write(data)
    return path

def extract_selected(root, plan, selection, h):
    limits = plan['acquisition']['archive_expansion']; archive = root / 'downloads/source-package.zip'
    selected = {}
    check(len({x['destination'] for x in selection}) == len(selection), 'Unique selected destinations')
    for row in selection:
        expected = dict(bytes=row['bytes'], sha256=row['sha256'])
        check(row['member'] not in selected or selected[row['member']] == expected, 'Repeated selected member identity disagreement')
        selected[row['member']] = expected
    total = 0; names = set(); extracted = []
    with zipfile.ZipFile(archive) as source:
        entries = source.infolist()
        check(len(entries) <= limits['max_entries'] and len(entries) == limits['expected_entries'], 'Archive entry count')
        for entry in entries:
            name = entry.filename
            relative(name[:-1] if entry.is_dir() else name)
            check(name not in names, 'Duplicate archive name'); names.add(name)
            mode = entry.external_attr >> 16; filetype = stat.S_IFMT(mode)
            check(filetype in (0, stat.S_IFREG, stat.S_IFDIR), 'Archive symlink or special member')
            check(not entry.flag_bits & 1, 'Encrypted archive member')
            check(0 <= entry.file_size <= limits['max_member_bytes'], 'Archive member expansion cap')
            total += entry.file_size
            check(total <= limits['max_total_bytes'], 'Archive total expansion cap')
        check(total == limits['expected_bytes'], 'Expected declared archive expanded bytes')
        check(set(selected) <= names, 'Selected archive member missing')
        for row in selection:
            entry = source.getinfo(row['member'])
            check(not entry.is_dir() and entry.file_size == row['bytes'], 'Selected member exact size')
            with source.open(entry) as stream: data = stream.read(row['bytes'] + 1)
            path = put(root, row['destination'], data, row)
            extracted.append(dict(member=row['member'], file=h.pin(path)))
    h.save_new(root/'ARCHIVE_EXTRACTION_RECEIPT.json', dict(status='PASS_SELECTED_SOURCE_AND_CHECKER_MEMBERS_ONLY', archive=h.pin(archive), validated_entries=len(names), declared_expansion_bytes=total, unique_selected_source_members=len(selected), selected_destination_files=len(selection), extracted=extracted, historical_controller_members_extracted=0))
    return [x['file'] for x in extracted]

def materialize_inventory(root, config, fetch, payload, h):
    refs=[]; jars=[]; shadows=[]; manifest_cp=[]
    tops=[x.replace('.', '/') for x in config['custom_top_level_classes']]
    derived=fetch['ordered_jars'][-1]
    check(derived['index'] == 164 and derived['method'] == 'extract-exact-zip-member-after-parent-pin', 'Fixed derived last JAR')
    parent=next(x for x in fetch['requests'] if x['id'] == derived['parent_fetch_id'])
    h.verify([dict(path=str(root/parent['destination']), bytes=parent['bytes'], sha256=parent['sha256'])])
    with zipfile.ZipFile(root/parent['destination']) as archive:
        members=[x for x in archive.infolist() if x.filename==derived['member']]
        check(len(members)==1 and members[0].file_size==derived['bytes'], 'Exact derived JAR member')
        with archive.open(members[0]) as stream: data=stream.read(derived['bytes']+1)
    put(root,derived['destination'],data,derived)
    for row in fetch['ordered_jars']:
        path=contained(root,row['destination']);ref=h.pin(path)
        check(ref['bytes']==row['bytes'] and ref['sha256']==row['sha256'], 'Ordered JAR bytes')
        jars.append(ref)
        with zipfile.ZipFile(path) as archive:
            names=archive.namelist()
            for name in names:
                if any(name==t+'.class' or name.startswith(t+'$') and name.endswith('.class') for t in tops): shadows.append([row['index'],name])
            if 'META-INF/MANIFEST.MF' in names:
                text=archive.read('META-INF/MANIFEST.MF').decode('utf-8').replace('\r\n','\n').replace('\n ','')
                if any(line.lower().startswith('class-path:') for line in text.splitlines()): manifest_cp.append(row['index'])
    check(len(jars)==164 and not shadows and not manifest_cp, 'Exact 164 JARs without custom shadows or manifest classpath')
    source_refs={}
    for row in payload['all_fourteen_restored_source_outputs']:
        path=contained(root/'restored',row['path']);ref=h.pin(path)
        check(ref['bytes']==row['bytes'] and ref['sha256']==row['sha256'], 'Restored source identity')
        refs.append(ref);source_refs[row['sha256']]=ref
    sources=[source_refs[sha] for sha in config['source_order_sha256']]
    check(len(sources)==6 and len({x['path'] for x in sources})==6, 'Fixed six-source compile order')
    source=source_refs[config['candidate']['source_identity']['sha256']]
    check(source['bytes']==config['candidate']['source_identity']['bytes'], 'Candidate source identity')
    origins={name:jars[index-1]['path'] for name,index in config['origin_jar_indexes'].items()}
    with (root/'origins.properties').open('x') as stream: stream.write(''.join(k+'='+v+'\n' for k,v in origins.items()))
    expected={name:dict(path=jars[row['jar_index']-1]['path'],sha256=row['sha256']) for name,row in config['released_origin_classes'].items()}
    h.save_new(root/'ORIGIN_EXPECTATIONS.json',expected)
    for row in payload['scientific_checker_and_adapter_files']:
        ref=h.pin(root/row['destination']);check(ref['bytes']==row['bytes'] and ref['sha256']==row['sha256'],'Fresh public checker identity');refs.append(ref)
    profile=h.pin(root/'inputs/ORIGINAL_PROFILES.json');check(profile['bytes']==payload['profile']['bytes'] and profile['sha256']==payload['profile']['sha256'],'Public profile identity')
    refs += jars+[profile,h.pin(root/'origins.properties')]
    return dict(schema='public-source-dependency-runtime-inventory-v1',sources=sources,ordered_jars=jars,classpath_entries=[str(root/'build/classes')]+[x['path'] for x in jars],origin_map=origins,origins=h.pin(root/'origins.properties'),candidate=dict(id=config['candidate']['id'],source=source),profiles=profile,input_files=refs,jar_shadow_entries=shadows,jar_manifest_classpath_entries=manifest_cp,**{k:config[k] for k in ('java','javac','python','java_home','jdk_inventory','native_configuration','custom_class_roster')})
