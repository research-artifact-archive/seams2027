import java.nio.file.*;
import java.security.MessageDigest;
import java.util.HexFormat;
public final class OriginProbe {
  public static void main(String[] args) throws Exception {
    for (String name : Files.readAllLines(Path.of(args[0]))) {
      Class<?> c = Class.forName(name, false, ClassLoader.getSystemClassLoader());
      String resource = "/" + name.replace('.', '/') + ".class";
      byte[] bytes;
      try (var in = c.getResourceAsStream(resource)) { bytes = in.readAllBytes(); }
      System.out.println(name + "\t" + Path.of(c.getProtectionDomain().getCodeSource().getLocation().toURI()).toRealPath()
          + "\t" + HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes)));
    }
  }
}
