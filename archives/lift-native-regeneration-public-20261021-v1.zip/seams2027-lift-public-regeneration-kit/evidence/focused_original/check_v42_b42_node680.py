"""Focused offline residual check of saved Lift node680; no native run or solve."""
raise RuntimeError("Archived presentation copy; run focused/check_node680.py with fresh authorization instead.")
from pathlib import Path
from itertools import product
from collections import deque
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path("origin:workspace")  # presentation copy only; use focused/check_node680.py
BASE = ROOT / "experiment/lift_t_causal_diagnosis_20261021/runs/continuation_01/lift__trivial_1/native"
ENGINE = ROOT / "experiment/lift_t_clean_producer_20261021/attempt_02/code/baseline/production/bdd_core.py"


def pin(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


refs = [pin(BASE / name) for name in (
    "model.json", "controller.json", "original_rhoE.bdd",
    "original_rhoS.bdd", "final_region.bdd", "solver_ENV_justice_0.bdd",
)] + [pin(ENGINE)]
spec = importlib.util.spec_from_file_location("focused_bdd", ENGINE)
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)
model = json.loads((BASE / "model.json").read_text())
graph = json.loads((BASE / "controller.json").read_text())
assert graph["complete"] is True and graph["model_sha256"] == pin(BASE / "model.json")["sha256"]
bdd = engine.BDD(model["bdd_variable_count"])
rho_e, _ = bdd.read_native((BASE / "original_rhoE.bdd").read_bytes())
rho_s, _ = bdd.read_native((BASE / "original_rhoS.bdd").read_bytes())
raw_region, _ = bdd.read_native((BASE / "final_region.bdd").read_bytes())
justice, _ = bdd.read_native((BASE / "solver_ENV_justice_0.bdd").read_bytes())
for name in ("rhoE", "rhoS"):
    ref = model["original_bdds"][name]
    assert pin(BASE / ref["file"])["sha256"] == ref["sha256"]
fields = model["fields"]
env_bits = sorted(bit for f in fields if f["owner"] == "ENV" for bit in f["next_bits"])
sys_bits = sorted(bit for f in fields if f["owner"] == "SYS" for bit in f["next_bits"])
helper = next(f for f in fields if f["name"] == "~envHelp")
helper_now, helper_next = helper["current_bits"][0], helper["next_bits"][0]
env_inputs = [dict(zip(env_bits, v)) for v in product((False, True), repeat=len(env_bits))]
sys_outputs = [dict(zip(sys_bits, v)) for v in product((False, True), repeat=len(sys_bits))]
nodes = {n["id"]: n for n in graph["nodes"]}
assert len(nodes) == len(graph["nodes"])
adj = {n: [] for n in nodes}
for source, target in graph["edges"]:
    assert source in nodes and target in nodes and target not in adj[source]
    adj[source].append(target)
for key, node in nodes.items():
    assert set(adj[key]) == set(node["successors"])
current = {k: {int(b): v for b, v in n["bits"].items()} for k, n in nodes.items()}


def next_bits(node):
    return {
        int(bit): value
        for field in fields
        for bit, value in field["encoding"][node["valuation"][field["name"]]]["next"].items()
    }


target = current["680"]
assert target[helper_now] is False
legal_at_680 = [e for e in env_inputs if bdd.evaluate(rho_e, target | e)]
assert len(legal_at_680) == 16 and all(e[helper_next] for e in legal_at_680)
# This local quantified check includes all 16 source inputs; helper is fixed false.
safe_counts = []
for e in env_inputs:
    if e[helper_next]:
        continue
    safe_counts.append(sum(bdd.evaluate(rho_s, target | e | y) for y in sys_outputs))
assert len(safe_counts) == 16 and min(safe_counts) > 0
reached, queue, checked_edges = {"680"}, deque(["680"]), 0
while queue:
    source = queue.popleft()
    bits = current[source]
    if source != "680":
        assert bits[helper_now] is True
        assert bdd.evaluate(justice, bits) is False
    by_input = {}
    for destination in adj[source]:
        nxt = next_bits(nodes[destination])
        assert bdd.evaluate(rho_e, bits | nxt)
        assert bdd.evaluate(rho_s, bits | nxt)
        assert nxt[helper_next] is True
        key = tuple(nxt[x] for x in env_bits)
        assert key not in by_input
        by_input[key] = destination
        checked_edges += 1
        if destination not in reached:
            reached.add(destination)
            queue.append(destination)
    expected = {
        tuple(e[x] for x in env_bits)
        for e in env_inputs if bdd.evaluate(rho_e, bits | e)
    }
    assert set(by_input) == expected and expected
assert all(pin(Path(ref["path"])) == ref for ref in refs)
report = {
    "status": "PASS_FOCUSED_SAVED_RESIDUAL_CERTIFICATE",
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "mode": "Offline finite inspection of saved graph and BDD relations; no native process, extraction, or region solving.",
    "inputs": refs,
    "checker": pin(Path(__file__).resolve()),
    "node_id": "680",
    "valuation": nodes["680"]["valuation"],
    "raw_core_membership": bdd.evaluate(raw_region, target),
    "original_C_at_node": True,
    "safe_responses_per_source_input": safe_counts,
    "original_legal_next_input_count": 0,
    "native_legal_next_input_count": len(legal_at_680),
    "every_native_legal_input_flips_helper": True,
    "residual_graph": {
        "states": len(reached),
        "edges": checked_edges,
        "exact_legal_input_coverage": True,
        "unique_response": True,
        "all_edges_native_environment_and_system_safe": True,
        "all_successor_states_helper_true": True,
        "helper_environment_justice_false_on_every_successor_state": True,
    },
    "strict_membership_conclusion": "The reached saved private memory at node680 witnesses strict winning of the actual saved transformed arena: every legal first move flips the helper, all future moves remain safe with helper true, and its added environment justice is thereafter false. Hence the full source valuation with helper false belongs to the actual strict W_R.",
    "attribution_boundary": "The raw core and actual strict game permit this dead end. The paired intervention establishes that choosing a different extraction response with unchanged upstream data yields a passing original-contract graph; it does not identify extraction as the unique root cause or repair the permissive game generally.",
    "independence_limit": "Reuses the already qualified Python BDD decoder and saved native model/graph; not an independent compiler or new all-region certificate.",
}
out = Path(__file__).resolve().parent / "V42_B42_NODE680_SAVED_RESIDUAL_CHECK.json"
with out.open("x") as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
print(json.dumps({k: report[k] for k in ("status", "raw_core_membership", "original_C_at_node", "residual_graph")}))
