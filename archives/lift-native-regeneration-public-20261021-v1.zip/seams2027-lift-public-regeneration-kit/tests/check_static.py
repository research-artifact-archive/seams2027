"""Synthetic structural/privacy checks only; no BDD, graph proof, native or network run."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import sys
import tempfile
import urllib.error
import urllib.request

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    if len(sys.argv) != 2:
        raise ValueError('Usage: check_static.py FRESH_OUTPUT_DIRECTORY')
    output = Path(sys.argv[1]).resolve()
    output.mkdir()
    config = load('static_config', HERE/'configure_run.py')
    bindings = load('static_bindings', HERE/'focused/model_bindings.py')
    fetch = load('static_fetch', HERE/'regenerate/fetch_one.py')
    manifest = config.verify_kit()
    checks = []
    def ok(name, fn):
        fn()
        checks.append({'case': name, 'pass_check': True})
    def bad(name, fn):
        try:
            fn()
        except (ValueError, KeyError, TypeError):
            checks.append({'case': name, 'pass_check': True})
            return
        raise AssertionError('Invalid synthetic input accepted: ' + name)
    for path in HERE.rglob('*.py'):
        compile(path.read_text(), str(path), 'exec')
    checks.append({'case': 'all_Python_sources_parse_without_execution', 'pass_check': True})
    forbidden = [('/'+'Users/').encode(), ('/'+'home/').encode(), ('it'+'aku3').encode()]
    for path in HERE.rglob('*'):
        if path.is_file():
            raw = path.read_bytes()
            if any(x in raw for x in forbidden):
                raise AssertionError('Private path/user label found: ' + str(path.relative_to(HERE)))
    checks.append({'case': 'all_distributed_files_no_private_user_path_labels', 'pass_check': True})
    for value in ('../x', '/absolute', 'a/../b', 'a//b', 'a/./b', 'a\\b', ''):
        bad('relative_path_reject_' + repr(value), lambda value=value: config.relative(value))
    bad('sandbox_output_not_child', lambda: config.sandbox(Path('/synthetic/work'), Path('/synthetic/elsewhere'), False))
    bad('sandbox_output_equals_workspace', lambda: config.sandbox(Path('/synthetic/work'), Path('/synthetic/work'), True))
    bad('sandbox_control_character', lambda: config.sbpl_path('/synthetic/line\nbreak'))
    acquisition, ancestors = config.sandbox(Path('/synthetic/work'), Path('/synthetic/work/a/run'), False)
    offline, _ = config.sandbox(Path('/synthetic/work'), Path('/synthetic/work/a/run'), True)
    assert len(ancestors) == 2 and '(deny network*)' not in acquisition and '(deny network*)' in offline
    assert '(literal "/synthetic/work/a/run/downloads/source-package.zip")' in offline
    assert config.sbpl_path('/synthetic/a"b') == json.dumps('/synthetic/a"b', ensure_ascii=False)
    checks.append({'case': 'sandbox_ancestor_metadata_rawZIP_network_and_escaping', 'pass_check': True})
    def field(name, owner, start):
        return dict(name=name, owner=owner, role=owner, domain_size=2, values=['false','true'], current_bits=[start], next_bits=[start+1],
                    encoding={value: {'current': {str(start): bit}, 'next': {str(start+1): bit}} for value,bit in [('false',False),('true',True)]})
    model = dict(fields=[field('b','ENV',0),field('x','SYS',2)], all_current_bits=[0,2], all_next_bits=[1,3], bdd_variable_count=4, bdd_variable_order=[0,1,2,3])
    graph = dict(complete=True, rank_domain_size=1, api_state_count=1, api_transition_count=1,
                 nodes=[dict(id='0',rank=0,valuation={'b':'false','x':'false'},bits={'0':False,'2':False},successors=['0'])],edges=[['0','0']])
    ok('synthetic_typed_graph_valid', lambda: bindings.validate_model_graph(model, graph))
    mutations = [
        ('owner',lambda m,g:m['fields'][0].update(owner='UNKNOWN')),
        ('domain',lambda m,g:m['fields'][0].update(domain_size=3)),
        ('current_bits_valuation',lambda m,g:g['nodes'][0]['bits'].update({'0':True})),
        ('untyped_valuation',lambda m,g:g['nodes'][0]['valuation'].update(b='third')),
        ('rank',lambda m,g:g['nodes'][0].update(rank=1)),
        ('duplicate_node',lambda m,g:(g['nodes'].append(copy.deepcopy(g['nodes'][0])),g.update(api_state_count=2))),
        ('missing_edge_node',lambda m,g:g['edges'][0].__setitem__(1,'absent')),
        ('nonboolean_bit',lambda m,g:g['nodes'][0]['bits'].update({'0':0})),
        ('missing_valuation_field',lambda m,g:g['nodes'][0]['valuation'].pop('x')),
        ('overlapping_bit_owner',lambda m,g:m['fields'][1].update(current_bits=[0])),
        ('noninjective_encoding',lambda m,g:m['fields'][0]['encoding']['true'].update(current={'0':False})),
        ('duplicate_successor',lambda m,g:g['nodes'][0]['successors'].append('0')),
        ('invalid_BDD_order',lambda m,g:m.update(bdd_variable_order=[0,1,2,2])),
        ('incomplete_graph',lambda m,g:g.update(complete=False)),
        ('wrong_edge_count',lambda m,g:g.update(api_transition_count=2)),
    ]
    for name, mutate in mutations:
        m,g=copy.deepcopy(model),copy.deepcopy(graph);mutate(m,g)
        bad('typed_graph_reject_'+name, lambda m=m,g=g:bindings.validate_model_graph(m,g))
    raw=b'{"synthetic":"unchanged model"}'
    before=dict(model_raw=raw,graph={'model_sha256':'old','nodes':[{'id':'0','bits':{'0':False}}],'edges':[['0','0']]},
                result={'model_export':{'sha256':'old'},'complete':True},bdds={'synthetic.bdd':b'synthetic'},printer=b'printer')
    after=copy.deepcopy(before);after['graph']['model_sha256']=hashlib.sha256(raw).hexdigest();after['result']['model_export']['sha256']='new'
    ok('synthetic_bridge_exact_allowed_metadata_only', lambda:bindings.check_bridge(before,after,['model_export.sha256']))
    for name, mutate in [('node',lambda x:x['graph']['nodes'][0]['bits'].update({'0':True})),('edge',lambda x:x['graph']['edges'].append(['0','1'])),
                          ('typed_model_bytes',lambda x:x.update(model_raw=b'changed')),('BDD_bytes',lambda x:x['bdds'].update({'synthetic.bdd':b'changed'})),
                          ('printer_bytes',lambda x:x.update(printer=b'changed')),('nonbinding_result',lambda x:x['result'].update(complete=False)),
                          ('invalid_model_hash',lambda x:x['graph'].update(model_sha256='arbitrary'))]:
        changed=copy.deepcopy(after);mutate(changed)
        bad('bridge_reject_'+name,lambda changed=changed:bindings.check_bridge(before,changed,['model_export.sha256']))
    jr={'file':'original_ENV_justice_0.bdd','bytes':1,'sha256':'a'*64};jm={'original_justices':{'ENV':[jr]}};jp={'bytes':1,'sha256':'a'*64}
    ok('synthetic_justice_metadata_identity',lambda:bindings.check_justice_metadata(jm,jp,jp))
    bad('justice_solver_identity_mismatch',lambda:bindings.check_justice_metadata(jm,jp,dict(jp,sha256='b'*64)))
    bad('justice_original_identity_mismatch',lambda:bindings.check_justice_metadata(jm,dict(jp,bytes=2),jp))
    bad('justice_extra_ENV_row',lambda:bindings.check_justice_metadata({'original_justices':{'ENV':[jr,jr]}},jp,jp))
    class Response:
        def __init__(self, code):
            self.code=self.status=code;self.msg='synthetic';self.headers={'Location':'/next'};self.closed=False;self.reads=0
        def info(self):return self.headers
        def geturl(self):return 'https://arxiv.org/synthetic'
        def read(self,*args):self.reads+=1;raise AssertionError('Redirect/error body read')
        def close(self):self.closed=True
    class SyntheticHTTPS(urllib.request.HTTPSHandler):
        def __init__(self,response):super().__init__();self.response=response
        def https_open(self,request):return self.response
    for status in [301,302,303,307,308]:
        response=Response(status)
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),SyntheticHTTPS(response),fetch.ReturnRedirect())
        returned=opener.open('https://arxiv.org/synthetic',timeout=1)
        assert returned.status==status;returned.close();assert response.closed and response.reads==0
        checks.append({'case':'real_urllib_dispatch_without_network_'+str(status),'pass_check':True})
    response=Response(503);opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),SyntheticHTTPS(response),fetch.ReturnRedirect())
    try:
        opener.open('https://arxiv.org/synthetic',timeout=1)
        raise AssertionError('503 accepted')
    except urllib.error.HTTPError as exc:
        exc.close();assert response.closed and response.reads==0
    checks.append({'case':'real_urllib_error_dispatch_no_body_read','pass_check':True})
    report=dict(status='PASS_NONSCIENTIFIC_STATIC_AND_SYNTHETIC_CHECKS',checks=checks,kit_manifest=manifest,
                public_network_calls=0,Java_invocations=0,BDD_or_scientific_graph_runs=0,
                scope='Artificial tiny structures and mocked HTTP response dispatch only; real public node680 and native regeneration are not executed.')
    with (output/'RESULT.json').open('x') as stream:json.dump(report,stream,ensure_ascii=False,indent=2);stream.write('\n')
    print(json.dumps(dict(status=report['status'],checks=len(checks))))


if __name__=='__main__':main()
