"""Verify one saved public node680 residual certificate; no native run or solve."""
from pathlib import Path, PurePosixPath
from itertools import product
from collections import deque
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import sys
import traceback

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent


def need(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    def unique(pairs):
        out = {}
        for key, value in pairs:
            need(key not in out, 'Duplicate JSON key')
            out[key] = value
        return out
    return json.loads(Path(path).read_text(), object_pairs_hook=unique)


def pin(path):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), 'Regular input file required')
    need(path.stat().st_size <= 16 * 1024 * 1024, 'Input16MiB cap')
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def match(path, expected):
    actual = pin(path)
    need(all(actual[key] == expected[key] for key in ('bytes', 'sha256')), 'Exact input identity mismatch')
    return actual


def member(root, name):
    value = PurePosixPath(name)
    need(name and not value.is_absolute() and '\\' not in name
         and all(x not in ('', '.', '..') for x in name.split('/')), 'Unsafe declared member')
    path = root.joinpath(*value.parts)
    need(path.resolve(strict=True).is_relative_to(root), 'Declared member escape')
    return path


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def snapshot(directory):
    return dict(model_raw=(directory/'model.json').read_bytes(), graph=load(directory/'controller.json'),
                result=load(directory/'result.json'), printer=(directory/'controller.txt').read_bytes(),
                bdds={path.name: path.read_bytes() for path in directory.glob('*.bdd')})


def check(args, output):
    inputs = load(HERE/'INPUTS.json')
    controls = [pin(HERE/name) for name in ('check_node680.py', 'model_bindings.py', 'INPUTS.json')]
    authorization = load(args.authorization)
    need(authorization['status'] == 'GO' and authorization['inputs'] == controls
         and authorization['output'] == str(output), 'New focused execution authorization bound to exact files/output required')
    need(sys.flags.optimize == 0, 'Python optimization forbidden')
    bundle = args.bundle.resolve(strict=True)
    sources = args.sources.resolve(strict=True)
    need(bundle.is_dir() and sources.is_dir() and bundle != sources, 'Distinct public input roots')
    need(not output.is_relative_to(bundle) and not bundle.is_relative_to(output)
         and not output.is_relative_to(sources) and not sources.is_relative_to(output), 'Fresh output must be disjoint from inputs')
    refs = [match(bundle/'MANIFEST.json', inputs['base_manifest']), match(bundle/'ORIGINAL_COPY_LEDGER.json', inputs['base_ledger'])]
    refs += [match(member(bundle, row['member']), row) for row in inputs['imports'] + inputs['files']]
    refs += [match(member(sources, inputs['source']['path']), inputs['source'])]
    bindings = module('focused_public_bindings', HERE/'model_bindings.py')
    bridge = module('focused_public_replay', bundle/'consumer/replay.py')
    resolver = bridge.io.Resolver(bundle, sources)
    original = bundle/'evidence/runs/continuation_01/lift__trivial_1/native'
    before = snapshot(original)
    view = output/'public_view'
    bridge_receipt = bridge.public_view(resolver, original, view)
    after = snapshot(view)
    invariant = bindings.check_bridge(before, after, inputs['bridge_result_allowed_fields'])
    save(output/'BRIDGE_RECEIPT.json', dict(existing_bridge=bridge_receipt, explicit_invariants=invariant,
         public_manifest=refs[0], original_copy_ledger=refs[1], prior_graph=pin(original/'controller.json'),
         public_view_graph=pin(view/'controller.json'), model=pin(view/'model.json')))
    model, graph = load(view/'model.json'), load(view/'controller.json')
    for data in (model, graph):
        need(data['fixture_id'] == data['case_id'] == 'lift__trivial_1' and data['variant'] == 'initializers', 'Fixed saved Lift identity')
    need(graph['api_state_count'] == inputs['graph_states'] and graph['api_transition_count'] == inputs['graph_edges'], 'Fixed complete saved graph counts')
    fields, nodes, current, following, adjacency = bindings.validate_model_graph(model, graph)
    engine = module('focused_public_bdd', bundle/'code/released/production/bdd_core.py')
    bdd = engine.BDD(model['bdd_variable_count'])
    roots = {}
    for key, filename in [('rhoE', 'original_rhoE.bdd'), ('rhoS', 'original_rhoS.bdd')]:
        declared = model['original_bdds'][key]
        need(declared['file'] == filename, 'Exact original relation name')
        match(view/filename, declared)
        roots[key], _ = bdd.read_native((view/filename).read_bytes())
    raw_region, _ = bdd.read_native((view/'final_region.bdd').read_bytes())
    justice_ref = bindings.check_justice_metadata(model, pin(view/'original_ENV_justice_0.bdd'), pin(view/'solver_ENV_justice_0.bdd'))
    match(view/'original_ENV_justice_0.bdd', justice_ref)
    match(view/'solver_ENV_justice_0.bdd', justice_ref)
    need((view/'original_ENV_justice_0.bdd').read_bytes() == (view/'solver_ENV_justice_0.bdd').read_bytes(), 'Solver/original justice bytes differ')
    justice, _ = bdd.read_native((view/'solver_ENV_justice_0.bdd').read_bytes())
    helper = [f for f in fields if f['name'] == '~envHelp']
    need(len(helper) == 1 and helper[0]['owner'] == 'ENV' and helper[0]['values'] == ['false', 'true'], 'Typed environment helper')
    helper = helper[0]
    helper_now, helper_next = helper['current_bits'][0], helper['next_bits'][0]
    need(helper['encoding']['false']['current'] == {str(helper_now): False}
         and helper['encoding']['true']['current'] == {str(helper_now): True}
         and helper['encoding']['false']['next'] == {str(helper_next): False}
         and helper['encoding']['true']['next'] == {str(helper_next): True}, 'Helper label/Boolean encoding identity')
    current_bits = model['all_current_bits']
    need(len(current_bits) == 11, 'Bounded fixed Lift current assignment space')
    justice_assignments = 0
    for values in product((False, True), repeat=len(current_bits)):
        state = dict(zip(current_bits, values))
        need(bdd.evaluate(justice, state) == (not state[helper_now]), 'Sole ENV justice is not NOT helper')
        justice_assignments += 1
    env_bits = sorted(bit for f in fields if f['owner'] == 'ENV' for bit in f['next_bits'])
    sys_bits = sorted(bit for f in fields if f['owner'] == 'SYS' for bit in f['next_bits'])
    need(len(env_bits) == 5 and len(sys_bits) == 6 and len(current_bits) == 11, 'Fixed Lift ownership/domain sizes')
    env_inputs = [dict(zip(env_bits, v)) for v in product((False, True), repeat=len(env_bits))]
    sys_outputs = [dict(zip(sys_bits, v)) for v in product((False, True), repeat=len(sys_bits))]
    ident = inputs['node_id']
    need(ident in nodes and nodes[ident]['valuation'] == inputs['valuation'] and nodes[ident]['rank'] == inputs['rank'], 'Exact full node680 valuation and private rank')
    target = current[ident]
    need(target[helper_now] is False, 'Source helper must be false')
    legal = [e for e in env_inputs if bdd.evaluate(roots['rhoE'], target | e)]
    need(len(legal) == 16 and all(e[helper_next] for e in legal), 'Exactly16 native legal helper-flipping inputs')
    original_inputs = [e for e in env_inputs if not e[helper_next]]
    original_legal = [e for e in original_inputs if bdd.evaluate(roots['rhoE'], target | e)]
    safe_counts = [sum(bdd.evaluate(roots['rhoS'], target | e | y) for y in sys_outputs) for e in original_inputs]
    need(len(original_inputs) == 16 and not original_legal and safe_counts == [3] * 16, 'Source C/empty original legal input certificate')
    reached, queue, checked_edges = {ident}, deque([ident]), 0
    while queue:
        source = queue.popleft()
        bits = current[source]
        if source != ident:
            need(bits[helper_now] is True and bdd.evaluate(justice, bits) is False, 'Residual successor must falsify ENV justice')
        by_input = {}
        for destination in adjacency[source]:
            nxt = following[destination]
            need(bdd.evaluate(roots['rhoE'], bits | nxt) and bdd.evaluate(roots['rhoS'], bits | nxt), 'Residual transition unsafe')
            need(nxt[helper_next] is True, 'Residual transition does not keep helper true')
            key = tuple(nxt[x] for x in env_bits)
            need(key not in by_input, 'More than one response to a legal input')
            by_input[key] = destination
            checked_edges += 1
            if destination not in reached:
                reached.add(destination)
                queue.append(destination)
        expected = {tuple(e[x] for x in env_bits) for e in env_inputs if bdd.evaluate(roots['rhoE'], bits | e)}
        need(expected and set(by_input) == expected, 'Incomplete legal environment input coverage')
    need(len(reached) == inputs['residual_states'] and checked_edges == inputs['residual_edges'], 'Exact saved residual size')
    # Revalidate all public files and restored source identities after inspection.
    bridge.io.Resolver(bundle, sources)
    need(all(pin(Path(ref['path'])) == ref for ref in refs + controls), 'Input/control mutation')
    report = dict(status='PASS_PUBLIC_FOCUSED_SAVED_RESIDUAL_CERTIFICATE', created_utc=datetime.now(timezone.utc).isoformat(),
        mode='Offline finite saved evidence inspection; no Java, compiler, solver or controller extraction.',
        inputs=refs, controls=controls, authorization=pin(args.authorization), bridge=pin(output/'BRIDGE_RECEIPT.json'),
        model_bindings=dict(all_nodes_typed_bit_valuation_consistent=True, all_ranks_valid=True,
            original_relation_hashes_verified=True, sole_original_and_solver_ENV_justice_identical=True,
            ENV_justice_exhaustively_NOT_helper=True, justice_assignments=justice_assignments),
        node_id=ident, valuation=nodes[ident]['valuation'], raw_core_membership=bdd.evaluate(raw_region, target),
        original_C_at_node=True, safe_responses_per_source_input=safe_counts, original_legal_next_input_count=len(original_legal),
        native_legal_next_input_count=len(legal), every_native_legal_input_flips_helper=True,
        residual_graph=dict(states=len(reached), edges=checked_edges, exact_legal_input_coverage=True,
            unique_response=True, all_edges_native_environment_and_system_safe=True,
            all_successor_states_helper_true=True, helper_environment_justice_false_on_every_successor_state=True),
        strict_membership_conclusion='The saved private memory gives a safe complete continuation from the full source valuation with helper=false. Every legal first input flips helper, every future state keeps helper=true and falsifies the sole ENV justice. Therefore this state belongs to the actual saved transformed strict W_R; initial-state reachability is not required for state winning.',
        attribution_boundary='Raw core membership is separate. This does not identify the entire raw core with W_R, recompute all-region winning, prove extraction the unique root cause, or establish a general repair.',
        independence_limit='Reuses the pinned public BDD decoder and saved graph/model. New explicit type/bit/justice binding checks do not constitute an independent compiler.',
        native_runs=0, compiler_runs=0, network_calls=0)
    save(output/'RESULT.json', report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', type=Path, required=True)
    parser.add_argument('--sources', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--authorization', type=Path, required=True)
    args = parser.parse_args()
    need(not args.out.exists() and not args.out.is_symlink(), 'Fresh focused output required')
    output = args.out.resolve()
    output.mkdir()
    try:
        report = check(args, output)
        print(json.dumps({k: report[k] for k in ('status', 'raw_core_membership', 'original_C_at_node', 'residual_graph')}))
    except BaseException as exc:
        save(output/'FAILURE.json', dict(status='FAIL_OR_UNKNOWN_PUBLIC_FOCUSED_CHECK', error=type(exc).__name__+': '+str(exc),
             traceback=traceback.format_exc(), native_runs=0, compiler_runs=0, network_calls=0))
        raise


if __name__ == '__main__':
    main()
