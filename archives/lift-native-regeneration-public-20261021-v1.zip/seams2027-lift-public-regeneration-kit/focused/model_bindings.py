"""Pure structural checks for the saved typed model and metadata-only bridge."""
import hashlib


def need(condition, message):
    if not condition:
        raise ValueError(message)


def integer(value):
    return type(value) is int


def difference_paths(left, right, path=''):
    if isinstance(left, dict) and isinstance(right, dict):
        need(set(left) == set(right), 'Bridge changed dictionary keys: ' + path)
        result = []
        for key in left:
            result += difference_paths(left[key], right[key], path + ('.' if path else '') + key)
        return result
    return [] if left == right and type(left) is type(right) else [path]


def check_bridge(before, after, allowed_result_fields):
    need(before['model_raw'] == after['model_raw'], 'Bridge altered public model bytes')
    need(before['bdds'] == after['bdds'], 'Bridge altered BDD bytes or roster')
    need(before['printer'] == after['printer'], 'Bridge altered printer bytes')
    changed = difference_paths(before['graph'], after['graph'])
    need(set(changed) <= {'model_sha256'}, 'Bridge altered graph science or metadata')
    need(after['graph']['model_sha256'] == hashlib.sha256(after['model_raw']).hexdigest(), 'Public model binding mismatch')
    result_changed = difference_paths(before['result'], after['result'])
    need(set(result_changed) <= set(allowed_result_fields), 'Bridge altered nonbinding result fields')
    return dict(model_bytes_unchanged=True, BDD_bytes_and_roster_unchanged=True, printer_bytes_unchanged=True,
                complete_nodes_edges_ranks_valuations_and_successors_unchanged=True,
                typed_fields_relations_ordered_justices_unchanged=True,
                graph_modified_fields=changed, result_modified_fields=result_changed)


def validate_model_graph(model, graph):
    fields = model['fields']
    need(isinstance(fields, list) and 0 < len(fields) <= 32, 'Bounded typed field list')
    names = [f['name'] for f in fields]
    need(all(isinstance(n, str) and n for n in names) and len(set(names)) == len(names), 'Unique typed field names')
    current, following = [], []
    for field in fields:
        need(field['owner'] in ('ENV', 'SYS') and field['role'] in ('ENV', 'SYS', 'AUX'), 'Typed owner and role')
        need(field['role'] == 'ENV' if field['owner'] == 'ENV' else field['role'] in ('SYS', 'AUX'), 'Owner/role correspondence')
        values = field['values']
        need(integer(field['domain_size']) and field['domain_size'] == 2 and len(values) == 2
             and len(set(values)) == 2 and all(isinstance(v, str) for v in values), 'Exact two-value typed domains')
        need(set(field['encoding']) == set(values), 'Encoding domain differs')
        for key, destination in [('current_bits', current), ('next_bits', following)]:
            bits = field[key]
            need(len(bits) == 1 and all(integer(x) and x >= 0 for x in bits), 'One Boolean bit per two-value field')
            destination += bits
        for value in values:
            encoding = field['encoding'][value]
            need(set(encoding) == {'current', 'next'}, 'Encoding phase keys')
            for phase, bit_key in [('current', 'current_bits'), ('next', 'next_bits')]:
                encoded = encoding[phase]
                need(set(encoded) == {str(x) for x in field[bit_key]}
                     and all(type(x) is bool for x in encoded.values()), 'Exact typed Boolean encoding')
        for phase in ('current', 'next'):
            need(field['encoding'][values[0]][phase] != field['encoding'][values[1]][phase], 'Noninjective typed encoding')
    count = model['bdd_variable_count']
    need(integer(count) and 0 < count <= 64, 'BDD variable count')
    need(len(set(current + following)) == len(current + following), 'Overlapping field bit ownership')
    need(set(current + following) == set(range(count)), 'Exact model bit coverage')
    need(model['all_current_bits'] == current and model['all_next_bits'] == following, 'Declared bit lists disagree with typed fields')
    order = model['bdd_variable_order']
    need(len(order) == count and all(integer(x) for x in order) and set(order) == set(range(count)), 'BDD order must be a variable permutation')
    need(graph['complete'] is True, 'Incomplete graph')
    ranks = graph['rank_domain_size']
    need(integer(ranks) and 0 < ranks <= 32, 'Rank domain')
    rows, edges = graph['nodes'], graph['edges']
    need(isinstance(rows, list) and len(rows) <= 4096 and isinstance(edges, list) and len(edges) <= 131072, 'Saved graph inspection size cap')
    need(integer(graph['api_state_count']) and graph['api_state_count'] == len(rows)
         and integer(graph['api_transition_count']) and graph['api_transition_count'] == len(edges), 'Complete graph counts')
    nodes = {}
    now = {}
    nxt = {}
    for row in rows:
        ident = row['id']
        need(isinstance(ident, str) and ident not in nodes, 'Unique node identity')
        need(integer(row['rank']) and 0 <= row['rank'] < ranks, 'Node rank outside declared domain')
        valuation = row['valuation']
        need(set(valuation) == set(names), 'Node valuation fields differ')
        encoded_now, encoded_next = {}, {}
        for field in fields:
            value = valuation[field['name']]
            need(value in field['values'], 'Value outside typed domain')
            encoded_now.update(field['encoding'][value]['current'])
            encoded_next.update(field['encoding'][value]['next'])
        need(set(row['bits']) == {str(x) for x in current} and all(type(x) is bool for x in row['bits'].values()), 'Exact node current-bit assignment')
        need(row['bits'] == encoded_now, 'Node bits disagree with typed valuation')
        need(isinstance(row['successors'], list) and len(set(row['successors'])) == len(row['successors']), 'Duplicate node successor')
        nodes[ident] = row
        now[ident] = {int(k): v for k, v in encoded_now.items()}
        nxt[ident] = {int(k): v for k, v in encoded_next.items()}
    adjacency = {ident: [] for ident in nodes}
    seen = set()
    for edge in edges:
        need(isinstance(edge, list) and len(edge) == 2 and all(isinstance(x, str) for x in edge), 'Edge shape')
        source, target = edge
        need(source in nodes and target in nodes and (source, target) not in seen, 'Missing edge node or duplicate edge')
        seen.add((source, target))
        adjacency[source].append(target)
    for ident, row in nodes.items():
        need(set(adjacency[ident]) == set(row['successors']), 'Edge/successor list disagreement')
    return fields, nodes, now, nxt, adjacency


def check_justice_metadata(model, original_pin, solver_pin):
    rows = model['original_justices']['ENV']
    need(len(rows) == 1 and rows[0]['file'] == 'original_ENV_justice_0.bdd', 'Exactly one named ENV justice required')
    need(all(original_pin[key] == rows[0][key] == solver_pin[key] for key in ('bytes', 'sha256')),
         'Original/solver ENV justice identities differ from model')
    return rows[0]
