Portable saved-evidence replay candidate

Run with Python 3.9 or newer, using only the standard library:

  python3 replay.py --bundle /absolute/path/to/bundle --out /absolute/path/to/new-output

The output directory must be new or empty. Use --stages patrol manager to omit
the optional saved reduced-query binding stage. Execute replay.py; the preserved
historical auditors under data/ are provenance and code inputs, not standalone
relocatable command entrypoints.

This checker recomputes:
* Patrol: typed saved-native-table graph/countercertificate bindings, all 103 safe
  replies of the 26-node countercertificate, and the actual-new helper quadrant
  premises U=D, F=C and retained auxiliary monitors.
* Manager: saved graph coverage/safety/SCCs, independent source-predicate equality
  on all 1,048,576 current/next source-state pairs, 69 sequential recorded events,
  three paused candidate decisions/installations, and 36 subsequent commits.
* Reduced query: typed Boolean query identities, saved native predicate/output
  bindings, and all 4,800 saved layout-state memberships (1,104 reduced winners).

It does not rerun native synthesis, extract a controller, reexecute the manager
worker, regenerate native winning fixed points, or retry the full-helper query.
That query remains UNKNOWN. It does not verify omitted historical source/runtime
pins or reconstruct the original native process. Native compiler/exporter,
encoding metadata, saved native winning-region provenance and recorded process
provenance remain trust boundaries. See OMITTED_HISTORICAL_CHECKS.json.

INPUT_LEDGER.json distinguishes original record hashes from anonymous transport
hashes and the package-relative copies. Copied data bytes remain unchanged.
MANIFEST.json verifies transport identity; semantic checks are separate and do
not accept producer PASS flags as their proof. ADAPTER_EXTRACTION.json identifies
the preserved independent code and exact semantic portions reused by the adapter.

The bundle contains original checking code and saved outputs only. It excludes
publisher PDFs/HTML, paper-derived Spectra specifications, upstream Java, JDKs,
JARs, native libraries and compiled classes. LICENSE-original.txt applies to
original artifact contributions. No external source restoration or network
access is needed for the declared saved-evidence verification scope.

Fresh positive and malformed-input qualification records are delivered separately.
This directory is a local candidate until its qualification record is reviewed.
