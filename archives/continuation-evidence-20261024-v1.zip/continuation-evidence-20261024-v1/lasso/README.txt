LIFT LASSO EVIDENCE AND SAVED REPLAY

Start with replay/README.txt. Run with Python 3.10+ on a POSIX host:

  python3 -I -S -B LASSO/replay/replay_lasso.py --bundle LASSO/replay \
    --out FRESH_OUTPUT --timeout-seconds 60

FRESH_OUTPUT must be a new directory outside the bundle. Each invocation
starts its own deadline, capped at 60 seconds. No network or native runtime
is required. Expected status: PASS_SAVED_LASSO_REPLAY.

The retained initialized prefix -> loop -> loop satisfies both arena edges
and every SYS justice, while the sole ENV justice is false on the loop.
All 19 saved DAG files and the three justice stages are checked, with the
unchanged authored source oracle. This witnesses failure of the language-
inclusion premise for this frozen transformed exported arena only.

qualification/QUALIFICATION.json records one successful author-host sandbox
replay plus BDD-corruption and rehashed-justice-roster rejection controls.
Workspace read/write and network were each probed for EPERM before replay.
No lasso replay failure was hidden; the first authorized attempt passed.
No solver, search, arena enumeration or controller extraction was performed.

This is not a repeated original 25-pin check: source Spectra and final_region
remain hash-only omissions. The 23 supplied semantic payloads include two
metadata projections, 19 DAGs and two authored checkers. Nine JSON-pointer
values are bound by the ledger to the original metadata hashes at assembly;
private full metadata and runtime provenance are not revalidated by replay.

Historical result, preregistration and checker records remain distinctly
labeled under replay/history. The past 600-second registration deadline
does not control new replay invocations. Anonymous derivative rules and all
original hashes are retained in replay/BINDING_LEDGER.json.

The trace is not an observed returned-controller execution or a theorem
counterexample under its language-inclusion hypothesis. This is one author-
host qualification, not independent external replication. No paper PDF,
paper-derived specification text, upstream Java or binary is redistributed.

The outer MANIFEST.json binds this complete delivery. Its replay-manifest
pin binds the exact subtree tested before outer qualification metadata was
added. No replay subtree byte changed after the successful qualification.
