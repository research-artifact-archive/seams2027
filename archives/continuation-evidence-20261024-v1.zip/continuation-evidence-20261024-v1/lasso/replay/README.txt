SAVED LIFT LASSO REPLAY

The replay deadline is fresh: at most 60 seconds from each invocation.
The historical 600-second preregistration deadline is preserved as history
and is not reused as permission to rerun an expired historical program.

Python 3.10+ standard library on a POSIX host is sufficient. Use a new output
directory outside this bundle; no network, JDK or external source is needed.

  python3 -I -S -B LASSO/replay_lasso.py --bundle LASSO \
    --out FRESH_OUTPUT --timeout-seconds 60

Expected: PASS_SAVED_LASSO_REPLAY, scientific_status POSITIVE, 19 saved DAGs.
Read LASSO_REPLAY_RESULT.json in FRESH_OUTPUT for every predicate and the
field-by-field comparison with the historical saved result.

One fixed initialized trace prefix -> loop -> loop is evaluated. The loop
satisfies all three SYS justices and fails the sole ENV justice at each of
the model, preconstructor and solver stages. Domains, initial predicates,
both transition predicates and the unchanged authored source-oracle clauses
are checked. The program performs no lasso search, arena enumeration, native
solver call, controller extraction or returned-controller execution.

The 23 public semantic payloads comprise two projected JSON objects, 19 DAG
files and two unchanged authored Python checkers. BINDING_LEDGER.json gives
the original metadata SHA-256 values, nine selected JSON pointers and exact
canonical-value equality records. Original model/result metadata contains
private paths and is not included. The ledger's source-value equality is
assembly-time provenance, not an independent restoration of those originals.

The original 25-pin check is NOT repeated. The paper-derived Spectra and
final_region.bdd remain hash-only omitted records. Source-oracle evaluation
does not newly establish source-text/compiler/runtime correspondence.
The saved model is trusted as an exported transformed arena. The legacy
original_bdds/original_justices names refer to that transformed arena.

This witness refutes the language-inclusion premise for this frozen arena.
It is neither an observed controller execution nor a counterexample to a
theorem whose hypotheses include that premise. No general failure rate,
default frontend behavior or independent external replication is claimed.

history/ preserves the completed author-side result and separately recorded
anonymous derivatives of its preregistration/checker. Changes and original
hashes are in BINDING_LEDGER.json. Do not execute the historical .py.txt file.
Qualification reports are supplied separately by the outer delivery.
