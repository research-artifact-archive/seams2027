#!/usr/bin/env python3
"""Read-only integrity and recorded-property check; never a scientific replay."""
from pathlib import Path, PurePosixPath
import argparse, collections, hashlib, json, sys

BASE = Path(__file__).resolve().parent
checks = 0

def need(condition, label):
    global checks
    checks += 1
    if not condition:
        raise ValueError(label)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(name):
    return json.loads((BASE / name).read_text(encoding='utf-8'))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive-dir', type=Path, help='Optional directory containing all four pinned full archives.')
    args = parser.parse_args()
    manifest = read('MANIFEST.json')
    need(manifest['scope'] == 'transport_and_recorded_properties_only', 'manifest scope')
    files = manifest['files']
    need(len({x['path'] for x in files}) == len(files), 'unique manifest members')
    for row in files:
        name = PurePosixPath(row['path'])
        need(not name.is_absolute() and '..' not in name.parts, 'safe relative member')
        data = (BASE / str(name)).read_bytes()
        need(len(data) == row['bytes'] and sha(data) == row['sha256'], 'pinned member: ' + str(name))
    records = {p.relative_to(BASE).as_posix() for p in (BASE/'records').rglob('*') if p.is_file()}
    need(records == {x['path'] for x in files if x['path'].startswith('records/')}, 'exact record inventory')
    index = read('claim_to_evidence.json')
    need({x['id'] for x in index['claims']} == {'guard','patrol','lift','manager'}, 'four claim groups')
    for row in index['record_provenance']:
        data = (BASE/row['path']).read_bytes()
        need(len(data) == row['bytes'] and sha(data) == row['sha256'], 'archive-member copy identity')

    native = read('records/guard/native_result.json')
    strict = read('records/guard/RESULT_01.json')
    need(native['status'] == 'JOB_UNREALIZABLE_NO_CONTROLLER', 'Guard recorded native refusal')
    need(native['pipeline'] == 'released_syntactic_kind_job_equivalent' and native['solver'] == '4fp', 'Guard selected route')
    need(native['native_solver_calls'] == 1 and native['controller_extraction_calls'] == 0, 'Guard recorded calls')
    need(native['initializers_replaced'] is False and native['GUI_execution'] is False, 'Guard initialization and GUI scope')
    need(strict['status'] == 'COMPLETE_EXPECTED_CAUSE', 'Guard complete separate strict audit')
    need(strict['coverage']['original_current_x_next'] == 16 and strict['coverage']['helper_current_x_next'] == 64, 'Guard complete finite coverage')
    need(strict['strict_safety']['descending_size_traces']['helper'] == [8,4,4], 'Guard strict safety trace')
    need(strict['initialization']['original_strict']['verdict'] is True and strict['initialization']['helper_strict']['verdict'] is False, 'Guard separate strict initializer results')
    need(strict['native_comparison']['general_native_strict_equivalence_claimed'] is False, 'No general raw/strict equivalence')

    certificate = read('records/patrol/WC_COUNTERCERTIFICATE.json')
    binding = read('records/patrol/ACTUAL_EXPORT_CERTIFICATE_BINDING.json')
    premise = read('records/patrol/RETAINED_CONSTRAINT_PREMISES.json')
    reduced = read('records/patrol/REDUCED_NATIVE_OUTCOME.json')
    reduced_audit = read('records/patrol/REDUCED_NATIVE_INDEPENDENT_AUDIT.json')
    need(len(certificate['states']) == 26 and len(certificate['rows']) == 25, 'Patrol recorded certificate shape')
    need(sum(len(row['all_safe_outputs']) for row in certificate['rows']) == 103 and len(certificate['not_C_exits']) == 1, 'Patrol recorded replies/exit')
    need(binding['status'] == 'PASS' and binding['countercertificate']['every_native_legal_safe_reply_bound'] is True, 'Actual-export binding record')
    need(binding['countercertificate']['native_export_first_flip_zero_response_confirmed'] is True, 'Recorded no-response first flip')
    need(binding['boundary']['all_source_fields'] == 14 and binding['boundary']['no_reinitialization_for_region_or_certificate'] is True, 'Patrol retained full-state record')
    new = next(row for row in premise['runs'] if row['age'] == 'new')
    need(new['status'] == 'PASS' and new['helper_trap']['U_equals_full_D'] is True and new['F_equals_C'] is True, 'Actual-new retained-constraint premise records')
    need(reduced['status'] == 'PASS_NATIVE_THEOREM_REDUCED_ROOT_LOSS_WITH_FULL_REGION_AGREEMENT', 'Reduced native completion record')
    need(reduced['Q_states'] == 4800 and reduced['W_Q_states'] == 1152 and reduced['F_Q_W_states'] == 1104, 'Reduced query recorded regions')
    need(reduced['whole_4800_state_membership_equal_to_independent_explicit_WF'] is True, 'Recorded whole-layout agreement')
    need(reduced['pending_in_F'] is True and reduced['pending_native_W'] is False and reduced['pending_F_Q_W'] is False, 'Recorded pending membership')
    need(reduced_audit['exact_state_membership_agreement'] == 4800, 'Separate reduced-query audit record')
    need(read('records/patrol/FULL_HELPER_UNKNOWN.json')['status'].startswith('UNKNOWN'), 'Separate full-helper UNKNOWN retained')

    pair = read('records/lift/PAIRED_EVIDENCE.json')
    graphs = read('records/lift/GRAPH_JUDGMENTS.json')
    need(pair['same_memory_object'] is True and pair['same_model_object'] is True and pair['variable_order_unchanged'] is True, 'Lift same solve/memory records')
    need(len(pair['BDD_equality_checks']) == 36 and all(pair['BDD_equality_checks'].values()), 'Lift all recorded BDD equalities')
    for arm,edges,cooperative in [('baseline',1170,False),('variant',1176,True)]:
        need(graphs[arm] == {'strict':True,'cooperative':cooperative,'original_states':154,'original_edges':edges}, 'Lift recorded graph judgment: ' + arm)
    need(graphs['status'] == 'COMPLETE_BOTH_ARMS_BOTH_AUDITS_AGREE' and len(graphs['checks']) == 4, 'Lift both complete graph audits')
    need(read('records/lift/RAW_REGION_RECHECK.json')['typed_state_count'] == 2048, 'Lift raw finite-region recheck record')
    memory = read('records/lift/MEMORY_RECHECK.json')
    need(memory['memory_sets_compared'] == 28 and memory['state_membership_comparisons'] == 57344, 'Lift memory recheck record')

    summary = read('records/manager/OBSERVED_SUMMARY.json')
    audit = read('records/manager/INDEPENDENT_AUDIT.json')
    events = [json.loads(line) for line in (BASE/'records/manager/EVENTS.jsonl').read_text().splitlines()]
    need(summary['status'] == 'COMPLETE_MANAGER_OBSERVATIONS' and not summary['errors'], 'Manager recorded completed execution')
    need(summary['scientific_attempts'] == 1 and summary['preexec_failed_launches'] == 1, 'Manager execution/failure history')
    need(summary['candidate_checks'] == 6 and summary['installations'] == 3 and summary['post_update_commits'] == 36, 'Manager recorded counts')
    need(len(events) == summary['event_count'] == 69, 'Manager exact event count')
    need(collections.Counter(x['event'] for x in events)['controller_installed'] == 3, 'Manager installation events')
    need([x['boundary'] for x in summary['episodes']] == ['pending_524','pending_526','pending_756'], 'Manager fixed boundary roster')
    for episode in summary['episodes']:
        need([x['decision'] for x in episode['decisions']] == ['WITHHOLD_NONCOOPERATIVE','PASS'], 'Manager recorded sequential decisions')
        need(all(x['same_paused_snapshot'] for x in episode['decisions']) and episode['selected'] == 'saved_normalized', 'Manager retained-boundary installation record')
        observed = episode['observations']
        need(observed['old_m3_response_step'] == 1 and observed['old_m3_clear_step'] == 2 and observed['cancel_used'] is False and observed['fair_self_loop'] is True, 'Manager recorded continuation observations')
    need(audit['status'] == 'PASS_INDEPENDENT_SEQUENTIAL_MANAGER_AUDIT' and audit['scientific_worker_reruns'] == 0, 'Manager separate saved audit record')
    checked_archives = []
    if args.archive_dir:
        for archive in index['archives']:
            p = args.archive_dir/archive['archive_name']
            data = p.read_bytes()
            need(len(data) == archive['bytes'] and sha(data) == archive['sha256'], 'Optional archive pin: ' + archive['id'])
            checked_archives.append(archive['id'])
    print(json.dumps({'status':'PASS_PINNED_RECORD_INSPECTION','record_files':len(records),'checks':checks,'claim_groups':4,'scientific_replays':0,'native_solver_calls':0,'network_requests':0,'optional_archive_checks':checked_archives,'scope':'File integrity and retained recorded-property consistency only. The scientific audits and native executions are historical evidence, not rerun by this command.'},indent=2))

if __name__ == '__main__':
    try:
        main()
    except (ValueError,KeyError,OSError,TypeError,StopIteration) as exc:
        print(json.dumps({'status':'FAIL_PINNED_RECORD_INSPECTION','error':str(exc),'checks_before_failure':checks}),file=sys.stderr)
        sys.exit(1)
