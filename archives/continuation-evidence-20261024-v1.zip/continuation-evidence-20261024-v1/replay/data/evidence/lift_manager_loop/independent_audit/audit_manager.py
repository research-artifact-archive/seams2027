"""Independent saved-only event/bit-table/graph audit. Does not import worker code."""
from pathlib import Path
from itertools import product
from collections import Counter
import json, hashlib, datetime, time, traceback, sys, marshal, importlib.util
sys.dont_write_bytecode = True
HERE=Path(__file__).resolve().parent; EXP=HERE.parent; ROOT=EXP.parents[1]
P58=ROOT/'experiment/v58_submission_20261023/pending_handoff'
ENV=['b1','b2','b3','c']; FLOORS=['f1','f2','f3']; AUX=['SYS_CONSTRAINT.%d.pRespondsToS.state'%i for i in range(3)]; FIELDS=ENV+FLOORS+AUX
checks=[]; anchors={}
def need(x,why,detail=None):
 if not x: raise AssertionError(why)
 checks.append(dict(check=why,status='PASS',**({'detail':detail} if detail is not None else {})))
def pin(p):
 p=Path(p);d=p.read_bytes();v=dict(path=str(p),bytes=len(d),sha256=hashlib.sha256(d).hexdigest());anchors[str(p)]=v;return v
def read(p):
 pin(p)
 return json.loads(Path(p).read_text())
def bound(ref):
 q=pin(ref['path']);assert all(q[k]==ref[k] for k in ['bytes','sha256']),ref['path'];return q

def envok(s,t,old=False):
 if sum(s[f]=='true' for f in FLOORS)!=1:return False
 if old and (s['b1']=='true' or t['b1']=='true'):return False
 for i in range(3):
  b=s[ENV[i]]=='true'; f=s[FLOORS[i]]=='true'
  if b and f and t[ENV[i]]!='false':return False
  if b and not f and s['c']=='false' and t[ENV[i]]!='true':return False
 return True

def sysok(s,t):
 buttons=[s[k]=='true' for k in ENV[:3]]; floors=[t[k]=='true' for k in FLOORS];c=s['c']=='true'
 allowed=[(floors[0] and not(buttons[1] or buttons[2])) or (floors[1] and (buttons[1] or buttons[2])) or (floors[0] and c),
  (floors[0] and buttons[0]) or (floors[1] and not(buttons[0] or buttons[2])) or (floors[2] and buttons[2]) or (floors[1] and c),
  (floors[2] and not(buttons[0] or buttons[1])) or (floors[1] and (buttons[0] or buttons[1])) or (floors[2] and c)]
 return all(s[f]=='false' or allowed[i] for i,f in enumerate(FLOORS)) and all((t[a]=='S1')==((s[a]=='S1' or buttons[i]) and not(s[FLOORS[i]]=='true' or c)) for i,a in enumerate(AUX))

def bit_table_model(ref):
 """Truth tables over every 2^20 source-current/source-next assignment, helper=false.
 This independently parses raw nodes; no BDD library or producer checker is used.
 """
 m=read(ref['model']['path']);fields={f['name']:f for f in m['fields']}; n=1<<20; mask=(1<<n)-1
 assert set(fields)==set(FIELDS) | ({'~envHelp'} if '~envHelp' in fields else set())
 for name,fld in fields.items():
  assert fld['domain_size']==2 and fld['values']==(['S0','S1'] if name in AUX else ['false','true'])
  assert fld['owner']==('ENV' if name in ENV+['~envHelp'] else 'SYS')
  assert fld['role']==('AUX' if name in AUX else 'ENV' if name in ENV+['~envHelp'] else 'SYS')
 columns={};free=0
 for phase in ['current','next']:
  for name in FIELDS:
   f=fields[name];assert len(f[phase+'_bits'])==1
   bit=f[phase+'_bits'][0];step=1<<free;col=((1<<step)-1)<<step;size=2*step
   while size<n:col |= col<<size;size*=2
   columns[bit]=col;free+=1
 if '~envHelp' in fields:
  for phase in ['current','next']:
   for bit,val in fields['~envHelp']['encoding']['false'][phase].items():columns[int(bit)]=mask if val else 0
 assert set(columns)==set(range(m['bdd_variable_count']))
 def lit(name,value,phase='current'):
  enc=fields[name]['encoding'][value][phase];assert len(enc)==1
  bit,val=next(iter(enc.items()));return columns[int(bit)] if val else mask^columns[int(bit)]
 def conj(*xs):
  z=mask
  for x in xs:z &= x
  return z
 def disj(*xs):
  z=0
  for x in xs:z |= x
  return z
 def imp(x,y):return (mask^x)|y
 b=[lit(k,'true') for k in ENV[:3]];f=[lit(k,'true') for k in FLOORS];fn=[lit(k,'true','next') for k in FLOORS];c=lit('c','true')
 one=disj(*(conj(f[i],*(mask^f[j] for j in range(3) if j!=i)) for i in range(3)))
 rhoe=conj(one,*(imp(b[i]&f[i],lit(ENV[i],'false','next')) for i in range(3)),*(imp(b[i]&(mask^f[i])&(mask^c),lit(ENV[i],'true','next')) for i in range(3)))
 move=[(fn[0]&(mask^b[1])&(mask^b[2]))|(fn[1]&(b[1]|b[2]))|(fn[0]&c), (fn[0]&b[0])|(fn[1]&(mask^b[0])&(mask^b[2]))|(fn[2]&b[2])|(fn[1]&c), (fn[2]&(mask^b[0])&(mask^b[1]))|(fn[1]&(b[0]|b[1]))|(fn[2]&c)]
 monitors=[mask^(lit(a,'S1','next') ^ ((lit(a,'S1')|b[i]) & (mask^(f[i]|c)))) for i,a in enumerate(AUX)]
 expected={'thetaE':conj(*(mask^x for x in b)),'thetaS':conj(f[0],mask^f[1],mask^f[2],*(lit(a,'S0') for a in AUX)), 'rhoE':rhoe,'rhoS':conj(*(imp(f[i],move[i]) for i in range(3)),*monitors)}
 def parse(r):
  p=Path(ref['model']['path']).parent/r['file'];v=pin(p);assert v['sha256']==r['sha256'] and v['bytes']==r['bytes']
  rows=[line.split() for line in p.read_text().splitlines() if line.strip()]
  if len(rows)==1 and rows[0][0]=='0':return mask if rows[0][1]=='1' else 0
  assert int(rows[0][0])==m['bdd_variable_count'];order=list(map(int,rows[1]));assert order==m['bdd_variable_order'];level={v:i for i,v in enumerate(order)}
  nodes={0:0,1:mask};meta={};triples=set()
  for row in rows[2:]:
   nid,var,lo,hi=map(int,row);assert nid not in nodes and lo in nodes and hi in nodes and lo!=hi and (var,lo,hi) not in triples
   assert all(ch<2 or level[meta[ch][0]]>level[var] for ch in [lo,hi]);meta[nid]=(var,lo,hi);triples.add((var,lo,hi))
   col=columns[var];nodes[nid]=(nodes[lo]&(mask^col))|(nodes[hi]&col)
  seen=set();todo=[nid]
  while todo:
   a=todo.pop()
   if a<2 or a in seen:continue
   seen.add(a);todo.extend(meta[a][1:])
  assert seen==set(meta) and len(seen)==r['node_count']
  return nodes[nid]
 for name,v in expected.items():assert parse(m['original_bdds'][name])==v,name
 for key in ['domain','domain_ENV_next','domain_SYS_next']:assert parse(m['original_bdds'][key])==mask
 assert len(m['original_justices']['SYS'])==3
 for a,r in zip(AUX,m['original_justices']['SYS']):assert parse(r)==lit(a,'S0')
 assert len(m['original_justices']['ENV'])==int('~envHelp' in fields)
 for r in m['original_justices']['ENV']:assert parse(r)==mask
 need(True,'raw source predicate equality on every one of 1,048,576 complete source-state pairs: '+Path(ref['path']).parent.name)
 return {'state_pairs':1<<20,'source_states':1024,'helper_false_projection':'~envHelp' in fields}

def scc(vertices,adj):
 # Iterative Kosaraju, separate from both producer graph algorithms.
 vertices=set(vertices);seen=set();order=[]
 for start in sorted(vertices,key=int):
  if start in seen:continue
  seen.add(start);stack=[(start,iter(v for v in adj[start] if v in vertices))]
  while stack:
   u,it=stack[-1]
   try:v=next(it)
   except StopIteration:order.append(u);stack.pop();continue
   if v not in seen:seen.add(v);stack.append((v,iter(w for w in adj[v] if w in vertices)))
 rev={u:[] for u in vertices}
 for u in vertices:
  for v in adj[u]:
   if v in vertices:rev[v].append(u)
 seen=set();groups=[]
 for start in reversed(order):
  if start in seen:continue
  group=set();todo=[start];seen.add(start)
  while todo:
   u=todo.pop();group.add(u)
   for v in rev[u]:
    if v not in seen:seen.add(v);todo.append(v)
  groups.append(group)
 return groups

def closure(g,roots,old):
 nodes={n['id']:n for n in g['nodes']};states={i:{k:n['valuation'][k] for k in FIELDS} for i,n in nodes.items()}
 edge_set={tuple(e) for e in g['edges']};assert edge_set=={(i,j) for i,n in nodes.items() for j in n['successors']}
 reached=set(roots);todo=list(roots);adj={};edges=[]
 while todo:
  u=todo.pop();adj[u]=[v for v in nodes[u]['successors'] if nodes[v]['valuation'].get('~envHelp','false')=='false' and envok(states[u],states[v],old)]
  for v in adj[u]:
   edges.append((u,v))
   if v not in reached:reached.add(v);todo.append(v)
 coverage=safety=True
 for u in reached:
  expected={v for v in product(['false','true'],repeat=4) if envok(states[u],dict(zip(ENV,v)),old)}
  observed=Counter(tuple(states[v][k] for k in ENV) for v in adj[u]);coverage &= set(observed)==expected and all(c==1 for c in observed.values())
  safety &= all(sysok(states[u],states[v]) for v in adj[u])
 cyclic=lambda group:len(group)>1 or any(v in adj[v] for v in group)
 cyc=set().union(*(c for c in scc(reached,adj) if cyclic(c)))
 good=set(cyc);reverse={u:[] for u in reached}
 for u,v in edges:reverse[v].append(u)
 todo=list(good)
 while todo:
  u=todo.pop()
  for v in reverse[u]:
   if v not in good:good.add(v);todo.append(v)
 badcycle=[any(cyclic(c) for c in scc({u for u in reached if states[u][a]=='S1'},adj)) for a in AUX]
 strict=safety and not any(badcycle) if coverage else None;coop=(good==reached) if coverage and safety else None
 return dict(complete=coverage,source_coverage=coverage,source_safety=safety,strict=strict,cooperative=coop,nodes=sorted(reached,key=int),edges=edges,deadends=sorted([u for u in reached if not adj[u]],key=int),no_infinite_continuation=sorted(reached-good,key=int))

def audit():
 preread=read(HERE/'PRIOR_READING.json');need(preread['original_plan_read_before_any_new_manager_outcome_contents'],'initial plan read before new outcome contents')
 p=read(EXP/'PLAN.json');initial=read(EXP/'PLAN_INITIAL_UNEXECUTED.json');amend=read(EXP/'PREEXEC_AMENDMENT.json')
 need(pin(EXP/'PLAN_INITIAL_UNEXECUTED.json')['sha256']==preread['original_plan_sha256_read'],'initial unexecuted plan preserved')
 for r in p['inputs']:bound(r)
 need(len(p['inputs'])==70,'all 70 executed-plan input pins match')
 for k in ['candidate_order','boundary_order','workloads','scientific_attempts','source_state_fields','selection_rule','old_gate_rule','continuation_rule','verdict_rule']:need(p[k]==initial[k],'unchanged scientific plan field '+k)
 need(p['scientific_attempts']==1 and amend['scientific_executions_before_amendment']==0 and amend['no_further_scientific_retry'],'one scientific execution after preserved pre-exec wrapper failure')
 for k in ['worker','initial_plan','failed_launch','new_supervisor']:bound(amend[k])
 failure=read(EXP/'LAUNCH01_FAILURE.json');need(not (EXP/'run01/output').exists(),'launch01 has no worker output directory')
 worker=(EXP/'code/worker.py').read_text();need(pin(EXP/'code/worker.py')['sha256']==amend['worker']['sha256']=='73b6db5a255d0742caa9fd18bcc1c349e36ec51b3edf26f5045ec8b65a48a40c','worker source unchanged through wrapper amendment')
 sup=read(EXP/'run02/SUPERVISOR.json');r=read(EXP/'run02/output/RESULT.json');events=[json.loads(x) for x in (EXP/'run02/output/EVENTS.jsonl').read_text().splitlines()]
 pin(EXP/'run02/output/EVENTS.jsonl')
 need(sup['exit_code']==0 and sup['stop_reason'] is None and sup['process_reaped'] and sup['wall_seconds']<120 and r['process_peak_rss_bytes']<p['bounds']['rss_bytes'],'single bounded worker completed and was reaped')
 need(r['status']=='COMPLETE_MANAGER_OBSERVATIONS' and not r['errors'] and r['native_calls']==r['synthesis_calls']==r['full_reset_uses']==0,'complete saved-only manager result without science/reset calls')
 need(r['preregistration']==pin(EXP/'PLAN.json'),'result binds actual pre-execution amended plan')
 sizes=[x.stat().st_size for x in (EXP/'run02').rglob('*') if x.is_file()];need(max(sizes)<=p['bounds']['file_bytes'] and sum(sizes)<=p['bounds']['output_tree_bytes'],'stored worker outputs within file and aggregate caps')
 # A Python no-bytecode-write flag does not forbid cache reads: verify extant observed caches against freshly compiled source.
 caches=[]
 for path in r['read_paths']:
  q=Path(path)
  if q.suffix=='.pyc' and q.exists():
   source=Path(importlib.util.source_from_cache(str(q)));code=marshal.loads(q.read_bytes()[16:]);expected=compile(source.read_bytes(),code.co_filename,'exec',dont_inherit=True)
   assert code==expected,str(q);caches.append(pin(q))
 need(True,'all extant observed Python bytecode caches match freshly compiled source',len(caches))
 need(not any('/pending_handoff/execution/' in x or Path(x).name in ['ROOT_RUNTIME_GO.json','ROOT_OLD_GATE_ADOPTION.json','INTERFACE_QUALIFICATION.json'] for x in r['read_paths']),'observed input reads contain no prior admission certificates or episode outcomes')
 need('source.view(sg[gn],[desc[\'root\']],False)' in worker and 'saved.closure_certificate(ctx,nodes,[desc[\'root\']],False)' in worker and 'saved.audit_equations(ctx)' in worker and "if selected:" in worker,'worker invokes fresh source, saved-graph and exact-model checks inside candidate loop')
 oldplan=read(P58/'PLAN.json');graphs={k:read(v['path']) for k,v in oldplan['graphs'].items()};nodes={k:{n['id']:n for n in g['nodes']} for k,g in graphs.items()}
 model_checks={k:bit_table_model(oldplan['graphs'][k]) for k in ['native','normalized']}
 old=closure(graphs['native'],['0','1'],True)
 for route in ['source','saved_native']:
  cert=r['fresh_old_gate'][route];need(all(cert[k]==old[k] is True for k in ['complete','source_coverage','source_safety','strict','cooperative']),'fresh old gate independently passes '+route)
 need(len(old['nodes'])==50 and len(old['edges'])==238,'old initialized closure has 50 nodes / 238 legal edges')
 need(len(events)==r['event_count']==69 and [e['seq'] for e in events]==list(range(69)) and all(e['pid']==sup['pid']==r['pid'] for e in events),'69 sequential events bind one worker PID')
 need(all(a['monotonic_ns']<b['monotonic_ns'] for a,b in zip(events,events[1:])),'event timestamps strictly monotonic')
 need([e['boundary_id'] for e in r['episodes']]==p['boundary_order'],'all three frozen boundaries executed in declared order')
 results=[];ids=[]
 for episode,boundary in zip(r['episodes'],oldplan['boundaries']):
  bid=boundary['id'];ev=[e for e in events if e['runtime']['boundary_id']==bid];before=episode['before'];ids.append((before['plant_identity'],before['state_object_identity']))
  prefix=len(boundary['prefix_node_ids'])-1
  want=['episode_boot']+['step_committed']*prefix+['boundary_paused_and_environment_changed']+['candidate_attempt_begin','candidate_attempt_decision']*2+['controller_installed','resumed']+['step_committed']*12+['manager_episode_completed']
  need([e['event'] for e in ev]==want,bid+' exact sequential attempt/install/continuation event order')
  need(all(e['runtime']['plant_identity']==ids[-1][0] and e['runtime']['state_object_identity']==ids[-1][1] for e in ev),bid+' same runtime and same state object throughout')
  boot=ev[0]['runtime'];need(boot['ticks']==0 and boot['controller']['node_id']=='0' and boot['controller']['rank']==0 and boot['contract_mode']=='old_no_b1' and boot['source_state']=={k:nodes['native']['0']['valuation'][k] for k in FIELDS},bid+' exact old initialized boot')
  for i,e in enumerate(ev):
   snap=e['runtime'];state=snap['source_state'];ctrl=snap['controller'];gn=ctrl['graph'];node=nodes[gn][ctrl['node_id']]
   assert state=={k:node['valuation'][k] for k in FIELDS} and ctrl['rank']==node['rank'] and ctrl['original_initial_flag']==node['initial']
   assert ctrl['graph_sha256']==oldplan['graphs'][gn]['sha256']
   if e['event']=='step_committed':
    prior=e['before'];assert prior==ev[i-1]['runtime'];src=nodes[gn][prior['controller']['node_id']]
    assert ctrl['instance_identity']==prior['controller']['instance_identity'] and ctrl['node_id'] in src['successors']
    assert e['offered_env']=={k:state[k] for k in ENV} and envok(prior['source_state'],state,prior['contract_mode']=='old_no_b1') and sysok(prior['source_state'],state)
    assert snap['ticks']==prior['ticks']+1 and not prior['paused'] and snap['epoch']==prior['epoch'] and snap['contract_mode']==prior['contract_mode']
  need(True,bid+' every committed transition independently satisfies exact graph edge, rank, ENV/SYS and monitor update')
  need([e['runtime']['controller']['node_id'] for e in ev[:prefix+1]]==boundary['prefix_node_ids'],bid+' actually executed frozen old prefix')
  pause=ev[prefix+1];need(pause['runtime']==before and before['source_state']==boundary['source_state'] and pause['before']==ev[prefix]['runtime'] and before['source_state']==pause['before']['source_state'],bid+' model change preserves full ten-field reached state')
  need(before['paused'] and before['epoch']==1 and before['contract_mode']=='normal' and before['source_state'][AUX[2]]=='S1' and before['source_state']['f3']=='false' and before['source_state']['c']=='false',bid+' genuinely unanswered m3 retained while paused')
  attempts=episode['attempts'];need([a['candidate'] for a in attempts]==p['candidate_order'][:2] and [a['decision'] for a in attempts]==['WITHHOLD_NONCOOPERATIVE','PASS'],bid+' fixed priority WITHHOLD then first PASS')
  closure_rows=[]
  for j,a in enumerate(attempts):
   desc=boundary['candidates'][j];assert all(a[k]==desc[k] for k in ['candidate','graph','root','rank'])
   ce=closure(graphs[a['graph']],[a['root']],False);closure_rows.append({k:v for k,v in ce.items() if k not in ['nodes','edges']})
   for route in ['source_certificate','saved_native_certificate']:
    cert=a[route];assert all(cert[k]==ce[k] for k in ['complete','source_coverage','source_safety','strict','cooperative'])
    assert (cert['reachable_state_count'],cert['reachable_edge_count'])==(len(ce['nodes']),len(ce['edges'])) if route=='source_certificate' else (cert['reachable_node_count'],cert['edge_count'])==(len(ce['nodes']),len(ce['edges']))
   assert a['source_certificate']['reachable_nodes']==ce['nodes']
   assert a['source_certificate']['derived_edges_sha256']==hashlib.sha256(json.dumps(sorted(ce['edges']),sort_keys=True,separators=(',',':')).encode()).hexdigest()
   assert a['before']==a['after']==before and a['post_update_commits_before_selection']==0
   begins=ev[prefix+2+2*j];decision=ev[prefix+3+2*j];assert begins['runtime']==decision['runtime']==before and decision['attempt']==a
   assert nodes[a['graph']][a['root']]['rank']==a['rank'] and {k:nodes[a['graph']][a['root']]['valuation'][k] for k in FIELDS}==before['source_state']
   phases=[t['stage'] for t in r['timings'] if t.get('boundary')==bid and t.get('candidate')==a['candidate']]
   assert phases==['fresh_source_correspondence_and_exact_root','fresh_source_complete_graph','fresh_saved_native_complete_graph','paused_candidate_complete_check']
  need(True,bid+' both fresh graph checks independently rederived, exact roots and paused state preserved')
  need(episode['unattempted']==[dict(candidate='saved_preference',reason='NOT_ATTEMPTED_AFTER_FIRST_PASS')] and episode['selected_candidate']=='saved_normalized',bid+' later preference not attempted after first complete PASS')
  install=ev[prefix+6];resume=ev[prefix+7];assert install['event']=='controller_installed' and resume['event']=='resumed'
  assert install['before']==before and install['runtime']['source_state']==before['source_state'] and install['runtime']['ticks']==before['ticks'] and install['runtime']['paused']
  assert install['runtime']['controller']['instance_identity']!=before['controller']['instance_identity']
  normalized=dict(install['runtime']);normalized['paused']=False;assert resume['runtime']==normalized==episode['install_snapshot']==episode['trail'][0]
  assert install['certified_root']['root_id']==boundary['candidates'][1]['root'] and install['certified_root']['rank']==boundary['candidates'][1]['rank']
  commits=[e for e in ev if e['event']=='step_committed' and e['phase']=='frozen_twelve_input_continuation']
  assert [e['runtime'] for e in commits]==episode['trail'][1:] and len(commits)==12 and episode['post_update_commits']==12
  bits=[''.join('1' if e['offered_env'][k]=='true' else '0' for k in ENV) for e in commits];assert bits==p['workloads'][bid]
  assert episode['offered_inputs']==[e['offered_env'] for e in commits]
  trail=episode['trail'];states=[x['source_state'] for x in trail];last=states[-1]
  metrics=dict(old_m3_response_step=next((i for i,s in enumerate(states[1:],1) if s['f3']=='true' and s['c']=='false'),None),old_m3_clear_step=next((i for i,s in enumerate(states[1:],1) if s[AUX[2]]=='S0'),None),final_genuinely_pending=[i+1 for i,a in enumerate(AUX) if last[a]=='S1' and last[FLOORS[i]]=='false' and last['c']=='false'],cancel_used=any(s['c']=='true' for s in states),executed_self_loop=trail[-1]['controller']['node_id']==trail[-2]['controller']['node_id'] and states[-1]==states[-2])
  metrics['fair_self_loop']=metrics['executed_self_loop'] and all(last[a]=='S0' for a in AUX)
  need(metrics==episode['observations'] and metrics['old_m3_response_step']==1 and metrics['old_m3_clear_step']==2 and metrics['fair_self_loop'] and not metrics['cancel_used'] and not metrics['final_genuinely_pending'],bid+' twelve frozen commits respond/clear at 1/2 and end in repeatable fair self-loop')
  assert episode['final']==trail[-1]==ev[-1]['runtime'] and episode['status']=='EXECUTED_FAIR_SELF_LOOP'
  results.append(dict(boundary=bid,closures=closure_rows,observations=metrics,post_update_commits=12))
 need(len(set(x[0] for x in ids))==len(set(x[1] for x in ids))==3,'distinct runtime/state objects across boundaries and retained objects within each boundary')
 return dict(status='PASS_INDEPENDENT_SEQUENTIAL_MANAGER_AUDIT',episodes=results,source_predicate_checks=model_checks,observed_worker_wall_seconds=sup['wall_seconds'],observed_process_peak_rss_bytes=r['process_peak_rss_bytes'],observed_supervisor_sampled_peak_rss_bytes=sup['sampled_peak_rss_bytes'],native_calls=0,synthesis_calls=0,scientific_worker_reruns=0,event_count=69,bytecode_cache_checks=len(caches),scope=['Independent finite graph reachability, input coverage, safety and SCC checks over saved graph records; no winning-region synthesis.','All 1,048,576 full source-state pairs are checked with independent Python integer truth tables and a separate native-node parser.','Events, exact object identities and code call sites support one sequential paused manager per boundary; no prior episode verdict is used as proof.','Python/process execution provenance and native exporter metadata remain trust boundaries. Timings are one observed instrumented run, not benchmark estimates.','The earlier launch01 failed before worker exec; only unsupported address-space limit and run directory were amended with parent authorization.'])

if __name__=='__main__':
 start=time.monotonic();out=dict(schema='v64-lift-manager-independent-audit-v1',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 try:out.update(audit())
 except BaseException as e:out.update(status='FAIL_INDEPENDENT_AUDIT',error=repr(e),traceback=traceback.format_exc())
 out.update(elapsed_seconds=time.monotonic()-start,checks=checks,input_anchors=list(anchors.values()),checker=pin(Path(__file__)))
 (HERE/'AUDIT_RESULT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ['status','error','traceback','elapsed_seconds','event_count'] if k in out},indent=2))
 sys.exit(0 if out['status'].startswith('PASS') else 1)
