"""One sequential manager per frozen live Lift boundary; no saved verdict loader."""
from pathlib import Path
import sys
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent))
from common import *
import traceback
OUT=Path(sys.argv[1]).resolve();OUT.mkdir(exist_ok=False)
T=Timings();opened=set()
def audit(event,args):
 if event=='open' and isinstance(args[0],str):
  p=Path(args[0]).resolve();mode=args[1]
  if mode is None or 'r' in mode:
   if str(ROOT) in str(p):
    opened.add(str(p))
    if ('/pending_handoff/execution/' in str(p) or p.name in ('ROOT_RUNTIME_GO.json','ROOT_OLD_GATE_ADOPTION.json','INTERFACE_QUALIFICATION.json')):
     raise RuntimeError('Saved certificate/verdict read is forbidden: '+str(p))
sys.addaudithook(audit)
RESULT=dict(schema='v64-lift-sequential-manager-v1',status='RUNNING',errors=[],episodes=[],timings=T.rows,native_calls=0,synthesis_calls=0,full_reset_uses=0)
KEYS=('complete','source_coverage','source_safety','strict','cooperative')
try:
 declaration=read(EXP/'PLAN.json');assert declaration['status']=='FROZEN_BEFORE_EXECUTION'
 RESULT['preregistration']=pin(EXP/'PLAN.json')
 for ref in declaration['inputs']:check(ref)
 with T.phase('setup_immutable_inputs_and_existing_modules'):
  plan=read(P58/'PLAN.json');assert plan['candidate_order']==declaration['candidate_order']
  base=load(P58/'code/runtime/run_handoff.py','manager_runtime')
  source=load(P58/'code/source_route/check_source_roots.py','manager_source')
  saved=load(P58/'code/saved_route/check_roots.py','manager_saved')
  follow=load(P61/'code/lift_continuation.py','manager_metrics')
  graphs={n:base.SavedGraph(n,ref,read(ref['path'])) for n,ref in plan['graphs'].items()}
  inputs=saved.Inputs();inputs.walk(plan);loaded,models=saved.load_graphs(plan,inputs)
  sg={n:source.load_graph(ref) for n,ref in plan['graphs'].items()}
  workloads=read(P61/'planning/LIFT_SUPPORTING_CONTINUATION_PLAN.json')['workloads']
  source.validate_source(plan['source']);source.validate_mode(plan);source.validate_source_roster_and_old(plan)
  cohort=source.validate_cohort(source.canonical_plan(plan),sg['native'])
 with T.phase('fresh_complete_old_gate_before_execution'):
  ctx,nodes=loaded['native'];starts,unused=source.initial_roots(sg['native']);nstarts=saved.initial_roots(ctx,nodes)
  assert starts==nstarts
  old_s=source.view(sg['native'],starts,True);old_n=saved.closure_certificate(ctx,nodes,nstarts,True)
  assert all(old_s[k] is True and old_n[k] is True for k in KEYS)
  assert old_s['reachable_state_count']==old_n['reachable_node_count'] and old_s['reachable_edge_count']==old_n['edge_count']
  RESULT['fresh_old_gate']=dict(source=old_s,saved_native=old_n,cohort=cohort)
 keep=[]
 with (OUT/'EVENTS.jsonl').open('x') as stream:
  log=base.EventLog(stream)
  for b in plan['boundaries']:
   episode=dict(boundary_id=b['id'],status='RUNNING',attempts=[],unattempted=[],selected_candidate=None)
   RESULT['episodes'].append(episode)
   rt=base.Runtime(b['id'],b['id'],'sequential_first_complete_strict_cooperative_pass',graphs['native'],log);keep.append(rt)
   for target in b['prefix_node_ids'][1:]:
    offered={k:graphs['native'].node(target)['valuation'][k] for k in base.ENV}
    assert rt.step(offered,'frozen_old_native_prefix',expected_target=target)
   rt.pause_and_change(b);before=rt.snapshot();episode['before']=before
   assert rt.state[base.AUX[2]]=='S1' and rt.state['f3']=='false' and rt.state['c']=='false'
   selected=None
   for index,desc in enumerate(b['candidates']):
    arm=desc['candidate'];gn=desc['graph'];attempt=dict(index=index+1,candidate=arm,graph=gn,root=desc['root'],rank=desc['rank'],decision='UNKNOWN_WITHHOLD',before=rt.snapshot())
    episode['attempts'].append(attempt);rt.emit('candidate_attempt_begin',attempt=attempt)
    try:
     with T.phase('paused_candidate_complete_check',boundary=b['id'],candidate=arm):
      assert rt.snapshot()==before and rt.paused and rt.controller is rt.old_controller
      with T.phase('fresh_source_correspondence_and_exact_root',boundary=b['id'],candidate=arm):
       for ref in (plan['source'],plan['old_source'],plan['graphs'][gn],plan['graphs'][gn]['model']):check(ref)
       source.validate_source(plan['source']);source.validate_mode(plan);source.validate_source_roster_and_old(plan)
       ctx,nodes=loaded[gn];eq=saved.audit_equations(ctx)
       sb=source.root_binding(sg[gn],desc['root'],desc['rank'],rt.state)
       saved.check_root_binding(nodes,desc['root'],desc['rank'],rt.state)
       if arm=='retain_old_native':assert desc['root']==rt.controller.node_id and desc['rank']==rt.controller.memory()['rank']
      with T.phase('fresh_source_complete_graph',boundary=b['id'],candidate=arm):sc=source.view(sg[gn],[desc['root']],False)
      with T.phase('fresh_saved_native_complete_graph',boundary=b['id'],candidate=arm):nc=saved.closure_certificate(ctx,nodes,[desc['root']],False)
      assert all(sc[k]==nc[k] for k in KEYS)
      assert sc['reachable_state_count']==nc['reachable_node_count'] and sc['reachable_edge_count']==nc['edge_count']
      assert rt.snapshot()==before
      accept=all(sc[k] is True for k in KEYS)
      decision='PASS' if accept else 'WITHHOLD_NONCOOPERATIVE' if sc['cooperative'] is False else 'WITHHOLD_FAILED_PROPERTY' if any(sc[k] is False for k in KEYS) else 'UNKNOWN_WITHHOLD'
      attempt.update(decision=decision,source_certificate=sc,saved_native_certificate=nc,source_correspondence=eq,exact_root=sb)
      if accept:
       cert=dict(candidate=arm,graph_sha256=graphs[gn].sha256,root_id=desc['root'],rank=desc['rank'],**{k:sc[k] for k in ('complete','strict','cooperative','source_coverage')})
       selected=(desc,cert)
    except Exception as e:
     attempt.update(decision='UNKNOWN_WITHHOLD',error=repr(e),traceback=traceback.format_exc())
    assert rt.snapshot()==before and rt.paused and rt.controller is rt.old_controller
    attempt.update(after=rt.snapshot(),same_runtime_state_monitor_and_old_controller=True,post_update_commits_before_selection=rt.ticks-before['ticks'])
    rt.emit('candidate_attempt_decision',attempt=attempt)
    if selected:
     episode['unattempted']=[dict(candidate=x['candidate'],reason='NOT_ATTEMPTED_AFTER_FIRST_PASS') for x in b['candidates'][index+1:]]
     break
   episode['trail']=[rt.snapshot()];episode['offered_inputs']=[]
   if selected:
    desc,cert=selected;arm=desc['candidate'];gn=desc['graph']
    candidate=rt.old_controller if arm=='retain_old_native' else base.GraphController(graphs[gn],desc['root'],rt.state,desc['rank'])
    rt.install(candidate,cert,{'fresh_manager_attempt':len(episode['attempts']),'preregistration_sha256':RESULT['preregistration']['sha256']})
    episode['selected_candidate']=arm;episode['install_snapshot']=rt.snapshot();episode['trail']=[rt.snapshot()]
    assert len(workloads[b['id']]['input_bits'])==12
    for bits in workloads[b['id']]['input_bits']:
     offered=dict(zip(base.ENV,('true' if x=='1' else 'false' for x in bits)))
     assert base.env_legal(rt.state,offered,'normal') and rt.step(offered,'frozen_twelve_input_continuation')
     episode['offered_inputs'].append(offered);episode['trail'].append(rt.snapshot())
    episode['observations']=follow.metrics(base,episode['trail'])
    episode['status']='EXECUTED_FAIR_SELF_LOOP' if episode['observations']['fair_self_loop'] else 'WORKLOAD_COMPLETED_WITHOUT_FAIR_SUFFIX'
   else:
    episode['status']='ALL_CANDIDATES_WITHHELD_PAUSED';assert rt.snapshot()==before
   episode.update(final=rt.snapshot(),post_update_commits=len(episode['offered_inputs']),single_runtime_object_preserved=True,source_monitor_not_reset_at_selection=True)
   rt.emit('manager_episode_completed',boundary=b['id'],selected_candidate=episode['selected_candidate'],status=episode['status'],observations=episode.get('observations'))
  assert len(keep)==3 and len({id(x) for x in keep})==3 and len({id(x.state) for x in keep})==3
  RESULT['event_count']=log.count
 with T.phase('final_exact_input_recheck'):
  inputs.recheck()
  for ref in declaration['inputs']:check(ref)
 RESULT.update(status='COMPLETE_MANAGER_OBSERVATIONS',raw_graph_model_bindings=models)
except BaseException as e:
 RESULT['status']='FAILED_OR_UNKNOWN';RESULT['errors'].append(dict(error=repr(e),traceback=traceback.format_exc()))
RESULT.update(process_peak_rss_bytes=rss(),pid=os.getpid(),read_paths=sorted(opened),saved_candidate_verdict_loader_called=False)
write(OUT/'RESULT.json',RESULT)
print(json.dumps({k:RESULT[k] for k in ('status','errors','process_peak_rss_bytes','pid')}))
raise SystemExit(0 if RESULT['status']=='COMPLETE_MANAGER_OBSERVATIONS' else 2)
