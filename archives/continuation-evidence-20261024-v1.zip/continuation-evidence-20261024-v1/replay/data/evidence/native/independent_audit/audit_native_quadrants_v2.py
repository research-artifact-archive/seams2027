"""Independent typed quadrant identities and helper-totality proof on saved tables."""
from audit_native_certificates import *
from audit_explicit_slice import QuantifiedDAG
import gc

def audit(age):
 start=time.monotonic();o=Model(age+'-original');j=Model(age+'-released');d=o.dag;qd=QuantifiedDAG(d)
 mapping={}
 for name,f in o.byname.items():
  g=j.byname[name];require((f['owner'],f['role'],f['values'])==(g['owner'],g['role'],g['values']),'exact semantic field roster')
  for phase in ('current','next'):
   for val in f['values']:
    require([o.enc[name,val,phase][v] for v in f[phase+'_bits']]==[j.enc[name,val,phase][v] for v in g[phase+'_bits']],'identical semantic typed codes')
   mapping.update(zip(g[phase+'_bits'],f[phase+'_bits']))
 require(set(j.byname)==set(o.byname)|{'~envHelp'},'only helper field added; all AUX retained')
 def tr(root,h,hp):
  fixed={**j.enc['~envHelp',str(h).lower(),'current'],**j.enc['~envHelp',str(hp).lower(),'next']}
  @lru_cache(None)
  def visit(u):
   if u<2:return u
   v,lo,hi=j.dag.nodes[u]
   if v in fixed:return visit(hi if fixed[v] else lo)
   return d.mk(mapping[v],visit(lo),visit(hi))
  return visit(root)
 edge=qd.join('and',o.formulas['domain'],qd.join('and',o.formulas['domain_ENV_next'],o.formulas['domain_SYS_next']))
 def equal(a,b):return qd.join('and',edge,a)==qd.join('and',edge,b)
 quad={}
 roots={}
 for h,hp in ((False,False),(False,True),(True,False),(True,True)):
  e=tr(j.formulas['rhoE'],h,hp);s=tr(j.formulas['rhoS'],h,hp);key=str(int(h))+str(int(hp));roots[key]=(e,s)
  quad[key]={'E_equals_source':equal(e,o.formulas['rhoE']),'E_equals_true':equal(e,1),'E_equals_false':equal(e,0),'S_equals_source':equal(s,o.formulas['rhoS']),'S_equals_true':equal(s,1)}
 # Inspect the actual helper trap relation support before proving totality.
 s11=roots['11'][1];support=d.support(s11)
 current_fields=[f for f in o.fields if support.intersection(f['current_bits'])]
 next_fields=[f for f in o.fields if support.intersection(f['next_bits'])]
 require(not any(f['owner']=='ENV' for f in next_fields),'helper trap has no next ENV dependence')
 require(all(f['owner']=='SYS' for f in next_fields),'only SYS next obligations remain in helper trap')
 count=0;min_outputs=10**9;max_outputs=0;unique_aux=True;public_choices_complete=True
 for vals in product(*(f['values'] for f in current_fields)):
  current=dict(zip([f['name'] for f in current_fields],vals));r=d.restrict(s11,o.bits(current));choices=o.enumerate(r,next_fields)
  require(choices,'all typed support currents have typed SYS reply')
  aux=[f['name'] for f in next_fields if f['role']=='AUX'];pub=[f for f in next_fields if f['role']=='SYS']
  unique_aux=unique_aux and len({tuple(z[n] for n in aux) for z in choices})==1
  public_choices_complete=public_choices_complete and {tuple(z[f['name']] for f in pub) for z in choices}==set(product(*(f['values'] for f in pub)))
  count+=1;min_outputs=min(min_outputs,len(choices));max_outputs=max(max_outputs,len(choices))
 require(quad['11']['E_equals_true'],'helper trap environment total')
 result={'age':age,'status':'PASS','quadrants':quad,'all_source_AUX_retained':True,'helper_trap':{'next_support_fields':[f['name'] for f in next_fields],'current_support_fields':[f['name'] for f in current_fields],'current_support_assignments':count,'typed_SYS_outputs_min':min_outputs,'typed_SYS_outputs_max':max_outputs,'unique_AUX_reply_at_each_current':unique_aux,'all_typed_public_SYS_outputs_admitted':public_choices_complete,'nontrivial_S11':not quad['11']['S_equals_true'],'U_equals_full_D':True,'U_count':o.carrier,'proof':'E11 permits every typed ENV input; S11 has no next ENV dependence; exhaustive typed current-support enumeration supplies a typed SYS successor at each current (all public SYS valuations and one AUX update). Thus D is a greatest fixed point of trap safety.'},'F_equals_C':quad['01']['E_equals_true'] and quad['01']['S_equals_source'],'F_equals_C_basis':'Given independently verified U=D, actual 01 edge is E=true,S=sourceS on all typed edges, so actual F is exactly full typed first-flip C.','elapsed_seconds':time.monotonic()-start,'dag_nodes':len(d.nodes)}
 return result
if __name__=='__main__':
 r={'schema':'v64-independent-native-quadrant-audit-v1','status':'RUNNING','independence':'Independent raw native parser, canonical DAG constructor, cofactor/name+value bit mapping, typed masking and support enumeration; no producer modules or BDD libraries.'}
 try:r['runs']=[audit(age) for age in sys.argv[1:] or ['new','old']];r['status']='PASS'
 except BaseException as e:r.update(status='FAILED',exception=repr(e),traceback=traceback.format_exc())
 r['file_hash_anchors']=anchors;r['checker_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();(HERE/'NATIVE_QUADRANTS_V2_RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='file_hash_anchors'},indent=2))
 if r['status']!='PASS':sys.exit(1)
