"""Independent saved-native-table auditor; no producer or BDD-library imports.

Trust boundary: native compiler/exporter and field/value encoding metadata.
Parses the native node tables, canonicalizes only by (variable,low,high),
restricts known valuations, and exhaustively enumerates typed remaining fields.
"""
from pathlib import Path
from collections import defaultdict, deque
from functools import lru_cache
from itertools import product
import json, hashlib, time, traceback, sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
EXP=HERE.parent
ROOT=EXP.parents[1]
CERT=ROOT/'experiment/v61_pending_diagnostic_impact_20261023/primary277/execution/finite_certificates_01'
REQUEST='SYS_CONSTRAINT.0.P_becomes_true_after_Q_until_R.state'
COORDS=('AX','AY','BX','BY','CX','CY')
anchors={}
def require(ok,msg):
 if not ok: raise AssertionError(msg)
def loadjson(path):
 raw=path.read_bytes(); anchors[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}; return json.loads(raw)
def value(v): return str(v).lower() if type(v) is bool else str(v)
def normalize(d): return {REQUEST if k=='request' else k:value(v) for k,v in d.items()}
def statekey(d): return tuple(sorted(normalize(d).items()))
class DAG:
 def __init__(self): self.nodes=[None,None];self.unique={}
 def mk(self,v,lo,hi):
  if lo==hi:return lo
  t=v,lo,hi
  if t not in self.unique:self.unique[t]=len(self.nodes);self.nodes.append(t)
  return self.unique[t]
 def parse(self,path,ref,n):
  raw=path.read_bytes(); anchors[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
  require(anchors[str(path.relative_to(ROOT))]=={k:ref[k] for k in ('bytes','sha256')},'native file pin')
  rows=[list(map(int,l.split())) for l in raw.decode('ascii').splitlines() if l.strip()]
  if len(rows)==1:
   require(rows[0] in ([0,0],[0,1]),'constant syntax');return rows[0][1]
  require(rows[0]==[n] and rows[1]==list(range(n)),'expected declared natural order')
  ids={0:0,1:1};native={};triples=set()
  for ident,v,lo,hi in rows[2:]:
   require(ident>1 and ident not in ids and 0<=v<n,'node identity')
   require(lo in ids and hi in ids and lo!=hi and (v,lo,hi) not in triples,'node topology/reduction')
   require(all(c<2 or native[c][0]>v for c in (lo,hi)),'native ordering')
   triples.add((v,lo,hi));native[ident]=(v,lo,hi);ids[ident]=self.mk(v,ids[lo],ids[hi])
  seen=set();todo=[ident]
  while todo:
   u=todo.pop()
   if u<2 or u in seen:continue
   seen.add(u);todo.extend(native[u][1:])
  require(len(seen)==len(native)==ref['node_count'],'complete reachable native nodes')
  require(sorted({native[u][0] for u in seen})==ref['support'],'native support')
  return ids[ident]
 def restrict(self,r,assignment):
  @lru_cache(None)
  def walk(u):
   if u<2:return u
   v,lo,hi=self.nodes[u]
   if v in assignment:return walk(hi if assignment[v] else lo)
   return self.mk(v,walk(lo),walk(hi))
  return walk(r)
 def evaluate(self,r,assignment):
  while r>1:
   v,lo,hi=self.nodes[r];r=hi if assignment[v] else lo
  return bool(r)
 def support(self,r):
  seen=set();vs=set();todo=[r]
  while todo:
   u=todo.pop()
   if u<2 or u in seen:continue
   seen.add(u);v,lo,hi=self.nodes[u];vs.add(v);todo.extend((lo,hi))
  return vs
class Model:
 def __init__(self,mode):
  self.directory=EXP/'native'/mode;self.model=loadjson(self.directory/'model.json');m=self.model
  self.dag=DAG();self.fields=m['fields'];self.byname={f['name']:f for f in self.fields};self.names=set(self.byname)
  self.env=[f for f in self.fields if f['owner']=='ENV'];self.sys=[f for f in self.fields if f['owner']=='SYS']
  self.enc={};allbits=set();self.carrier=1
  for f in self.fields:
   name=f['name'];self.carrier*=len(f['values']);require(f['domain_size']==len(set(f['values'])),'domain size')
   codes=set()
   for val in f['values']:
    e=f['encoding'][val]
    for phase,bitkey in (('current','current_bits'),('next','next_bits')):
     bits={int(k):v for k,v in e[phase].items()};require(set(bits)==set(f[bitkey]) and all(type(v) is bool for v in bits.values()),'typed encoding')
     self.enc[name,val,phase]=bits
    c=tuple(e['current'][str(b)] for b in f['current_bits']);n=tuple(e['next'][str(b)] for b in f['next_bits'])
    require(c==n and c not in codes,'injective paired encoding');codes.add(c)
   for k in ('current_bits','next_bits'):
    require(not allbits.intersection(f[k]),'disjoint bit ownership');allbits.update(f[k])
  require(allbits==set(range(m['bdd_variable_count'])),'all bits owned')
  self.formulas={k:self.dag.parse(self.directory/v['file'],v,m['bdd_variable_count']) for k,v in m['original_bdds'].items()}
  self.justices={o:[self.dag.parse(self.directory/v['file'],v,m['bdd_variable_count']) for v in refs] for o,refs in m['original_justices'].items()}
  self.enbits={b for f in self.env for b in f['next_bits']};self.cbits=set(m['all_current_bits'])
  require(self.dag.support(self.formulas['rhoE'])<=self.cbits|self.enbits,'ENV cannot use SYS next fields')
 def bits(self,d,phase='current'):
  bits={}
  for name,val in normalize(d).items():
   require(name in self.byname and val in self.byname[name]['values'],'typed value '+name+':'+val)
   bits.update(self.enc[name,val,phase])
  return bits
 def full(self,d): require(set(normalize(d))==self.names,'complete state roster');return self.bits(d)
 def test(self,key,state,nxt=None):
  bits=self.full(state)
  if nxt is not None:bits.update(self.bits(nxt,'next'))
  return self.dag.evaluate(self.formulas[key],bits)
 def enumerate(self,root,fields,phase='next'):
  # Exhaustive typed Cartesian product, with exact residual-DAG zero pruning.
  fields=sorted(fields,key=lambda f:min(f[phase+'_bits']))
  output=[]
  def visit(u,i,assignment):
   if u==0:return
   if i==len(fields):
    require(u==1,'unbound variable after typed enumeration');output.append(dict(assignment));return
   f=fields[i];name=f['name']
   for val in f['values']:
    rr=self.dag.restrict(u,self.enc[name,val,phase])
    if rr:
     assignment[name]=val;visit(rr,i+1,assignment)
   assignment.pop(name,None)
  visit(root,0,{})
  return output
 def legal(self,state):
  r=self.dag.restrict(self.formulas['rhoE'],self.full(state));return self.enumerate(r,self.env)
 def replies(self,state,inp):
  b=self.full(state);b.update(self.bits(inp,'next'));r=self.dag.restrict(self.formulas['rhoS'],b);return self.enumerate(r,self.sys)
 def justice_values(self,state,owner):
  bits=self.full(state);return tuple(self.dag.evaluate(r,bits) for r in self.justices[owner])

def sccs(vertices,adj):
 # Independent iterative Kosaraju; every cyclic SCC is eligible, not just sinks.
 vertices=set(vertices);seen=set();order=[]
 for start in vertices:
  if start in seen:continue
  seen.add(start);stack=[(start,iter(adj[start]))]
  while stack:
   u,it=stack[-1]
   try:
    v=next(it)
    if v in vertices and v not in seen:seen.add(v);stack.append((v,iter(adj[v])))
   except StopIteration:order.append(u);stack.pop()
 rev={u:[] for u in vertices}
 for u in vertices:
  for v in adj[u]:
   if v in vertices:rev[v].append(u)
 seen=set();out=[]
 for start in reversed(order):
  if start in seen:continue
  seen.add(start);todo=[start];component=[]
  while todo:
   u=todo.pop();component.append(u)
   for v in rev[u]:
    if v not in seen:seen.add(v);todo.append(v)
  out.append(component)
 return out,rev

def audit_graph(m,name,boundary):
 graph=loadjson(CERT/(name+'.json'));nodes={n['id']:n for n in graph['nodes']};require(len(nodes)==len(graph['nodes']),'unique graph ids')
 edges=defaultdict(list);adj={i:set() for i in nodes}
 for e in graph['edges']:require(e['source'] in nodes and e['target'] in nodes,'graph endpoints');edges[e['source']].append(e);adj[e['source']].add(e['target'])
 reached=set(graph['roots']);todo=list(reached)
 while todo:
  for v in adj[todo.pop()]:
   if v not in reached:reached.add(v);todo.append(v)
 require(reached==set(nodes),'all certificate states reachable')
 if name=='NEW_GRAPH':require(len(graph['roots'])==1 and statekey(nodes[graph['roots'][0]]['state'])==statekey(boundary['boundary']),'exact new pending root')
 else:
  for r in graph['roots']:require(m.test('thetaE',nodes[r]['state']) and m.test('thetaS',nodes[r]['state']),'old native initializer')
  require(any(statekey(n['state'])==statekey(boundary['boundary']) and n['private']['phase']==0 for n in nodes.values()),'old graph contains full pending boundary')
 legal_count=0;response_count=0;envjustice={};sysjustice={}
 for i,n in nodes.items():
  s=n['state'];m.full(s)
  actual=m.legal(s);keys={statekey(v) for v in actual};listed={statekey(e['input']) for e in edges[i]}
  require(len(keys)==len(actual) and len(listed)==len(edges[i]) and keys==listed,'all native legal inputs exactly once at node '+str(i));legal_count+=len(actual)
  # Enumerating all ten ENV fields above includes every 250,000 typed valuation.
  require(all(all(v[k]==value(s[k]) for k in COORDS) for v in actual),'full typed ENV legal closure')
  for e in edges[i]:
   target=nodes[e['target']]['state'];require(all(value(target[k])==value(v) for k,v in e['input'].items()),'target contains actual input')
   require(m.test('rhoE',s,target) and m.test('rhoS',s,target),'actual native source edge');response_count+=1
  envjustice[i]=m.justice_values(s,'ENV');sysjustice[i]=m.justice_values(s,'SYS')
 def cyclic(c):return len(c)>1 or c[0] in adj[c[0]]
 for j in range(len(m.justices['SYS'])):
  comps,_=sccs([i for i in nodes if not sysjustice[i][j]],adj)
  for c in comps:
   require(not(cyclic(c) and all(any(envjustice[i][k] for i in c) for k in range(len(m.justices['ENV'])))),'native ENV-fair SYS-unfair cycle')
 comps,rev=sccs(nodes,adj);accept=set()
 for c in comps:
  if cyclic(c) and all(any(envjustice[i][k] for i in c) for k in range(len(m.justices['ENV']))) and all(any(sysjustice[i][k] for i in c) for k in range(len(m.justices['SYS']))):accept.update(c)
 can=set(accept);todo=list(can)
 while todo:
  for v in rev[todo.pop()]:
   if v not in can:can.add(v);todo.append(v)
 require(can==set(nodes),'native fair cooperative continuation from every reachable graph node')
 return {'states':len(nodes),'edges':response_count,'legal_inputs_exactly_covered':legal_count,'all_typed_next_ENV_fields_enumerated_with_exact_pruning':True,'coordinate_closure':True,'strict_native_justice_audit':True,'cooperative_native_justice_audit':True,'private_policy_update':'not independently checked by this native binding audit; source graph auditor covers private phase'}

def audit_counter(m,released,boundary):
 c=loadjson(CERT/'WC_COUNTERCERTIFICATE.json');states=c['states'];require(statekey(states[c['root']])==statekey(boundary['boundary']),'counter root is full pending state')
 rowids={r['source'] for r in c['rows']};exits={r['state'] for r in c['not_C_exits']};require(len(rowids)==len(c['rows']) and not rowids&exits and rowids|exits==set(range(len(states))),'counter row/exit coverage')
 safe_count=0;adj={i:set() for i in range(len(states))}
 for row in c['rows']:
  i=row['source'];s=states[i];inp=row['input'];require(m.test('rhoE',s,inp),'counter chosen input native legal')
  safe=m.replies(s,inp);listed=[normalize(r['output']) for r in row['all_safe_outputs']]
  require(len({statekey(v) for v in listed})==len(listed) and {statekey(v) for v in safe}=={statekey(v) for v in listed},'all 300 typed native SYS replies covered')
  safe_count+=len(safe)
  for r in row['all_safe_outputs']:
   require(statekey(states[r['target']])==statekey({**inp,**r['output']}),'full counter successor binding');adj[i].add(r['target'])
  require(all(m.justice_values(s,'ENV')),'counter every nonexit satisfies every ENV justice')
 common_bad=[j for j in range(len(m.justices['SYS'])) if all(not m.justice_values(states[i],'SYS')[j] for i in rowids)]
 require(common_bad,'one SYS justice false on every infinite nonexit branch')
 for row in c['not_C_exits']:
  s=states[row['state']];inp=row['typed_illegal_input'];require(not m.test('rhoE',s,inp),'exit flip input source illegal')
  require(not m.replies(s,inp),'exit typed input has zero native SYS replies')
  ss={**s,'~envHelp':False};ii={**inp,'~envHelp':True}
  require(released.test('rhoE',ss,ii),'actual export permits first flip witness')
  require(not released.replies(ss,ii),'actual export first flip has zero native SYS replies')
 reached={c['root']};todo=list(reached)
 while todo:
  for v in adj[todo.pop()]:
   if v not in reached:reached.add(v);todo.append(v)
 require(reached==set(range(len(states))),'all counter states reachable')
 return {'states':len(states),'nonexit_rows':len(rowids),'exits':len(exits),'all_safe_replies':safe_count,'typed_SYS_outputs_per_row':300,'SYS_justice_indices_false_on_all_nonexit_states':common_bad,'every_native_legal_safe_reply_bound':True,'native_export_first_flip_zero_response_confirmed':True}

def main():
 start=time.monotonic();result={'schema':'v64-independent-native-finite-audit-v1','status':'RUNNING','independence':'No producer modules, BDD libraries, source equation implementations, or producer PASS flags imported. Independent native table parser/evaluator, exhaustive typed field enumerator, graph SCC/fairness audit. Native compiler/exporter and shared field encoding metadata remain trusted.'}
 try:
  boundary=loadjson(CERT/'BOUNDARY.json');old=Model('old-original');new=Model('new-original');released=Model('new-released')
  result['typed_carriers']={'old':old.carrier,'new':new.carrier,'released':released.carrier}
  # Bind the actual BOOT and exact carried logical monitor; no initializers imposed at new root.
  require(old.test('thetaE',boundary['initial']) and old.test('thetaS',boundary['initial']),'old initializer')
  require(old.test('rhoE',boundary['initial'],boundary['boundary']) and old.test('rhoS',boundary['initial'],boundary['boundary']),'native actual BOOT')
  require(boundary['initial']['request']=='S0' and boundary['boundary']['request']=='S2','pending monitor carried')
  require(not new.test('thetaS',boundary['boundary']),'pending root is noninitial')
  result['boundary']={'all_source_fields':len(boundary['boundary']),'native_old_BOOT_valid':True,'request_initial':'S0','request_pending':'S2','new_root_fails_initializer':True,'no_reinitialization_for_region_or_certificate':True}
  print('BOUNDARY_PASS',flush=True)
  result['old_graph']=audit_graph(old,'OLD_GRAPH',boundary);print('OLD_GRAPH_PASS',flush=True)
  result['new_graph']=audit_graph(new,'NEW_GRAPH',boundary);print('NEW_GRAPH_PASS',flush=True)
  result['countercertificate']=audit_counter(new,released,boundary);print('COUNTER_PASS',flush=True)
  result['status']='PASS'
 except BaseException as e:result.update(status='FAILED',exception=repr(e),traceback=traceback.format_exc())
 result['elapsed_seconds']=time.monotonic()-start;result['file_hash_anchors']=anchors
 result['checker_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 (HERE/'NATIVE_CERTIFICATE_BINDING_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k not in ('file_hash_anchors','traceback')},indent=2),flush=True)
 if result['status']!='PASS':sys.exit(1)
if __name__=='__main__':main()
