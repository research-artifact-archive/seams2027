"""Independent finite closed-layout strict solving from raw native node tables.
Own bit-set fixed point loop; no producer fixed-point or BDD implementation.
"""
from audit_native_certificates import *
import gc
class QuantifiedDAG:
 def __init__(self,d):self.d=d;self.calls=0
 @lru_cache(maxsize=300000)
 def join(self,op,a,b):
  if a>b:a,b=b,a
  if op=='or':
   if b==1 or a==1:return 1
   if a==0:return b
  else:
   if a==0:return 0
   if a==1:return b
  if a==b:return a
  va=self.d.nodes[a][0];vb=self.d.nodes[b][0];v=min(va,vb)
  al,ah=self.d.nodes[a][1:] if va==v else (a,a);bl,bh=self.d.nodes[b][1:] if vb==v else (b,b)
  return self.d.mk(v,self.join(op,al,bl),self.join(op,ah,bh))
 def typed_quantify(self,r,model,fields,op):
  for f in fields:
   rs=[self.d.restrict(r,model.enc[f['name'],v,'next']) for v in f['values']]
   r=0 if op=='or' else 1
   for rr in rs:r=self.join(op,r,rr)
  return r

def explicit_game(age,boundary):
 start=time.monotonic();m=Model(age+'-original');layout={k:value(boundary['boundary'][k]) for k in COORDS}
 other=[f for f in m.fields if f['name'] not in layout]
 states=[{**layout,**dict(zip([f['name'] for f in other],vals))} for vals in product(*(f['values'] for f in other))]
 require(len(states)==4800 and len(other)==8,'exact 4800 state slice; only six ENV fields fixed')
 ids={statekey(s):i for i,s in enumerate(states)};root=ids[statekey(boundary['boundary'])];q=(1<<len(states))-1
 precomputed=[];C=0;aa=[0]*len(m.justices['ENV']);gg=[0]*len(m.justices['SYS']);qd=QuantifiedDAG(m.dag);c_cache={};legalcount=0;replycount=0
 for i,s in enumerate(states):
  ss=m.full(s);native_s=m.dag.restrict(m.formulas['rhoS'],ss)
  if native_s not in c_cache:
   e=qd.typed_quantify(native_s,m,m.sys,'or');a=qd.typed_quantify(e,m,m.env,'and');require(a in (0,1),'full current valuation and all typed next fields quantified');c_cache[native_s]=a
  cin=c_cache[native_s]
  if cin:C|=1<<i
  x=int(s['robotX']);y=int(s['robotY']);c=int(s['charging']);blocked=sum(s[k]=='true' for k in ('Ablocked','Bblocked','Cblocked'))
  allowed=1 if (x,y)==(4,0) and c<3 else 1+(x>0)+(x<4)+(y>0)+(y<4)
  require(bool(cin)==(allowed>blocked),'native full typed C equals N > k in every slice state')
  for j,a in enumerate(m.justice_values(s,'ENV')):
   if a:aa[j]|=1<<i
  for j,g in enumerate(m.justice_values(s,'SYS')):
   if g:gg[j]|=1<<i
  inputs=m.legal(s);legalcount+=len(inputs);moves=[]
  for inp in inputs:
   require(all(inp[k]==layout[k] for k in COORDS),'all typed legal inputs stay in fixed layout')
   outputs=m.replies(s,inp);replycount+=len(outputs);targets=0
   for out in outputs:targets |= 1<<ids[statekey({**inp,**out})]
   moves.append(targets)
  precomputed.append(tuple(moves))
  if i%1000==0:print(age,'ENUM',i,'seconds',round(time.monotonic()-start,2),flush=True)
 require(C.bit_count()==4596,'expected literal first-flip slice count')
 def solve(guard):
  calls=0
  lists=[tuple(t&guard for t in choices) if (guard>>i)&1 else tuple(0 for t in choices) for i,choices in enumerate(precomputed)]
  @lru_cache(None)
  def pre(target):
   nonlocal calls
   calls+=1;answer=0
   for i,choices in enumerate(lists):
    if all(t&target for t in choices):answer|=1<<i
   return answer
  z=q;outer=0
  while True:
   before=z;outer+=1
   for g in gg:
    y=0
    while True:
     prior=y;base=(g&pre(z))|pre(y);yy=0
     for a in aa:
      x=z
      while True:
       xx=base|((q^a)&pre(x))
       require(xx&~x==0,'independent X descending')
       if xx==x:break
       x=xx
      yy|=x
     require(prior&~yy==0,'independent Y ascending');y=yy
     if y==prior:break
    require(y&~z==0,'sequential outer descent');z=y
   if z==before:break
  return z&guard,{'predecessor_evaluations':calls,'outer_iterations':outer}
 w,wlog=solve(q);wf,wflog=solve(C)
 result={'age':age,'status':'PASS','slice_states':len(states),'fixed_ENV_coordinates':layout,'free_fields':[f['name'] for f in other], 'typed_legal_inputs':legalcount,'typed_safe_replies':replycount,'C_count':C.bit_count(),'W_count':w.bit_count(),'W_F_count':wf.bit_count(),'pending_root_index':root,'pending_in_C':bool(C&(1<<root)),'pending_in_W':bool(w&(1<<root)),'pending_in_W_F':bool(wf&(1<<root)),'W_log':wlog,'W_F_log':wflog,'elapsed_seconds':time.monotonic()-start,'scope':'Counts only the 4800-state closed fixed-ENV-layout slice; actual legal inputs enumerate all ten next ENV fields including all coordinate values; helper flip C universally quantifies all typed next ENV fields. No source initialization restriction.'}
 print(json.dumps(result,indent=2),flush=True)
 # Save enumerated region membership for exact comparison, not just counts.
 (HERE/(age+'_explicit_regions.json')).write_text(json.dumps({'states':states,'C_ids':[i for i in range(len(states)) if C>>i&1],'W_ids':[i for i in range(len(states)) if w>>i&1],'W_F_ids':[i for i in range(len(states)) if wf>>i&1]},separators=(',',':'))+'\n')
 return result
if __name__=='__main__':
 result={'schema':'v64-independent-explicit-slice-audit-v1','status':'RUNNING','independence':'Uses only own raw native table parser/evaluator/typed enumerator, own DAG OR/AND for typed quantification, and own sequential bit-set GR(1) fixed point implementation. No producer solver or BDD library imports.'}
 try:
  boundary=loadjson(CERT/'BOUNDARY.json');result['runs']=[explicit_game(age,boundary) for age in sys.argv[1:] or ['new']];result['status']='PASS'
 except BaseException as e:result.update(status='FAILED',exception=repr(e),traceback=traceback.format_exc());print(result['traceback'],flush=True)
 result['file_hash_anchors']=anchors;result['checker_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();(HERE/'EXPLICIT_SLICE_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
 if result['status']!='PASS':sys.exit(1)
