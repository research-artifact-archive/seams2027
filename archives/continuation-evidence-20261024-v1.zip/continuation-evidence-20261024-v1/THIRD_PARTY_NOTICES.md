Source and redistribution boundary

The 41 central records and all saved-replay inputs retain their copied bytes.
Source archive/member/hash provenance is in claim_to_evidence.json; the replay
ledger distinguishes original hashes, anonymous transport hashes and package
copies. Qualification metadata path aliasing is documented separately in
qualification/RECEIPT_TRANSFORM_LEDGER.json. LICENSE-original.txt applies to
original artifact contributions, not externally obtained source material.

No publisher PDF/HTML, paper-derived Lift specification, upstream Java source,
full upstream-derived extractor, JDK/JAR/native library/compiled class, or
source-fetch cache is included. Saved exported model JSON still retains its
parsed/translated formula inventories and typed encoding metadata. The full
local R5 inspection archive is not
distributed. Earlier public source-restoration procedures retrieve omitted
inputs from their distributors with exact hashes and original terms.

The current saved Patrol/manager/reduced replay needs no omitted source bytes.
It trusts native exporter/encoding and saved native/process provenance; omitted
historical source/runtime pins are explicitly outside its qualified scope.
The optional earlier native-regeneration kit has its own exact installed
runtime and same-host qualification, described in REPLAY_COMMANDS.txt.

Original public boundary record:
https://github.com/research-artifact-archive/seams2027/blob/certificate-finite-evidence-20261023-v2/THIRD_PARTY_NOTICES.md
