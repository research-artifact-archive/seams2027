"""Explicit-root Lift source checker. No synthesis, BDD evaluation, or graph edits.

CLI: python3 -I -B check_source_roots.py PLAN.json old_gate|candidate_roots OUTPUT.json
The two copied independent modules are byte-identical to the prior source audit.
Only source_contracts' Lift equations and independent_core's finite graph engine
are used. SavedDag is not used. All output is new/exclusive; inputs are read-only.
"""
from pathlib import Path
import hashlib
import itertools
import json
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from independent_core import AuditError, need, decode_json, pin, read_pin, save_new, finite_fairness
from source_contracts import CONTRACTS, HELPER

C = CONTRACTS['lift__trivial_1']
ARMS = ('retain_old_native', 'saved_normalized', 'saved_preference')
GRAPH_FOR_ARM = dict(zip(ARMS, ('native', 'normalized', 'preference')))
SCHEMA = 'v58-pending-rooted-graph-certificate-bundle-v1'
ENV_INPUTS = tuple(dict(zip(C.env, values)) for values in itertools.product(('false', 'true'), repeat=4))
OLD_SOURCE_APPEND = b'\n\nassumption -- constructed_old_mode_no_b1\n\talw(b1=false);\n'


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def source_state(value):
    need(isinstance(value, dict) and set(value) == set(C.names), 'Exact ten source/AUX fields required')
    need(all(type(value[n]) is str and value[n] in C.values[n] for n in C.names), 'Source field value/type')
    return {n: value[n] for n in C.names}


def validate_mode(plan):
    mode = plan['old_mode']
    need(mode.get('disabled_ENV') == 'b1' and mode.get('current_value') == 'false'
         and mode.get('next_value') == 'false'
         and mode.get('source_initializers_preserved') is True, 'Wrong frozen old-mode restriction')
    need(set(mode) == {'disabled_ENV', 'current_value', 'next_value', 'source_initializers_preserved'},
         'Unexpected old-mode semantics')


def validate_source(ref):
    raw = read_pin(ref)
    need(len(raw) == C.source_bytes and hashlib.sha256(raw).hexdigest() == C.source_sha256,
         'Wrong exact source contract')


def manifest_pins(value):
    """Collect provenance bindings without interpreting any saved model predicate."""
    found = {}
    def walk(x):
        if isinstance(x, dict):
            if {'path', 'bytes', 'sha256'} <= set(x):
                need(type(x['path']) is str and type(x['bytes']) is int and x['bytes'] >= 0
                     and type(x['sha256']) is str and len(x['sha256']) == 64, 'Malformed manifest pin')
                p = {k: x[k] for k in ('path', 'bytes', 'sha256')}
                need(p['path'] not in found or found[p['path']] == p, 'Conflicting manifest pin')
                found[p['path']] = p
            for v in x.values(): walk(v)
        elif isinstance(x, list):
            for v in x: walk(v)
    walk(value)
    return list(found.values())


def validate_source_roster_and_old(plan):
    roster = decode_json(read_pin(plan['roster']))
    need(roster.get('schema') == 'v58-pending-handoff-roster-v1'
         and roster.get('boundaries') == plan['boundaries']
         and roster.get('source_fields') == list(C.names)
         and roster.get('boundary_count') == 3, 'Pinned roster/PLAN mismatch')
    source_raw = read_pin(plan['source'])
    need(read_pin(plan['old_source']) == source_raw + OLD_SOURCE_APPEND, 'Old source is not exact frozen append')
    return {'roster': plan['roster'], 'old_source': plan['old_source'], 'exact_old_source_append': True}


def canonical_plan(plan):
    """Normalize only manifest names, never controller/source state or memory."""
    need(plan.get('schema') == 'v58-pending-handoff-plan-v1', 'Plan schema')
    normalized = dict(plan)
    rows = []
    for original in plan['boundaries']:
        row = dict(original)
        row.update(old_node=original['reached_native_node'], old_rank=original['reached_rank'],
                   prefix=original['prefix_node_ids'])
        candidates = original['candidates']
        need(isinstance(candidates, list) and len(candidates) == 3
             and [c['candidate'] for c in candidates] == list(ARMS), 'Frozen candidate list and order')
        row['roots'] = {c['candidate']: {'graph': c['graph'], 'node': c['root'], 'rank': c['rank']}
                        for c in candidates}
        rows.append(row)
    normalized['boundaries'] = rows
    return normalized


def env_legal(s, t, old):
    return C.rho_e(s, t) and (not old or (s['b1'] == 'false' and t['b1'] == 'false'))


def load_graph(ref):
    raw = read_pin(ref)
    need(len(raw) <= 16 * 1024 * 1024, 'Graph size cap')
    g = decode_json(raw)
    need(g.get('complete') is True and g.get('fixture_id') == C.candidate, 'Complete exact Lift graph required')
    expected_model = ref.get('model_sha256')
    if expected_model is None and isinstance(ref.get('model'), dict):
        expected_model = ref['model'].get('sha256')
    need(isinstance(expected_model, str) and len(expected_model) == 64
         and g.get('model_sha256') == expected_model, 'Graph/model digest binding')
    need(g.get('rank_domain_size') == 3, 'Exact Lift private rank domain')
    need(isinstance(g.get('nodes'), list) and 0 < len(g['nodes']) <= 4096, 'Graph node cap')
    need(isinstance(g.get('edges'), list) and len(g['edges']) <= 100000, 'Graph edge cap')
    nodes, states, helpers = {}, {}, {}
    for n in g['nodes']:
        identity = n.get('id')
        need(type(identity) is str and identity.isdigit() and str(int(identity)) == identity
             and identity not in nodes and n.get('native_id') == int(identity), 'Graph node ID')
        need(type(n.get('rank')) is int and 0 <= n['rank'] < 3 and type(n.get('initial')) is bool,
             'Graph rank or original-initial marker')
        need(n.get('rank_class') == 'tau.smlab.syntech.games.gr1.GR1RankInfo'
             and n.get('rank_info') == 'System Justice ' + str(n['rank']), 'Private rank representation')
        v = n.get('valuation')
        need(isinstance(v, dict) and set(v) in (set(C.names), set(C.names) | {HELPER}), 'Graph valuation names')
        if HELPER in v:
            need(v[HELPER] in ('false', 'true'), 'Graph helper value')
        states[identity] = source_state({k: v[k] for k in C.names})
        helpers[identity] = v.get(HELPER, 'false')
        need(isinstance(n.get('bits'), dict) and all(k.isdigit() and type(x) is bool for k, x in n['bits'].items()),
             'Graph raw bit representation')
        successors = n.get('successors')
        need(isinstance(successors, list) and all(type(x) is str for x in successors)
             and len(successors) == len(set(successors)), 'Successor list integrity')
        if 'native_bdd_text' in n:
            text = n['native_bdd_text']
            need(type(text) is str and text.startswith('<') and text.endswith('>'), 'Native valuation text')
            pairs = [x.strip().split(':', 1) for x in text[1:-1].split(',')]
            need(all(len(x) == 2 for x in pairs) and len(pairs) == len(v)
                 and dict(pairs) == v, 'Native valuation text mismatch')
        nodes[identity] = n
    need(len({HELPER in n['valuation'] for n in nodes.values()}) == 1, 'Mixed helper inventory')
    edges = []
    for edge in g['edges']:
        need(isinstance(edge, list) and len(edge) == 2 and all(type(x) is str and x in nodes for x in edge),
             'Edge endpoint integrity')
        edges.append(tuple(edge))
    need(len(edges) == len(set(edges)), 'Duplicate graph edge')
    declared = {(a, b) for a, n in nodes.items() for b in n['successors']}
    need(declared == set(edges), 'Graph edge/successor list mismatch')
    need(g.get('api_state_count') == len(nodes) and g.get('api_transition_count') == len(edges),
         'Complete API graph counts mismatch')
    return {'ref': ref, 'raw': g, 'nodes': nodes, 'states': states, 'helpers': helpers,
            'edges': edges, 'adj': {i: list(n['successors']) for i, n in nodes.items()}}


def root_binding(graph, root, rank, expected=None):
    need(type(root) is str and root in graph['nodes'], 'Unknown explicit root')
    need(type(rank) is int and graph['nodes'][root]['rank'] == rank, 'Actual root rank mismatch')
    need(graph['helpers'][root] == 'false', 'Residual root must be helper=false or helper-free')
    if expected is not None:
        need(graph['states'][root] == source_state(expected), 'Exact root source/AUX mismatch')
    return {'root_id': root, 'rank': rank, 'original_initial_marker': graph['nodes'][root]['initial'],
            'source_initializer_compatible': bool(C.theta_e(graph['states'][root]) and C.theta_s(graph['states'][root])),
            'source_ENV_initializer': bool(C.theta_e(graph['states'][root])),
            'source_SYS_AUX_initializer': bool(C.theta_s(graph['states'][root])),
            'source_state': graph['states'][root]}


def view(graph, roots, old):
    """Build the entire original-legal reachable suffix from explicit memory roots."""
    need(roots and len(roots) == len(set(roots)), 'Distinct nonempty roots required')
    for r in roots:
        need(r in graph['nodes'] and graph['helpers'][r] == 'false', 'View root/helper binding')
        need(not old or graph['states'][r]['b1'] == 'false', 'Old root violates b1 restriction')
    reached, pending, edges, ignored = set(roots), list(roots), [], 0
    while pending:
        a = pending.pop()
        s = graph['states'][a]
        for b in graph['adj'][a]:
            if graph['helpers'][b] != 'false' or not env_legal(s, graph['states'][b], old):
                ignored += 1
                continue
            edges.append((a, b))
            if b not in reached:
                reached.add(b)
                pending.append(b)
    outgoing = {i: [] for i in reached}
    for a, b in edges:
        outgoing[a].append(b)
    coverage, violations = [], []
    for a in sorted(reached, key=int):
        s = graph['states'][a]
        observed = {}
        for b in outgoing[a]:
            t = graph['states'][b]
            key = tuple(t[n] for n in C.env)
            observed.setdefault(key, []).append(b)
            if not C.rho_s(s, t):
                violations.append({'from': a, 'to': b, 'reason': 'source_SYS_safety_or_AUX_update'})
        legal = [tuple(e[n] for n in C.env) for e in ENV_INPUTS if env_legal(s, e, old)]
        missing = [e for e in legal if e not in observed]
        multiple = [{'ENV': list(e), 'targets': ids} for e, ids in observed.items() if len(ids) != 1]
        need(set(observed) <= set(legal), 'Internal source-view ENV filtering mismatch')
        coverage.append({'node': a, 'all_typed_ENV_inputs_examined': 16, 'legal_count': len(legal),
                         'represented_count': len(observed), 'missing': [list(x) for x in missing],
                         'multiple_responses': multiple, 'pass': not missing and not multiple})
    source_coverage = all(row['pass'] for row in coverage)
    ej, sj = [], [set() for _ in range(3)]
    for a in reached:
        env_j, sys_j = C.justice(graph['states'][a])
        need(env_j == [] and len(sys_j) == 3, 'Exact ordered Lift justice inventory')
        for i, truth in enumerate(sys_j):
            if truth:
                sj[i].add(a)
    fair = finite_fairness(reached, edges, roots, ej, sj)
    safety = not violations
    complete = source_coverage
    strict = bool(safety and fair['strict_liveness']['pass']) if complete else None
    cooperative = bool(fair['nonconflicting']['pass']) if complete and safety else None
    return {'complete': complete, 'strict': strict, 'cooperative': cooperative,
            'source_coverage': source_coverage, 'source_safety': safety,
            'status': 'COMPLETE_ROOT_CERTIFICATE' if complete else 'UNKNOWN_INCOMPLETE_SOURCE_COVERAGE',
            'roots': list(roots), 'old_mode': old, 'reachable_nodes': sorted(reached, key=int),
            'reachable_state_count': len(reached), 'reachable_edge_count': len(edges),
            'derived_edges_sha256': canonical(sorted(edges)), 'ignored_non_original_or_mode_edges': ignored,
            'input_coverage': coverage, 'safety_violations': violations, 'fairness': fair,
            'ordered_justice': {'ENV': [], 'SYS': [n + '=S0' for n, _ in C.aux]},
            'cooperation_basis': 'Complete original-legal reachable suffix; existential ENV-fair infinite continuation from every reached private state. No finite-trace inference.'}


def initial_roots(graph):
    roots = [i for i, n in graph['nodes'].items() if n['initial']]
    need(len(roots) == 2, 'Both original initial native nodes required')
    bindings = [root_binding(graph, i, 0) for i in roots]
    need(all(b['source_initializer_compatible'] for b in bindings), 'Original initial source/monitor binding')
    envs = {tuple(graph['states'][i][n] for n in C.env) for i in roots}
    expected = {tuple(e[n] for n in C.env) for e in ENV_INPUTS if C.theta_e(e)}
    need(envs == expected and len(envs) == len(roots), 'Original quantified ENV initial coverage')
    need('0' in roots, 'Frozen prefix start node0 must be original-initial')
    return sorted(roots, key=int), bindings


def validate_cohort(plan, native):
    rows = plan['boundaries']
    need(isinstance(rows, list) and len(rows) == 3
         and [row['old_node'] for row in rows] == ['524', '526', '756'], 'Frozen three-boundary roster required')
    need(len({row['id'] for row in rows}) == 3 and len({row['old_node'] for row in rows}) == 3,
         'Boundary identity duplicate')
    # This traversal is performed only during the authorized old_gate/candidate CLI.
    starts, _ = initial_roots(native)
    reach = set(starts)
    pending = list(starts)
    while pending:
        a = pending.pop()
        for b in native['adj'][a]:
            if (native['helpers'][b] == 'false' and native['states'][b]['b1'] == 'false'
                    and env_legal(native['states'][a], native['states'][b], True) and b not in reach):
                reach.add(b)
                pending.append(b)
    expected = {i for i in reach if native['states'][i]['c'] == 'false'
                and any(native['states'][i][n] == 'S1' and native['states'][i][f] == 'false'
                        for (n, _), f in zip(C.aux, C.system))}
    need(expected == {row['old_node'] for row in rows}, 'Frozen boundary roster incomplete/extra')
    for row in rows:
        root_binding(native, row['old_node'], row['old_rank'], row['source_state'])
        prefix = row['prefix']
        need(isinstance(prefix, list) and len(prefix) >= 2 and prefix[0] == '0'
             and prefix[-1] == row['old_node'], 'Frozen prefix endpoints')
        need(len(prefix) == 3 and row['prefix_input_bits'] == [
            ''.join('1' if native['states'][t][k] == 'true' else '0' for k in C.env)
            for t in prefix[1:]], 'Frozen prefix offered inputs')
        for a, b in zip(prefix, prefix[1:]):
            need(a in native['nodes'] and b in native['adj'][a]
                 and native['helpers'][a] == native['helpers'][b] == 'false'
                 and env_legal(native['states'][a], native['states'][b], True)
                 and C.rho_s(native['states'][a], native['states'][b]), 'Frozen prefix source edge')
    return {'complete': True, 'all_initial_old_reachable_count': len(reach), 'initial_roots': starts,
            'genuinely_pending_private_nodes': sorted(expected, key=int),
            'distinct_source_valuations': len({canonical(row['source_state']) for row in rows}),
            'prefixes_verified': len(rows)}


def validate_old_adoption(plan, plan_pin):
    path = Path(plan['old_gate_adoption_path'])
    need(path.is_absolute() and path.is_file() and not path.is_symlink(), 'Missing old-gate adoption')
    adoption = decode_json(path.read_bytes())
    need(adoption.get('status') == 'ADOPTED_BOTH_OLD_GATE_CERTIFICATES', 'Old gate not adopted')
    bound_plan = adoption.get('plan', adoption.get('plan_pin'))
    need(bound_plan == plan_pin, 'Old-gate adoption plan binding')
    source_path = Path(plan['old_gate_source_result_path'])
    need(source_path.is_absolute() and source_path.is_file() and not source_path.is_symlink(), 'Missing source old-gate result')
    source_pin = pin(source_path)
    # Adoption must pin the exact source result, wherever the root stores its list.
    def contains_pin(x):
        if isinstance(x, dict):
            if x.get('sha256') == source_pin['sha256'] and x.get('bytes') == source_pin['bytes']:
                return True
            return any(contains_pin(v) for v in x.values())
        return isinstance(x, list) and any(contains_pin(v) for v in x)
    need(contains_pin(adoption), 'Old-gate adoption lacks source certificate pin')
    result = decode_json(read_pin(source_pin))
    need(result.get('schema') == SCHEMA and result.get('status') == 'COMPLETE_OLD_GATE'
         and result.get('route') == 'source' and result.get('plan') == plan_pin, 'Source old-gate bundle binding')
    gate = result.get('old_gate', {})
    need(all(gate.get(k) is True for k in ('complete', 'strict', 'cooperative', 'source_coverage', 'source_safety')),
         'False or incomplete old gate')
    saved_path = Path(plan['old_gate_saved_result_path'])
    need(saved_path.is_absolute() and saved_path.is_file() and not saved_path.is_symlink(),
         'Missing saved-model old-gate result')
    saved_pin = pin(saved_path)
    need(adoption.get('certificates') == {'source': source_pin, 'saved_model': saved_pin},
         'Old-gate adoption must pin the exact certificate pair')
    saved = decode_json(read_pin(saved_pin))
    need(saved.get('schema') == SCHEMA and saved.get('status') == 'COMPLETE_OLD_GATE'
         and saved.get('route') == 'saved_model' and saved.get('plan') == plan_pin,
         'Saved-model old-gate bundle binding')
    other = saved.get('old_gate', {})
    need(all(other.get(k) is True for k in ('complete', 'strict', 'cooperative', 'source_coverage', 'source_safety')),
         'Saved-model old gate is false or incomplete')
    need(sorted(gate['roots'], key=int) == sorted(other['starts'], key=int) and len(gate['roots']) == 2
         and gate['reachable_nodes'] == other['reachable_nodes']
         and gate['reachable_state_count'] == other['reachable_node_count']
         and gate['reachable_edge_count'] == other['edge_count']
         and gate['derived_edges_sha256'] == canonical(sorted(other['graph']['edges'])),
         'Complete old closures disagree')
    qualification_pin = pin(plan['interface_qualification_result_path'])
    qualification = decode_json(read_pin(qualification_pin))
    need(qualification.get('status') == 'PASS_INTERFACE_QUALIFICATION'
         and qualification.get('plan') == plan_pin and qualification.get('checks')
         and all(c.get('pass_') is True for c in qualification['checks'])
         and pin(__file__) in qualification.get('code', []), 'Interface qualification missing, failed, or stale')
    for ref in manifest_pins(qualification):
        read_pin(ref)
    return gate, {'adoption': pin(path), 'source_certificate': source_pin, 'saved_certificate': saved_pin}


def run(plan_path, mode):
    plan_pin = pin(plan_path)
    raw_plan = decode_json(read_pin(plan_pin))
    provenance = manifest_pins(raw_plan)
    for ref in provenance:
        read_pin(ref)
    source_bindings = validate_source_roster_and_old(raw_plan)
    plan = canonical_plan(raw_plan)
    need(mode in ('old_gate', 'candidate_roots'), 'Unknown checker mode')
    source = plan['source']
    validate_source(source)
    validate_mode(plan)
    need(set(plan['graphs']) == {'native', 'normalized', 'preference'}, 'Frozen graph roster')
    graphs = {name: load_graph(ref) for name, ref in plan['graphs'].items()}
    result = {'schema': SCHEMA, 'route': 'source', 'mode': mode, 'plan': plan_pin,
              'source': source, 'graph_pins': {n: {k: r[k] for k in ('path', 'bytes', 'sha256')}
                                           for n, r in plan['graphs'].items()},
              'source_bindings': source_bindings, 'provenance_pin_count': len(provenance),
              'trust_scope': 'Hand-derived exact source equations and copied independent finite-set graph algorithm. No saved-model predicates, native compiler, solver, prior semantic verdict or finite trace determines a rooted verdict.',
              'boundaries': []}
    if mode == 'old_gate':
        roots, bindings = initial_roots(graphs['native'])
        gate = view(graphs['native'], roots, True)
        gate['initial_bindings'] = bindings
        gate['cohort_validation'] = validate_cohort(plan, graphs['native'])
        result.update(status='COMPLETE_OLD_GATE' if gate['complete'] else 'UNKNOWN_INCOMPLETE_OLD_GATE', old_gate=gate)
    else:
        gate, adoption = validate_old_adoption(plan, plan_pin)
        result.update(old_gate=gate, old_gate_adoption=adoption)
        validate_cohort(plan, graphs['native'])
        for row in plan['boundaries']:
            boundary = {'id': row['id'], 'source_state': row['source_state'], 'reached_native_node': row['old_node'],
                        'reached_rank': row['old_rank'], 'prefix': row['prefix'], 'candidates': []}
            need(set(row['roots']) == set(ARMS), 'Fixed three-arm candidate roster')
            for arm in ARMS:
                descriptor = row['roots'][arm]
                candidate = {'candidate': arm, 'graph_sha256': plan['graphs'][GRAPH_FOR_ARM[arm]]['sha256'],
                             'root_id': descriptor.get('node'), 'rank': descriptor.get('rank')}
                try:
                    need(descriptor.get('graph') == GRAPH_FOR_ARM[arm], 'Arm/graph identity')
                    if arm == 'retain_old_native':
                        need(descriptor.get('node') == row['old_node'] and descriptor.get('rank') == row['old_rank'],
                             'Retain-old must use exact reached private memory')
                    graph = graphs[descriptor['graph']]
                    candidate.update(root_binding(graph, descriptor['node'], descriptor['rank'], row['source_state']))
                    candidate.update(view(graph, [descriptor['node']], False))
                except (AuditError, KeyError, TypeError, ValueError) as error:
                    candidate.update(status='UNKNOWN_ROOT_BINDING_OR_STRUCTURE', complete=False, strict=None,
                                     cooperative=None, source_coverage=None, error=str(error))
                boundary['candidates'].append(candidate)
            result['boundaries'].append(boundary)
        complete = all(c['complete'] for b in result['boundaries'] for c in b['candidates'])
        result['status'] = 'COMPLETE_ROOTED_CANDIDATES' if complete else 'UNKNOWN_INCOMPLETE_ROOTED_CANDIDATES'
    need(pin(plan_path) == plan_pin, 'Plan changed during read-only check')
    for ref in provenance:
        read_pin(ref)
    result['input_pins_unchanged'] = True
    result['graph_mutations'] = 0
    result['native_solver_calls'] = 0
    return result


def main():
    need(len(sys.argv) == 4, 'Usage: check_source_roots.py PLAN.json MODE OUTPUT.json')
    plan_path, mode, output = sys.argv[1:]
    try:
        result = run(plan_path, mode)
    except (AuditError, OSError, KeyError, TypeError, ValueError) as error:
        result = {'schema': SCHEMA, 'route': 'source', 'mode': mode, 'status': 'UNKNOWN_INPUT_OR_BINDING',
                  'complete': False, 'strict': None, 'cooperative': None, 'error': str(error), 'boundaries': []}
        if Path(plan_path).is_file():
            result['plan'] = pin(plan_path)
    save_new(output, result)
    print(json.dumps({'status': result['status'], 'output': pin(output)}))
    return 0 if result['status'].startswith('COMPLETE_') else 2


if __name__ == '__main__':
    raise SystemExit(main())
