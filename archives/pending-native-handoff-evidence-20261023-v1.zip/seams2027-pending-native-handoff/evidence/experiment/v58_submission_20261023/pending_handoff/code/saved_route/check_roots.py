#!/usr/bin/env python3
"""Saved-model, immutable-graph explicit-root certification for frozen Lift N3.

No solver, extractor, source-checker import, initializer override or graph edit.
Native source predicates are checked against independently composed Lift BDD
clauses under helper=false. Fairness is exact on the entire rooted closure.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
from collections import defaultdict, deque
from itertools import product
sys.dont_write_bytecode = True
_spec=importlib.util.spec_from_file_location('v47_saved_model_generic',Path(__file__).resolve().parent/'generic_base.py')
G=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(G)

ENV = ['b1','b2','b3','c']
SYS = ['f1','f2','f3']
AUX = ['SYS_CONSTRAINT.%d.pRespondsToS.state' % i for i in range(3)]
FIELDS = ENV + SYS + AUX
SOURCE_SHA = '6a8f8220385130b2eb219ecfa33186b179d610ffcf805a30f9cab47ab204dae7'
ARM_GRAPHS = {'retain_old_native':'native','saved_normalized':'normalized','saved_preference':'preference'}
VENDOR = {'generic_base.py':'3c465e4253712c6f021920e6a164ef48c63c5bf6cfb3432d17ab95fb5778ebda','vendor/bdd_core.py':'f9497519b8a073a29e5748c908cadc804f437080cf12d36558d9e0210462dbac','vendor/graph_fairness.py':'3da6d64631bd88ae0bda4ad71ccc37c46f48de233a51dcc843a476e391981d45'}
req=G.require

class IntegrityError(ValueError): pass

def pin(path):
    path=Path(path).resolve(); raw=path.read_bytes()
    return {'path':str(path),'bytes':len(raw),'sha256':G.sha_bytes(raw)}

class Inputs:
    def __init__(self): self.seen={}
    def load(self, ref):
        if not isinstance(ref,dict) or not {'path','bytes','sha256'}<=set(ref): raise IntegrityError('Missing absolute file pin')
        p=Path(ref['path'])
        if not p.is_absolute() or not p.is_file() or p.is_symlink(): raise IntegrityError('File pin type/location')
        raw=p.read_bytes()
        if type(ref['bytes']) is not int or len(raw)!=ref['bytes'] or G.sha_bytes(raw)!=ref['sha256']: raise IntegrityError('File pin mismatch: '+p.name)
        self.seen[str(p.resolve())]=dict(path=str(p.resolve()),bytes=len(raw),sha256=G.sha_bytes(raw))
        return p
    def json(self, ref): return G.read_json(self.load(ref))
    def walk(self, item):
        if isinstance(item,dict):
            if {'path','bytes','sha256'}<=set(item): self.load(item)
            for v in item.values():self.walk(v)
        elif isinstance(item,list):
            for v in item:self.walk(v)
    def recheck(self):
        for ref in list(self.seen.values()):self.load(ref)

def equations(ctx):
    """Literal transcription of the pinned Lift source including three monitors."""
    b=ctx.b; T=lambda n,p=False:ctx.literal(n,'true',p); F=lambda n,p=False:ctx.literal(n,'false',p)
    bs=[T(n) for n in ENV[:3]]; fs=[T(n) for n in SYS]; fn=[T(n,True) for n in SYS]; c=T('c')
    one=b.conj(b.disj(*fs),*(b.implies(fs[i],b.conj(*(b.neg(fs[j]) for j in range(3) if j!=i))) for i in range(3)))
    env=[one]
    for i in range(3):
        env.extend([b.implies(b.conj(bs[i],fs[i]),F(ENV[i],True)),b.implies(b.conj(bs[i],b.neg(fs[i]),b.neg(c)),T(ENV[i],True))])
    moves=[b.implies(fs[0],b.disj(b.conj(fn[0],b.neg(bs[1]),b.neg(bs[2])),b.conj(fn[1],bs[1]),b.conj(fn[1],bs[2]),b.conj(fn[0],c))),
           b.implies(fs[1],b.disj(b.conj(fn[0],bs[0]),b.conj(fn[1],b.neg(bs[0]),b.neg(bs[2])),b.conj(fn[2],bs[2]),b.conj(fn[1],c))),
           b.implies(fs[2],b.disj(b.conj(fn[2],b.neg(bs[0]),b.neg(bs[1])),b.conj(fn[1],bs[0]),b.conj(fn[1],bs[1]),b.conj(fn[2],c)))]
    monitors=[]
    for i,name in enumerate(AUX):
        pending=ctx.literal(name,'S1'); nxt=ctx.literal(name,'S1',True); response=b.disj(fs[i],c)
        monitors.append(b.iff(nxt,b.conj(b.disj(pending,bs[i]),b.neg(response))))
    return {'thetaE':b.conj(*(F(n) for n in ENV[:3])),
            'thetaS':b.conj(T('f1'),F('f2'),F('f3'),*(ctx.literal(n,'S0') for n in AUX)),
            'rhoE':b.conj(*env), 'rhoS':b.conj(*moves,*monitors),
            'justices':{'ENV':[], 'SYS':[ctx.literal(n,'S0') for n in AUX]}}

def cofactor(ctx,u):
    if '~envHelp' not in ctx.by_name:return u
    bits=ctx.bits({'~envHelp':'false'})|ctx.bits({'~envHelp':'false'},True)
    return ctx.b.exists(ctx.b.conj(u,ctx.b.cube(bits)),bits)

def audit_equations(ctx):
    req(set(ctx.by_name) in (set(FIELDS),set(FIELDS+['~envHelp'])),'Exact Lift typed field roster')
    for n in FIELDS:
        f=ctx.by_name[n]; values=['S0','S1'] if n in AUX else ['false','true']
        req(f['values']==values and f['owner']==('ENV' if n in ENV else 'SYS') and f['role']==('AUX' if n in AUX else 'ENV' if n in ENV else 'SYS'),'Exact Lift owner/type: '+n)
    if '~envHelp' in ctx.by_name:
        f=ctx.by_name['~envHelp'];req(f['values']==['false','true'] and f['owner']==f['role']=='ENV','Native helper declaration')
    e=equations(ctx)
    for k in ('thetaE','thetaS','rhoE','rhoS'):req(cofactor(ctx,ctx.formulas[k])==e[k], 'Saved original/helper-false predicate differs from independent source: '+k)
    req(len(ctx.justices['SYS'])==3,'Source justice order/roster')
    for u,v in zip(ctx.justices['SYS'],e['justices']['SYS']):req(cofactor(ctx,u)==v,'Ordered source monitor justice mismatch')
    if '~envHelp' in ctx.by_name: req(len(ctx.justices['ENV'])==1 and cofactor(ctx,ctx.justices['ENV'][0])==1,'Released helper fairness projection')
    else:req(ctx.justices['ENV']==[],'Original source ENV justice roster')
    e['rhoE_old'] = ctx.b.conj(e['rhoE'], ctx.literal('b1', 'false'), ctx.literal('b1', 'false', True))
    req(ctx.b.conj(e['thetaE'], ctx.literal('b1', 'false')) == e['thetaE'], 'Old restriction changes original ENV initializer')
    ctx.source_equations=e
    return {'status':'PASS','method':'independent_symbolic_source_clause_identity','predicates':4,'ordered_SYS_justices':3,'source_ENV_justices':0,'helper_false_projection': '~envHelp' in ctx.by_name,'typed_original_state_count':1024,'source_initializers_unchanged':True}

def source_value(node): return {k:node['valuation'][k] for k in FIELDS}
def in_view(node): return node['valuation'].get('~envHelp','false')=='false'

def graph_decode(ctx,g,name,model_sha,printer=None):
    schemas={'native':'released-kind-complete-native-controller-v1','preference':'experimental-extractor-complete-controller-v1','normalized':'released-concrete-controller-export-v2'}
    req(g.get('schema')==schemas[name] and g.get('complete') is True,'Exact complete graph adapter')
    G.identity(g,ctx.profile)
    req(g.get('model_sha256')==model_sha,'Graph/model SHA binding')
    req(type(g.get('rank_domain_size')) is int and g['rank_domain_size']==3,'Source rank domain')
    if name=='normalized':
        req(g.get('pipeline')=='normalized_kind' and g.get('entry_mode')=='original_initializer' and g.get('initialization')==G.INIT,'Normalized graph original initialization')
        req(g.get('entry_valuation') is None and g.get('entry_bits') is None and g.get('replay_sha256') is None,'Normalized graph was rerooted')
    else:req(g.get('initialization')=='source_initializers','Native graph source initializer identity')
    req(isinstance(g.get('nodes'),list) and 0<len(g['nodes'])<=32768,'Node roster budget')
    nodes={}; identities=set();edges=[];texts=[]
    for n in g['nodes']:
        sid=n['id'];req(type(sid) is str and re.fullmatch(r'0|[1-9][0-9]*',sid) and sid not in nodes,'Unique native node ID')
        req(type(n['native_id']) is int and str(n['native_id'])==sid,'Native numeric ID')
        rank=n['rank'];req(type(rank) is int and 0<=rank<3 and n['rank_class']=='tau.smlab.syntech.games.gr1.GR1RankInfo' and n['rank_info']==f'System Justice {rank}','Actual native rank binding')
        req(type(n['initial']) is bool,'Original initial flag type')
        val=ctx.valuation(n['valuation'],'Raw node');req(G.bit_map(n['bits'],ctx.current,'Raw bits')==ctx.bits(val),'Raw node valuation/bits')
        key=(rank,tuple(val[k] for k in ctx.by_name));req(key not in identities,'Duplicate private memory/state identity');identities.add(key)
        succ=n['successors'];req(isinstance(succ,list) and all(type(t) is str for t in succ) and len(succ)==len(set(succ)),'Successor roster')
        edges.extend([[sid,t] for t in succ]);nodes[sid]=n
        if name!='normalized':
            txt='<'+', '.join(k+':'+val[k] for k in ctx.by_name)+'>'
            req(n.get('native_bdd_text')==txt,'Native BDD printer node text')
            texts.extend([('Initial State ' if n['initial'] else 'State ')+sid+' '+txt,'\tWith successors : '+', '.join(succ)])
    req(len(edges)<=1000000 and all(t in nodes for _,t in edges),'Edge budget/dangling target')
    req(g['edges']==edges,'Exact full raw edge/successor vectors')
    if name=='normalized':req(g['api_state_order']==list(nodes),'Normalized raw API state vector')
    elif 'api_state_order' in g:req(g['api_state_order']==list(nodes),'Optional native API state vector')
    req(type(g['api_state_count']) is int and g['api_state_count']==len(nodes) and type(g['api_transition_count']) is int and g['api_transition_count']==len(edges),'API counts')
    if name=='normalized':req(g.get('exported_edge_count')==len(edges),'Exported edge count')
    elif printer is not None:req(printer==('\n'.join(texts)+'\n').encode(),'Native printer/raw graph correspondence')
    else:req(False,'Missing native printer')
    return nodes

def exact_state(value):
    req(isinstance(value,dict) and set(value)==set(FIELDS),'Complete ten-field source/AUX snapshot')
    req(all(value[k] in (['S0','S1'] if k in AUX else ['false','true']) and type(value[k]) is str for k in FIELDS),'Snapshot type/domain')

def check_root_binding(nodes,root,rank,state):
    exact_state(state);req(type(root) is str and root in nodes,'Explicit root absent')
    n=nodes[root];req(type(rank) is int and n['rank']==rank,'Explicit root actual private rank differs')
    req(source_value(n)==state and in_view(n),'Explicit root source/AUX/helper binding differs')
    return n

def closure_certificate(ctx,nodes,starts,old):
    req(starts and len(starts)==len(set(starts)) and all(s in nodes and in_view(nodes[s]) for s in starts),'Root roster')
    req(all(not old or nodes[s]['valuation']['b1']=='false' for s in starts),'Old root violates b1 guard')
    effective_env = ctx.source_equations['rhoE_old' if old else 'rhoE']
    seen=set(starts);queue=deque(starts);edges=[];ignored=0
    while queue:
        sid=queue.popleft()
        for t in nodes[sid]['successors']:
            if not in_view(nodes[t]):
                ignored+=1;continue
            if not ctx.b.evaluate(effective_env,ctx.bits(source_value(nodes[sid]))|ctx.bits(source_value(nodes[t]),True)):
                ignored+=1;continue
            edges.append([sid,t])
            if t not in seen:seen.add(t);queue.append(t)
    by_source=defaultdict(list)
    for s,t in edges:by_source[s].append(t)
    env_inputs=list(product(['false','true'],repeat=4));failures=[];checks=0
    e=ctx.source_equations;counts={}
    for sid in sorted(seen,key=int):
        cur=source_value(nodes[sid]);cb=ctx.bits(cur)
        legal=set()
        for xs in env_inputs:
            w=dict(zip(ENV,xs)); checks+=1
            if ctx.b.evaluate(effective_env,cb|ctx.bits(w,True)):legal.add(xs)
        counts[sid]=len(legal);responses=defaultdict(list)
        for t in by_source[sid]:
            val=source_value(nodes[t]);xs=tuple(val[k] for k in ENV);responses[xs].append(t)
            if not ctx.b.evaluate(e['rhoS'],cb|ctx.bits(val,True)):failures.append({'kind':'SOURCE_SYS_SAFETY','source':sid,'target':t})
        for kind,bad in [('MISSING_LEGAL_INPUT',legal-set(responses)),('ILLEGAL_ENV_EDGE',set(responses)-legal)]:
            if bad:failures.append({'kind':kind,'source':sid,'inputs':[dict(zip(ENV,x)) for x in sorted(bad)]})
        for xs,ts in responses.items():
            if len(ts)!=1:failures.append({'kind':'RESPONSE_PRIVATE_MEMORY_NONDETERMINISM','source':sid,'input':dict(zip(ENV,xs)),'targets':ts})
    graph={'states':sorted(seen,key=int),'starts':starts,'edges':edges,'env_justice':[],
           'sys_justice':[[s for s in sorted(seen,key=int) if ctx.b.evaluate(u,ctx.bits(source_value(nodes[s])))] for u in e['justices']['SYS']]}
    coverage=not any(x['kind']!='SOURCE_SYS_SAFETY' for x in failures);safety=not any(x['kind']=='SOURCE_SYS_SAFETY' for x in failures)
    base={'complete':coverage,'source_coverage':coverage,'source_safety':safety,'strict':False if coverage and not safety else None,'cooperative':None,'ignored_non_original_or_mode_edges':ignored,'reachable_node_count':len(seen),'edge_count':len(edges),'all_legal_input_enumeration_count':checks,'legal_input_count':sum(counts.values()),'starts':starts,'reachable_nodes':graph['states'],'defects':failures,'graph':graph,'source_initializers_reapplied':False,'old_ENV_restriction_applied':old}
    if not failures:
        fair=G.graph_analyzer()(graph);base.update(strict=fair['strict_liveness']['pass'],cooperative=fair['nonconflicting']['pass'],fairness=fair)
    return base

def initial_roots(ctx,nodes):
    starts=[s for s,n in nodes.items() if n['initial'] and in_view(n)]
    req(starts,'No original initial states');actual=[];e=ctx.source_equations
    for s in starts:
        n=nodes[s];v=source_value(n);req(n['rank']==0 and ctx.b.evaluate(e['thetaE'],ctx.bits(v)) and ctx.b.evaluate(e['thetaS'],ctx.bits(v)),'Original initial state/rank violation')
        actual.append(tuple(v[k] for k in ENV))
    expected={xs for xs in product(['false','true'],repeat=4) if ctx.b.evaluate(e['thetaE'],ctx.bits(dict(zip(ENV,xs))))}
    req(len(actual)==len(set(actual)) and set(actual)==expected,'All original initial ENV choices covered exactly once')
    return starts

def validate_old_mode(plan):
    o=plan['old_mode'];req(o.get('disabled_ENV')=='b1' and o.get('current_value')=='false' and o.get('next_value')=='false' and o.get('source_initializers_preserved') is True,'Old mode is not exact frozen G !b1')

def load_graphs(plan,inputs):
    source=inputs.load(plan['source']);req(plan['source']['sha256']==SOURCE_SHA,'Unsupported source bytes')
    req(set(plan['graphs'])=={'native','normalized','preference'},'Fixed graph roster')
    loaded={};reports={}
    for name,ref in plan['graphs'].items():
        gp=inputs.load(ref);mp=inputs.load(ref['model']);m=G.read_json(mp)
        model_source=inputs.load(m['input']);req(m['input']['sha256']==plan['source']['sha256'] and m['input']['bytes']==plan['source']['bytes'] and model_source.read_bytes()==source.read_bytes(),'Exact common source bytes for model provenance')
        profile={k:m[k] for k in ('fixture_id','case_id','variant')};profile['source']=m['input']
        ctx=G.Context(mp.parent,profile,m);model_report=ctx.audit_model();eq=audit_equations(ctx)
        for field in ('original_bdds','original_justices'):
            def record(v):
                if isinstance(v,dict) and {'file','bytes','sha256'}<=set(v):inputs.load({'path':str(mp.parent/v['file']),'bytes':v['bytes'],'sha256':v['sha256']})
                elif isinstance(v,dict):
                    for x in v.values():record(x)
                elif isinstance(v,list):
                    for x in v:record(x)
            record(m[field])
        g=G.read_json(gp);printer=inputs.load(ref['printer']).read_bytes() if ref.get('printer') else None
        nodes=graph_decode(ctx,g,name,ref['model']['sha256'],printer)
        if ref.get('result'):inputs.load(ref['result'])
        inputs.walk(ref.get('source_correspondence',[]));inputs.walk(ref.get('model_predicates',[]))
        loaded[name]=(ctx,nodes);reports[name]={'model':ref['model'],'controller':{k:ref[k] for k in ('path','bytes','sha256')},'typed_model':model_report,'source_equations':eq,'raw_nodes':len(nodes),'raw_edges':sum(len(n['successors']) for n in nodes.values())}
    return loaded,reports

def boundary_rows(plan):
    rows=plan['boundaries'];req(isinstance(rows,list) and len(rows)==3 and len({r['id'] for r in rows})==3 and [r['reached_native_node'] for r in rows]==['524','526','756'],'Fixed three-private-state pending boundary census')
    for row in rows:exact_state(row['source_state'])
    return rows

def boundary_bindings(plan,loaded,old):
    ctx,nodes=loaded['native'];rows=boundary_rows(plan);got=[]
    reach=set(old['starts']);todo=list(old['starts']);adj=defaultdict(list)
    for a,b in old['graph']['edges']:adj[a].append(b)
    while todo:
        for t in adj[todo.pop()]:
            if t not in reach:reach.add(t);todo.append(t)
    expected={s for s in reach if nodes[s]['valuation']['c']=='false' and any(nodes[s]['valuation'][n]=='S1' and nodes[s]['valuation'][f]=='false' for n,f in zip(AUX,SYS))}
    for row in rows:
        root=row['reached_native_node'];rank=row['reached_rank'];state=row['source_state']
        check_root_binding(nodes,root,rank,state);req(root in old['reachable_nodes'],'Boundary outside old closure');got.append(root)
        req(state['c']=='false' and any(state[n]=='S1' and state[f]=='false' for n,f in zip(AUX,SYS)) and nodes[root]['initial'] is False,'Boundary must be noninitial with genuinely unanswered monitor')
        prefix=row['prefix_node_ids'];req(isinstance(prefix,list) and prefix and prefix[0]=='0' and prefix[0] in old['starts'] and prefix[-1]==root,'Old prefix endpoints')
        req(len(prefix)==3 and row['prefix_input_bits']==[''.join('1' if nodes[t]['valuation'][k]=='true' else '0' for k in ENV) for t in prefix[1:]],'Frozen prefix offered inputs')
        for u,v in zip(prefix,prefix[1:]):
            req([u,v] in old['graph']['edges'],'Old prefix is not an actual legal saved edge')
            req(ctx.b.evaluate(ctx.source_equations['rhoS'],ctx.bits(source_value(nodes[u]))|ctx.bits(source_value(nodes[v]),True)),'Old prefix violates source SYS/AUX')
        rootlist=row['candidates'];req(isinstance(rootlist,list) and [r['candidate'] for r in rootlist]==list(ARM_GRAPHS),'Fixed three candidate records/order');roots={r['candidate']:r for r in rootlist}
        for arm,gn in ARM_GRAPHS.items():
            rr=roots[arm];req(rr['graph']==gn,'Candidate graph identity');target=rr['root'];r=rr['rank']
            check_root_binding(loaded[gn][1],target,r,state)
            req(arm!='retain_old_native' or (target==root and r==rank),'Retained-old private memory policy')
    req(len(got)==len(set(got)) and set(got)==expected,'Frozen roster differs from complete reachable genuinely-pending private census')
    return rows


def run(plan_path,mode):
    inputs=Inputs();pp=pin(plan_path);plan=inputs.json(pp)
    for name,digest in VENDOR.items():req(G.sha(Path(__file__).parent/name)==digest,'Vendored checker drift')
    req(plan.get('schema')=='v58-pending-handoff-plan-v1','Plan schema');req(mode in ('old_gate','candidate_roots'),'Unknown mode');validate_old_mode(plan)
    roster=inputs.json(plan['roster']);req(roster['boundaries']==plan['boundaries'],'Inline/frozen roster equality')
    input_manifest=inputs.json(plan['inputs']);inputs.walk(input_manifest)
    new_source=inputs.load(plan['source']).read_bytes();old_source=inputs.load(plan['old_source']).read_bytes()
    req(old_source==new_source+b'\n\nassumption -- constructed_old_mode_no_b1\n\talw(b1=false);\n','Old source differs beyond exact appended G !b1')
    inputs.walk(plan.get('source_correspondence',[]))
    loaded,models=load_graphs(plan,inputs);ctx,nodes=loaded['native']
    old=closure_certificate(ctx,nodes,initial_roots(ctx,nodes),True)
    rows=boundary_bindings(plan,loaded,old)
    result={'schema':'v58-pending-rooted-graph-certificate-bundle-v1','route':'saved_model','status':('COMPLETE_OLD_GATE' if old['complete'] else 'UNKNOWN_INCOMPLETE_OLD_GATE') if mode=='old_gate' else 'COMPLETE_ROOTED_CANDIDATES','mode':mode,'plan':pp,'checker':pin(__file__),'old_gate':old,'boundaries':[],'models':models,'limitations':['Immutable existing graphs are re-rooted; no new native synthesis/extraction.','Source/AUX values are preserved while saved alternatives initialize their exact certified stored root and rank.','No proof of arbitrary old private-memory transport.'],'no_native_solver_or_compiler':True}
    if mode=='candidate_roots':
        ap=Path(plan['old_gate_adoption_path']);adoption=inputs.json(pin(ap));req(adoption.get('status')=='ADOPTED_BOTH_OLD_GATE_CERTIFICATES' and adoption.get('plan')==pp,'Old gate adoption/plan binding')
        prior_path=Path(plan['old_gate_saved_result_path']);prior=inputs.json(pin(prior_path))
        req(prior.get('schema')==result['schema'] and prior.get('route')=='saved_model' and prior.get('plan')==pp and prior.get('status')=='COMPLETE_OLD_GATE','Prior own old gate binding')
        req(prior['old_gate']==old and all(old[k] is True for k in ('complete','strict','cooperative','source_coverage','source_safety')),'Old gate not passed or changed')
        def contains_ref(value,ref):
            if isinstance(value,dict):return (value.get('sha256')==ref['sha256'] and value.get('bytes')==ref['bytes']) or any(contains_ref(v,ref) for v in value.values())
            return isinstance(value,list) and any(contains_ref(v,ref) for v in value)
        req(contains_ref(adoption,pin(prior_path)),'Adoption lacks own old-gate certificate pin')
        inputs.walk(adoption);result['old_gate_adoption']=pin(ap);result['prior_old_gate_result']=pin(prior_path)
        source_prior_path=Path(plan['old_gate_source_result_path']);source_prior=inputs.json(pin(source_prior_path))
        req(source_prior.get('schema')==result['schema'] and source_prior.get('route')=='source' and source_prior.get('plan')==pp and source_prior.get('status')=='COMPLETE_OLD_GATE','Prior independent source old gate binding')
        req(all(source_prior['old_gate'][k] is True for k in ('complete','strict','cooperative','source_coverage','source_safety')),'Independent source old gate did not pass')
        req(contains_ref(adoption,pin(source_prior_path)),'Adoption lacks independent source old-gate certificate pin')
        req(adoption.get('certificates')=={'source':pin(source_prior_path),'saved_model':pin(prior_path)},'Adoption must bind exact old certificate pair')
        sg=source_prior['old_gate']
        req(sorted(sg['roots'],key=int)==sorted(old['starts'],key=int) and len(old['starts'])==2
            and sg['reachable_nodes']==old['reachable_nodes'] and sg['reachable_state_count']==old['reachable_node_count']
            and sg['reachable_edge_count']==old['edge_count']
            and sg['derived_edges_sha256']==G.sha_bytes(json.dumps(sorted(old['graph']['edges']),sort_keys=True,separators=(',',':')).encode()),'Old complete closure pair differs')
        qualification=inputs.json(pin(plan['interface_qualification_result_path']))
        req(qualification.get('status')=='PASS_INTERFACE_QUALIFICATION' and qualification.get('plan')==pp
            and qualification.get('checks') and all(c.get('pass_') is True for c in qualification['checks'])
            and pin(__file__) in qualification.get('code',[]),'Interface qualification missing, failed, or stale')
        inputs.walk(qualification)
        result['prior_source_old_gate_result']=pin(source_prior_path)
        for row in rows:
            out={'id':row['id'],'source_state':row['source_state'],'reached_native_node':row['reached_native_node'],'reached_rank':row['reached_rank'],'candidates':[]}
            for arm,gn in ARM_GRAPHS.items():
                rr=next(r for r in row['candidates'] if r['candidate']==arm);c,n=loaded[gn];cert=closure_certificate(c,n,[rr['root']],False)
                cert.update(candidate=arm,graph_sha256=plan['graphs'][gn]['sha256'],root_id=rr['root'],rank=rr['rank'],root_original_initial_flag=n[rr['root']]['initial'])
                out['candidates'].append(cert)
            result['boundaries'].append(out)
    if mode=='candidate_roots' and not all(c['complete'] for row in result['boundaries'] for c in row['candidates']):result['status']='UNKNOWN_INCOMPLETE_ROOTED_CANDIDATES'
    inputs.recheck();result['verified_input_pins']=list(inputs.seen.values());return result

def main(argv):
    if len(argv)!=3:raise SystemExit('usage: check_roots.py PLAN.json old_gate|candidate_roots OUTPUT.json')
    plan,mode,out=Path(argv[0]),argv[1],Path(argv[2]);req(not out.exists(),'Refuse output overwrite')
    try:result=run(plan,mode)
    except IntegrityError as exc:result={'schema':'v58-pending-rooted-graph-certificate-bundle-v1','route':'saved_model','status':'UNKNOWN_INTEGRITY','error':str(exc),'mode':mode,'plan':pin(plan),'old_gate':None,'boundaries':[]}
    except G.ResourceRefusal as exc:result={'schema':'v58-pending-rooted-graph-certificate-bundle-v1','route':'saved_model','status':'UNKNOWN_RESOURCE','error':str(exc),'mode':mode,'plan':pin(plan),'old_gate':None,'boundaries':[]}
    except (G.Invalid,KeyError,TypeError,ValueError,OSError) as exc:result={'schema':'v58-pending-rooted-graph-certificate-bundle-v1','route':'saved_model','status':'UNKNOWN_MODEL_BINDING','error':str(exc),'mode':mode,'plan':pin(plan),'old_gate':None,'boundaries':[]}
    out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':result['status'],'output':str(out.resolve())}))
    return 0 if result['status'].startswith('COMPLETE_') else 2

if __name__=='__main__':raise SystemExit(main(sys.argv[1:]))
