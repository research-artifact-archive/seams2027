"""Root-owned saved-result adoption. No new graph, BDD, or runtime evaluations."""
import sys
from pathlib import Path
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from control_common import gate_pair, save_new


def main():
    if len(sys.argv) != 2:
        raise SystemExit('Usage: adopt_old_gate.py PLAN.json')
    plan, pp, certs, summary = gate_pair(sys.argv[1])
    value = dict(status='ADOPTED_BOTH_OLD_GATE_CERTIFICATES', execution_owner='/root',
                 plan=pp, certificates=certs, full_closure_agreement=summary,
                 scope='Both actual b1 old-mode certificates passed; no prediction adopted as an outcome.')
    save_new(plan['old_gate_adoption_path'], value)
    print(value['status'])


if __name__ == '__main__':
    main()
