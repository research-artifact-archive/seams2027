"""File binding and saved-certificate reconciliation only; no scientific imports."""
import hashlib
import json
from pathlib import Path


def need(value, message):
    if not value:
        raise ValueError(message)


def pin(path):
    path = Path(path).resolve()
    need(path.is_file() and not path.is_symlink(), 'Regular input required')
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def load(ref):
    need(pin(ref['path']) == {k: ref[k] for k in ('path', 'bytes', 'sha256')}, 'Current file pin differs')
    return json.loads(Path(ref['path']).read_text())


def refs(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= set(value):
            yield {k: value[k] for k in ('path', 'bytes', 'sha256')}
        for v in value.values():
            yield from refs(v)
    elif isinstance(value, list):
        for v in value:
            yield from refs(v)


def recheck(value):
    for ref in refs(value):
        need(pin(ref['path']) == ref, 'Pinned input changed: ' + ref['path'])


def gate_pair(plan_path):
    pp = pin(plan_path)
    plan = load(pp)
    recheck(plan)
    cert_refs = {'source': pin(plan['old_gate_source_result_path']),
                 'saved_model': pin(plan['old_gate_saved_result_path'])}
    bundles = {route: load(ref) for route, ref in cert_refs.items()}
    for route, b in bundles.items():
        need(b.get('schema') == 'v58-pending-rooted-graph-certificate-bundle-v1'
             and b.get('status') == 'COMPLETE_OLD_GATE' and b.get('route') == route
             and b.get('plan') == pp, 'Old gate identity/status/plan differs')
        need(all(b['old_gate'].get(k) is True for k in
                 ('complete', 'source_coverage', 'source_safety', 'strict', 'cooperative')),
             'Old eligibility is false or UNKNOWN; stop this study')
    a, b = bundles['source']['old_gate'], bundles['saved_model']['old_gate']
    need(sorted(a['roots'], key=int) == sorted(b['starts'], key=int) and len(a['roots']) == 2,
         'Both original initial choices must agree')
    need({v['source_state']['c'] for v in a['initial_bindings']} == {'false', 'true'}
         and all(v['source_initializer_compatible'] is True for v in a['initial_bindings']),
         'Original initializer coverage differs')
    need(a['reachable_nodes'] == b['reachable_nodes'] and a['reachable_state_count'] == b['reachable_node_count']
         and a['reachable_edge_count'] == b['edge_count'], 'Old closure differs between routes')
    edge_hash = hashlib.sha256(json.dumps(sorted(b['graph']['edges']), sort_keys=True,
                                         separators=(',', ':')).encode()).hexdigest()
    need(a['derived_edges_sha256'] == edge_hash, 'Old complete edge relation differs')
    need(a['cohort_validation']['genuinely_pending_private_nodes'] == ['524', '526', '756']
         and a['cohort_validation']['initial_roots'] == sorted(a['roots'], key=int),
         'Genuine-pending census or all-initial scope differs')
    recheck({'plan': pp, 'certificates': cert_refs})
    return plan, pp, cert_refs, dict(initial_roots=a['roots'],
        reachable_nodes=a['reachable_state_count'], reachable_edges=a['reachable_edge_count'],
        closure_sha256=edge_hash, genuinely_pending_nodes=['524', '526', '756'])


def adopted_old(plan_path):
    plan, pp, certs, summary = gate_pair(plan_path)
    adoption_ref = pin(plan['old_gate_adoption_path'])
    adoption = load(adoption_ref)
    need(adoption.get('status') == 'ADOPTED_BOTH_OLD_GATE_CERTIFICATES'
         and adoption.get('plan') == pp and adoption.get('certificates') == certs,
         'Root old-gate adoption is absent or stale')
    return plan, pp, certs, summary


def save_new(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

