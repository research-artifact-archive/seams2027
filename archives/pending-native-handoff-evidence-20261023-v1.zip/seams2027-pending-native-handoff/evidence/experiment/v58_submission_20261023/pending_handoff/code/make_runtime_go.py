"""Root-owned JSON binding after reading both complete candidate certificates.

This tool does not evaluate source equations, BDDs, graph fairness or runtime.
"""
import sys
from pathlib import Path
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from control_common import adopted_old, load, need, pin, recheck, save_new, refs


def main():
    need(len(sys.argv) == 7,
         'Usage: make_runtime_go.py PLAN.json INDEPENDENT_REVIEW.json INTERFACE_QUALIFICATION.json SOURCE_CANDIDATES.json SAVED_CANDIDATES.json NEW_GO.json')
    plan_path, review_path, qualification_path, source_path, saved_path, output = sys.argv[1:]
    plan, pp, old_certs, summary = adopted_old(plan_path)
    runtime = pin(Path(__file__).parent / 'runtime/run_handoff.py')
    review_ref, qualification_ref = pin(review_path), pin(qualification_path)
    review, qualification = load(review_ref), load(qualification_ref)
    need(str(review.get('status', '')).startswith('PASS'), 'Independent static review failed')
    review_pins = list(refs(review))
    need(pp in review_pins and runtime in review_pins, 'Static review does not bind exact plan/runtime')
    need(qualification.get('status') == 'PASS_INTERFACE_QUALIFICATION'
         and qualification.get('plan') == pp and qualification.get('checks')
         and all(c.get('pass_') is True for c in qualification['checks'])
         and runtime in list(refs(qualification)), 'Interface qualification failed or stale')
    cert_refs = dict(source=pin(source_path), saved_model=pin(saved_path))
    certs = {route: load(ref) for route, ref in cert_refs.items()}
    keys = ('candidate', 'graph_sha256', 'root_id', 'rank', 'complete', 'strict', 'cooperative', 'source_coverage')
    for route, bundle in certs.items():
        need(bundle.get('schema') == 'v58-pending-rooted-graph-certificate-bundle-v1'
             and bundle.get('route') == route and bundle.get('status') == 'COMPLETE_ROOTED_CANDIDATES'
             and bundle.get('plan') == pp, 'Candidate certificate identity differs')
        need(all(bundle['old_gate'].get(k) is True for k in ('complete', 'source_safety', 'source_coverage', 'strict', 'cooperative')),
             'Candidate bundle lost old eligibility gate')
        need([r['id'] for r in bundle['boundaries']] == [r['id'] for r in plan['boundaries']], 'Candidate boundary roster differs')
        for row, actual in zip(plan['boundaries'], bundle['boundaries']):
            need(all(row[k] == actual[k] for k in ('id', 'source_state', 'reached_native_node', 'reached_rank')),
                 'Candidate source/AUX/reached root differs')
            need([c['candidate'] for c in actual['candidates']] == plan['candidate_order'], 'Candidate order differs')
            for bound, cert in zip(row['candidates'], actual['candidates']):
                need(type(cert.get('rank')) is int and cert['rank'] == bound['rank']
                     and cert['root_id'] == bound['root'] and cert['graph_sha256'] == plan['graphs'][bound['graph']]['sha256'],
                     'Certified exact root/rank/graph differs')
                need(all(type(cert.get(k)) is bool for k in ('complete', 'strict', 'cooperative', 'source_coverage'))
                     and cert['complete'] and cert['source_coverage'], 'Candidate incomplete/UNKNOWN')
    for left, right in zip(certs['source']['boundaries'], certs['saved_model']['boundaries']):
        for a, b in zip(left['candidates'], right['candidates']):
            need({k: a[k] for k in keys} == {k: b[k] for k in keys}, 'Candidate route disagreement')
    value = dict(status='GO_EXACT_FROZEN_HANDOFF_RUNTIME', execution_owner='/root', plan=pp,
                 runtime_script=runtime, independent_runtime_review=review_ref,
                 interface_qualification=qualification_ref, certificates=cert_refs,
                 old_gate_certificates=old_certs, old_gate_summary=summary,
                 expected_episodes=6, candidate_roots=9, single_worker=True,
                 arbitrary_wall_stop=None, native_or_compiler_calls=0, full_reset_uses=0,
                 scope='Root-owned binding of actual reviewed outputs. A complete cooperative=false candidate remains a normal routing outcome.')
    recheck(value)
    save_new(output, value)
    print(value['status'])


if __name__ == '__main__':
    main()
