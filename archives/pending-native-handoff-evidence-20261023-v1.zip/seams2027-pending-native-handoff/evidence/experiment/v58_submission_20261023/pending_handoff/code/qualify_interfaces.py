"""Root-run focused qualification; never runs a study episode or complete checker.

Positive installation fixtures seed a paused boundary explicitly. They are
synthetic interface tests, not executed old prefixes or scientific outcomes.
The real old gate must already have passed by both routes.
"""
import copy
import importlib.util
import io
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from control_common import adopted_old, need, pin, recheck, save_new


def module(name, relative):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).parent / relative)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


def main():
    need(len(sys.argv) == 3, 'Usage: qualify_interfaces.py PLAN.json FRESH_RESULT.json')
    plan_path, output = sys.argv[1:]
    need(not Path(output).exists(), 'Fresh qualification result required')
    plan, pp, old_certs, old_summary = adopted_old(plan_path)
    R = module('pending_runtime_qualification', 'runtime/run_handoff.py')
    S = module('pending_source_qualification', 'source_route/check_source_roots.py')
    B = module('pending_saved_qualification', 'saved_route/check_roots.py')
    raw_graphs = {n: json.loads(Path(r['path']).read_text()) for n, r in plan['graphs'].items()}
    graphs = {n: R.SavedGraph(n, plan['graphs'][n], d) for n, d in raw_graphs.items()}
    source_graphs = {n: S.load_graph(r) for n, r in plan['graphs'].items()}
    saved_nodes = {n: {x['id']: x for x in d['nodes']} for n, d in raw_graphs.items()}
    roster = R.normalized_roster(json.loads(Path(plan['roster']['path']).read_text()), graphs)
    rows = R.validate_roster(roster, graphs)
    checks = []
    keepalive = []
    rejection_types = (R.Refusal, S.AuditError, B.G.Invalid, B.IntegrityError)

    def positive(label, action):
        try:
            action()
            checks.append(dict(name=label, pass_=True))
        except Exception as exc:
            checks.append(dict(name=label, pass_=False, error=type(exc).__name__ + ': ' + str(exc)))

    def negative(label, action):
        try:
            action()
        except rejection_types as exc:
            checks.append(dict(name=label, pass_=True, rejected_by=type(exc).__name__, reason=str(exc)))
        except Exception as exc:
            checks.append(dict(name=label, pass_=False, unexpected_error=type(exc).__name__ + ': ' + str(exc)))
        else:
            checks.append(dict(name=label, pass_=False, error='Mutation was accepted'))

    def fixture(row):
        log = R.EventLog(io.StringIO())
        rt = R.Runtime('SYNTHETIC_QUALIFICATION', row['id'], 'strict_and_cooperative', graphs['native'], log)
        # Deliberate fixture setup, NOT a claim that the two old commits ran.
        rt.state.update(row['source_state'])
        rt.old_controller.node_id = row['reached_native_node']
        rt.ticks = 2
        rt.mode, rt.epoch, rt.paused = 'normal', 1, True
        keepalive.append(rt)
        return rt

    def install(row, binding):
        rt = fixture(row)
        before = dict(rt.state)
        candidate = rt.old_controller if binding['candidate'] == 'retain_old_native' else R.GraphController(
            graphs[R.CANDIDATE_GRAPH[binding['candidate']]], binding['root_id'], rt.state, binding['rank'])
        rt.install(candidate, binding, {'fixture': 'SYNTHETIC_NOT_A_CERTIFICATE'})
        need(rt.state == before and rt.state[R.AUX[2]] == 'S1' and rt.state['f3'] == 'false', 'Pending obligation reset')
        need(rt.controller.memory()['rank'] == binding['rank'] and id(rt.state) == rt.state_identity,
             'Stored rank or source object changed')

    for row in rows:
        for c in row['candidates']:
            graph_name = R.CANDIDATE_GRAPH[c['candidate']]
            def binding_check(row=row, c=c, graph_name=graph_name):
                R.GraphController(graphs[graph_name], c['root_id'], row['source_state'], c['rank'])
                S.root_binding(source_graphs[graph_name], c['root_id'], c['rank'], row['source_state'])
                B.check_root_binding(saved_nodes[graph_name], c['root_id'], c['rank'], row['source_state'])
            positive(row['id'] + '/' + c['candidate'] + '/exact_three_route_root', binding_check)
            positive(row['id'] + '/' + c['candidate'] + '/synthetic_stored_rank_install',
                     lambda row=row, c=c: install(row, c))
    row, c = rows[0], rows[0]['candidates'][1]
    wrong_rank = (c['rank'] + 1) % 3
    negative('runtime_wrong_actual_rank', lambda: R.GraphController(graphs['normalized'], c['root_id'], row['source_state'], wrong_rank))
    negative('source_wrong_actual_rank', lambda: S.root_binding(source_graphs['normalized'], c['root_id'], wrong_rank, row['source_state']))
    negative('saved_wrong_actual_rank', lambda: B.check_root_binding(saved_nodes['normalized'], c['root_id'], wrong_rank, row['source_state']))
    for value in (True, 1.0):
        negative('runtime_noninteger_actual_rank_' + type(value).__name__,
                 lambda value=value: R.GraphController(graphs['normalized'], c['root_id'], row['source_state'], value))
    changed = dict(row['source_state']); changed[R.AUX[2]] = 'S0'
    negative('lost_pending_monitor', lambda: R.GraphController(graphs['normalized'], c['root_id'], changed, c['rank']))
    swapped = dict(row['source_state']); swapped[R.AUX[0]], swapped[R.AUX[2]] = swapped[R.AUX[2]], swapped[R.AUX[0]]
    negative('swapped_monitor', lambda: S.root_binding(source_graphs['normalized'], c['root_id'], c['rank'], swapped))
    negative('wrong_source_root', lambda: R.GraphController(graphs['normalized'], '0', row['source_state'], 0))
    helper = next(n for n in raw_graphs['native']['nodes'] if n['valuation']['~envHelp'] == 'true')
    negative('helper_true_root', lambda: R.GraphController(graphs['native'], helper['id'], graphs['native'].source(helper['id']), helper['rank']))

    def bad_install(kind):
        rt = fixture(row)
        candidate = R.GraphController(graphs['normalized'], c['root_id'], rt.state, c['rank'])
        binding = dict(c)
        if kind == 'rank': binding['rank'] = wrong_rank
        if kind == 'root': binding['root_id'] = '0'
        if kind == 'pending': rt.state[R.AUX[2]] = 'S0'
        if kind == 'mode': rt.mode = 'old_no_b1'
        if kind == 'object': rt.state = dict(rt.state)
        rt.install(candidate, binding, {'fixture': 'SYNTHETIC_NOT_A_CERTIFICATE'})
    for kind in ('rank', 'root', 'pending', 'mode', 'object'):
        negative('installation_' + kind + '_mutation', lambda kind=kind: bad_install(kind))
    negative('unknown_old_b3_mode', lambda: R.env_legal(row['source_state'], R.FIXED_INPUTS[0], 'old_no_b3'))
    bad_plan = copy.deepcopy(plan); bad_plan['old_mode']['disabled_ENV'] = 'b3'
    negative('source_old_mode_b3_substitution', lambda: S.validate_mode(bad_plan))
    negative('saved_old_mode_b3_substitution', lambda: B.validate_old_mode(bad_plan))

    def mode_truth_table():
        for row in rows:
            for current_b1 in ('false', 'true'):
                state = dict(row['source_state'], b1=current_b1)
                for offered in R.INPUTS:
                    expected = S.C.rho_e(state, offered) and current_b1 == offered['b1'] == 'false'
                    need(R.env_legal(state, offered, 'old_no_b1') == expected == S.env_legal(state, offered, True),
                         'Current/next b1 restriction disagrees')
            need(not R.env_legal(row['source_state'], R.FIXED_INPUTS[0], 'old_no_b1')
                 and R.env_legal(row['source_state'], R.FIXED_INPUTS[0], 'normal'), 'New b1 input gate')
        dropped_b3 = dict(R.FIXED_INPUTS[0], b3='false')
        need(not R.env_legal(rows[0]['source_state'], dropped_b3, 'normal'), 'Unanswered b3 persistence was lost')
    positive('b1_current_next_all_96_boundary_inputs_and_pending_b3', mode_truth_table)
    negative('paused_step', lambda: fixture(row).step(R.FIXED_INPUTS[0], 'qualification'))
    bad_roster = copy.deepcopy(roster)
    bad_roster['boundaries'][0]['post_update_inputs'][0]['b1'] = 'false'
    negative('changed_frozen_input_script', lambda: R.validate_roster(bad_roster, graphs))

    def missing_response():
        data = copy.deepcopy(raw_graphs['normalized'])
        node = next(n for n in data['nodes'] if n['id'] == c['root_id'])
        offered = R.FIXED_INPUTS[0]
        target = next(t for t in node['successors'] if all(saved_nodes['normalized'][t]['valuation'][k] == offered[k] for k in R.ENV))
        node['successors'].remove(target)
        data['edges'].remove([node['id'], target])
        graph = R.SavedGraph('normalized', plan['graphs']['normalized'], data)
        R.GraphController(graph, c['root_id'], row['source_state'], c['rank']).propose(row['source_state'], offered)
    negative('missing_required_response', missing_response)

    def certificates():
        out = {}
        for route in ('source', 'saved_model'):
            bundle = dict(schema='v58-pending-rooted-graph-certificate-bundle-v1', route=route,
                          status='COMPLETE_ROOTED_CANDIDATES', plan=pp,
                          old_gate=dict(complete=True, source_coverage=True, strict=True, cooperative=True), boundaries=[])
            for row in rows:
                candidates = [dict(c, complete=True, source_coverage=True, strict=True,
                                   cooperative=c['candidate'] != 'retain_old_native') for c in row['candidates']]
                bundle['boundaries'].append({k: row[k] for k in ('id', 'source_state', 'reached_native_node', 'reached_rank')} | {'candidates': candidates})
            out[route] = bundle
        return out
    def check_certificates(kind=None):
        value = certificates()
        if kind == 'stale_plan': value['source']['plan'] = dict(pp, sha256='0' * 64)
        if kind == 'wrong_root': value['source']['boundaries'][0]['candidates'][1]['root_id'] = '0'
        if kind == 'wrong_rank': value['source']['boundaries'][0]['candidates'][1]['rank'] = 0
        if kind == 'bool_rank': value['source']['boundaries'][0]['candidates'][1]['rank'] = True
        if kind == 'float_rank': value['source']['boundaries'][0]['candidates'][1]['rank'] = 1.0
        if kind == 'integer_verdict': value['source']['boundaries'][0]['candidates'][0]['strict'] = 1
        if kind == 'incomplete': value['source']['boundaries'][0]['candidates'][0]['complete'] = False
        if kind == 'disagreement': value['source']['boundaries'][0]['candidates'][0]['cooperative'] = True
        R.agreeing_certificates(value['source'], value['saved_model'], rows, graphs, pp)
    positive('cooperative_false_is_valid_candidate_routing_result', check_certificates)
    for kind in ('stale_plan', 'wrong_root', 'wrong_rank', 'bool_rank', 'float_rank', 'integer_verdict', 'incomplete', 'disagreement'):
        negative('certificate_' + kind, lambda kind=kind: check_certificates(kind))
    recheck(plan)
    recheck({'plan': pp, 'old_certificates': old_certs})
    result = dict(status='PASS_INTERFACE_QUALIFICATION' if all(c['pass_'] for c in checks) else 'FAIL_INTERFACE_QUALIFICATION',
                  plan=pp, script=pin(__file__), old_certificates=old_certs, old_gate_summary=old_summary,
                  checks=checks, actual_stored_root_binding_checks=9, synthetic_installation_checks=9,
                  scientific_episodes=0, complete_checker_invocations=0, native_solver_or_compiler_calls=0,
                  note='Synthetic paused fixtures are deliberately seeded. No qualification fixture is reported as an executed old prefix or an admitted real controller.',
                  code=[pin(Path(__file__).parent / p) for p in ('runtime/run_handoff.py', 'source_route/check_source_roots.py', 'saved_route/check_roots.py')])
    save_new(output, result)
    print(result['status'])
    return 0 if result['status'].startswith('PASS') else 2


if __name__ == '__main__':
    raise SystemExit(main())
