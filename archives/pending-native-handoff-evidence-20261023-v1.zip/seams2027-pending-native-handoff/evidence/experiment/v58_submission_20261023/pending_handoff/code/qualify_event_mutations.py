"""Root-run mutation qualification of saved real events; no runtime invocation."""
import copy
import importlib.util
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from control_common import need, pin, load, save_new, recheck


def main():
    need(len(sys.argv) == 4, 'Usage: qualify_event_mutations.py PLAN.json RUNTIME_RESULT.json FRESH_DIRECTORY')
    plan_path, result_path, output = map(Path, sys.argv[1:])
    need(not output.exists() and output.parent.is_dir(), 'Fresh qualification directory required')
    original_ref = pin(result_path)
    plan_ref = pin(plan_path)
    original = load(original_ref)
    original_events = [json.loads(line) for line in Path(original['events']['path']).read_text().splitlines()]
    auditor_path = Path(__file__).parent / 'source_route/audit_handoff_events.py'
    spec = importlib.util.spec_from_file_location('pending_event_mutation_audit', auditor_path)
    A = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = A
    spec.loader.exec_module(A)
    output.mkdir()
    checks = []
    positive = A.run(plan_path, result_path)
    need(positive['status'] == 'PASS_ALL_6_EXECUTED_EPISODES', 'Actual event audit must first pass')
    save_new(output / 'POSITIVE_AUDIT.json', positive)
    checks.append(dict(name='actual_saved_event_positive', pass_=True))

    def first(events, name):
        return next(e for e in events if e['event'] == name)

    def install_event(events):
        return next(e for e in events if e['event'] in ('controller_installed', 'controller_retained'))

    def mutate(events, result, kind):
        if kind == 'missing_commit':
            events.remove(first(events, 'step_committed'))
        elif kind == 'duplicate_commit':
            at = events.index(first(events, 'step_committed'))
            events.insert(at, copy.deepcopy(events[at]))
        elif kind == 'missing_resume':
            events.remove(first(events, 'resumed'))
        elif kind == 'duplicate_admission':
            at = events.index(first(events, 'candidate_admission'))
            events.insert(at, copy.deepcopy(events[at]))
        elif kind == 'wrong_rank':
            install_event(events)['runtime']['controller']['rank'] = 2
        elif kind == 'bool_rank':
            install_event(events)['runtime']['controller']['rank'] = True
        elif kind == 'float_rank':
            install_event(events)['runtime']['controller']['rank'] = 1.0
        elif kind == 'bool_created_rank':
            install_event(events)['runtime']['controller']['created_rank'] = False
        elif kind == 'float_created_rank':
            install_event(events)['runtime']['controller']['created_rank'] = 0.0
        elif kind == 'reset_pending':
            install_event(events)['runtime']['source_state']['SYS_CONSTRAINT.2.pRespondsToS.state'] = 'S0'
        elif kind == 'wrong_mode':
            first(events, 'boundary_paused_and_environment_changed')['runtime']['contract_mode'] = 'old_no_b1'
        elif kind == 'old_b3_mode':
            first(events, 'episode_boot')['runtime']['contract_mode'] = 'old_no_b3'
        elif kind == 'replaced_source_object':
            install_event(events)['runtime']['state_object_identity'] += 1
        elif kind == 'wrong_script_input':
            e = next(e for e in events if e['event'] == 'step_committed' and e.get('phase') == 'frozen_five_input_script')
            e['offered_env']['b1'] = 'false'
        elif kind == 'false_response_summary':
            e = first(events, 'script_observation')
            e['observations']['old_f3_response_observed'] = not e['observations']['old_f3_response_observed']
        elif kind == 'stale_certificate':
            result['certificates']['source']['sha256'] = '0' * 64
        else:
            raise ValueError('Unknown mutation')
        # Remove the trivial numbering symptom so lifecycle checks themselves
        # must detect dropped/duplicate events.
        if kind in ('missing_commit', 'duplicate_commit', 'missing_resume', 'duplicate_admission'):
            for i, e in enumerate(events):
                e['seq'] = i
            result['event_count'] = len(events)

    kinds = ('missing_commit', 'duplicate_commit', 'missing_resume', 'duplicate_admission',
             'wrong_rank', 'bool_rank', 'float_rank', 'bool_created_rank', 'float_created_rank',
             'reset_pending', 'wrong_mode', 'old_b3_mode', 'replaced_source_object',
             'wrong_script_input', 'false_response_summary', 'stale_certificate')
    for kind in kinds:
        directory = output / kind
        directory.mkdir()
        result, events = copy.deepcopy(original), copy.deepcopy(original_events)
        mutate(events, result, kind)
        events_path = directory / 'MUTATED_EVENTS.jsonl'
        events_path.write_text(''.join(json.dumps(e) + '\n' for e in events))
        result['events'] = pin(events_path)
        result_copy = directory / 'MUTATED_RESULT.json'
        save_new(result_copy, result)
        try:
            unexpected = A.run(plan_path, result_copy)
        except A.AuditError as exc:
            checks.append(dict(name=kind, pass_=True, rejected_by=type(exc).__name__, reason=str(exc)))
        except Exception as exc:
            checks.append(dict(name=kind, pass_=False, unexpected_error=type(exc).__name__ + ': ' + str(exc)))
        else:
            checks.append(dict(name=kind, pass_=False, unexpected_status=unexpected.get('status')))
    recheck({'original_result': original_ref, 'plan': plan_ref, 'events': original['events']})
    result = dict(status='PASS_EVENT_MUTATION_QUALIFICATION' if all(c['pass_'] for c in checks) else 'FAIL_EVENT_MUTATION_QUALIFICATION',
                  plan=plan_ref, original_runtime_result=original_ref, auditor=pin(auditor_path),
                  qualifier=pin(__file__), checks=checks, runtime_imports=0, scientific_runtime_episodes=0,
                  scope='Saved-event audit only. Mutation fixtures are deliberately invalid copies; original result/events remain unchanged.')
    save_new(output / 'QUALIFICATION.json', result)
    print(result['status'])
    return 0 if result['status'].startswith('PASS') else 2


if __name__ == '__main__':
    raise SystemExit(main())
