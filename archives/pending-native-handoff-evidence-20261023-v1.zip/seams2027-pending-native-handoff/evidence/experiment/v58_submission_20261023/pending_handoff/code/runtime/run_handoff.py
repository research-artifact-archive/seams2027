"""Execute the frozen saved-graph handoff census after exact root authorization.

CLI: python -I -S -B run_handoff.py PLAN.json GO.json NEW_OUTPUT_DIRECTORY
No synthesis, compilation, scientific module imports, or subprocesses occur here.
Universal graph properties come from two separately produced certificate routes.
"""
from __future__ import annotations

import datetime
import hashlib
import itertools
import json
import os
from pathlib import Path
import sys
import threading
import time
from types import MappingProxyType

ENV = ("b1", "b2", "b3", "c")
FLOORS = ("f1", "f2", "f3")
AUX = tuple("SYS_CONSTRAINT.%d.pRespondsToS.state" % i for i in range(3))
FIELDS = ENV + FLOORS + AUX
BOOL = ("false", "true")
INPUTS = tuple(dict(zip(ENV, values)) for values in itertools.product(BOOL, repeat=4))
POLICIES = ("strict_only", "strict_and_cooperative")
ORDER = ("retain_old_native", "saved_normalized", "saved_preference")
CANDIDATE_GRAPH = {
    "retain_old_native": "native", 
    "saved_normalized": "normalized", "saved_preference": "preference",
}
SOURCE_SHA = "6a8f8220385130b2eb219ecfa33186b179d610ffcf805a30f9cab47ab204dae7"
SOURCE_BYTES = 2218
MAX_FILE = 16 * 1024 * 1024
MAX_EVENTS = 4096
OLD_SOURCE_SUFFIX = b"\n\nassumption -- constructed_old_mode_no_b1\n\talw(b1=false);\n"
CERTIFICATE_KEYS = ("candidate", "graph_sha256", "root_id", "rank", "complete", "strict", "cooperative", "source_coverage")

FIXED_INPUTS = tuple(dict(zip(ENV, ("true" if bit == "1" else "false" for bit in bits)))
                     for bits in ("1010", "1000", "1000", "0000", "0000"))


class Refusal(ValueError):
    pass


def need(condition, message):
    if not condition:
        raise Refusal(message)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()




def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def pin(path):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), "Input not a regular nonsymlink file: " + str(path))
    need(path.stat().st_size <= MAX_FILE, "Input file bound: " + str(path))
    raw = path.read_bytes()
    return {"path": str(path.resolve()), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, "Duplicate JSON key: " + key)
        result[key] = value
    return result


def read_json(path):
    pin(path)
    return json.loads(Path(path).read_text(encoding="utf-8"), object_pairs_hook=unique_object)


def file_references(value):
    """Find explicit pin objects without interpreting prose or historical hashes."""
    if isinstance(value, dict):
        if {"path", "bytes", "sha256"} <= set(value):
            yield value
        for child in value.values():
            yield from file_references(child)
    elif isinstance(value, list):
        for child in value:
            yield from file_references(child)


def binds_current_file(review, ref):
    for candidate in file_references(review):
        if candidate.get("bytes") == ref["bytes"] and candidate.get("sha256") == ref["sha256"]:
            try:
                if Path(candidate["path"]).samefile(ref["path"]):
                    return True
            except (OSError, TypeError):
                pass
    return False


class BoundInputs:
    def __init__(self):
        self.files = {}

    def add(self, ref, expected=None):
        need(isinstance(ref, dict) and {"path", "bytes", "sha256"} <= set(ref), "Missing file pin")
        path = Path(ref["path"])
        need(path.is_absolute(), "Pinned path must be absolute")
        actual = pin(path)
        need(type(ref["bytes"]) is int and ref["bytes"] == actual["bytes"]
             and ref["sha256"] == actual["sha256"], "Input pin mismatch: " + str(path))
        if expected is not None:
            need(path.samefile(expected), "Bound file is not the expected file")
        self.files[actual["path"]] = actual
        return path

    def load(self, ref, expected=None):
        return read_json(self.add(ref, expected))

    def recheck(self):
        need(all(pin(row["path"]) == row for row in self.files.values()), "Bound input changed during runtime")


def typed_source(state):
    need(isinstance(state, dict) and set(state) == set(FIELDS), "Exact ten source/history fields required")
    need(all(state[k] in BOOL for k in ENV + FLOORS), "Non-Boolean source field")
    need(all(state[k] in ("S0", "S1") for k in AUX), "Untyped response monitor")
    return state


def truth(state, name):
    return state[name] == "true"


def initial_source():
    return {**{name: "false" for name in ENV}, "f1": "true", "f2": "false", "f3": "false",
            **{name: "S0" for name in AUX}}


def next_monitors(state):
    return {a: "S1" if (state[a] == "S1" or truth(state, b))
            and not (truth(state, f) or truth(state, "c")) else "S0"
            for a, b, f in zip(AUX, ENV[:3], FLOORS)}


def env_legal(state, offered, mode):
    need(mode in ("old_no_b1", "normal"), "Unknown contract mode")
    if not isinstance(offered, dict) or set(offered) != set(ENV) or any(offered[k] not in BOOL for k in ENV):
        return False
    if sum(truth(state, f) for f in FLOORS) != 1:
        return False
    if mode == "old_no_b1" and (truth(state, "b1") or truth(offered, "b1")):
        return False
    for b, f in zip(ENV[:3], FLOORS):
        if truth(state, b) and truth(state, f) and truth(offered, b):
            return False
        if truth(state, b) and not truth(state, f) and not truth(state, "c") and not truth(offered, b):
            return False
    return True


def sys_legal(state, target):
    typed_source(state)
    typed_source(target)
    b1, b2, b3, c = [truth(state, x) for x in ENV]
    n1, n2, n3 = [truth(target, x) for x in FLOORS]
    moves = (
        (n1 and not b2 and not b3) or (n2 and (b2 or b3)) or (n1 and c),
        (n1 and b1) or (n2 and not b1 and not b3) or (n3 and b3) or (n2 and c),
        (n3 and not b1 and not b2) or (n2 and (b1 or b2)) or (n3 and c),
    )
    return all(not truth(state, f) or allowed for f, allowed in zip(FLOORS, moves)) and all(
        target[a] == value for a, value in next_monitors(state).items())


class SavedGraph:
    """Immutable records; no root relabeling or private-rank rewriting."""
    def __init__(self, label, ref, data):
        need(label in ("native", "normalized", "preference"), "Unexpected graph label")
        self.label = label
        self.ref = dict(ref)
        self.sha256 = ref["sha256"]
        self.has_helper = label != "normalized"
        nodes = {}
        need(isinstance(data.get("nodes"), list) and data["nodes"], "Missing graph nodes")
        for raw in data["nodes"]:
            node_id = raw.get("id")
            need(type(node_id) is str and node_id not in nodes, "Duplicate or malformed private node ID")
            need(type(raw.get("rank")) is int and 0 <= raw["rank"] < 3, "Unexpected actual private rank")
            need(type(raw.get("initial")) is bool, "Missing original initial flag")
            value = raw.get("valuation")
            expected = set(FIELDS) | ({"~envHelp"} if self.has_helper else set())
            need(isinstance(value, dict) and set(value) == expected, "Graph field/helper roster differs")
            typed_source({k: value[k] for k in FIELDS})
            if self.has_helper:
                need(value["~envHelp"] in BOOL, "Untyped native helper")
            successors = raw.get("successors")
            need(isinstance(successors, list) and all(type(x) is str for x in successors)
                 and len(successors) == len(set(successors)), "Malformed successor list")
            nodes[node_id] = MappingProxyType({
                "id": node_id, "rank": raw["rank"], "initial": raw["initial"],
                "valuation": MappingProxyType(dict(value)), "successors": tuple(successors),
            })
        edges = data.get("edges")
        need(isinstance(edges, list) and all(isinstance(x, list) and len(x) == 2
             and all(type(v) is str for v in x) for x in edges), "Malformed edge records")
        edge_set = frozenset(tuple(x) for x in edges)
        need(len(edge_set) == len(edges), "Duplicate graph edge")
        need(all(t in nodes for node in nodes.values() for t in node["successors"]), "Successor absent")
        need(edge_set == frozenset((n["id"], t) for n in nodes.values() for t in n["successors"]),
             "Edge/successor representations disagree")
        self.nodes = MappingProxyType(nodes)
        self.edges = edge_set

    def node(self, node_id):
        need(node_id in self.nodes, "Bound private root is absent")
        return self.nodes[node_id]

    def original(self, node_id):
        node = self.node(node_id)
        return not self.has_helper or node["valuation"]["~envHelp"] == "false"

    def source(self, node_id):
        return {k: self.node(node_id)["valuation"][k] for k in FIELDS}


class GraphController:
    def __init__(self, graph, root_id, expected_source, expected_rank, require_initial=False):
        node = graph.node(root_id)
        need(graph.original(root_id), "A new or reached root cannot have helper=true")
        need(type(expected_rank) is int and graph.source(root_id) == expected_source and node["rank"] == expected_rank,
             "Exact source/history/private-root mapping differs")
        if require_initial:
            need(node["initial"] is True, "Old start not original-initial marked")
        self.graph = graph
        self.node_id = root_id
        self.created_root = root_id
        self.created_rank = expected_rank

    def memory(self):
        node = self.graph.node(self.node_id)
        return {"instance_identity": id(self), "graph": self.graph.label,
                "graph_sha256": self.graph.sha256, "node_id": self.node_id,
                "rank": node["rank"], "original_initial_flag": node["initial"],
                "created_root": self.created_root, "created_rank": self.created_rank}

    def propose(self, state, offered):
        need(self.graph.source(self.node_id) == state, "Controller current state differs from plant")
        candidates = [node_id for node_id in self.graph.node(self.node_id)["successors"]
                      if self.graph.original(node_id) and all(
                          self.graph.node(node_id)["valuation"][k] == offered[k] for k in ENV)]
        need(len(candidates) == 1, "Actual native response missing or nondeterministic")
        target = candidates[0]
        need((self.node_id, target) in self.graph.edges, "Proposed private transition absent")
        return self.graph.source(target), target

    def commit(self, target):
        need((self.node_id, target) in self.graph.edges, "Cannot commit absent private edge")
        self.node_id = target


class EventLog:
    def __init__(self, stream):
        self.stream = stream
        self.count = 0
        self.bytes = 0

    def emit(self, event, **payload):
        need(self.count < MAX_EVENTS, "Event count bound")
        row = {"seq": self.count, "event": event, "utc": now(), "monotonic_ns": time.monotonic_ns(),
               "pid": os.getpid(), **payload}
        raw = json.dumps(row, ensure_ascii=False) + "\n"
        self.bytes += len(raw.encode("utf-8"))
        need(self.bytes <= MAX_FILE, "Event stream byte bound")
        self.stream.write(raw)
        self.stream.flush()
        self.count += 1


class Runtime:
    def __init__(self, episode_id, boundary_id, policy, old_graph, log):
        self.episode_id = episode_id
        self.boundary_id = boundary_id
        self.policy = policy
        self.state = initial_source()
        self.old_controller = GraphController(old_graph, "0", self.state, 0, require_initial=True)
        self.controller = self.old_controller
        self.mode = "old_no_b1"
        self.epoch = 0
        self.paused = False
        self.ticks = 0
        self.state_identity = id(self.state)
        self.log = log
        self.lock = threading.RLock()
        self.retained_instances = [self.old_controller]
        self.emit("episode_boot")

    def snapshot(self):
        need(id(self.state) == self.state_identity, "State object replaced")
        return {"episode_id": self.episode_id, "boundary_id": self.boundary_id, "policy": self.policy,
                "plant_identity": id(self), "state_object_identity": id(self.state),
                "source_state": dict(self.state), "contract_mode": self.mode, "epoch": self.epoch,
                "paused": self.paused, "ticks": self.ticks, "controller": self.controller.memory()}

    def emit(self, event, **extra):
        self.log.emit(event, runtime=self.snapshot(), **extra)

    def step(self, offered, phase, expected_target=None):
        with self.lock:
            need(not self.paused, "Attempted step while paused")
            before = self.snapshot()
            need(env_legal(self.state, offered, self.mode), "Offered input violates active source ENV relation")
            target_state, target_id = self.controller.propose(self.state, offered)
            need(expected_target is None or target_id == expected_target, "Actual old prefix differs from frozen private path")
            if not sys_legal(self.state, target_state):
                self.emit("response_rejected", phase=phase, before=before, offered_env=offered,
                          proposed_source_state=target_state, proposed_node_id=target_id,
                          reason="source_SYS_or_logical_history_transition_violated")
                return False
            self.state.update(target_state)
            self.controller.commit(target_id)
            self.ticks += 1
            self.emit("step_committed", phase=phase, before=before, offered_env=offered)
            return True

    def pause_and_change(self, boundary):
        with self.lock:
            need(self.mode == "old_no_b1" and not self.paused and self.epoch == 0, "Invalid change lifecycle")
            need(self.controller is self.old_controller, "Old controller changed before boundary")
            need(self.controller.node_id == boundary["reached_native_node"]
                 and self.controller.memory()["rank"] == boundary["reached_rank"]
                 and self.state == boundary["source_state"], "Actual reached boundary differs from frozen record")
            before = self.snapshot()
            self.paused = True
            self.mode = "normal"
            self.epoch += 1
            need(self.state == before["source_state"], "Change mutated source/history")
            self.emit("boundary_paused_and_environment_changed", before=before,
                      removed_restriction="G !b1", pending_monitor_scope="m3=S1, f3=false, c=false; genuinely unanswered obligation")

    def install(self, candidate, binding, certificate_evidence):
        with self.lock:
            need(self.paused and self.mode == "normal" and self.epoch == 1, "Invalid installation lifecycle")
            before = self.snapshot()
            name = binding["candidate"]
            need(type(binding.get("rank")) is int, "Certificate rank must be an integer")
            if name == "retain_old_native":
                need(candidate is self.old_controller and candidate is self.controller,
                     "Retain-old must keep the same actually reached controller instance")
            else:
                need(candidate is not self.old_controller and candidate not in self.retained_instances,
                     "Replacement must be a newly created controller instance")
                need(candidate.memory()["rank"] == candidate.created_rank == binding["rank"], "Replacement private memory differs from certified stored rank")
                self.retained_instances.append(candidate)
            need(candidate.graph.source(candidate.node_id) == self.state, "Installation resets source/history")
            need(candidate.graph.sha256 == binding["graph_sha256"] and candidate.node_id == binding["root_id"]
                 and candidate.memory()["rank"] == binding["rank"], "Installed root differs from certificate binding")
            self.controller = candidate
            need(self.state == before["source_state"], "Installation mutated source/history")
            self.emit("controller_retained" if name == "retain_old_native" else "controller_installed",
                      before=before, candidate=name, certified_root=dict(binding), certificates=certificate_evidence)
            self.paused = False
            self.emit("resumed")


def agreeing_certificates(source, saved, boundaries, graphs, plan_ref):
    expected_boundary_ids = [b["id"] for b in boundaries]
    for route, bundle in (("source", source), ("saved_model", saved)):
        need(bundle.get("schema") == "v58-pending-rooted-graph-certificate-bundle-v1"
             and bundle.get("status") == "COMPLETE_ROOTED_CANDIDATES" and bundle.get("route") == route,
             "Incomplete or wrong certificate route")
        bound_plan = bundle.get("plan")
        need(isinstance(bound_plan, dict) and all(bound_plan.get(k) == plan_ref[k] for k in ("bytes", "sha256"))
             and Path(bound_plan["path"]).samefile(plan_ref["path"]), "Certificate plan binding differs")
        gate = bundle.get("old_gate")
        need(isinstance(gate, dict) and all(type(gate.get(k)) is bool for k in
             ("complete", "strict", "cooperative", "source_coverage")), "Malformed old gate")
        need(all(gate[k] for k in ("complete", "strict", "cooperative", "source_coverage")),
             "Old-mode gate did not pass; runtime is forbidden")
        rows = bundle.get("boundaries")
        need(isinstance(rows, list) and [b.get("id") for b in rows] == expected_boundary_ids,
             "Certificate boundary roster/order differs")
        for expected, actual in zip(boundaries, rows):
            for key in ("source_state", "reached_native_node", "reached_rank"):
                need(actual.get(key) == expected[key], "Certificate boundary identity differs: " + key)
            candidates = actual.get("candidates")
            need(isinstance(candidates, list) and [c.get("candidate") for c in candidates] == list(ORDER),
                 "Certificate candidate roster/order differs")
            for bound, cert in zip(expected["candidates"], candidates):
                need(type(cert.get("rank")) is int, "Certificate rank must be an integer")
                for key in ("candidate", "graph_sha256", "root_id", "rank"):
                    need(cert.get(key) == bound[key], "Certificate root binding differs: " + key)
                need(cert["graph_sha256"] == graphs[CANDIDATE_GRAPH[cert["candidate"]]].sha256,
                     "Certificate graph identity differs")
                need(all(type(cert.get(k)) is bool for k in ("complete", "strict", "cooperative", "source_coverage")),
                     "Candidate verdict must be explicit Boolean")
                need(cert["complete"] and cert["source_coverage"], "Noncomplete candidate or missing source coverage")
    for key in ("complete", "strict", "cooperative", "source_coverage"):
        need(source["old_gate"][key] == saved["old_gate"][key], "Old-gate routes disagree")
    for a, b in zip(source["boundaries"], saved["boundaries"]):
        for x, y in zip(a["candidates"], b["candidates"]):
            for key in ("candidate", "graph_sha256", "root_id", "rank", "complete", "strict", "cooperative", "source_coverage"):
                need(x[key] == y[key], "Independent candidate routes disagree: " + key)
    return {b["id"]: [{key: cert[key] for key in CERTIFICATE_KEYS} for cert in b["candidates"]]
            for b in source["boundaries"]}


def continuation(runtime, script):
    need(script == list(FIXED_INPUTS), "Fixed post-update script changed")
    trail = [runtime.snapshot()]
    progress = []
    status = None
    for step, offered in enumerate(script, 1):
        if not env_legal(runtime.state, offered, "normal"):
            runtime.emit("script_input_refused", script_step=step, offered_env=offered)
            status = "FIXED_SCRIPT_ENV_REFUSED"
            break
        if not runtime.step(offered, "frozen_five_input_script"):
            status = "FIXED_SCRIPT_RESPONSE_REJECTED"
            break
        trail.append(runtime.snapshot())
        state = runtime.state
        progress.append({"commit": step, "b1": state["b1"], "b3": state["b3"],
                         "f1": state["f1"], "f3": state["f3"], "c": state["c"],
                         "m1": state[AUX[0]], "m3": state[AUX[2]]})
    repeated = len(trail) >= 2 and trail[-1]["controller"]["node_id"] == trail[-2]["controller"]["node_id"] and trail[-1]["source_state"] == trail[-2]["source_state"]
    justice_hits = {a: runtime.state[a] == "S0" for a in AUX}
    fair_self_loop = repeated and all(justice_hits.values())
    if status is None:
        status = "EXECUTED_FAIR_SELF_LOOP" if fair_self_loop else "FIXED_SCRIPT_COMPLETED_WITHOUT_FAIR_SELF_LOOP"
    observation = {"old_pending_m3_at_install": trail[0]["source_state"][AUX[2]] == "S1" and not truth(trail[0]["source_state"], "f3"),
                   "first_input_illegal_old_mode": not env_legal(trail[0]["source_state"], script[0], "old_no_b1"),
                   "new_b1_observed": any(x["b1"] == "true" for x in progress),
                   "old_f3_response_observed": any(x["f3"] == "true" and x["c"] == "false" for x in progress),
                   "old_m3_cleared": any(x["m3"] == "S0" for x in progress),
                   "new_m1_pending_observed": any(x["m1"] == "S1" for x in progress),
                   "new_f1_response_after_request": any(x["f1"] == "true" and x["m1"] == "S1" and x["c"] == "false" for x in progress),
                   "new_m1_cleared_after_pending": any(x["m1"] == "S1" and any(y["commit"] > x["commit"] and y["m1"] == "S0" for y in progress) for x in progress),
                   "cancellation_used": any(x["c"] == "true" for x in progress),
                   "executed_self_loop": repeated, "fair_self_loop": fair_self_loop}
    runtime.emit("script_observation", status=status, progress=progress, observations=observation,
                 SYS_justice_hits=justice_hits, ENV_justice_count=0)
    return {"status": status, "committed_continuation_steps": len(trail)-1,
            "trail": trail, "progress": progress, "observations": observation,
            "SYS_justice_hits": justice_hits, "ENV_justice_count": 0,
            "final_snapshot": runtime.snapshot(),
            "scope": "Five fixed actual commits at most. A finite self-loop traversal is observed; infinite fair repetition additionally uses the complete source/graph certificates."}


def run_episode(boundary, policy, graphs, verdicts, certificate_refs, log, keepalive):
    episode_id = boundary["id"] + "__" + policy
    rt = Runtime(episode_id, boundary["id"], policy, graphs["native"], log)
    keepalive.append(rt)
    path = boundary["prefix_node_ids"]
    for target in path[1:]:
        offered = {k: graphs["native"].node(target)["valuation"][k] for k in ENV}
        need(rt.step(offered, "frozen_old_native_prefix", expected_target=target), "Frozen old prefix response rejected")
    need(rt.ticks == len(path) - 1, "Prefix ticks differ")
    rt.pause_and_change(boundary)
    decisions = []
    chosen = None
    for cert in verdicts:
        eligible = cert["strict"] and (policy == "strict_only" or cert["cooperative"])
        considered = chosen is None
        decision = {**dict(cert), "considered": considered, "eligible_under_policy": eligible,
                    "selected": considered and eligible}
        decisions.append(decision)
        rt.emit("candidate_admission", decision=decision, certificates=certificate_refs)
        if considered and eligible:
            chosen = cert
    if chosen is None:
        rt.emit("admission_abstained", reason="No candidate satisfies the frozen admission policy")
        return {"episode_id": episode_id, "boundary_id": boundary["id"], "policy": policy,
                "status": "COMPLETE_ADMISSION_ABSTAINED", "decisions": decisions,
                "selected_candidate": None, "prefix_committed_steps": len(path) - 1,
                "final_snapshot": rt.snapshot()}
    if chosen["candidate"] == "retain_old_native":
        candidate = rt.old_controller
    else:
        candidate = GraphController(graphs[CANDIDATE_GRAPH[chosen["candidate"]]], chosen["root_id"],
                                    rt.state, chosen["rank"])
    rt.install(candidate, chosen, certificate_refs)
    outcome = continuation(rt, boundary["post_update_inputs"])
    rt.emit("episode_completed", selected_candidate=chosen["candidate"], outcome=outcome["status"])
    return {"episode_id": episode_id, "boundary_id": boundary["id"], "policy": policy,
            "status": "COMPLETE_EXECUTED_HANDOFF", "prefix_committed_steps": len(path) - 1,
            "decisions": decisions, "selected_candidate": chosen["candidate"],
            "old_private_root": {"node_id": boundary["reached_native_node"], "rank": boundary["reached_rank"]},
            "installed_private_root": {"node_id": chosen["root_id"], "rank": chosen["rank"]},
            "outcome": outcome, "final_snapshot": rt.snapshot()}


def validate_roster(roster, graphs):
    boundaries = roster.get("boundaries")
    need(isinstance(boundaries, list) and len(boundaries) == 3, "Expected frozen three-boundary census")
    need(len({b["id"] for b in boundaries}) == 3 and all(type(b["id"]) is str for b in boundaries), "Boundary IDs differ")
    need([b["reached_native_node"] for b in boundaries] == ["524", "526", "756"], "Do not merge distinct old private states")
    need(len({tuple(b["source_state"][k] for k in FIELDS) for b in boundaries}) == 3, "Expected three full source valuations")
    for b in boundaries:
        typed_source(b["source_state"])
        need(type(b["reached_rank"]) is int, "Reached rank must be an integer")
        old = graphs["native"].node(b["reached_native_node"])
        need(old["rank"] == b["reached_rank"] and graphs["native"].source(old["id"]) == b["source_state"], "Old boundary identity differs")
        need(graphs["native"].original(old["id"]) and old["valuation"]["b1"] == "false", "Old boundary outside declared mode")
        need(any(b["source_state"][a] == "S1" for a in AUX), "Boundary lacks nonzero logical history")
        need(b["source_state"][AUX[2]] == "S1" and not truth(b["source_state"], "f3") and not truth(b["source_state"], "c"), "Genuine third-floor pending obligation absent")
        need(b.get("post_update_inputs") == list(FIXED_INPUTS), "Frozen five-input script differs")
        path = b.get("prefix_node_ids")
        need(isinstance(path, list) and 2 <= len(path) <= 64 and path[0] == "0"
             and path[-1] == b["reached_native_node"] and len(set(path)) == len(path), "Malformed frozen BFS prefix")
        need(all((s, t) in graphs["native"].edges for s, t in zip(path, path[1:])), "Frozen prefix edge absent")
        need(len(path) == 3 and b["prefix_input_bits"] == ["".join("1" if graphs["native"].source(t)[k] == "true" else "0" for k in ENV) for t in path[1:]], "Frozen prefix offered inputs differ")
        need(isinstance(b.get("candidates"), list) and [c["candidate"] for c in b["candidates"]] == list(ORDER), "Frozen candidate order differs")
        for c in b["candidates"]:
            graph = graphs[CANDIDATE_GRAPH[c["candidate"]]]
            node = graph.node(c["root_id"])
            need(type(c["rank"]) is int and c["graph_sha256"] == graph.sha256 and graph.source(node["id"]) == b["source_state"]
                 and graph.original(node["id"]) and node["rank"] == c["rank"], "Candidate root/source/rank binding differs")
            if c["candidate"] == "retain_old_native":
                need(c["root_id"] == b["reached_native_node"] and c["rank"] == b["reached_rank"], "Retained root differs from reached root")
    return boundaries


def normalized_roster(raw, graphs):
    """Translate field names only; preserve every source/rank/root selection."""
    need(isinstance(raw.get("boundaries"), list), "Missing frozen boundary roster")
    rows = []
    for source_row in raw["boundaries"]:
        row = dict(source_row)
        need(isinstance(row.get("candidates"), list), "Missing frozen candidates")
        candidates = []
        for item in row["candidates"]:
            name = item.get("candidate")
            need(name in CANDIDATE_GRAPH and item.get("graph") == CANDIDATE_GRAPH[name],
                 "Frozen candidate graph label differs")
            candidates.append({"candidate": name, "graph_sha256": graphs[item["graph"]].sha256,
                               "root_id": item["root"], "rank": item["rank"]})
        row["candidates"] = candidates
        rows.append(row)
    return {**raw, "boundaries": rows}


def load_authorized(plan_path, go_path):
    inputs = BoundInputs()
    plan_ref, go_ref = pin(plan_path), pin(go_path)
    plan = inputs.load(plan_ref)
    go = inputs.load(go_ref)
    need(go.get("status") == "GO_EXACT_FROZEN_HANDOFF_RUNTIME", "Missing exact runtime GO")
    inputs.add(go["plan"], plan_path)
    inputs.add(go["runtime_script"], Path(__file__))
    review = inputs.load(go["independent_runtime_review"])
    need(type(review.get("status")) is str and review["status"].startswith("PASS"), "Independent runtime review did not pass")
    need(binds_current_file(review, plan_ref) and binds_current_file(review, pin(__file__)),
         "Independent runtime review does not bind current plan and runtime script")
    qualification = inputs.load(go["interface_qualification"])
    need(qualification.get("status") == "PASS_INTERFACE_QUALIFICATION"
         and qualification.get("plan") == plan_ref and qualification.get("checks")
         and all(row.get("pass_") is True for row in qualification["checks"]),
         "Focused interface qualification is absent, stale, or failed")
    need(binds_current_file(qualification, pin(__file__)), "Qualification does not bind this runtime")
    for ref in file_references(qualification):
        inputs.add(ref)
    need(plan.get("schema") == "v58-pending-handoff-plan-v1", "Unexpected frozen plan schema")
    need(plan.get("candidate_order") == list(ORDER) and plan.get("policies") == list(POLICIES), "Frozen policies or order differ")
    need(plan.get("disabled_button") == "b1" and plan.get("old_start_node") == "0"
         and plan.get("continuation_steps_per_episode") == 5, "Frozen mode/start/bound differs")
    need(plan.get("old_mode") == {"disabled_ENV": "b1", "current_value": "false",
         "next_value": "false", "source_initializers_preserved": True}, "Old-mode definition differs")
    need(plan.get("full_reset_uses") == 0 and plan.get("fresh_native_or_compiler_execution") is False,
         "Unexpected execution scope")
    source_path = inputs.add(plan["source"])
    need(pin(source_path)["sha256"] == SOURCE_SHA and pin(source_path)["bytes"] == SOURCE_BYTES, "Exact unchanged Lift source required")
    old_source_path = inputs.add(plan["old_source"])
    need(old_source_path.read_bytes() == source_path.read_bytes() + OLD_SOURCE_SUFFIX,
         "Old source must append only the frozen G !b1 assumption")
    for ref in file_references(plan):
        inputs.add(ref)
    input_manifest = inputs.load(plan["inputs"])
    need(input_manifest.get("schema") == "v58-pending-staged-immutable-inputs-v1", "Unexpected staged input manifest")
    for name in ("source", "old_source", "graphs", "roster"):
        need(input_manifest.get(name) == plan.get(name), "Plan and staged input manifest differ: " + name)
    for ref in file_references(input_manifest):
        inputs.add(ref)
    selection = inputs.load(plan["selection"])
    need(selection.get("status") == "SELECT_V58_PENDING_B1_ALL_THREE", "Selection does not authorize pending b1 study")
    need(set(plan["graphs"]) == {"native", "preference", "normalized"}, "Graph roster differs")
    graphs = {label: SavedGraph(label, ref, inputs.load(ref)) for label, ref in plan["graphs"].items()}
    for label, graph_ref in plan["graphs"].items():
        for name in ("model", "result"):
            inputs.add(graph_ref[name])
        if graph_ref.get("printer") is None:
            need(label == "normalized", "Native graph printer pin is required")
        else:
            inputs.add(graph_ref["printer"])
    roster = inputs.load(plan["roster"])
    need(plan.get("boundaries") == roster.get("boundaries"), "Inline and separately pinned boundary rosters differ")
    boundaries = validate_roster(normalized_roster(roster, graphs), graphs)
    need(set(go["certificates"]) == {"source", "saved_model"}, "Both independent certificate routes required")
    certs = {route: inputs.load(ref) for route, ref in go["certificates"].items()}
    verdicts = agreeing_certificates(certs["source"], certs["saved_model"], boundaries, graphs, plan_ref)
    need(plan.get("wall_seconds") is None, "No arbitrary scientific wall cap")
    inputs.recheck()
    return inputs, plan_ref, go_ref, plan, graphs, boundaries, verdicts, go["certificates"]


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    need(len(argv) == 3, "Usage: run_handoff.py PLAN.json GO.json NEW_OUTPUT_DIRECTORY")
    plan_path, go_path, output = (Path(value).resolve() for value in argv)
    need(not output.exists() and output.parent.is_dir(), "Output must be a new directory under an existing parent")
    inputs, plan_ref, go_ref, plan, graphs, boundaries, verdicts, cert_refs = load_authorized(plan_path, go_path)
    output.mkdir()
    result = {"schema": "v58-pending-executed-handoff-census-result-v1", "status": "RUNNING", "started_utc": now(),
              "plan": plan_ref, "execution_go": go_ref, "runtime_script": pin(__file__), "certificates": cert_refs,
              "scope": "Constructed saved-graph noninitial handoffs; no fresh synthesis or private-memory transport.",
              "expected_episodes": 6, "episodes": [{"episode_id": b["id"] + "__" + policy,
                  "boundary_id": b["id"], "policy": policy, "status": "NOT_ATTEMPTED"}
                  for b in boundaries for policy in POLICIES], "errors": [], "scientific_native_or_compiler_calls": 0,
              "full_reset_uses": 0, "conference_submission": False}
    def checkpoint():
        temporary = output / ".RESULT.pending"
        with temporary.open("wb") as stream:
            stream.write(encode(result))
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, output / "RESULT.json")
    # A fresh, owned directory makes replacement safe. Persist all six rows even
    # if a resource supervisor subsequently terminates this process group.
    checkpoint()
    keepalive = []
    event_path = output / "EVENTS.jsonl"
    with event_path.open("x", encoding="utf-8") as stream:
        log = EventLog(stream)
        try:
            log.emit("census_started", plan=plan_ref, execution_go=go_ref, certificates=cert_refs)
            for index, (b, policy) in enumerate((b, p) for b in boundaries for p in POLICIES):
                result["episodes"][index] = {"episode_id": b["id"] + "__" + policy,
                                             "boundary_id": b["id"], "policy": policy, "status": "RUNNING"}
                checkpoint()
                result["episodes"][index] = run_episode(b, policy, graphs, verdicts[b["id"]], cert_refs, log, keepalive)
                checkpoint()
            need(len(keepalive) == 6 and len({id(rt) for rt in keepalive}) == 6
                 and len({id(rt.state) for rt in keepalive}) == 6, "Episode plant/state instances overlap")
            inputs.recheck()
            result["status"] = "COMPLETE_EXECUTED_HANDOFF_CENSUS"
            log.emit("census_completed", episodes=6, outcomes=[e.get("outcome", {}).get("status", e["status"]) for e in result["episodes"]])
        except BaseException as error:
            result["status"] = "UNKNOWN_OR_INVALID_HANDOFF_CENSUS"
            result["errors"].append(type(error).__name__ + ": " + str(error))
            for row in result["episodes"]:
                if row["status"] == "RUNNING":
                    row["status"] = "UNKNOWN_INTERRUPTED_EPISODE"
            try:
                log.emit("census_failed", error=result["errors"][-1])
            except BaseException:
                pass
        finally:
            result["event_count"] = log.count
            result["finished_utc"] = now()
            try:
                inputs.recheck()
                result["input_integrity"] = "PASS"
            except BaseException as error:
                result["input_integrity"] = "FAIL"
                result["status"] = "UNKNOWN_INPUT_MUTATION"
                result["errors"].append(type(error).__name__ + ": " + str(error))
    result["events"] = pin(event_path)
    result["bound_inputs"] = list(inputs.files.values())
    raw = encode(result)
    need(len(raw) <= MAX_FILE, "Result file bound")
    checkpoint()
    print(json.dumps({"status": result["status"], "result": pin(output / "RESULT.json")}))
    return 0 if result["status"] == "COMPLETE_EXECUTED_HANDOFF_CENSUS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
