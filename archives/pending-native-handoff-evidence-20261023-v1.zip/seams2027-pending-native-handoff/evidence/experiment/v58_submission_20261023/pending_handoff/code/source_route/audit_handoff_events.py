"""Independent source-equation audit of the frozen handoff event census.

CLI: python3 -I -B audit_handoff_events.py PLAN.json RUNTIME_RESULT.json OUTPUT.json
Never imports the runtime, invokes its methods, synthesizes, or changes graphs.
Complete controller verdicts remain external two-route evidence; this audit
reconstructs the recorded executions and their declared finite continuation.
"""
from pathlib import Path
import datetime
import itertools
import json
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from independent_core import AuditError, need, decode_json, pin, read_pin, save_new
from source_contracts import CONTRACTS, HELPER

C = CONTRACTS['lift__trivial_1']
ARMS = ('retain_old_native', 'saved_normalized', 'saved_preference')
POLICIES = ('strict_only', 'strict_and_cooperative')
GRAPH_FOR = dict(zip(ARMS, ('native', 'normalized', 'preference')))
CERT_KEYS = ('candidate', 'graph_sha256', 'root_id', 'rank', 'complete', 'strict', 'cooperative', 'source_coverage')
ENV_INPUTS = tuple(dict(zip(C.env, v)) for v in itertools.product(('false', 'true'), repeat=4))


def same_pin(a, b):
    return (isinstance(a, dict) and isinstance(b, dict) and a.get('sha256') == b.get('sha256')
            and a.get('bytes') == b.get('bytes') and Path(a['path']).samefile(b['path']))


def gather_pins(value):
    found = {}
    def visit(x):
        if isinstance(x, dict):
            if {'path', 'bytes', 'sha256'} <= set(x):
                ref = {k: x[k] for k in ('path', 'bytes', 'sha256')}
                need(ref['path'] not in found or found[ref['path']] == ref, 'Conflicting provenance pin')
                found[ref['path']] = ref
            for v in x.values(): visit(v)
        elif isinstance(x, list):
            for v in x: visit(v)
    visit(value)
    return list(found.values())


def typed(s):
    need(isinstance(s, dict) and set(s) == set(C.names), 'Exact source/AUX field set')
    need(all(type(s[n]) is str and s[n] in C.values[n] for n in C.names), 'Typed source/AUX values')
    return s


def env_legal(s, offered, old=False):
    need(set(offered) == set(C.env), 'Exact offered ENV fields')
    return C.rho_e(s, offered) and (not old or s['b1'] == offered['b1'] == 'false')


def graph_records(ref):
    data = decode_json(read_pin(ref))
    need(data.get('complete') is True and data.get('fixture_id') == C.candidate, 'Complete Lift graph required')
    nodes = {}
    for n in data['nodes']:
        need(n['id'] not in nodes, 'Duplicate graph private node')
        need(type(n['rank']) is int and 0 <= n['rank'] < 3 and type(n['initial']) is bool, 'Native memory metadata')
        v = n['valuation']; need(set(v) in (set(C.names), set(C.names) | {HELPER}), 'Raw graph fields')
        typed({k: v[k] for k in C.names})
        nodes[n['id']] = n
    edges = {tuple(e) for e in data['edges']}
    need(len(edges) == len(data['edges']) and edges == {(i, t) for i, n in nodes.items() for t in n['successors']},
         'Raw graph edge parity')
    need(all(a in nodes and b in nodes for a, b in edges), 'Raw graph edge endpoint')
    return {'nodes': nodes, 'edges': edges, 'pin': ref}


def graph_source(g, node):
    return {n: g['nodes'][node]['valuation'][n] for n in C.names}


def check_snapshot(snap, graph_map, episode, boundary, policy):
    need(isinstance(snap, dict) and snap.get('episode_id') == episode and snap.get('boundary_id') == boundary
         and snap.get('policy') == policy, 'Event episode identity')
    typed(snap['source_state'])
    for key in ('plant_identity', 'state_object_identity'):
        need(type(snap.get(key)) is int and snap[key] > 0, 'Reported object identity')
    need(type(snap.get('ticks')) is int and snap['ticks'] >= 0 and type(snap.get('paused')) is bool
         and type(snap.get('epoch')) is int and snap['epoch'] in (0, 1)
         and snap.get('contract_mode') in ('old_no_b1', 'normal'), 'Runtime lifecycle fields')
    memory = snap['controller']
    need(type(memory.get('instance_identity')) is int and memory['instance_identity'] > 0, 'Controller instance identity')
    need(memory.get('graph') in graph_map, 'Runtime graph label')
    graph = graph_map[memory['graph']]
    need(memory.get('graph_sha256') == graph['pin']['sha256'] and memory.get('node_id') in graph['nodes'], 'Runtime graph/root digest')
    node = graph['nodes'][memory['node_id']]
    need(node['valuation'].get(HELPER, 'false') == 'false' and graph_source(graph, node['id']) == snap['source_state'],
         'Plant/graph full source+AUX mismatch')
    need(type(memory.get('rank')) is int and memory.get('rank') == node['rank']
         and type(memory.get('original_initial_flag')) is bool and memory.get('original_initial_flag') == node['initial'],
         'Actual private rank/original marker mismatch')
    created = memory.get('created_root')
    need(created in graph['nodes'] and type(memory.get('created_rank')) is int
         and memory.get('created_rank') == graph['nodes'][created]['rank'], 'Actual created memory root')


def same_plant(before, after):
    need(all(before[k] == after[k] for k in ('episode_id', 'boundary_id', 'policy', 'plant_identity', 'state_object_identity')),
         'Source object or runtime instance replaced')


def equal_except(before, after, keys):
    need({k: v for k, v in before.items() if k not in keys}
         == {k: v for k, v in after.items() if k not in keys}, 'Unexpected snapshot mutation')


def response(graphs, snap, offered):
    memory = snap['controller']; graph = graphs[memory['graph']]
    candidates = [t for t in graph['nodes'][memory['node_id']]['successors']
                  if graph['nodes'][t]['valuation'].get(HELPER, 'false') == 'false'
                  and all(graph['nodes'][t]['valuation'][k] == offered[k] for k in C.env)]
    need(len(candidates) == 1, 'Recorded offered input lacks unique raw graph response')
    return candidates[0], graph_source(graph, candidates[0])


def check_step(event, previous, graphs, old, phase, expected_target=None):
    need(event['event'] == 'step_committed' and event.get('phase') == phase and event.get('before') == previous,
         'Missing actual prefix/continuation commit or wrong before snapshot')
    after = event['runtime']; same_plant(previous, after)
    offered = event['offered_env']
    need(env_legal(previous['source_state'], offered, old), 'Executed illegal ENV input')
    target, source = response(graphs, previous, offered)
    need(expected_target is None or target == expected_target, 'Executed prefix private node differs')
    need(C.rho_s(previous['source_state'], source), 'Executed source SYS/AUX transition violation')
    need(after['source_state'] == source and all(after['source_state'][k] == offered[k] for k in C.env),
         'Committed plant differs from raw response')
    equal_except(previous, after, {'source_state', 'ticks', 'controller'})
    need(previous['paused'] is False and after['ticks'] == previous['ticks'] + 1, 'Commit pause/tick invariant')
    a, b = previous['controller'], after['controller']
    need(all(a[k] == b[k] for k in ('instance_identity', 'graph', 'graph_sha256', 'created_root', 'created_rank')),
         'Controller instance/root changed during step')
    need(b['node_id'] == target, 'Private commit absent or wrong')
    return after


def audit_episode(events, row, policy, graphs, certificates, certificate_refs, episode_result, step_bound=5):
    episode = row['id'] + '__' + policy
    need(events and all(e.get('runtime', {}).get('episode_id') == episode for e in events), 'Episode event partition')
    for event in events:
        check_snapshot(event['runtime'], graphs, episode, row['id'], policy)
        if 'before' in event:
            check_snapshot(event['before'], graphs, episode, row['id'], policy)
    pos = 0
    def take(name):
        nonlocal pos
        need(pos < len(events) and events[pos]['event'] == name, 'Expected event ' + name)
        e = events[pos]; pos += 1; return e
    boot = take('episode_boot')['runtime']; current = boot
    need(C.theta_e(boot['source_state']) and C.theta_s(boot['source_state']) and boot['source_state']['c'] == 'false',
         'Boot source initializer')
    need(boot['contract_mode'] == 'old_no_b1' and boot['epoch'] == 0 and boot['paused'] is False and boot['ticks'] == 0,
         'Boot mode/lifecycle')
    old_instance = boot['controller']['instance_identity']
    need(boot['controller']['graph'] == 'native' and boot['controller']['node_id'] == '0'
         and boot['controller']['rank'] == 0 and boot['controller']['created_root'] == '0'
         and boot['controller']['created_rank'] == 0 and boot['controller']['original_initial_flag'] is True,
         'Boot exact original native private memory')
    need(len(row['prefix_node_ids']) == 3 and row['prefix_input_bits'] == [''.join('1' if graph_source(graphs['native'], t)[k] == 'true' else '0' for k in C.env) for t in row['prefix_node_ids'][1:]], 'Frozen prefix input sequence')
    for target in row['prefix_node_ids'][1:]:
        current = check_step(take('step_committed'), current, graphs, True, 'frozen_old_native_prefix', target)
    prefix_steps = len(row['prefix_node_ids']) - 1
    need(current['source_state'] == row['source_state'] and current['controller']['node_id'] == row['reached_native_node']
         and current['controller']['rank'] == row['reached_rank'] and current['ticks'] == prefix_steps, 'Reached full boundary mismatch')
    need(current['source_state'][C.aux[2][0]] == 'S1' and current['source_state']['f3'] == current['source_state']['c'] == 'false'
         and not (C.theta_e(current['source_state']) and C.theta_s(current['source_state'])), 'Noninitial genuinely unanswered third-floor obligation')
    paused = take('boundary_paused_and_environment_changed')
    need(paused.get('before') == current and paused.get('removed_restriction') == 'G !b1', 'Atomic pause/declared mode change')
    after = paused['runtime']; same_plant(current, after)
    equal_except(current, after, {'paused', 'epoch', 'contract_mode'})
    need(after['paused'] is True and after['epoch'] == 1 and after['contract_mode'] == 'normal', 'Paused new-mode state')
    current = after
    decisions, chosen = [], None
    for cert in certificates:
        event = take('candidate_admission')
        need(event['runtime'] == current and event.get('certificates') == certificate_refs, 'Admission moved state or evidence pins')
        decision = event['decision']
        need(all(decision.get(k) == cert[k] for k in CERT_KEYS), 'Counterfeit candidate certificate binding/verdict')
        eligible = cert['strict'] and (policy == 'strict_only' or cert['cooperative'])
        considered = chosen is None
        need(decision.get('considered') is considered and decision.get('eligible_under_policy') is eligible
             and decision.get('selected') is (considered and eligible), 'Admission eligibility/order/selection mismatch')
        decisions.append(decision)
        if considered and eligible: chosen = cert
    need(episode_result.get('decisions') == decisions and episode_result.get('prefix_committed_steps') == prefix_steps,
         'Result decisions/prefix count differs from events')
    if chosen is None:
        event = take('admission_abstained'); need(event['runtime'] == current, 'Abstention mutated state')
        need(pos == len(events) and episode_result.get('selected_candidate') is None
             and episode_result.get('status') == 'COMPLETE_ADMISSION_ABSTAINED'
             and episode_result.get('final_snapshot') == current, 'Abstention outcome binding')
        return {'episode_id': episode, 'pass': True, 'selected_candidate': None, 'prefix_steps': prefix_steps,
                'continuation_steps': 0, 'outcome': 'COMPLETE_ADMISSION_ABSTAINED',
                'plant_identity': boot['plant_identity'], 'state_object_identity': boot['state_object_identity'],
                'old_controller_instance': old_instance}
    retaining = chosen['candidate'] == 'retain_old_native'
    install = take('controller_retained' if retaining else 'controller_installed')
    need(install.get('before') == current and install.get('candidate') == chosen['candidate']
         and install.get('certified_root') == chosen and install.get('certificates') == certificate_refs, 'Installation certificate binding')
    after = install['runtime']; same_plant(current, after); equal_except(current, after, {'controller'})
    memory = after['controller']
    need(memory['graph'] == GRAPH_FOR[chosen['candidate']] and memory['graph_sha256'] == chosen['graph_sha256']
         and memory['node_id'] == chosen['root_id'] and memory['rank'] == chosen['rank'], 'Installed exact stored private root')
    if retaining:
        need(memory == current['controller'] and memory['instance_identity'] == old_instance, 'Retain-old memory/instance changed')
    else:
        need(memory['instance_identity'] != old_instance and memory['created_root'] == chosen['root_id']
             and memory['created_rank'] == memory['rank'] == chosen['rank'], 'Replacement must create exact certified stored-rank memory')
    current = after
    resumed = take('resumed')['runtime']; equal_except(current, resumed, {'paused'})
    need(resumed['paused'] is False, 'Resume did not clear pause'); current = resumed
    script = row['post_update_inputs']
    expected_inputs = [dict(zip(C.env, ['true' if x == '1' else 'false' for x in bits]))
                       for bits in ('1010', '1000', '1000', '0000', '0000')]
    need(script == expected_inputs and step_bound == 5, 'Frozen five-input script')
    trail, progress, outcome = [current], [], None
    for step, offered in enumerate(script, 1):
        if not env_legal(current['source_state'], offered):
            event = take('script_input_refused')
            need(event['runtime'] == current and event.get('script_step') == step and event.get('offered_env') == offered,
                 'Illegal-script refusal changed state/input')
            outcome = 'FIXED_SCRIPT_ENV_REFUSED'
            break
        need(pos < len(events), 'Missing fixed script event')
        if events[pos]['event'] == 'response_rejected':
            event = take('response_rejected')
            target, source = response(graphs, current, offered)
            need(event['runtime'] == current and event.get('before') == current and event.get('offered_env') == offered
                 and event.get('phase') == 'frozen_five_input_script' and event.get('proposed_node_id') == target
                 and event.get('proposed_source_state') == source and not C.rho_s(current['source_state'], source),
                 'False response rejection or state mutation')
            outcome = 'FIXED_SCRIPT_RESPONSE_REJECTED'
            break
        event = take('step_committed')
        need(event.get('offered_env') == offered, 'Fixed input order changed')
        current = check_step(event, current, graphs, False, 'frozen_five_input_script')
        trail.append(current)
        state = current['source_state']
        progress.append({'commit': step, 'b1': state['b1'], 'b3': state['b3'], 'f1': state['f1'],
                         'f3': state['f3'], 'c': state['c'], 'm1': state[C.aux[0][0]], 'm3': state[C.aux[2][0]]})
    repeated = len(trail) >= 2 and trail[-1]['controller']['node_id'] == trail[-2]['controller']['node_id'] and trail[-1]['source_state'] == trail[-2]['source_state']
    hits = {n: current['source_state'][n] == 'S0' for n, _ in C.aux}
    fair_loop = repeated and all(hits.values())
    if outcome is None:
        outcome = 'EXECUTED_FAIR_SELF_LOOP' if fair_loop else 'FIXED_SCRIPT_COMPLETED_WITHOUT_FAIR_SELF_LOOP'
    observation = {'old_pending_m3_at_install': trail[0]['source_state'][C.aux[2][0]] == 'S1' and trail[0]['source_state']['f3'] == 'false',
                   'first_input_illegal_old_mode': not env_legal(trail[0]['source_state'], script[0], True),
                   'new_b1_observed': any(x['b1'] == 'true' for x in progress),
                   'old_f3_response_observed': any(x['f3'] == 'true' and x['c'] == 'false' for x in progress),
                   'old_m3_cleared': any(x['m3'] == 'S0' for x in progress),
                   'new_m1_pending_observed': any(x['m1'] == 'S1' for x in progress),
                   'new_f1_response_after_request': any(x['f1'] == 'true' and x['m1'] == 'S1' and x['c'] == 'false' for x in progress),
                   'new_m1_cleared_after_pending': any(x['m1'] == 'S1' and any(y['commit'] > x['commit'] and y['m1'] == 'S0' for y in progress) for x in progress),
                   'cancellation_used': any(x['c'] == 'true' for x in progress),
                   'executed_self_loop': repeated, 'fair_self_loop': fair_loop}
    event = take('script_observation')
    need(event['runtime'] == current and event.get('status') == outcome and event.get('progress') == progress
         and event.get('observations') == observation and event.get('SYS_justice_hits') == hits
         and event.get('ENV_justice_count') == 0, 'Fixed-script progress/response/clear/self-loop summary differs')
    finite_detail = {'trail': trail, 'progress': progress, 'observations': observation,
                     'SYS_justice_hits': hits, 'ENV_justice_count': 0}
    completed = take('episode_completed')
    need(completed['runtime'] == current and completed.get('selected_candidate') == chosen['candidate']
         and completed.get('outcome') == outcome and pos == len(events), 'Episode completion mismatch/extra events')
    need(type(episode_result.get('old_private_root', {}).get('rank')) is int
         and type(episode_result.get('installed_private_root', {}).get('rank')) is int,
         'Result private rank must be an integer')
    need(episode_result.get('status') == 'COMPLETE_EXECUTED_HANDOFF'
         and episode_result.get('selected_candidate') == chosen['candidate']
         and episode_result.get('old_private_root') == {'node_id': row['reached_native_node'], 'rank': row['reached_rank']}
         and episode_result.get('installed_private_root') == {'node_id': chosen['root_id'], 'rank': chosen['rank']}
         and episode_result.get('final_snapshot') == current, 'Result root/outcome identity')
    recorded = episode_result['outcome']; continuation_steps = len(trail) - 1
    need(recorded.get('status') == outcome and recorded.get('committed_continuation_steps') == continuation_steps
         and recorded.get('final_snapshot') == current, 'Result finite continuation differs')
    for k, v in finite_detail.items(): need(recorded.get(k) == v, 'Result cycle detail differs: ' + k)
    return {'episode_id': episode, 'pass': True, 'selected_candidate': chosen['candidate'], 'prefix_steps': prefix_steps,
            'continuation_steps': continuation_steps, 'outcome': outcome, 'retained_old_instance': retaining,
            'boundary_source_initializer_compatible': False, 'genuinely_unanswered_m3_preserved_at_install': True,
            'plant_identity': boot['plant_identity'], 'state_object_identity': boot['state_object_identity'],
            'old_controller_instance': old_instance, 'installed_controller_instance': memory['instance_identity']}


def run(plan_path, result_path):
    plan_ref, result_ref = pin(plan_path), pin(result_path)
    plan, result = decode_json(read_pin(plan_ref)), decode_json(read_pin(result_ref))
    need(plan.get('schema') == 'v58-pending-handoff-plan-v1' and same_pin(result.get('plan'), plan_ref), 'Runtime result/PLAN binding')
    need(result.get('schema') == 'v58-pending-executed-handoff-census-result-v1'
         and result.get('status') == 'COMPLETE_EXECUTED_HANDOFF_CENSUS' and result.get('input_integrity') == 'PASS',
         'Incomplete runtime census cannot receive a complete event audit')
    need(plan.get('continuation_steps_per_episode') == 5 and plan.get('policies') == list(POLICIES)
         and plan.get('candidate_order') == list(ARMS), 'Frozen runtime policy/bound')
    refs = gather_pins({'plan': plan, 'result': result})
    for ref in refs: read_pin(ref)
    need(read_pin(plan['old_source']) == read_pin(plan['source']) + b'\n\nassumption -- constructed_old_mode_no_b1\n\talw(b1=false);\n', 'Old source exact b1-only restriction')
    need(plan['source']['sha256'] == C.source_sha256 and plan['source']['bytes'] == C.source_bytes, 'Exact Lift source binding')
    need(result.get('scientific_native_or_compiler_calls') == 0 and result.get('full_reset_uses') == 0,
         'Runtime scope changed')
    execution_go = decode_json(read_pin(result['execution_go']))
    need(execution_go.get('status') == 'GO_EXACT_FROZEN_HANDOFF_RUNTIME'
         and same_pin(execution_go.get('plan'), plan_ref)
         and same_pin(execution_go.get('runtime_script'), result['runtime_script'])
         and execution_go.get('certificates') == result['certificates'], 'Exact runtime GO/result binding')
    roster = decode_json(read_pin(plan['roster']))
    need(roster['boundaries'] == plan['boundaries'] and len(plan['boundaries']) == 3, 'Exact complete frozen cohort')
    graphs = {name: graph_records(ref) for name, ref in plan['graphs'].items()}
    cert_refs = result['certificates']; need(set(cert_refs) == {'source', 'saved_model'}, 'Two external certificate routes')
    bundles = {route: decode_json(read_pin(ref)) for route, ref in cert_refs.items()}
    expected_ids = [b['id'] for b in plan['boundaries']]
    for route, bundle in bundles.items():
        need(bundle.get('schema') == 'v58-pending-rooted-graph-certificate-bundle-v1'
             and bundle.get('route') == route and bundle.get('status') == 'COMPLETE_ROOTED_CANDIDATES'
             and same_pin(bundle.get('plan'), plan_ref), 'Certificate route/PLAN binding')
        need(all(bundle['old_gate'].get(k) is True for k in ('complete', 'strict', 'cooperative', 'source_coverage')),
             'Old gate must pass in both independent routes')
        need([b['id'] for b in bundle['boundaries']] == expected_ids, 'Certificate boundary census')
    verdicts = {}
    for row, source_row, saved_row in zip(plan['boundaries'], bundles['source']['boundaries'], bundles['saved_model']['boundaries']):
        for cert_row in (source_row, saved_row):
            need(all(cert_row[k] == row[k] for k in ('id', 'source_state', 'reached_native_node', 'reached_rank')),
                 'Certificate boundary state/memory')
            need([c['candidate'] for c in cert_row['candidates']] == list(ARMS), 'Certificate arm order')
        compact = []
        for bound, a, b in zip(row['candidates'], source_row['candidates'], saved_row['candidates']):
            value = {k: a[k] for k in CERT_KEYS}
            need(type(a.get('rank')) is int and type(b.get('rank')) is int, 'Certificate rank must be an integer')
            need(value == {k: b[k] for k in CERT_KEYS}, 'Independent rooted verdict disagreement')
            need(value['candidate'] == bound['candidate'] and value['root_id'] == bound['root']
                 and value['rank'] == bound['rank'] and value['graph_sha256'] == plan['graphs'][bound['graph']]['sha256'],
                 'Candidate certificate root differs from frozen plan')
            need(all(type(value[k]) is bool for k in ('complete', 'strict', 'cooperative', 'source_coverage'))
                 and value['complete'] and value['source_coverage'], 'Complete Boolean candidate evidence required')
            compact.append(value)
        verdicts[row['id']] = compact
    events_raw = read_pin(result['events'])
    events = [decode_json(line) for line in events_raw.decode('utf-8').splitlines()]
    need(2 <= len(events) <= 4096 and len(events) == result['event_count'], 'Event census/size')
    need([e.get('seq') for e in events] == list(range(len(events))), 'Event sequence gap/duplication')
    need(len({e.get('pid') for e in events}) == 1 and type(events[0].get('pid')) is int and events[0]['pid'] > 0,
         'Event process identity')
    need(all(type(e.get('monotonic_ns')) is int for e in events)
         and all(a['monotonic_ns'] <= b['monotonic_ns'] for a, b in zip(events, events[1:])), 'Monotonic event clock')
    for e in events:
        need(datetime.datetime.fromisoformat(e['utc'].replace('Z', '+00:00')).tzinfo is not None, 'Event UTC timestamp')
    need(events[0]['event'] == 'census_started' and events[-1]['event'] == 'census_completed', 'Census lifecycle bounds')
    need(events[0].get('plan') == result['plan'] and events[0].get('execution_go') == result['execution_go']
         and events[0].get('certificates') == cert_refs, 'Census start bindings')
    expected = [(b, p) for b in plan['boundaries'] for p in POLICIES]
    need(len(result['episodes']) == result.get('expected_episodes') == 6, 'All six result rows required')
    groups, order = {}, []
    for e in events[1:-1]:
        episode = e.get('runtime', {}).get('episode_id')
        need(type(episode) is str, 'Unscoped event inside census')
        if not order or episode != order[-1]:
            need(episode not in groups, 'Interleaved/repeated episode block')
            order.append(episode); groups[episode] = []
        groups[episode].append(e)
    need(order == [b['id'] + '__' + p for b, p in expected], 'All six actual episode event blocks required')
    audited = []
    for (row, policy), episode_result in zip(expected, result['episodes']):
        episode = row['id'] + '__' + policy
        need(episode_result.get('episode_id') == episode and episode_result.get('boundary_id') == row['id']
             and episode_result.get('policy') == policy, 'Result episode census order')
        audited.append(audit_episode(groups[episode], row, policy, graphs, verdicts[row['id']], cert_refs,
                                     episode_result, plan['continuation_steps_per_episode']))
    need(len({a['plant_identity'] for a in audited}) == len({a['state_object_identity'] for a in audited}) == 6,
         'Separate episode plant/state instances required')
    old_instances = {a['old_controller_instance'] for a in audited}
    need(len(old_instances) == 6, 'Separate actual old-controller instances required across episodes')
    replacements = [a['installed_controller_instance'] for a in audited
                    if a.get('selected_candidate') is not None and not a['retained_old_instance']]
    need(len(set(replacements)) == len(replacements) and not set(replacements) & old_instances,
         'Replacement instances reused across episodes or from old controllers')
    expected_outcomes = [e.get('outcome', {}).get('status', e['status']) for e in result['episodes']]
    need(events[-1].get('episodes') == 6 and events[-1].get('outcomes') == expected_outcomes, 'Census completion summary')
    for ref in refs + [plan_ref, result_ref]: read_pin(ref)
    return {'schema': 'v58-pending-independent-source-event-audit-v1', 'status': 'PASS_ALL_6_EXECUTED_EPISODES',
            'plan': plan_ref, 'runtime_result': result_ref, 'events': result['events'], 'certificates': cert_refs,
            'auditor': pin(__file__), 'episode_count': 6, 'event_count': len(events), 'episodes': audited,
            'source_equations': pin(Path(__file__).with_name('source_contracts.py')),
            'runtime_imports': 0, 'source_object_preserved_each_episode': True, 'input_pins_unchanged': True,
            'scope': 'The recorded actual step/commit, atomic pause, admission, exact memory installation and bounded suffix are independently reconstructed. Universal strict/cooperative judgments are the separately bound complete-graph certificates; a finite prefix or lasso is not substituted for them.'}


def main():
    need(len(sys.argv) == 4, 'Usage: audit_handoff_events.py PLAN.json RESULT.json OUTPUT.json')
    plan_path, result_path, output = sys.argv[1:]
    try:
        result = run(plan_path, result_path)
    except (AuditError, OSError, KeyError, TypeError, ValueError) as error:
        result = {'schema': 'v58-pending-independent-source-event-audit-v1', 'status': 'FAIL_OR_UNKNOWN_EVENT_AUDIT',
                  'error': str(error), 'plan': pin(plan_path), 'runtime_result': pin(result_path)}
    save_new(output, result)
    print(json.dumps({'status': result['status'], 'output': pin(output)}))
    return 0 if result['status'].startswith('PASS') else 2


if __name__ == '__main__':
    raise SystemExit(main())
