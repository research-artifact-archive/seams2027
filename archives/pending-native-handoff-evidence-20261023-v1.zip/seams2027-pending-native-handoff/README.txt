Pending-request continuity after an environment-model change

This anonymous evidence snapshot records a fixed follow-up on the known Lift
source and saved native-produced controllers. The original two initial choices
and all three genuinely pending noninitial boundaries are retained. Both
certificate routes check all nine candidate roots. The six fixed episodes use
five post-update inputs each. No new synthesis, performance gain, held-out
generalization or failure-avoidance claim is made. Both admission policies can
serve the same requests on the fixed script.

Files under evidence/ are preserved scientific code and saved evidence, with
only declared path and dependent hash metadata changes. Controller nodes,
edges, valuations and stored ranks are unchanged. Model source-path relocation
changes the model hash, controller.model_sha256 and the graph JSON file hash;
dependent result and protocol pins follow in a recorded dependency order.
PUBLIC_PIN_MAP.json retains original byte hashes as lineage. TRANSFORMATIONS.json
identifies every changed pointer; original private values are represented by
hashes. Deliberately malformed qualification fixtures stay malformed.

Lift source bytes and derivatives are not redistributed. Obtain both pinned
inputs below before offline source reconstruction:

Fourth historical evidence archive (the exact name matters):
https://github.com/research-artifact-archive/seams2027/raw/refs/tags/lift-causal-evidence-20261021-v1/archives/lift-causal-extension-public-20261021-v1.zip
2986678 bytes; SHA256 64ba40d58edd2b5b04a7583c4e5ee32fe184b9d5c264026201fcfa5b4b747d07

Publisher HTML:
https://arxiv.org/html/2609.12231v1
1624775 bytes; SHA256 78a3adba587d3179008afefa9ef7cecc9bd9eacc030d64c64a30f9171955b8ee

tools/restore_pending_sources.py accepts --fourth-archive, --paper-html and a
fresh --output directory. It reads the exact restoration manifest member,
extracts downloadable listings LSTx13 and LSTx5, restores the omitted response
pattern, then appends the exact 59-byte no-b1 assumption for the old mode.
The outputs are 2218 bytes/SHA256 6a8f8220385130b2eb219ecfa33186b179d610ffcf805a30f9cab47ab204dae7
and 2277 bytes/SHA256 c57da4230023632ac31136787fa139569ab6e91facbab4adcb52b58adefbd16e.
The helper is offline only and does not execute code from the archive. The
historical archive's broader restoration helper also handles an upstream JAR;
that JAR and helper execution are not needed here.

tools/bind_pending_replay.py creates a separate fresh workspace from the
immutable MANIFEST.json, restored sources and an explicit Python interpreter.
It performs only file/metadata binding and emits BINDING_BRIDGE.json plus a
BOUND_NOT_AUTHORIZED session. It does not create a passing review or reuse an
old execution GO. An actual reviewer must inspect and approve the exact bound
plan, runtime and bridge before run_pending_replay_stage.py may be invoked.

The fixed order is: source old gate, saved-model old gate, agreement/adoption,
interface qualification, both candidate routes, fresh runtime GO, six runtime
episodes, independent event audit, then saved-event mutation qualification.
Each stage is once-only under the pinned process-group/resource supervisor.
The replay has no network dependency, native compilation/synthesis or automatic
usage reset. Source-byte restoration is not a scientific replay result.

tools/compare_pending_replay.py compares complete semantic records and all 98
events. It normalizes only verified file pins, clocks and checked identities,
including explicit preservation of deliberately invalid fixture values. The
assembly status alone is not a replay claim; consult the separately supplied
relocated-replay comparison receipt and its exact input/helper bindings.

All helpers use Python's standard library. The saved checker modules and their
dependencies are included; no hidden workspace source tree, JDK or JAR is
required. LICENSE and THIRD_PARTY_NOTICES.txt state the distribution boundary.

Runnable offline reproduction

The recorded execution environment is macOS with Python 3.10.9. Python 3.10+
syntax is required; other Python versions and operating systems are not
qualified by this release. The supervisor also requires POSIX process groups,
signals and resource limits, and a ps implementation supporting
  ps -axo pid=,ppid=,pgid=,rss=
These OS facilities are dependencies in addition to Python's standard library.
No claim of Windows compatibility is made.

In helper names, statuses and flags, "Root" means the reader operating their
own replay and reviewing its exact bytes. It does not mean an author-operated
service, an author account, or permission to contact the original authors.
The execution and ordinary-usage flags attest to the reader's actual decision
and available resource/usage budget. They do not obtain or reset any credits.

Use a POSIX shell. Set these six absolute paths for your own installation and
download locations. The two output directories must not exist; their parent
directories must already exist. The replay root must be outside the immutable
extracted bundle. Resolve any interpreter symlink before setting TASK_PYTHON.

  set -eu
  TASK_PYTHON='/absolute/path/to/python3.10'
  TASK_BUNDLE='/absolute/path/to/seams2027-pending-native-handoff'
  TASK_FOURTH_ARCHIVE='/absolute/path/to/lift-causal-extension-public-20261021-v1.zip'
  TASK_PAPER_HTML='/absolute/path/to/paper_2609.12231v1.html'
  TASK_RESTORED='/absolute/path/to/fresh-restored-sources'
  TASK_REPLAY='/absolute/path/to/fresh-pending-replay'

First check the downloaded release archive against its published checksum and
inspect its immutable MANIFEST.json. The local hashes below bind subsequent
commands to inspected bytes; computing a hash does not replace that review.

  task_sha256() {
    "$TASK_PYTHON" -c 'import hashlib,sys; from pathlib import Path; print(hashlib.sha256(Path(sys.argv[1]).read_bytes()).hexdigest())' "$1"
  }
  TASK_MANIFEST_SHA256="$(task_sha256 "$TASK_BUNDLE/MANIFEST.json")"
  "$TASK_PYTHON" -B "$TASK_BUNDLE/tools/restore_pending_sources.py" \
    --fourth-archive "$TASK_FOURTH_ARCHIVE" \
    --paper-html "$TASK_PAPER_HTML" \
    --output "$TASK_RESTORED"
  "$TASK_PYTHON" -B "$TASK_BUNDLE/tools/bind_pending_replay.py" \
    --bundle-root "$TASK_BUNDLE" \
    --expected-manifest-sha256 "$TASK_MANIFEST_SHA256" \
    --restored-sources "$TASK_RESTORED" \
    --replay-root "$TASK_REPLAY" \
    --python "$TASK_PYTHON"

The restoration creates exactly two byte contents: lift_new.spectra and
lift_old_no_b1.spectra. Binding creates four separately named input files:
the two protocol inputs and the two original model.input aliases of the new
source. PUBLIC_BINDINGS.json records each alias's restored_from basename.
The distinct aliases preserve the saved checker's original input-ledger
cardinality and order; identical source bytes do not merge those paths.

Binding returns BOUND_NOT_AUTHORIZED. Before executing a scientific stage,
read _portable_replay/REVIEW_REQUIRED.json, BINDING_BRIDGE.json and SESSION.json,
the exact PLAN.json and runtime file they pin, the declared dependencies and
all metadata changes. Check that only declared paths and dependent file pins
changed, that graph/state/rank/script content is preserved, and that limits,
all three candidate arms, nine roots and six episodes match the fixed protocol.

Record your actual review in a new file at
  "$TASK_REPLAY/_portable_replay/REVIEW.json"
It must be a JSON object with these fields:
  status: a string starting with PASS only if your review actually passed;
  portable_binding_review: true only after that inspection;
  scientific_execution_authorized: true only after your execution decision;
  plan: the exact {path, bytes, sha256} object from REVIEW_REQUIRED.json;
  runtime: the exact {path, bytes, sha256} object from REVIEW_REQUIRED.json;
  binding_bridge: the exact {path, bytes, sha256} object from REVIEW_REQUIRED.json.
Add the review findings and scope in your own words. Do not manufacture a PASS
record by renaming REVIEW_REQUIRED.json or copying a previous execution's GO.
The package deliberately has no command that generates a passing review.

After that review and execution decision, hash the session and your review.
The following function performs exactly one named stage. A failed or unknown
stage must remain recorded and stops this sequence; do not delete its attempt
journal/lock or silently rerun it. All ten stages use the pinned supervisor.

  TASK_SESSION="$TASK_REPLAY/_portable_replay/SESSION.json"
  TASK_REVIEW="$TASK_REPLAY/_portable_replay/REVIEW.json"
  TASK_SESSION_SHA256="$(task_sha256 "$TASK_SESSION")"
  TASK_REVIEW_SHA256="$(task_sha256 "$TASK_REVIEW")"
  task_run_stage() {
    "$TASK_PYTHON" -B "$TASK_REPLAY/_portable_replay/tools/run_pending_replay_stage.py" \
      --session "$TASK_SESSION" \
      --expected-session-sha256 "$TASK_SESSION_SHA256" \
      --review "$TASK_REVIEW" \
      --expected-review-sha256 "$TASK_REVIEW_SHA256" \
      --stage "$1" \
      --confirmed-root-controlled-execution \
      --ordinary-usage-gate-confirmed
  }
  task_run_stage old_source
  task_run_stage old_saved
  task_run_stage old_adoption
  task_run_stage interfaces
  task_run_stage candidate_source
  task_run_stage candidate_saved
  task_run_stage runtime_go
  task_run_stage runtime
  task_run_stage event_audit
  task_run_stage event_mutations

Inspect each stage's attempt, complete output and PROCESS.json. A PASS_STAGE
requires the expected result status, unchanged frozen inputs, a reaped child
and no remaining process-group members. The final comparator requires every
stage to have completed with the same session and review, and compares all
44 semantic records, including the complete 98-event stream and 16 mutation
fixtures. Its output path must also be fresh.

  "$TASK_PYTHON" -B "$TASK_REPLAY/_portable_replay/tools/compare_pending_replay.py" \
    --session "$TASK_SESSION" \
    --expected-session-sha256 "$TASK_SESSION_SHA256" \
    --output "$TASK_REPLAY/_portable_replay/REPLAY_COMPARISON.json"

Only PASS_RELOCATED_REPLAY establishes this complete replay comparison.
Preserve the full replay directory, review, attempts, process receipts and
comparison receipt together. Source restoration PASS, binding success and
assembly integrity remain narrower results.
