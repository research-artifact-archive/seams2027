#!/usr/bin/env python3
"""Compare complete saved/replayed semantic records without scientific imports.

Only verified file-binding metadata, observed clocks and checked process/object
identities are normalized. Roots, ranks, states, transitions, scripts, verdicts,
qualification rows, unknown outcomes and every event remain in the comparison.
"""
import argparse
import datetime
from pathlib import Path
from pending_public_common import below, canonical, decode, digest, need, pin, verify, write_new
from run_pending_replay_stage import STAGES

AUDIT_RECORDS = {
    "experiment/v58_submission_20261023/pending_handoff/execution/EVENT_AUDIT.json",
    "experiment/v58_submission_20261023/pending_handoff/execution/event_mutations_01/POSITIVE_AUDIT.json",
}


def amended_bundle(args, session, session_ref):
    """Accept a separately reviewed comparator-only revision; retain execution bytes."""
    original_bundle = Path(session["bundle_root"])
    if args.comparison_amendment is None:
        need(args.expected_amendment_sha256 is None, "Amendment hash without an amendment")
        need(pin(__file__) == session["comparer"], "Comparator code binding")
        return original_bundle, session["public_manifest"], None
    amendment_ref = pin(args.comparison_amendment)
    need(amendment_ref["sha256"] == args.expected_amendment_sha256, "Exact amendment hash")
    amendment = decode(args.comparison_amendment.read_bytes())
    need(amendment["schema"] == "pending-comparison-metadata-amendment-v1"
         and amendment["status"] == "ROOT_ACCEPTED_COMPARATOR_ONLY_AMENDMENT"
         and amendment["scientific_executions_authorized"] is False,
         "Explicit comparison-only amendment required")
    need(amendment["session"] == session_ref
         and amendment["original_comparer"] == session["comparer"]
         and amendment["original_manifest"] == session["public_manifest"], "Original execution binding")
    need(pin(__file__) == amendment["corrected_comparer"], "Corrected comparator code binding")
    need(args.output.resolve() == Path(amendment["comparison_output"]).resolve(),
         "The one fresh comparison output is fixed by the accepted amendment")
    for key in ("original_comparer", "original_manifest", "revised_manifest", "previous_comparison"):
        need(pin(amendment[key]["path"]) == amendment[key], "Amendment input changed: " + key)
    previous = decode(Path(amendment["previous_comparison"]["path"]).read_bytes())
    need(previous["status"] == "FAIL_SEMANTIC_COMPARISON" and previous["session"] == session_ref
         and previous["comparer"] == session["comparer"]
         and previous["public_manifest"] == session["public_manifest"], "Retained original failure binding")
    need(len(previous["checks"]) == 44
         and {r["path"] for r in previous["checks"] if r["pass"] is False} == AUDIT_RECORDS
         and sum(r["pass"] is True for r in previous["checks"]) == 42, "Exact original42/44 outcome")
    need(previous["stage_attempts"] == [pin(args.session.parent / "attempts" / (stage + ".json"))
                                         for stage in STAGES],
         "The exact ten attempts referenced by the original failure must remain unchanged")
    old_manifest = decode(Path(amendment["original_manifest"]["path"]).read_bytes())
    new_manifest = decode(Path(amendment["revised_manifest"]["path"]).read_bytes())
    revised_bundle = Path(amendment["revised_manifest"]["path"]).parent
    need({k:v for k,v in old_manifest.items() if k != "files"}
         == {k:v for k,v in new_manifest.items() if k != "files"}, "Manifest scope unchanged")
    need([r["path"] for r in old_manifest["files"]] == [r["path"] for r in new_manifest["files"]],
         "Exact bundle member roster/order unchanged")
    for old, new in zip(old_manifest["files"], new_manifest["files"]):
        old_raw = verify(below(original_bundle, old["path"]), old)
        new_raw = verify(below(revised_bundle, new["path"]), new)
        if old["path"] == "tools/compare_pending_replay.py":
            need(digest(old_raw) == {k: session["comparer"][k] for k in ("bytes", "sha256")}
                 and digest(new_raw) == {k: amendment["corrected_comparer"][k] for k in ("bytes", "sha256")},
                 "Only the reviewed comparator bytes may change")
        else:
            need(old == new and old_raw == new_raw, "Non-comparator bundle member changed")
    need({p.relative_to(revised_bundle).as_posix() for p in revised_bundle.rglob("*") if p.is_file()}
         == {r["path"] for r in new_manifest["files"]} | {"MANIFEST.json"}, "Revised bundle has extras")
    return revised_bundle, amendment["revised_manifest"], amendment_ref


def audit_summary_identities(value, tokens, episode_ids):
    """Bind the two summary aliases to the already verified same-episode objects."""
    need(value["status"] == "PASS_ALL_6_EXECUTED_EPISODES"
         and [e["episode_id"] for e in value["episodes"]] == episode_ids, "Exact six audit summaries")
    result = {}
    for index, row in enumerate(value["episodes"]):
        eid = row["episode_id"]
        need(type(row["retained_old_instance"]) is bool, "Typed retained-instance summary")
        retained_from_events = "INSTALLED_CONTROLLER:" + eid not in tokens.values()
        need(row["retained_old_instance"] is retained_from_events,
             "Retained-instance summary must agree with the recorded installation event")
        expected = {"plant_identity": "PLANT:" + eid, "state_object_identity": "SOURCE:" + eid,
                    "old_controller_instance": "OLD_CONTROLLER:" + eid,
                    "installed_controller_instance": ("OLD_CONTROLLER:" if retained_from_events
                                                       else "INSTALLED_CONTROLLER:") + eid}
        for field, token in expected.items():
            need(type(row[field]) is int and tokens.get(row[field]) == token,
                 "Audit summary object must match its same-episode verified event object")
            if field in {"old_controller_instance", "installed_controller_instance"}:
                result["/episodes/" + str(index) + "/" + field] = token
    return result


def event_identities(events, owned_pid, episode_ids):
    need(len(events) == 98 and [e["seq"] for e in events] == list(range(98)), "Exact ordered 98 events")
    need(events[0]["event"] == "census_started" and events[-1]["event"] == "census_completed", "Census endpoints")
    need(all(type(e["pid"]) is int and e["pid"] == owned_pid for e in events), "Owned event process identity")
    clocks = [e["monotonic_ns"] for e in events]
    need(all(type(v) is int and v >= 0 for v in clocks)
         and all(a <= b for a, b in zip(clocks, clocks[1:])), "Monotonic event clock")
    episodes, tokens, source_ids = {}, {}, []

    def assign(value, token):
        need(type(value) is int and value > 0 and (value not in tokens or tokens[value] == token),
             "Object identity collision or invalid token")
        tokens[value] = token

    for event in events:
        if "runtime" not in event:
            continue
        snap = event["runtime"]
        eid, memory = snap["episode_id"], snap["controller"]
        if event["event"] == "episode_boot":
            need(eid not in episodes, "Duplicate episode boot")
            episodes[eid] = {"plant": snap["plant_identity"], "source": snap["state_object_identity"],
                             "old": memory["instance_identity"], "active": memory["instance_identity"],
                             "installed": False, "terminal": False}
            assign(snap["plant_identity"], "PLANT:" + eid)
            assign(snap["state_object_identity"], "SOURCE:" + eid)
            assign(memory["instance_identity"], "OLD_CONTROLLER:" + eid)
            source_ids.append(snap["state_object_identity"])
        need(eid in episodes, "Event before episode boot")
        state = episodes[eid]
        need(not state["terminal"] and snap["plant_identity"] == state["plant"]
             and snap["state_object_identity"] == state["source"], "Plant/source identity continuity")
        if event["event"] == "controller_installed":
            need(not state["installed"] and memory["instance_identity"] != state["old"], "Single replacement identity")
            state["active"] = memory["instance_identity"]
            state["installed"] = True
            assign(memory["instance_identity"], "INSTALLED_CONTROLLER:" + eid)
        if event["event"] == "controller_retained":
            need(not state["installed"] and memory["instance_identity"] == state["old"], "Retained controller identity")
        need(memory["instance_identity"] == state["active"], "Active controller continuity")
        if "before" in event:
            before = event["before"]
            need(before["episode_id"] == eid and before["plant_identity"] == state["plant"]
                 and before["state_object_identity"] == state["source"], "Before/after plant/source continuity")
            prior = state["old"] if event["event"] == "controller_installed" else state["active"]
            need(before["controller"]["instance_identity"] == prior, "Before/after controller continuity")
        if event["event"] == "episode_completed":
            state["terminal"] = True
    need(list(episodes) == episode_ids and all(s["terminal"] for s in episodes.values()), "All six complete episodes")
    need(len(set(source_ids)) == 6, "Distinct live episode source objects")
    return tokens, source_ids


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--session", required=True, type=Path)
    parser.add_argument("--expected-session-sha256", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--comparison-amendment", type=Path)
    parser.add_argument("--expected-amendment-sha256")
    args = parser.parse_args()
    need(not args.output.exists(), "Fresh comparison receipt required")
    session_ref = pin(args.session)
    need(session_ref["sha256"] == args.expected_session_sha256, "Exact session hash")
    session = decode(args.session.read_bytes())
    need(session["schema"] == "pending-handoff-portable-replay-session-v1", "Session schema")
    root = Path(session["root"])
    bundle, public_manifest_ref, amendment_ref = amended_bundle(args, session, session_ref)
    manifest = decode(verify(bundle / "MANIFEST.json", public_manifest_ref))
    public = {row["path"]: verify(below(bundle, row["path"]), row) for row in manifest["files"]}
    contract = decode(public["PUBLIC_BINDINGS.json"])
    pin_map = decode(public["PUBLIC_PIN_MAP.json"])["files"]
    rows = {row["path"]: row for row in contract["files"]}
    need(len(rows) == len(contract["files"]), "Unique public file inventory")
    for ref in session["inputs"] + session["helper_inputs"] + [session[k] for k in
        ("public_manifest", "public_bindings", "python", "restoration_receipt", "binding_bridge", "limits")]:
        need(pin(ref["path"]) == ref, "Frozen input changed before comparison")
    attempts = {}
    for stage in STAGES:
        record = decode((args.session.parent / "attempts" / (stage + ".json")).read_bytes())
        need(record["status"] == "PASS_STAGE" and record["session"] == session_ref, "Every stage must complete once")
        need(pin(record["output"]["path"]) == record["output"]
             and pin(record["process"]["path"]) == record["process"], "Stage output/process pin")
        process = decode(Path(record["process"]["path"]).read_bytes())
        need(process["status"] == "COMPLETE" and process["exit_code"] == 0 and process["owned_child_reaped"] is True
             and not process["violations"] and process["final_group_observation"] == {"state": "ABSENT", "members": []},
             "Owned process completion")
        attempts[stage] = record
    review_ref = attempts["runtime"]["review"]
    need(all(a["review"] == review_ref for a in attempts.values()) and pin(review_ref["path"]) == review_ref,
         "One exact Root review throughout replay")
    comparison = session["comparison"]
    old_events_path = comparison["events"]
    old_events = [decode(line) for line in public["evidence/" + old_events_path].splitlines()]
    new_events = [decode(line) for line in below(root, old_events_path).read_bytes().splitlines()]
    old_process = decode(public["evidence/" + comparison["original_runtime_process"]])
    new_process = decode(Path(attempts["runtime"]["process"]["path"]).read_bytes())
    plan = decode(Path(session["plan"]["path"]).read_bytes())
    eids = [b["id"] + "__" + policy for b in plan["boundaries"] for policy in plan["policies"]]
    old_ids, old_source_ids = event_identities(old_events, old_process["owned_pid"], eids)
    new_ids, new_source_ids = event_identities(new_events, new_process["owned_pid"], eids)
    original_hashes = {r["path"]: r["original"]["sha256"] for r in pin_map}
    # Duplicate identical original files share the same lineage hash token.
    old_hash_tokens, new_hash_tokens = {}, {}
    for row in pin_map:
        token = "FILE_LINEAGE:" + row["original"]["sha256"]
        for key in ("original", "public"):
            old_hash_tokens[row[key]["sha256"]] = token
        runtime = below(root, row["path"])
        if runtime.is_file():
            new_hash_tokens[pin(runtime)["sha256"]] = token
    external = {r["path"]: r for r in contract["external_sources"]}
    for row in external.values():
        token = "RESTORED_SOURCE:" + row["sha256"]
        old_hash_tokens[row["sha256"]] = new_hash_tokens[row["sha256"]] = token
    aliases = comparison.get("omitted_review_aliases", [])
    old_aliases = {(a["bytes"], a["sha256"]): a["token"] for a in aliases}
    need(set(old_aliases.values()) == {"EXACT_RUNTIME_REVIEW"}, "Only the omitted historical review may be aliased")
    summary_aliases = {}

    def normalize(value, side, filename, pointer="", field=None):
        ids = old_ids if side == "old" else new_ids
        source_ids = old_source_ids if side == "old" else new_source_ids
        hash_tokens = old_hash_tokens if side == "old" else new_hash_tokens
        if isinstance(value, dict):
            if {"path", "bytes", "sha256"} <= set(value):
                shape = {k: value[k] for k in ("path", "bytes", "sha256")}
                old_alias = old_aliases.get((shape["bytes"], shape["sha256"])) if side == "old" else None
                if old_alias is not None or (side == "new" and shape == review_ref):
                    token = "EXACT_RUNTIME_REVIEW"
                else:
                    prefix = "@ROOT@/" if side == "old" else str(root) + "/"
                    need(shape["path"].startswith(prefix), "Undeclared comparison file pin: " + filename + pointer)
                    name = shape["path"][len(prefix):]
                    actual = (external[name] if name in external else digest(public["evidence/" + name])) if side == "old" else pin(below(root, name))
                    invalid = filename.endswith("/stale_certificate/MUTATED_RESULT.json") and pointer == "/certificates/source"
                    need(shape["bytes"] == actual["bytes"] and shape["sha256"] == ("0" * 64 if invalid else actual["sha256"]),
                         "Unverified comparison pin: " + filename + pointer)
                    token = "DECLARED_STALE_SOURCE_CERTIFICATE" if invalid else "BOUND_FILE:" + name
                return {k: (token if k == "path" else "VERIFIED_METADATA" if k in {"bytes", "sha256"}
                            else normalize(v, side, filename, pointer + "/" + k, k)) for k, v in value.items()}
            return {k: normalize(v, side, filename, pointer + "/" + k, k) for k, v in value.items()}
        if isinstance(value, list):
            return [normalize(v, side, filename, pointer + "/" + str(i), field) for i, v in enumerate(value)]
        if field in {"old_controller_instance", "installed_controller_instance"}:
            need(filename in AUDIT_RECORDS and (side, filename, pointer) in summary_aliases,
                 "Controller summary alias outside exact audited episode field")
            return summary_aliases[(side, filename, pointer)]
        if field in {"plant_identity", "state_object_identity", "instance_identity"}:
            need(type(value) is int, "Object identity must be an integer")
            if value in ids:
                return ids[value]
            if "/replaced_source_object/" in filename and field == "state_object_identity":
                matches = [v for v in source_ids if value == v + 1]
                need(len(matches) == 1, "Exact declared source-object mutation")
                return "DECLARED_PLUS_ONE_MUTATION:" + ids[matches[0]]
            raise ValueError("Unknown object identity: " + filename + pointer)
        if field in {"started_utc", "finished_utc", "created_utc", "utc"}:
            need(type(value) is str and datetime.datetime.fromisoformat(value.replace("Z", "+00:00")).tzinfo is not None,
                 "Timezone-aware recorded UTC required")
            return "VALIDATED_UTC"
        if field == "monotonic_ns":
            need(type(value) is int and value >= 0, "Recorded monotone counter type")
            return "VALIDATED_MONOTONIC_COUNTER"
        if field == "pid":
            need(value == (old_process if side == "old" else new_process)["owned_pid"], "Owned runtime PID")
            return "OWNED_RUNTIME_PROCESS"
        if type(value) is str:
            if value in hash_tokens:
                return hash_tokens[value]
            return value.replace(str(root) + "/", "@ROOT@/") if side == "new" else value
        return value

    checks = []
    for row in comparison["records"]:
        name = row["path"]
        need(name in rows and row["format"] == rows[name]["format"], "Comparison must name an included exact format")
        a, b = public["evidence/" + name], below(root, name).read_bytes()
        if row["format"] == "json":
            a, b = decode(a), decode(b)
            if name in AUDIT_RECORDS:
                for side, value, tokens in (("old", a, old_ids), ("new", b, new_ids)):
                    for pointer, token in audit_summary_identities(value, tokens, eids).items():
                        summary_aliases[(side, name, pointer)] = token
        elif row["format"] == "jsonl":
            a, b = [decode(line) for line in a.splitlines()], [decode(line) for line in b.splitlines()]
        else:
            need(row["format"] == "bytes", "Unsupported comparison format")
            checks.append({"path": name, "pass": a == b,
                           "original_bytes": digest(a), "replay_bytes": digest(b)})
            continue
        left, right = normalize(a, "old", name), normalize(b, "new", name)
        # Canonical JSON equality distinguishes true/1 and 1/1.0, which Python
        # container equality would conflate in the rank mutation fixtures.
        checks.append({"path": name, "pass": canonical(left) == canonical(right),
                       "normalized_original": digest(canonical(left)),
                       "normalized_replay": digest(canonical(right))})
    need(any(r["path"] == old_events_path for r in comparison["records"]), "Full event sequence must be compared")
    for row in manifest["files"]:
        verify(below(bundle, row["path"]), row)
    for ref in session["inputs"] + session["helper_inputs"]:
        need(pin(ref["path"]) == ref, "Immutable runtime input changed after comparison")
    need(pin(args.session) == session_ref, "Session changed during comparison")
    need(pin(bundle / "MANIFEST.json") == public_manifest_ref, "Public manifest changed during comparison")
    if amendment_ref is not None:
        need(pin(args.comparison_amendment) == amendment_ref, "Amendment changed during comparison")
        # Recheck the old failure, both bundle snapshots and exact corrected code.
        amended_bundle(args, session, session_ref)
    receipt = {"schema": "pending-handoff-relocated-replay-comparison-v1",
               "status": "PASS_RELOCATED_REPLAY" if all(c["pass"] for c in checks) else "FAIL_SEMANTIC_COMPARISON",
               "session": session_ref, "public_manifest": public_manifest_ref,
               "binding_bridge": session["binding_bridge"], "comparer": pin(__file__),
               "checks": checks, "stage_attempts": [pin(args.session.parent / "attempts" / (s + ".json")) for s in STAGES],
               "event_count": 98, "episode_count": 6, "all_process_groups_reaped_and_absent": True,
               "normalization": ["verified file path/byte/hash metadata", "the declared omitted exact runtime review",
                                  "validated UTC/monotonic clocks", "owned PID", "validated plant/source/controller identities",
                                  "the exact plus-one source-identity and zero-digest mutation fixtures"],
               "scientific_executions_by_comparison": 0}
    if amendment_ref is not None:
        amendment = decode(args.comparison_amendment.read_bytes())
        receipt.update(comparison_amendment=amendment_ref,
                       execution_public_manifest=session["public_manifest"],
                       execution_comparer=session["comparer"],
                       previous_failed_comparison=amendment["previous_comparison"],
                       corrected_summary_alias_fields=["old_controller_instance", "installed_controller_instance"],
                       scientific_stages_repeated_for_comparison_correction=0)
    write_new(args.output, receipt)
    print(receipt["status"])
    if receipt["status"] != "PASS_RELOCATED_REPLAY":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
