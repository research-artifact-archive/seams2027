"""Strict file/metadata operations for the pending-handoff publication helpers.

Only the Python standard library is used. This module has no study imports,
source predicates, BDD operations, fairness checks, controller steps or network.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path, PurePosixPath


def need(ok, message):
    if not ok:
        raise ValueError(message)


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def digest(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def unique(pairs):
    out = {}
    for key, value in pairs:
        need(key not in out, "Duplicate JSON key: " + key)
        out[key] = value
    return out


def decode(raw):
    return json.loads(raw.decode("utf-8"), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def relative(value):
    need(type(value) is str and value and "\\" not in value, "Relative POSIX name required")
    p = PurePosixPath(value)
    need(not p.is_absolute() and all(part not in ("", ".", "..") for part in value.split("/")),
         "Unsafe relative name: " + value)
    need(p.as_posix() == value, "Noncanonical relative name")
    return value


def below(root, name):
    root = Path(root).resolve()
    path = root / relative(name)
    need(path.resolve().is_relative_to(root), "Path escaped root")
    for item in [path, *path.parents]:
        if item == root:
            break
        need(not item.is_symlink(), "Symlink in path: " + str(item))
    return path


def pin(path):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), "Regular nonsymlink input required")
    return {"path": str(path.resolve()), **digest(path.read_bytes())}


def verify(path, expected):
    raw = Path(path).read_bytes()
    need(digest(raw) == {k: expected[k] for k in ("bytes", "sha256")},
         "Input byte/hash mismatch: " + str(path))
    return raw


def write_new(path, value, raw=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(value if raw else encoded(value))


def tokens(pointer):
    need(type(pointer) is str and pointer.startswith("/"), "Non-root JSON pointer required")
    return [part.replace("~1", "/").replace("~0", "~") for part in pointer[1:].split("/")]


def at(value, pointer):
    for part in tokens(pointer):
        value = value[int(part)] if isinstance(value, list) else value[part]
    return value


def put(value, pointer, replacement):
    parts = tokens(pointer)
    for part in parts[:-1]:
        value = value[int(part)] if isinstance(value, list) else value[part]
    key = int(parts[-1]) if isinstance(value, list) else parts[-1]
    need(key in range(len(value)) if isinstance(value, list) else key in value,
         "Metadata edit cannot create a new field")
    value[key] = replacement


def pointer_items(value, pointer=""):
    yield pointer, value
    if isinstance(value, dict):
        for key, child in value.items():
            escaped = key.replace("~", "~0").replace("/", "~1")
            yield from pointer_items(child, pointer + "/" + escaped)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from pointer_items(child, pointer + "/" + str(index))


def validate_rule(row, rule):
    op, pointer = rule["op"], rule["pointer"]
    leaf = tokens(pointer)[-1]
    need(op in {"pin", "file_pin", "digest", "bytes", "path", "redact", "historical_pin", "invalid_stale_pin"},
         "Unknown metadata operation")
    need(row["format"] in {"json", "jsonl"}, "No editing byte-preserved payloads")
    if row.get("role") == "controller":
        need(op == "digest" and pointer == "/model_sha256", "Only controller model binding may change")
    if row.get("role") == "model":
        need(pointer in {"/input", "/input/path"} and op in {"pin", "path"},
             "Only model input binding may change")
    need(not any(part in {"nodes", "edges", "valuation", "successors", "source_state", "post_update_inputs"}
                 for part in tokens(pointer)), "Scientific graph/state/script content cannot be rewritten")
    if op == "digest":
        need(leaf == "sha256" or leaf.endswith("_sha256"), "Digest field required")
    if op == "bytes":
        need(leaf == "bytes", "Byte-count field required")
    if op in {"redact", "historical_pin"}:
        need(type(rule.get("reason")) is str and rule["reason"], "Explicit omission/provenance reason required")
    if op == "invalid_stale_pin":
        need(row["path"].endswith("/stale_certificate/MUTATED_RESULT.json")
             and pointer == "/certificates/source", "Only the declared zero-digest mutation may remain invalid")
    if op in {"pin", "file_pin", "digest", "bytes", "path", "invalid_stale_pin"}:
        relative(rule["target"])


def transform(files, rows, externals, root_prefix, output_names=()):
    """Apply an explicit pointer allowlist in dependency order, never study code.

    `files` holds verified input bytes. Sources omitted from the archive are
    represented by exact external pins. Each pin/digest operation validates its
    old hash against the original target before using the transformed target.
    Public paths use @ROOT@; replay paths use an actual fresh absolute root.
    """
    definitions = {relative(row["path"]): row for row in rows}
    need(len(definitions) == len(rows) and set(definitions) == set(files), "Exact unique file roster")
    external_pins = {relative(row["path"]): {k: row[k] for k in ("bytes", "sha256")}
                     for row in externals}
    need(not set(definitions) & set(external_pins), "External/included path collision")
    original = {name: digest(raw) for name, raw in files.items()} | external_pins
    result, changes, visiting = {}, [], set()
    outputs = set(map(relative, output_names))

    def located(name):
        return root_prefix.rstrip("/") + "/" + name

    def target_pin(name):
        if name in definitions:
            visit(name)
            return digest(result[name])
        need(name in external_pins, "Undeclared file dependency: " + name)
        return external_pins[name]

    def visit(name):
        if name in result:
            return
        need(name not in visiting, "Metadata dependency cycle at " + name)
        visiting.add(name)
        row, raw = definitions[name], files[name]
        rules = row.get("operations", [])
        need(len({r["pointer"] for r in rules}) == len(rules), "Duplicate metadata pointer: " + name)
        if not rules:
            result[name] = raw
            visiting.remove(name)
            return
        value = decode(raw) if row["format"] == "json" else [decode(line) for line in raw.splitlines()]
        before = deepcopy(value)
        for rule in rules:
            validate_rule(row, rule)
            op, pointer = rule["op"], rule["pointer"]
            old = deepcopy(at(value, pointer))
            if op in {"pin", "file_pin", "digest", "bytes", "invalid_stale_pin"}:
                target = rule["target"]
                need(target in original, "Missing declared reference target")
                new_pin = target_pin(target)
                if op == "invalid_stale_pin":
                    need(isinstance(old, dict) and old["sha256"] == "0" * 64
                         and old["bytes"] == original[target]["bytes"], "Exact deliberately stale source-certificate pin")
                    new = dict(old, path=located(target), bytes=new_pin["bytes"])
                elif op in {"pin", "file_pin"}:
                    need(isinstance(old, dict), "Pin object required")
                    need({k: old[k] for k in ("bytes", "sha256")} == original[target],
                         "Original reference does not bind target: " + name + pointer)
                    new = dict(old, **new_pin)
                    if op == "pin":
                        need(type(old.get("path")) is str, "Path pin required")
                        new["path"] = located(target)
                    else:
                        need(type(old.get("file")) is str, "Relative native file pin required")
                else:
                    key = "sha256" if op == "digest" else "bytes"
                    need(old == original[target][key], "Original standalone digest/size mismatch")
                    new = new_pin[key]
            elif op == "path":
                target = rule["target"]
                need(type(old) is str and target in set(original) | outputs,
                     "Path must target declared input or output")
                new = located(target)
            elif op == "redact":
                need(type(old) is str and type(rule["value"]) is str, "String provenance redaction only")
                new = rule["value"]
            else:
                need(isinstance(old, dict) and {"path", "bytes", "sha256"} <= set(old), "Historical pin required")
                new = dict(old, path="origin:omitted:" + old["sha256"])
            put(value, pointer, new)
            if old != new:
                changes.append({"path": name, "pointer": pointer, "operation": op,
                                "old_value_sha256": digest(encoded(old))["sha256"],
                                "new_value": new, "reason": rule.get("reason", "Declared location/dependency binding")})
        # Operation types above preserve all non-metadata values and structures.
        if row.get("role") == "controller":
            a, b = deepcopy(before), deepcopy(value)
            a.pop("model_sha256"); b.pop("model_sha256")
            need(a == b, "Scientific controller graph changed")
        result[name] = encoded(value) if row["format"] == "json" else b"".join(
            json.dumps(v, ensure_ascii=False, allow_nan=False).encode() + b"\n" for v in value)
        visiting.remove(name)

    for name in definitions:
        visit(name)
    return result, changes


def validate_path_closure(files, rows, externals, prefix):
    """Reject implicit runnable paths; report explicitly declared provenance omissions."""
    available = {name: digest(raw) for name, raw in files.items()} | {
        row["path"]: {k: row[k] for k in ("bytes", "sha256")} for row in externals}
    closure = []
    for row in rows:
        if row["format"] not in {"json", "jsonl"}:
            continue
        raw = files[row["path"]]
        value = decode(raw) if row["format"] == "json" else [decode(line) for line in raw.splitlines()]
        historical = {r["pointer"] for r in row.get("operations", []) if r["op"] == "historical_pin"}
        invalid = {r["pointer"] for r in row.get("operations", []) if r["op"] == "invalid_stale_pin"}
        for pointer, obj in pointer_items(value):
            if not isinstance(obj, dict) or not {"path", "bytes", "sha256"} <= set(obj):
                continue
            if pointer in historical:
                need(obj["path"] == "origin:omitted:" + obj["sha256"], "Historical omission marker")
                kind = "DECLARED_HISTORICAL_NOT_RUNNABLE"
            else:
                need(type(obj["path"]) is str and obj["path"].startswith(prefix.rstrip("/") + "/"),
                     "Unresolved path pin: " + row["path"] + pointer)
                name = relative(obj["path"][len(prefix.rstrip("/")) + 1:])
                need(name in available, "Missing declared reference target")
                if pointer in invalid:
                    need(obj["bytes"] == available[name]["bytes"] and obj["sha256"] == "0" * 64,
                         "Exact zero-digest mutation must remain invalid")
                    kind = "DECLARED_INVALID_STALE_CERTIFICATE_FIXTURE"
                else:
                    need({k: obj[k] for k in ("bytes", "sha256")} == available[name],
                         "Unresolved/mismatched reference: " + row["path"] + pointer)
                    kind = "EXTERNAL_SOURCE_RESTORATION" if name not in files else "INCLUDED"
            closure.append({"file": row["path"], "pointer": pointer, "kind": kind})
    return closure
