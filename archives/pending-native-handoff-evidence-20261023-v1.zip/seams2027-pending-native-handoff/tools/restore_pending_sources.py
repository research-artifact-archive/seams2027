#!/usr/bin/env python3
"""Restore exactly two Lift inputs from verified local public dependencies.

Offline only. Does not execute archive code or import a scientific module.
Publisher source bytes are generated locally; do not add them to the release.
"""
import argparse
import base64
import re
from pathlib import Path
import zipfile
from pending_public_common import decode, digest, need, pin, verify, write_new

ARCHIVE_URL = "https://github.com/research-artifact-archive/seams2027/raw/refs/tags/lift-causal-evidence-20261021-v1/archives/lift-causal-extension-public-20261021-v1.zip"
ARCHIVE_PIN = {"bytes": 2986678, "sha256": "64ba40d58edd2b5b04a7583c4e5ee32fe184b9d5c264026201fcfa5b4b747d07"}
MANIFEST_MEMBER = "seams2027-lift-causal-extension/source_restoration/LIFT_CAUSAL_SOURCE_FETCH_MANIFEST.json"
MANIFEST_PIN = {"bytes": 68619, "sha256": "bcfd8a1621b7dce24e757169f590143c28d10c4abb24f865986dbc31aac1b934"}
HTML_URL = "https://arxiv.org/html/2609.12231v1"
HTML_PIN = {"bytes": 1624775, "sha256": "78a3adba587d3179008afefa9ef7cecc9bd9eacc030d64c64a30f9171955b8ee"}
NEW_PIN = {"bytes": 2218, "sha256": "6a8f8220385130b2eb219ecfa33186b179d610ffcf805a30f9cab47ab204dae7"}
OLD_SUFFIX = b"\n\nassumption -- constructed_old_mode_no_b1\n\talw(b1=false);\n"
OLD_PIN = {"bytes": 2277, "sha256": "c57da4230023632ac31136787fa139569ab6e91facbab4adcb52b58adefbd16e"}
SOURCE_TARGETS = {
    "experiment/v58_submission_20261023/pending_handoff/inputs/lift_new.spectra": "lift_new.spectra",
    "experiment/v58_submission_20261023/pending_handoff/inputs/lift_old_no_b1.spectra": "lift_old_no_b1.spectra",
    "experiment/seams_research_reframing_20261018/runtime_closure_01/sources/lift__trivial_1.spectra": "lift_new.spectra",
    "experiment/seams_establishment_20261013/k7_population_preparation/source_inputs/reconstructed/lift__trivial_1.spectra": "lift_new.spectra",
}


def restore(archive, html_path):
    verify(archive, ARCHIVE_PIN)
    with zipfile.ZipFile(archive) as z:
        need(z.namelist().count(MANIFEST_MEMBER) == 1, "Unique restoration manifest member required")
        raw = z.read(MANIFEST_MEMBER)
    need(digest(raw) == MANIFEST_PIN, "Fourth-archive restoration manifest hash")
    manifest = decode(raw)
    row = next(item for item in manifest["upstream_downloads"] if item["id"] == "paper_html")
    need(row["url"] == HTML_URL and {k: row[k] for k in ("bytes", "sha256")} == HTML_PIN,
         "Pinned publisher HTML identity")
    html = verify(html_path, HTML_PIN).decode("utf-8")
    listings = {item["id"]: item for item in manifest["paper"]["listings"]}

    def listing(name):
        spec = listings[name]
        figures = re.findall(r'<figure\b[^>]*id="' + re.escape(spec["listing_id"])
                             + r'"[^>]*>(.*?)</figure>', html, re.S)
        need(len(figures) == 1, "Exactly one figure required")
        payloads = re.findall(r'href="data:text/plain;base64,([^"]+)"', figures[0])
        need(len(payloads) == 1, "Exactly one raw listing payload required")
        value = base64.b64decode(payloads[0], validate=True)
        need(digest(value) == spec["raw"], "Exact raw listing bytes")
        return value

    lift, donor = listing("lift__trivial_1"), listing("arbiter__original")
    pattern_spec = manifest["paper"]["pattern"]
    marker = pattern_spec["start_marker"].encode()
    need(pattern_spec["donor_id"] == "arbiter__original" and donor.count(marker) == 1
         and marker not in lift, "Exact omitted response-pattern recipe")
    pattern = donor[donor.index(marker):]
    need(digest(pattern) == {k: pattern_spec[k] for k in ("bytes", "sha256")}, "Donor pattern bytes")
    new = lift + b"\n\n" + pattern
    need(digest(new) == NEW_PIN == listings["lift__trivial_1"]["reconstructed"], "Reconstructed source bytes")
    old = new + OLD_SUFFIX
    need(len(OLD_SUFFIX) == 59 and digest(old) == OLD_PIN, "Exact !b1 append/output identity")
    return new, old


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fourth-archive", required=True, type=Path)
    parser.add_argument("--paper-html", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    need(not args.output.exists() and args.output.parent.is_dir(), "Fresh output with existing parent required")
    new, old = restore(args.fourth_archive, args.paper_html)
    args.output.mkdir()
    write_new(args.output / "lift_new.spectra", new, raw=True)
    write_new(args.output / "lift_old_no_b1.spectra", old, raw=True)
    receipt = {"schema": "pending-lift-offline-source-restoration-v1", "status": "PASS_SOURCE_BYTES_ONLY",
               "archive": pin(args.fourth_archive), "archive_url": ARCHIVE_URL,
               "manifest_member": MANIFEST_MEMBER, "manifest_member_pin": MANIFEST_PIN,
               "publisher_html": pin(args.paper_html), "publisher_url": HTML_URL,
               "outputs": [pin(args.output / "lift_new.spectra"), pin(args.output / "lift_old_no_b1.spectra")],
               "old_append": digest(OLD_SUFFIX), "network_calls": 0, "scientific_executions": 0,
               "scope": "Local source-byte reconstruction only; no redistribution grant or scientific replay claim."}
    write_new(args.output / "SOURCE_RESTORATION_RECEIPT.json", receipt)
    print("PASS_SOURCE_BYTES_ONLY")


if __name__ == "__main__":
    main()
