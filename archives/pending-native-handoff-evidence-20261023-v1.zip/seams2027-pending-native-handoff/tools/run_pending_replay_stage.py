#!/usr/bin/env python3
"""Explicit Root-invoked, once-only dispatcher for the fixed portable replay.

This is an execution helper. Merely preparing/binding a bundle does not run it.
Each stage uses the pinned existing process-group/resource supervisor. No wall
deadline, native synthesis, network access or automatic usage reset is added.
"""
import argparse
import datetime
import os
from pathlib import Path
import subprocess
from pending_public_common import below, decode, need, pin, verify, write_new

BASE = "experiment/v58_submission_20261023/pending_handoff"
STAGES = ("old_source", "old_saved", "old_adoption", "interfaces", "candidate_source",
          "candidate_saved", "runtime_go", "runtime", "event_audit", "event_mutations")
STATUS = {"old_source": "COMPLETE_OLD_GATE", "old_saved": "COMPLETE_OLD_GATE",
          "old_adoption": "ADOPTED_BOTH_OLD_GATE_CERTIFICATES", "interfaces": "PASS_INTERFACE_QUALIFICATION",
          "candidate_source": "COMPLETE_ROOTED_CANDIDATES", "candidate_saved": "COMPLETE_ROOTED_CANDIDATES",
          "runtime_go": "GO_EXACT_FROZEN_HANDOFF_RUNTIME", "runtime": "COMPLETE_EXECUTED_HANDOFF_CENSUS",
          "event_audit": "PASS_ALL_6_EXECUTED_EPISODES", "event_mutations": "PASS_EVENT_MUTATION_QUALIFICATION"}


def references(value):
    if isinstance(value, dict):
        if {"path", "bytes", "sha256"} <= set(value):
            yield {k: value[k] for k in ("path", "bytes", "sha256")}
        for child in value.values():
            yield from references(child)
    elif isinstance(value, list):
        for child in value:
            yield from references(child)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--session", required=True, type=Path)
    parser.add_argument("--expected-session-sha256", required=True)
    parser.add_argument("--review", required=True, type=Path)
    parser.add_argument("--expected-review-sha256", required=True)
    parser.add_argument("--stage", choices=STAGES, required=True)
    parser.add_argument("--confirmed-root-controlled-execution", action="store_true", required=True)
    parser.add_argument("--ordinary-usage-gate-confirmed", action="store_true", required=True)
    args = parser.parse_args()
    session_ref, review_ref = pin(args.session), pin(args.review)
    need(session_ref["sha256"] == args.expected_session_sha256
         and review_ref["sha256"] == args.expected_review_sha256, "Exact Root session/review pins")
    session, review = decode(args.session.read_bytes()), decode(args.review.read_bytes())
    need(session["schema"] == "pending-handoff-portable-replay-session-v1"
         and session["allowed_attempts_per_stage"] == 1 and session["network_required_during_replay"] is False,
         "Exact bounded portable session required")
    root, control = Path(session["root"]), args.session.resolve().parent
    need(control == root / "_portable_replay" and args.review.resolve().is_relative_to(control),
         "Review must be supplied in this fresh replay control directory")
    need(str(review.get("status", "")).startswith("PASS")
         and review.get("portable_binding_review") is True
         and review.get("scientific_execution_authorized") is True,
         "An actual passing exact-byte binding review and explicit Root authority are required")
    review_pins = list(references(review))
    for ref in (session["plan"], session["binding_bridge"], pin(root / BASE / "code/runtime/run_handoff.py")):
        need(ref in review_pins, "Review must bind this exact plan, graph/metadata bridge and runtime")
    need(pin(__file__) == session["runner"], "Dispatcher changed after binding")
    frozen = session["inputs"] + session["helper_inputs"] + [session[k] for k in
        ("public_manifest", "public_bindings", "python", "restoration_receipt", "binding_bridge", "limits")]
    for ref in frozen:
        need(pin(ref["path"]) == ref, "Runtime/archive input changed: " + ref["path"])
    outputs = {stage: below(root, session["stage_outputs"][stage]) for stage in STAGES}
    need(set(session["stage_outputs"]) == set(STAGES), "Exact ten-stage roster")
    for prior in STAGES[:STAGES.index(args.stage)]:
        path = control / "attempts" / (prior + ".json")
        need(path.is_file(), "Earlier stage not attempted: " + prior)
        previous = decode(path.read_bytes())
        need(previous.get("status") == "PASS_STAGE" and previous["session"] == session_ref
             and previous["review"] == review_ref and pin(outputs[prior]) == previous["output"],
             "Earlier stage failed, changed, or used another review: " + prior)
        process = decode(Path(previous["process"]["path"]).read_bytes())
        need(pin(previous["process"]["path"]) == previous["process"]
             and process["status"] == "COMPLETE" and process["exit_code"] == 0
             and process["owned_child_reaped"] is True and not process["violations"]
             and process["final_group_observation"] == {"state": "ABSENT", "members": []},
             "Earlier process ownership/cleanup differs")
    need(not outputs[args.stage].exists(), "Stage output must be fresh")
    py, plan = session["python"]["path"], session["plan"]["path"]
    code = root / BASE / "code"
    stage = args.stage
    commands = {
        "old_source": [str(code / "source_route/check_source_roots.py"), plan, "old_gate", str(outputs["old_source"])],
        "old_saved": [str(code / "saved_route/check_roots.py"), plan, "old_gate", str(outputs["old_saved"])],
        "old_adoption": [str(code / "adopt_old_gate.py"), plan],
        "interfaces": [str(code / "qualify_interfaces.py"), plan, str(outputs["interfaces"])],
        "candidate_source": [str(code / "source_route/check_source_roots.py"), plan, "candidate_roots", str(outputs["candidate_source"])],
        "candidate_saved": [str(code / "saved_route/check_roots.py"), plan, "candidate_roots", str(outputs["candidate_saved"])],
        "runtime_go": [str(code / "make_runtime_go.py"), plan, review_ref["path"], str(outputs["interfaces"]),
                       str(outputs["candidate_source"]), str(outputs["candidate_saved"]), str(outputs["runtime_go"])],
        "runtime": [str(code / "runtime/run_handoff.py"), plan, str(outputs["runtime_go"]), str(outputs["runtime"].parent)],
        "event_audit": [str(code / "source_route/audit_handoff_events.py"), plan, str(outputs["runtime"]), str(outputs["event_audit"])],
        "event_mutations": [str(code / "qualify_event_mutations.py"), plan, str(outputs["runtime"]), str(outputs["event_mutations"].parent)],
    }
    if stage in {"runtime", "event_mutations"}:
        need(not outputs[stage].parent.exists(), "Fresh stage directory required")
    receipt_dir = control / "processes" / stage
    need(not receipt_dir.exists(), "Fresh process receipt required")
    active = control / "ACTIVE_STAGE.json"
    write_new(active, {"stage": stage, "owner_pid": os.getpid(), "session": session_ref})
    attempt_path = control / "attempts" / (stage + ".json")
    scientific_argv = [py, "-B", *commands[stage]]
    supervised = [py, "-B", session["supervisor"]["path"], str(receipt_dir), str(root / BASE),
                  session["limits"]["path"], "--", *scientific_argv]
    attempt = {"status": "DISPATCHED_ONCE", "stage": stage, "session": session_ref, "review": review_ref,
               "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "scientific_argv": scientific_argv, "supervised_argv": supervised}
    write_new(attempt_path, attempt)
    child = subprocess.run(supervised, cwd=root, check=False)
    # Always retain the attempt and all outputs, including failure/UNKNOWN.
    process_path = receipt_dir / "PROCESS.json"
    process = decode(process_path.read_bytes())
    attempt["process"] = pin(process_path)
    attempt["supervisor_exit_code"] = child.returncode
    complete = child.returncode == 0 and process["status"] == "COMPLETE" and process["exit_code"] == 0 \
        and process["owned_child_reaped"] is True and not process["violations"] \
        and process["final_group_observation"] == {"state": "ABSENT", "members": []}
    if outputs[stage].is_file():
        attempt["output"] = pin(outputs[stage])
        result = decode(outputs[stage].read_bytes())
        attempt["scientific_status"] = result.get("status")
        complete = complete and result.get("status") == STATUS[stage]
    else:
        complete = False
    for ref in frozen:
        complete = complete and pin(ref["path"]) == ref
    complete = complete and pin(args.session) == session_ref and pin(args.review) == review_ref
    attempt["status"] = "PASS_STAGE" if complete else "FAIL_OR_UNKNOWN_STAGE"
    attempt["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    # This file is the single owned attempt journal, not a new attempt.
    from pending_public_common import encoded
    attempt_path.write_bytes(encoded(attempt))
    if complete:
        active.unlink()
    print(attempt["status"] + " " + stage)
    if not complete:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
