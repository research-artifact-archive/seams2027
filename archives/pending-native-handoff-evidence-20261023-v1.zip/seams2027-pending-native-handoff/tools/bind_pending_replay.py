#!/usr/bin/env python3
"""Create a fresh portable replay tree and metadata bridge; run no study code."""
import argparse
from pathlib import Path
from pending_public_common import (below, decode, digest, need, pin, transform,
                                   validate_path_closure, verify, write_new)
from restore_pending_sources import NEW_PIN, OLD_PIN, SOURCE_TARGETS

BASE = "experiment/v58_submission_20261023/pending_handoff"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle-root", type=Path, required=True)
    parser.add_argument("--expected-manifest-sha256", required=True)
    parser.add_argument("--restored-sources", type=Path, required=True)
    parser.add_argument("--replay-root", type=Path, required=True)
    parser.add_argument("--python", type=Path, required=True)
    args = parser.parse_args()
    bundle, root = args.bundle_root.resolve(), args.replay_root.resolve()
    need(not root.exists() and root.parent.is_dir() and not root.is_relative_to(bundle)
         and not bundle.is_relative_to(root), "Fresh separate replay root required")
    manifest_ref = pin(bundle / "MANIFEST.json")
    need(manifest_ref["sha256"] == args.expected_manifest_sha256, "Root-adopted immutable public manifest")
    manifest = decode((bundle / "MANIFEST.json").read_bytes())
    need(manifest["status"] == "ASSEMBLED_NOT_REPLAY_QUALIFIED", "Use immutable assembly snapshot")
    inventory = {}
    for row in manifest["files"]:
        need(row["path"] not in inventory, "Duplicate manifest member")
        inventory[row["path"]] = verify(below(bundle, row["path"]), row)
    need(len(inventory) == manifest["file_count_excluding_manifest"], "Manifest member count")
    contract = decode(inventory["PUBLIC_BINDINGS.json"])
    need(contract["schema"] == "pending-handoff-public-bindings-v1", "Public bindings schema")
    rows = [r for r in contract["files"] if r["runtime"]]
    working = {r["path"]: inventory["evidence/" + r["path"]] for r in rows}
    for row in rows:
        need(digest(working[row["path"]]) == {k: row[k] for k in ("bytes", "sha256")}, "Runtime input roster pin")
    sources = {}
    need(len(contract["external_sources"]) == len(SOURCE_TARGETS)
         and {r["path"]: r["restored_from"] for r in contract["external_sources"]} == SOURCE_TARGETS,
         "Exact source alias paths and restoration mapping required")
    for row in contract["external_sources"]:
        expected = OLD_PIN if row["restored_from"] == "lift_old_no_b1.spectra" else NEW_PIN
        need({k: row[k] for k in ("bytes", "sha256")} == expected, "Source alias content identity")
        sources[row["path"]] = verify(args.restored_sources / row["restored_from"], row)
    receipt_ref = pin(args.restored_sources / "SOURCE_RESTORATION_RECEIPT.json")
    receipt = decode((args.restored_sources / "SOURCE_RESTORATION_RECEIPT.json").read_bytes())
    need(receipt["status"] == "PASS_SOURCE_BYTES_ONLY" and receipt["network_calls"] == 0
         and receipt["scientific_executions"] == 0, "Exact offline source restoration receipt")
    for row in contract["external_sources"]:
        need(any(r["bytes"] == row["bytes"] and r["sha256"] == row["sha256"] for r in receipt["outputs"]),
             "Restoration receipt must bind both exact inputs")
    transformed, changes = transform(working, rows, contract["external_sources"], str(root), contract["output_paths"])
    closure = validate_path_closure(transformed, rows, contract["external_sources"], str(root))
    plan = decode(transformed[BASE + "/PLAN.json"])
    need(plan["candidate_order"] == ["retain_old_native", "saved_normalized", "saved_preference"]
         and plan["policies"] == ["strict_only", "strict_and_cooperative"]
         and plan["continuation_steps_per_episode"] == 5, "Fixed runtime protocol")
    need(plan["process_policy"]["single_worker"] is True
         and plan["process_policy"]["single_scientific_attempt_per_stage"] is True
         and plan["process_policy"]["wall_seconds"] is None, "Fixed process policy")
    root.mkdir()
    for name, raw in {**transformed, **sources}.items():
        write_new(below(root, name), raw, raw=True)
    # Store exact original helper bytes inside the replay root too. They are
    # pinned together with every input before Root approves any execution.
    for name, raw in inventory.items():
        if name.startswith("tools/"):
            write_new(below(root, "_portable_replay/" + name), raw, raw=True)
    control = root / "_portable_replay"
    (control / "processes").mkdir()
    (control / "attempts").mkdir()
    (root / BASE / "execution").mkdir(parents=True, exist_ok=True)
    fresh_output_directories = {below(root, contract["stage_outputs"][stage]).parent
                                for stage in ("runtime", "event_mutations")}
    for name in contract["output_paths"]:
        parent = below(root, name).parent
        if not any(parent == fresh or parent.is_relative_to(fresh) for fresh in fresh_output_directories):
            parent.mkdir(parents=True, exist_ok=True)
    limits = {k: plan["process_policy"][k] for k in
              ("rss_bytes", "output_tree_bytes", "stream_bytes", "disk_floor_bytes")}
    write_new(control / "LIMITS.json", limits)
    bridge = {"schema": "pending-handoff-runtime-binding-bridge-v1", "status": "BOUND_NOT_EXECUTED",
              "public_manifest": manifest_ref, "restoration_receipt": receipt_ref,
              "changes": changes, "reference_closure": closure,
              "files": [{"path": name, "public": digest(working[name]), "runtime": digest(transformed[name])}
                        for name in sorted(working)],
              "scientific_payload_or_graph_content_changed": False, "scientific_executions": 0}
    write_new(control / "BINDING_BRIDGE.json", bridge)
    runtime_ref = pin(root / BASE / "code/runtime/run_handoff.py")
    plan_ref = pin(root / BASE / "PLAN.json")
    write_new(control / "REVIEW_REQUIRED.json", {"status": "NEEDS_ACTUAL_ROOT_REVIEW",
        "plan": plan_ref, "runtime": runtime_ref, "binding_bridge": pin(control / "BINDING_BRIDGE.json"),
        "note": "This template is not a PASS review or execution authority. Root must inspect the exact binding and supply an actual review receipt separately."})
    session = {"schema": "pending-handoff-portable-replay-session-v1", "status": "BOUND_NOT_AUTHORIZED",
               "root": str(root), "bundle_root": str(bundle), "public_manifest": manifest_ref,
               "public_bindings": pin(bundle / "PUBLIC_BINDINGS.json"), "python": pin(args.python),
               "restoration_receipt": receipt_ref, "binding_bridge": pin(control / "BINDING_BRIDGE.json"),
               "limits": pin(control / "LIMITS.json"), "plan": plan_ref,
               "supervisor": pin(root / contract["supervisor"]),
               "runner": pin(control / "tools/run_pending_replay_stage.py"),
               "comparer": pin(control / "tools/compare_pending_replay.py"),
               "inputs": [pin(below(root, name)) for name in sorted(set(transformed) | set(sources))],
               "helper_inputs": [pin(p) for p in sorted((control / "tools").iterdir()) if p.is_file()],
               "stage_outputs": contract["stage_outputs"], "comparison": contract["comparison"],
               "allowed_attempts_per_stage": 1, "network_required_during_replay": False,
               "scope": "Requires an actual exact-byte Root review and explicit stage invocation; historical GO is never reused."}
    write_new(control / "SESSION.json", session)
    for row in manifest["files"]:
        verify(below(bundle, row["path"]), row)
    print("BOUND_NOT_AUTHORIZED " + pin(control / "SESSION.json")["sha256"])


if __name__ == "__main__":
    main()
