package tau.smlab.syntech.games.gr1;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.sf.javabdd.BDD;
import tau.smlab.syntech.games.controller.enumerate.EnumStateI;
import tau.smlab.syntech.games.controller.enumerate.EnumStrategyI;
import tau.smlab.syntech.jtlv.Env;

/**
 * Bounded observer for the copied release extractor.
 *
 * During construction this records primitive metadata and BDD.id() references.
 * All additional BDD algebra, traversal, and text conversion occur in finish(),
 * after the controller is complete. Retaining references can still change GC
 * and memory pressure; this observer therefore requires graph-parity validation.
 * This class never changes a candidate, rank, controller, or memory array.
 */
final class GR1ExtractionObserver implements AutoCloseable {
  private final Path output;
  private final Set<Integer> focusIds = new LinkedHashSet<>();
  private final boolean allIds;
  private final int maxNodes;
  private final int maxEvents;
  private final int maxBddRefs;
  private final int maxTextChars;
  private final List<Map<String, Object>> events = new ArrayList<>();
  private final List<Snapshot> held = new ArrayList<>();
  private final Map<Integer, Integer> firstIncomingCy = new LinkedHashMap<>();
  private final Map<Integer, Integer> firstIncomingJ = new LinkedHashMap<>();
  private final Map<Integer, Integer> firstExpandedCy = new LinkedHashMap<>();
  private final Set<Integer> detailedNodes = new LinkedHashSet<>();
  private final Set<Integer> seenFocusedNodes = new LinkedHashSet<>();
  private boolean active;
  private int nodeId = -1;
  private int nodeJ = -1;
  private int nodeCy = -1;
  private int edgeIndex = -1;
  private long droppedEvents;
  private long droppedBddRefs;
  private long truncatedTexts;
  private long focusedNodesBeyondCap;
  private boolean finished;

  GR1ExtractionObserver() {
    String path = System.getProperty("lift.trace.path", "").trim();
    output = path.isEmpty() ? null : Paths.get(path);
    String selected = System.getProperty("lift.trace.nodeIds", "704,680").trim();
    allIds = selected.equals("*");
    if (!allIds && !selected.isEmpty()) {
      for (String token : selected.split(",")) focusIds.add(Integer.parseInt(token.trim()));
    }
    maxNodes = positiveProperty("lift.trace.maxNodes", 16);
    maxEvents = positiveProperty("lift.trace.maxEvents", 5000);
    maxBddRefs = positiveProperty("lift.trace.maxBddRefs", 10000);
    maxTextChars = positiveProperty("lift.trace.maxTextChars", 200000);
  }

  private static int positiveProperty(String name, int fallback) {
    int value = Integer.parseInt(System.getProperty(name, String.valueOf(fallback)));
    if (value <= 0) throw new IllegalArgumentException(name + " must be positive");
    return value;
  }

  void initial(EnumStateI state, int j, int cy) {
    if (output == null) return;
    firstIncomingCy.putIfAbsent(state.getStateId(), cy);
    firstIncomingJ.putIfAbsent(state.getStateId(), j);
  }

  void beginNode(EnumStateI state, int j, int cy, GR1Memory memory) {
    if (output == null) return;
    nodeId = state.getStateId();
    nodeJ = j;
    nodeCy = cy;
    edgeIndex = -1;
    firstExpandedCy.putIfAbsent(nodeId, cy);
    boolean focused = allIds || focusIds.contains(nodeId);
    if (focused) seenFocusedNodes.add(nodeId);
    active = focused && (detailedNodes.contains(nodeId) || detailedNodes.size() < maxNodes);
    if (focused && !active) focusedNodesBeyondCap++;
    if (!active) return;
    detailedNodes.add(nodeId);
    event("node_begin", "state", state.getData(), "initial", state.isInitial(),
        "rank_j", state.get_rank_info().memVal(),
        "first_incoming_j", firstIncomingJ.get(nodeId),
        "first_incoming_cy", firstIncomingCy.get(nodeId),
        "first_expanded_cy", firstExpandedCy.get(nodeId));
    for (int i = 0; i < memory.x_mem[j].length; i++) {
      // Capture only references here; compute membership after all decisions.
      BDD[] ranks = memory.x_mem[j][i];
      boolean present = ranks != null && cy >= 0 && cy < ranks.length && ranks[cy] != null;
      event("x_membership", "i", i, "state", state.getData(),
          "x_slot_present", present, "x", present ? ranks[cy] : null);
    }
  }

  void beginEdge(BDD primedEnvironmentSuccessor) {
    if (output == null) return;
    edgeIndex++;
    event("environment_successor", "primed_environment", primedEnvironmentSuccessor);
  }

  void addedEdge(EnumStateI from, EnumStateI newlyCreated, int incomingJ, int incomingCy) {
    if (output == null) return;
    // Native EnumStateImpl.addSuccessor appends exactly once, including reuse.
    EnumStateI target = from.getSuccessors().lastElement();
    int id = target.getStateId();
    Integer earlierCy = firstIncomingCy.get(id);
    Integer earlierJ = firstIncomingJ.get(id);
    event("edge_added", "target_id", id, "created", newlyCreated != null,
        "target_state", target.getData(), "target_rank_j", target.get_rank_info().memVal(),
        "incoming_j", incomingJ, "incoming_cy", incomingCy,
        "earlier_incoming_j", earlierJ, "earlier_incoming_cy", earlierCy,
        "target_first_expanded_cy", firstExpandedCy.get(id));
    firstIncomingCy.putIfAbsent(id, incomingCy);
    firstIncomingJ.putIfAbsent(id, incomingJ);
  }

  void event(String kind, Object... fields) {
    if (output == null || !active) return;
    if ((fields.length & 1) != 0) throw new IllegalArgumentException("Odd observer field count");
    if (events.size() >= maxEvents) {
      droppedEvents++;
      return;
    }
    Map<String, Object> row = map("event", kind, "node_id", nodeId, "source_j", nodeJ,
        "source_cy", nodeCy, "environment_successor_index", edgeIndex);
    for (int i = 0; i < fields.length; i += 2) {
      Object value = fields[i + 1];
      if (value instanceof BDD) {
        if (held.size() >= maxBddRefs) {
          value = map("capture", "omitted_bdd_reference_cap");
          droppedBddRefs++;
        } else {
          Snapshot snapshot = new Snapshot(((BDD) value).id());
          held.add(snapshot);
          value = snapshot;
        }
      }
      row.put(String.valueOf(fields[i]), value);
    }
    events.add(row);
  }

  void finish(EnumStrategyI controller) {
    if (output == null) return;
    if (finished) throw new IllegalStateException("Observer already finished");
    // No extraction decisions remain. Additional BDD operations start here.
    for (Map<String, Object> row : events) {
      if ("x_membership".equals(row.get("event"))) {
        Object a = row.get("state"), b = row.get("x");
        if (a instanceof Snapshot && b instanceof Snapshot) {
          BDD intersection = ((Snapshot) a).bdd.and(((Snapshot) b).bdd);
          try {
            row.put("membership_nonempty", !intersection.isZero());
          } finally {
            intersection.free();
          }
        }
      }
      for (Map.Entry<String, Object> entry : row.entrySet()) {
        if (entry.getValue() instanceof Snapshot) {
          entry.setValue(render((Snapshot) entry.getValue()));
        }
      }
    }
    Set<Integer> missing = new LinkedHashSet<>(focusIds);
    missing.removeAll(seenFocusedNodes);
    Map<String, Object> payload = map(
        "schema", "lift-t-generic-extractor-observer-v1",
        "construction_complete", true,
        "observation_mode", "bounded_reference_capture_then_postconstruction_serialization",
        "graph_parity_verified", false,
        "graph_parity_note", "Caller must compare with native graph; observer does not establish parity.",
        "selected_node_ids", allIds ? "*" : new ArrayList<>(focusIds),
        "seen_focused_node_ids", new ArrayList<>(seenFocusedNodes),
        "detailed_node_ids", new ArrayList<>(detailedNodes),
        "missing_focused_node_ids", new ArrayList<>(missing),
        "max_nodes", maxNodes, "max_events", maxEvents,
        "max_bdd_references", maxBddRefs, "max_text_characters_per_representation", maxTextChars,
        "dropped_events", droppedEvents, "dropped_bdd_references", droppedBddRefs,
        "truncated_texts", truncatedTexts, "focused_nodes_beyond_cap", focusedNodesBeyondCap,
        "complete_for_seen_focused_nodes",
        droppedEvents == 0 && droppedBddRefs == 0 && truncatedTexts == 0 && focusedNodesBeyondCap == 0,
        "controller_states", controller.numOfStates(),
        "controller_transitions", controller.numOfTransitions(),
        "captured_bdd_references", held.size(), "events", events);
    try {
      Path parent = output.toAbsolutePath().getParent();
      if (parent != null) Files.createDirectories(parent);
      Files.write(output, (json(payload) + "\n").getBytes(StandardCharsets.UTF_8),
          StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
      finished = true;
    } catch (IOException e) {
      throw new UncheckedIOException("Cannot write observer output " + output, e);
    }
  }

  private Map<String, Object> render(Snapshot snapshot) {
    BDD b = snapshot.bdd;
    // Text has BDD variable/cube semantics, not a claim of complete minterm enumeration.
    return map("zero", b.isZero(), "one", b.isOne(), "node_count", b.nodeCount(),
        "bdd_cubes", limited(b.toString()),
        "domain_text", limited(b.toStringWithDomains(Env.stringer)));
  }

  private Object limited(String text) {
    if (text.length() <= maxTextChars) return text;
    truncatedTexts++;
    return map("truncated", true, "original_characters", text.length(),
        "prefix", text.substring(0, maxTextChars));
  }

  @Override
  public void close() {
    for (Snapshot snapshot : held) snapshot.bdd.free();
    held.clear();
    active = false;
  }

  private static final class Snapshot {
    final BDD bdd;
    Snapshot(BDD bdd) { this.bdd = bdd; }
  }

  private static Map<String, Object> map(Object... fields) {
    Map<String, Object> result = new LinkedHashMap<>();
    for (int i = 0; i < fields.length; i += 2) {
      result.put(String.valueOf(fields[i]), fields[i + 1]);
    }
    return result;
  }

  private static String json(Object value) {
    if (value == null) return "null";
    if (value instanceof Boolean || value instanceof Number) return String.valueOf(value);
    if (value instanceof Map<?, ?>) {
      StringBuilder result = new StringBuilder("{");
      boolean first = true;
      for (Map.Entry<?, ?> e : ((Map<?, ?>) value).entrySet()) {
        if (!first) result.append(',');
        first = false;
        result.append(quote(String.valueOf(e.getKey()))).append(':').append(json(e.getValue()));
      }
      return result.append('}').toString();
    }
    if (value instanceof Iterable<?>) {
      StringBuilder result = new StringBuilder("[");
      boolean first = true;
      for (Object item : (Iterable<?>) value) {
        if (!first) result.append(',');
        first = false;
        result.append(json(item));
      }
      return result.append(']').toString();
    }
    return quote(String.valueOf(value));
  }

  private static String quote(String text) {
    StringBuilder result = new StringBuilder("\"");
    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      switch (c) {
        case '"': result.append("\\\""); break;
        case '\\': result.append("\\\\"); break;
        case '\b': result.append("\\b"); break;
        case '\f': result.append("\\f"); break;
        case '\n': result.append("\\n"); break;
        case '\r': result.append("\\r"); break;
        case '\t': result.append("\\t"); break;
        default:
          if (c < 0x20) {
            String h = Integer.toHexString(c);
            result.append("\\u");
            for (int z = h.length(); z < 4; z++) result.append('0');
            result.append(h);
          } else {
            result.append(c);
          }
      }
    }
    return result.append('"').toString();
  }
}
