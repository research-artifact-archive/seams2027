#!/usr/bin/env python3
"""Restore pinned Lift causal-extension source bytes without Java or a solver.

Use a fresh --output-root. --cache optionally supplies or retains the exact
upstream HTML/JAR objects named in the adjacent manifest. A cache hit is checked
before use; a corrupt cache is an error, never an invitation to substitute data.
"""

import argparse
import base64
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import sys
import urllib.request
import zipfile


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(data, expected, label):
    require(len(data) == expected["bytes"], label + ": byte count mismatch")
    require(digest(data) == expected["sha256"], label + ": SHA-256 mismatch")
    return data


def relative_path(value):
    path = PurePosixPath(value)
    require(
        value and not path.is_absolute()
        and all(part not in ("", ".", "..") for part in value.split("/"))
        and "\\" not in value,
        "Unsafe relative path",
    )
    return path


def below(root, value):
    path = relative_path(value)
    target = root.joinpath(*path.parts)
    require(target.resolve().is_relative_to(root.resolve()), "Path escapes root")
    return target


def download(row, cache):
    cached = below(cache, row["cache_name"]) if cache is not None else None
    if cached is not None and cached.exists():
        require(cached.is_file() and not cached.is_symlink(), "Invalid cache object")
        return pin(cached.read_bytes(), row, row["id"]), "VERIFIED_CACHE"
    require(row["url"].startswith("https://"), "Upstream URL must use HTTPS")
    request = urllib.request.Request(
        row["url"], headers={"User-Agent": "Lift-Causal-Source-Restoration/1.0"}
    )
    cap = row["max_download_bytes"]
    with urllib.request.urlopen(request, timeout=30) as response:
        require(response.geturl().startswith("https://"), "Insecure redirect")
        data = response.read(cap + 1)
    require(len(data) <= cap, "Upstream download exceeds declared limit")
    pin(data, row, row["id"])
    if cached is not None:
        cached.parent.mkdir(parents=True, exist_ok=True)
        with cached.open("xb") as handle:
            handle.write(data)
    return data, "HTTPS_GET_VERIFIED"


def listing_payload(html, row):
    matches = re.findall(
        r'<figure\b[^>]*id="' + re.escape(row["listing_id"])
        + r'"[^>]*>(.*?)</figure>', html, re.S
    )
    require(len(matches) == 1, row["id"] + ": expected one listing")
    payloads = re.findall(
        r'href="data:text/plain;base64,([^"]+)"', matches[0]
    )
    require(len(payloads) == 1, row["id"] + ": expected one payload")
    return pin(base64.b64decode(payloads[0], validate=True), row["raw"], row["id"])


def reconstruct_paper(data, spec):
    html = data.decode("utf-8")
    raw = {row["id"]: listing_payload(html, row) for row in spec["listings"]}
    pattern_spec = spec["pattern"]
    donor = raw[pattern_spec["donor_id"]]
    marker = pattern_spec["start_marker"].encode("utf-8")
    require(donor.count(marker) == 1, "Expected one response-pattern declaration")
    pattern = pin(donor[donor.index(marker):], pattern_spec, "Response pattern")
    result = {}
    for row in spec["listings"]:
        value = raw[row["id"]].decode("utf-8")
        for edit in row["edits"]:
            operation = edit["operation"]
            if operation == "append_exact_omitted_pattern":
                require("pattern pRespondsToS" not in value, "Pattern already present")
                value += "\n\n" + pattern.decode("utf-8")
            elif operation in (
                "declared_typographical_reconstruction",
                "infinite_trace_equivalent_response_lowering",
            ):
                require(
                    value.count(edit["old"]) == edit.get("occurrences", 1),
                    "Declared replacement count mismatch",
                )
                value = value.replace(edit["old"], edit["new"])
            else:
                raise ValueError("Unknown paper reconstruction operation")
        result[row["id"]] = pin(
            value.encode("utf-8"), row["reconstructed"], row["id"] + "/reconstructed"
        )
    return result


def apply_recipe(base, recipe):
    if recipe["normalize_crlf_to_lf"]:
        base = base.decode("utf-8").replace("\r\n", "\n").encode("utf-8")
    pin(base, recipe["normalized_base"], "Normalized recipe base")
    parts = []
    previous_end = 0
    for segment in recipe["segments"]:
        require(len(segment) == 1, "Malformed recipe segment")
        if "copy" in segment:
            start, end = segment["copy"]
            require(
                type(start) is int and type(end) is int
                and previous_end <= start < end <= len(base),
                "Invalid or nonmonotonic recipe copy range",
            )
            parts.append(base[start:end])
            previous_end = end
        elif "insert_utf8" in segment:
            parts.append(segment["insert_utf8"].encode("utf-8"))
        else:
            raise ValueError("Unknown recipe segment")
    return b"".join(parts)


def restore(manifest, component_root, downloaded):
    upstream = {}
    for member in manifest["upstream_members"]:
        with zipfile.ZipFile(io.BytesIO(downloaded[member["download_id"]])) as archive:
            matches = [x for x in archive.infolist() if x.filename == member["member"]]
            require(len(matches) == 1, "Missing or duplicate upstream source member")
            require(matches[0].file_size == member["bytes"], "Member size mismatch")
            data = archive.read(matches[0])
        upstream[member["id"]] = pin(data, member, member["id"])
    templates = {}
    for template in manifest["original_templates"]:
        path = below(component_root, template["file"])
        require(path.is_file() and not path.is_symlink(), "Missing original template")
        templates[template["id"]] = pin(path.read_bytes(), template, template["id"])
    paper = reconstruct_paper(
        downloaded[manifest["paper"]["download_id"]], manifest["paper"]
    )
    outputs = {}
    for output in manifest["outputs"]:
        name = str(relative_path(output["path"]))
        require(name not in outputs, "Duplicate output path")
        kind = output["kind"]
        if kind == "paper_reconstructed":
            value = paper[output["listing_id"]]
        elif kind == "append_original_suffix":
            value = outputs[output["base"]] + output["suffix_utf8"].encode("utf-8")
        elif kind == "original_template":
            value = templates[output["template_id"]]
        elif kind == "copy_insert_recipe":
            source, key = output["base"].split(":", 1)
            require(source in ("upstream", "output"), "Unknown recipe base type")
            base = upstream[key] if source == "upstream" else outputs[key]
            value = apply_recipe(base, output["recipe"])
        else:
            raise ValueError("Unknown generated output kind")
        outputs[name] = pin(value, output, name)
    return outputs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--cache", type=Path)
    args = parser.parse_args()
    component_root = Path(__file__).resolve().parent
    manifest_path = component_root / "LIFT_CAUSAL_SOURCE_FETCH_MANIFEST.json"
    manifest_bytes = manifest_path.read_bytes()
    manifest = json.loads(manifest_bytes)
    require(manifest["schema"] == "lift-causal-source-restoration-v1", "Wrong schema")
    require(not args.output_root.exists(), "Output root must be a new directory")
    require(not args.output_root.is_symlink(), "Output root must not be a symlink")
    if args.cache is not None:
        require(not args.cache.is_symlink(), "Cache root must not be a symlink")
        require(not args.cache.exists() or args.cache.is_dir(), "Cache is not a directory")
    downloaded, acquisition = {}, []
    for row in manifest["upstream_downloads"]:
        require(row["id"] not in downloaded, "Duplicate upstream download identifier")
        data, mode = download(row, args.cache)
        downloaded[row["id"]] = data
        acquisition.append({
            "id": row["id"], "url": row["url"], "mode": mode,
            "bytes": len(data), "sha256": digest(data),
        })
    outputs = restore(manifest, component_root, downloaded)
    # Resolve and validate all outputs before creating the new output tree.
    destinations = [(below(args.output_root, name), data) for name, data in outputs.items()]
    args.output_root.mkdir(parents=True, exist_ok=False)
    for path, data in destinations:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as handle:
            handle.write(data)
    receipt = {
        "schema": "lift-causal-source-restoration-receipt-v1",
        "status": "PASS_EXACT_SOURCE_BYTE_RESTORATION_ONLY",
        "manifest": {"bytes": len(manifest_bytes), "sha256": digest(manifest_bytes)},
        "acquisition": acquisition,
        "files": [
            {"path": name, "bytes": len(data), "sha256": digest(data)}
            for name, data in outputs.items()
        ],
        "source_files_restored": len(outputs),
        "archived_class_hash_records": len(manifest["archived_class_hashes"]),
        "class_hashes_verified_by_this_run": False,
        "java_executed": False, "compiled": False, "scientific_code_executed": False,
    }
    with (args.output_root / "SOURCE_RESTORATION_RECEIPT.json").open("x", encoding="utf-8") as handle:
        json.dump(receipt, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    print(json.dumps({
        "status": receipt["status"], "source_files_restored": len(outputs),
        "class_hashes_verified_by_this_run": False,
        "java_executed": False, "compiled": False, "scientific_code_executed": False,
    }, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile) as error:
        print("Source restoration stopped: " + str(error), file=sys.stderr)
        sys.exit(1)
