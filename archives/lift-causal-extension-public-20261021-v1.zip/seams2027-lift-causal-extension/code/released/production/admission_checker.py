"""Independent, finite model-level admission certificates for frozen K7 inputs.

This module never calls a native solver, constructs a controller, changes a raw
edge, or repairs a response. Source profiles are independently reviewed pinned
formula transcriptions. The producer/runtime invocation provenance is an explicit
separate audited-code trust boundary; saved JSON cannot establish invocation.
"""
from collections import defaultdict, deque
import hashlib
import importlib.util
from itertools import product
import json
from pathlib import Path
import re
import sys

from bdd_core import BDD, Invalid, ResourceRefusal, require

BASE = Path(__file__).resolve().parent
PROFILE_SHA256 = "1cc14f2aa4c0c0e3e523d9ff170d6f9f0be449ca7f4d7ed0d718a5f96e6da58b"
CONSUMER_SHA256 = "6e8bdf3a19dde5e99205e9b13255951d3d48fe103d5a4f0c9fa401688ef357ee"
GRAPH_SHA256 = "3da6d64631bd88ae0bda4ad71ccc37c46f48de233a51dcc843a476e391981d45"
MAX_JSON_BYTES = 64 * 1024 * 1024
MAX_STATES = 32768
MAX_EDGES = 1000000
MAX_INPUT_CHECKS = 4000000


class ControllerDefect(Invalid):
    """An actual complete emitted response violates a controller obligation."""
    def __init__(self, defects):
        self.defects = defects
        super().__init__("Complete raw controller fails original safety/input/response obligations")


def sha_bytes(raw):
    return hashlib.sha256(raw).hexdigest()


def sha(path):
    return sha_bytes(path.read_bytes())


def unique_object(pairs):
    result = {}
    for k, v in pairs:
        require(k not in result, "Duplicate JSON key: " + k)
        result[k] = v
    return result


def file_bytes(path, limit=MAX_JSON_BYTES):
    require(path.is_file() and not path.is_symlink(), "Expected regular non-symlink file: " + path.name)
    if path.stat().st_size > limit:
        raise ResourceRefusal("File byte budget exceeded: " + path.name)
    return path.read_bytes()


def read_json(path):
    return json.loads(file_bytes(path).decode("utf-8"), object_pairs_hook=unique_object)


def pinned_file(base, ref, basename=True):
    require(isinstance(ref, dict), "Missing file pin")
    name = ref.get("file")
    require(type(name) is str and name and not Path(name).is_absolute(), "Relative file pin required")
    require(name == Path(name).as_posix() and "\\" not in name, "Noncanonical relative file pin")
    parts = Path(name).parts
    require(all(p not in ("", ".", "..") for p in parts) and (not basename or len(parts) == 1),
            "Unsafe file pin")
    path = base
    for part in parts:
        path = path / part
        require(not path.is_symlink(), "Symlink in file pin")
    raw = file_bytes(path)
    require(type(ref.get("bytes")) is int and ref["bytes"] == len(raw), "File byte pin mismatch: " + name)
    require(type(ref.get("sha256")) is str and ref["sha256"] == sha_bytes(raw), "File SHA mismatch: " + name)
    return path


def exact_list(xs, expected, label):
    require(isinstance(xs, list) and all(type(x) is int for x in xs)
            and len(xs) == len(set(xs)) and set(xs) == set(expected), label)


def bit_map(value, expected, label):
    require(isinstance(value, dict) and set(value) == {str(v) for v in expected}
            and all(type(x) is bool for x in value.values()), label)
    return {int(k): v for k, v in value.items()}


def identity(data, profile, pipeline=None):
    for k in ("fixture_id", "case_id", "variant"):
        require(data.get(k) == profile[k], "Identity mismatch: " + k)
    if pipeline is not None:
        require(data.get("pipeline") == pipeline, "Pipeline mismatch")
        require(data.get("solver") == ("3fp" if pipeline == "original_strict" else "4fp"), "Solver mismatch")


def load_profile(fixture_id):
    path = BASE / "source_audit/SOURCE_PROFILES.json"
    require(sha(path) == PROFILE_SHA256, "Source profile freeze mismatch")
    data = read_json(path)
    require(data.get("schema") == "k7-independent-source-profiles-v1", "Source profile schema")
    require(fixture_id in data["profiles"], "Fixture outside frozen population")
    p = data["profiles"][fixture_id]
    for key in ("source", "trace"):
        pinned_file(path.parent, p[key], basename=False)
    trace = read_json(path.parent / p["trace"]["file"])
    observations = []
    for row in trace["observations"]:
        require(all(type(v) is bool for v in row.values()), "Unsupported source trace domain")
        observations.append({k: "true" if v else "false" for k, v in row.items()})
    require(p["observations"] == observations, "Profile trace adapter differs from pinned observations")
    return p


class Context:
    def __init__(self, directory, profile, model):
        self.directory, self.profile, self.model = directory, profile, model
        require(model.get("schema") == "k7-native-model-export-v1", "Model schema")
        identity(model, profile)
        self.b = BDD(model["bdd_variable_count"])
        exact_list(model.get("bdd_variable_order"), range(self.b.n), "Model variable order")
        self.fields = model["fields"]
        require(isinstance(self.fields, list) and len(self.fields) <= 32, "Field roster/cap")
        expected = profile["expected_fields_in_native_order"]
        require(len(self.fields) == len(expected), "Complete public/AUX field count")
        self.by_name, self.current, self.next, self.env_next, self.sys_next = {}, [], [], [], []
        self.prime, self.unprime, self.enc = {}, {}, {}
        for field, exp in zip(self.fields, expected):
            name = field["name"]
            require(name not in self.by_name and name == exp["name"], "Native field order/identity")
            require(field["owner"] == exp["owner"] and field["role"] == exp["role"], "Native field ownership")
            values = field["values"]
            require(values == sorted(exp["domain"]) and type(field["domain_size"]) is int
                    and field["domain_size"] == len(values), "Native field domain")
            cb, nb = field["current_bits"], field["next_bits"]
            require(isinstance(cb, list) and isinstance(nb, list) and len(cb) == len(nb) and cb,
                    "Field current/next bit pairing")
            exact_list(cb, cb, "Field current bits")
            exact_list(nb, nb, "Field next bits")
            require(all(0 <= x < self.b.n for x in cb+nb), "Field bit outside manager")
            require(not set(cb+nb) & set(self.current+self.next) and not set(cb) & set(nb), "Overlapping field bits")
            require(set(field["encoding"]) == set(values), "Value encoding roster")
            codes = set()
            self.enc[name] = {}
            for value in values:
                e = field["encoding"][value]
                c = bit_map(e["current"], cb, "Current value encoding")
                n = bit_map(e["next"], nb, "Next value encoding")
                require(tuple(c[v] for v in cb) == tuple(n[v] for v in nb), "Current/next encoding disagreement")
                code = tuple(c[v] for v in cb)
                require(code not in codes, "Noninjective value encoding")
                codes.add(code)
                self.enc[name][value] = (c, n)
            self.by_name[name] = field
            self.current.extend(cb); self.next.extend(nb)
            (self.env_next if field["owner"] == "ENV" else self.sys_next).extend(nb)
            self.prime.update(zip(cb, nb)); self.unprime.update(zip(nb, cb))
        require(set(self.current+self.next) == set(range(self.b.n)), "Unaccounted native bit/helper")
        exact_list(model.get("all_current_bits"), self.current, "Current bit union")
        exact_list(model.get("all_next_bits"), self.next, "Next bit union")
        require(model.get("public_fields") == {"ENV": profile["public_ENV"], "SYS": profile["public_SYS"]}, "Public field roster")
        self.env = profile["public_ENV"]
        self.sys = [f["name"] for f in self.fields if f["owner"] == "SYS"]
        self.public = profile["public_ENV"] + profile["public_SYS"]
        self.current_env = [x for f in self.fields if f["owner"] == "ENV" for x in f["current_bits"]]
        self.current_sys = [x for f in self.fields if f["owner"] == "SYS" for x in f["current_bits"]]
        self.refs = {}
        self.formulas = {k: self.compile(v) for k, v in profile["formulas"].items()}
        self.justices = {owner: [self.compile(x) for x in profile["justices"][owner]] for owner in ("ENV", "SYS")}
        self.domain = self.b.conj(*(self.domain_of(f, False) for f in self.fields))
        self.domain_en = self.b.conj(*(self.domain_of(f, True) for f in self.fields if f["owner"] == "ENV"))
        self.domain_sn = self.b.conj(*(self.domain_of(f, True) for f in self.fields if f["owner"] == "SYS"))

    def domain_of(self, field, prime):
        return self.b.disj(*(self.literal(field["name"], v, prime) for v in field["values"]))

    def literal(self, name, value, prime=False):
        require(name in self.enc and value in self.enc[name] and type(prime) is bool, "Source AST field/domain")
        return self.b.cube(self.enc[name][value][int(prime)])

    def compile(self, ast):
        if type(ast) is bool: return int(ast)
        require(isinstance(ast, list) and ast, "Source AST node")
        op = ast[0]
        if op == "var":
            require(len(ast) == 3 and set(self.enc.get(ast[1], {})) == {"false", "true"}, "Source boolean field")
            return self.literal(ast[1], "true", ast[2])
        if op == "eq":
            require(len(ast) == 4, "Source equality arity")
            return self.literal(ast[1], ast[2], ast[3])
        args = [self.compile(x) for x in ast[1:]]
        if op == "not":
            require(len(args) == 1, "Source not arity")
            return self.b.neg(args[0])
        if op in ("and", "or"):
            return (self.b.conj if op == "and" else self.b.disj)(*args)
        require(op in ("implies", "iff") and len(args) == 2, "Source AST operator/arity")
        return (self.b.implies if op == "implies" else self.b.iff)(*args)

    def read_bdd(self, ref, allowed=None):
        path = pinned_file(self.directory, ref)
        key = (path.name, ref["sha256"])
        if key not in self.refs:
            u, meta = self.b.read_native(file_bytes(path, 8*1024*1024))
            self.refs[key] = (u, meta)
        u, meta = self.refs[key]
        support = self.b.support(u)
        exact_list(ref.get("support"), support, "Saved BDD support metadata")
        require(type(ref.get("node_count")) is int and ref["node_count"] == meta["node_count"], "Saved BDD node count")
        require(type(ref.get("zero")) is bool and ref["zero"] == (u == 0)
                and type(ref.get("one")) is bool and ref["one"] == (u == 1), "Saved BDD constant metadata")
        require(meta["order"] is None or meta["order"] == self.model["bdd_variable_order"], "Saved BDD order/model mismatch")
        if allowed is not None:
            require(self.b.support(u) <= set(allowed), "BDD has forbidden support: " + path.name)
        return u

    def equal(self, ref, expected, label, allowed=None):
        require(self.read_bdd(ref, allowed) == expected, label + " differs from independent source equation")

    def valuation(self, v, label, names=None):
        names = list(self.by_name) if names is None else names
        require(isinstance(v, dict) and set(v) == set(names)
                and all(type(v[k]) is str and v[k] in self.enc[k] for k in names), label + " valuation/domain")
        return v

    def bits(self, v, prime=False):
        out = {}
        for name, value in v.items(): out.update(self.enc[name][value][int(prime)])
        return out

    def cube(self, v, prime=False):
        return self.b.cube(self.bits(v, prime))

    def singleton(self, u):
        if u == 0: return None
        values = {}
        for name, f in self.by_name.items():
            candidates = [value for value in f["values"] if self.b.conj(u, self.literal(name, value)) == u]
            if len(candidates) != 1: return None
            values[name] = candidates[0]
        return values if self.cube(values) == u else None

    def audit_model(self):
        p, m, b = self.profile, self.model, self.b
        require(m["input"]["sha256"] == p["source"]["sha256"] and m["input"]["bytes"] == p["source"]["bytes"], "Native source fixture pin")
        limits = {"thetaE": self.current_env, "thetaS": self.current, "rhoE": self.current+self.env_next,
                  "rhoS": self.current+self.next}
        for key, u in self.formulas.items(): self.equal(m["original_bdds"][key], u, key, limits[key])
        for key, u, allowed in (("domain", self.domain, self.current), ("domain_ENV_next", self.domain_en, self.env_next),
                                ("domain_SYS_next", self.domain_sn, self.sys_next)):
            self.equal(m["original_bdds"][key], u, key, allowed)
        for owner in ("ENV", "SYS"):
            refs = m["original_justices"][owner]
            require(len(refs) == len(self.justices[owner]), "Original justice roster/order")
            for ref, u in zip(refs, self.justices[owner]): self.equal(ref, u, "Original " + owner + " justice", self.current)
        require(b.conj(self.formulas["rhoE"], b.neg(self.domain_en)) == 0, "ENV relation outside next domain")
        require(b.conj(self.formulas["rhoS"], b.neg(self.domain_sn)) == 0, "SYS relation outside next domain")
        inventory = m.get("source_inventory")
        require(isinstance(inventory, dict) and set(inventory) == {"parsed", "translated", "native_behaviors"}, "Complete source inventory missing")
        for phase in ("parsed", "translated"):
            inv = inventory[phase]
            for owner in ("ENV", "SYS", "AUX"):
                require(isinstance(inv.get(owner), dict), "Source inventory player")
                for c in inv[owner]["constraints"]:
                    require("spec_ast" in c and "trace_id" in c, "Source constraint structure missing")
                for c in inv[owner]["patterns"]:
                    require("actuals_ast" in c and "trace_id" in c, "Source pattern structure missing")
        require([v["name"] for v in inventory["parsed"]["ENV"]["variables"]] == p["public_ENV"], "Parsed ENV field identity")
        require([v["name"] for v in inventory["parsed"]["SYS"]["variables"]] == p["public_SYS"], "Parsed SYS field identity")
        native = inventory["native_behaviors"]
        require(native["env_justice_count"] == len(self.justices["ENV"]) and native["sys_justice_count"] == len(self.justices["SYS"]), "Behavior justice count")
        return {"status": "PASS", "field_count": len(self.fields), "source_formula_equivalence": "EXACT_CANONICAL_BDD",
                "ENV_justice_count": len(self.justices["ENV"]), "SYS_justice_count": len(self.justices["SYS"]),
                "source_inventory_claim": "Structural source receipt retained; actual translation/code provenance is separately audited."}

    def audit_replay(self, replay):
        require(replay.get("schema") == "k7-original-prefix-replay-v1", "Replay schema")
        identity(replay, self.profile)
        require(replay.get("original_initializers_applied_once") is True
                and replay.get("manual_monitor_initialization") is False
                and replay.get("unobserved_outgoing_endpoint_edge_processed") is False, "Replay temporal boundary")
        obs = replay["observations"]
        require(obs == self.profile["observations"] and obs, "Replay differs from published full public observations")
        order = replay["public_field_order"]
        require(isinstance(order, list) and len(order) == len(set(order)) and set(order) == set(self.public), "Trace public field roster")
        tsv = ("\t".join(order)+"\n" + "".join("\t".join(row[k] for k in order)+"\n" for row in obs)).encode("utf-8")
        require(replay["trace_input"]["sha256"] == sha_bytes(tsv) and replay["trace_input"]["bytes"] == len(tsv), "Canonical public TSV byte pin")
        for row in obs: self.valuation(row, "Public observation", self.public)
        states, edges = replay["states"], replay["edges"]
        require(len(states) == len(obs) and len(edges) == len(obs)-1, "Replay complete state/edge count")
        b, f = self.b, self.formulas
        u = b.conj(f["thetaE"], f["thetaS"], self.cube(obs[0]))
        require(b.conj(u, b.neg(self.domain)) == 0, "Initial replay outside domain")
        for i, saved in enumerate(states):
            require(type(saved["observation_index"]) is int and saved["observation_index"] == i, "Replay observation index")
            self.equal(saved["states"], u, "Replay state " + str(i), self.current)
            if i < len(edges):
                edge = edges[i]
                require(type(edge["edge_index"]) is int and edge["edge_index"] == i, "Replay edge index")
                rel = b.conj(u, f["rhoE"], f["rhoS"], self.cube(obs[i+1], True))
                post = b.exists(rel, self.current)
                self.equal(edge["relation"], rel, "Replay relation " + str(i))
                self.equal(edge["successor_before_unprime"], post, "Replay postimage " + str(i), self.next)
                u = b.rename(post, self.unprime)
                require(b.conj(u, b.neg(self.domain)) == 0, "Replay successor outside domain")
        self.equal(replay["endpoint"], u, "Replay endpoint", self.current)
        val = self.singleton(u)
        status = "EMPTY" if u == 0 else "SINGLETON" if val is not None else "AMBIGUOUS"
        require(replay["endpoint_status"] == status and replay["entry_valuation"] == val, "Replay endpoint cardinality/valuation")
        if val is None: require(replay["entry_bits"] is None, "Non-singleton replay bits")
        else: require(bit_map(replay["entry_bits"], self.current, "Replay entry bits") == self.bits(val), "Replay entry bit encoding")
        self.endpoint, self.entry = u, val
        return {"status": "PASS", "observation_count": len(obs), "endpoint_status": status,
                "entry_valuation": val, "candidate_initializers_applied_once": True, "pending_AUX_preserved": True}

    def viability(self):
        b, f = self.b, self.formulas
        alive = b.exists(f["rhoE"], self.env_next)
        require(b.support(alive) <= set(self.current), "Alive unsupported dependence")
        v, iterations = self.domain, 0
        while True:
            if iterations >= 65536: raise ResourceRefusal("Independent V iteration budget exceeded")
            response = b.exists(b.conj(f["rhoS"], b.rename(v, self.prime)), self.sys_next)
            cp = b.forall(b.implies(f["rhoE"], response), self.env_next)
            require(b.support(cp) <= set(self.current), "CPre unsupported dependence")
            nxt = b.conj(self.domain, alive, cp)
            require(b.conj(nxt, b.neg(v)) == 0, "Independent V iteration not descending")
            iterations += 1
            if nxt == v: return v, alive, iterations
            v = nxt

    def audit_normalization(self, result, pipeline):
        b = self.b
        projections = result["entry_projections"]
        require(projections.get("original_initializers_reapplied") is False and projections.get("monitors_reset") is False, "Handoff initializer/monitor reset")
        e = b.exists(self.endpoint, self.current_sys)
        s = b.exists(self.endpoint, self.current_env)
        self.equal(projections["ENV"], e, "Entry ENV projection", self.current_env)
        self.equal(projections["SYS"], s, "Entry SYS projection", self.current_sys)
        self.equal(projections["complete_cube"], self.endpoint, "Entry full cube", self.current)
        require(b.conj(e, s) == self.endpoint, "Entry projection join")
        self.v, rounds = self.domain, None
        if pipeline == "helperfree":
            self.v, alive, rounds = self.viability()
            self.equal(result["V"], self.v, "Greatest viable set", self.current)
            self.equal(result["alive"], alive, "Alive", self.current)
            norm = result["normalization"]
            require(norm.get("V_restriction") is True and norm.get("helper_added") is False
                    and norm.get("ENV_justice_copies") == len(self.justices["ENV"]), "Normalization declaration")
            self.equal(norm["restricted_rhoS"], b.conj(self.formulas["rhoS"], self.v, b.rename(self.v, self.prime)), "Restricted SYS relation")
        else:
            require("V" not in result and "normalization" not in result, "Undeclared strict pipeline normalization")
        self.equal(result["residual_thetaE"], e, "Residual ENV initializer", self.current_env)
        self.equal(result["residual_thetaS"], b.conj(s, self.v) if pipeline == "helperfree" else s,
                   "Residual SYS initializer", self.current)
        expected = {"ENV": self.justices["ENV"], "SYS": self.justices["SYS"] + (self.justices["ENV"] if pipeline == "helperfree" else [])}
        for owner in ("ENV", "SYS"):
            refs = result["preconstructor_justices"][owner]
            require(len(refs) == len(expected[owner]), "Preconstructor justice roster")
            for ref, u in zip(refs, expected[owner]): self.equal(ref, u, "Preconstructor justice", self.current)
        self.rank_size = len(expected["SYS"]) or 1
        if result["status"] != "COMPLETE_EMPTY_V_REJECTION":
            for owner in ("ENV", "SYS"):
                goals = expected[owner] or [1]
                refs = result["solver_input_justices"][owner]
                require(len(refs) == len(goals), "Constructor TRUE padding/order")
                for ref, u in zip(refs, goals): self.equal(ref, u, "Solver justice", self.current)
        return {"status": "PASS", "V_fixed_point_iterations": rounds, "V_empty": self.v == 0,
                "source_ENV_justice_copies": len(self.justices["ENV"]) if pipeline == "helperfree" else 0,
                "new_controller_memory": "rank0", "original_initializers_reapplied": False}


def graph_analyzer():
    path = BASE / "graph_fairness.py"
    require(sha(path) == GRAPH_SHA256, "Reviewed graph fairness checker drift")
    spec = importlib.util.spec_from_file_location("k7_reviewed_graph_fairness", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.analyze_graph


def analyze_controller(ctx, data, pipeline):
    require(data.get("schema") == "released-concrete-controller-export-v2", "Controller schema")
    identity(data, ctx.profile, pipeline)
    require(data.get("complete") is True and data.get("controller_certified") is False, "Raw controller status")
    require(data.get("entry_mode") == "current_history" and data.get("entry_valuation") == ctx.entry,
            "Controller factual entry")
    require(bit_map(data["entry_bits"], ctx.current, "Controller entry bits") == ctx.bits(ctx.entry), "Controller entry bits mismatch")
    require(data.get("handoff") == {"policy": "new_controller_rank0", "rank": 0}, "Controller memory handoff")
    require(type(data.get("rank_domain_size")) is int and data["rank_domain_size"] == ctx.rank_size, "Rank domain")
    nodes = data["nodes"]
    require(isinstance(nodes, list) and nodes, "Controller state roster")
    if len(nodes) > MAX_STATES: raise ResourceRefusal("Controller state budget exceeded")
    by_id, identities, flat, starts = {}, set(), [], []
    required = {"id", "native_id", "rank", "rank_class", "rank_info", "initial", "valuation", "bits", "successors"}
    for node in nodes:
        require(isinstance(node, dict) and set(node) == required, "Controller node schema")
        sid = node["id"]
        require(type(sid) is str and re.fullmatch(r"0|[1-9][0-9]*", sid) is not None and sid not in by_id,
                "Native state ID")
        require(type(node["native_id"]) is int and str(node["native_id"]) == sid, "Native ID correspondence")
        rank = node["rank"]
        require(type(rank) is int and 0 <= rank < ctx.rank_size, "Native rank range")
        require(node["rank_class"] == "tau.smlab.syntech.games.gr1.GR1RankInfo"
                and node["rank_info"] == f"System Justice {rank}", "Native rank identity")
        require(type(node["initial"]) is bool, "Native initial flag")
        val = ctx.valuation(node["valuation"], "Controller node")
        require(bit_map(node["bits"], ctx.current, "Controller node bits") == ctx.bits(val), "Controller node bits mismatch")
        key = (rank, tuple(val[k] for k in ctx.by_name))
        require(key not in identities, "Duplicate valuation/controller-memory identity")
        identities.add(key)
        require(isinstance(node["successors"], list) and all(type(t) is str for t in node["successors"]), "Raw successor vector")
        flat.extend([[sid, t] for t in node["successors"]])
        if len(flat) > MAX_EDGES: raise ResourceRefusal("Controller edge budget exceeded")
        if node["initial"]:
            starts.append(sid)
            require(val == ctx.entry and rank == 0, "Factual initial state/rank changed")
        by_id[sid] = node
    require(len(starts) == 1, "Exactly one factual rank0 start required")
    require(data["api_state_order"] == list(by_id) and data["edges"] == flat, "Raw API vector/edge correspondence")
    for k, n in (("api_state_count", len(nodes)), ("api_transition_count", len(flat)), ("exported_edge_count", len(flat))):
        require(type(data.get(k)) is int and data[k] == n, "API count mismatch: " + k)
    require(len({tuple(e) for e in flat}) == len(flat) and all(t in by_id for _, t in flat), "Duplicate/dangling raw edge")
    parent, queue = {starts[0]: None}, deque(starts)
    while queue:
        u = queue.popleft()
        for t in by_id[u]["successors"]:
            if t not in parent: parent[t] = u; queue.append(t)
    require(set(parent) == set(by_id), "Unreachable emitted state")
    env_inputs = list(product(*(ctx.by_name[k]["values"] for k in ctx.env)))
    if len(env_inputs)*len(nodes) > MAX_INPUT_CHECKS: raise ResourceRefusal("Legal input enumeration budget exceeded")
    counts, failures = {}, []
    for sid, node in by_id.items():
        v = node["valuation"]
        current = ctx.bits(v)
        legal = {xs for xs in env_inputs if ctx.b.evaluate(ctx.formulas["rhoE"], current | ctx.bits(dict(zip(ctx.env, xs)), True))}
        counts[sid] = len(legal)
        responses = defaultdict(list)
        for tid in node["successors"]:
            w = by_id[tid]["valuation"]
            responses[tuple(w[k] for k in ctx.env)].append(tid)
            if not ctx.b.evaluate(ctx.formulas["rhoS"], current | ctx.bits(w, True)):
                failures.append({"kind": "ORIGINAL_SYS_SAFETY", "source": sid, "target": tid})
        for kind, bad in (("MISSING_LEGAL_INPUT", legal-set(responses)), ("ILLEGAL_ENV_EDGE", set(responses)-legal)):
            if bad: failures.append({"kind": kind, "source": sid, "inputs": [dict(zip(ctx.env, xs)) for xs in sorted(bad)]})
        for xs, targets in responses.items():
            if len(targets) != 1:
                failures.append({"kind": "NONDETERMINISTIC_RESPONSE_OR_MEMORY", "source": sid,
                                 "input": dict(zip(ctx.env, xs)), "targets": targets})
        if pipeline == "helperfree" and not ctx.b.evaluate(ctx.v, current):
            failures.append({"kind": "V_INVARIANCE", "source": sid})
    if failures:
        raise ControllerDefect(failures)
    graph = {"states": list(by_id), "edges": flat, "starts": starts}
    for owner, key in (("ENV", "env_justice"), ("SYS", "sys_justice")):
        graph[key] = [[sid for sid, node in by_id.items() if ctx.b.evaluate(u, ctx.bits(node["valuation"]))]
                      for u in ctx.justices[owner]]
    fair = graph_analyzer()(graph)
    witnesses = []
    if not fair["nonconflicting"]["pass"]:
        bad = set(fair["nonconflicting"]["failing_states"])
        terminal = next((sid for sid in parent if sid in bad and counts[sid] == 0), next(sid for sid in parent if sid in bad))
        ids, cursor = [], terminal
        while cursor is not None: ids.append(cursor); cursor = parent[cursor]
        ids.reverse()
        witnesses.append({"kind": "REACHABLE_ENV_DEADEND" if counts[terminal] == 0 else "NO_FAIR_CONTINUATION",
                          "prefix": [{"id": sid, "rank": by_id[sid]["rank"], "valuation": by_id[sid]["valuation"],
                                      "legal_ENV_input_count": counts[sid]} for sid in ids],
                          "all_bad_states": fair["nonconflicting"]["failing_states"]})
    witnesses.extend(fair["strict_liveness"]["counterexamples"])
    return {"state_count": len(nodes), "edge_count": len(flat), "legal_input_count": sum(counts.values()),
            "structural_safety_coverage_determinism": "PASS", "strict_controller_pass": fair["strict_liveness"]["pass"],
            "nonconflicting_pass": fair["nonconflicting"]["pass"],
            "kind_controller_pass": fair["strict_liveness"]["pass"] and fair["nonconflicting"]["pass"],
            "witnesses": witnesses, "fairness": fair, "graph": graph}


def base_certificate(fixture, pipeline):
    return {"schema": "k7-independent-admission-certificate-v1", "status": "INVALID", "fixture_id": fixture,
            "pipeline": pipeline, "model_sha256": None, "replay_sha256": None, "result_sha256": None,
            "controller_sha256": None, "checker_sha256": sha(Path(__file__)), "source_profile_pins": None,
            "original_model_audit": None, "factual_replay_audit": None, "normalization_and_handoff_audit": None,
            "strict_controller_pass": None, "nonconflicting_pass": None, "kind_controller_pass": None, "witnesses": [],
            "failure_stage": "SOURCE_BINDING", "model_and_replay_validated": False,
            "refusal_scope": "QUALIFICATION_INTEGRITY", "controller_defects": [],
            "trust_boundary": "Exact exported graph and separately audited frozen native producer/runtime invocation provenance; certificate does not itself establish historical invocation."}


def _check_arm(directory, fixture, pipeline, cert):
    require(pipeline in ("original_strict", "helperfree"), "Unknown pipeline")
    require(directory.is_dir() and not directory.is_symlink(), "Arm directory type")
    profile = load_profile(fixture)
    cert["source_profile_pins"] = {"profiles_sha256": PROFILE_SHA256, "source": profile["source"], "trace": profile["trace"],
                                   "bdd_core_sha256": sha(BASE / "bdd_core.py"), "graph_fairness_sha256": GRAPH_SHA256}
    result = read_json(directory / "result.json")
    cert["result_sha256"] = sha(directory / "result.json")
    require(result.get("schema") == "k7-native-admission-production-v1", "Result schema")
    identity(result, profile, pipeline)
    require(result.get("teardown") == "COMPLETED" and result.get("controller_certified") is False, "Native completion status")
    require(result.get("input_sha256") == profile["source"]["sha256"], "Result/source fixture pin")
    mp = pinned_file(directory, result["model_export"])
    rp = pinned_file(directory, result["replay_export"])
    cert["model_sha256"], cert["replay_sha256"] = sha(mp), sha(rp)
    model, replay = read_json(mp), read_json(rp)
    ctx = Context(directory, profile, model)
    cert["failure_stage"] = "ORIGINAL_MODEL_CHECK"
    cert["original_model_audit"] = ctx.audit_model()
    cert["failure_stage"] = "FACTUAL_REPLAY_CHECK"
    cert["factual_replay_audit"] = ctx.audit_replay(replay)
    require(result.get("entry_valuation") == ctx.entry and result.get("trace_sha256") == replay["trace_input"]["sha256"], "Result/replay correspondence")
    cert["model_and_replay_validated"] = True
    cert["failure_stage"] = "NATIVE_RESULT_BOUNDARY"
    status = result["status"]
    allowed = {"COMPLETE_HISTORY_REJECTION", "COMPLETE_EMPTY_V_REJECTION", "COMPLETE_REGION_REJECTION",
               "COMPLETE_CONTROLLER_EXPORTED", "COMPLETE_EXTRACTION_OR_EXPORT_FAILURE"}
    require(status in allowed, "Incomplete native production: " + str(status))
    if status == "COMPLETE_HISTORY_REJECTION":
        require(ctx.entry is None and result.get("history_rejection_reason") == replay["endpoint_status"], "Unsupported history rejection")
        require(result.get("native_solver_called") is False and result.get("controller_extraction_called") is False
                and result.get("controller_export") is None, "History-refusal execution boundary")
        cert.update(status="VALID_SEMANTIC_REFUSAL", refusal_kind="HISTORY_"+replay["endpoint_status"], failure_stage=None,
                    refusal_scope="CANDIDATE_SEMANTIC")
        return ctx, result, None
    require(ctx.entry is not None, "Non-singleton history proceeded")
    cert["failure_stage"] = "NORMALIZATION_AND_HANDOFF_CHECK"
    cert["normalization_and_handoff_audit"] = ctx.audit_normalization(result, pipeline)
    if status == "COMPLETE_EMPTY_V_REJECTION":
        require(pipeline == "helperfree" and ctx.v == 0 and result.get("entry_in_region") is False, "Unsupported empty-V refusal")
        ctx.equal(result["final_region"], 0, "Empty-V final region", ctx.current)
        require(result.get("native_solver_called") is False and result.get("controller_extraction_called") is False
                and result.get("controller_export") is None, "Empty-V refusal execution boundary")
        cert.update(status="VALID_SEMANTIC_REFUSAL", refusal_kind="EMPTY_V_INDEPENDENTLY_CHECKED", failure_stage=None,
                    refusal_scope="CANDIDATE_SEMANTIC")
        return ctx, result, None
    require(result.get("native_solver_called") is True, "Missing native solver call receipt")
    cert["failure_stage"] = "NATIVE_REGION_CHECK"
    w = ctx.read_bdd(result["native_W"], ctx.current)
    region = ctx.b.conj(w, ctx.v if pipeline == "helperfree" else ctx.domain)
    ctx.equal(result["final_region"], region, "Final region", ctx.current)
    member = ctx.b.conj(ctx.endpoint, ctx.b.neg(region)) == 0
    require(type(result.get("native_residual_initial_verdict")) is bool and result["native_residual_initial_verdict"] == member
            and type(result.get("entry_in_region")) is bool and result["entry_in_region"] == member, "Native region/entry verdict mismatch")
    if status == "COMPLETE_REGION_REJECTION":
        require(not member and result.get("controller_extraction_called") is False and result.get("controller_export") is None,
                "Unsupported native region refusal")
        cert.update(status="VALID_SEMANTIC_REFUSAL", refusal_kind="SOURCE_QUALIFIED_NATIVE_REGION_REFUSAL", failure_stage=None,
                    refusal_scope="CANDIDATE_SEMANTIC",
                    refusal_claim="Native negative region output bound and internally checked; independent unrealizability is not claimed.")
        return ctx, result, None
    require(member and result.get("controller_extraction_called") is True, "Extraction without positive region")
    if status == "COMPLETE_EXTRACTION_OR_EXPORT_FAILURE":
        require(type(result.get("extraction_exception")) is str and result.get("controller_export") is None,
                "Missing technical extraction failure receipt")
        cert.update(status="INVALID", refusal_kind="TECHNICAL_EXTRACTION_OR_EXPORT_FAILURE", failure_stage="NATIVE_EXTRACTION_OR_EXPORT",
                    refusal_scope="CANDIDATE_TECHNICAL")
        return ctx, result, None
    cp = pinned_file(directory, result["controller_export"])
    cert["failure_stage"] = "CONTROLLER_BINDING"
    cert["controller_sha256"] = sha(cp)
    controller = read_json(cp)
    pin = result["controller_export"]
    require(pin.get("complete") is True and all(type(pin.get(k)) is int and pin[k] == controller.get(k)
            for k in ("api_state_count", "api_transition_count", "exported_edge_count")), "Result/controller completeness counts")
    require(controller.get("model_sha256") == cert["model_sha256"] and controller.get("replay_sha256") == cert["replay_sha256"], "Controller model/replay pins")
    cert["failure_stage"] = "CONTROLLER_CHECK"
    proof = analyze_controller(ctx, controller, pipeline)
    for key in ("strict_controller_pass", "nonconflicting_pass", "kind_controller_pass", "witnesses"):
        cert[key] = proof[key]
    cert.update(status="VALID_EXPORT_CERTIFICATE", controller_audit=proof, failure_stage=None, refusal_scope=None)
    return ctx, result, controller


def check_arm(arm_directory, expected_fixture_id, expected_pipeline):
    cert = base_certificate(expected_fixture_id, expected_pipeline)
    try:
        _check_arm(Path(arm_directory), expected_fixture_id, expected_pipeline, cert)
    except ControllerDefect as error:
        cert.update(status="INVALID", error=str(error), refusal_scope="CANDIDATE_CONTROLLER", controller_defects=error.defects,
                    witnesses=error.defects)
    except ResourceRefusal as error:
        cert.update(status="RESOURCE_REFUSAL", error=str(error), refusal_scope="CANDIDATE_TECHNICAL")
    except (Invalid, OSError, UnicodeError, json.JSONDecodeError, KeyError, TypeError, ValueError, IndexError, RecursionError) as error:
        cert.update(status="INVALID", error=type(error).__name__ + ": " + str(error))
    return cert


def load_verified_semantics(arm_directory, expected_fixture_id, expected_pipeline):
    """Read-only runtime adapter; raises on any incomplete/invalid certificate.

    Returns (Context, certificate), with original predicates available as
    ctx.formulas and evaluated by ctx.b.evaluate(u, ctx.bits(current) |
    ctx.bits(next, True)). Native inputs require only the ENV part of next for
    rhoE. This validates the exact raw graph too; it never mutates artifacts.
    """
    cert = base_certificate(expected_fixture_id, expected_pipeline)
    ctx, _, _ = _check_arm(Path(arm_directory), expected_fixture_id, expected_pipeline, cert)
    require(cert["status"] == "VALID_EXPORT_CERTIFICATE", "Runtime requires a fully certified raw export")
    return ctx, cert


def canonical_digest(value):
    return sha_bytes(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8"))


def _check_runtime(directory, runtime_path, fixture, pipeline, out):
    native_cert = base_certificate(fixture, pipeline)
    ctx, _, raw = _check_arm(directory, fixture, pipeline, native_cert)
    require(native_cert["status"] == "VALID_EXPORT_CERTIFICATE", "Runtime requires a completely certified native controller")
    out["native_certificate"] = native_cert
    out["model_and_replay_validated"] = True
    out["failure_stage"] = "RUNTIME_BINDING"
    cp = directory / "native_certificate.json"
    require(read_json(cp) == native_cert, "Saved native certificate differs from current deterministic certification")
    consumer = BASE.parent / "k7_admission_activation_preparation/model_consumer.py"
    require(sha(consumer) == CONSUMER_SHA256, "Frozen model consumer source drift")
    data = read_json(runtime_path)
    out["runtime_export_sha256"] = sha(runtime_path)
    require(data.get("schema") == "k7-model-executor-export-v1", "Runtime export schema")
    require(data.get("fixture_id") == fixture and data.get("pipeline") == pipeline, "Runtime identity")
    bindings = {"controller_sha256": native_cert["controller_sha256"], "model_sha256": native_cert["model_sha256"],
                "replay_sha256": native_cert["replay_sha256"], "result_sha256": native_cert["result_sha256"],
                "native_certificate_sha256": sha(cp), "consumer_source_sha256": CONSUMER_SHA256}
    require(all(data.get(k) == v for k, v in bindings.items()), "Runtime/source/native certificate byte pins")
    require(data.get("full_raw_graph_bijection") is True and data.get("exploration_from_actual_activation") is True
            and data.get("live_model_rewound") is False, "Runtime exploration contract")
    ticket = data["activation_ticket"]
    require(set(ticket) == {"episode_id", "epoch", "public_valuation", "history_sha256", "fixture_id", "pipeline",
                            "semantic_valuation", "chosen_start_id", "bindings"}, "Activation ticket schema")
    require(ticket["episode_id"] == ctx.profile["case_id"] and type(ticket["epoch"]) is int and ticket["epoch"] == 0,
            "Initial paused episode/epoch")
    require(ticket["public_valuation"] == ctx.profile["observations"][-1]
            and ticket["history_sha256"] == canonical_digest(ctx.profile["observations"]), "Activation ticket public history")
    require(ticket["fixture_id"] == fixture and ticket["pipeline"] == pipeline and ticket["semantic_valuation"] == ctx.entry
            and ticket["bindings"] == bindings, "Activation ticket semantic/source binding")
    by_id = {node["id"]: node for node in raw["nodes"]}
    start = next(sid for sid, node in by_id.items() if node["initial"])
    require(ticket["chosen_start_id"] == start, "Activation chosen native start")
    receipt = data["activation_receipt"]
    before = {k: ticket[k] for k in ("episode_id", "epoch", "public_valuation", "history_sha256")}
    after = {"native_id": by_id[start]["native_id"], "rank": 0, "valuation": ctx.entry, "epoch": 1}
    require(receipt.get("status") == "ACTIVATED_MODEL" and receipt.get("before") == before
            and receipt.get("after") == after and receipt.get("entry_values_unchanged") is True
            and type(receipt.get("new_private_rank")) is int and receipt["new_private_rank"] == 0
            and receipt.get("chosen_start_id") == start and receipt.get("bindings") == bindings,
            "Atomic activation entry/epoch/rank correspondence")
    require(type(receipt["before"]["epoch"]) is int and all(type(receipt["after"][k]) is int
            for k in ("native_id", "rank", "epoch")), "Activation native scalar types")
    out["failure_stage"] = "RUNTIME_GRAPH_CHECK"
    runtime_nodes = data["runtime_nodes"]
    require(isinstance(runtime_nodes, list) and len(runtime_nodes) == len(by_id), "Runtime/raw state count")
    seen = set()
    for node in runtime_nodes:
        require(isinstance(node, dict) and set(node) == {"id", "native_id", "rank", "valuation", "initial"}, "Runtime node schema")
        sid = node["id"]
        require(type(sid) is str and sid in by_id and sid not in seen, "Runtime native ID bijection")
        seen.add(sid)
        source = by_id[sid]
        require(node == {key: source[key] for key in node}, "Runtime/raw complete state and memory mismatch")
        require(type(node["native_id"]) is int and type(node["rank"]) is int and type(node["initial"]) is bool,
                "Runtime state scalar types")
        ctx.valuation(node["valuation"], "Runtime state")
    require(seen == set(by_id), "Missing runtime state")
    depth, queue = {start: 0}, deque([start])
    while queue:
        sid = queue.popleft()
        for tid in by_id[sid]["successors"]:
            if tid not in depth: depth[tid] = depth[sid]+1; queue.append(tid)
    transitions = data["executed_transitions"]
    require(isinstance(transitions, list) and len(transitions) == len(raw["edges"]), "Runtime/raw invocation count")
    edges, used_inputs = [], set()
    for event in transitions:
        require(isinstance(event, dict) and set(event) == {"source", "target", "input", "before", "after", "writes"}, "Actual step event schema")
        sid, tid = event["source"], event["target"]
        require(type(sid) is str and type(tid) is str and sid in by_id and tid in by_id, "Actual step ID")
        source, target = by_id[sid], by_id[tid]
        inp = ctx.valuation(event["input"], "Actual ENV input", ctx.env)
        require(inp == {k: target["valuation"][k] for k in ctx.env}, "ENV input not committed to actual successor")
        input_key = (sid, tuple(inp[k] for k in ctx.env))
        require(input_key not in used_inputs, "Repeated runtime state/input invocation")
        used_inputs.add(input_key)
        expected_before = {"native_id": source["native_id"], "rank": source["rank"], "valuation": source["valuation"], "epoch": 1+depth[sid]}
        expected_after = {"native_id": target["native_id"], "rank": target["rank"], "valuation": target["valuation"], "epoch": 2+depth[sid]}
        require(event["before"] == expected_before and event["after"] == expected_after, "Actual step complete state/rank/epoch transition")
        for state in (event["before"], event["after"]):
            require(type(state["native_id"]) is int and type(state["rank"]) is int and type(state["epoch"]) is int,
                    "Actual step native scalar type")
        values = target["valuation"]
        expected_writes = {role: {f["name"]: values[f["name"]] for f in ctx.fields if f["role"] == role}
                           for role in ("ENV", "SYS", "AUX")}
        require(event["writes"] == expected_writes, "Atomic ENV/SYS/AUX write roster/values")
        require(ctx.b.evaluate(ctx.formulas["rhoE"], ctx.bits(source["valuation"]) | ctx.bits(inp, True)), "Actual runtime illegal ENV input")
        require(ctx.b.evaluate(ctx.formulas["rhoS"], ctx.bits(source["valuation"]) | ctx.bits(values, True)), "Actual runtime original SYS violation")
        edges.append([sid, tid])
    require(data["runtime_edges"] == edges and len({tuple(e) for e in edges}) == len(edges)
            and set(map(tuple, edges)) == set(map(tuple, raw["edges"])), "Actual runtime/raw edge bijection")
    require(type(data.get("input_checks")) is int and data["input_checks"] == len(edges), "Actual runtime input count")
    # Recompute properties on the actual event-derived graph, using source labels.
    graph = {"states": list(by_id), "starts": [start], "edges": edges}
    for owner, key in (("ENV", "env_justice"), ("SYS", "sys_justice")):
        graph[key] = [[sid for sid, node in by_id.items() if ctx.b.evaluate(u, ctx.bits(node["valuation"]))]
                      for u in ctx.justices[owner]]
    fair = graph_analyzer()(graph)
    actual = {"strict_controller_pass": fair["strict_liveness"]["pass"], "nonconflicting_pass": fair["nonconflicting"]["pass"],
              "kind_controller_pass": fair["strict_liveness"]["pass"] and fair["nonconflicting"]["pass"]}
    require(all(native_cert[k] == v for k, v in actual.items()), "Executable/raw property disagreement")
    out.update(actual)
    out.update(status="VALID_RUNTIME_CERTIFICATE", failure_stage=None, refusal_scope=None, bindings=bindings,
               state_count=len(by_id), executed_transition_count=len(edges), raw_graph_bijection="PASS", fairness=fair,
               witnesses=native_cert["witnesses"], activation_audit="PASS", actual_transition_audit="PASS")


def check_runtime(arm_directory, runtime_export_path, expected_fixture_id, expected_pipeline):
    """Certify the saved executable graph, conditional on frozen invocation code.

    Historical step invocation is established by the separately audited consumer
    and bound execution receipts; saved graph equality alone cannot prove it.
    """
    out = {"schema": "k7-independent-runtime-certificate-v1", "status": "INVALID", "fixture_id": expected_fixture_id,
           "pipeline": expected_pipeline, "checker_sha256": sha(Path(__file__)), "failure_stage": "NATIVE_CERTIFICATE_CHECK",
           "refusal_scope": "QUALIFICATION_INTEGRITY", "model_and_replay_validated": False,
           "strict_controller_pass": None, "nonconflicting_pass": None, "kind_controller_pass": None, "witnesses": [],
           "trust_boundary": "Actual step invocation depends on audited frozen consumer code and bound execution receipts, not saved graph equality alone."}
    try:
        _check_runtime(Path(arm_directory), Path(runtime_export_path), expected_fixture_id, expected_pipeline, out)
    except ResourceRefusal as error:
        out.update(status="RESOURCE_REFUSAL", error=str(error), refusal_scope="CANDIDATE_TECHNICAL")
    except (Invalid, OSError, UnicodeError, json.JSONDecodeError, KeyError, TypeError, ValueError, IndexError, RecursionError) as error:
        out.update(status="INVALID", error=type(error).__name__+": "+str(error))
    return out


def main():
    if len(sys.argv) != 4:
        print("usage: admission_checker.py ARM_DIRECTORY FIXTURE_ID original_strict|helperfree", file=sys.stderr)
        return 2
    result = check_arm(*sys.argv[1:])
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["status"] in ("VALID_EXPORT_CERTIFICATE", "VALID_SEMANTIC_REFUSAL") else 2


if __name__ == "__main__":
    raise SystemExit(main())
