"""Execute exactly the six prespecified controls through unchanged root drivers."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent.parent
META = ROOT / "success_controls_execution"
PYTHON = "origin:home/.pyenv/versions/3.10.9/bin/python3.10"


def now():
    return datetime.now(timezone.utc).isoformat()


def read(path):
    return json.loads(Path(path).read_text())


def pin(path):
    path = Path(path).resolve(strict=True)
    h = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            size += len(chunk)
            h.update(chunk)
    return {"path": str(path), "bytes": size, "sha256": h.hexdigest()}


def save_new(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def save_progress(value):
    path = META / "PROGRESS.json"
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    temp.replace(path)


def command(driver, candidate, stage):
    argv = [PYTHON, "-I", "-S", "-B", str(ROOT / driver), candidate]
    out = META / f"{candidate}.{stage}.stdout.txt"
    err = META / f"{candidate}.{stage}.stderr.txt"
    started = now()
    tick = time.monotonic()
    with out.open("xb") as stdout, err.open("xb") as stderr:
        result = subprocess.run(argv, cwd=WORK, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, check=False)
    return {"argv": argv, "started_utc": started, "finished_utc": now(),
            "returncode": result.returncode, "elapsed_seconds": time.monotonic() - tick,
            "stdout": pin(out), "stderr": pin(err)}


def main():
    assert len(sys.argv) == 1
    assert not (ROOT / "SUCCESS_CONTROLS_RESULT.json").exists()
    META.mkdir(exist_ok=False)
    plan = read(ROOT / "PRESPECIFIED_SUCCESS_CONTROLS.json")
    order = [x["candidate"] for x in plan["controls"]]
    assert order == ["arbiter__trivial_1", "minepump__trivial_1", "minepump__trivial_2",
                     "traffic_single__trivial_1", "traffic_updated__preferred", "traffic_updated__trivial_1"]
    compiled = read(ROOT / "VARIANT_COMPILE_RECEIPT.json")
    adapter = read(ROOT / "variant_audit/ADAPTER_PACKAGE.json")
    paths = [ROOT / x for x in ["PRESPECIFIED_SUCCESS_CONTROLS.json", "run_intervention_pair.py",
                                "run_pair_audits.py", "run_baseline.py", "VARIANT_COMPILE_RECEIPT.json",
                                "INTERVENTION_PLAN.json", "variant_audit/ADAPTER_PACKAGE.json"]]
    paths += [Path(x["path"]) for x in compiled["sources"] + compiled["classes"] + adapter["files"]]
    paths += [Path(PYTHON), Path(__file__)]
    pins = list({str(p.resolve()): pin(p) for p in paths}.values())
    destinations = {candidate: ROOT / "runs/continuation_01" / candidate for candidate in order}
    absence = {candidate: not (path.exists() or path.is_symlink()) for candidate, path in destinations.items()}
    preflight = {
        "schema": "six-success-controls-execution-preflight-v1", "created_utc": now(),
        "candidate_order": order, "all_output_destinations_absent": all(absence.values()),
        "output_absence": absence, "shared_input_pins": pins,
        "automatic_retries": 0, "root_drivers_modified": False,
        "pair_gate": "COMPLETE_PAIRED_INTERVENTION_AWAITING_SEMANTIC_AUDITS plus input_integrity PASS",
        "execution": "Sequential pair then four existing audit jobs, exactly once per eligible candidate.",
        "native_pair_limits": {"wall_seconds": 30, "rss_bytes": 1073741824,
                               "stdout_bytes": 536870912, "output_tree_bytes": 805306368},
        "audit_wall_seconds": [60, 180, 60, 180], "full_reset_uses": 0,
    }
    save_new(META / "PREFLIGHT.json", preflight)
    ledger = {
        "schema": "six-prespecified-success-controls-result-v1", "status": "RUNNING",
        "started_utc": now(), "prespecified_controls": pin(ROOT / "PRESPECIFIED_SUCCESS_CONTROLS.json"),
        "preflight": pin(META / "PREFLIGHT.json"), "candidate_order": order,
        "rows": [], "automatic_retries": 0, "full_reset_uses": 0,
        "native_pair_driver_calls": 0, "audit_driver_calls": 0,
    }
    stop_shared_mutation = False
    for sequence, candidate in enumerate(order, 1):
        row = {"candidate": candidate, "sequence": sequence, "status": "UNKNOWN_NOT_ATTEMPTED",
               "errors": [], "native_pair_driver_calls": 0, "audit_driver_calls": 0}
        ledger["rows"].append(row)
        case = destinations[candidate]
        try:
            if stop_shared_mutation:
                row["status"] = "UNKNOWN_NOT_ATTEMPTED_SHARED_INPUT_MUTATION"
                continue
            if not all(pin(r["path"]) == r for r in pins):
                stop_shared_mutation = True
                raise RuntimeError("Shared input mutation before candidate")
            if not absence[candidate] or case.exists() or case.is_symlink():
                row["status"] = "UNKNOWN_OUTPUT_DESTINATION_ALREADY_EXISTS"
                continue
            print(json.dumps({"stage": "pair_start", "candidate": candidate, "sequence": sequence}), flush=True)
            row["native_pair_driver_calls"] = 1
            row["pair_invocation"] = command("run_intervention_pair.py", candidate, "pair")
            ledger["native_pair_driver_calls"] += 1
            if not (case / "PAIR_RESULT.json").is_file():
                row["status"] = "UNKNOWN_PAIR_RESULT_MISSING"
                continue
            pair = read(case / "PAIR_RESULT.json")
            row["pair_result"] = pin(case / "PAIR_RESULT.json")
            row["pair_status"] = pair["status"]
            row["pair_input_integrity"] = pair.get("input_integrity")
            if (row["pair_invocation"]["returncode"] != 0
                    or pair["status"] != "COMPLETE_PAIRED_INTERVENTION_AWAITING_SEMANTIC_AUDITS"
                    or pair.get("input_integrity") != "PASS"):
                row["status"] = "UNKNOWN_PAIR_NOT_ESTABLISHED"
                row["errors"].extend(pair.get("errors", []))
                continue
            row["intervention_observation"] = pair["intervention_observation"]
            row["historical_baseline_parity"] = all(pair["historical_baseline_parity"].values())
            row["variant_model_region_parity"] = all(pair["variant_model_region_byte_parity"].values())
            assert not (case / "audits").exists(), "Audit output must be absent"
            print(json.dumps({"stage": "audits_start", "candidate": candidate}), flush=True)
            row["audit_driver_calls"] = 1
            row["audits_invocation"] = command("run_pair_audits.py", candidate, "audits")
            ledger["audit_driver_calls"] += 1
            if not (case / "audits/RESULT.json").is_file():
                row["status"] = "UNKNOWN_AUDITS_RESULT_MISSING"
                continue
            audits = read(case / "audits/RESULT.json")
            row["audits_result"] = pin(case / "audits/RESULT.json")
            row["audits_status"] = audits["status"]
            row["audit_input_integrity"] = audits.get("input_integrity")
            row["checks"] = audits.get("checks", [])
            if (row["audits_invocation"]["returncode"] != 0
                    or audits["status"] != "COMPLETE_BOTH_ARMS_BOTH_AUDITS_AGREE"
                    or audits.get("input_integrity") != "PASS"):
                row["status"] = "UNKNOWN_AUDITS_INCOMPLETE_OR_DISAGREE"
                row["errors"].extend(audits.get("errors", []))
                continue
            row["baseline"] = audits["baseline"]
            row["variant"] = audits["variant"]
            row["original_graph_counts_unchanged"] = all(
                audits["baseline"][key] == audits["variant"][key] for key in ["original_states", "original_edges"])
            if not all(audits["baseline"][key] is True for key in ["strict", "cooperative"]):
                row["status"] = "FAIL_BASELINE_CONTROL_NOT_POSITIVE"
            elif not all(audits["variant"][key] is True for key in ["strict", "cooperative"]):
                row["status"] = "FAIL_CONTROL_REGRESSION"
            else:
                row["status"] = "PASS_CONTROL_PRESERVED"
        except BaseException as exc:
            row["status"] = "UNKNOWN_CONTROL_EXCEPTION"
            row["errors"].append(type(exc).__name__ + ": " + str(exc))
        finally:
            row["shared_input_pins_unchanged"] = all(pin(r["path"]) == r for r in pins)
            if not row["shared_input_pins_unchanged"]:
                row["status"] = "UNKNOWN_SHARED_INPUT_MUTATION"
                stop_shared_mutation = True
            row["finished_utc"] = now()
            save_new(META / f"{candidate}.RESULT.json", row)
            save_progress(ledger)
            print(json.dumps({"stage": "case_complete", "candidate": candidate, "status": row["status"],
                              "baseline": row.get("baseline"), "variant": row.get("variant")}), flush=True)
    assert len(ledger["rows"]) == 6
    ledger["pass_count"] = sum(r["status"] == "PASS_CONTROL_PRESERVED" for r in ledger["rows"])
    ledger["failure_count"] = sum(r["status"].startswith("FAIL") for r in ledger["rows"])
    ledger["unknown_count"] = sum(r["status"].startswith("UNKNOWN") for r in ledger["rows"])
    ledger["status"] = ("PASS_ALL_SIX_PRESPECIFIED_CONTROLS" if ledger["pass_count"] == 6
                        else "COMPLETE_CONTROLS_WITH_FAILURE_OR_UNKNOWN")
    ledger["shared_input_pins_unchanged"] = all(pin(r["path"]) == r for r in pins)
    ledger["finished_utc"] = now()
    ledger["scope"] = ("Instance-level preservation on the six prospectively declared native-pipeline success controls. "
                       "Does not establish a general nonconflicting synthesis repair.")
    save_new(ROOT / "SUCCESS_CONTROLS_RESULT.json", ledger)
    save_progress(ledger)
    print(json.dumps({k: ledger[k] for k in ["status", "pass_count", "failure_count", "unknown_count",
                                            "native_pair_driver_calls", "audit_driver_calls",
                                            "shared_input_pins_unchanged"]}), flush=True)


if __name__ == "__main__":
    main()
