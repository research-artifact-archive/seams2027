"""Run both unchanged mathematical graph checks on both members of one pair."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location("audit_baseline", ROOT / "run_baseline.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
h = base.helpers


def main():
    assert len(sys.argv) == 2
    candidate = sys.argv[1]
    run = ROOT / "adaptation_episode_01/native_pair_01" / candidate
    pair = h.read(run / "PAIR_RESULT.json")
    assert pair["status"] == "COMPLETE_PAIRED_INTERVENTION_AWAITING_SEMANTIC_AUDITS"
    c = h.read(base.OLD / "frozen_execution_01/CONFIG.json")
    package = h.read(ROOT / "variant_audit/ADAPTER_PACKAGE.json")
    refs = package["files"] + [h.pin(ROOT / "variant_audit/ADAPTER_PACKAGE.json"),
                               h.pin(Path(__file__)), h.pin(run / "PAIR_RESULT.json")]
    refs += [h.pin(p) for p in run.rglob("*") if p.is_file()
             and p.name not in ["stdout.txt", "stderr.txt"]]
    refs = list({x["path"]: x for x in refs}.values())
    h.verify(refs)
    audit_dir = run / "audits"
    audit_dir.mkdir(exist_ok=False)
    deadline = datetime.now(timezone.utc) + timedelta(seconds=600)
    h.save_new(audit_dir / "INPUTS.json", {"inputs": refs, "deadline_utc": deadline.isoformat(),
                                        "attempts_per_checker": 1, "automatic_retries": 0})
    py = c["runtime"]["python"]["path"]
    jobs = [
        ("baseline_production", 60, [py, "-I", "-S", "-B", c["production"]["script"]["path"],
             str(run / "native"), candidate, "--profiles", c["profiles"]["path"],
             "--profile-sha256", c["profiles"]["sha256"], "--output-dir", str(audit_dir / "baseline_production")],
         "certificate.json"),
        ("baseline_independent", 180, [py, "-I", "-S", "-B", c["independent"]["script"]["path"],
             str(run / "baseline_inputs.json"), str(audit_dir / "baseline_independent")], "AUDIT_RESULT.json"),
        ("variant_production", 60, [py, "-I", "-S", "-B", str(ROOT / "variant_audit/production/audit_variant.py"),
             str(run / "variant_inputs.json"), str(audit_dir / "variant_production")], "certificate.json"),
        ("variant_independent", 180, [py, "-I", "-S", "-B", str(ROOT / "variant_audit/independent/audit_worker.py"),
             str(run / "variant_inputs.json"), str(audit_dir / "variant_independent")], "AUDIT_RESULT.json"),
    ]
    result = {"status": "RUNNING", "candidate": candidate, "checks": [], "errors": []}
    stage = h.load_stage()
    try:
        for name, wall, cmd, output_name in jobs:
            process = stage.run_bounded(
                cmd, audit_dir / (name + "_process"), deadline.isoformat(), wall_seconds=wall,
                rss_bytes=1073741824, stream_bytes=8388608, file_bytes=16777216,
                watch_files=[audit_dir / name / output_name], output_tree=audit_dir,
                output_tree_bytes=67108864, aggregate_tree=audit_dir,
                aggregate_tree_bytes=67108864, min_free_bytes=1073741824)
            entry = {"name": name, "process": h.pin(audit_dir / (name + "_process") / "PROCESS_RECEIPT.json"),
                     "process_complete": h.valid_process(process)}
            if (audit_dir / name / output_name).is_file():
                entry["output"] = h.pin(audit_dir / name / output_name)
                data = h.read(audit_dir / name / output_name)
                entry["status"] = data["status"]
                if "production" in name and data["status"] == "COMPLETE_DERIVED_ORIGINAL_CERTIFICATE":
                    entry["strict"] = data["derived_fairness"]["strict_liveness"]["pass"]
                    entry["cooperative"] = data["derived_fairness"]["nonconflicting"]["pass"]
                    entry["original_states"] = data["original_view_mapping"]["states"]
                    entry["original_edges"] = data["original_view_mapping"]["edges"]
                if "independent" in name and data["status"] == "COMPLETE_INDEPENDENT_RAW_GRAPH_AUDIT":
                    entry["strict"] = data["independent_strict"]
                    entry["cooperative"] = data["independent_cooperative"]
                    entry["original_states"] = data["original_view"]["states"]
                    entry["original_edges"] = data["original_view"]["edges"]
            result["checks"].append(entry)
            h.save_atomic(audit_dir / "PROGRESS.json", result)
        for arm in ["baseline", "variant"]:
            checks = [x for x in result["checks"] if x["name"].startswith(arm)]
            assert len(checks) == 2 and all(x["process_complete"] for x in checks), arm + " process incomplete"
            keys = ["strict", "cooperative", "original_states", "original_edges"]
            assert all(k in x for x in checks for k in keys), arm + " audit incomplete"
            assert all(checks[0][k] == checks[1][k] for k in keys), arm + " checker disagreement"
            result[arm] = {k: checks[0][k] for k in keys}
        result["status"] = "COMPLETE_BOTH_ARMS_BOTH_AUDITS_AGREE"
    except BaseException as exc:
        result["status"] = "UNKNOWN_OR_DISAGREEING_PAIR_AUDITS"
        result["errors"].append(type(exc).__name__ + ": " + str(exc))
    finally:
        try:
            h.verify(refs)
            result["input_integrity"] = "PASS"
        except BaseException as exc:
            result["input_integrity"] = "FAIL"
            result["status"] = "UNKNOWN_INPUT_MUTATION"
            result["errors"].append(str(exc))
        result["finished_utc"] = datetime.now(timezone.utc).isoformat()
        h.save_new(audit_dir / "RESULT.json", result)
        print(json.dumps(result))


if __name__ == "__main__":
    main()
