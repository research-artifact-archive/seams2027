"""Create an isolated paired harness from the unchanged released-route wrapper."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent.parent
SOURCE = WORK / "experiment/seams_submission_push_20261016/released_kind_pipeline_feasibility/src/ReleasedKindJobProducer.java"
text = SOURCE.read_text()
text = text.replace("public final class ReleasedKindJobProducer {", "public final class PairedLiftDiagnostic {", 1)
marker = 'out.put("controller_export",writeJson("controller.json",after));out.put("status","JOB_CONTROLLER_PRINTED");'
assert text.count(marker) == 1
text = text.replace(marker, marker + "\n          pairedDiagnostics(mem,gm,controller);")
methods = r'''
  static void collectMemory(String label,Object value,Map<String,BDD> saved) {
    if(value==null)return;
    if(value instanceof BDD){saved.put(label,((BDD)value).id());return;}
    if(value.getClass().isArray()) {
      for(int i=0;i<java.lang.reflect.Array.getLength(value);i++)
        collectMemory(label+"_"+i,java.lang.reflect.Array.get(value,i),saved);
    } else throw new IllegalArgumentException("Unexpected memory field "+label);
  }
  static Map<String,BDD> captureMemoryAndModel(GR1Memory mem,GameModel gm)throws Exception {
    Map<String,BDD> saved=new LinkedHashMap<>();
    for(String field:Arrays.asList("x_mem","y_mem","z_mem")) {
      java.lang.reflect.Field f=GR1Memory.class.getDeclaredField(field);
      f.setAccessible(true);collectMemory(field,f.get(mem),saved);
    }
    saved.put("win",mem.getWin().id());
    for(boolean e:Arrays.asList(true,false)) {
      PlayerModule p=e?gm.getEnv():gm.getSys();String side=e?"ENV":"SYS";
      saved.put(side+"_initial",p.initial().id());saved.put(side+"_trans",p.trans().id());
      for(int i=0;i<p.justiceNum();i++)saved.put(side+"_justice_"+i,p.justiceAt(i).id());
    }
    return saved;
  }
  static List<Integer> variableOrder(BDD b) {
    List<Integer> order=new ArrayList<>();
    for(int i=0;i<b.getFactory().varNum();i++)order.add(b.getFactory().level2Var(i));
    return order;
  }
  static void pairedDiagnostics(GR1Memory mem,GameModel gm,EnumStrategyI nativeController)throws Exception {
    checkpoint("PAIRED_OBSERVER_SAME_MEMORY_AND_MODEL");
    Map<String,BDD> before=captureMemoryAndModel(mem,gm);
    List<Integer> order=variableOrder(mem.getWin());
    GR1ObservedControllerConstructionSkip observer=new GR1ObservedControllerConstructionSkip(mem,gm);
    EnumStrategyI observedController=observer.calculateConcreteController();
    Map<String,Object> original=controllerSnapshot(nativeController,gm);
    Map<String,Object> observed=controllerSnapshot(observedController,gm);
    Object originalID=original.remove("controller_identity");
    Object observedID=observed.remove("controller_identity");
    boolean graphParity=json(original).equals(json(observed));
    original.put("controller_identity",originalID);observed.put("controller_identity",observedID);
    out.put("observer_controller_export",writeJson("observer_controller.json",observed));
    Map<String,BDD> after=captureMemoryAndModel(mem,gm);
    Map<String,Object> checks=new LinkedHashMap<>();
    boolean memoryParity=before.keySet().equals(after.keySet());
    for(String name:before.keySet()) {
      boolean same=after.containsKey(name)&&before.get(name).equals(after.get(name));
      checks.put(name,same);memoryParity &= same;
    }
    boolean orderParity=order.equals(variableOrder(mem.getWin()));
    Path memoryDir=receipt.getParent().resolve("paired_memory");Files.createDirectory(memoryDir);
    Map<String,Object> memoryFiles=new LinkedHashMap<>();
    for(Map.Entry<String,BDD> entry:before.entrySet()) {
      Path dest=memoryDir.resolve(entry.getKey()+".bdd");
      Env.saveBDD(dest.toString(),entry.getValue(),false);
      memoryFiles.put(entry.getKey(),m("file",dest.getFileName().toString(),"bytes",Files.size(dest),
        "sha256",sha(Files.readAllBytes(dest)),"nodes",entry.getValue().nodeCount()));
    }
    Map<String,Object> diagnostic=m("mode","observer_only_paired_after_unmodified_native_extraction",
      "same_memory_object",true,"same_model_object",true,
      "graph_parity_excluding_only_controller_object_identity",graphParity,
      "memory_and_model_all_BDDs_equal",memoryParity,"BDD_equality_checks",checks,
      "variable_order_unchanged",orderParity,"bdd_variable_order",order,
      "observer_class",identity(observer.getClass()),"observer_helper_class",identity(Class.forName("tau.smlab.syntech.games.gr1.GR1ExtractionObserver")),
      "memory_snapshots",memoryFiles,"native_graph_states",nativeController.numOfStates(),
      "native_graph_edges",nativeController.numOfTransitions(),"observed_graph_states",observedController.numOfStates(),
      "observed_graph_edges",observedController.numOfTransitions(),
      "trace_path",System.getProperty("lift.trace.path"));
    out.put("paired_observer",writeJson("paired_observer.json",diagnostic));
    for(BDD b:before.values())b.free();for(BDD b:after.values())b.free();
    require(graphParity&&memoryParity&&orderParity,"Paired observer parity failed");
  }
'''
assert text.endswith("}\n")
text = text[:-2] + methods + "}\n"
dest = ROOT / "src/PairedLiftDiagnostic.java"
dest.parent.mkdir(exist_ok=True)
assert not dest.exists()
dest.write_text(text)
receipt = {
    "original_source": str(SOURCE), "original_source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    "derived_source": str(dest), "derived_source_sha256": hashlib.sha256(dest.read_bytes()).hexdigest(),
    "changes": ["rename wrapper class", "call paired diagnostics after unchanged native graph export",
                "append memory/model capture, observer extraction, graph/BDD equality and post-extraction export"],
    "unchanged_native_solver_and_extractor_classes": True,
}
(ROOT / "PAIRED_HARNESS_SOURCE.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
print(dest)
