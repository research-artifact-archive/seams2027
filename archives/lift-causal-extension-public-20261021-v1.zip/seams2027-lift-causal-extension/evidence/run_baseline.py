"""Reproduce one unchanged released Lift T run with both existing graph audits."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent.parent
OLD = WORK / "experiment/seams_research_reframing_20261018"
CONFIG = OLD / "lift_resource_followup_01/CONFIG.json"
DISPATCH = OLD / "frozen_execution_01/code/dispatch/dispatch.py"
assert hashlib.sha256(DISPATCH.read_bytes()).hexdigest() == "380c45269a1815141fd326651b22373d4d3c57c9277ae5e882991f95bc3eccc9"
spec = importlib.util.spec_from_file_location("baseline_helpers", DISPATCH)
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
pin, read, verify, save = helpers.pin, helpers.read, helpers.verify, helpers.save_new


def main():
    assert len(sys.argv) == 2 and sys.argv[1] == "execute"
    c = read(CONFIG)["execution"]
    row = next(x for x in c["candidates"] if x["id"] == "lift__trivial_1")
    historical = OLD / "lift_resource_followup_01/batch_01/lift__trivial_1"
    frozen = read(OLD / "frozen_execution_01/FROZEN.json")
    by_path = {x["path"]: x for x in frozen["files"]}
    needed = [pin(CONFIG), pin(DISPATCH), pin(Path(__file__))]
    needed += [row["source"], c["profiles"], c["runtime"]["java"], c["runtime"]["python"],
               c["runtime"]["origins"]] + c["runtime"]["class_files"]
    for path in c["runtime"]["classpath_entries"]:
        p = Path(path)
        if p.is_file():
            assert path in by_path, path
            needed.append(by_path[path])
    for x in frozen["files"]:
        if "/frozen_execution_01/code/" in x["path"] and Path(x["path"]).suffix == ".py":
            needed.append(x)
    for name in ["result.json", "model.json", "controller.json", "controller.txt"]:
        needed.append(pin(historical / "native" / name))
    needed = list({x["path"]: x for x in needed}.values())
    verify(needed)
    run = ROOT / "runs/baseline_01"
    run.mkdir(parents=True, exist_ok=False)
    deadline = datetime.now(timezone.utc) + timedelta(seconds=300)
    save(run / "INPUTS.json", {
        "purpose": "Unmodified Lift T reproduction; original contract and initialization unchanged",
        "authorization": pin(ROOT / "AUTHORIZATION_AND_PRIORITY_CHANGE.json"),
        "inputs": needed,
        "limits": c["limits"],
        "deadline_utc": deadline.isoformat(),
        "automatic_retries": 0,
        "full_reset_uses": 0,
    })
    stage = helpers.load_stage()
    outcome = {"status": "STARTED", "native_calls": 0, "production_calls": 0,
               "independent_calls": 0, "errors": []}
    native = run / "native"

    def invoke(command, process_dir, wall, stream, watched):
        return stage.run_bounded(
            command, process_dir, deadline.isoformat(), wall_seconds=wall,
            rss_bytes=c["limits"]["rss_bytes"], stream_bytes=stream,
            file_bytes=c["limits"]["file_bytes"], watch_files=watched,
            output_tree=run, output_tree_bytes=c["limits"]["case_output_bytes"],
            aggregate_tree=run, aggregate_tree_bytes=c["limits"]["case_output_bytes"],
            min_free_bytes=c["limits"]["min_free_bytes"])

    try:
        cmd = helpers.native_command(c, row, native)
        old_cmd = read(historical / "native/PROCESS_REQUEST.json")["argv"]
        assert all(a == b for i, (a, b) in enumerate(zip(cmd, old_cmd)) if i != 8)
        assert len(cmd) == len(old_cmd) == 10
        outcome["native_calls"] = 1
        process = invoke(cmd, native, c["limits"]["native_wall_seconds"],
                         c["limits"]["native_stream_bytes"],
                         [native / x for x in ["result.json", "model.json", "controller.json", "controller.txt"]])
        outcome["native_process"] = pin(native / "PROCESS_RECEIPT.json")
        assert helpers.valid_process(process), "native process incomplete"
        nr = read(native / "result.json")
        helpers.validate_native(nr, c, row)
        outcome["native_status"] = nr["status"]
        before = [pin(x) for x in sorted(native.iterdir()) if x.is_file()]
        outcome["native_output_pins"] = before
        parity = {}
        for old in sorted((historical / "native").iterdir()):
            if old.suffix == ".bdd" or old.name in ["model.json", "controller.json", "controller.txt"]:
                new = native / old.name
                parity[old.name] = {
                    "same_bytes": new.is_file() and pin(old)["sha256"] == pin(new)["sha256"],
                    "historical": pin(old), "new": pin(new) if new.is_file() else None}
        outcome["historical_semantic_artifact_byte_parity"] = parity
        production = run / "production"
        cmd = [c["runtime"]["python"]["path"], "-I", "-S", "-B",
               c["production"]["script"]["path"], str(native), row["id"],
               "--profiles", c["profiles"]["path"], "--profile-sha256", c["profiles"]["sha256"],
               "--output-dir", str(production)]
        outcome["production_calls"] = 1
        process = invoke(cmd, run / "production_process", c["production"]["wall_seconds"],
                         c["production"]["stream_bytes"],
                         [production / x for x in ["certificate.json", "derived_original_graph.json",
                                                  "derived_original_fairness.json"]])
        assert helpers.valid_process(process), "production audit incomplete"
        outcome["production_certificate"] = pin(production / "certificate.json")
        manifest = run / "independent_inputs.json"
        save(manifest, helpers.audit_manifest(c, row, native))
        independent = run / "independent"
        cmd = [c["runtime"]["python"]["path"], "-I", "-S", "-B",
               c["independent"]["script"]["path"], str(manifest), str(independent)]
        outcome["independent_calls"] = 1
        process = invoke(cmd, run / "independent_process", c["independent"]["wall_seconds"],
                         c["independent"]["stream_bytes"],
                         [independent / x for x in ["AUDIT_RESULT.json", "INDEPENDENT_VIEW.json"]])
        assert helpers.valid_process(process), "independent audit incomplete"
        outcome["independent_audit"] = pin(independent / "AUDIT_RESULT.json")
        verify(before)
        outcome["status"] = "COMPLETE_REPRODUCTION_AND_BOTH_AUDITS"
    except BaseException as exc:
        outcome["status"] = "UNKNOWN_INCOMPLETE_REPRODUCTION"
        outcome["errors"].append(type(exc).__name__ + ": " + str(exc))
    finally:
        try:
            verify(needed)
            outcome["input_integrity"] = "PASS"
        except BaseException as exc:
            outcome["input_integrity"] = "FAIL"
            outcome["status"] = "UNKNOWN_INPUT_MUTATION"
            outcome["errors"].append(str(exc))
        outcome["finished_utc"] = datetime.now(timezone.utc).isoformat()
        save(run / "RESULT.json", outcome)
        print(json.dumps({k: v for k, v in outcome.items()
                          if k not in ["native_output_pins", "historical_semantic_artifact_byte_parity"]}))


if __name__ == "__main__":
    main()
