"""Bounded native/experimental extraction pair, with immutable source evidence."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location("intervention_baseline", ROOT / "run_baseline.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
h = base.helpers
VARIANT = "final_candidate_original_env_continuation_preference_v1"


def make_manifest(c, row, folder, process):
    return {
        "schema": "remaining-nine-independent-audit-inputs-v1",
        "candidate_id": row["id"],
        "inputs": {"source": row["source"], "profile": c["profiles"],
                   "native_result": h.pin(folder / "result.json"),
                   "model": h.pin(folder / "model.json"), "native_process": process,
                   "controller": h.pin(folder / "controller.json"),
                   "printer": h.pin(folder / "controller.txt")},
        "bdd_files": {p.name: h.pin(p) for p in sorted(folder.glob("*.bdd"))}}


def main():
    assert len(sys.argv) == 2
    candidate = sys.argv[1]
    controls = h.read(ROOT / "PRESPECIFIED_SUCCESS_CONTROLS.json")
    assert candidate in ["lift__trivial_1"] + [x["candidate"] for x in controls["controls"]]
    config_path = base.OLD / "frozen_execution_01/CONFIG.json"
    c = h.read(config_path)
    row = next(x for x in c["candidates"] if x["id"] == candidate)
    historical = (base.OLD / "lift_resource_followup_01/batch_01" if candidate == "lift__trivial_1"
                  else base.OLD / "remaining_nine_batch_01") / candidate / "native"
    compiled = h.read(ROOT / "VARIANT_COMPILE_RECEIPT.json")
    assert compiled["returncode"] == 0
    inputs = h.read(ROOT / "runs/baseline_01/INPUTS.json")["inputs"]
    inputs += compiled["sources"] + compiled["classes"]
    inputs += [row["source"], h.pin(config_path), h.pin(Path(__file__)),
               h.pin(ROOT / "VARIANT_COMPILE_RECEIPT.json"),
               h.pin(ROOT / "INTERVENTION_PLAN.json"), h.pin(ROOT / "PRESPECIFIED_SUCCESS_CONTROLS.json")]
    inputs += [h.pin(x) for x in sorted(historical.iterdir())
               if x.suffix == ".bdd" or x.name in ["model.json", "controller.json", "controller.txt"]]
    h.verify(inputs)
    run = ROOT / "adaptation_episode_03/native_pair_01" / candidate
    run.mkdir(parents=True, exist_ok=False)
    native, changed = run / "native", run / "variant"
    deadline = datetime.now(timezone.utc) + timedelta(seconds=60)
    cmd = h.native_command(c, row, native)
    cmd[4] = str(ROOT / "classes_variant") + ":" + cmd[4]
    cmd[5] = "PairedContinuationDiagnostic"
    h.save_new(run / "INPUTS.json", {
        "candidate": candidate, "variant_name": VARIANT, "inputs": inputs,
        "command": cmd, "deadline_utc": deadline.isoformat(), "wall_seconds": 30,
        "rss_bytes": 1073741824, "stream_bytes": 536870912, "output_tree_bytes": 805306368,
        "order": ["unmodified native extraction", "conditional continuation preference on same memory/model"],
        "automatic_retries": 0})
    result = {"status": "RUNNING", "candidate": candidate, "variant_name": VARIANT, "errors": []}
    try:
        p = h.load_stage().run_bounded(
            cmd, native, deadline.isoformat(), wall_seconds=30, rss_bytes=1073741824,
            stream_bytes=536870912, file_bytes=16777216,
            watch_files=[folder / name for folder in [native, changed]
                         for name in ["result.json", "controller.json", "controller.txt"]],
            output_tree=run, output_tree_bytes=805306368,
            aggregate_tree=run, aggregate_tree_bytes=805306368, min_free_bytes=1073741824)
        process = h.pin(native / "PROCESS_RECEIPT.json")
        result["process"] = process
        assert h.valid_process(p), "Paired process incomplete"
        nr = h.read(native / "result.json")
        h.validate_native(nr, c, row)
        vr = h.read(changed / "result.json")
        assert vr["status"] == "JOB_CONTROLLER_PRINTED" and vr["teardown"] == "COMPLETED"
        assert vr["nonrelease_extractor"] is True and vr["extractor_variant"] == VARIANT
        parity = {}
        for old in sorted(historical.iterdir()):
            if old.suffix == ".bdd" or old.name in ["model.json", "controller.txt"]:
                parity[old.name] = h.pin(old)["sha256"] == h.pin(native / old.name)["sha256"]
        old_graph, new_graph = h.read(historical / "controller.json"), h.read(native / "controller.json")
        for graph in [old_graph, new_graph]:
            for key in ["controller_identity", "native_memory_identity"]:
                graph.pop(key)
        parity["complete_graph_excluding_object_identities"] = old_graph == new_graph
        result["historical_baseline_parity"] = parity
        assert all(parity.values()), "Unmodified arm differs from historical baseline"
        diag = h.read(changed / "paired_intervention.json")
        assert diag["memory_and_model_all_BDDs_equal"] and diag["variable_order_unchanged"]
        assert diag["same_memory_object"] and diag["same_model_object"]
        assert all(diag["BDD_equality_checks"].values())
        result["intervention_observation"] = {
            k: diag[k] for k in ["examined_candidates", "refined_candidates", "no_preferred_candidate_fallbacks",
                                "native_graph_states", "native_graph_edges", "variant_graph_states", "variant_graph_edges"]}
        model_parity = {}
        for path in sorted(native.glob("*.bdd")):
            model_parity[path.name] = h.pin(path)["sha256"] == h.pin(changed / path.name)["sha256"]
        model_parity["model.json"] = h.pin(native / "model.json")["sha256"] == h.pin(changed / "model.json")["sha256"]
        assert all(model_parity.values()), "Variant model/region bytes changed"
        result["variant_model_region_byte_parity"] = model_parity
        baseline_manifest = run / "baseline_inputs.json"
        h.save_new(baseline_manifest, make_manifest(c, row, native, process))
        pair = {
            "schema": "same-memory-extraction-pair-evidence-v1",
            "candidate_id": candidate, "variant_name": VARIANT,
            "baseline_result": h.pin(native / "result.json"),
            "variant_result": h.pin(changed / "result.json"),
            "producer_evidence": h.pin(changed / "paired_intervention.json"),
            "same_memory_object": diag["same_memory_object"], "same_model_object": diag["same_model_object"],
            "memory_and_model_all_BDDs_equal": diag["memory_and_model_all_BDDs_equal"],
            "variable_order_unchanged": diag["variable_order_unchanged"],
            "BDD_equality_checks": diag["BDD_equality_checks"],
            "expected_BDD_keys": list(diag["BDD_equality_checks"]),
            "BDD_roster_source": "Producer captureMemoryAndModel enumerates all nonnull X/Y/Z entries, win, both initial/trans relations and all ordered justices.",
            "model_region_byte_parity": model_parity,
            "memory_equality_evidence_kind": "Producer checked BDD semantic equality; separate baseline memory was independently recomputed."}
        pair_path = run / "PAIRED_EVIDENCE.json"
        h.save_new(pair_path, pair)
        extractor_class = "tau.smlab.syntech.games.gr1.GR1ContinuationPreferenceConstruction"
        class_path = ROOT / "classes_variant" / (extractor_class.replace(".", "/") + ".class")
        binding = {
            "schema": "experimental-extractor-binding-v1", "candidate_id": candidate,
            "variant_name": VARIANT, "nonrelease_extractor": True,
            "upstream_transformation_unchanged": True, "upstream_raw_core_unchanged": True,
            "baseline_manifest": h.pin(baseline_manifest), "variant_result": h.pin(changed / "result.json"),
            "source_files": compiled["sources"], "class_files": {extractor_class: h.pin(class_path)},
            "extractor_class": extractor_class, "paired_evidence": h.pin(pair_path)}
        binding_path = run / "VARIANT_BINDING.json"
        h.save_new(binding_path, binding)
        manifest = make_manifest(c, row, changed, process)
        # This predicate is diagnostic, not part of the source model/justice inventory.
        manifest["bdd_files"].pop("selection_preference.bdd")
        manifest["schema"] = "experimental-extractor-independent-audit-inputs-v1"
        manifest["variant_binding"] = h.pin(binding_path)
        h.save_new(run / "variant_inputs.json", manifest)
        result["status"] = "COMPLETE_PAIRED_INTERVENTION_AWAITING_SEMANTIC_AUDITS"
    except BaseException as exc:
        result["status"] = "UNKNOWN_OR_INVALID_INTERVENTION_PAIR"
        result["errors"].append(type(exc).__name__ + ": " + str(exc))
    finally:
        try:
            h.verify(inputs)
            result["input_integrity"] = "PASS"
        except BaseException as exc:
            result["input_integrity"] = "FAIL"
            result["status"] = "UNKNOWN_INPUT_MUTATION"
            result["errors"].append(str(exc))
        result["finished_utc"] = datetime.now(timezone.utc).isoformat()
        h.save_new(run / "PAIR_RESULT.json", result)
        print(json.dumps(result))


if __name__ == "__main__":
    main()
