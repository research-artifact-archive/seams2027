"""Finite-set recomputation of the released raw 4FP recurrence.

Only SavedDag parsing/evaluation is reused. No Java, native solver, symbolic
fixed-point operations, source-policy controller or native final region is
used to compute the finite-set result.
"""
from pathlib import Path
from datetime import datetime, timezone
from itertools import product
import hashlib
import importlib.util
import json
import sys
import time
import traceback

sys.dont_write_bytecode = True
STARTED = time.monotonic()
LIMIT_SECONDS = 110


def check_time():
    if time.monotonic() - STARTED > LIMIT_SECONDS:
        raise TimeoutError("Independent core internal 110-second limit")


def need(value, message):
    if not value:
        raise ValueError(message)


def pin(path):
    path = Path(path).resolve(strict=True)
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def verify(ref):
    need(pin(ref["path"]) == ref, "Pinned input changed: " + ref["path"])


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()
    need(len(raw) < 16 * 1024 * 1024, "Individual output exceeds 16 MiB")
    with Path(path).open("xb") as stream:
        stream.write(raw)


class SetLog:
    def __init__(self, states):
        self.states = states
        self.ids = {}
        self.sets = []
        self.events = []

    def sid(self, mask):
        need(0 <= mask < (1 << self.states), "Set outside typed state carrier")
        if mask not in self.ids:
            need(len(self.ids) < 8192, "Set catalog cap")
            self.ids[mask] = len(self.sets)
            self.sets.append({"id": len(self.sets), "cardinality": mask.bit_count(), "mask_hex": hex(mask)})
        return self.ids[mask]

    def event(self, kind, position, **sets):
        need(len(self.events) < 40000, "Iteration trace event cap")
        record = {"kind": kind, **position}
        record.update({name: self.sid(mask) for name, mask in sets.items()})
        self.events.append(record)


class ProductPredecessor:
    """Explicit finite ENV-first quantifiers, grouped by identical choice rows."""
    def __init__(self, env_count, sys_count, rows):
        self.env_count = env_count
        self.sys_count = sys_count
        self.rows = rows
        self.states = env_count * sys_count
        need(len(rows) == self.states, "One choice row per current state")
        self.groups = {}
        for index, row in enumerate(rows):
            self.groups[row] = self.groups.get(row, 0) | (1 << index)
        self.cache = {}
        self.direct_validation_targets = 0
        self.sys_target_mask = (1 << sys_count) - 1

    def both(self, target):
        check_time()
        if target in self.cache:
            return self.cache[target]
        # At a fixed current state, native support guarantees that the safe
        # SYS/AUX choices do not depend on e'. No legal ENV choices are dropped.
        slices = [(target >> (e * self.sys_count)) & self.sys_target_mask
                  for e in range(self.env_count)]
        hit_env_by_sys = {}
        cpre = epre = 0
        for (legal_env, safe_sys), current_states in self.groups.items():
            if safe_sys not in hit_env_by_sys:
                hit_env_by_sys[safe_sys] = sum(
                    1 << e for e, target_sys in enumerate(slices) if safe_sys & target_sys)
            hits = legal_env & hit_env_by_sys[safe_sys]
            # Universal ENV implication is vacuously true at an ENV dead end.
            if hits == legal_env:
                cpre |= current_states
            if hits:
                epre |= current_states
        if self.direct_validation_targets < 32:
            # Independent, ungrouped enumeration of legal environment choices.
            direct_c = direct_e = 0
            for s, (legal_env, safe_sys) in enumerate(self.rows):
                all_responses = True
                some_response = False
                for e in range(self.env_count):
                    if legal_env & (1 << e):
                        response = bool(safe_sys & slices[e])
                        all_responses = all_responses and response
                        some_response = some_response or response
                if all_responses:
                    direct_c |= 1 << s
                if some_response:
                    direct_e |= 1 << s
            need((cpre, epre) == (direct_c, direct_e), "Grouped/direct predecessor disagreement")
            self.direct_validation_targets += 1
        need(len(self.cache) < 8192, "Predecessor target-cache cap")
        self.cache[target] = cpre, epre
        return cpre, epre


def raw_four_fixed_points(universe, assumptions, guarantees, predecessor, log=None):
    """Successive j schedule of GR1SeparatedGame, using only integer sets.

    start = G_j ∩ CPre(z) ∪ CPre(y_old)
    w' = start ∪ (¬A_i ∩ EPre(w) ∩ CPre(w ∪ (x ∩ ¬A_i)))
    z: greatest; each j's y: least; each i's x from z: greatest; w: least.
    """
    z = universe
    outer = 0
    totals = {"outer_passes": 0, "Y_updates": 0, "X_updates": 0, "W_updates": 0}
    final_memory = None
    while True:
        check_time()
        need(outer < 4096, "Outer fixed-point iteration cap")
        old_z = z
        current_memory = {"X": [], "Y": [], "Z": []}
        for j, guarantee in enumerate(guarantees):
            y = 0
            cy = 0
            j_x = []
            j_y = []
            while True:
                check_time()
                need(cy < 4096, "Y fixed-point iteration cap")
                old_y = y
                start = (guarantee & predecessor.both(z)[0]) | predecessor.both(old_y)[0]
                y = 0
                row_x = []
                for i, assumption in enumerate(assumptions):
                    neg_a = universe ^ assumption
                    x = z
                    xi = 0
                    while True:
                        check_time()
                        need(xi < 4096, "X fixed-point iteration cap")
                        old_x = x
                        w = 0
                        wi = 0
                        while True:
                            check_time()
                            need(wi < 4096, "W fixed-point iteration cap")
                            old_w = w
                            epre_w = predecessor.both(old_w)[1]
                            cpre_union = predecessor.both(old_w | (old_x & neg_a))[0]
                            w = start | (neg_a & epre_w & cpre_union)
                            need(old_w & ~w == 0, "W least-fixed-point monotonicity failed")
                            if log:
                                log.event("W_update", {"outer": outer, "j": j, "cy": cy, "i": i, "xi": xi, "wi": wi},
                                          Z=z, Y_previous=old_y, X=old_x, start=start,
                                          W_previous=old_w, EPre_W=epre_w, CPre_union=cpre_union, W=w)
                            totals["W_updates"] += 1
                            wi += 1
                            if w == old_w:
                                break
                        x = w
                        need(x & ~old_x == 0, "X greatest-fixed-point monotonicity failed")
                        if log:
                            log.event("X_update", {"outer": outer, "j": j, "cy": cy, "i": i, "xi": xi},
                                      previous=old_x, value=x)
                        totals["X_updates"] += 1
                        xi += 1
                        if x == old_x:
                            break
                    row_x.append(x)
                    y |= x
                need(old_y & ~y == 0, "Y least-fixed-point monotonicity failed")
                if log:
                    log.event("Y_update", {"outer": outer, "j": j, "cy": cy}, previous=old_y, value=y)
                j_x.append(row_x)
                j_y.append(y)
                totals["Y_updates"] += 1
                cy += 1
                if y == old_y:
                    break
            previous_z = z
            z = y
            need(z & ~previous_z == 0, "Sequential Z greatest-fixed-point monotonicity failed")
            if log:
                log.event("Z_component_update", {"outer": outer, "j": j}, previous=previous_z, value=z)
            current_memory["X"].append(j_x)
            current_memory["Y"].append(j_y)
            current_memory["Z"].append(z)
        outer += 1
        totals["outer_passes"] = outer
        final_memory = current_memory
        if z == old_z:
            break
    return z, final_memory, totals


def synthetic_controls():
    # Four states = two possible next inputs by two possible next responses.
    p = ProductPredecessor(2, 2, [(0, 0), (3, 1), (1, 2), (2, 0)])
    for target in range(16):
        cpre, epre = p.both(target)
        need(cpre & 1 and not (epre & 1), "ENV-dead-end vacuity control")
        need(not (cpre & 8) and not (epre & 8), "Legal input with no SYS response control")
    total = ProductPredecessor(1, 1, [(1, 1)])
    values = []
    for assumptions, guarantees, expected in [([1], [1], 1), ([1], [0], 0), ([0], [0], 0)]:
        got, _, _ = raw_four_fixed_points(1, assumptions, guarantees, total)
        need(got == expected, "One-state closed-form recurrence control")
        values.append({"assumption": assumptions[0], "guarantee": guarantees[0], "region": got})
    return {"status": "PASS", "predecessor_targets": 16,
            "ENV_dead_end_CPre_vacuous_EPre_false": True,
            "legal_ENV_without_response_rejected": True,
            "closed_form_one_state_cases": values}


def main():
    protocol_path, output_dir = Path(sys.argv[1]), Path(sys.argv[2])
    output_dir.mkdir(exist_ok=False)
    protocol = read(protocol_path)
    inputs = protocol["input_pins"]
    result = {"schema": "lift-t-independent-explicit-raw4fp-v1", "status": "UNKNOWN_STARTED",
              "started_utc": datetime.now(timezone.utc).isoformat(),
              "native_solver_runs": 0, "Java_processes": 0, "BDD_fixed_point_operations": 0,
              "protocol_pin": pin(protocol_path), "input_pins": inputs}
    try:
        for ref in inputs:
            verify(ref)
        evaluator_ref = protocol["saved_DAG_evaluator"]
        verify(evaluator_ref)
        spec = importlib.util.spec_from_file_location("core_recompute_saved_dag", evaluator_ref["path"])
        evaluator = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(evaluator)
        result["synthetic_controls"] = synthetic_controls()
        native = Path(protocol["native_directory"])
        native_result = read(native / "result.json")
        model = read(native / "model.json")
        need(native_result["status"] == "JOB_CONTROLLER_PRINTED", "Completed native baseline required")
        need(native_result["configuration"]["TransFuncType"] == "SINGLE_FUNC", "SINGLE_FUNC required")
        need(pin(native / "model.json")["sha256"] == native_result["model_export"]["sha256"], "Model/result binding")
        fields = model["fields"]
        env_fields = [f for f in fields if f["owner"] == "ENV"]
        sys_fields = [f for f in fields if f["owner"] == "SYS"]
        need(len(fields) == 11 and len(env_fields) == 5 and len(sys_fields) == 6, "Lift T typed field cardinalities")
        need(all(f["domain_size"] == 2 and len(f["values"]) == 2 for f in fields), "Binary typed Lift T fields")
        need(fields == env_fields + sys_fields, "Explicit ENV-then-SYS state enumeration")
        env_values = list(product(*(f["values"] for f in env_fields)))
        sys_values = list(product(*(f["values"] for f in sys_fields)))
        states = [dict(zip([f["name"] for f in fields], e + s)) for e in env_values for s in sys_values]
        count = len(states)
        need(count == 2048 and len(env_values) == 32 and len(sys_values) == 64, "Exact full carrier size")
        universe = (1 << count) - 1

        def encoding(fs, values, timing):
            bits = {}
            for field, value in zip(fs, values):
                for bit, truth in field["encoding"][value][timing].items():
                    need(int(bit) not in bits and type(truth) is bool, "Disjoint well-typed field encoding")
                    bits[int(bit)] = truth
            return bits

        current_bits = [encoding(fields, tuple(state[f["name"]] for f in fields), "current") for state in states]
        env_next_bits = [encoding(env_fields, values, "next") for values in env_values]
        sys_next_bits = [encoding(sys_fields, values, "next") for values in sys_values]
        current_support = set(model["all_current_bits"])
        env_next_support = set().union(*(set(x) for x in env_next_bits))
        sys_next_support = set().union(*(set(x) for x in sys_next_bits))
        need(current_support | env_next_support | sys_next_support == set(range(22)), "Complete 22 native bits")
        dags = {}

        def dag(ref, allowed):
            filename = ref["file"]
            path = native / filename
            actual = pin(path)
            need(actual["bytes"] == ref["bytes"] and actual["sha256"] == ref["sha256"], "BDD reference pin mismatch")
            if filename not in dags:
                dags[filename] = evaluator.SavedDag(path.read_bytes(), model["bdd_variable_count"], model["bdd_variable_order"])
            obj = dags[filename]
            need(obj.support <= allowed, "Unsupported dependency in " + filename)
            if "support" in ref:
                need(obj.support == set(ref["support"]), "Saved support metadata mismatch")
            return obj

        roots = model["original_bdds"]
        rho_e = dag(roots["rhoE"], current_support | env_next_support)
        rho_s = dag(roots["rhoS"], current_support | sys_next_support)
        domain = dag(roots["domain"], current_support)
        domain_e = dag(roots["domain_ENV_next"], env_next_support)
        domain_s = dag(roots["domain_SYS_next"], sys_next_support)
        need(all(domain.value(bits) for bits in current_bits), "Full binary typed current domain")
        need(all(domain_e.value(bits) for bits in env_next_bits), "Full typed ENV-next domain")
        need(all(domain_s.value(bits) for bits in sys_next_bits), "Full typed SYS-next domain")
        rows = []
        for s, current in enumerate(current_bits):
            if s % 64 == 0:
                check_time()
            legal_e = sum(1 << e for e, bits in enumerate(env_next_bits) if rho_e.value(current | bits))
            safe_s = sum(1 << q for q, bits in enumerate(sys_next_bits) if rho_s.value(current | bits))
            rows.append((legal_e, safe_s))
        predecessor = ProductPredecessor(32, 64, rows)
        justice_masks = {}
        for owner in ["ENV", "SYS"]:
            justice_masks[owner] = []
            for ref in native_result["solver_justices"][owner]:
                objective = dag(ref, current_support)
                justice_masks[owner].append(sum(1 << s for s, bits in enumerate(current_bits) if objective.value(bits)))
        need(len(justice_masks["ENV"]) == 1 and len(justice_masks["SYS"]) == 3, "Exact solver justice multiplicities")
        log = SetLog(count)
        computed, memory, totals = raw_four_fixed_points(
            universe, justice_masks["ENV"], justice_masks["SYS"], predecessor, log)

        # Read the native expected winning region only after independent solve.
        expected_dag = dag(native_result["final_region"], current_support)
        native_region = sum(1 << s for s, bits in enumerate(current_bits) if expected_dag.value(bits))
        symmetric_difference = computed ^ native_region
        theta_e = dag(roots["thetaE"], current_support)
        theta_s = dag(roots["thetaS"], current_support)
        initial_rows = []
        for e, values in enumerate(env_values):
            matching = [s for s in range(e * 64, (e + 1) * 64) if theta_e.value(current_bits[s])]
            if not matching:
                continue
            need(len(matching) == 64, "ENV initialization unexpectedly depends on SYS")
            choices = [s for s in matching if theta_s.value(current_bits[s]) and computed & (1 << s)]
            initial_rows.append({"environment": dict(zip([f["name"] for f in env_fields], values)),
                                 "winning_initial_state_indices": choices})
        initial_verdict = all(x["winning_initial_state_indices"] for x in initial_rows)
        need(initial_verdict == native_result["native_initial_verdict"], "Initial verdict comparison disagreement")
        saved_memory = {
            "index_convention": "X[j][cy][i], Y[j][cy], Z[j]; last complete outer sweep; includes equality-confirming updates",
            "X": [[[log.sid(mask) for mask in row] for row in group] for group in memory["X"]],
            "Y": [[log.sid(mask) for mask in group] for group in memory["Y"]],
            "Z": [log.sid(mask) for mask in memory["Z"]],
            "memory_tail_note": "Only effectively visited slices are recorded; stale non-null Java array tails are not inferred.",
        }
        for ref in inputs:
            verify(ref)
        state_order = {
            "ordering": "itertools.product of ENV field values, then SYS/AUX field values; index=e_index*64+s_index",
            "fields": [{"name": f["name"], "owner": f["owner"], "role": f["role"], "values": f["values"]}
                       for f in fields],
            "states": count, "ENV_choices": 32, "SYS_AUX_choices": 64,
        }
        save(output_dir / "STATE_ORDER.json", state_order)
        save(output_dir / "SET_CATALOG.json", {"state_order": state_order, "sets": log.sets})
        save(output_dir / "ITERATION_TRACE.json", {"totals": totals, "events": log.events, "final_memory": saved_memory})
        result.update({
            "status": "PASS_FULL_TYPED_REGION_EQUAL" if symmetric_difference == 0 else "FAIL_FULL_TYPED_REGION_DIFFERENCE",
            "typed_state_count": count, "ENV_successor_choices": 32, "SYS_AUX_successor_choices": 64,
            "rhoE_DAG_evaluations": count * 32, "rhoS_DAG_evaluations": count * 64,
            "factorization_basis": "Checked rhoE excludes next SYS/AUX and rhoS excludes next ENV; every typed value is included.",
            "choice_row_groups": len(predecessor.groups),
            "legal_ENV_choice_count": sum(e.bit_count() for e, s in rows),
            "full_safe_transition_count": sum(e.bit_count() * s.bit_count() for e, s in rows),
            "ENV_dead_end_states": sum(e == 0 for e, s in rows),
            "CPre_vacuity_preserved": True,
            "no_Alive_filter_no_justice_normalization": True,
            "solver_justice_counts": {k: len(v) for k, v in justice_masks.items()},
            "computed_region_cardinality": computed.bit_count(),
            "native_region_cardinality": native_region.bit_count(),
            "symmetric_difference_cardinality": symmetric_difference.bit_count(),
            "computed_region_mask_hex": hex(computed),
            "native_region_mask_hex": hex(native_region),
            "first_differences": [{"index": s, "state": states[s], "computed": bool(computed & (1 << s)),
                                   "native": bool(native_region & (1 << s))}
                                  for s in range(count) if symmetric_difference & (1 << s)][:16],
            "original_transformed_initial_choices": initial_rows,
            "computed_initial_verdict": initial_verdict,
            "native_initial_verdict": native_result["native_initial_verdict"],
            "iterations": totals, "unique_predecessor_targets": len(predecessor.cache),
            "direct_ungrouped_predecessor_checks": predecessor.direct_validation_targets,
            "unique_recorded_sets": len(log.sets), "trace_events": len(log.events),
            "final_memory": saved_memory,
            "post_input_hash_check": "PASS",
            "interpretation": "Finite-set evaluation of this raw transformed recurrence agrees or disagrees with the saved native region only. It does not establish extracted-strategy cooperation or identify the cause of the failing graph.",
        })
        result["output_pins"] = [pin(output_dir / x) for x in ["STATE_ORDER.json", "SET_CATALOG.json", "ITERATION_TRACE.json"]]
    except BaseException as exc:
        result.update(status="UNKNOWN_RECOMPUTATION_INCOMPLETE", error=type(exc).__name__ + ": " + str(exc),
                      traceback=traceback.format_exc())
    result["elapsed_seconds"] = time.monotonic() - STARTED
    result["finished_utc"] = datetime.now(timezone.utc).isoformat()
    save(output_dir / "RESULT.json", result)
    print(json.dumps({k: result.get(k) for k in ["status", "typed_state_count", "computed_region_cardinality",
                                               "native_region_cardinality", "symmetric_difference_cardinality",
                                               "iterations", "elapsed_seconds", "error"]}))
    if result["status"].startswith("UNKNOWN"):
        raise SystemExit(2)


if __name__ == "__main__":
    main()
