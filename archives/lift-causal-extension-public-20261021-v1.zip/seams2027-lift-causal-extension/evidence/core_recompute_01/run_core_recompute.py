"""One contained, explicitly bounded independent Lift T finite-set solve."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
EXPERIMENT = HERE.parent
WORK = EXPERIMENT.parent.parent
OLD = WORK / "experiment/seams_research_reframing_20261018"
NATIVE = EXPERIMENT / "runs/baseline_01/native"


def pin(path):
    path = Path(path).resolve(strict=True)
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def save(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def main():
    assert len(sys.argv) == 1
    assert not (HERE / "PROTOCOL.json").exists(), "One fresh run only"
    config = json.loads((OLD / "lift_resource_followup_01/CONFIG.json").read_text())["execution"]
    py = config["runtime"]["python"]
    assert pin(py["path"]) == py
    evaluator = OLD / "frozen_execution_01/code/independent/independent_core.py"
    assert pin(evaluator)["sha256"] == "aa7aa11d0ab35f9505db132db45cb9cc7832e91216e80f56651bf0b3cea8805e"
    supervisor = OLD / "frozen_execution_01/code/dispatch/bounded_process.py"
    companion = supervisor.with_name("owned_process.py")
    source_base = WORK / "experiment/seams_establishment_20261013/current_build_preparation/released_sources"
    recurrence = source_base / "tau.smlab.syntech.games.gr1/src/tau/smlab/syntech/games/gr1/GR1SeparatedGame.java"
    predecessor = source_base / "tau.smlab.syntech.gamemodel/src/tau/smlab/syntech/gamemodel/PlayerModule.java"
    files = [NATIVE / "result.json", NATIVE / "model.json"] + sorted(NATIVE.glob("*.bdd"))
    files += [evaluator, supervisor, companion, HERE / "recompute_worker.py", Path(__file__),
              recurrence, predecessor, EXPERIMENT / "PIPELINE_SOURCE_MAP.json", EXPERIMENT / "PIPELINE_SOURCE_MAP.txt"]
    pins = [pin(p) for p in files]
    protocol = {
        "schema": "lift-t-independent-raw4fp-protocol-v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "authorization": pin(EXPERIMENT / "AUTHORIZATION_AND_PRIORITY_CHANGE.json"),
        "purpose": "Finite-set recomputation on the exact baseline transformed typed arena; full-region equality test.",
        "native_directory": str(NATIVE), "input_pins": pins, "saved_DAG_evaluator": pin(evaluator),
        "recurrence": {
            "CPre": "forall next ENV: rhoE(s,e') implies exists next SYS/AUX: rhoS(s,e',o') and (e',o') in T",
            "EPre": "exists next ENV,next SYS/AUX: rhoE(s,e') and rhoS(s,e',o') and (e',o') in T",
            "start": "(G_j intersect CPre(Z)) union CPre(Y_previous)",
            "W": "least W: start union (not A_i intersect EPre(W) intersect CPre(W union (X intersect not A_i)))",
            "X": "greatest, initialized at current Z, repeatedly replaced by the inner least-W result",
            "Y": "least, initialized empty; union converged X over the ordered ENV justices",
            "Z": "greatest, initialized all 2048 typed states; successive ordered SYS-justice sweeps until the final component stabilizes",
            "source_lines": "GR1SeparatedGame.java 27-69; PlayerModule.java 1394-1432 and 1774-1799",
            "no_contract_repair": True, "no_Alive_restriction": True, "no_justice_normalization": True,
            "no_final_region_or_saved_graph_used_for_computation": True,
        },
        "limits": {"wall_seconds": 120, "internal_seconds": 110, "rss_bytes": 1073741824,
                   "output_tree_bytes": 33554432, "stream_bytes": 1048576, "file_bytes": 16777216,
                   "min_free_bytes": 1073741824, "automatic_retries": 0},
        "native_solver_runs": 0, "full_reset_uses": 0,
    }
    save(HERE / "PROTOCOL.json", protocol)
    spec = importlib.util.spec_from_file_location("independent_core_supervisor", supervisor)
    stage = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(stage)
    output = HERE / "output"
    command = [py["path"], "-I", "-S", "-B", str(HERE / "recompute_worker.py"),
               str(HERE / "PROTOCOL.json"), str(output)]
    deadline = datetime.now(timezone.utc) + timedelta(seconds=120)
    process = stage.run_bounded(
        command, HERE / "process", deadline.isoformat(), wall_seconds=120,
        rss_bytes=1073741824, stream_bytes=1048576, file_bytes=16777216,
        watch_files=[output / x for x in ["RESULT.json", "SET_CATALOG.json", "ITERATION_TRACE.json", "STATE_ORDER.json"]],
        output_tree=HERE, output_tree_bytes=33554432,
        aggregate_tree=HERE, aggregate_tree_bytes=33554432, min_free_bytes=1073741824)
    result = {
        "schema": "lift-t-independent-raw4fp-run-v1",
        "status": "UNKNOWN_INDEPENDENT_PROCESS",
        "protocol": pin(HERE / "PROTOCOL.json"),
        "process": pin(HERE / "process/PROCESS_RECEIPT.json"),
        "native_solver_runs": 0, "full_reset_uses": 0,
    }
    if (output / "RESULT.json").exists():
        child = json.loads((output / "RESULT.json").read_text())
        result["worker_result"] = pin(output / "RESULT.json")
        result["worker_status"] = child["status"]
        for name in ["typed_state_count", "computed_region_cardinality", "native_region_cardinality",
                     "symmetric_difference_cardinality", "iterations", "elapsed_seconds", "error"]:
            if name in child:
                result[name] = child[name]
        if (process["status"] == "PROCESS_COMPLETED" and process["exit_code"] == 0
                and not process["resource_reasons"] and not process["fatal_reasons"]):
            result["status"] = child["status"]
    result["post_input_hash_check"] = all(pin(r["path"]) == r for r in pins)
    if not result["post_input_hash_check"]:
        result["status"] = "UNKNOWN_INPUT_CHANGED"
    result["resource_reasons"] = process["resource_reasons"]
    result["fatal_reasons"] = process["fatal_reasons"]
    result["finished_utc"] = datetime.now(timezone.utc).isoformat()
    save(HERE / "RESULT.json", result)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
