"""Bounded membership comparison of independently recomputed and observed X/Y/Z."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
from itertools import product
import hashlib
import importlib.util
import json
import sys
import time
import traceback

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
EXPERIMENT = BASE.parent
WORK = EXPERIMENT.parent.parent
OLD = WORK / "experiment/seams_research_reframing_20261018"
RUN = BASE / "memory_compare_01"
OBSERVER = EXPERIMENT / "runs/paired_observer_02/native"
NATIVE = EXPERIMENT / "runs/baseline_01/native"


def pin(path):
    path = Path(path).resolve(strict=True)
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()
    if len(raw) >= 16 * 1024 * 1024:
        raise ValueError("Individual output cap")
    with Path(path).open("xb") as stream:
        stream.write(raw)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def worker():
    started = time.monotonic()
    protocol = read(RUN / "PROTOCOL.json")
    result = {
        "schema": "lift-t-independent-observed-memory-comparison-v1",
        "status": "UNKNOWN_STARTED",
        "native_runs": 0, "fixed_point_recomputations_in_this_comparison": 0,
        "inputs": protocol["input_pins"], "protocol_pin": pin(RUN / "PROTOCOL.json"),
    }
    try:
        assert all(pin(r["path"]) == r for r in protocol["input_pins"])
        core = load("memory_compare_saved_DAG", protocol["saved_DAG_evaluator"]["path"])
        recomputed = read(BASE / "output/RESULT.json")
        catalog = read(BASE / "output/SET_CATALOG.json")
        observer = read(OBSERVER / "paired_observer.json")
        model = read(OBSERVER / "model.json")
        native_model = read(NATIVE / "model.json")
        native_result = read(NATIVE / "result.json")
        assert recomputed["status"] == "PASS_FULL_TYPED_REGION_EQUAL"
        assert model == native_model
        assert observer["same_memory_object"] and observer["same_model_object"]
        assert observer["graph_parity_excluding_only_controller_object_identity"]
        assert observer["memory_and_model_all_BDDs_equal"] and observer["variable_order_unchanged"]
        assert all(observer["BDD_equality_checks"].values())
        fields = model["fields"]
        ordered = catalog["state_order"]
        assert ordered["fields"] == [
            {"name": f["name"], "owner": f["owner"], "role": f["role"], "values": f["values"]}
            for f in fields]
        valuations = list(product(*(f["values"] for f in fields)))
        assert len(valuations) == 2048
        assignments = []
        for values in valuations:
            bits = {}
            for f, value in zip(fields, values):
                bits.update({int(bit): truth for bit, truth in f["encoding"][value]["current"].items()})
            assignments.append(bits)
        sets = {row["id"]: int(row["mask_hex"], 16) for row in catalog["sets"]}
        memory = recomputed["final_memory"]
        expected = {}
        for j, group in enumerate(memory["X"]):
            for cy, row in enumerate(group):
                for i, set_id in enumerate(row):
                    expected[f"x_mem_{j}_{i}_{cy}"] = sets[set_id]
        for j, group in enumerate(memory["Y"]):
            for cy, set_id in enumerate(group):
                expected[f"y_mem_{j}_{cy}"] = sets[set_id]
        for j, set_id in enumerate(memory["Z"]):
            expected[f"z_mem_{j}"] = sets[set_id]
        expected["win"] = int(recomputed["computed_region_mask_hex"], 16)
        saved = observer["memory_snapshots"]
        actual_memory_keys = {k for k in saved if k.startswith(("x_mem_", "y_mem_", "z_mem_")) or k == "win"}
        missing = sorted(set(expected) - actual_memory_keys)
        extra = sorted(actual_memory_keys - set(expected))
        assert not missing, "Missing observed effective memory slices: " + repr(missing)
        # Bind the observed model's full relations and ordered justices to the
        # exact native model used by the independent finite-set recomputation.
        relation_map = {
            "ENV_initial": native_model["original_bdds"]["thetaE"],
            "ENV_trans": native_model["original_bdds"]["rhoE"],
            "SYS_initial": native_model["original_bdds"]["thetaS"],
            "SYS_trans": native_model["original_bdds"]["rhoS"],
        }
        for owner in ["ENV", "SYS"]:
            for i, ref in enumerate(native_result["solver_justices"][owner]):
                relation_map[f"{owner}_justice_{i}"] = ref
        relation_checks = {}
        for name, baseline in relation_map.items():
            ref = saved[name]
            current = pin(OBSERVER / "paired_memory" / ref["file"])
            relation_checks[name] = (
                current["sha256"] == ref["sha256"] == baseline["sha256"]
                and current["bytes"] == ref["bytes"] == baseline["bytes"])
        assert all(relation_checks.values()), "Observed relation/justice binding mismatch"
        rows = []
        for name, finite_set in expected.items():
            if time.monotonic() - started > 110:
                raise TimeoutError("Memory comparison internal limit")
            ref = saved[name]
            path = OBSERVER / "paired_memory" / ref["file"]
            current = pin(path)
            assert current["sha256"] == ref["sha256"] and current["bytes"] == ref["bytes"]
            dag = core.SavedDag(path.read_bytes(), model["bdd_variable_count"], model["bdd_variable_order"])
            assert dag.support <= set(model["all_current_bits"])
            observed = sum(1 << i for i, bits in enumerate(assignments) if dag.value(bits))
            difference = finite_set ^ observed
            rows.append({
                "name": name, "observed_file": current, "typed_states_compared": 2048,
                "independent_cardinality": finite_set.bit_count(), "observed_cardinality": observed.bit_count(),
                "symmetric_difference_cardinality": difference.bit_count(),
                "matches": difference == 0,
                "first_differences": [
                    {"index": i, "valuation": dict(zip([f["name"] for f in fields], valuations[i])),
                     "independent": bool(finite_set & (1 << i)), "observed": bool(observed & (1 << i))}
                    for i in range(2048) if difference & (1 << i)][:8],
            })
        assert all(pin(r["path"]) == r for r in protocol["input_pins"])
        result.update(
            status=("PASS_ALL_OBSERVED_XYZ_AND_WIN_EQUAL" if not extra and all(r["matches"] for r in rows)
                    else "FAIL_MEMORY_COMPARISON_DIFFERENCE"),
            typed_states=2048, memory_sets_compared=len(rows), state_membership_comparisons=2048 * len(rows),
            relation_and_ordered_justice_byte_bindings=relation_checks,
            missing_memory_slices=missing, extra_memory_slices_not_effectively_recomputed=extra,
            rows=rows, all_input_hashes_unchanged=True,
            scope="All effective last-sweep X/Y/Z slices and win are compared by typed-state membership. Equality is not proof of extracted-controller cooperation or a causal diagnosis.")
    except BaseException as exc:
        result.update(status="UNKNOWN_MEMORY_COMPARISON_INCOMPLETE",
                      error=type(exc).__name__ + ": " + str(exc), traceback=traceback.format_exc())
    result["elapsed_seconds"] = time.monotonic() - started
    result["finished_utc"] = datetime.now(timezone.utc).isoformat()
    save(RUN / "WORKER_RESULT.json", result)
    print(json.dumps({k: result.get(k) for k in ["status", "memory_sets_compared",
                                               "state_membership_comparisons", "elapsed_seconds", "error"]}))
    if result["status"].startswith("UNKNOWN"):
        raise SystemExit(2)


def main():
    if len(sys.argv) == 2 and sys.argv[1] == "--worker":
        worker()
        return
    assert len(sys.argv) == 1
    RUN.mkdir(exist_ok=False)
    evaluator = OLD / "frozen_execution_01/code/independent/independent_core.py"
    supervisor = OLD / "frozen_execution_01/code/dispatch/bounded_process.py"
    python = read(OLD / "lift_resource_followup_01/CONFIG.json")["execution"]["runtime"]["python"]
    assert pin(python["path"]) == python
    files = [Path(__file__), evaluator, supervisor, supervisor.with_name("owned_process.py"),
             BASE / "RESULT.json", BASE / "output/RESULT.json", BASE / "output/SET_CATALOG.json",
             BASE / "output/STATE_ORDER.json", BASE / "output/ITERATION_TRACE.json",
             OBSERVER / "paired_observer.json", OBSERVER / "result.json", OBSERVER / "model.json",
             NATIVE / "result.json", NATIVE / "model.json"]
    files += sorted((OBSERVER / "paired_memory").glob("*.bdd"))
    protocol = {
        "purpose": "Compare saved independent finite-set X/Y/Z with the observer's immutable native memory snapshots.",
        "input_pins": [pin(p) for p in files], "saved_DAG_evaluator": pin(evaluator),
        "limits": {"wall_seconds": 120, "internal_seconds": 110, "rss_bytes": 1073741824,
                   "output_tree_bytes": 33554432, "stream_bytes": 1048576, "file_bytes": 16777216},
        "native_runs": 0, "new_game_solves": 0, "full_reset_uses": 0,
    }
    save(RUN / "PROTOCOL.json", protocol)
    stage = load("memory_compare_supervisor", supervisor)
    command = [python["path"], "-I", "-S", "-B", str(Path(__file__)), "--worker"]
    process = stage.run_bounded(
        command, RUN / "process", (datetime.now(timezone.utc) + timedelta(seconds=120)).isoformat(),
        wall_seconds=120, rss_bytes=1073741824, stream_bytes=1048576, file_bytes=16777216,
        watch_files=[RUN / "WORKER_RESULT.json"], output_tree=RUN, output_tree_bytes=33554432,
        aggregate_tree=RUN, aggregate_tree_bytes=33554432, min_free_bytes=1073741824)
    result = {"status": "UNKNOWN_MEMORY_COMPARISON_PROCESS", "protocol": pin(RUN / "PROTOCOL.json"),
              "process": pin(RUN / "process/PROCESS_RECEIPT.json")}
    if (RUN / "WORKER_RESULT.json").exists():
        value = read(RUN / "WORKER_RESULT.json")
        result["worker_result"] = pin(RUN / "WORKER_RESULT.json")
        result["worker_status"] = value["status"]
        for name in ["memory_sets_compared", "state_membership_comparisons", "elapsed_seconds", "error"]:
            if name in value:
                result[name] = value[name]
        if process["status"] == "PROCESS_COMPLETED" and process["exit_code"] == 0:
            result["status"] = value["status"]
    result["all_input_hashes_unchanged"] = all(pin(r["path"]) == r for r in protocol["input_pins"])
    if not result["all_input_hashes_unchanged"]:
        result["status"] = "UNKNOWN_MEMORY_COMPARISON_INPUT_CHANGE"
    save(RUN / "RESULT.json", result)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
