# Independent Lift T raw-core recomputation

The independent finite-set computation agrees with the saved native raw four-fixed-point region on **all 2,048 typed states**. Both regions contain 2,048 states; their symmetric difference is empty. The subsequent comparison also agrees with **every observed X/Y/Z slice and the final win set**: 28 sets, 57,344 state-membership comparisons, zero differences and no missing or extra memory slices.

The computation used `runs/baseline_01/native/model.json` and its byte-pinned saved BDDs. The X/Y/Z comparison separately used the immutable `runs/paired_observer_02/native/paired_memory/` snapshots. All inputs were rehashed after each run and remained unchanged. Java/native solver executions in these two checks: zero.

## Exact recurrence and quantifiers

For the transformed native game, with 32 next environment choices and 64 next system/AUX choices:

```
CPre(T) = {s | for every e':
                 rhoE(s,e') implies there exists o':
                 rhoS(s,e',o') and (e',o') in T}
EPre(T) = {s | there exist e',o':
                 rhoE(s,e') and rhoS(s,e',o') and (e',o') in T}
start   = (G_j intersect CPre(Z)) union CPre(Y_previous)
W_next  = start union
          (not A_i intersect EPre(W) intersect
           CPre(W union (X intersect not A_i)))
```

The schedule follows the inspected released recurrence: greatest Z from the whole carrier; successive ordered system-justice sweeps; least Y from empty; greatest X initialized at the current Z for each environment justice; least W from empty. Source anchors are `GR1SeparatedGame.java:27–69` and `PlayerModule.java:1394–1432,1774–1799`, already pinned through `PIPELINE_SOURCE_MAP`.

No `Alive` restriction, source-contract repair, environment-justice normalization or cooperative winning-region oracle was added. CPre retains universal-implication vacuity at environment dead ends; EPre requires a real safe transition. The transformed model has no environment-dead-end states on this full carrier.

## Representation and checks

Existing `SavedDag` code only parsed and evaluated saved decision DAGs. All fixed-point operations used Python integer sets. Verified relation support permits factoring the complete transition relation into legal environment choices and safe system/AUX choices at each current state: rhoE excludes next SYS/AUX, and rhoS excludes next ENV. This required 65,536 rhoE and 131,072 rhoS evaluations and produced 96 distinct choice-row groups representing 224,864 safe complete transitions.

The implementation checked its grouped predecessor against direct, ungrouped quantifier enumeration for every one of the 15 target sets encountered. Synthetic controls also checked environment-dead-end vacuity, a legal input without a system response, and three closed-form one-state recurrence cases.

The solve took one outer pass, 12 Y updates, 18 X updates and 48 W updates. It saved 21 distinct sets and 81 iteration events, including W layers, for later diagnostic comparison. Both transformed initial environment assignments have the required winning initial system/AUX response.

The separate observer comparison first bound its complete model, initial relations, transition relations and ordered justices to the baseline. It then compared 12 X slices, 12 Y slices, three Z components and win by full typed-state membership. The effective slice indexing is recorded explicitly; no unvisited Java array tail was treated as a recomputed slice.

## Bounds and interpretation

Both runs used the existing contained-process supervisor with a 120-second wall limit, 1 GiB RSS limit and 32 MiB output-tree limit, with no automatic retries. The finite-set worker completed in 0.421 seconds; its supervised process peaked at 21,757,952 bytes RSS. The memory-comparison worker completed in 0.040 seconds. Neither run hit a resource or integrity limit.

These results detect no numerical disagreement between the stated raw recurrence, the native final region and the stored converged X/Y/Z sets for this Lift T instance. They do **not** certify the cooperation of the extracted controller, establish a general correctness theorem for the raw recurrence, or identify whether selection, missing progress information or another extraction detail causes the observed failure.

Machine-readable entry points:

- `RESULT.json` and `output/RESULT.json`: complete region comparison and resource receipt.
- `output/STATE_ORDER.json`, `output/SET_CATALOG.json`, `output/ITERATION_TRACE.json`: exact finite-state encoding and all recorded iterations.
- `memory_compare_01/RESULT.json` and `memory_compare_01/WORKER_RESULT.json`: all 28 observed-memory comparisons.
- `PROTOCOL.json` and `memory_compare_01/PROTOCOL.json`: immutable inputs, source anchors and bounds.
