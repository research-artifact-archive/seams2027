"""Execute an explicitly bounded, modeled Lift adaptation episode."""
from pathlib import Path
from datetime import datetime, timezone
import copy
import hashlib
import itertools
import json
import os
import contextlib
import importlib.util
import sys
import threading
import time

HERE = Path(__file__).resolve().parent
ENV = ("b1", "b2", "b3", "c")
FLOORS = ("f1", "f2", "f3")
AUX = tuple(f"SYS_CONSTRAINT.{i}.pRespondsToS.state" for i in range(3))
FIELDS = ENV + FLOORS + AUX
VALUES = ("false", "true")
INPUTS = [dict(zip(ENV, x)) for x in itertools.product(VALUES, repeat=4)]


def now():
    return datetime.now(timezone.utc).isoformat()


def pin(path):
    path = Path(path)
    b = path.read_bytes()
    return {"path": str(path.resolve()), "bytes": len(b),
            "sha256": hashlib.sha256(b).hexdigest()}


def save(path, value):
    with Path(path).open("x") as f:
        json.dump(value, f, indent=2)
        f.write("\n")


def truth(s, name):
    return s[name] == "true"


def rho_e(s, e, mode):
    # Mixed ENV/SYS floor invariants constrain the current state only.
    if sum(truth(s, f) for f in FLOORS) != 1:
        return False
    if mode == "maintenance" and any(truth(x, b) for x in (s, e) for b in ENV[:3]):
        return False
    for b, f in zip(ENV[:3], FLOORS):
        if truth(s, b) and truth(s, f) and truth(e, b):
            return False
        if truth(s, b) and not truth(s, f) and not truth(s, "c") and not truth(e, b):
            return False
    return True


def next_aux(s):
    return {a: "S1" if (s[a] == "S1" or truth(s, b)) and not
            (truth(s, f) or truth(s, "c")) else "S0"
            for a, b, f in zip(AUX, ENV[:3], FLOORS)}


def rho_s(s, t):
    b1, b2, b3, c = [truth(s, x) for x in ENV]
    n1, n2, n3 = [truth(t, x) for x in FLOORS]
    allowed = (
        (n1 and not b2 and not b3) or (n2 and (b2 or b3)) or (n1 and c),
        (n1 and b1) or (n2 and not b1 and not b3) or (n3 and b3) or (n2 and c),
        (n3 and not b1 and not b2) or (n2 and (b1 or b2)) or (n3 and c))
    return (all(not truth(s, f) or a for f, a in zip(FLOORS, allowed))
            and all(t[a] == v for a, v in next_aux(s).items()))


def initial_state(c="false"):
    return {**{b: "false" for b in ENV[:3]}, "c": c,
            "f1": "true", "f2": "false", "f3": "false",
            **{a: "S0" for a in AUX}}


class Stationary:
    name = "source_coded_maintenance_controller"
    node_id = None

    def propose(self, s, e):
        return {**e, "f1": "true", "f2": "false", "f3": "false",
                **next_aux(s)}, None

    def commit(self, node):
        assert node is None


class NativeController:
    def __init__(self, path, name, boundary):
        self.path = Path(path)
        self.name = name
        self.graph = json.loads(self.path.read_text())
        self.nodes = {x["id"]: x for x in self.graph["nodes"]}
        self.edges = {tuple(x) for x in self.graph["edges"]}
        matches = [x for x in self.nodes.values() if x["initial"]
                   and x["valuation"]["~envHelp"] == "false"
                   and {k: x["valuation"][k] for k in FIELDS} == boundary]
        assert len(matches) == 1, "No unique exact initial-compatible handoff"
        assert matches[0]["rank"] == 0, "Declared initial rank-zero boundary absent"
        self.node_id = matches[0]["id"]
        self.initial_mapping = copy.deepcopy(matches[0])

    def propose(self, s, e):
        cur = self.nodes[self.node_id]
        assert {k: cur["valuation"][k] for k in FIELDS} == s
        matches = [self.nodes[i] for i in cur["successors"]
                   if self.nodes[i]["valuation"]["~envHelp"] == "false"
                   and all(self.nodes[i]["valuation"][k] == e[k] for k in ENV)]
        assert len(matches) == 1, "Native response absent or nondeterministic"
        nxt = matches[0]
        assert (self.node_id, nxt["id"]) in self.edges
        return {k: nxt["valuation"][k] for k in FIELDS}, nxt["id"]

    def commit(self, node):
        self.node_id = node


class Runtime:
    def __init__(self, arm, log):
        self.arm = arm
        self.state = initial_state()
        self.controller = Stationary()
        self.mode = "maintenance"
        self.epoch = 0
        self.paused = False
        self.ticks = 0
        self.lock = threading.RLock()
        self.log = log
        self.plant_identity = id(self)
        self.state_identity = id(self.state)
        self.emit("boot")

    def snap(self):
        return {"arm": self.arm, "plant_identity": self.plant_identity,
                "state_object_identity": self.state_identity,
                "source_state": dict(self.state), "contract_mode": self.mode,
                "epoch": self.epoch, "paused": self.paused, "ticks": self.ticks,
                "installed_controller": self.controller.name,
                "native_node_id": self.controller.node_id}

    def emit(self, event, **extra):
        self.log(event, runtime=self.snap(), **extra)

    def legal(self):
        return [e for e in INPUTS if rho_e(self.state, e, self.mode)]

    def step(self, e, phase):
        with self.lock:
            assert not self.paused
            before = self.snap()
            assert e in INPUTS and rho_e(self.state, e, self.mode), "Illegal offered ENV input"
            nxt, node = self.controller.propose(self.state, e)
            if not rho_s(self.state, nxt):
                self.emit("response_rejected", phase=phase, before=before,
                          offered_env=e, proposed_state=nxt, proposed_node_id=node,
                          reason="source_SYS_transition_violated")
                return False
            # No target one-hot shield is added: that is next round's ENV obligation.
            self.state.update(nxt)
            self.controller.commit(node)
            self.ticks += 1
            assert id(self.state) == self.state_identity
            self.emit("step_committed", phase=phase, before=before, offered_env=e)
            return True

    def change_and_pause(self):
        with self.lock:
            before = self.snap()
            assert self.mode == "maintenance" and not self.paused
            self.paused = True
            self.mode = "normal"
            self.epoch += 1
            assert self.state == before["source_state"]
            self.emit("environment_changed_and_paused", before=before)

    def install(self, candidate, evidence):
        with self.lock:
            before = self.snap()
            assert self.paused and self.epoch == 1 and self.mode == "normal"
            assert self.state == {k: candidate.initial_mapping["valuation"][k] for k in FIELDS}
            self.controller = candidate
            assert self.state == before["source_state"]
            self.emit("controller_installed", before=before, evidence=evidence,
                      exact_initial_mapping=candidate.initial_mapping,
                      graph=pin(candidate.path))
            self.paused = False
            self.emit("resumed")


def main():
    run = HERE / "execution"
    run.mkdir(exist_ok=False)
    plan = json.loads((HERE / "PLAN.json").read_text())
    refs = [pin(HERE / p) for p in ["PLAN.json", "run_episode.py",
            "run_intervention_pair.py", "run_pair_audits.py", "lift_maintenance.spectra"]]
    refs += [plan["new_contract"]["source"]]
    events = []
    event_file = (run / "EVENTS.jsonl").open("x")

    def log(event, **extra):
        item = {"seq": len(events), "event": event, "utc": now(),
                "monotonic_ns": time.monotonic_ns(), "pid": os.getpid(), **extra}
        events.append(item)
        event_file.write(json.dumps(item) + "\n")
        event_file.flush()

    result = {"status": "RUNNING", "scope": plan["scope"], "errors": [],
              "inputs": refs, "started_utc": now(), "full_reset_uses": 0}
    try:
        log("episode_started", plan=pin(HERE / "PLAN.json"))
        # Exhaustive old closed-loop graph: 2 initial/reachable c states, 4 edges.
        old_states = [initial_state(c) for c in VALUES]
        old_edges = []
        for s in old_states:
            legal = [e for e in INPUTS if rho_e(s, e, "maintenance")]
            assert len(legal) == 2
            for e in legal:
                t, _ = Stationary().propose(s, e)
                assert rho_s(s, t) and t in old_states
                old_edges.append({"source": s, "env": e, "target": t})
        old_cert = {"scope": "Exhaustive source-coded maintenance closed loop",
                    "states": old_states, "edges": old_edges,
                    "strict": True, "cooperative": True,
                    "proof": "Both initial ENV values covered; all four legal edges safe, all reachable states have all three justice monitors S0 and legal successors."}
        save(run / "OLD_CONTROLLER_CHECK.json", old_cert)
        log("old_controller_checked", proof=pin(run / "OLD_CONTROLLER_CHECK.json"))
        arms = [Runtime(name, log) for name in ("strict_only", "strict_and_cooperative")]
        for c in plan["old_ticks_c"]:
            for rt in arms:
                assert rt.step({**{b: "false" for b in ENV[:3]}, "c": c}, "maintenance")
        assert all(rt.state == initial_state() and rt.ticks == 4 for rt in arms)
        for rt in arms:
            rt.change_and_pause()
        boundary = copy.deepcopy(arms[0].state)
        log("candidate_generation_started", frozen_boundaries=[rt.snap() for rt in arms])
        for driver in ("run_intervention_pair.py", "run_pair_audits.py"):
            with (run / (driver + ".stdout.txt")).open("x") as out, \
                 (run / (driver + ".stderr.txt")).open("x") as err:
                spec = importlib.util.spec_from_file_location("episode_" + driver[:-3], HERE / driver)
                module = importlib.util.module_from_spec(spec)
                old_argv = sys.argv[:]
                try:
                    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                        spec.loader.exec_module(module)
                        sys.argv = [str(HERE / driver), "lift__trivial_1"]
                        module.main()
                finally:
                    sys.argv = old_argv
            log("generation_stage_finished", driver=driver, returncode=0,
                execution_mode="driver main called in runtime process; native/checker children individually supervised",
                stdout=pin(run / (driver + ".stdout.txt")),
                stderr=pin(run / (driver + ".stderr.txt")))
            path = HERE / "native_pair_01/lift__trivial_1" / (
                "audits/RESULT.json" if "audits" in driver else "PAIR_RESULT.json")
            data = json.loads(path.read_text())
            assert data["status"].startswith("COMPLETE") and data["input_integrity"] == "PASS"
        pair = HERE / "native_pair_01/lift__trivial_1"
        audits = json.loads((pair / "audits/RESULT.json").read_text())
        assert all(rt.paused and rt.state == boundary and rt.ticks == 4 for rt in arms)
        log("candidate_generation_and_audits_completed", audits=pin(pair / "audits/RESULT.json"),
            unchanged_paused_boundaries=[rt.snap() for rt in arms])
        candidates = [("released_native", "native", "baseline"),
                      ("experimental_continuation_preference", "variant", "variant")]
        for rt in arms:
            decisions = []
            selected = None
            for name, folder, label in candidates:
                verdict = audits[label]
                eligible = verdict["strict"] and (
                    rt.arm == "strict_only" or verdict["cooperative"])
                decisions.append({"candidate": name, "strict": verdict["strict"],
                                  "cooperative": verdict["cooperative"], "admit": eligible})
                log("candidate_admission", arm=rt.arm, decision=decisions[-1])
                if eligible:
                    selected = NativeController(pair / folder / "controller.json", name, rt.state)
                    break
            assert selected is not None
            rt.install(selected, {"ordered_decisions": decisions,
                                 "audit_result": pin(pair / "audits/RESULT.json")})
        # Same input script, each input checked against each actual current state.
        for e in plan["common_post_switch_inputs"]:
            for rt in arms:
                assert rt.step(e, "common_post_switch_script")
        outcomes = {}
        for rt in arms:
            tail = [rt.snap()]
            seen = {(rt.controller.node_id, tuple(rt.state[k] for k in FIELDS)): 0}
            outcome = None
            for _ in range(plan["limits"]["continuation_steps_per_arm"]):
                legal = rt.legal()
                if not legal:
                    rt.emit("no_legal_original_ENV_continuation", all_typed_inputs_checked=len(INPUTS))
                    outcome = {"status": "ORIGINAL_ENV_DEADEND", "state": rt.snap(),
                               "all_typed_inputs_checked": len(INPUTS)}
                    break
                assert rt.step(legal[0], "lexicographic_legal_continuation")
                tail.append(rt.snap())
                key = (rt.controller.node_id, tuple(rt.state[k] for k in FIELDS))
                if key in seen:
                    begin = seen[key]
                    cycle = tail[begin:-1]
                    hits = {a: any(s["source_state"][a] == "S0" for s in cycle) for a in AUX}
                    assert cycle and all(hits.values())
                    outcome = {"status": "EXECUTED_FAIR_LASSO", "cycle_start": begin,
                               "cycle_end": len(tail)-1, "tail_states": tail,
                               "SYS_justice_hits": hits, "ENV_justice_count": 0,
                               "interpretation": "Concrete executed fair continuation; universal properties come from separate full-controller audits."}
                    rt.emit("executed_fair_lasso", cycle_start=begin,
                            cycle_end=len(tail)-1, SYS_justice_hits=hits)
                    break
                seen[key] = len(tail)-1
            outcomes[rt.arm] = outcome or {"status": "UNKNOWN_CONTINUATION_BOUND"}
        # Explicit separate counterfactual; it never changes either experimental plant.
        noadapt = Runtime("no_adaptation_counterfactual", log)
        assert noadapt.state == boundary
        noadapt.change_and_pause()
        noadapt.paused = False
        noadapt.emit("counterfactual_resumed_without_controller_change")
        counterfactual = []
        for e in plan["no_adaptation_counterfactual_inputs"]:
            ok = noadapt.step(e, "no_adaptation_counterfactual")
            counterfactual.append({"env": e, "step_committed": ok})
            if not ok:
                break
        result.update({"status": "COMPLETE_EXECUTED_EPISODE",
                       "outcomes": outcomes, "no_adaptation_counterfactual": counterfactual,
                       "fresh_audits": pin(pair / "audits/RESULT.json"),
                       "old_controller_check": pin(run / "OLD_CONTROLLER_CHECK.json"),
                       "final_snapshots": [rt.snap() for rt in arms],
                       "claims_require_independent_episode_audit": True})
        log("episode_completed", outcomes={k: v["status"] for k, v in outcomes.items()})
    except BaseException as exc:
        result["status"] = "UNKNOWN_OR_INVALID_EPISODE"
        result["errors"].append(type(exc).__name__ + ": " + str(exc))
        log("episode_failed", error=result["errors"][-1])
    finally:
        result["input_integrity"] = "PASS" if all(pin(x["path"]) == x for x in refs) else "FAIL"
        if result["input_integrity"] != "PASS":
            result["status"] = "UNKNOWN_INPUT_MUTATION"
        result["finished_utc"] = now()
        event_file.close()
        result["events"] = pin(run / "EVENTS.jsonl")
        result["event_count"] = len(events)
        save(run / "RESULT.json", result)
        print(json.dumps(result))


if __name__ == "__main__":
    main()
