"""Read-only independent audit of the saved modeled adaptation episode.

No episode implementation is imported. Source transition predicates come from
the independently authored frozen contract. Full-graph judges are not rerun.
The only write is this checker's requested report, under independent/.
"""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import importlib.util
import itertools
import json
import sys

sys.dont_write_bytecode = True
HERE = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent
CONTRACT_PATH = (HERE.parent.parent / "seams_research_reframing_20261018"
                 / "frozen_execution_01/code/independent/source_contracts.py")
CONTRACT_SHA = "30d1d89c5977798601cfcf661ef8d642c3fdb7c7c7600cd9d9fa9a3a25011fc8"
ARMS = ("strict_only", "strict_and_cooperative")
OLD_NAME = "source_coded_maintenance_controller"
POOL = (("released_native", "native", "baseline"),
        ("experimental_continuation_preference", "variant", "variant"))
COUNTERFACTUAL = "no_adaptation_counterfactual"


def pin(path):
    path = Path(path).resolve()
    b = path.read_bytes()
    return {"path": str(path), "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()}


def read(path):
    return json.loads(Path(path).read_text())


def time_value(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


class Audit:
    def __init__(self):
        self.counts = Counter()
        self.read_pins = {}
        self.report = {
            "schema": "lift-executed-adaptation-independent-audit-v1",
            "status": "RUNNING",
            "started_utc": datetime.now(timezone.utc).isoformat(),
            "scope": "Source semantics, event replay, actual controller edges, and executed continuation.",
            "independence": {
                "episode_runner_imports": 0,
                "native_processes": 0,
                "new_full_graph_judge_runs": 0,
                "source_contract_import": pin(CONTRACT_PATH),
                "full_graph_results": "Inspect and bind the four existing fresh judge reports; do not infer universal fairness from the executed loop."
            },
            "limitations": [
                "Constructed in-process model, not hardware or deployment middleware.",
                "Initial-compatible stopped handoff; arbitrary-state migration is not shown.",
                "The shared prefix was selected from an already known failure, not held out.",
                "The executed loop witnesses one infinite continuation; separate complete graph judgments support universal properties.",
                "Process-group RSS bounds are separate; no measured aggregate-tree RSS bound is claimed."
            ],
            "errors": []
        }

    def need(self, condition, label, category="structural"):
        self.counts[category] += 1
        if not condition:
            raise AssertionError(label)

    def load(self, path):
        path = Path(path).resolve()
        self.read_pins[str(path)] = pin(path)
        return read(path)

    def check_pin(self, ref):
        actual = pin(ref["path"])
        self.need(actual == ref, "pin mismatch: " + ref["path"], "pins")
        self.read_pins[actual["path"]] = actual
        return Path(ref["path"])

    def pinned_load(self, ref):
        return self.load(self.check_pin(ref))

    def source(self, state):
        self.need(set(state) == set(self.C.names), "source field roster differs", "typed_states")
        self.need(all(state[k] in self.C.values[k] for k in self.C.names),
                  "source valuation outside typed domain", "typed_states")
        return state

    def project(self, node):
        return {k: node["valuation"][k] for k in self.C.names}

    def env_legal(self, state, env, maintenance=False):
        # Original ENV predicates use only successor ENV variables.
        original = self.C.rho_e(state, {**state, **env})
        extra = not maintenance or all(
            x[b] == "false" for x in (state, env) for b in self.C.env[:3])
        return original and extra

    def legal_inputs(self, state, maintenance=False):
        return [e for e in self.env_inputs if self.env_legal(state, e, maintenance)]

    def stationary_successor(self, state, env):
        # Derive the unique legal AUX update by typed enumeration and rhoS.
        outputs = []
        for aux_values in itertools.product(*(values for _, values in self.C.aux)):
            candidate = {**env, **dict(zip(self.C.system, ("true", "false", "false"))),
                         **dict(zip((name for name, _ in self.C.aux), aux_values))}
            if self.C.rho_s(state, candidate):
                outputs.append(candidate)
        return outputs

    def process(self, ref, earliest=None, latest=None):
        receipt = self.pinned_load(ref)
        self.need(receipt["status"] == "PROCESS_COMPLETED" and receipt["exit_code"] == 0,
                  "process did not complete", "processes")
        self.need(receipt["parent_finalization_completed"] and receipt["receipt_persisted"]
                  and not receipt["parent_aborted"] and not receipt["parent_internal_exception"],
                  "process supervisor did not finish normally", "processes")
        self.need(not receipt["resource_reasons"] and not receipt["fatal_reasons"],
                  "process resource/fatal reason present", "processes")
        self.need(receipt["final_group_observation"]["state"] == "ABSENT",
                  "owned process group not absent", "processes")
        self.need(receipt["exact_child_wait4"]["exact_child_reaped"]
                  and receipt["exact_child_wait4"]["returncode"] == 0,
                  "child not exactly reaped successfully", "processes")
        self.need(all(x["complete"] for x in receipt["capture"].values()),
                  "process stream capture incomplete", "processes")
        if earliest is not None:
            self.need(time_value(receipt["started_utc"]) >= time_value(earliest),
                      "process began before the declared generation stage", "timeline")
        if latest is not None:
            self.need(time_value(receipt["exact_child_wait4"]["reaped_utc"]) <= time_value(latest),
                      "process reaped after stage-complete event", "timeline")
        return receipt

    def setup(self):
        self.need(pin(CONTRACT_PATH)["sha256"] == CONTRACT_SHA, "wrong independent contract code", "pins")
        spec = importlib.util.spec_from_file_location("episode_independent_contract", CONTRACT_PATH)
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        self.module = module
        self.C = module.CONTRACTS["lift__trivial_1"]
        self.env_inputs = [dict(zip(self.C.env, values)) for values in
                           itertools.product(*(self.C.values[k] for k in self.C.env))]
        self.plan = self.load(HERE / "PLAN.json")
        self.need(self.plan["status"] == "FROZEN_BEFORE_EXECUTION", "unfrozen plan")
        self.need(self.plan["candidate_pool"] == [x[0] for x in POOL], "unexpected candidate pool")
        self.need(self.plan["old_ticks_c"] == ["false", "true", "true", "false"], "warmup changed")
        self.need(self.plan["limits"]["continuation_steps_per_arm"] == 32, "tail bound changed")
        self.need(self.plan["full_reset_uses"] == 0, "unexpected reset use")
        new_path = self.check_pin(self.plan["new_contract"]["source"])
        old_path = self.check_pin(self.plan["old_contract"]["source"])
        self.need(pin(new_path)["sha256"] == self.C.source_sha256
                  and pin(new_path)["bytes"] == self.C.source_bytes, "source contract pin mismatch", "pins")
        expected_suffix = b"\nassumption -- maintenance_no_requests\n  alw((!b1 & !b2 & !b3));\n"
        self.need(old_path.read_bytes() == new_path.read_bytes() + expected_suffix,
                  "maintenance changes more than the declared restriction", "source_contracts")
        self.result = self.load(HERE / "execution/RESULT.json")
        self.need(self.result["status"] == "COMPLETE_EXECUTED_EPISODE"
                  and self.result["input_integrity"] == "PASS" and not self.result["errors"],
                  "episode did not complete")
        self.need(self.result["scope"] == self.plan["scope"] and self.result["full_reset_uses"] == 0,
                  "episode scope/reset differs")
        for ref in self.result["inputs"]:
            self.check_pin(ref)
        event_path = self.check_pin(self.result["events"])
        self.events = [json.loads(line) for line in event_path.read_text().splitlines()]
        self.need(len(self.events) == self.result["event_count"], "event count differs")
        self.need([e["seq"] for e in self.events] == list(range(len(self.events))),
                  "event sequence has gaps or duplicates", "timeline")
        self.need(len({e["pid"] for e in self.events}) == 1, "episode runtime pid changes", "timeline")
        self.need(all(a["monotonic_ns"] < b["monotonic_ns"]
                      and time_value(a["utc"]) <= time_value(b["utc"])
                      for a, b in zip(self.events, self.events[1:])),
                  "event time is not monotonic", "timeline")
        self.need(self.events[0]["event"] == "episode_started"
                  and self.events[-1]["event"] == "episode_completed", "bad event endpoints")
        self.need(time_value(self.plan["created_utc"]) <= time_value(self.events[0]["utc"]),
                  "plan created after execution began", "timeline")
        self.by_event = {}
        for event in self.events:
            self.by_event.setdefault(event["event"], []).append(event)
        for event in ("episode_started", "old_controller_checked", "candidate_generation_started",
                      "candidate_generation_and_audits_completed", "episode_completed"):
            self.need(len(self.by_event.get(event, [])) == 1, "wrong multiplicity: " + event)
        self.generation_start = self.by_event["candidate_generation_started"][0]
        self.generation_end = self.by_event["candidate_generation_and_audits_completed"][0]
        self.need(self.generation_start["seq"] < self.generation_end["seq"], "generation ordering", "timeline")

    def old_controller(self):
        old = self.pinned_load(self.result["old_controller_check"])
        self.check_pin(self.by_event["old_controller_checked"][0]["proof"])
        # Derive all old initial states from the pinned source initializers.
        candidates = [{**env, **dict(zip(self.C.system, ("true", "false", "false"))),
                       **{name: "S0" for name, _ in self.C.aux}} for env in self.env_inputs]
        expected = [s for s in candidates if self.C.theta_e(s) and self.C.theta_s(s)]
        self.need(len(expected) == 2 and old["states"] == expected,
                  "old graph does not cover exact initial states", "old_graph")
        expected_edges = []
        for state in expected:
            self.source(state)
            env_justice, sys_justice = self.C.justice(state)
            self.need(not env_justice and len(sys_justice) == 3 and all(sys_justice),
                      "old reachable state lacks justice", "old_graph")
            inputs = self.legal_inputs(state, maintenance=True)
            self.need(len(inputs) == 2, "old legal ENV count", "old_graph")
            for env in inputs:
                targets = self.stationary_successor(state, env)
                self.need(len(targets) == 1 and targets[0] in expected,
                          "old stationary update not closed and uniquely safe", "old_graph")
                expected_edges.append({"source": state, "env": env, "target": targets[0]})
        self.need(old["edges"] == expected_edges and len(expected_edges) == 4,
                  "old edge enumeration differs", "old_graph")
        self.need(old["strict"] is True and old["cooperative"] is True, "old verdict differs", "old_graph")
        self.initial_states = expected
        self.report["old_controller"] = {"initial_reachable_states": 2, "edges": 4,
                                          "strict": True, "cooperative": True,
                                          "proof": "All reachable states satisfy all SYS justice sets, and every state has two legal covered ENV choices."}

    def candidates(self):
        pair_dir = HERE / "native_pair_01/lift__trivial_1"
        pair = self.load(pair_dir / "PAIR_RESULT.json")
        self.need(pair["status"] == "COMPLETE_PAIRED_INTERVENTION_AWAITING_SEMANTIC_AUDITS"
                  and pair["input_integrity"] == "PASS" and not pair["errors"],
                  "fresh pair incomplete")
        stages = self.by_event.get("generation_stage_finished", [])
        self.need(len(stages) == 2 and [e["driver"] for e in stages] ==
                  ["run_intervention_pair.py", "run_pair_audits.py"], "wrong generation stages", "timeline")
        self.need(self.generation_start["seq"] < stages[0]["seq"] < stages[1]["seq"]
                  < self.generation_end["seq"], "generation stage order", "timeline")
        for stage in stages:
            self.need(stage["returncode"] == 0, "generation stage returncode")
            self.check_pin(stage["stdout"])
            self.check_pin(stage["stderr"])
        process = self.process(pair["process"], self.generation_start["utc"], stages[0]["utc"])
        self.need(str(pair_dir / "native/result.json") in process["argv"]
                  and "PairedContinuationDiagnostic" in process["argv"],
                  "pair process does not target this episode", "freshness")
        self.need(process["limits"]["wall_seconds"] == self.plan["limits"]["pair_wall_seconds"]
                  and process["limits"]["rss_bytes"] == self.plan["limits"]["pair_rss_bytes"],
                  "pair resource limits differ")
        audits_path = self.check_pin(self.result["fresh_audits"])
        self.need(audits_path.resolve() == (pair_dir / "audits/RESULT.json").resolve(),
                  "audits from a different episode", "freshness")
        self.check_pin(self.generation_end["audits"])
        audits = self.load(audits_path)
        self.need(audits["status"] == "COMPLETE_BOTH_ARMS_BOTH_AUDITS_AGREE"
                  and audits["input_integrity"] == "PASS" and not audits["errors"],
                  "fresh judges incomplete")
        expected_names = {a + "_" + b for a in ("baseline", "variant") for b in ("production", "independent")}
        self.need(len(audits["checks"]) == 4
                  and {c["name"] for c in audits["checks"]} == expected_names, "four fresh judges required")
        verdicts = {}
        judged_graphs = {}
        for check in audits["checks"]:
            self.need(check["process_complete"], "judge process incomplete")
            receipt = self.process(check["process"], stages[0]["utc"], stages[1]["utc"])
            self.need(receipt["limits"]["wall_seconds"] == self.plan["limits"]["checker_wall_seconds"][
                "production" if "production" in check["name"] else "independent"], "judge wall bound differs")
            output = self.pinned_load(check["output"])
            self.need(Path(check["output"]["path"]).is_relative_to(pair_dir),
                      "judge output outside fresh episode", "freshness")
            if "production" in check["name"]:
                self.need(output["status"] == "COMPLETE_DERIVED_ORIGINAL_CERTIFICATE",
                          "production certificate incomplete")
                direct = {"strict": output["derived_fairness"]["strict_liveness"]["pass"],
                          "cooperative": output["derived_fairness"]["nonconflicting"]["pass"],
                          "original_states": output["original_view_mapping"]["states"],
                          "original_edges": output["original_view_mapping"]["edges"]}
                judged_graphs[check["name"]] = output["native_graph"]["sha256"]
                folder = "native" if check["name"].startswith("baseline") else "variant"
                self.need(output["native_result_sha256"] == pin(pair_dir / folder / "result.json")["sha256"],
                          "production judge bound to another native result", "judge_binding")
            else:
                self.need(output["status"] == "COMPLETE_INDEPENDENT_RAW_GRAPH_AUDIT",
                          "independent graph certificate incomplete")
                direct = {"strict": output["independent_strict"],
                          "cooperative": output["independent_cooperative"],
                          "original_states": output["original_view"]["states"],
                          "original_edges": output["original_view"]["edges"]}
                for ref in output["input_bindings"].values():
                    self.check_pin(ref)
                self.check_pin(output["input_manifest_pin"])
                self.need(output["input_bindings"]["source"] == self.plan["new_contract"]["source"]
                          and output["source_correspondence"]["thetaE_thetaS_rhoE_rhoS_full_original_domain"]
                          and output["native_returned_graph"]["safety"],
                          "independent judge lacks source/safety binding", "judge_binding")
                judged_graphs[check["name"]] = output["input_bindings"]["controller"]["sha256"]
            self.need(all(check[k] == v for k, v in direct.items()),
                      "summary differs from judge result", "judge_binding")
            label = check["name"].split("_", 1)[0]
            self.need(audits[label] == direct, "judges disagree with arm summary", "judge_binding")
            verdicts[label] = direct
        self.graphs = {}
        for name, folder, label in POOL:
            native_result = self.load(pair_dir / folder / "result.json")
            self.need(native_result["status"] == "JOB_CONTROLLER_PRINTED"
                      and native_result["teardown"] == "COMPLETED", "native export incomplete")
            self.need(native_result["native_solver_calls"] == 1
                      and native_result["controller_extraction_calls"] == 1
                      and native_result["paired_process_total_controller_extractions"] == 2,
                      "pair counts differ")
            self.need(native_result["controller_before_print_sha256"] ==
                      native_result["controller_after_print_sha256"], "printing changed graph")
            ref = native_result["controller_export"]
            graph_pin = pin(pair_dir / folder / ref["file"])
            self.need(graph_pin["bytes"] == ref["bytes"] and graph_pin["sha256"] == ref["sha256"],
                      "graph export binding differs", "judge_binding")
            self.need(judged_graphs[label + "_production"] == graph_pin["sha256"]
                      and judged_graphs[label + "_independent"] == graph_pin["sha256"],
                      "the two judges did not check this installed graph", "judge_binding")
            graph = self.load(graph_pin["path"])
            self.need(graph["complete"] is True, "incomplete native graph")
            nodes = {n["id"]: n for n in graph["nodes"]}
            self.need(len(nodes) == len(graph["nodes"]), "duplicate native node ids")
            edges = {tuple(e) for e in graph["edges"]}
            self.need(edges == {(n["id"], t) for n in nodes.values() for t in n["successors"]},
                      "native edge roster differs from adjacency")
            self.graphs[name] = {"pin": graph_pin, "nodes": nodes, "edges": edges,
                                 "verdict": verdicts[label]}
        self.audit_pin = pin(audits_path)
        self.report["fresh_candidate_verdicts"] = verdicts

    def replay(self):
        previous = {}
        maintained = {arm: [] for arm in ARMS}
        common = {arm: [] for arm in ARMS}
        tail = {arm: [] for arm in ARMS}
        decisions = {arm: [] for arm in ARMS}
        installations = {}
        changes = {}
        trajectory = {arm: [] for arm in ARMS}
        counter_steps = []
        accepted_steps = 0
        rejected_steps = 0
        runtime_events = {"boot", "step_committed", "environment_changed_and_paused",
                          "controller_installed", "resumed", "no_legal_original_ENV_continuation",
                          "executed_fair_lasso", "counterfactual_resumed_without_controller_change",
                          "response_rejected"}
        for event in self.events:
            kind = event["event"]
            if kind == "candidate_admission":
                arm = event["arm"]
                self.need(arm in ARMS, "unexpected admission arm")
                self.need(event["seq"] > self.generation_end["seq"], "admission before judges", "timeline")
                index = len(decisions[arm])
                self.need(index < len(POOL), "extra admission")
                name, _, _ = POOL[index]
                verdict = self.graphs[name]["verdict"]
                admit = verdict["strict"] and (arm == "strict_only" or verdict["cooperative"])
                expected = {"candidate": name, "strict": verdict["strict"],
                            "cooperative": verdict["cooperative"], "admit": admit}
                self.need(event["decision"] == expected, "admission predicate/order differs", "selection")
                self.need(not any(d["admit"] for d in decisions[arm]), "candidate visited after acceptance")
                decisions[arm].append(expected)
                continue
            if kind in ("candidate_generation_started", "candidate_generation_and_audits_completed"):
                field = "frozen_boundaries" if kind.endswith("started") else "unchanged_paused_boundaries"
                self.need(event[field] == [previous[a] for a in ARMS],
                          "generation boundary snapshot differs", "handoff")
                self.need(all(previous[a]["paused"] and previous[a]["ticks"] == 4 for a in ARMS),
                          "generation ran outside paused boundary", "handoff")
            if kind not in runtime_events:
                self.need("runtime" not in event, "unrecognized runtime event")
                continue
            snap = event["runtime"]
            arm = snap["arm"]
            self.need(arm in (*ARMS, COUNTERFACTUAL), "unexpected runtime arm")
            self.source(snap["source_state"])
            if kind == "boot":
                self.need(arm not in previous and snap["source_state"] in self.initial_states,
                          "invalid boot state", "runtime_continuity")
                self.need(snap["source_state"]["c"] == "false"
                          and snap["contract_mode"] == "maintenance" and snap["epoch"] == 0
                          and not snap["paused"] and snap["ticks"] == 0
                          and snap["installed_controller"] == OLD_NAME and snap["native_node_id"] is None,
                          "invalid boot metadata", "runtime_continuity")
                if arm == COUNTERFACTUAL:
                    self.need(snap["source_state"] == changes[ARMS[0]]["source_state"],
                              "counterfactual boundary differs")
                previous[arm] = snap
                continue
            self.need(arm in previous, "runtime event before boot")
            prev = previous[arm]
            self.need(snap["plant_identity"] == prev["plant_identity"]
                      and snap["state_object_identity"] == prev["state_object_identity"],
                      "plant or state object identity changed", "runtime_continuity")
            if "before" in event:
                self.need(event["before"] == prev, "before snapshot breaks continuity", "runtime_continuity")
            if kind in ("step_committed", "response_rejected"):
                self.need(not prev["paused"], "step while paused", "runtime_continuity")
                env = event["offered_env"]
                self.need(env in self.env_inputs and self.env_legal(
                    prev["source_state"], env, prev["contract_mode"] == "maintenance"),
                    "offered input illegal for this actual arm state", "source_ENV")
                target = snap["source_state"] if kind == "step_committed" else event["proposed_state"]
                self.source(target)
                self.need({k: target[k] for k in self.C.env} == env, "target ENV differs from input")
                safe = self.C.rho_s(prev["source_state"], target)
                if kind == "step_committed":
                    self.need(safe, "committed source SYS violation", "source_SYS")
                    self.need({k: v for k, v in snap.items() if k not in ("source_state", "ticks", "native_node_id")}
                              == {k: v for k, v in prev.items() if k not in ("source_state", "ticks", "native_node_id")}
                              and snap["ticks"] == prev["ticks"] + 1, "invalid committed metadata",
                              "runtime_continuity")
                    if prev["installed_controller"] == OLD_NAME:
                        self.need(self.stationary_successor(prev["source_state"], env) == [target]
                                  and snap["native_node_id"] is None, "stationary output mismatch", "old_graph")
                    else:
                        graph = self.graphs[prev["installed_controller"]]
                        source_node = graph["nodes"][prev["native_node_id"]]
                        target_node = graph["nodes"][snap["native_node_id"]]
                        self.need(self.project(source_node) == prev["source_state"]
                                  and self.project(target_node) == target,
                                  "source valuation differs from native private node", "native_edges")
                        self.need(source_node["valuation"]["~envHelp"] == "false"
                                  and target_node["valuation"]["~envHelp"] == "false"
                                  and (source_node["id"], target_node["id"]) in graph["edges"],
                                  "not an actual original-view native edge", "native_edges")
                        responses = [graph["nodes"][node] for node in source_node["successors"]
                                     if graph["nodes"][node]["valuation"]["~envHelp"] == "false"
                                     and all(graph["nodes"][node]["valuation"][k] == env[k] for k in self.C.env)]
                        self.need(len(responses) == 1 and responses[0]["id"] == target_node["id"],
                                  "native response not uniquely determined", "native_edges")
                    accepted_steps += 1
                else:
                    self.need(arm == COUNTERFACTUAL and not safe and snap == prev,
                              "invalid rejection or rejection changed runtime", "source_SYS")
                    self.need(event["reason"] == "source_SYS_transition_violated"
                              and prev["installed_controller"] == OLD_NAME, "rejection reason differs")
                    self.need(tuple(target[k] for k in self.C.system) == ("true", "false", "false")
                              and all(self.module.response_update(
                                  prev["source_state"], target, monitor,
                                  prev["source_state"][button] == "true",
                                  prev["source_state"][floor] == "true"
                                  or prev["source_state"]["c"] == "true")
                                  for (monitor, _), button, floor in
                                  zip(self.C.aux, self.C.env[:3], self.C.system)),
                              "counterfactual proposal not stationary with correct AUX")
                    rejected_steps += 1
                phase = event["phase"]
                if phase == "maintenance":
                    self.need(arm in ARMS and prev["contract_mode"] == "maintenance", "bad maintenance phase")
                    maintained[arm].append(env)
                elif phase == "common_post_switch_script":
                    self.need(arm in installations and prev["contract_mode"] == "normal",
                              "common script before installation", "timeline")
                    common[arm].append(env)
                    trajectory[arm].append({"seq": event["seq"], "native_node_id": snap["native_node_id"],
                                            "source_state": snap["source_state"]})
                elif phase == "lexicographic_legal_continuation":
                    self.need(arm in ARMS and common[arm] == self.plan["common_post_switch_inputs"],
                              "tail before complete common script")
                    legal = self.legal_inputs(prev["source_state"])
                    self.need(bool(legal) and env == legal[0], "tail choice not least legal ENV", "continuation")
                    if not tail[arm]:
                        tail[arm].append(prev)
                    tail[arm].append(snap)
                else:
                    self.need(phase == "no_adaptation_counterfactual" and arm == COUNTERFACTUAL,
                              "unexpected step phase")
                    counter_steps.append({"env": env, "step_committed": kind == "step_committed"})
            elif kind == "environment_changed_and_paused":
                expected = {**prev, "contract_mode": "normal", "epoch": 1, "paused": True}
                self.need(prev["contract_mode"] == "maintenance" and prev["epoch"] == 0
                          and not prev["paused"] and snap == expected, "change mutated source or invalid epoch",
                          "handoff")
                self.need(arm not in changes, "multiple environment changes")
                changes[arm] = snap
                if arm in ARMS:
                    self.need(prev["ticks"] == 4 and event["seq"] < self.generation_start["seq"],
                              "change not after warmup and before generation", "timeline")
            elif kind == "controller_installed":
                self.need(arm in ARMS and arm not in installations and prev["paused"],
                          "bad installation multiplicity/state")
                self.need(decisions[arm] and decisions[arm][-1]["admit"], "no admitted candidate")
                selected = decisions[arm][-1]["candidate"]
                graph = self.graphs[selected]
                self.need(event["graph"] == graph["pin"], "installed graph differs", "selection")
                self.check_pin(event["graph"])
                self.need(event["evidence"]["ordered_decisions"] == decisions[arm]
                          and event["evidence"]["audit_result"] == self.audit_pin,
                          "installation admission evidence differs", "selection")
                node = event["exact_initial_mapping"]
                self.need(node == graph["nodes"][node["id"]] and node["initial"] and node["rank"] == 0
                          and node["valuation"]["~envHelp"] == "false"
                          and self.project(node) == prev["source_state"], "incompatible initial mapping", "handoff")
                matches = [n for n in graph["nodes"].values() if n["initial"] and n["rank"] == 0
                           and n["valuation"]["~envHelp"] == "false"
                           and self.project(n) == prev["source_state"]]
                self.need(len(matches) == 1, "nonunique handoff mapping", "handoff")
                self.need(snap == {**prev, "installed_controller": selected, "native_node_id": node["id"]},
                          "installation changed source/epoch/ticks", "handoff")
                installations[arm] = snap
                trajectory[arm].append({"seq": event["seq"], "native_node_id": node["id"],
                                        "source_state": snap["source_state"]})
            elif kind in ("resumed", "counterfactual_resumed_without_controller_change"):
                self.need(prev["paused"] and snap == {**prev, "paused": False},
                          "resume mutated state/controller", "handoff")
                self.need((kind == "resumed" and arm in installations)
                          or (kind.startswith("counterfactual") and arm == COUNTERFACTUAL),
                          "invalid resume arm")
            else:
                self.need(snap == prev, "outcome event changed runtime", "runtime_continuity")
        # Update previous once for every runtime event, including no-change events.
            previous[arm] = snap
        self.need(len({s["plant_identity"] for s in previous.values()}) == 3
                  and len({s["state_object_identity"] for s in previous.values()}) == 3,
                  "arms share plant or state object", "runtime_continuity")
        self.need(set(installations) == set(ARMS), "not both controllers installed")
        self.need(changes[ARMS[0]]["source_state"] == changes[ARMS[1]]["source_state"],
                  "arms changed at different source states", "handoff")
        for arm in ARMS:
            expected_warmup = [{**{b: "false" for b in self.C.env[:3]}, "c": c}
                               for c in self.plan["old_ticks_c"]]
            self.need(maintained[arm] == expected_warmup, "warmup inputs differ")
            self.need(common[arm] == self.plan["common_post_switch_inputs"], "common prefix differs")
            self.need(previous[arm] in self.result["final_snapshots"], "final snapshot differs")
            self.need(len(tail[arm]) - 1 <= 32, "continuation bound exceeded")
        self.need(counter_steps == self.result["no_adaptation_counterfactual"]
                  and [s["env"] for s in counter_steps] == self.plan["no_adaptation_counterfactual_inputs"]
                  and [s["step_committed"] for s in counter_steps] == [True, False],
                  "counterfactual result differs")
        self.need(rejected_steps == 1, "unexpected rejection count")
        self.previous, self.tail = previous, tail
        self.report["selection"] = {a: {"decisions": decisions[a],
                                       "selected": installations[a]["installed_controller"],
                                       "initial_native_node": installations[a]["native_node_id"]}
                                    for a in ARMS}
        self.report["common_prefix_trajectories"] = trajectory
        self.report["replayed_steps"] = {"committed": accepted_steps, "rejected_counterfactual": rejected_steps}
        self.report["counterfactual"] = {
            "legal_ENV_inputs": 2, "committed_steps": 1,
            "failure": "The second request requires departure from floor 1; stationary f100 violates the original movement guarantee while the AUX update remains correct."}

    def outcomes(self):
        summary = {}
        for arm in ARMS:
            outcome = self.result["outcomes"][arm]
            if outcome["status"] == "ORIGINAL_ENV_DEADEND":
                self.need(outcome["state"] == self.previous[arm], "deadend state differs", "continuation")
                legal = self.legal_inputs(self.previous[arm]["source_state"])
                self.need(not legal and outcome["all_typed_inputs_checked"] == len(self.env_inputs) == 16,
                          "claimed deadend has a legal original ENV successor", "continuation")
                matching = [e for e in self.by_event.get("no_legal_original_ENV_continuation", [])
                            if e["runtime"]["arm"] == arm]
                self.need(len(matching) == 1, "missing/extra deadend event")
                summary[arm] = {"status": "INDEPENDENTLY_CONFIRMED_ORIGINAL_ENV_DEADEND",
                                "native_node_id": self.previous[arm]["native_node_id"],
                                "typed_ENV_inputs_tested": 16, "legal_ENV_successors": 0}
            elif outcome["status"] == "EXECUTED_FAIR_LASSO":
                states = self.tail[arm]
                self.need(states == outcome["tail_states"] and len(states) >= 2,
                          "lasso states differ from executed tail", "continuation")
                start, end = outcome["cycle_start"], outcome["cycle_end"]
                self.need(0 <= start < end == len(states) - 1, "invalid cycle indexes", "continuation")
                key = lambda s: (s["native_node_id"], tuple(s["source_state"][k] for k in self.C.names))
                self.need(key(states[start]) == key(states[end]), "cycle does not close", "continuation")
                keys = [key(s) for s in states[:-1]]
                self.need(len(keys) == len(set(keys)), "execution did not stop at first repeat", "continuation")
                cycle = states[start:end]
                env_count, sys_count = (len(x) for x in self.C.justice(cycle[0]["source_state"]))
                self.need(env_count == 0 and sys_count == 3, "wrong source justice roster")
                hits = [any(self.C.justice(s["source_state"])[1][i] for s in cycle) for i in range(sys_count)]
                self.need(all(hits), "executed cycle not SYS fair", "continuation")
                recorded_hits = {name: hit for (name, _), hit in zip(self.C.aux, hits)}
                self.need(outcome["SYS_justice_hits"] == recorded_hits
                          and outcome["ENV_justice_count"] == 0, "recorded justice differs", "continuation")
                matching = [e for e in self.by_event.get("executed_fair_lasso", [])
                            if e["runtime"]["arm"] == arm]
                self.need(len(matching) == 1 and matching[0]["cycle_start"] == start
                          and matching[0]["cycle_end"] == end, "lasso event differs")
                summary[arm] = {"status": "INDEPENDENTLY_CONFIRMED_EXECUTED_FAIR_LASSO",
                                "tail_transitions": len(states) - 1, "cycle_start": start,
                                "cycle_end": end, "cycle_length": end - start,
                                "cycle_native_node_ids": [s["native_node_id"] for s in cycle],
                                "SYS_justice_hits": recorded_hits, "ENV_justice_count": 0}
            else:
                raise AssertionError("Bounded or incomplete continuation is not success: " + outcome["status"])
        self.need({a: self.result["outcomes"][a]["status"] for a in ARMS}
                  == self.events[-1]["outcomes"], "completion summary differs")
        self.report["outcomes"] = summary

    def outer_receipt(self):
        execution = self.load(HERE / "EXECUTION_RECEIPT.json")
        self.need(execution["status"] == "COMPLETE_BOUNDED_EXECUTION"
                  and execution["process_complete"] and execution["input_integrity"] == "PASS",
                  "outer bounded execution incomplete")
        self.need(execution["automatic_retries"] == 0 and execution["full_reset_uses"] == 0,
                  "unexpected retry/reset")
        receipt = self.process(execution["process"])
        self.need(receipt["limits"]["wall_seconds"] == self.plan["limits"]["whole_episode_wall_seconds"]
                  and receipt["limits"]["rss_bytes"] ==
                  self.plan["limits"]["episode_controller_process_group_rss_bytes"],
                  "outer resource limits differ")
        self.need(execution["episode_result"] == pin(HERE / "execution/RESULT.json"),
                  "outer result pin differs", "pins")
        expected_receipts = {str(p.resolve()) for p in
                             (HERE / "native_pair_01").rglob("PROCESS_RECEIPT.json")}
        self.need(execution["inner_process_cleanup_verified"]
                  and len(execution["inner_processes"]) == 5
                  and len(expected_receipts) == 5
                  and {x["receipt"]["path"] for x in execution["inner_processes"]} == expected_receipts
                  and all(x["complete"] for x in execution["inner_processes"]),
                  "outer receipt lacks all five completed inner process groups")
        for inner in execution["inner_processes"]:
            self.check_pin(inner["receipt"])
        execution_inputs = self.load(HERE / "EXECUTION_INPUTS.json")
        for ref in execution_inputs["inputs"]:
            self.check_pin(ref)
        self.report["resource_evidence"] = {
            "outer_owned_group_rss_cap_bytes": receipt["limits"]["rss_bytes"],
            "serial_native_or_checker_owned_group_rss_cap_bytes": self.plan["limits"]["pair_rss_bytes"],
            "all_inspected_owned_groups_absent": True,
            "aggregate_tree_RSS_measured": False
        }

    def run(self):
        self.setup()
        self.old_controller()
        self.candidates()
        self.replay()
        self.outcomes()
        self.outer_receipt()
        for ref in list(self.read_pins.values()):
            self.need(pin(ref["path"]) == ref, "input changed during independent audit", "pins")
        self.report["status"] = "PASS_CONSTRUCTED_EXECUTABLE_ADAPTATION_EPISODE"


def main():
    output = Path(sys.argv[2]) if len(sys.argv) == 3 else HERE / "independent/AUDIT_RESULT.json"
    output = output.resolve()
    if not output.is_relative_to(HERE / "independent"):
        raise ValueError("Report must be under the independent/ directory")
    if output.exists():
        raise FileExistsError(output)
    output.parent.mkdir(exist_ok=True)
    auditor = Audit()
    try:
        auditor.run()
    except BaseException as exc:
        auditor.report["status"] = "FAIL_OR_INCOMPLETE_INDEPENDENT_EPISODE_AUDIT"
        auditor.report["errors"].append(type(exc).__name__ + ": " + str(exc))
    auditor.report["checks"] = dict(auditor.counts)
    auditor.report["inputs"] = list(auditor.read_pins.values())
    auditor.report["checker"] = pin(Path(__file__))
    auditor.report["finished_utc"] = datetime.now(timezone.utc).isoformat()
    with output.open("x") as f:
        json.dump(auditor.report, f, indent=2)
        f.write("\n")
    print(json.dumps({"status": auditor.report["status"], "errors": auditor.report["errors"],
                      "report": pin(output), "checks": auditor.report["checks"]}))
    return 0 if auditor.report["status"].startswith("PASS_") else 1


if __name__ == "__main__":
    raise SystemExit(main())
