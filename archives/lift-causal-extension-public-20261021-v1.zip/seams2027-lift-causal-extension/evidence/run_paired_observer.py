"""Run the native and observed extractor on one unchanged model/memory pair."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("paired_baseline", ROOT / "run_baseline.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
h = base.helpers


def main():
    assert sys.argv[1:] == ["execute"]
    config = h.read(base.CONFIG)["execution"]
    row = next(x for x in config["candidates"] if x["id"] == "lift__trivial_1")
    baseline = ROOT / "runs/baseline_01/native"
    inputs = h.read(ROOT / "runs/baseline_01/INPUTS.json")["inputs"]
    inputs += h.read(ROOT / "COMPILE_RECEIPT.json")["sources"]
    inputs += h.read(ROOT / "COMPILE_RECEIPT.json")["classes"]
    inputs += [h.pin(Path(__file__)), h.pin(ROOT / "COMPILE_RECEIPT.json")]
    inputs += [h.pin(x) for x in sorted(baseline.iterdir())
               if x.suffix == ".bdd" or x.name in ["model.json", "controller.json", "controller.txt"]]
    h.verify(inputs)
    run = ROOT / "runs/paired_observer_01"
    run.mkdir(exist_ok=False)
    native = run / "native"
    deadline = datetime.now(timezone.utc) + timedelta(seconds=60)
    cmd = h.native_command(config, row, native)
    cmd[4] = str(ROOT / "classes") + ":" + cmd[4]
    cmd[5] = "PairedLiftDiagnostic"
    cmd[1:1] = [
        "-Dlift.trace.path=" + str(native / "observer_trace.json"),
        "-Dlift.trace.nodeIds=0,10,339,438,668,704,706,680,708",
        "-Dlift.trace.maxEvents=20000", "-Dlift.trace.maxBddRefs=40000"]
    h.save_new(run / "INPUTS.json", {
        "inputs": inputs, "command": cmd, "deadline_utc": deadline.isoformat(),
        "wall_seconds": 30, "rss_bytes": 1073741824, "stream_bytes": 268435456,
        "output_tree_bytes": 536870912, "same_JVM_same_model_same_memory": True,
        "order": ["unmodified native extraction and printer", "observed extraction",
                  "complete graph and BDD equality checks", "memory export"],
        "automatic_retries": 0})
    result = {"status": "RUNNING", "errors": []}
    try:
        p = h.load_stage().run_bounded(
            cmd, native, deadline.isoformat(), wall_seconds=30, rss_bytes=1073741824,
            stream_bytes=268435456, file_bytes=16777216,
            watch_files=[native / x for x in ["result.json", "observer_trace.json",
                                             "controller.json", "observer_controller.json"]],
            output_tree=run, output_tree_bytes=536870912,
            aggregate_tree=run, aggregate_tree_bytes=536870912, min_free_bytes=1073741824)
        result["process"] = h.pin(native / "PROCESS_RECEIPT.json")
        assert h.valid_process(p), "Paired process did not complete"
        native_result = h.read(native / "result.json")
        h.validate_native(native_result, config, row)
        parity = {}
        for old in sorted(baseline.iterdir()):
            if old.suffix == ".bdd" or old.name in ["model.json", "controller.txt"]:
                parity[old.name] = h.pin(old)["sha256"] == h.pin(native / old.name)["sha256"]
        old_graph = h.read(baseline / "controller.json")
        new_graph = h.read(native / "controller.json")
        for graph in [old_graph, new_graph]:
            for key in ["controller_identity", "native_memory_identity"]:
                graph.pop(key)
        parity["native_complete_graph_excluding_object_identities"] = old_graph == new_graph
        result["baseline_parity"] = parity
        assert all(parity.values()), "Primary native run differs from fresh baseline"
        diag = h.read(native / "paired_observer.json")
        result["paired_observer"] = h.pin(native / "paired_observer.json")
        for key in ["graph_parity_excluding_only_controller_object_identity",
                    "memory_and_model_all_BDDs_equal", "variable_order_unchanged"]:
            assert diag[key] is True, key
        trace = h.read(native / "observer_trace.json")
        result["trace"] = h.pin(native / "observer_trace.json")
        result["trace_event_count"] = len(trace["events"])
        result["trace_complete"] = trace["complete_for_seen_focused_nodes"]
        result["missing_focus_nodes"] = trace["missing_focused_node_ids"]
        assert result["trace_complete"] and not result["missing_focus_nodes"], "Incomplete focused trace"
        result["status"] = "COMPLETE_PAIRED_OBSERVER_ALL_PARITY_PASS"
    except BaseException as exc:
        result["status"] = "UNKNOWN_OR_INVALID_OBSERVER_COMPARISON"
        result["errors"].append(type(exc).__name__ + ": " + str(exc))
    finally:
        try:
            h.verify(inputs)
            result["input_integrity"] = "PASS"
        except BaseException as exc:
            result["input_integrity"] = "FAIL"
            result["status"] = "UNKNOWN_INPUT_MUTATION"
            result["errors"].append(str(exc))
        result["finished_utc"] = datetime.now(timezone.utc).isoformat()
        h.save_new(run / "RESULT.json", result)
        print(json.dumps(result))


if __name__ == "__main__":
    main()
