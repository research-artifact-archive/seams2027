"""One-shot bounded execution; preserve every failure and incomplete output."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import importlib.util
import json
import sys

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("episode_base", HERE.parent / "run_baseline.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
h = base.helpers
assert not (HERE / "execution").exists()
assert not (HERE / "process").exists()
refs = [h.pin(HERE / name) for name in (
    "PLAN.json", "run_episode.py", "launch_bounded.py",
    "run_intervention_pair.py", "run_pair_audits.py",
    "lift_maintenance.spectra", "INDEPENDENT_REVIEW_PROTOCOL.json")]
plan = h.read(HERE / "PLAN.json")
refs.append(plan["new_contract"]["source"])
h.verify(refs)
h.save_new(HERE / "EXECUTION_INPUTS.json", {
    "inputs": refs, "automatic_retries": 0, "full_reset_uses": 0,
    "execution_limits": plan["limits"]})
deadline = datetime.now(timezone.utc) + timedelta(seconds=620)
process = h.load_stage().run_bounded(
    [sys.executable, "-I", "-S", "-B", str(HERE / "run_episode.py")],
    HERE / "process", deadline.isoformat(), wall_seconds=600,
    rss_bytes=2147483648, stream_bytes=8388608, file_bytes=1073741824,
    watch_files=[HERE / "execution/RESULT.json", HERE / "execution/EVENTS.jsonl"],
    output_tree=HERE, output_tree_bytes=1073741824,
    aggregate_tree=HERE, aggregate_tree_bytes=1073741824,
    min_free_bytes=1073741824)
result = {"process_complete": h.valid_process(process),
          "process": h.pin(HERE / "process/PROCESS_RECEIPT.json"),
          "automatic_retries": 0, "full_reset_uses": 0}
try:
    h.verify(refs)
    result["input_integrity"] = "PASS"
except Exception as exc:
    result["input_integrity"] = "FAIL"
    result["error"] = str(exc)
if (HERE / "execution/RESULT.json").is_file():
    result["episode_result"] = h.pin(HERE / "execution/RESULT.json")
    result["episode_status"] = h.read(HERE / "execution/RESULT.json")["status"]
inner_receipts = sorted((HERE / "native_pair_01").rglob("PROCESS_RECEIPT.json"))
result["inner_processes"] = [
    {"receipt": h.pin(path), "complete": h.valid_process(h.read(path))}
    for path in inner_receipts]
result["inner_process_cleanup_verified"] = (
    len(inner_receipts) == 5 and all(x["complete"] for x in result["inner_processes"]))
result["status"] = (
    "COMPLETE_BOUNDED_EXECUTION" if result["process_complete"]
    and result["input_integrity"] == "PASS"
    and result["inner_process_cleanup_verified"]
    and result.get("episode_status") == "COMPLETE_EXECUTED_EPISODE"
    else "UNKNOWN_OR_INVALID_BOUNDED_EXECUTION")
h.save_new(HERE / "EXECUTION_RECEIPT.json", result)
print(json.dumps(result))
