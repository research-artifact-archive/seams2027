"""Prepare one selection-only intervention and a same-memory paired harness."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent.parent
VARIANT = "final_candidate_original_env_continuation_preference_v1"
RELEASE = WORK / "experiment/seams_establishment_20261013/current_build_preparation/released_sources/tau.smlab.syntech.games.gr1/src/tau/smlab/syntech/games/gr1/GR1ConceteControllerConstructionSkip.java"
source = RELEASE.read_text()
source = source.replace("GR1ConceteControllerConstructionSkip", "GR1ContinuationPreferenceConstruction")
source = source.replace("private GR1StrategyType kind;", """private GR1StrategyType kind;
    private BDD continuationPreference;
    private long refinedCandidates, noPreferredCandidate, examinedCandidates;
    public long getRefinedCandidates() { return refinedCandidates; }
    public long getNoPreferredCandidate() { return noPreferredCandidate; }
    public long getExaminedCandidates() { return examinedCandidates; }
    public BDD getContinuationPreference() { return continuationPreference; }
    private void initializeContinuationPreference() {
      BDD relation = env.trans().id();
      BDD helperFalse = Env.getBDDValue("~envHelp", "false");
      if (helperFalse != null) {
        relation.andWith(helperFalse.id());
        relation.andWith(Env.prime(helperFalse));
      }
      for (tau.smlab.syntech.jtlv.env.module.ModuleBDDField f : env.getAllFields())
        relation.andWith(f.other().getDomain().domain());
      continuationPreference = relation.exist(env.modulePrimeVars());
      relation.free();
      // Helper-true histories are kept unchanged. Only helper-false choices
      // are tested for an original-contract legal environment continuation.
      if (helperFalse != null) continuationPreference.orWith(helperFalse.not());
    }
""", 1)
marker = "int strategy_kind = ((GR1StrategyType) kind).old_value();"
assert source.count(marker) == 1
source = source.replace(marker, marker + "\n        initializeContinuationPreference();")
marker = "BDD one_cand = CoreUtil.satOne(candidate, envUnprimedVars.union(sysUnprimedVars));"
assert source.count(marker) == 1
source = source.replace(marker, """// Single behavioral intervention: prefer a candidate that leaves an
                // original legal environment step, if one survives all native rules.
                examinedCandidates++;
                BDD preferred = candidate.and(continuationPreference);
                if (!preferred.isZero()) {
                  if (!preferred.equals(candidate)) refinedCandidates++;
                  candidate.free();
                  candidate = preferred;
                } else {
                  noPreferredCandidate++;
                  preferred.free();
                }
                """ + marker)
src = ROOT / "src_variant"
extractor_path = src / "tau/smlab/syntech/games/gr1/GR1ContinuationPreferenceConstruction.java"
extractor_path.parent.mkdir(parents=True, exist_ok=True)
assert not extractor_path.exists()
extractor_path.write_text(source)

harness = (ROOT / "src/PairedLiftDiagnostic.java").read_text()
harness = harness.replace("PairedLiftDiagnostic", "PairedContinuationDiagnostic")
harness = harness.replace("  static Path receipt;", "  static Path receipt;\n  static Map<String,Object> pendingVariantOutcome;\n  static Path pendingVariantPath;", 1)
start = harness.index("  static void pairedDiagnostics(")
harness = harness[:start] + r'''
  static void pairedDiagnostics(GR1Memory mem,GameModel gm,EnumStrategyI nativeController)throws Exception {
    final String variantName="final_candidate_original_env_continuation_preference_v1";
    checkpoint("PAIRED_SELECTION_INTERVENTION_SAME_MEMORY_AND_MODEL");
    Map<String,BDD> before=captureMemoryAndModel(mem,gm);
    List<Integer> order=variableOrder(mem.getWin());
    GR1ContinuationPreferenceConstruction extractor=new GR1ContinuationPreferenceConstruction(mem,gm);
    EnumStrategyI changed=extractor.calculateConcreteController();
    Map<String,BDD> after=captureMemoryAndModel(mem,gm);
    Map<String,Object> checks=new LinkedHashMap<>();
    boolean memoryParity=before.keySet().equals(after.keySet());
    for(String name:before.keySet()) {
      boolean same=after.containsKey(name)&&before.get(name).equals(after.get(name));
      checks.put(name,same);memoryParity &= same;
    }
    boolean orderParity=order.equals(variableOrder(mem.getWin()));
    require(memoryParity&&orderParity,"Intervention mutated memory/model/order");
    Path nativeReceipt=receipt, nativeDir=receipt.getParent();
    Path variantDir=nativeDir.getParent().resolve("variant");Files.createDirectory(variantDir);
    try(java.nio.file.DirectoryStream<Path> files=Files.newDirectoryStream(nativeDir)) {
      for(Path file:files)if(file.getFileName().toString().endsWith(".bdd")||file.getFileName().toString().equals("model.json"))
        Files.copy(file,variantDir.resolve(file.getFileName()));
    }
    Map<String,Object> nativeOut=new LinkedHashMap<>(out);
    Map<String,Object> configuration=new LinkedHashMap<>((Map<String,Object>)out.get("configuration"));
    configuration.put("extractor_strategy","experimental:"+variantName);
    out.put("configuration",configuration);
    out.put("schema","experimental-extractor-native-result-v1");
    out.put("pipeline","released_syntactic_4fp_experimental_extractor");
    out.put("nonrelease_extractor",true);
    out.put("variant_name",variantName);
    out.put("extractor_variant",variantName);
    out.put("experimental_extractor_class_identity",identity(extractor.getClass()));
    out.put("experimental_class_identities",Arrays.asList(identity(extractor.getClass())));
    out.put("paired_process_total_controller_extractions",2);
    out.put("counts_scope","This variant arm; same process also performed one unchanged baseline extraction.");
    out.put("baseline_controller_pin",filePin(nativeDir.resolve("controller.json")));
    receipt=variantDir.resolve("result.json");
    Map<String,Object> graph=controllerSnapshot(changed,gm);
    graph.put("schema","experimental-extractor-complete-controller-v1");
    graph.put("nonrelease_extractor",true);
    graph.put("variant_name",variantName);
    graph.put("extractor_variant",variantName);
    graph.put("helper_policy","complete_experimental_graph_with_native_helper");
    String beforeJSON=json(graph);
    out.put("controller_before_print_sha256",sha(beforeJSON.getBytes(StandardCharsets.UTF_8)));
    Path printer=variantDir.resolve("controller.txt");
    try(PrintStream stream=new PrintStream(Files.newOutputStream(printer),false,StandardCharsets.UTF_8)){
      new SimpleTextPrinter().printController(stream,changed);
      if(stream.checkError())throw new IOException("Variant printer output stream error");
    }
    Map<String,Object> graphAfter=controllerSnapshot(changed,gm);
    graphAfter.put("schema","experimental-extractor-complete-controller-v1");
    graphAfter.put("nonrelease_extractor",true);graphAfter.put("variant_name",variantName);
    graphAfter.put("extractor_variant",variantName);
    graphAfter.put("helper_policy","complete_experimental_graph_with_native_helper");
    String afterJSON=json(graphAfter);
    require(beforeJSON.equals(afterJSON),"Variant printer mutated graph");
    out.put("controller_after_print_sha256",sha(afterJSON.getBytes(StandardCharsets.UTF_8)));
    out.put("controller_export",writeJson("controller.json",graphAfter));
    out.put("printed_controller",filePin(printer));
    out.put("selection_preference",snapshot("selection_preference",extractor.getContinuationPreference()));
    Map<String,Object> diagnostic=m("variant_name",variantName,"nonrelease_extractor",true,
      "intervention","conditional preference immediately before transition satOne only",
      "same_memory_object",true,"same_model_object",true,
      "memory_and_model_all_BDDs_equal",memoryParity,"BDD_equality_checks",checks,
      "variable_order_unchanged",orderParity,"bdd_variable_order",order,
      "experimental_extractor_class",identity(extractor.getClass()),
      "examined_candidates",extractor.getExaminedCandidates(),
      "refined_candidates",extractor.getRefinedCandidates(),
      "no_preferred_candidate_fallbacks",extractor.getNoPreferredCandidate(),
      "native_graph_states",nativeController.numOfStates(),"native_graph_edges",nativeController.numOfTransitions(),
      "variant_graph_states",changed.numOfStates(),"variant_graph_edges",changed.numOfTransitions(),
      "claim_scope","Instance-directed choice intervention; one-step continuation preference is not a general fair-continuation proof.");
    out.put("paired_intervention",writeJson("paired_intervention.json",diagnostic));
    out.put("status","JOB_CONTROLLER_PRINTED");
    // Shared teardown follows once both records are complete. Parent verifies
    // the primary final receipt before accepting this variant's paired binding.
    out.put("teardown","SHARED_TEARDOWN_PENDING");
    checkpoint("VARIANT_EXPORTED_AWAITING_SHARED_TEARDOWN");
    Path pendingVariantReceipt=receipt;
    pendingVariantPath=receipt;pendingVariantOutcome=new LinkedHashMap<>(out);
    receipt=nativeReceipt;out.clear();out.putAll(nativeOut);
    out.put("paired_intervention_result",pendingVariantReceipt.toString());
    out.put("paired_process_total_controller_extractions",2);
    out.put("counts_scope","This baseline arm; same process also performed one experimental extraction.");
    for(BDD b:before.values())b.free();for(BDD b:after.values())b.free();
  }
}
'''
# The original finally block owns the one shared model/game teardown. Mirror
# its observed result into the variant receipt only after that teardown.
marker = 'checkpoint("PROCESS_FINISHED");}System.exit(exit);'
assert harness.count(marker) == 1
harness = harness.replace(marker, '''checkpoint("PROCESS_FINISHED");
      Object variantReceipt=out.get("paired_intervention_result");
      if(variantReceipt!=null) {
        // Finish the actual variant result only after the one shared teardown.
        pendingVariantOutcome.put("teardown",out.get("teardown"));
        pendingVariantOutcome.put("stage","PROCESS_FINISHED");
        pendingVariantOutcome.put("shared_teardown_primary_result",filePin(receipt));
        if(exit!=0)pendingVariantOutcome.put("status","UNKNOWN_SHARED_PROCESS_FAILURE");
        Files.writeString(pendingVariantPath,json(pendingVariantOutcome)+"\\n",StandardCharsets.UTF_8);
        Path shared=Paths.get(String.valueOf(variantReceipt)).getParent().resolve("SHARED_TEARDOWN.json");
        Files.writeString(shared,json(m("teardown",out.get("teardown"),"primary_result",filePin(receipt),
          "paired_process_total_controller_extractions",2,"process_exit_code",exit))+"\\n",StandardCharsets.UTF_8);
      }
    }System.exit(exit);''')
harness_path = src / "PairedContinuationDiagnostic.java"
assert not harness_path.exists()
harness_path.write_text(harness)

def pin(p):
    return {"path": str(p.resolve()), "bytes": p.stat().st_size,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}

plan = {
    "declared_utc": datetime.now(timezone.utc).isoformat(),
    "variant_name": VARIANT,
    "status": "PREPARED_NOT_EXECUTED",
    "trigger_evidence": pin(ROOT / "runs/paired_observer_02/native/observer_trace.json"),
    "baseline_parity_evidence": pin(ROOT / "runs/paired_observer_02/RESULT.json"),
    "behavioral_change": "At final transition satOne, intersect the candidate with original ENV one-step continuation states when that intersection is nonempty; retain candidate otherwise. Helper-true histories are unchanged.",
    "predicate": "exists typed next ENV: transformed rhoE with h=false,h'=false; disjoin current h=true. Without helper, use original ENV trans and typed next ENV directly.",
    "model_core_memory_changes": False,
    "initial_selection_changes": False,
    "expected_observation": "Prevent the first bad node creations while preserving a native candidate/rank; later reuse of those bad nodes may disappear.",
    "rejection_conditions": ["model/memory/order mutation", "incomplete process or graph", "failed original-contract strictness", "remaining original-contract noncooperation"],
    "limits": {"native_pair_wall_seconds": 30, "rss_bytes": 1073741824,
               "stream_bytes": 536870912, "case_output_bytes": 805306368},
    "scope": "Instance intervention, not a general synthesis correction. Complete graph and six prespecified success controls must be checked.",
    "source_baseline": pin(RELEASE),
    "new_sources": [pin(extractor_path), pin(harness_path)],
}
(ROOT / "INTERVENTION_PLAN.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"variant": VARIANT, "sources": [str(extractor_path), str(harness_path)]}))
