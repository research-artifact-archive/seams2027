"""Independent audit of fixed source contracts and complete native job outputs.

No production checker or certificate is imported/read. Real input evaluation
requires a separately frozen input manifest, bounded launcher, and Root GO.
Importing this module performs no input reads or source/DAG/graph evaluation.
"""
from pathlib import Path
from itertools import product
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import sys
import traceback

# Metadata-only experimental adapter. Source, DAG and graph algorithms below are unchanged.
_meta_spec = importlib.util.spec_from_file_location(
    'variant_metadata', Path(__file__).resolve().parent.parent / 'variant_metadata.py')
_variant_metadata = importlib.util.module_from_spec(_meta_spec)
_meta_spec.loader.exec_module(_variant_metadata)

# Isolated (-I -S) Python intentionally omits the script directory. Load only
# these two explicit sibling files; the launcher pins both as runtime inputs.
for _name in ('independent_core', 'source_contracts'):
    _spec = importlib.util.spec_from_file_location(_name, Path(__file__).resolve().with_name(_name + '.py'))
    _module = importlib.util.module_from_spec(_spec)
    sys.modules[_name] = _module
    _spec.loader.exec_module(_module)

from independent_core import (AuditError, need, decode_json, pin, read_pin, save_new,
                              SavedDag, closure, reachable_from, finite_fairness)
from source_contracts import CONTRACTS, HELPER, BOOL

MAX_SOURCE_STATES = 1024
MAX_SOURCE_PAIRS = 1_048_576
MAX_NATIVE_STATES = 2048
MAX_GRAPH_NODES = 4096
MAX_GRAPH_EDGES = 65536
MAX_INPUT_CHECKS = 4_000_000
CONFIGURATION = {
    'release': '1.0.0.202402072123', 'BDDPackage': 'JTLV', 'BDDPackageVersion': 'DEFAULT',
    'synthesisMethod': 'synthesisPitermanReduction', 'ConcreteControllerFormat': 'JTLV',
    'optChoice': 'none', 'reorderChoice': 'none', 'groupVars': False, 'TraceInfo': 'NONE',
    'TransFuncType': 'SINGLE_FUNC', 'extractor_strategy': 'native_two_argument_default_ZYX'}


def compile_profile(expression, values, allow_next=True):
    """Whitelist-only expression compiler used solely as an additional cross-check."""
    count = [0]

    def emit(node, depth=0):
        count[0] += 1
        need(count[0] <= 4096 and depth <= 128, 'Profile expression size/depth cap')
        if type(node) is bool:
            return repr(node)
        need(type(node) is list and node and type(node[0]) is str, 'Profile expression shape')
        operator, *args = node
        if operator in ('var', 'eq'):
            need(len(args) == (2 if operator == 'var' else 3), 'Profile field expression arity')
            name, prime = args[0], args[-1]
            need(type(name) is str and name in values and type(prime) is bool, 'Profile known field/timing')
            need(allow_next or not prime, 'Primed initial/justice profile expression')
            value = 'true' if operator == 'var' else args[1]
            need(type(value) is str and value in values[name], 'Profile known field value')
            if operator == 'var':
                need(tuple(values[name]) == BOOL, 'Boolean profile variable domain')
            return f"({'successor' if prime else 'state'}[{name!r}] == {value!r})"
        need(operator in ('not', 'and', 'or', 'implies', 'iff'), 'Unknown profile operator')
        need((operator in ('and', 'or')) or len(args) == (1 if operator == 'not' else 2), 'Profile operator arity')
        parts = [emit(arg, depth + 1) for arg in args]
        if operator == 'not':
            return f'(not {parts[0]})'
        if operator in ('and', 'or'):
            return '(' + (f' {operator} '.join(parts) if parts else repr(operator == 'and')) + ')'
        if operator == 'implies':
            return f'((not {parts[0]}) or {parts[1]})'
        return f'({parts[0]} == {parts[1]})'

    code = 'def expression(state, successor=None):\n    return ' + emit(expression) + '\n'
    namespace = {'__builtins__': {}}
    exec(compile(code, '<independent-profile-crosscheck>', 'exec'), namespace)
    return namespace['expression']


def states_for(names, values, cap):
    total = 1
    for name in names:
        total *= len(values[name])
        need(total <= cap, 'Typed enumeration cap')
    return [dict(zip(names, row)) for row in product(*(values[name] for name in names))]


class ModelAudit:
    """Typed input identity and source correspondence, independently evaluated."""
    def __init__(self, manifest, contract, read, result, model, profile):
        self.manifest, self.contract, self.read = manifest, contract, read
        self.result, self.model, self.profile = result, model, profile
        self.loaded = {}
        if result is None:
            # Separate source-model qualification: no native-job observation is fabricated.
            need(HELPER not in {field['name'] for field in model['fields']}, 'Source-only model must be original/helper-free')
            helper = False
        else:
            helper = result.get('helper_added')
            need(type(helper) is bool, 'Observed native helper flag must be Boolean')
            need(result.get('helper_is_native_nonaux_ENV') is helper, 'Observed helper ENV/nonAUX flag')
        self.helper = helper
        self.env = contract.env + ((HELPER,) if helper else ())
        self.names = contract.env + ((HELPER,) if helper else ()) + contract.system + tuple(n for n, _ in contract.aux)
        self.values = dict(contract.values)
        if helper:
            self.values[HELPER] = BOOL
        need(profile.get('fixture_id') == contract.candidate and profile.get('case_id') == contract.candidate
             and profile.get('variant') == 'initializers', 'Profile original-initializer identity')
        need(profile['source']['bytes'] == contract.source_bytes and profile['source']['sha256'] == contract.source_sha256,
             'Profile exact source pin')
        need(profile['public_ENV'] == list(contract.env) and profile['public_SYS'] == list(contract.system)
             and profile['expected_fields_in_native_order'] == contract.fields, 'Profile source-owned typed field roster')
        need(set(profile['formulas']) == {'thetaE', 'thetaS', 'rhoE', 'rhoS'} and set(profile['justices']) == {'ENV', 'SYS'},
             'Profile complete formula/justice roster')
        self.profile_formulas = {name: compile_profile(expr, contract.values, name.startswith('rho'))
                                 for name, expr in profile['formulas'].items()}
        self.profile_justices = {owner: [compile_profile(expr, contract.values, False) for expr in profile['justices'][owner]]
                                for owner in ('ENV', 'SYS')}
        fields = model['fields']
        need([field['name'] for field in fields] == list(self.names), 'Complete native field order/AUX/helper identity')
        self.field_by_name = {field['name']: field for field in fields}
        self.current, self.next, self.env_current, self.env_next, self.sys_next = set(), set(), set(), set(), set()
        for field in fields:
            name = field['name']
            need(type(field['domain_size']) is int and field['domain_size'] == 2 and tuple(field['values']) == self.values[name],
                 'Exact two-valued typed field domain')
            owner = 'ENV' if name in self.env else 'SYS'
            role = 'ENV' if owner == 'ENV' else 'SYS' if name in contract.system else 'AUX'
            need(field['owner'] == owner and field['role'] == role, 'Native source field owner/AUX role')
            cb, nb = field['current_bits'], field['next_bits']
            need(type(cb) is list and type(nb) is list and len(cb) == len(nb) == 1
                 and all(type(bit) is int and bit >= 0 for bit in cb + nb)
                 and not ((set(cb) | set(nb)) & (self.current | self.next)) and cb != nb,
                 'Disjoint typed current/next field bits')
            self.current.update(cb); self.next.update(nb)
            if owner == 'ENV':
                self.env_current.update(cb); self.env_next.update(nb)
            else:
                self.sys_next.update(nb)
            need(set(field['encoding']) == set(self.values[name]), 'Complete typed encoding roster')
            for timing, bits in [('current', cb), ('next', nb)]:
                encoded = []
                for value in self.values[name]:
                    mapping = field['encoding'][value][timing]
                    need(set(mapping) == {str(bit) for bit in bits} and all(type(v) is bool for v in mapping.values()),
                         'Complete Boolean encoding map')
                    encoded.append(tuple(mapping[str(bit)] for bit in bits))
                need(set(encoded) == {(False,), (True,)}, 'Bijective Boolean/enum encoding')
        for key, expected in [('all_current_bits', self.current), ('all_next_bits', self.next)]:
            declared = model[key]
            need(type(declared) is list and all(type(bit) is int for bit in declared)
                 and len(declared) == len(set(declared)) and set(declared) == expected, 'Complete bit roster: ' + key)
        count, order = model['bdd_variable_count'], model['bdd_variable_order']
        need(type(count) is int and 0 < count <= 64 and self.current | self.next == set(range(count))
             and len(self.current) == len(self.names), 'Complete native bit carrier')
        need(type(order) is list and all(type(bit) is int for bit in order) and len(order) == count
             and set(order) == set(range(count)), 'Native BDD variable permutation')
        parsed = model['source_inventory']['parsed']
        need([x['name'] for x in parsed['ENV']['variables']] == list(contract.env)
             and [x['name'] for x in parsed['SYS']['variables']] == list(contract.system), 'Parsed original public fields')
        self.native_formulas = {name: self.dag(model['original_bdds'][name], allowed) for name, allowed in
                                [('thetaE', self.env_current), ('thetaS', self.current),
                                 ('rhoE', self.current | self.env_next), ('rhoS', self.current | self.next)]}

    def bits(self, state, prime=False):
        answer = {}
        for name, value in state.items():
            need(name in self.field_by_name and value in self.values[name], 'Typed source/native valuation')
            answer.update({int(k): v for k, v in self.field_by_name[name]['encoding'][value]['next' if prime else 'current'].items()})
        return answer

    def native_state(self, original, helper='false'):
        return dict(original, **{HELPER: helper}) if self.helper else dict(original)

    def dag(self, ref, allowed):
        name = ref['file']
        need(type(name) is str and Path(name).name == name and name in self.manifest['bdd_files'], 'Pinned local saved-DAG reference')
        target = self.manifest['bdd_files'][name]
        need(ref['bytes'] == target['bytes'] and ref['sha256'] == target['sha256'], 'Saved DAG/native byte pin')
        if name not in self.loaded:
            self.loaded[name] = SavedDag(read_pin(target), self.model['bdd_variable_count'], self.model['bdd_variable_order'])
        answer = self.loaded[name]
        need(answer.support <= allowed, 'Saved DAG illegal variable support: ' + name)
        return answer

    def verify_source(self):
        c, p, roots = self.contract, self.profile_formulas, self.native_formulas
        original = states_for(c.names, c.values, MAX_SOURCE_STATES)
        full = states_for(self.names, self.values, MAX_NATIVE_STATES)
        need(len(original) ** 2 <= MAX_SOURCE_PAIRS, 'Source state-pair cap')
        cached = [(s, self.bits(self.native_state(s)), self.bits(self.native_state(s), True)) for s in original]
        for s, cb, _ in cached:
            te, ts = c.theta_e(s), c.theta_s(s)
            need(type(te) is bool and type(ts) is bool, 'Source initial predicate Boolean')
            need(roots['thetaE'].value(cb) == te and roots['thetaS'].value(cb) == ts, 'Source/native original initializer mismatch')
            need(p['thetaE'](s) == te and p['thetaS'](s) == ts, 'Profile/source original initializer mismatch')
            for t, _, nb in cached:
                joined = cb | nb
                re, rs = c.rho_e(s, t), c.rho_s(s, t)
                need(type(re) is bool and type(rs) is bool, 'Source transition predicate Boolean')
                need(roots['rhoE'].value(joined) == re and roots['rhoS'].value(joined) == rs, 'Source/native transition mismatch')
                need(p['rhoE'](s, t) == re and p['rhoS'](s, t) == rs, 'Profile/source transition timing mismatch')
        domains = [('domain', self.current, full, False),
                   ('domain_ENV_next', self.env_next, states_for(self.env, self.values, MAX_NATIVE_STATES), True),
                   ('domain_SYS_next', self.sys_next, states_for(c.system + tuple(n for n, _ in c.aux), self.values, MAX_NATIVE_STATES), True)]
        for key, allowed, sample, prime in domains:
            root = self.dag(self.model['original_bdds'][key], allowed)
            need(all(root.value(self.bits(s, prime)) for s in sample), 'Full typed native domain mismatch: ' + key)
        for s in full:
            expected_initial = c.theta_e(s) and (not self.helper or s[HELPER] == 'false')
            need(roots['thetaE'].value(self.bits(s)) == expected_initial,
                 'Full native initial ENV/helper correspondence')
        justices = {owner: [self.dag(ref, self.current) for ref in self.model['original_justices'][owner]] for owner in ('ENV', 'SYS')}
        helper_index = None
        if self.helper:
            matches = [i for i, root in enumerate(justices['ENV'])
                       if all(root.value(self.bits(s)) == (s[HELPER] == 'false') for s in full)]
            need(len(matches) == 1, 'Unique full-domain inserted helper justice')
            helper_index = matches[0]
        source_roots = {'ENV': [root for i, root in enumerate(justices['ENV']) if i != helper_index], 'SYS': justices['SYS']}
        for s, cb, _ in cached:
            expected = c.justice(s)
            need(type(expected) is tuple and len(expected) == 2 and all(type(v) is bool for row in expected for v in row), 'Source justice predicate shape')
            for owner, wanted in zip(('ENV', 'SYS'), expected):
                need([root.value(cb) for root in source_roots[owner]] == wanted, 'Ordered source/native justice mismatch')
                need([expr(s) for expr in self.profile_justices[owner]] == wanted, 'Ordered profile/source justice mismatch')
        padding = {}
        for phase in (() if self.result is None else ('preconstructor_justices', 'solver_justices')):
            padding[phase] = {}
            for owner in ('ENV', 'SYS'):
                phase_roots = [self.dag(ref, self.current) for ref in self.result[phase][owner]]
                expected_count = len(justices[owner])
                allowed_padding = phase == 'solver_justices' and expected_count == 0
                need(len(phase_roots) == (1 if allowed_padding else expected_count), 'Constructor ordered justice/TRUE-padding count')
                for s in full:
                    cb = self.bits(s)
                    expected_values = [root.value(cb) for root in justices[owner]] or ([True] if allowed_padding else [])
                    need([root.value(cb) for root in phase_roots] == expected_values, 'Constructor ordered justice/TRUE-padding semantics')
                padding[phase][owner] = allowed_padding
        self.original, self.full_states, self.source_roots = original, full, source_roots
        self.native_justice_count = {owner: len(justices[owner]) or 1 for owner in ('ENV', 'SYS')}
        input_states = states_for(c.env, c.values, MAX_SOURCE_STATES)
        initial_inputs = [s for s in input_states if c.theta_e(s)]
        return {'source_sha256': c.source_sha256, 'original_typed_states': len(original),
                'native_typed_states': len(full), 'original_state_pairs_checked': len(original) ** 2,
                'mapping': 'helper_false_restriction' if self.helper else 'identity',
                'thetaE_thetaS_rhoE_rhoS_full_original_domain': True,
                'full_native_initial_ENV_correspondence': True,
                'all_typed_native_domain_values_checked': True, 'profile_crosscheck': True,
                'ordered_justice_identity': True, 'helper_justice_index': helper_index,
                'constructor_TRUE_padding': padding if self.result is not None else None,
                'constructor_phases_inspected': self.result is not None,
                'original_initial_ENV_choices': len(initial_inputs),
                'timing_note': c.timing_note}


def verify_process(process):
    need(process['status'] == 'PROCESS_COMPLETED' and process['exit_code'] == 0
         and process['owned_child_reaped'] is True and process['final_group_observation']['state'] == 'ABSENT'
         and not process['fatal_reasons'] and not process['resource_reasons']
         and set(process['capture']) == {'stdout', 'stderr'}
         and all(value['complete'] is True for value in process['capture'].values()), 'Native process incomplete')


def audit_graph(ctx, graph, printed, refs):
    c, r = ctx.contract, ctx.result
    need(graph['schema'] == 'experimental-extractor-complete-controller-v1' and graph['complete'] is True
         and graph['initialization'] == 'source_initializers', 'Complete original-initializer graph')
    # The producer's historical helper_policy label is deliberately not used to infer helper presence.
    need(graph['model_sha256'] == refs['model']['sha256'] and graph['native_memory_identity'] == r['native_memory_identity'],
         'Graph/model/private-memory binding')
    need(r['same_native_memory_passed_to_constructor'] is True and r['same_native_model_passed_to_constructor'] is True
         and r['controller_before_print_sha256'] == r['controller_after_print_sha256'], 'Native extraction/printer identity')
    nodes, flat, by_id = graph['nodes'], [], {}
    need(type(nodes) is list and 0 < len(nodes) <= MAX_GRAPH_NODES and len(nodes) == graph['api_state_count'], 'Native graph node count/cap')
    rank_count = ctx.native_justice_count['SYS']
    need(type(graph['rank_domain_size']) is int and graph['rank_domain_size'] == rank_count, 'Native SYS justice/rank domain')
    lines = printed.splitlines()
    need(len(lines) == 2 * len(nodes), 'Complete native printer line count')
    for i, node in enumerate(nodes):
        identity = str(i)
        need(node['id'] == identity and type(node['native_id']) is int and node['native_id'] == i, 'Ordered raw native ID')
        need(type(node['initial']) is bool and type(node['rank']) is int and 0 <= node['rank'] < rank_count
             and node['rank_class'] == 'tau.smlab.syntech.games.gr1.GR1RankInfo' and type(node['rank_info']) is str,
             'Native rank/private memory encoding')
        state = node['valuation']
        need(type(state) is dict and set(state) == set(ctx.names), 'Complete typed native node valuation')
        expected_bits = ctx.bits(state)
        need(all(type(value) is bool for value in node['bits'].values())
             and {str(k): v for k, v in expected_bits.items()} == node['bits'], 'Native bits/value identity')
        successors = node['successors']
        need(type(successors) is list and all(type(v) is str for v in successors)
             and len(successors) == len(set(successors)), 'Unique native successors')
        prefix = ('Initial State ' if node['initial'] else 'State ') + identity + ' '
        need(lines[2*i].startswith(prefix + '<') and lines[2*i].endswith('>'), 'Printed native initial/ID')
        body = lines[2*i][len(prefix):]
        need(body == node['native_bdd_text'], 'Printed native BDD text identity')
        pairs = [item.split(':') for item in body[1:-1].split(', ')]
        need(all(len(pair) == 2 for pair in pairs) and len(pairs) == len(dict(pairs)) and dict(pairs) == state,
             'Complete printed valuation identity')
        expected_line = '\tWith successors : ' + ', '.join(successors) if successors else '\tWith no successors.'
        need(lines[2*i+1] == expected_line, 'Complete printed ordered successor identity')
        by_id[identity] = node
        flat.extend((identity, successor) for successor in successors)
    need([list(edge) for edge in flat] == graph['edges'] and len(flat) == graph['api_transition_count']
         and len(flat) == len(set(flat)) <= MAX_GRAPH_EDGES and all(b in by_id for _, b in flat), 'Complete raw edge export/cap')
    starts = [node['id'] for node in nodes if node['initial']]
    need(starts and all(by_id[i]['rank'] == 0 and (not ctx.helper or by_id[i]['valuation'][HELPER] == 'false') for i in starts),
         'Original native initial private-memory/helper values')
    need(reachable_from(starts, closure(set(by_id), flat)) == set(by_id), 'Raw native unreachable extra nodes')
    native_inputs = states_for(ctx.env, ctx.values, MAX_NATIVE_STATES)
    original_inputs = states_for(c.env, c.values, MAX_SOURCE_STATES)
    original_initial = {tuple(s[name] for name in c.env) for s in original_inputs if c.theta_e(s)}
    native_initial = {tuple(s[name] for name in ctx.env) for s in native_inputs if ctx.native_formulas['thetaE'].value(ctx.bits(s))}
    actual_initial = {}
    for identity in starts:
        state = by_id[identity]['valuation']; key = tuple(state[name] for name in ctx.env)
        need(key not in actual_initial and ctx.native_formulas['thetaE'].value(ctx.bits(state))
             and ctx.native_formulas['thetaS'].value(ctx.bits(state)) and c.theta_e(state) and c.theta_s(state),
             'Native/source original initializer response')
        actual_initial[key] = identity
    need(set(actual_initial) == native_initial
         and {tuple(by_id[i]['valuation'][name] for name in c.env) for i in starts} == original_initial,
         'Exact original/native initial ENV coverage')
    need(len(by_id) * len(native_inputs) <= MAX_INPUT_CHECKS, 'Native legal-input check cap')
    for node in nodes:
        cb = ctx.bits(node['valuation'])
        expected = {tuple(s[name] for name in ctx.env) for s in native_inputs
                    if ctx.native_formulas['rhoE'].value(cb | ctx.bits(s, True))}
        actual = {}
        for successor_id in node['successors']:
            successor = by_id[successor_id]['valuation']; joined = cb | ctx.bits(successor, True)
            need(ctx.native_formulas['rhoE'].value(joined) and ctx.native_formulas['rhoS'].value(joined), 'Raw native safety')
            key = tuple(successor[name] for name in ctx.env)
            need(key not in actual, 'Raw native input response/private-memory nondeterminism')
            actual[key] = successor_id
        need(set(actual) == expected, 'Raw native complete legal-input coverage')
    permitted = {identity for identity, node in by_id.items() if not ctx.helper or node['valuation'][HELPER] == 'false'}
    permitted_edges = [(a, b) for a, b in flat if a in permitted and b in permitted]
    view_ids = reachable_from(starts, closure(permitted, permitted_edges))
    view_edges = [(a, b) for a, b in permitted_edges if a in view_ids]
    adjacency = {identity: [] for identity in view_ids}
    for a, b in view_edges:
        need(b in view_ids, 'Original view closed under selected edges')
        adjacency[a].append(b)
    need(len(view_ids) * len(original_inputs) <= MAX_INPUT_CHECKS, 'Original legal-input check cap')
    for identity in sorted(view_ids, key=int):
        state = by_id[identity]['valuation']
        expected = {tuple(s[name] for name in c.env) for s in original_inputs if c.rho_e(state, s)}
        actual = {}
        for successor_id in adjacency[identity]:
            successor = by_id[successor_id]['valuation']
            need(c.rho_e(state, successor) and c.rho_s(state, successor), 'Original view safety/AUX timing')
            key = tuple(successor[name] for name in c.env)
            need(key not in actual, 'Original input response/private-memory nondeterminism')
            actual[key] = successor_id
        need(set(actual) == expected, 'Original view complete legal-input coverage')
    sample_justice = c.justice(by_id[starts[0]]['valuation'])
    env_labels, sys_labels = [set() for _ in sample_justice[0]], [set() for _ in sample_justice[1]]
    for identity in view_ids:
        values = c.justice(by_id[identity]['valuation'])
        for labels, truth_values in zip((env_labels, sys_labels), values):
            need(len(labels) == len(truth_values), 'Stable source justice roster')
            for label, holds in zip(labels, truth_values):
                if holds:
                    label.add(identity)
    fairness = finite_fairness(view_ids, view_edges, starts, env_labels, sys_labels)
    view = {'schema': 'independent-source-original-view-v1', 'candidate': c.candidate,
            'mapping': 'helper_false_restriction' if ctx.helper else 'identity',
            'states': sorted(view_ids, key=int), 'starts': starts, 'edges': [list(edge) for edge in view_edges],
            'env_justice': [sorted(label, key=int) for label in env_labels],
            'sys_justice': [sorted(label, key=int) for label in sys_labels],
            'native_nodes': [by_id[i] for i in sorted(view_ids, key=int)]}
    summary = {'native_returned_graph': {'states': len(nodes), 'edges': len(flat), 'initial_states': len(starts),
                                         'all_reachable': True, 'safety': True, 'complete_input_checks': len(nodes) * len(native_inputs)},
               'original_view': {'states': len(view_ids), 'edges': len(view_edges), 'initial_states': len(starts),
                                 'safety': True, 'complete_input_checks': len(view_ids) * len(original_inputs),
                                 'native_IDs_ranks_AUX_preserved': True, 'memory_reset_or_graph_repair': False},
               'fairness': fairness, 'independent_strict': fairness['strict_liveness']['pass'],
               'independent_cooperative': fairness['nonconflicting']['pass']}
    return summary, view


def audit(manifest, contracts=CONTRACTS):
    need(manifest['schema'] == 'experimental-extractor-independent-audit-inputs-v1', 'Input manifest schema')
    candidate = manifest['candidate_id']
    need(candidate in contracts, 'No declared exact source oracle for candidate')
    contract, refs, read_refs = contracts[candidate], manifest['inputs'], []
    need(set(refs) <= {'source', 'profile', 'native_result', 'model', 'native_process', 'controller', 'printer'},
         'Forbidden or unknown logical input (production certificates excluded)')

    def read(name):
        raw = read_pin(refs[name]); read_refs.append(name)
        return raw

    source = read('source')
    need(len(source) == contract.source_bytes and hashlib.sha256(source).hexdigest() == contract.source_sha256, 'Exact declared source contract pin')
    profile = decode_json(read('profile'))['profiles'][candidate]
    result, model, process = decode_json(read('native_result')), decode_json(read('model')), decode_json(read('native_process'))
    verify_process(process)
    for item in (result, model):
        need(item['fixture_id'] == item['case_id'] == candidate and item['variant'] == 'initializers', 'Raw original-initializer identity')
    outcome = result['status']
    need(outcome in ('JOB_UNREALIZABLE_NO_CONTROLLER', 'JOB_EMPTY_MEMORY_NO_CONTROLLER', 'JOB_CONTROLLER_PRINTED')
         and result['teardown'] == 'COMPLETED', 'Incomplete or unsupported native job')
    variant_provenance = _variant_metadata.validate_manifest(manifest, CONFIGURATION)
    need(all(result[key] is False for key in ('initializers_replaced', 'semantic_reduction_used', 'ENV_justice_normalization_used')), 'Changed native semantics')
    need(result['input_sha256'] == model['input']['sha256'] == contract.source_sha256
         and model['input']['bytes'] == contract.source_bytes and model['schema'] == 'k7-native-model-export-v1', 'Source/native model binding')
    need(result['model_export']['bytes'] == refs['model']['bytes'] and result['model_export']['sha256'] == refs['model']['sha256'], 'Native model export pin')
    ctx = ModelAudit(manifest, contract, read, result, model, profile)
    correspondence = ctx.verify_source()
    summary = {'candidate_id': candidate, 'candidate': candidate, 'native_outcome': outcome, 'source_correspondence': correspondence,
               'input_bindings': dict(refs),
               'production_certificate_read': False, 'production_checker_imports': 0,
               'native_processes': 0, 'region_fixed_point_solves': 0,
               'initial_cooperation_inferred_from_region_nonemptiness': False,
               'scope': 'Exact declared source-initialized native output; no population, repair-loop, or historical-label promotion.'}
    summary.update(variant_provenance)
    view = None
    if outcome == 'JOB_UNREALIZABLE_NO_CONTROLLER':
        need(result['native_initial_verdict'] is False and result['memory_empty_guard_called'] is False
             and result['controller_extraction_calls'] == result['native_printer_calls'] == 0, 'False-verdict short circuit')
        need('controller' not in refs and 'printer' not in refs, 'Unexpected graph on native false verdict')
        summary.update(status='COMPLETE_INDEPENDENT_NO_CONTROLLER', no_controller_reason='NATIVE_FALSE_VERDICT',
                       independent_strict=None, independent_cooperative=None, original_view={'status': 'NOT_RETURNED'})
    elif outcome == 'JOB_EMPTY_MEMORY_NO_CONTROLLER':
        need(result['native_initial_verdict'] is True and result['memory_empty_guard_called'] is True and result['memory_empty'] is True
             and result['controller_extraction_calls'] == result['native_printer_calls'] == 0, 'Empty-memory short circuit')
        need('controller' not in refs and 'printer' not in refs, 'Unexpected graph on empty-memory outcome')
        summary.update(status='COMPLETE_INDEPENDENT_NO_CONTROLLER', no_controller_reason='EMPTY_NATIVE_MEMORY',
                       independent_strict=None, independent_cooperative=None, original_view={'status': 'NOT_RETURNED'})
    else:
        need(result['native_initial_verdict'] is True and result['memory_empty_guard_called'] is True
             and result['memory_empty'] is False and result['memory_complete'] is True
             and result['controller_extraction_calls'] == result['native_printer_calls'] == 1, 'Complete native extraction gate')
        graph_raw = read('controller')
        graph, printed = decode_json(graph_raw), read('printer').decode('utf-8')
        need(graph_raw.endswith(b'\n') and hashlib.sha256(graph_raw[:-1]).hexdigest() == result['controller_after_print_sha256'],
             'Exact after-printer graph serialization/hash binding')
        need(graph['fixture_id'] == graph['case_id'] == candidate and graph['variant'] == 'initializers', 'Raw graph identity')
        for key, logical in [('controller_export', 'controller'), ('printed_controller', 'printer')]:
            need(result[key]['bytes'] == refs[logical]['bytes'] and result[key]['sha256'] == refs[logical]['sha256'], 'Native graph/printer export pin')
        graph_summary, view = audit_graph(ctx, graph, printed, refs)
        summary.update(status='COMPLETE_INDEPENDENT_RAW_GRAPH_AUDIT', **graph_summary)
    _variant_metadata.validate_manifest(manifest)  # Post-evaluation pin recheck only.
    summary.update(saved_DAG_files_evaluated=sorted(ctx.loaded), logical_inputs_read=read_refs)
    return summary, view


def main():
    need(len(sys.argv) == 3, 'Usage: audit_worker.py INPUTS.json OUTPUT_DIRECTORY')
    manifest_path, output = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
    need(not output.exists() and not output.is_symlink(), 'Fresh absent audit output directory required')
    output.mkdir(exist_ok=False)
    manifest = decode_json(manifest_path.read_bytes())
    started = datetime.now(timezone.utc).isoformat()
    try:
        result, view = audit(manifest)
        if view is not None:
            save_new(output / 'INDEPENDENT_VIEW.json', view)
            result['view_pin'] = pin(output / 'INDEPENDENT_VIEW.json')
        exit_code = 0
    except BaseException as error:
        result = {'status': 'UNKNOWN_INDEPENDENT_AUDIT', 'error': str(error), 'exception_type': type(error).__name__,
                  'traceback': traceback.format_exc(), 'production_certificate_read': False,
                  'production_checker_imports': 0, 'native_processes': 0, 'region_fixed_point_solves': 0}
        exit_code = 2
    result.update(nonrelease_extractor=True,
                  metadata_adapter_pin=pin(Path(__file__).resolve().parent.parent / 'variant_metadata.py'))
    result.update(started_utc=started, finished_utc=datetime.now(timezone.utc).isoformat(),
                  input_manifest_pin=pin(manifest_path), worker_pin=pin(Path(__file__)),
                  source_contracts_pin=pin(Path(__file__).with_name('source_contracts.py')),
                  independent_core_pin=pin(Path(__file__).with_name('independent_core.py')))
    save_new(output / 'AUDIT_RESULT.json', result)
    print(json.dumps({key: result[key] for key in ('status', 'candidate_id', 'error', 'independent_strict', 'independent_cooperative') if key in result}))
    return exit_code


if __name__ == '__main__':
    sys.exit(main())
