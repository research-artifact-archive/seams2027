# Experimental extractor audit adapter

Prepared for `final_candidate_original_env_continuation_preference_v1`.
The name is a bound input, not hard-coded in the judge.

Both entry points use the same frozen manifest and a fresh absent output directory:

```text
python -I -S -B variant_audit/independent/audit_worker.py INPUTS.json OUTPUT_DIR
python -I -S -B variant_audit/production/audit_variant.py INPUTS.json OUTPUT_DIR
```

Run each through the authorized bounded launcher. Do not invoke
`production/certify.py` directly: it is the copied mathematical implementation,
and the public production entry point adds the mandatory metadata gate.
This preparation does not launch either checker.

The independent output is `AUDIT_RESULT.json` and `INDEPENDENT_VIEW.json`.
The production output is `certificate.json`, `derived_original_graph.json`,
and `derived_original_fairness.json`. Successful evaluation is distinct from
strict/cooperative success: inspect those two verdicts explicitly.
Incomplete metadata or evaluation yields UNKNOWN, never a semantic pass.
Only complete returned-controller variants are accepted by this adapter.
No-controller/timeout cases require an external run outcome and remain UNKNOWN.

## Producer fields

The result must retain the actual original-initializer and upstream fields and
add/change only the experimental identity:

```json
{
  "schema": "experimental-extractor-native-result-v1",
  "pipeline": "released_syntactic_4fp_experimental_extractor",
  "nonrelease_extractor": true,
  "extractor_variant": "final_candidate_original_env_continuation_preference_v1",
  "experimental_class_identities": [
    {"class": "fully.qualified.Class", "class_sha256": "ACTUAL_CLASS_HASH", "code_source": "ACTUAL_RUNTIME_SOURCE"}
  ],
  "configuration": {
    "extractor_strategy": "experimental:final_candidate_original_env_continuation_preference_v1"
  }
}
```

The displayed configuration fragment is not the full object: retain every other
released configuration field unchanged. `native_solver_calls=1` refers to the
unchanged raw solver invocation; graph-specific extraction/printer counters
must accurately count the exported variant graph. Pair-wide baseline plus variant
extraction counts belong in the pairing receipt, not hidden as a released run.

The exported graph uses:

```json
{
  "schema": "experimental-extractor-complete-controller-v1",
  "nonrelease_extractor": true,
  "extractor_variant": "final_candidate_original_env_continuation_preference_v1"
}
```

All other model, node, edge, initial, rank, AUX, bit, printer and export binding
fields retain the existing exact meanings. In particular this adapter supports
the unchanged `GR1RankInfo` encoding, not a new memory/rank representation.
Generate these labels when the variant is exported. The adapter does not rewrite
result, model, graph, printer or process receipts.

## Input manifest and binding

A `PIN` is exactly `{"path": "ABSOLUTE_PATH", "bytes": INTEGER, "sha256": "64_LOWERCASE_HEX"}`.
All inputs must be regular non-symlink files. Metadata input size is capped at
16 MiB per pinned file; this does not pin or read the large stdout stream itself.

Use the existing independent manifest shape with:

```text
schema: experimental-extractor-independent-audit-inputs-v1
candidate_id: exact source-contract candidate
inputs: existing source/profile/native_result/model/native_process/controller/printer pins
bdd_files: complete existing basename -> PIN roster
variant_binding: PIN of binding JSON below
```

The binding JSON is created after all producer outputs and the pairing receipt
are finalized, then the audit manifest is frozen:

```text
schema: experimental-extractor-binding-v1
candidate_id: same candidate
variant_name: final_candidate_original_env_continuation_preference_v1
nonrelease_extractor: true
upstream_transformation_unchanged: true
upstream_raw_core_unchanged: true
baseline_manifest: PIN of the unmodified same-JVM baseline's original independent-input manifest
variant_result: exactly the variant inputs.native_result PIN
source_files: [PIN of each experimental Java source, including changed harness sources]
class_files: {fully.qualified.Class: PIN of its compiled class file, ...}
extractor_class: fully qualified experimental extractor class present in class_files
paired_evidence: PIN of the same-JVM pairing receipt
```

`experimental_class_identities` in the result must contain exactly the
`class_files` roster and the actual runtime class hashes. Include runtime
identities for harness/helper classes that appear in this roster.
Source and bytecode pins bind the declared build; the launcher/build receipt
remains responsible for demonstrating their compilation relationship.

The pairing receipt must contain:

```text
baseline_result: exactly baseline_manifest.inputs.native_result PIN
variant_result: exactly the variant result PIN
same_memory_object: true
same_model_object: true
memory_and_model_all_BDDs_equal: true
variable_order_unchanged: true
BDD_equality_checks: {each effective x_mem_*, y_mem_*, z_mem_*, win,
                     ENV_initial, ENV_trans, SYS_initial, SYS_trans,
                     and all ordered justices: true}
expected_BDD_keys: [complete memory/model snapshot roster, each key exactly once]
```

Its equality roster must describe the full inspected memory/model; the
adapter requires the equality-check keys to match `expected_BDD_keys` exactly,
and verifies the bound receipt's positive checks. The declared roster's
completeness remains producer-attested: this adapter does not reconstruct array
dimensions or independently recompute X/Y/Z equality. Both certificates
explicitly attribute that part to the producer receipt.

The adapter additionally rehashes and requires byte equality of the source,
profile, complete model and every saved BDD versus the baseline, and equality
of upstream configuration, runtime, class identities, solver identity,
ordered justices, model/memory object identities and verdict/memory flags.
Different BDD serializations are conservatively refused even if they could
be semantically equivalent; add a separately reviewed semantic proof workflow
if such a comparison is actually needed.

Production requires `native_result` to be `result.json`, the model to be
`model.json` in that directory, and BDD/controller/printer paths to match the
actual export files there. The shared process receipt may be elsewhere.
Both entry points recheck all bound pins after evaluation.

## Unchanged mathematics

`METADATA_ONLY.diff` lists every change to the two copied checkers.
The five dependency files are byte-identical to their pinned originals.
The independent checker changes only the schema/configuration gate, imports
the metadata validator, and records/rechecks provenance.
The production mathematical implementation changes exactly two schema strings.
The production wrapper validates metadata and invokes the same `check` function.

`prepare_copies.py` verifies seven original hashes and reverses each declared
edit, requiring exact original bytes before writing `PREPARATION_RECEIPT.json`.
This proves that removing the enumerated metadata edits restores the original
checker files exactly. It does not claim a new independent proof of the
original mathematical algorithms.
