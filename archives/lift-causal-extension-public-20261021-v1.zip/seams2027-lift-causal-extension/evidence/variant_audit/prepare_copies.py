"""Create auditable metadata-only copies; performs no scientific execution."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
ORIGINAL = WORK / "experiment/seams_research_reframing_20261018/frozen_execution_01/code"
EXPECTED = {
    "independent/audit_worker.py": "2b1c509677f978ef6b01c6d2d7e3b511b981d98f9943a783c82ce84d30907781",
    "independent/independent_core.py": "aa7aa11d0ab35f9505db132db45cb9cc7832e91216e80f56651bf0b3cea8805e",
    "independent/source_contracts.py": "30d1d89c5977798601cfcf661ef8d642c3fdb7c7c7600cd9d9fa9a3a25011fc8",
    "production/certify.py": "a74be2da9bd8e0d4dd6576b1170df911007944f3673aa35077b5eed8f9f7dea8",
    "production/admission_checker.py": "20b2a56b253ad66f13b16f07f69ca897cbbad8775527e0648dd29b0f8bc7b720",
    "production/bdd_core.py": "f9497519b8a073a29e5748c908cadc804f437080cf12d36558d9e0210462dbac",
    "production/graph_fairness.py": "3da6d64631bd88ae0bda4ad71ccc37c46f48de233a51dcc843a476e391981d45",
}
IMPORT = """
# Metadata-only experimental adapter. Source, DAG and graph algorithms below are unchanged.
_meta_spec = importlib.util.spec_from_file_location(
    'variant_metadata', Path(__file__).resolve().parent.parent / 'variant_metadata.py')
_variant_metadata = importlib.util.module_from_spec(_meta_spec)
_meta_spec.loader.exec_module(_variant_metadata)
"""
EDITS = {
    "independent/audit_worker.py": [
        ("import traceback\n", "import traceback\n" + IMPORT),
        ("need(graph['schema'] == 'released-kind-complete-native-controller-v1'",
         "need(graph['schema'] == 'experimental-extractor-complete-controller-v1'"),
        ("need(manifest['schema'] == 'remaining-nine-independent-audit-inputs-v1'",
         "need(manifest['schema'] == 'experimental-extractor-independent-audit-inputs-v1'"),
        ("    need(result['native_solver_calls'] == 1 and result['pipeline'] == 'released_syntactic_kind_job_equivalent'\n"
         "         and result['solver'] == '4fp' and result['configuration'] == CONFIGURATION, 'Exact one-call released native configuration')",
         "    variant_provenance = _variant_metadata.validate_manifest(manifest, CONFIGURATION)"),
        ("    view = None\n    if outcome == 'JOB_UNREALIZABLE_NO_CONTROLLER':",
         "    summary.update(variant_provenance)\n    view = None\n    if outcome == 'JOB_UNREALIZABLE_NO_CONTROLLER':"),
        ("    summary.update(saved_DAG_files_evaluated=sorted(ctx.loaded), logical_inputs_read=read_refs)",
         "    _variant_metadata.validate_manifest(manifest)  # Post-evaluation pin recheck only.\n"
         "    summary.update(saved_DAG_files_evaluated=sorted(ctx.loaded), logical_inputs_read=read_refs)"),
        ("    result.update(started_utc=started, finished_utc=datetime.now(timezone.utc).isoformat(),",
         "    result.update(nonrelease_extractor=True,\n"
         "                  metadata_adapter_pin=pin(Path(__file__).resolve().parent.parent / 'variant_metadata.py'))\n"
         "    result.update(started_utc=started, finished_utc=datetime.now(timezone.utc).isoformat(),"),
    ],
    "production/certify.py": [
        ("graph.get('schema') == 'released-kind-complete-native-controller-v1'",
         "graph.get('schema') == 'experimental-extractor-complete-controller-v1'"),
        ("'schema': 'released-kind-job-certificate-v2'",
         "'schema': 'experimental-extractor-job-certificate-v1'"),
    ],
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    receipt = {"status": "STATIC_METADATA_ADAPTER_PREPARED", "scientific_execution": False,
               "mathematical_changes": [], "files": [], "restore_proofs": []}
    diffs = []
    for relative, expected in EXPECTED.items():
        source, target = ORIGINAL / relative, HERE / relative
        raw = source.read_bytes()
        assert sha(raw) == expected, relative
        old = raw.decode()
        new = old
        for before, after in EDITS.get(relative, []):
            assert new.count(before) == 1, (relative, before)
            new = new.replace(before, after, 1)
        restored = new
        for before, after in reversed(EDITS.get(relative, [])):
            assert restored.count(after) == 1, (relative, after)
            restored = restored.replace(after, before, 1)
        assert restored.encode() == raw
        ast.parse(new, filename=str(target))
        target.parent.mkdir(exist_ok=True)
        with target.open("xb") as stream:
            stream.write(new.encode())
        receipt["files"].append({"file": relative, "original_path": str(source),
                                 "original_sha256": sha(raw), "adapted_sha256": sha(new.encode()),
                                 "byte_identical": raw == new.encode()})
        receipt["restore_proofs"].append({"file": relative, "reverse_declared_metadata_edits_exact_bytes": True})
        diffs += difflib.unified_diff(old.splitlines(True), new.splitlines(True),
                                      fromfile=str(source), tofile=str(target))
    for path in HERE.rglob("*.py"):
        ast.parse(path.read_text(), filename=str(path))
    (HERE / "METADATA_ONLY.diff").write_text("".join(diffs))
    (HERE / "PREPARATION_RECEIPT.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"status": receipt["status"], "copied_files": len(receipt["files"]),
                      "unchanged_dependencies": sum(x["byte_identical"] for x in receipt["files"]),
                      "restore_proofs": len(receipt["restore_proofs"]), "scientific_execution": False}))


if __name__ == "__main__":
    main()
