"""Pinned provenance checks for experimental extraction; no mathematical checks.

This module does not read production certificates, evaluate a BDD, traverse a
controller, or rewrite any input. Import has no file-reading side effects.
"""
from pathlib import Path
import hashlib
import json
import re

INPUT_SCHEMA = "experimental-extractor-independent-audit-inputs-v1"
BINDING_SCHEMA = "experimental-extractor-binding-v1"
RESULT_SCHEMA = "experimental-extractor-native-result-v1"
GRAPH_SCHEMA = "experimental-extractor-complete-controller-v1"
PIPELINE = "released_syntactic_4fp_experimental_extractor"
CONFIGURATION = {
    "release": "1.0.0.202402072123", "BDDPackage": "JTLV",
    "BDDPackageVersion": "DEFAULT", "synthesisMethod": "synthesisPitermanReduction",
    "ConcreteControllerFormat": "JTLV", "optChoice": "none",
    "reorderChoice": "none", "groupVars": False, "TraceInfo": "NONE",
    "TransFuncType": "SINGLE_FUNC",
    "extractor_strategy": "native_two_argument_default_ZYX",
}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def unique(pairs):
    value = {}
    for key, item in pairs:
        need(key not in value, "Duplicate JSON key: " + key)
        value[key] = item
    return value


def decode(raw):
    return json.loads(raw, object_pairs_hook=unique)


def pin(path):
    path = Path(path)
    need(path.is_absolute() and not path.is_symlink() and path.is_file(),
         "Absolute regular non-symlink input required")
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest()}


def read_pin(ref):
    need(type(ref) is dict and set(ref) == {"path", "bytes", "sha256"}, "Exact pin shape")
    need(type(ref["path"]) is str and type(ref["bytes"]) is int and 0 <= ref["bytes"] <= 16 * 1024 * 1024
         and type(ref["sha256"]) is str and re.fullmatch("[0-9a-f]{64}", ref["sha256"]),
         "Pin types/size/hash")
    path = Path(ref["path"])
    need(path.is_absolute() and not path.is_symlink() and path.is_file(), "Pinned input path")
    need(path.stat().st_size == ref["bytes"], "Pinned input byte count")
    raw = path.read_bytes()
    need(hashlib.sha256(raw).hexdigest() == ref["sha256"], "Pinned input digest: " + str(path))
    return raw


def same_content(left, right):
    return (left["bytes"], left["sha256"]) == (right["bytes"], right["sha256"])


def validate_manifest(manifest, released_configuration=None):
    """Validate honest labeling and pairing before either scientific checker.

    Same-game evidence is deliberately conservative: complete model and saved
    BDD files must be byte-identical. Nonidentical serializations are refused;
    they are not silently accepted on counts or producer equality assertions.
    X/Y/Z equality remains an explicitly attributed in-process producer receipt.
    """
    expected = CONFIGURATION if released_configuration is None else released_configuration
    need(expected == CONFIGURATION, "Adapter/released configuration disagreement")
    need(manifest["schema"] == INPUT_SCHEMA, "Experimental input manifest required")
    candidate = manifest["candidate_id"]
    binding = decode(read_pin(manifest["variant_binding"]))
    need(binding["schema"] == BINDING_SCHEMA and binding["nonrelease_extractor"] is True,
         "Explicit nonrelease binding required")
    name = binding["variant_name"]
    need(type(name) is str and re.fullmatch("[a-z][a-z0-9_]{1,127}", name),
         "Variant name syntax")
    need(binding["candidate_id"] == candidate, "Binding candidate identity")
    need(binding["upstream_transformation_unchanged"] is True
         and binding["upstream_raw_core_unchanged"] is True, "Unchanged upstream declaration")
    refs = manifest["inputs"]
    need(set(refs) == {"source", "profile", "native_result", "model",
                       "native_process", "controller", "printer"}, "Exact variant logical input roster")
    need(binding["variant_result"] == refs["native_result"], "Binding/result pin equality")
    raw = {key: read_pin(ref) for key, ref in refs.items()}
    result, graph = decode(raw["native_result"]), decode(raw["controller"])
    need(result["schema"] == RESULT_SCHEMA and result["pipeline"] == PIPELINE
         and result["nonrelease_extractor"] is True and result["extractor_variant"] == name,
         "Honest experimental result identity")
    config = dict(expected, extractor_strategy="experimental:" + name)
    need(result["configuration"] == config and result["solver"] == "4fp"
         and result["native_solver_calls"] == 1, "Exact unchanged upstream configuration")
    need(result["status"] == "JOB_CONTROLLER_PRINTED" and result["teardown"] == "COMPLETED",
         "Adapter accepts complete returned experimental controllers only")
    need(result["fixture_id"] == result["case_id"] == candidate and result["variant"] == "initializers",
         "Experimental original-initializer identity")
    need(graph["schema"] == GRAPH_SCHEMA and graph["nonrelease_extractor"] is True
         and graph["extractor_variant"] == name, "Honest experimental graph identity")
    baseline = decode(read_pin(binding["baseline_manifest"]))
    need(baseline["schema"] == "remaining-nine-independent-audit-inputs-v1"
         and baseline["candidate_id"] == candidate, "Unmodified paired baseline manifest")
    old_refs = baseline["inputs"]
    need(set(old_refs) == set(refs), "Paired baseline logical input roster")
    old_raw = {key: read_pin(ref) for key, ref in old_refs.items()}
    old = decode(old_raw["native_result"])
    need(old["pipeline"] == "released_syntactic_kind_job_equivalent"
         and old["configuration"] == expected and old["status"] == "JOB_CONTROLLER_PRINTED",
         "Paired baseline must use the unchanged released extractor")
    for key in ("source", "profile", "model"):
        need(same_content(refs[key], old_refs[key]), "Paired byte identity: " + key)
    need(refs["native_result"]["path"] != old_refs["native_result"]["path"]
         and refs["controller"]["path"] != old_refs["controller"]["path"],
         "Variant and baseline artifacts must be separate")
    for key in ("runtime", "input_sha256", "class_identities", "solver_class_identity",
                "preconstructor_justices", "solver_justices",
                "native_initial_verdict", "memory_complete", "memory_empty",
                "native_model_identity", "native_memory_identity"):
        need(result[key] == old[key], "Paired upstream identity: " + key)
    need(set(manifest["bdd_files"]) == set(baseline["bdd_files"])
         and "final_region.bdd" in manifest["bdd_files"], "Complete paired BDD roster")
    for key, ref in manifest["bdd_files"].items():
        read_pin(ref)
        read_pin(baseline["bdd_files"][key])
        need(same_content(ref, baseline["bdd_files"][key]), "Paired saved BDD identity: " + key)
    sources, classes = binding["source_files"], binding["class_files"]
    need(type(sources) is list and sources and type(classes) is dict and classes,
         "Nonempty experimental source/class pins")
    for ref in sources:
        read_pin(ref)
    identities = result["experimental_class_identities"]
    need(type(identities) is list and len(identities) == len(classes),
         "Observed experimental class roster")
    observed = {}
    for item in identities:
        need(item["class"] not in observed, "Unique observed experimental classes")
        observed[item["class"]] = item
    need(set(observed) == set(classes) and binding["extractor_class"] in classes,
         "Exact experimental runtime class identities")
    for classname, ref in classes.items():
        read_pin(ref)
        need(observed[classname]["class_sha256"] == ref["sha256"],
             "Runtime/source-packet class hash: " + classname)
    pairing = decode(read_pin(binding["paired_evidence"]))
    need(pairing["baseline_result"] == old_refs["native_result"]
         and pairing["variant_result"] == refs["native_result"], "Pair receipt result bindings")
    for key in ("same_memory_object", "same_model_object",
                "memory_and_model_all_BDDs_equal", "variable_order_unchanged"):
        need(pairing[key] is True, "Paired producer observation: " + key)
    checks = pairing["BDD_equality_checks"]
    roster = pairing["expected_BDD_keys"]
    need(type(roster) is list and all(type(k) is str for k in roster)
         and len(roster) == len(set(roster)) and set(checks) == set(roster),
         "Exact equality-check coverage of declared memory/model roster")
    required = {"win", "ENV_initial", "ENV_trans", "SYS_initial", "SYS_trans"}
    need(type(checks) is dict and required <= set(checks) and all(v is True for v in checks.values())
         and all(any(k.startswith(prefix) for k in checks) for prefix in ("x_mem_", "y_mem_", "z_mem_")),
         "Positive declared model/memory equality receipt")
    return {
        "nonrelease_extractor": True, "extractor_variant": name,
        "variant_binding": manifest["variant_binding"],
        "baseline_manifest": binding["baseline_manifest"],
        "paired_evidence": binding["paired_evidence"],
        "paired_BDD_keys_verified": sorted(checks),
        "paired_roster_completeness": "Producer-attested full memory/model roster; this metadata adapter checks exact declared coverage, not memory-array dimensions.",
        "upstream_transformation_unchanged": True, "upstream_raw_core_unchanged": True,
        "upstream_evidence": "Identical input/configuration/runtime/upstream class identities, complete model and saved BDD bytes; same-object and X/Y/Z equality are verified producer receipt fields, not recomputed here.",
        "experimental_source_pins": sources, "experimental_class_pins": classes,
        "scope": "Experimental extractor on the paired unchanged released transformed game and raw core. Full original-contract checks; no claim of released-extractor behavior or general repair correctness.",
    }
