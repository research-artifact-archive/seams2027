"""Synthetic metadata-only tests. Never invokes either scientific checker."""
from pathlib import Path
import copy
import importlib.util
import json
import tempfile

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("adapter_metadata_test", HERE / "variant_metadata.py")
meta = importlib.util.module_from_spec(spec)
spec.loader.exec_module(meta)


def main():
    passed = []
    with tempfile.TemporaryDirectory(prefix="metadata-only-", dir=HERE) as temp:
        root = Path(temp)

        def save(name, value):
            path = root / name
            path.write_text(json.dumps(value))
            return meta.pin(path)

        def fixture():
            candidate, name = "synthetic_metadata_only", "synthetic_extractor_v1"
            shared = {
                "runtime": {"java_version": "synthetic"}, "input_sha256": "1" * 64,
                "class_identities": [], "solver_class_identity": {},
                "preconstructor_justices": {}, "solver_justices": {},
                "native_initial_verdict": True, "memory_complete": True, "memory_empty": False,
                "native_model_identity": 7, "native_memory_identity": 11,
            }
            base = dict(shared, pipeline="released_syntactic_kind_job_equivalent",
                        configuration=meta.CONFIGURATION, status="JOB_CONTROLLER_PRINTED")
            class_pin = save("Class.class", {"synthetic": "not executable bytecode"})
            source = save("Source.java", {"synthetic": "not Java"})
            result = dict(shared, schema=meta.RESULT_SCHEMA, pipeline=meta.PIPELINE,
                          nonrelease_extractor=True, extractor_variant=name,
                          configuration=dict(meta.CONFIGURATION, extractor_strategy="experimental:" + name),
                          solver="4fp", native_solver_calls=1, status="JOB_CONTROLLER_PRINTED",
                          teardown="COMPLETED", fixture_id=candidate, case_id=candidate,
                          variant="initializers",
                          experimental_class_identities=[{"class": "synthetic.Class",
                                                          "class_sha256": class_pin["sha256"]}])
            refs = {k: save(k + ".json", {}) for k in ("source", "profile", "model", "native_process", "printer")}
            refs["native_result"] = save("variant_result.json", result)
            refs["controller"] = save("variant_graph.json", {"schema": meta.GRAPH_SCHEMA,
                                                            "nonrelease_extractor": True, "extractor_variant": name})
            old_refs = dict(refs, native_result=save("baseline_result.json", base),
                            controller=save("baseline_graph.json", {}))
            bdds = {"final_region.bdd": save("final_region.bdd", {"synthetic": "not a BDD"})}
            baseline = save("baseline_manifest.json", {"schema": "remaining-nine-independent-audit-inputs-v1",
                                                      "candidate_id": candidate, "inputs": old_refs, "bdd_files": bdds})
            pairing = {"baseline_result": old_refs["native_result"], "variant_result": refs["native_result"],
                       "same_memory_object": True, "same_model_object": True,
                       "memory_and_model_all_BDDs_equal": True, "variable_order_unchanged": True,
                       "BDD_equality_checks": {k: True for k in
                                              ("x_mem_0", "y_mem_0", "z_mem_0", "win", "ENV_initial",
                                               "ENV_trans", "SYS_initial", "SYS_trans")}}
            pairing["expected_BDD_keys"] = list(pairing["BDD_equality_checks"])
            binding = {"schema": meta.BINDING_SCHEMA, "candidate_id": candidate, "variant_name": name,
                       "nonrelease_extractor": True, "upstream_transformation_unchanged": True,
                       "upstream_raw_core_unchanged": True, "baseline_manifest": baseline,
                       "variant_result": refs["native_result"], "source_files": [source],
                       "class_files": {"synthetic.Class": class_pin}, "extractor_class": "synthetic.Class",
                       "paired_evidence": save("paired.json", pairing)}
            manifest = {"schema": meta.INPUT_SCHEMA, "candidate_id": candidate, "inputs": refs,
                        "bdd_files": bdds, "variant_binding": save("binding.json", binding)}
            return manifest, binding, result, pairing

        manifest, _, _, _ = fixture()
        assert meta.validate_manifest(manifest)["nonrelease_extractor"] is True
        passed.append("honest_synthetic_metadata_accepted_without_science")

        for case in ("released_label", "wrong_strategy", "upstream_changed", "class_hash_mismatch",
                     "pair_result_mismatch", "failed_memory_equality", "missing_memory_family",
                     "same_artifact_path", "input_pin_tamper"):
            manifest, binding, result, pairing = fixture()
            if case == "released_label":
                result["pipeline"] = "released_syntactic_kind_job_equivalent"
            elif case == "wrong_strategy":
                result["configuration"] = copy.deepcopy(meta.CONFIGURATION)
            elif case == "upstream_changed":
                result["runtime"] = {"java_version": "changed"}
            elif case == "class_hash_mismatch":
                result["experimental_class_identities"][0]["class_sha256"] = "0" * 64
            elif case == "pair_result_mismatch":
                pairing["variant_result"] = pairing["baseline_result"]
            elif case == "failed_memory_equality":
                pairing["BDD_equality_checks"]["x_mem_0"] = False
            elif case == "missing_memory_family":
                del pairing["BDD_equality_checks"]["z_mem_0"]
            elif case == "same_artifact_path":
                baseline = meta.decode(meta.read_pin(binding["baseline_manifest"]))
                baseline["inputs"]["controller"] = manifest["inputs"]["controller"]
                binding["baseline_manifest"] = save("baseline_manifest.json", baseline)
            elif case == "input_pin_tamper":
                manifest["inputs"]["source"] = dict(manifest["inputs"]["source"], sha256="0" * 64)
            old_variant_pin = manifest["inputs"]["native_result"]
            manifest["inputs"]["native_result"] = save("variant_result.json", result)
            binding["variant_result"] = manifest["inputs"]["native_result"]
            if pairing["variant_result"] == old_variant_pin:
                pairing["variant_result"] = manifest["inputs"]["native_result"]
            binding["paired_evidence"] = save("paired.json", pairing)
            manifest["variant_binding"] = save("binding.json", binding)
            try:
                meta.validate_manifest(manifest)
            except (ValueError, KeyError):
                passed.append(case + "_rejected")
            else:
                raise AssertionError("Unexpected metadata acceptance: " + case)
    receipt = {"status": "PASS_SYNTHETIC_METADATA_ONLY", "checks": passed,
               "scientific_checker_calls": 0, "BDD_evaluations": 0, "graph_traversals": 0}
    (HERE / "METADATA_TEST_RECEIPT.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
