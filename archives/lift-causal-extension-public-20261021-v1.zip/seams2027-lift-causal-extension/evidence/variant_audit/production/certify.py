"""Certificate adapter for the unchanged released Kind job.

Audit helper-false correspondence when the observed native model has the ENV
non-AUX helper; otherwise audit direct identity correspondence. No original
initializer, field, native edge or private memory is repaired. Three historical
core implementations are copied without edits and byte-pinned before import.
Profiles are reviewed source transcriptions, not a separate source oracle.
Native invocation provenance remains an explicit launcher trust obligation.
"""
from pathlib import Path
from itertools import product
from collections import defaultdict, deque
import argparse
import copy
import hashlib
import json
import re
import sys
import traceback

CODE_DIR = Path(__file__).resolve().parent
CORE_PINS = {
    'bdd_core.py': 'f9497519b8a073a29e5748c908cadc804f437080cf12d36558d9e0210462dbac',
    'admission_checker.py': '20b2a56b253ad66f13b16f07f69ca897cbbad8775527e0648dd29b0f8bc7b720',
    'graph_fairness.py': '3da6d64631bd88ae0bda4ad71ccc37c46f48de233a51dcc843a476e391981d45',
}
# -I omits the script directory. Add only this explicitly pinned directory.
for _name, _hash in CORE_PINS.items():
    _path = CODE_DIR / _name
    if _path.is_symlink() or hashlib.sha256(_path.read_bytes()).hexdigest() != _hash:
        raise RuntimeError('Pinned dependency mismatch: ' + _name)
sys.path.insert(0, str(CODE_DIR))
from admission_checker import Context, read_json, pinned_file, bit_map, require
from bdd_core import Invalid, ResourceRefusal
from graph_fairness import analyze_graph
for _name in ('bdd_core', 'admission_checker', 'graph_fairness'):
    if Path(sys.modules[_name].__file__).resolve() != CODE_DIR / (_name + '.py'):
        raise RuntimeError('Unexpected already-loaded dependency: ' + _name)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def reach(starts, edges):
    adjacency = defaultdict(list)
    for source, target in edges:
        adjacency[source].append(target)
    seen, queue = set(starts), deque(starts)
    while queue:
        for target in adjacency[queue.popleft()]:
            if target not in seen:
                seen.add(target)
                queue.append(target)
    return seen


def audit_model(directory, result, profile, certificate):
    model = read_json(pinned_file(directory, result['model_export']))
    require(model['input']['sha256'] == profile['source']['sha256']
            and model['input']['bytes'] == profile['source']['bytes'], 'Input/source pin')
    require(type(result.get('helper_added')) is bool, 'Observed helper_added boolean required')
    helper = result['helper_added']
    require(result.get('helper_is_native_nonaux_ENV') is helper,
            'Observed helper ownership flag disagrees')
    require(all(f['name'] != '~envHelp' for f in profile['expected_fields_in_native_order'])
            and '~envHelp' not in profile['public_ENV'] + profile['public_SYS'],
            'Original profile must not contain reduction helper')
    adapted = copy.deepcopy(profile)
    if helper:
        adapted['public_ENV'] = profile['public_ENV'] + ['~envHelp']
        adapted['expected_fields_in_native_order'].insert(len(profile['public_ENV']), {
            'name': '~envHelp', 'domain': ['false', 'true'], 'owner': 'ENV', 'role': 'ENV'})
    context = Context(directory, adapted, model)
    bdd = context.b
    domain_next = bdd.rename(context.domain, context.prime)
    if helper:
        b0 = context.literal('~envHelp', 'false')
        bn0 = context.literal('~envHelp', 'false', True)
        current_mask = bdd.conj(context.domain, b0)
        edge_mask = bdd.conj(context.domain, domain_next, b0, bn0)
    else:
        require('~envHelp' not in context.by_name, 'Identity mapping requires no helper field')
        b0 = None
        current_mask = context.domain
        edge_mask = bdd.conj(context.domain, domain_next)
    original_bits = {bit for field in model['fields'] if field['name'] != '~envHelp'
                     for bit in field['current_bits']}
    checks = []
    limits = {'thetaE': context.current_env, 'thetaS': context.current,
              'rhoE': context.current + context.env_next,
              'rhoS': context.current + context.next}
    require(set(context.formulas) == set(limits), 'Exactly four source transition formulas')
    for key, expected in context.formulas.items():
        actual = context.read_bdd(model['original_bdds'][key], limits[key])
        initial = key.startswith('theta')
        mask = current_mask if initial else edge_mask
        if helper:
            label = 'b=false' if initial else 'b=bprime=false'
        else:
            label = 'current legal domain' if initial else 'current and next legal domains'
        equal = bdd.conj(mask, bdd.apply('xor', actual, expected)) == 0
        checks.append({'equation': key, 'mask': label,
                       'equivalent_on_entire_legal_domain': equal})
        require(equal, ('Helper-false' if helper else 'Identity')
                + ' transformed/original ' + key + ' mismatch')
    # The released syntactic reduction always adds ENV INI !helper.  Matching
    # only on the false slice would miss extra helper-true initial ENV choices,
    # especially on a false/empty result without a returned initial graph.
    initial_env = context.read_bdd(model['original_bdds']['thetaE'], context.current_env)
    expected_initial_env = bdd.conj(context.formulas['thetaE'], b0) if helper else context.formulas['thetaE']
    require(bdd.conj(context.domain, bdd.apply('xor', initial_env, expected_initial_env)) == 0,
            'Full native initial ENV correspondence')
    certificate['initialization_correspondence'] = {
        'status': 'PASS', 'ENV_full_native_typed_domain': True,
        'ENV_definition': 'original thetaE and helper=false' if helper else 'original thetaE',
        'SYS_definition': 'original thetaS on helper=false legal domain' if helper else 'original thetaS on legal domain',
        'original_initializers_replaced': False}
    for key, expected, allowed in [
            ('domain', context.domain, context.current),
            ('domain_ENV_next', context.domain_en, context.env_next),
            ('domain_SYS_next', context.domain_sn, context.sys_next)]:
        context.equal(model['original_bdds'][key], expected, key, allowed)
    justice_audit = {}
    for owner in ['ENV', 'SYS']:
        actual = [context.read_bdd(ref, context.current)
                  for ref in model['original_justices'][owner]]
        filtered, helper_index = list(actual), None
        if helper and owner == 'ENV':
            matches = [i for i, value in enumerate(actual)
                       if bdd.conj(context.domain, bdd.apply('xor', value, b0)) == 0]
            require(len(matches) == 1, 'Unique inserted helper justice')
            helper_index = matches[0]
            filtered.pop(helper_index)
        require(len(filtered) == len(context.justices[owner]), 'Original justice count after mapping')
        for actual_value, expected_value in zip(filtered, context.justices[owner]):
            require(bdd.conj(current_mask, bdd.apply('xor', actual_value, expected_value)) == 0,
                    'Original justice identity/order')
        before = [context.read_bdd(ref, context.current)
                  for ref in result['preconstructor_justices'][owner]]
        require(len(before) == len(actual), 'Preconstructor/model justice count')
        for actual_value, expected_value in zip(before, actual):
            require(bdd.conj(context.domain, bdd.apply('xor', actual_value, expected_value)) == 0,
                    'Preconstructor/model justice identity/order')
        solver = [context.read_bdd(ref, context.current)
                  for ref in result['solver_justices'][owner]]
        expected = actual or [1]
        require(len(solver) == len(expected), 'Native constructor justice padding count')
        for actual_value, expected_value in zip(solver, expected):
            require(bdd.conj(context.domain, bdd.apply('xor', actual_value, expected_value)) == 0,
                    'Native constructor only TRUE-pads empty owner')
        justice_audit[owner] = {
            'original_count': len(filtered), 'transformed_count': len(actual),
            'helper_justice_index': helper_index, 'solver_count': len(solver),
            'native_TRUE_padding': not actual}
    inventory = model['source_inventory']['parsed']
    require([x['name'] for x in inventory['ENV']['variables']] == profile['public_ENV'],
            'Original parsed ENV identity')
    require([x['name'] for x in inventory['SYS']['variables']] == profile['public_SYS'],
            'Original parsed SYS identity')
    mapping = {'status': 'PASS', 'full_domain_equivalences': checks,
               'justice_identity_order': justice_audit,
               'all_original_fields_and_logical_AUX_retained': True,
               'helper_owner': 'ENV_nonAUX' if helper else None,
               'original_current_bit_count': len(original_bits)}
    certificate['helper_mapping_equations' if helper else 'identity_mapping_equations'] = mapping
    certificate['original_mapping_kind'] = 'helper_false' if helper else 'identity'
    return context, model


def parse_printed(text, nodes):
    lines = text.splitlines()
    require(len(lines) == 2 * len(nodes), 'Native printer line count')
    for index, node in enumerate(nodes):
        match = re.fullmatch(r'(Initial )?State ([0-9]+) (<[^<>]+>)', lines[2 * index])
        require(match is not None, 'Native printed state format')
        require((match.group(1) is not None) == node['initial'] and int(match.group(2)) == index,
                'Printed initial/ID mismatch')
        pairs = [part.split(':') for part in match.group(3)[1:-1].split(', ')]
        require(all(len(pair) == 2 for pair in pairs), 'Printed valuation syntax')
        value = dict(pairs)
        require(len(value) == len(pairs) and value == node['valuation'],
                'Printed native valuation differs from complete node')
        require(match.group(3) == node['native_bdd_text'], 'Native BDD string receipt mismatch')
        expected = ('\tWith successors : ' + ', '.join(node['successors'])
                    if node['successors'] else '\tWith no successors.')
        require(lines[2 * index + 1] == expected, 'Printed successors differ from native graph')
    return {'status': 'PASS', 'decoded_states': len(nodes), 'all_variables_printed': True,
            'helper_projection_by_printer': False, 'same_graph_before_after_printer': True}


def certify_graph(directory, result, profile, context, model, certificate, output):
    bdd = context.b
    graph = read_json(pinned_file(directory, result['controller_export']))
    require(graph.get('schema') == 'experimental-extractor-complete-controller-v1'
            and graph.get('complete') is True, 'Complete graph schema')
    require(graph['model_sha256'] == sha(directory / 'model.json'), 'Graph/model identity')
    require(graph['native_memory_identity'] == result['native_memory_identity'], 'Graph/memory identity')
    require(result['controller_before_print_sha256'] == result['controller_after_print_sha256'],
            'Printer mutation guard')
    require(result.get('same_native_memory_passed_to_constructor') is True
            and result.get('same_native_model_passed_to_constructor') is True,
            'Same solver memory/model to generic constructor')
    require(type(graph['rank_domain_size']) is int
            and graph['rank_domain_size'] == len(result['solver_justices']['SYS'])
            and graph['rank_domain_size'] > 0,
            'Native rank domain equals constructor SYS justice count')
    nodes = graph['nodes']
    require(0 < len(nodes) <= 4096 and len(nodes) == graph['api_state_count'], 'Node count cap')
    index, flat = {}, []
    for i, node in enumerate(nodes):
        sid = node['id']
        require(sid == str(i) and node['native_id'] == i and sid not in index, 'Exact native state order/ID')
        require(type(node['initial']) is bool and type(node['rank']) is int
                and 0 <= node['rank'] < graph['rank_domain_size'], 'Initial/rank encoding')
        require(node['rank_class'] == 'tau.smlab.syntech.games.gr1.GR1RankInfo', 'Rank class')
        context.valuation(node['valuation'], 'Graph node')
        require(bit_map(node['bits'], context.current, 'Native graph bits')
                == context.bits(node['valuation']), 'Value/bit identity')
        require(type(node['successors']) is list
                and len(set(node['successors'])) == len(node['successors']), 'Unique native successors')
        index[sid] = node
        flat.extend([[sid, target] for target in node['successors']])
    require(flat == graph['edges'] and len(flat) == graph['api_transition_count']
            and len(flat) <= 65536, 'Complete ordered raw edge export')
    require(all(target in index for _, target in flat), 'Raw target exists')
    printed = pinned_file(directory, result['printed_controller'])
    certificate['native_printer_mapping'] = parse_printed(printed.read_text(), nodes)
    all_starts = [node['id'] for node in nodes if node['initial']]
    require(all_starts, 'Nonempty native initial graph')
    require(all(index[sid]['rank'] == 0 for sid in all_starts), 'Native rank-zero initial memory')
    require(reach(all_starts, flat) == set(index), 'Native graph contains unreachable extra nodes')
    if result['helper_added']:
        starts = [sid for sid in all_starts if index[sid]['valuation']['~envHelp'] == 'false']
        require(starts == all_starts, 'Native initial helper must be false')
        b0ids = {sid for sid, node in index.items() if node['valuation']['~envHelp'] == 'false'}
        zero_edges = [edge for edge in flat if edge[0] in b0ids and edge[1] in b0ids]
        reachable = reach(starts, zero_edges)
        edges = [edge for edge in zero_edges if edge[0] in reachable]
        definition = ('Reachable native subgraph with ENV helper fixed false forever; '
                      'complete native IDs/ranks/private memory and logical AUX retained. '
                      'This is a derived view, not a printer projection.')
    else:
        starts = all_starts
        reachable = reach(starts, flat)
        edges = [edge for edge in flat if edge[0] in reachable]
        definition = ('Identity view of the complete reachable native graph without a reduction helper; '
                      'all native IDs, ranks, private memory, logical AUX and edges retained.')
    adjacency = defaultdict(list)
    for source, target in edges:
        adjacency[source].append(target)
    env = profile['public_ENV']
    inputs = [dict(zip(env, values)) for values in product(*[context.by_name[x]['values'] for x in env])]
    require(len(inputs) * len(reachable) <= 4000000, 'Input check cap')
    actual_initial = defaultdict(list)
    for sid in starts:
        node = index[sid]
        bits = context.bits(node['valuation'])
        require(bdd.evaluate(context.formulas['thetaE'], bits)
                and bdd.evaluate(context.formulas['thetaS'], bits), 'Original native initial response')
        actual_initial[tuple(node['valuation'][x] for x in env)].append(sid)
    legal_initial = set()
    for inp in inputs:
        if bdd.evaluate(context.formulas['thetaE'], context.bits(inp)):
            legal_initial.add(tuple(inp[x] for x in env))
    require(set(actual_initial) == legal_initial and all(len(v) == 1 for v in actual_initial.values()),
            'Exact initial ENV coverage/private response')
    checked = 0
    for sid in sorted(reachable):
        current = context.bits(index[sid]['valuation'])
        expected, seen = set(), defaultdict(list)
        for inp in inputs:
            checked += 1
            if bdd.evaluate(context.formulas['rhoE'], {**current, **context.bits(inp, True)}):
                expected.add(tuple(inp[x] for x in env))
        for target_id in adjacency[sid]:
            target = index[target_id]
            bits = {**current, **context.bits(target['valuation'], True)}
            require(bdd.evaluate(context.formulas['rhoE'], bits), 'Retained edge violates original ENV')
            require(bdd.evaluate(context.formulas['rhoS'], bits), 'Retained edge violates original SYS/AUX')
            seen[tuple(target['valuation'][x] for x in env)].append(target_id)
        require(set(seen) == expected, 'Original legal input coverage')
        require(all(len(v) == 1 for v in seen.values()), 'Original response/private memory not unique')
    view = {'states': sorted(reachable), 'starts': starts, 'edges': edges,
            'env_justice': [], 'sys_justice': []}
    for owner, key in [('ENV', 'env_justice'), ('SYS', 'sys_justice')]:
        view[key] = [[sid for sid in sorted(reachable)
                      if bdd.evaluate(justice, context.bits(index[sid]['valuation']))]
                     for justice in context.justices[owner]]
    save(output / 'derived_original_graph.json', view)
    fairness = analyze_graph(view)
    save(output / 'derived_original_fairness.json', fairness)
    certificate['native_graph'] = {'states': len(nodes), 'edges': len(flat),
                                   'initial_states': len(starts), 'sha256': sha(directory / 'controller.json'),
                                   'printed_sha256': sha(printed)}
    certificate['original_view_mapping'] = {
        'status': 'PASS', 'definition': definition, 'states': len(reachable), 'edges': len(edges),
        'initial_states': len(starts), 'original_legal_input_checks': checked,
        'original_initial_ENV_choices': len(legal_initial), 'edge_or_memory_repair': False,
        'raw_native_ids_retained': True, 'all_logical_AUX_retained': True}
    certificate['derived_fairness'] = fairness
    certificate['derived_original_graph_sha256'] = sha(output / 'derived_original_graph.json')
    certificate['status'] = 'COMPLETE_DERIVED_ORIGINAL_CERTIFICATE'


def check(directory, fixture, profiles_path, expected_profile_sha256, output):
    certificate = {'schema': 'experimental-extractor-job-certificate-v1', 'fixture_id': fixture,
                   'native_outcome': None, 'status': 'UNKNOWN_ORIGINAL_MAPPING',
                   'checker_sha256': sha(Path(__file__)), 'BDD_core_sha256': sha(CODE_DIR / 'bdd_core.py'),
                   'SCC_core_sha256': sha(CODE_DIR / 'graph_fairness.py'),
                   'derived_fairness': None, 'GUI_execution': False}
    try:
        require(type(expected_profile_sha256) is str
                and re.fullmatch('[0-9a-f]{64}', expected_profile_sha256) is not None,
                'Explicit profile hash required')
        profiles = read_json(profiles_path)
        require(sha(profiles_path) == expected_profile_sha256, 'Profile byte identity')
        certificate['original_profiles_sha256'] = expected_profile_sha256
        profile = profiles['profiles'][fixture]
        require(profile['fixture_id'] == fixture and profile['case_id'] == fixture
                and profile['variant'] == 'initializers', 'Original-initializer profile identity')
        result = read_json(directory / 'result.json')
        certificate['native_result_sha256'] = sha(directory / 'result.json')
        certificate['native_outcome'] = result.get('status')
        require(result['fixture_id'] == fixture and result['case_id'] == fixture
                and result['variant'] == 'initializers', 'Native result identity')
        require(result.get('input_sha256') == profile['source']['sha256'], 'Native input hash')
        require(result.get('initializers_replaced') is False
                and result.get('semantic_reduction_used') is False
                and result.get('ENV_justice_normalization_used') is False, 'Job scope settings')
        require(result['native_solver_calls'] == 1, 'Exactly one native solver call')
        if result.get('status', '').startswith('UNKNOWN_'):
            certificate['status'] = 'UNKNOWN_NATIVE_PIPELINE'
            certificate['native_exception'] = result.get('exception')
            return certificate
        require(result.get('teardown') == 'COMPLETED', 'Native teardown')
        context, model = audit_model(directory, result, profile, certificate)
        if result['status'] == 'JOB_UNREALIZABLE_NO_CONTROLLER':
            require(result['native_initial_verdict'] is False
                    and result['memory_empty_guard_called'] is False, 'False verdict short circuit')
            require(result['controller_extraction_calls'] == 0 and result['native_printer_calls'] == 0,
                    'No extractor/printer on false verdict')
            certificate['status'] = 'COMPLETE_NO_CONTROLLER'
            certificate['original_view_mapping'] = {'status': 'NOT_RETURNED'}
        elif result['status'] == 'JOB_EMPTY_MEMORY_NO_CONTROLLER':
            require(result['native_initial_verdict'] is True
                    and result['memory_empty_guard_called'] is True
                    and result['memory_empty'] is True, 'Memory guard short circuit')
            require(result['controller_extraction_calls'] == 0 and result['native_printer_calls'] == 0,
                    'No extractor/printer on empty memory')
            certificate['status'] = 'COMPLETE_NO_CONTROLLER'
            certificate['original_view_mapping'] = {'status': 'NOT_RETURNED'}
        elif result['status'] == 'JOB_CONTROLLER_PRINTED':
            require(result['native_initial_verdict'] is True
                    and result['memory_empty_guard_called'] is True
                    and result['memory_empty'] is False
                    and result['memory_complete'] is True, 'Released extraction gate')
            require(result['controller_extraction_calls'] == 1 and result['native_printer_calls'] == 1,
                    'Exactly one extraction/printer')
            certify_graph(directory, result, profile, context, model, certificate, output)
        else:
            raise Invalid('Unsupported native outcome')
    except (Invalid, KeyError, ValueError, TypeError, OSError, UnicodeError, ResourceRefusal) as error:
        certificate['mapping_error'] = str(error)
        certificate['traceback'] = traceback.format_exc()
        certificate['status'] = 'UNKNOWN_ORIGINAL_MAPPING'
    return certificate


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run_dir', type=Path)
    parser.add_argument('fixture')
    parser.add_argument('--profiles', type=Path, required=True)
    parser.add_argument('--profile-sha256', required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args(argv)
    directory = args.run_dir.resolve(strict=True)
    profiles = args.profiles.resolve(strict=True)
    output = args.output_dir.absolute()
    require(directory.is_dir() and not output.exists() and not output.is_symlink(),
            'Fresh output directory required')
    require(output.resolve(strict=False) != directory, 'Output must differ from input directory')
    output.mkdir(parents=False, exist_ok=False)
    certificate = check(directory, args.fixture, profiles, args.profile_sha256, output)
    save(output / 'certificate.json', certificate)
    print(json.dumps({'fixture': args.fixture, 'native_outcome': certificate['native_outcome'],
                      'status': certificate['status'], 'mapping_error': certificate.get('mapping_error')}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
