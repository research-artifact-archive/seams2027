"""Audit an explicitly nonrelease extractor with unchanged production mathematics.

Usage: python -I -S -B audit_variant.py INPUTS.json FRESH_OUTPUT_DIRECTORY
Run only through the separately authorized bounded launcher.
"""
from pathlib import Path
from datetime import datetime, timezone
import importlib.util
import json
import sys
import traceback

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


metadata = load("variant_metadata", HERE.parent / "variant_metadata.py")
checker = load("variant_production_core", HERE / "certify.py")


def main():
    metadata.need(len(sys.argv) == 3, "Usage: audit_variant.py INPUTS.json OUTPUT_DIRECTORY")
    manifest_path, output = Path(sys.argv[1]).absolute(), Path(sys.argv[2]).absolute()
    metadata.need(not output.exists() and not output.is_symlink(), "Fresh absent output directory")
    output.mkdir(exist_ok=False)
    started = datetime.now(timezone.utc).isoformat()
    try:
        manifest = metadata.decode(manifest_path.read_bytes())
        provenance = metadata.validate_manifest(manifest)
        refs = manifest["inputs"]
        process = metadata.decode(metadata.read_pin(refs["native_process"]))
        metadata.need(process["status"] == "PROCESS_COMPLETED" and process["exit_code"] == 0
                      and process["owned_child_reaped"] is True
                      and process["final_group_observation"]["state"] == "ABSENT"
                      and not process["fatal_reasons"] and not process["resource_reasons"]
                      and set(process["capture"]) == {"stdout", "stderr"}
                      and all(v["complete"] is True for v in process["capture"].values()),
                      "Variant process incomplete")
        directory = Path(refs["native_result"]["path"]).parent
        metadata.need(Path(refs["native_result"]["path"]).name == "result.json"
                      and Path(refs["model"]["path"]) == directory / "model.json",
                      "Production file-layout identity")
        result = metadata.decode(metadata.read_pin(refs["native_result"]))
        for key, logical in (("controller_export", "controller"), ("printed_controller", "printer")):
            metadata.need(directory / result[key]["file"] == Path(refs[logical]["path"]),
                          "Production/independent graph file identity")
        for name, ref in manifest["bdd_files"].items():
            metadata.need(directory / name == Path(ref["path"]), "Production/independent BDD file identity")
        certificate = checker.check(directory, manifest["candidate_id"],
                                    Path(refs["profile"]["path"]), refs["profile"]["sha256"], output)
        certificate.update(provenance)
        # Recheck all pins after scientific evaluation; inputs are never rewritten.
        metadata.validate_manifest(manifest)
        exit_code = 0 if certificate["status"].startswith("COMPLETE_") else 2
    except BaseException as error:
        certificate = {"schema": "experimental-extractor-job-certificate-v1",
                       "status": "UNKNOWN_EXPERIMENTAL_ORIGINAL_MAPPING",
                       "nonrelease_extractor": True, "error": str(error),
                       "exception_type": type(error).__name__, "traceback": traceback.format_exc()}
        exit_code = 2
    certificate.update(started_utc=started, finished_utc=datetime.now(timezone.utc).isoformat(),
                       input_manifest_pin=metadata.pin(manifest_path),
                       wrapper_pin=metadata.pin(Path(__file__)),
                       metadata_adapter_pin=metadata.pin(HERE.parent / "variant_metadata.py"))
    with (output / "certificate.json").open("x") as stream:
        json.dump(certificate, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({k: certificate[k] for k in
                     ("status", "fixture_id", "extractor_variant", "nonrelease_extractor", "error")
                     if k in certificate}))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
