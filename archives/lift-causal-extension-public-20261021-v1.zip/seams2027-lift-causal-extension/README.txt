Lift T causal comparison and executed modeled adaptation

This separately versioned addendum contains saved evidence from the Lift T
diagnosis, a single experimental extraction intervention, six prespecified
native-success controls, and one completed in-process adaptation episode.
The previous three archives and their eleven-candidate population are unchanged.

Reading order
1. CLAIM_TO_FILE_INDEX.json gives exact paths and expected saved results.
2. evidence/CAUSAL_COMPARISON_CLOSURE.json and the complete paired graph/audit
   files support the fixed-instance extraction-selection conclusion.
3. evidence/PRESPECIFIED_SUCCESS_CONTROLS.json and SUCCESS_CONTROLS_RESULT.json
   retain all six controls. The preference refined zero candidates in them.
4. evidence/adaptation_episode_04 contains the completed episode and independent
   audit. Episodes 01, 02 and 03 and their follow-up records retain failed attempts.
5. ORIGINAL_COPY_LEDGER.json distinguishes archived execution identities from
   distributed path-sanitized bytes. OMISSIONS.json discloses bulk logs,
   upstream-derived sources and producer bytecode that are not distributed.

Recompute saved semantics with Python 3.10 or newer

First restore the exact upstream-derived source files into a new directory:

  python3 -I -S -B source_restoration/fetch_lift_causal_sources.py \
    --output-root ../lift-causal-sources --cache ../lift-source-cache

Then use a fresh output directory:

  python3 -I -S -B consumer/replay.py --bundle . \
    --sources ../lift-causal-sources --out ../lift-causal-replay

Keep the source, cache and replay-output directories outside the extracted
bundle, as in these examples. The bundle integrity check refuses extra files.

The source helper uses two hash-pinned upstream downloads and Python's standard
library. It reconstructs seven candidate specifications, the maintenance
specification and six Java sources. It neither compiles nor runs Java.
The same files can be restored from a previously populated verified cache.
Third-party material keeps its original publisher's terms.

Expected final status: PASS_SAVED_SEMANTICS_REPLAY.
The replay recomputes the raw finite-set 4FP region, checks all 28 observed
X/Y/Z/win sets, runs two mathematical graph checks on each of sixteen saved
arms (seven paired cases and the episode's fresh pair), and replays the saved
episode events against source predicates and actual saved controller edges.
The complete original-contract Lift graphs are 154 states/1170 edges with
strict=true/cooperation=false before the intervention, and 154/1176 with both
true afterward. All six dormant controls remain strict and cooperative.

What this replay establishes

The scientific graph/model/recurrence/episode algorithms are copied unchanged.
The portable consumer adapts input locations and serialization/hash references.
It verifies every distributed byte, every reconstructed source byte, the
original/copy ledger, and consistency of archived producer records. Its
production-checker views change only path and digest metadata, never controller
states, edges, ranks, AUX values, formulas or ordered justices.

Actual producer class bytes are not included, rebuilt or executed. Class hashes,
process completion, same-memory-object observations and in-process BDD-equality
receipts remain archived producer evidence. A successful saved-semantics replay
does not recreate that producer or prove its invocation. It launches no JVM,
native solver, controller extractor or episode implementation. The semantic
results and this provenance boundary are reported separately.

Limits

The continuation preference is experimental and supported for this Lift
instance; this is not a generally correct nonconflicting synthesis algorithm.
The six controls do not exercise an active refinement. The adaptation episode
is a constructed in-process model at a paused, initial-compatible boundary,
using a prefix selected from a known failure. It does not demonstrate hardware
deployment, arbitrary-state migration, held-out generalization or timing
performance. One executed fair lasso is an existential runtime witness; the
complete graph checks provide their separate universal judgments.

This is selected saved evidence, not the complete raw execution record.
Large repetitive process streams are omitted with exact byte counts and hashes.
No separate public full-log asset is currently supplied. All failed attempts
and their process/result summaries remain visible. Native regeneration is not
a supported entry point: the complete pinned upstream runtime/classpath and
toolchain would have to be supplied and qualified separately.

The consumer uses a 120-second wall limit for each core/memory phase and a
180-second limit for each graph/episode phase. A limit or incomplete result is
reported as failure/unknown, never a pass. These reader wall limits do not
recreate the original process-group memory measurements.
