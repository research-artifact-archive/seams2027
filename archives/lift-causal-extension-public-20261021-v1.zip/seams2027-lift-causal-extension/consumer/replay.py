#!/usr/bin/env python3
"""Recompute saved semantics with Python only; never invoke the producer."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import copy
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import traceback

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


io = load("portable_io", HERE / "portable_io.py")


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def compact(value):
    return (json.dumps(value, ensure_ascii=False, separators=(",", ":")) + "\n").encode()


def public_view(resolver, directory, destination):
    """Adapt only paths/serialization digests for the unchanged production API."""
    directory = Path(directory)
    destination.mkdir()
    for path in directory.glob("*.bdd"):
        shutil.copyfile(path, destination / path.name)
    model_raw = (directory / "model.json").read_bytes()
    model = json.loads(model_raw)
    graph = json.loads((directory / "controller.json").read_bytes())
    result = json.loads((directory / "result.json").read_bytes())
    original_nodes, original_edges = copy.deepcopy(graph["nodes"]), copy.deepcopy(graph["edges"])
    graph["model_sha256"] = sha(model_raw)
    graph_raw = compact(graph)
    result["model_export"].update(bytes=len(model_raw), sha256=sha(model_raw))
    result["controller_export"].update(bytes=len(graph_raw), sha256=sha(graph_raw))
    result["controller_before_print_sha256"] = sha(graph_raw[:-1])
    result["controller_after_print_sha256"] = sha(graph_raw[:-1])
    assert graph["nodes"] == original_nodes and graph["edges"] == original_edges
    (destination / "model.json").write_bytes(model_raw)
    (destination / "controller.json").write_bytes(graph_raw)
    (destination / "result.json").write_bytes(compact(result))
    shutil.copyfile(directory / "controller.txt", destination / "controller.txt")
    return {
        "model": "Public copy unchanged; only its input path label differs from the archived producer bytes.",
        "graph_modified_fields": ["model_sha256"],
        "result_modified_fields": ["model_export.bytes", "model_export.sha256",
                                   "controller_export.bytes", "controller_export.sha256",
                                   "controller_before_print_sha256", "controller_after_print_sha256"],
        "graph_nodes_edges_ranks_AUX_unchanged": True,
        "model_fields_relations_justice_order_unchanged": True,
        "view_files": [io.actual_pin(destination / x) for x in
                       ("model.json", "controller.json", "result.json", "controller.txt")],
    }


def graph_worker(resolver, task, output):
    bundle = resolver.bundle
    pair = bundle / task["directory"]
    arm = task["arm"]
    variant = arm == "variant"
    manifest_path = pair / ("variant_inputs.json" if variant else "baseline_inputs.json")
    manifest = resolver.json(manifest_path)
    directory = pair / ("variant" if variant else "native")
    code = (bundle / "evidence/variant_audit" if variant else bundle / "code/released")
    independent = load("reader_independent", code / "independent/audit_worker.py")
    independent.read_pin = resolver.read_pin
    independent.pin = resolver.pin
    if variant:
        meta = load("reader_portable_metadata", HERE / "portable_variant_metadata.py")
        meta.read_pin = resolver.read_pin
        meta.pin = resolver.pin
        meta.record_class_attestation = resolver.class_attestation
        independent._variant_metadata = meta
    summary, view = independent.audit(manifest)
    save(output / "independent.json", summary)
    save(output / "independent_view.json", view)
    view_directory = output / "production_view"
    transform = public_view(resolver, directory, view_directory)
    production = load("reader_production", code / "production/certify.py")
    production_output = output / "production"
    production_output.mkdir()
    profile = bundle / "support/ORIGINAL_PROFILES.json"
    certificate = production.check(view_directory, manifest["candidate_id"],
                                   profile, sha(profile.read_bytes()), production_output)
    save(production_output / "certificate.json", certificate)
    if not certificate["status"].startswith("COMPLETE_"):
        raise ValueError("Production semantic recheck incomplete: " + str(certificate))
    a = [summary["original_view"]["states"], summary["original_view"]["edges"],
         summary["independent_strict"], summary["independent_cooperative"]]
    b = [certificate["original_view_mapping"]["states"], certificate["original_view_mapping"]["edges"],
         certificate["derived_fairness"]["strict_liveness"]["pass"],
         certificate["derived_fairness"]["nonconflicting"]["pass"]]
    if a != b:
        raise ValueError("Independent and production semantic rechecks disagree")
    result = {"status": "PASS_BOTH_SAVED_SEMANTIC_CHECKERS_AGREE",
              "candidate": manifest["candidate_id"], "pair": task["id"], "arm": arm,
              "states_edges_strict_cooperative": a,
              "metadata_adapter": transform, "scope": resolver.provenance()}
    save(output / "RESULT.json", result)
    return result


def core_worker(resolver, output):
    bundle = resolver.bundle
    native = bundle / "evidence/runs/baseline_01/native"
    view = output / "native_view"
    transform = public_view(resolver, native, view)
    evaluator = bundle / "code/released/independent/independent_core.py"
    protocol = {
        "native_directory": str(view),
        "saved_DAG_evaluator": io.actual_pin(evaluator),
        "input_pins": [io.actual_pin(p) for p in sorted(view.iterdir())],
    }
    protocol_path = output / "PROTOCOL.json"
    save(protocol_path, protocol)
    code = bundle / "evidence/core_recompute_01/recompute_worker.py"
    module = load("reader_raw_four_fixed_points", code)
    old_argv = sys.argv
    try:
        sys.argv = [str(code), str(protocol_path), str(output / "recomputed")]
        module.main()
    finally:
        sys.argv = old_argv
    result = io.load_json(output / "recomputed/RESULT.json")
    if result["status"] != "PASS_FULL_TYPED_REGION_EQUAL":
        raise ValueError("Raw recurrence recheck did not match")
    saved = resolver.json(bundle / "evidence/core_recompute_01/output/RESULT.json")
    for key in ["computed_region_mask_hex", "native_region_mask_hex", "iterations",
                "final_memory", "typed_state_count", "symmetric_difference_cardinality"]:
        if result[key] != saved[key]:
            raise ValueError("Raw recurrence saved/recomputed difference: " + key)
    result.update(metadata_adapter=transform, producer_scope=resolver.provenance())
    save(output / "RESULT.json", result)
    return result


def memory_worker(resolver, output, core_output):
    bundle = resolver.bundle
    code = bundle / "evidence/core_recompute_01/run_memory_compare.py"
    module = load("reader_memory_comparison", code)
    # Only input locations, output location, pin/read helpers and protocol I/O
    # are rebound. worker() and every membership operation are unmodified.
    module.BASE = Path(core_output)
    module.RUN = output
    module.OBSERVER = bundle / "evidence/runs/paired_observer_02/native"
    module.NATIVE = bundle / "evidence/runs/baseline_01/native"
    original_pin = module.pin
    original_read = module.read

    def mixed_pin(path):
        p = Path(path).resolve()
        if str(p) in resolver.by_path:
            return resolver.pin(p)
        if not (p.is_relative_to(output.resolve()) or p.is_relative_to(Path(core_output).resolve())):
            raise ValueError("Undeclared memory-comparison input outside fresh output")
        return io.actual_pin(p)

    def mixed_read(path):
        p = Path(path).resolve()
        if str(p) in resolver.by_path:
            return resolver.json(p)
        if not (p.is_relative_to(output.resolve()) or p.is_relative_to(Path(core_output).resolve())):
            raise ValueError("Undeclared memory-comparison input outside fresh output")
        return original_read(p)

    module.pin = mixed_pin
    module.read = mixed_read
    evaluator = bundle / "code/released/independent/independent_core.py"
    protocol = {"input_pins": [mixed_pin(p) for p in (
        module.OBSERVER / "paired_observer.json", module.OBSERVER / "model.json",
        module.NATIVE / "model.json", module.NATIVE / "result.json")],
        "saved_DAG_evaluator": mixed_pin(evaluator)}
    save(output / "PROTOCOL.json", protocol)
    module.worker()
    result = io.load_json(output / "WORKER_RESULT.json")
    if result["status"] != "PASS_ALL_OBSERVED_XYZ_AND_WIN_EQUAL":
        raise ValueError("Observed memory recheck did not match")
    native_graph = resolver.json(module.OBSERVER / "controller.json")
    observed_graph = resolver.json(module.OBSERVER / "observer_controller.json")
    left = {k: v for k, v in native_graph.items() if k != "controller_identity"}
    right = {k: v for k, v in observed_graph.items() if k != "controller_identity"}
    if left != right:
        raise ValueError("Saved observer complete graph differs from its paired native graph")
    trace = resolver.json(module.OBSERVER / "observer_trace.json")
    if not (trace["construction_complete"] and trace["complete_for_seen_focused_nodes"]
            and not trace["missing_focused_node_ids"]
            and all(trace[k] == 0 for k in ("dropped_events", "dropped_bdd_references",
                                          "truncated_texts", "focused_nodes_beyond_cap"))):
        raise ValueError("Saved focused observer trace is incomplete")
    result["saved_observer_graph_parity"] = {
        "equal_excluding_only_controller_object_identity": True,
        "states": native_graph["api_state_count"], "edges": native_graph["api_transition_count"],
        "trace_events": len(trace["events"]),
        "trace_scope": "All recorded events for the declared focused nodes; not a trace of every graph node.",
    }
    result["producer_scope"] = resolver.provenance()
    save(output / "RESULT.json", result)
    return result


def episode_worker(resolver, output):
    module_path = resolver.bundle / "evidence/adaptation_episode_04/independent/audit_episode.py"
    old_argv = sys.argv
    try:
        sys.argv = [str(module_path)]
        module = load("reader_episode_audit", module_path)
    finally:
        sys.argv = old_argv
    episode = resolver.bundle / "evidence/adaptation_episode_04"
    module.HERE = episode
    module.CONTRACT_PATH = resolver.bundle / "code/released/independent/source_contracts.py"
    module.pin = resolver.pin
    module.read = resolver.json
    original_check = module.Audit.check_pin
    original_load = module.Audit.load

    def check_pin(self, ref):
        resolver.read_pin(ref)
        actual = resolver.pin(ref["path"])
        self.need(actual == ref, "historical pin mismatch", "pins")
        self.read_pins[actual["path"]] = actual
        return Path(actual["path"])

    module.Audit.check_pin = check_pin
    # events are read directly with Path.read_text by setup(). Supply a separate
    # relocated JSONL view while preserving the original pin through the resolver.
    event = episode / "execution/EVENTS.jsonl"
    event_row = resolver.row(event)
    relocated = output / "EVENTS.relocated.jsonl"
    raw = b"".join(compact(resolver.relocate(json.loads(line)))
                   for line in event.read_text().splitlines())
    relocated.write_bytes(raw)
    replacement = dict(event_row, path=str(relocated.resolve()),
                       new_bytes=len(raw), new_sha=sha(raw), kind="relocated_event_view")
    resolver.by_origin[event_row["origin"]] = replacement
    resolver.by_path[str(relocated.resolve())] = replacement
    resolver.by_path[str(event.resolve())] = replacement
    auditor = module.Audit()
    auditor.run()
    auditor.report["checks"] = dict(auditor.counts)
    auditor.report["status"] = "PASS_SAVED_EPISODE_SEMANTICS_AND_ARCHIVED_RECORD_CONSISTENCY"
    auditor.report["consumer_scope"] = resolver.provenance()
    auditor.report["episode_implementation_executed"] = False
    auditor.report["new_full_graph_checks"] = "Both graph mathematics are independently rerun for the episode's saved pair by the graph phase."
    save(output / "RESULT.json", auditor.report)
    return auditor.report


def worker(args):
    output = Path(args.out).resolve()
    output.mkdir()
    resolver = io.Resolver(args.bundle, args.sources)
    task = json.loads(args.worker)
    try:
        if task["kind"] == "graph":
            result = graph_worker(resolver, task, output)
        elif task["kind"] == "core":
            result = core_worker(resolver, output)
        elif task["kind"] == "memory":
            result = memory_worker(resolver, output, task["core_output"])
        elif task["kind"] == "episode":
            result = episode_worker(resolver, output)
        else:
            raise ValueError("Unknown replay phase")
        print(json.dumps({"status": result["status"], "task": task}))
        return 0
    except BaseException as exc:
        failure = {"status": "FAIL_OR_UNKNOWN_SAVED_REPLAY", "task": task,
                   "error": type(exc).__name__ + ": " + str(exc), "traceback": traceback.format_exc(),
                   "native_runs": 0}
        save(output / "FAILURE.json", failure)
        print(json.dumps(failure))
        return 2


def run_phase(args, root, name, task, seconds):
    destination = root / name
    command = [sys.executable, "-I", "-S", "-B", str(Path(__file__).resolve()),
               "--bundle", str(Path(args.bundle).resolve()), "--sources", str(Path(args.sources).resolve()),
               "--out", str(destination), "--worker", json.dumps(task, separators=(",", ":"))]
    started = datetime.now(timezone.utc).isoformat()
    try:
        process = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 timeout=seconds, check=False)
        stdout, stderr, code = process.stdout, process.stderr, process.returncode
        status = "COMPLETED" if code == 0 else "FAILED"
    except subprocess.TimeoutExpired as exc:
        stdout, stderr, code, status = exc.stdout or b"", exc.stderr or b"", None, "UNKNOWN_WALL_LIMIT"
    if len(stdout) + len(stderr) > 8 * 1024 * 1024:
        raise ValueError("Replay stream budget exceeded")
    (root / (name + ".stdout.txt")).write_bytes(stdout)
    (root / (name + ".stderr.txt")).write_bytes(stderr)
    receipt = {"phase": name, "status": status, "returncode": code, "wall_seconds_limit": seconds,
               "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(),
               "Python": sys.version, "Java_processes": 0, "task": task}
    save(root / (name + ".process.json"), receipt)
    if code != 0:
        raise RuntimeError("Replay phase failed: " + name + "; inspect its FAILURE.json and process log")
    return io.load_json(destination / "RESULT.json")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--sources", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--worker", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker:
        return worker(args)
    output = args.out.resolve()
    if output.exists() or output.is_symlink():
        raise ValueError("Output directory must be fresh")
    io.Resolver(args.bundle, args.sources)
    output.mkdir()
    plan = io.load_json(args.bundle / "REPLAY_INPUTS.json")
    results = {}
    try:
        results["core"] = run_phase(args, output, "core", {"kind": "core"}, 120)
        # The unmodified memory worker expects BASE/output/RESULT.json.
        memory_base = output / "memory_inputs"
        memory_base.mkdir()
        shutil.copytree(output / "core/recomputed", memory_base / "output")
        results["memory"] = run_phase(args, output, "memory",
                                     {"kind": "memory", "core_output": str(memory_base)}, 120)
        results["graphs"] = []
        for pair in plan["pairs"]:
            for arm in ("baseline", "variant"):
                task = dict(pair, kind="graph", arm=arm)
                result = run_phase(args, output, pair["id"] + "__" + arm, task, 180)
                results["graphs"].append(result)
        results["episode"] = run_phase(args, output, "episode", {"kind": "episode"}, 180)
        target = [x for x in results["graphs"] if x["candidate"] == "lift__trivial_1"]
        for row in target:
            expected = plan["expected"]["lift_variant" if row["arm"] == "variant" else "lift_original"]
            if row["states_edges_strict_cooperative"] != expected:
                raise ValueError("Lift result differs from declared expected semantics")
        controls = [x for x in results["graphs"] if x["candidate"] != "lift__trivial_1"]
        if len(controls) != 12 or not all(x["states_edges_strict_cooperative"][2:] == [True, True] for x in controls):
            raise ValueError("Dormant control result differs")
        archived_controls = io.load_json(args.bundle / "evidence/SUCCESS_CONTROLS_RESULT.json")
        if (archived_controls["pass_count"] != 6 or archived_controls["failure_count"] != 0
                or archived_controls["unknown_count"] != 0
                or not all(x["intervention_observation"]["refined_candidates"] == 0
                           for x in archived_controls["rows"])):
            raise ValueError("Archived six-control dormant-refinement record differs")
        receipt = {"status": "PASS_SAVED_SEMANTICS_REPLAY", "graph_arms": 16,
                   "mathematical_graph_checker_runs": 32, "raw4fp_recomputations": 1,
                   "memory_sets_compared": results["memory"]["memory_sets_compared"],
                   "episode_event_replays": 1, "native_solver_runs": 0, "Java_processes": 0,
                   "controller_extractions": 0, "episode_executions": 0,
                   "producer_identity_recreated": False,
                   "scope": "Saved source/model/controller and event semantics are recomputed. Archived producer/runtime/process/class evidence is consistency-checked only; no new producer was run.",
                   "results": results}
    except BaseException as exc:
        receipt = {"status": "FAIL_OR_UNKNOWN_SAVED_SEMANTICS_REPLAY",
                   "error": type(exc).__name__ + ": " + str(exc),
                   "completed_results": results, "native_solver_runs": 0, "Java_processes": 0}
    save(output / "REPLAY_RESULT.json", receipt)
    print(json.dumps({k: v for k, v in receipt.items() if k not in ("results", "completed_results")}))
    return 0 if receipt["status"] == "PASS_SAVED_SEMANTICS_REPLAY" else 2


if __name__ == "__main__":
    raise SystemExit(main())
