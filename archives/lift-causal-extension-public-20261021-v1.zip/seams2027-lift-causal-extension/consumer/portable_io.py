"""Explicit original/copy identity resolver for saved evidence.

Historical pins attest to the original bytes; the manifest separately verifies
the distributed bytes. This module never claims those two serializations have
the same digest. No path outside the verified bundle or restored-source tree
is read as a fallback.
"""
from pathlib import Path, PurePosixPath
import hashlib
import json


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load_json(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Duplicate JSON key: " + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique)


def safe_relative(name):
    path = PurePosixPath(name)
    if not name or path.is_absolute() or ".." in path.parts or "\\" in name or str(path) != name:
        raise ValueError("Unsafe relative member: " + name)
    return path


def actual_pin(path):
    path = Path(path).resolve(strict=True)
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": sha(raw)}


def verify_tree(bundle):
    bundle = Path(bundle).resolve(strict=True)
    manifest = load_json(bundle / "MANIFEST.json")
    if manifest["schema"] != "lift-causal-extension-public-manifest-v1":
        raise ValueError("Unexpected bundle manifest")
    declared = set()
    for row in manifest["files"]:
        relative = safe_relative(row["path"])
        if row["path"] in declared:
            raise ValueError("Duplicate manifest member")
        declared.add(row["path"])
        path = bundle.joinpath(*relative.parts)
        if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(bundle):
            raise ValueError("Missing/nonregular bundle member")
        if row["bytes"] > 16 * 1024 * 1024:
            raise ValueError("Individual input exceeds 16 MiB")
        raw = path.read_bytes()
        if len(raw) != row["bytes"] or sha(raw) != row["sha256"]:
            raise ValueError("Bundle content mismatch: " + row["path"])
    actual = {p.relative_to(bundle).as_posix() for p in bundle.rglob("*") if p.is_file()}
    if actual != declared | {"MANIFEST.json"}:
        raise ValueError("Unexpected or absent files in the bundle")
    return manifest


class Resolver:
    def __init__(self, bundle, sources):
        self.bundle = Path(bundle).resolve(strict=True)
        verify_tree(self.bundle)
        self.sources = Path(sources).resolve(strict=True)
        self.by_origin = {}
        self.by_path = {}
        self.class_attestations = []
        ledger = load_json(self.bundle / "ORIGINAL_COPY_LEDGER.json")
        for row in ledger["files"]:
            path = self.bundle / safe_relative(row["member"])
            self.register(row["origin"], path, row["original_bytes"], row["original_sha256"],
                          row["public_bytes"], row["public_sha256"], "verified_public_copy")
        manifest = load_json(self.bundle / "source_restoration/LIFT_CAUSAL_SOURCE_FETCH_MANIFEST.json")
        for row in manifest["outputs"]:
            path = self.sources / safe_relative(row["path"])
            if not path.resolve(strict=True).is_relative_to(self.sources):
                raise ValueError("Restored source escapes the declared source directory")
            raw = path.read_bytes()
            if len(raw) != row["bytes"] or sha(raw) != row["sha256"] or path.is_symlink():
                raise ValueError("Restored source identity mismatch: " + row["path"])
            origins = row.get("origins", [])
            if "origin" in row:
                origins = origins + [row["origin"]]
            if "historical_source_identity" in row:
                origins = origins + [row["historical_source_identity"]["origin"]]
            for origin in origins:
                self.register(origin, path, row["bytes"], row["sha256"],
                              row["bytes"], row["sha256"], "exact_restored_source")
        self.omissions = {r["origin"]: r for r in load_json(self.bundle / "OMISSIONS.json")["files"]}

    def register(self, origin, path, old_bytes, old_sha, new_bytes, new_sha, kind):
        row = {"origin": origin, "path": str(path.resolve()),
               "old_bytes": old_bytes, "old_sha": old_sha,
               "new_bytes": new_bytes, "new_sha": new_sha, "kind": kind}
        if origin in self.by_origin and self.by_origin[origin] != row:
            raise ValueError("Conflicting origin mapping: " + origin)
        self.by_origin[origin] = row
        # Multiple historical maintenance attempts can resolve to one exact source.
        self.by_path.setdefault(row["path"], row)

    def row(self, path):
        key = str(path)
        if key in self.by_origin:
            return self.by_origin[key]
        resolved = str(Path(key).resolve())
        if resolved not in self.by_path:
            raise ValueError("No declared origin/copy mapping: " + key)
        return self.by_path[resolved]

    def path(self, name):
        return Path(self.row(name)["path"])

    def check_copy(self, row):
        path = Path(row["path"])
        if path.is_symlink() or not path.is_file():
            raise ValueError("Nonregular input copy")
        raw = path.read_bytes()
        if len(raw) != row["new_bytes"] or sha(raw) != row["new_sha"]:
            raise ValueError("Verified public copy changed: " + row["origin"])
        return raw

    def pin(self, path):
        row = self.row(path)
        self.check_copy(row)
        return {"path": row["path"], "bytes": row["old_bytes"], "sha256": row["old_sha"]}

    def read_pin(self, ref):
        if not isinstance(ref, dict) or set(ref) != {"path", "bytes", "sha256"}:
            raise ValueError("Exact historical pin shape required")
        row = self.row(ref["path"])
        if (ref["bytes"], ref["sha256"]) != (row["old_bytes"], row["old_sha"]):
            raise ValueError("Historical pin does not match original/copy ledger")
        raw = self.check_copy(row)
        if Path(row["path"]).suffix == ".json":
            value = json.loads(raw)
            relocated = self.relocate(value)
            if relocated != value:
                return (json.dumps(relocated, ensure_ascii=False, separators=(",", ":")) + "\n").encode()
        return raw

    def relocate(self, value):
        if isinstance(value, str):
            if value in self.by_origin:
                return self.by_origin[value]["path"]
            if "origin:" not in value:
                return value
            # Only substitute declared roots inside recorded argv/classpaths.
            for origin in sorted(self.by_origin, key=len, reverse=True):
                if origin in value:
                    value = value.replace(origin, self.by_origin[origin]["path"])
            return value
        if isinstance(value, list):
            return [self.relocate(x) for x in value]
        if isinstance(value, dict):
            return {self.relocate(k): self.relocate(v) for k, v in value.items()}
        return value

    def json(self, path):
        row = self.row(path)
        return self.relocate(json.loads(self.check_copy(row)))

    def class_attestation(self, ref):
        name = ref["path"]
        row = self.omissions.get(name)
        if row is None or row["kind"] != "producer_bytecode":
            raise ValueError("Class absent from explicit bytecode omission ledger")
        if (row["bytes"], row["sha256"]) != (ref["bytes"], ref["sha256"]):
            raise ValueError("Recorded class identity mismatch")
        self.class_attestations.append({
            "origin": name, "bytes": row["bytes"], "sha256": row["sha256"],
            "scope": "Archived producer class hash only; actual bytecode not read, rebuilt or executed.",
        })

    def provenance(self):
        return {
            "public_bytes_verified": True,
            "restored_source_bytes_verified": True,
            "original_copy_identities": "Historical pins matched through the explicit original/copy ledger; public-path serialization has separate hashes.",
            "producer_scope": "Archived process, runtime, same-object and in-process equality observations were inspected for consistency, not regenerated.",
            "actual_producer_class_bytes_verified": False,
            "Java_processes": 0, "native_solver_runs": 0, "controller_extractions": 0,
            "episode_executions": 0,
            "class_attestations": self.class_attestations,
        }
