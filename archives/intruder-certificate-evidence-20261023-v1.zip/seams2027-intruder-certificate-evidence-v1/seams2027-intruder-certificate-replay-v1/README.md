# Intruder saved-certificate replay

This package contains the complete original-model obstruction and the G-repaired
strategy certificate, their exact source/import files, independent Python
checkers, exhaustive finite semantic qualifiers, and local rejection controls.
It requires Python 3.10 or later on POSIX macOS/Linux and only its standard
library. No network, Java, native solver, C++ build, or pip install is required.

Run from this archive's root, after creating a fresh sibling
`../intruder-replay-results` directory outside the immutable kit. Preserve
the folder hierarchy. The commands below are sequential; use an appropriate
external resource supervisor. Retained internal 150-second limits must yield
unverified/failure reports rather than be interpreted as a contrary theorem.
Existing result files are refused. `REPLAY_PLAN.json` records expected statuses.

The first four commands qualify finite source semantics and check both complete
certificates. The last two run local negative controls and write about 360 MiB of
temporary fixture data. They are not substitutes for the full certificate check.

```sh
python3 -I -S -B experiment/v53_intruder_cooperativity_diagnosis_20261022/source_certificate_01/qualify_verifier_semantics.py --out ../intruder-replay-results/ORIGINAL_SEMANTICS.json
```

```sh
python3 -I -S -B experiment/v53_intruder_cooperativity_diagnosis_20261022/source_certificate_01/verify_certificate.py --certificate-dir experiment/v53_intruder_cooperativity_diagnosis_20261022/source_certificate_02/candidate_01 --source experiment/v48_comparative_improvement_20261021/native355/inputs/1673286053.spectra --import-source experiment/v48_comparative_improvement_20261021/native355/inputs/imports/DwyerPatterns.spectra --out ../intruder-replay-results/ORIGINAL_CERTIFICATE.json
```

```sh
python3 -I -S -B experiment/v54_intruder_minimal_spec_repair_20261022/source_game_02/qualify_candidate_semantics.py --out ../intruder-replay-results/REPAIRED_SEMANTICS.json
```

```sh
python3 -I -S -B experiment/v54_intruder_minimal_spec_repair_20261022/source_game_02/verify_candidate_certificate.py --candidate-id deadend_stay_both --source experiment/v54_intruder_minimal_spec_repair_20261022/deadend_stay_01/candidate/1673286053.spectra --import-source experiment/v54_intruder_minimal_spec_repair_20261022/deadend_stay_01/candidate/imports/DwyerPatterns.spectra --semantic-profile experiment/v54_intruder_minimal_spec_repair_20261022/source_game_02/CANDIDATE_SEMANTIC_PROFILE.json --certificate-dir experiment/v54_intruder_minimal_spec_repair_20261022/source_game_execution_02/deadend_stay_both_01/certificate --out ../intruder-replay-results/REPAIRED_CERTIFICATE.json
```

```sh
python3 -I -S -B experiment/v53_intruder_cooperativity_diagnosis_20261022/source_certificate_01/test_certificate_rejections.py --certificate-dir experiment/v53_intruder_cooperativity_diagnosis_20261022/source_certificate_02/candidate_01 --verification-result ../intruder-replay-results/ORIGINAL_CERTIFICATE.json --fixtures-dir ../intruder-replay-results/fixtures_original --out ../intruder-replay-results/ORIGINAL_REJECTIONS.json
```

```sh
python3 -I -S -B experiment/v54_intruder_minimal_spec_repair_20261022/source_game_02/test_candidate_rejections.py --candidate-id deadend_stay_both --certificate-dir experiment/v54_intruder_minimal_spec_repair_20261022/source_game_execution_02/deadend_stay_both_01/certificate --verification-result ../intruder-replay-results/REPAIRED_CERTIFICATE.json --qualification-result ../intruder-replay-results/REPAIRED_SEMANTICS.json --source experiment/v54_intruder_minimal_spec_repair_20261022/deadend_stay_01/candidate/1673286053.spectra --import-source experiment/v54_intruder_minimal_spec_repair_20261022/deadend_stay_01/candidate/imports/DwyerPatterns.spectra --semantic-profile experiment/v54_intruder_minimal_spec_repair_20261022/source_game_02/CANDIDATE_SEMANTIC_PROFILE.json --fixtures-dir ../intruder-replay-results/fixtures_repaired --out ../intruder-replay-results/REPAIRED_REJECTIONS.json
```

The original certificate labels 276,829 states and certifies the joint
strict/cooperative obstruction for the allowed initializer (0,7). It does not
claim strict-only unrealizability or that all eight initializers lose. The G
certificate labels 407,172 states and covers all eight original initializers;
unlabelled states and complete winning-region computation are not classified.
The exact G repair is an intermediate-snapshot deadend-stay repair, not a
verification of the complete original physical task or preference superiority.

Four binary payloads, all Spectra source/import bytes, all mathematical Python
functions, quantifiers and loops are unchanged. `TRANSFORMATIONS.json` identifies
the location-only profile changes and expected-pin updates. Original identity
hashes remain available for comparison; fresh results bind delivered identities.
`MANIFEST.json` binds the delivered package. This preparation does not execute
any checker and does not itself establish a fresh relocated replay result.
