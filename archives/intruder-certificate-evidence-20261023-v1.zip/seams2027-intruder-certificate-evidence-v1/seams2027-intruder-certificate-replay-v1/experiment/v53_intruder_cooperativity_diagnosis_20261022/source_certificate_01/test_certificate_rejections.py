#!/usr/bin/env python3
"""Bounded rejection controls for the exact frozen original-source verifier.

Run only under the root-owned bounded dispatcher. This is a local rejection
test, not another full proof or generator run. The seed must already have a
hash-bound full PASS report. Semantic mutations are saved as complete fresh
certificates with recomputed payload hashes, successfully loaded, then checked
at one designated source (or the selected initializer). No check_all is called.
"""

from __future__ import annotations

import argparse
from array import array
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import sys
import time
from types import ModuleType
import unicodedata


CHECKER_BYTES = 21773
CHECKER_SHA256 = "2c74a8dc80aa4dc86626d4a85f432b4a1268112f7a59538e8780a7907ffdea33"
INTERNAL_SECONDS = 150
MAX_FIXTURE_DIRS = 24
MAX_WRITTEN_BYTES = 512 * 1024 * 1024
MAX_JSON_BYTES = 1024 * 1024
MAX_FAILURE_EXAMPLES = 5
EXPECTED_CASES = 17


class HarnessError(Exception):
    pass


class HarnessTimeout(BaseException):
    """Escapes individual-case handlers; only main may record this stop."""


def need(condition, reason):
    if not condition:
        raise HarnessError(reason)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, "duplicate report JSON key: " + repr(key))
        result[key] = value
    return result


def reject_constant(value):
    raise HarnessError("non-finite report JSON constant: " + value)


def read_regular(path, limit):
    path = Path(path)
    need(not path.is_symlink(), "symlink input refused: " + str(path))
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
    with os.fdopen(os.open(path, flags), "rb") as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_size <= limit,
             "input is not a bounded regular file: " + str(path))
        data = stream.read(limit + 1)
        after = os.fstat(stream.fileno())
        need(len(data) == before.st_size and len(data) <= limit,
             "incomplete or excessive input read: " + str(path))
        fields = lambda item: (item.st_dev, item.st_ino, item.st_size,
                               item.st_mtime_ns, item.st_ctime_ns)
        need(fields(before) == fields(after), "input changed during read: " + str(path))
    return data


def pin(path, data):
    return {"path": str(Path(path).absolute()), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def path_key(path):
    return unicodedata.normalize("NFC", str(Path(path).resolve()))


def pin_key(record):
    need(type(record) is dict and type(record.get("path")) is str and
         type(record.get("bytes")) is int and record["bytes"] >= 0 and
         type(record.get("sha256")) is str and len(record["sha256"]) == 64,
         "malformed pin record")
    return path_key(record["path"]), record["bytes"], record["sha256"]


def json_bytes(value):
    raw = (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()
    need(len(raw) <= MAX_JSON_BYTES, "JSON exceeds 1 MiB bound")
    return raw


def load_checker():
    path = Path(__file__).resolve().with_name("verify_certificate.py")
    raw = read_regular(path, 256 * 1024)
    record = pin(path, raw)
    need((record["bytes"], record["sha256"]) == (CHECKER_BYTES, CHECKER_SHA256),
         "frozen verifier pin mismatch")
    # Execute precisely the pinned bytes, without a second path read or pyc.
    sys.dont_write_bytecode = True
    module = ModuleType("frozen_v53_certificate_verifier_for_rejection_controls")
    module.__file__ = str(path)
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module, record


class FixtureStore:
    def __init__(self, root):
        self.root = root
        root.mkdir(mode=0o755, parents=False, exist_ok=False)
        self.written = 0
        self.directories = 0
        self.pins = []

    def write(self, path, data):
        need(self.written + len(data) <= MAX_WRITTEN_BYTES, "fixture disk bound exceeded")
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
        with os.fdopen(os.open(path, flags, 0o644), "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        self.written += len(data)
        expected = pin(path, data)
        actual = pin(path, read_regular(path, max(len(data), 1)))
        need(expected == actual, "fresh fixture readback mismatch")
        self.pins.append(actual)
        return actual

    def create(self, name, manifest, ranks, actions, *, raw_manifest=None,
               raw_ranks=None, raw_actions=None, changed_source=None):
        need(self.directories < MAX_FIXTURE_DIRS, "fixture directory bound exceeded")
        directory = self.root / name
        directory.mkdir(mode=0o755, exist_ok=False)
        self.directories += 1
        payload = array("I", ranks)
        if sys.byteorder != "little":
            payload.byteswap()
        rank_data = payload.tobytes() if raw_ranks is None else raw_ranks
        action_data = bytes(actions) if raw_actions is None else raw_actions
        pins = [self.write(directory / "certificate.json",
                           json_bytes(manifest) if raw_manifest is None else raw_manifest),
                self.write(directory / "ranks.u32le", rank_data),
                self.write(directory / "chosen_env.u8", action_data)]
        source_path = None
        if changed_source is not None:
            source_path = directory / "mutated_source.spectra"
            pins.append(self.write(source_path, changed_source))
        return directory, pins, source_path


def repinned_manifest(seed, ranks, actions, rounds):
    manifest = copy.deepcopy(seed)
    manifest["completed_outer_rounds"] = rounds
    payload = array("I", ranks)
    if sys.byteorder != "little":
        payload.byteswap()
    for key, filename, raw in (("ranks", "ranks.u32le", payload.tobytes()),
                               ("actions", "chosen_env.u8", bytes(actions))):
        manifest[key] = {"file": filename, "bytes": len(raw),
                         "sha256": hashlib.sha256(raw).hexdigest()}
    return manifest


def expected_rejection(verifier, operation, substring):
    try:
        operation()
    except Exception as exc:
        if type(exc) is verifier.Rejected and substring in str(exc):
            return {"status": "PASS_EXPECTED_REJECTION", "exception_type": "Rejected",
                    "reason": str(exc)[:4096], "expected_reason_substring": substring}
        return {"status": "FAIL_WRONG_REJECTION", "exception_type": type(exc).__name__,
                "reason": str(exc)[:4096], "expected_reason_substring": substring}
    return {"status": "FAIL_UNEXPECTED_ACCEPTANCE", "expected_reason_substring": substring}


def run(args, result):
    verifier, checker_pin = load_checker()
    certificate_dir = args.certificate_dir.resolve()
    fixture_root = args.fixtures_dir.absolute()
    need(not fixture_root.exists() and not fixture_root.is_symlink(), "fixtures path must be fresh")
    need(not fixture_root.resolve().is_relative_to(certificate_dir),
         "fixtures directory must be outside the original certificate")
    report_raw = read_regular(args.verification_result, MAX_JSON_BYTES)
    report_pin = pin(args.verification_result, report_raw)
    report = json.loads(report_raw, object_pairs_hook=unique_object, parse_constant=reject_constant)
    need(type(report) is dict and report.get("schema") ==
         "v53-original-source-countercertificate-verification-v1" and
         report.get("status") == verifier.PASS_STATUS, "seed report must be a full verifier PASS")
    need(pin_key(report.get("verifier_pin")) == pin_key(checker_pin),
         "PASS report uses a different verifier")
    report_pins = report.get("input_pins")
    need(type(report_pins) is list and len(report_pins) == 5, "PASS report must bind five inputs")
    keys = [pin_key(item) for item in report_pins]
    need(len({item[0] for item in keys}) == 5, "PASS input paths must be unique")

    def reported_path(size, sha):
        matches = [item["path"] for item in report_pins
                   if item["bytes"] == size and item["sha256"] == sha]
        need(len(matches) == 1, "source/import pin is not unique")
        return Path(matches[0])

    source_path = reported_path(verifier.SOURCE_BYTES, verifier.SOURCE_SHA256)
    import_path = reported_path(verifier.IMPORT_BYTES, verifier.IMPORT_SHA256)
    manifest, selected_x, rounds, ranks, actions, input_pins = verifier.load_inputs(
        certificate_dir, source_path, import_path)
    need(set(keys) == {pin_key(item) for item in input_pins},
         "PASS report does not bind these exact original inputs")
    scope = report.get("claim_scope", {})
    need(scope.get("joint_strict_and_all_prefix_cooperation_unrealizable") is True and
         all(scope.get(name) is False for name in
             ("strict_correctness_alone_unrealizable", "all_eight_environment_initializers_losing",
              "generator_fixed_point_completeness_certified")), "unexpected seed proof scope")
    semantics = report.get("source_semantics", {})
    need(semantics.get("id") == verifier.SEMANTICS_ID and
         semantics.get("qualified_by_exact_source_and_import_hashes") is True and
         semantics.get("environment_moves_first") is True and
         semantics.get("history_uses_current_value_for_robot1_move") is True and
         type(semantics.get("original_environment_justice_count")) is int and
         semantics["original_environment_justice_count"] == 0, "wrong source-semantics qualification")
    local = report.get("local_certificate_checks", {})
    need(all(local.get(name) is True for name in
             ("every_positive_state_checked", "every_unlabelled_action_checked",
              "all_legal_system_responses_independently_enumerated")) and
         report.get("no_native_W_BDD_CSR_or_producer_transition_tables_used") is True,
         "PASS report lacks complete independent coverage")
    initial = verifier.verify_initial(selected_x, ranks)
    need(initial == report.get("initialization"), "seed initializer differs from PASS report")
    self_pin = pin(__file__, read_regular(__file__, 256 * 1024))
    originals = [self_pin, checker_pin, report_pin] + input_pins
    result.update({"seed_full_verification_report": report_pin, "original_input_pins": originals,
                   "seed_full_verification_was_not_reexecuted": True,
                   "selected_initialization": initial, "seed_report_counts": local.get("counts"),
                   "case_results": [], "synthetic_local_baselines": []})
    store = FixtureStore(fixture_root)
    cases = result["case_results"]
    scanner = verifier.LocalVerifier(ranks, actions, rounds)
    witnesses = {}
    counts = {"positive_states": 0, "unlabelled_states": 0,
              "maximum_rank": 0, "positive_goal_states": 0}
    for state_id, rank in enumerate(ranks):
        if rank == 0:
            counts["unlabelled_states"] += 1
            witnesses.setdefault("unlabelled", state_id)
            if "illegal_current" not in witnesses and not verifier.physical_arena(*verifier.decode(state_id)[:3]):
                witnesses["illegal_current"] = state_id
            continue
        counts["positive_states"] += 1
        counts["maximum_rank"] = max(counts["maximum_rank"], rank)
        e, r0, r1, history = verifier.decode(state_id)
        is_goal = verifier.goal(e, r0, r1)
        counts["positive_goal_states"] += int(is_goal)
        witnesses.setdefault("positive", state_id)
        if all(key in witnesses for key in ("q_true", "q_false", "edge", "non_goal_edge")):
            continue
        if scanner.q_count(e, r0, r1) == 0:
            witnesses.setdefault("q_false", state_id)
            continue
        witnesses.setdefault("q_true", state_id)
        if "edge" not in witnesses or (not is_goal and "non_goal_edge" not in witnesses):
            for nr0, nr1, nh in verifier.original_sys_responses(r0, r1, history, actions[state_id]):
                target = verifier.encode(actions[state_id], nr0, nr1, nh)
                if target != state_id and scanner.q_count(actions[state_id], nr0, nr1) > 0:
                    witnesses.setdefault("edge", (state_id, target))
                    if not is_goal:
                        witnesses.setdefault("non_goal_edge", (state_id, target))
                    break
    need(all(local.get("counts", {}).get(name) == value for name, value in counts.items()),
         "actual seed counts differ from bound PASS report")
    result["independently_read_seed_counts"] = counts
    result["seed_has_positive_goal_states"] = counts["positive_goal_states"] > 0
    result["witness_scan_states"] = len(ranks)

    def location(state_id):
        e, r0, r1, history = verifier.decode(state_id)
        return {"state_id": state_id, "intruder": verifier.COORD[e],
                "robot0": verifier.COORD[r0], "robot1": verifier.COORD[r1], "history": history}

    def local_check(rr, aa, bound, state_id):
        verifier.LocalVerifier(rr, aa, bound).check_state(state_id)

    def semantic_case(name, witness, expected, mutate, *, initial_case=False,
                      baseline=None, baseline_scope="ORIGINAL_FULL_PASS_CERTIFICATE"):
        record = {"name": name, "kind": "SEMANTIC_REJECTION_AFTER_SUCCESSFUL_LOAD",
                  "baseline_scope": baseline_scope, "full_certificate_validity_claim_for_fixture": False}
        cases.append(record)
        if witness is None:
            record.update({"status": "NOT_TESTED", "reason": "no suitable bounded witness"})
            return
        base_ranks, base_actions, base_rounds = baseline or (ranks, actions, rounds)
        record["source"] = location(witness)
        try:
            if initial_case:
                verifier.verify_initial(selected_x, base_ranks)
            else:
                local_check(base_ranks, base_actions, base_rounds, witness)
            record["baseline_selected_check_passed"] = True
            changed_ranks, changed_actions = array("I", base_ranks), bytearray(base_actions)
            record["mutation"] = mutate(changed_ranks, changed_actions)
            changed_manifest = repinned_manifest(manifest, changed_ranks, changed_actions, base_rounds)
            directory, fixture_pins, _ = store.create(name, changed_manifest, changed_ranks, changed_actions)
            record.update({"fixture_directory": str(directory), "fixture_readback_pins": fixture_pins})
            _, fixture_x, fixture_rounds, loaded_ranks, loaded_actions, loaded_pins = verifier.load_inputs(
                directory, source_path, import_path)
            record.update({"fixture_load_inputs_passed": True, "loaded_input_pins": loaded_pins})
            operation = (lambda: verifier.verify_initial(fixture_x, loaded_ranks)) if initial_case else (
                lambda: local_check(loaded_ranks, loaded_actions, fixture_rounds, witness))
            record.update(expected_rejection(verifier, operation, expected))
        except Exception as exc:
            record.update({"status": "FAIL_BASELINE_OR_FIXTURE_LOAD", "exception_type": type(exc).__name__,
                           "reason": str(exc)[:4096]})

    def change_action(state_id, value):
        def mutate(rr, aa):
            before = aa[state_id]
            aa[state_id] = value
            return {"state_id": state_id, "action_before": before, "action_after": value}
        return mutate

    def change_rank(state_id, value, clear_action=False):
        def mutate(rr, aa):
            before, action_before = rr[state_id], aa[state_id]
            rr[state_id] = value
            if clear_action:
                aa[state_id] = verifier.NO_ACTION
            return {"state_id": state_id, "rank_before": before, "rank_after": value,
                    "action_before": action_before, "action_after": aa[state_id]}
        return mutate

    qt = witnesses.get("q_true")
    semantic_case("q_true_no_action", qt, "has invalid action", change_action(qt, 255))
    illegal_action = None
    if qt is not None:
        illegal_action = next(cell for cell in range(64)
                              if cell not in verifier.original_env_actions(*verifier.decode(qt)[:3]))
    semantic_case("original_illegal_env_action", qt, "original-illegal ENV action",
                  change_action(qt, illegal_action))
    illegal_current = witnesses.get("illegal_current")
    semantic_case("positive_illegal_current_arena", illegal_current, "violates the original current arena",
                  change_rank(illegal_current, 1))
    edge = witnesses.get("edge")
    semantic_case("missing_q_true_response_rank", edge[0] if edge else None,
                  "without a rank", change_rank(edge[1] if edge else None, 0, clear_action=True))

    # A bound increase alone preserves every seed local inequality. It is used
    # only as a source-local baseline; no full-certificate check is claimed.
    non_goal_edge = witnesses.get("non_goal_edge")
    adjusted_baseline = None
    if non_goal_edge:
        source, target = non_goal_edge
        adjusted_rounds = max(rounds, ranks[source] + 1)
        need(adjusted_rounds <= verifier.STATE_COUNT + 1, "rank-increase baseline exceeds manifest bound")
        baseline_manifest = repinned_manifest(manifest, ranks, actions, adjusted_rounds)
        directory, baseline_pins, _ = store.create("baseline_non_goal_round_bound", baseline_manifest, ranks, actions)
        _, _, bound, rr, aa, loaded_pins = verifier.load_inputs(directory, source_path, import_path)
        local_check(rr, aa, bound, source)
        adjusted_baseline = (rr, aa, bound)
        result["synthetic_local_baselines"].append({"name": "baseline_non_goal_round_bound",
            "scope": "ROUND_BOUND_ADJUSTED_SOURCE_LOCAL_BASELINE", "source": location(source),
            "target": location(target), "original_rounds": rounds, "baseline_rounds": bound,
            "load_inputs_passed": True, "selected_source_check_passed": True,
            "full_certificate_validity_checked": False, "fixture_readback_pins": baseline_pins,
            "loaded_input_pins": loaded_pins})
    semantic_case("non_goal_response_rank_increase", non_goal_edge[0] if non_goal_edge else None,
                  "rank increases on response", change_rank(non_goal_edge[1] if non_goal_edge else None,
                  ranks[non_goal_edge[0]] + 1 if non_goal_edge else 1), baseline=adjusted_baseline,
                  baseline_scope="ROUND_BOUND_ADJUSTED_SOURCE_LOCAL_BASELINE")

    # The real rank-1 seed has no positive goal state. This explicit legal
    # current goal and non-staying ENV move cover the strict branch locally.
    goal_source = verifier.encode(3 * 8 + 3, 2 * 8 + 3, 4 * 8 + 3, 1)
    goal_action = 3 * 8 + 2
    ge, gr0, gr1, gh = verifier.decode(goal_source)
    need(verifier.physical_arena(ge, gr0, gr1) and verifier.goal(ge, gr0, gr1) and
         goal_action != ge and goal_action in verifier.original_env_actions(ge, gr0, gr1),
         "synthetic goal witness is not original-legal")
    goal_ranks, goal_actions = array("I", ranks), bytearray(actions)
    goal_ranks[goal_source], goal_actions[goal_source] = 2, goal_action
    goal_targets = []
    for nr0, nr1, nh in verifier.original_sys_responses(gr0, gr1, gh, goal_action):
        target = verifier.encode(goal_action, nr0, nr1, nh)
        if scanner.q_count(goal_action, nr0, nr1) > 0:
            need(target != goal_source, "synthetic goal source has a self-response")
            goal_ranks[target] = 1
            goal_targets.append(target)
    need(0 < len(goal_targets) <= 25, "synthetic goal witness lacks Q-true responses")
    goal_bound = max(rounds, 2)
    goal_manifest = repinned_manifest(manifest, goal_ranks, goal_actions, goal_bound)
    directory, goal_pins, _ = store.create("baseline_synthetic_goal_local", goal_manifest, goal_ranks, goal_actions)
    _, _, bound, rr, aa, loaded_pins = verifier.load_inputs(directory, source_path, import_path)
    local_check(rr, aa, bound, goal_source)
    result["synthetic_local_baselines"].append({"name": "baseline_synthetic_goal_local",
        "scope": "SYNTHETIC_LOCALLY_VALID_GOAL_SOURCE_ONLY", "source": location(goal_source),
        "source_rank": 2, "chosen_environment_cell": goal_action, "q_true_response_ids": goal_targets,
        "q_true_response_ranks": 1, "load_inputs_passed": True, "selected_source_check_passed": True,
        "full_certificate_validity_checked": False,
        "fixture_may_fail_other_states": True, "fixture_readback_pins": goal_pins,
        "loaded_input_pins": loaded_pins})
    semantic_case("goal_equal_rank_response", goal_source, "does not strictly decrease",
                  change_rank(goal_source, 1), baseline=(rr, aa, bound),
                  baseline_scope="SYNTHETIC_LOCALLY_VALID_GOAL_SOURCE_ONLY")
    qf = witnesses.get("q_false")
    semantic_case("q_false_terminal_has_action", qf, "must have terminal action 255", change_action(qf, 0))
    unlabelled = witnesses.get("unlabelled")
    semantic_case("rank_zero_has_action", unlabelled, "has a non-255 action", change_action(unlabelled, 0))
    positive = witnesses.get("positive")
    semantic_case("rank_exceeds_completed_rounds", positive, "rank exceeds completed rounds",
                  change_rank(positive, rounds + 1))
    semantic_case("selected_initializer_missing_rank", initial["state_id"],
                  "selected initializer has no positive rank", change_rank(initial["state_id"], 0, True),
                  initial_case=True)

    def loader_case(name, expected, changed_manifest=None, **payloads):
        record = {"name": name, "kind": "LOAD_INPUTS_REJECTION", "baseline_load_inputs_passed": True}
        cases.append(record)
        try:
            directory, fixture_pins, changed_source_path = store.create(
                name, manifest if changed_manifest is None else changed_manifest, ranks, actions, **payloads)
            record.update({"fixture_directory": str(directory), "fixture_readback_pins": fixture_pins})
            record.update(expected_rejection(verifier, lambda: verifier.load_inputs(
                directory, changed_source_path or source_path, import_path), expected))
        except Exception as exc:
            record.update({"status": "FAIL_FIXTURE_CONSTRUCTION", "exception_type": type(exc).__name__,
                           "reason": str(exc)[:4096]})

    ordinary_manifest = json_bytes(manifest)
    duplicate_manifest = b'{"schema":' + json.dumps(manifest["schema"]).encode() + b',' + ordinary_manifest[1:]
    loader_case("duplicate_json_key", "duplicate JSON key", raw_manifest=duplicate_manifest)
    changed = copy.deepcopy(manifest)
    changed["selected_initial_x"] = True
    loader_case("boolean_selected_initial_x", "selected_initial_x: expected integer", changed)
    changed = copy.deepcopy(manifest)
    changed["source"]["sha256"] = "0" * 64
    loader_case("source_hash_metadata_wrong", "source: SHA-256 mismatch", changed)
    changed_actions = bytearray(actions)
    changed_actions[0] ^= 1
    loader_case("actions_payload_hash_mismatch", "actions: payload hash mismatch", raw_actions=changed_actions)
    raw_ranks = read_regular(certificate_dir / "ranks.u32le", verifier.RANK_BYTES)
    loader_case("truncated_rank_payload", "incorrect input size", raw_ranks=raw_ranks[:-1])
    changed_source = bytearray(read_regular(source_path, verifier.SOURCE_BYTES))
    changed_source[0] ^= 1
    loader_case("actual_source_byte_flip", "actual source hash mismatch", changed_source=changed_source)
    changed = copy.deepcopy(manifest)
    changed["ranks"]["file"] = "../ranks.u32le"
    loader_case("invalid_rank_filename", "ranks: filename must be ranks.u32le", changed)

    need(len(cases) == EXPECTED_CASES, "unexpected rejection-control roster")
    # Recheck every protected original and retained fixture after all tests.
    for record in originals + store.pins:
        actual = pin(record["path"], read_regular(record["path"], max(record["bytes"], 1)))
        need(pin_key(actual) == pin_key(record), "input or fixture changed: " + record["path"])
    result.update({"all_original_inputs_unchanged": True, "all_fixture_readback_pins_rechecked": True,
                   "fixture_directories": store.directories, "fixture_bytes_written": store.written,
                   "passed_cases": sum(case["status"] == "PASS_EXPECTED_REJECTION" for case in cases),
                   "not_tested_cases": sum(case["status"] == "NOT_TESTED" for case in cases),
                   "bounded_failure_examples": [case for case in cases
                       if case["status"] != "PASS_EXPECTED_REJECTION"][:MAX_FAILURE_EXAMPLES]})
    if all(case["status"] == "PASS_EXPECTED_REJECTION" for case in cases):
        result["status"] = "PASS_BOUNDED_CERTIFICATE_REJECTION_CONTROLS"
        return 0
    result["status"] = "INCOMPLETE_OR_FAILED_CERTIFICATE_REJECTION_CONTROLS"
    return 2


def on_timeout(signum, frame):
    raise HarnessTimeout("internal 150-second wall-clock cap reached")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--certificate-dir", type=Path, required=True)
    parser.add_argument("--verification-result", type=Path, required=True)
    parser.add_argument("--fixtures-dir", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    started = time.monotonic()
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    with os.fdopen(os.open(args.out, flags, 0o644), "wb") as output:
        result = {"schema": "v53-bounded-certificate-rejection-controls-v1",
                  "status": "UNVERIFIED_REJECTION_CONTROLS", "full_proof_claim": False,
                  "scope": "17 negative controls for loading and selected local verifier branches only",
                  "no_producer_reference_BDD_CSR_native_or_subprocess_execution": True,
                  "full_certificate_verification_called": False,
                  "bounds": {"internal_wall_seconds": INTERNAL_SECONDS, "expected_external_wall_seconds": 180,
                             "expected_external_rss_gib": 2, "max_fixture_directories": MAX_FIXTURE_DIRS,
                             "max_written_bytes": MAX_WRITTEN_BYTES, "max_failure_examples": MAX_FAILURE_EXAMPLES,
                             "expected_cases": EXPECTED_CASES}}
        previous_handler = signal.signal(signal.SIGALRM, on_timeout)
        signal.setitimer(signal.ITIMER_REAL, INTERNAL_SECONDS)
        try:
            code = run(args, result)
        except (Exception, HarnessTimeout) as exc:
            result.update({"status": "UNKNOWN_OR_FAILED_REJECTION_CONTROLS", "exception_type": type(exc).__name__,
                           "reason": str(exc)[:4096]})
            code = 2
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
            signal.signal(signal.SIGALRM, previous_handler)
        result.update({"elapsed_seconds": time.monotonic() - started,
                       "created_utc": datetime.now(timezone.utc).isoformat()})
        output.write(json_bytes(result))
        output.flush()
        os.fsync(output.fileno())
    print(json.dumps({"status": result["status"], "report": str(args.out.absolute())}))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
