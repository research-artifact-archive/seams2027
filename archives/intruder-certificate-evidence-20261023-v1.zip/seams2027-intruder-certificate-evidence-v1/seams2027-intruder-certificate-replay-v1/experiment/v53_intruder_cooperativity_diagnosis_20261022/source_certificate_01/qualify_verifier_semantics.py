"""Exhaustive finite-factor and response-list qualification of the proof checker.

The reference is the separately written, previously source-correspondence
qualified scalar evaluator. No producer, CSR, native W or BDD is loaded.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import signal
import sys
import time

D = Path(__file__).resolve().parent
B = D.parent
CHECKER_SHA = '2c74a8dc80aa4dc86626d4a85f432b4a1268112f7a59538e8780a7907ffdea33'
REFERENCE_SHA = '9734504093ee83870c9223e61fe980c9af30fa4b787fe96b7eaafd24ed3ffe78'


def need(value, message):
    if not value:
        raise ValueError(message)


def pin(path):
    raw = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def load(path, name, expected):
    need(pin(path)['sha256'] == expected, 'exact reviewed code: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main(out):
    need(not out.exists(), 'fresh output required')
    started = time.monotonic()
    paths = [D/'verify_certificate.py', B/'intruder_audit/oracle355/source_semantics.py']
    before = [pin(path) for path in paths]
    checker = load(paths[0], 'qualified_source_checker', CHECKER_SHA)
    reference = load(paths[1], 'original_scalar_reference', REFERENCE_SHA)
    source = checker.DEFAULT_SOURCE
    imported = checker.DEFAULT_IMPORT
    need(pin(source)['sha256'] == checker.SOURCE_SHA256, 'exact original source')
    need(pin(imported)['sha256'] == checker.IMPORT_SHA256, 'exact original import')
    before += [pin(source), pin(imported)]
    contract = reference.Contract()
    points = tuple((x, y) for x in range(8) for y in range(8))
    need(checker.COORD == points, 'cell-coordinate encoding')
    counts = {}

    def state(e, a, b, h):
        ex, ey = points[e]; ax, ay = points[a]; bx, by = points[b]
        return {'intruderX': str(ex), 'intruderY': str(ey),
                'robotX0': str(ax), 'robotY0': str(ay),
                'robotX1': str(bx), 'robotY1': str(by),
                'ONCE_aux_0': ('true' if h else 'false')}

    moves = []
    for cell in range(64):
        expected = tuple(target for target in range(64)
                         if reference.step(points[cell], points[target]))
        actual = tuple(checker.bounded_moves(cell))
        need(len(actual) == len(set(actual)) and set(actual) == set(expected),
             'complete move list')
        need(actual == checker.MOVES[cell], 'production move table')
        need(checker.outside_obstacle(cell) == (points[cell] not in contract.obstacles),
             'obstacle factor')
        moves.append(expected)
        for target in range(64):
            need(checker.adjacent(cell, target) ==
                 reference.adjacent(points[cell], points[target]), 'adjacency factor')
    counts.update(clear_factor=64, complete_move_lists=64, step_assignments=4096,
                  adjacency_assignments=4096)

    # Every typed state index, including both logical history values.
    for sid in range(checker.STATE_COUNT):
        values = checker.decode(sid)
        need(all(0 <= x < 64 for x in values[:3]) and values[3] in (0, 1),
             'decode domains')
        need(checker.encode(*values) == sid, 'complete dense index roundtrip')
    counts['index_roundtrips'] = checker.STATE_COUNT

    # Complete ENV action sets over all physical valuations. Completeness over
    # all 64 next cells follows from the independently checked move lists;
    # rhoE rejects all cells outside those lists by its movement conjunct.
    env_evaluations = 0
    env_next = [{'intruderX': str(x), 'intruderY': str(y)} for x, y in points]
    for e in range(64):
        for a in range(64):
            for b in range(64):
                s = state(e, a, b, 0)
                actual = tuple(checker.original_env_actions(e, a, b))
                expected = tuple(n for n in moves[e] if contract.rho_e(s, env_next[n]))
                env_evaluations += len(moves[e])
                need(len(actual) == len(set(actual)) and set(actual) == set(expected),
                     'complete original ENV choices')
                need(checker.goal(e, a, b) == contract.justices(s)[1][0], 'source goal')
                need(checker.physical_arena(e, a, b) ==
                     (points[e] not in contract.obstacles and all(contract.invariants(s))),
                     'current original legal arena')
    counts.update(complete_ENV_choice_queries=64**3,
                  reference_rhoE_evaluations=env_evaluations,
                  goal_assignments=64**3, arena_assignments=64**3)

    # Qualify all robot1 movement assignments and all history-update assignments.
    # The response iterator below is then checked for EVERY input tuple.
    for h in (0, 1):
        for b in range(64):
            actual_positions = checker.MOVES[b] if h else (b,)
            for nb in range(64):
                expected = (bool(h) and reference.step(points[b], points[nb])) or b == nb
                need((nb in actual_positions) == expected, 'current history movement gate')
        for na in range(64):
            for nh in (0, 1):
                need((checker.update_history(h, na) == nh) ==
                     (bool(nh) == (bool(h) or points[na] == (0, 7))),
                     'deterministic next history')
    counts.update(robot1_movement_assignments=8192, history_update_assignments=256)

    # Factor source rhoS into robot/history constraints and the two NEXT
    # intruder-collision tests. For each (a,b,h), obtain the complete base relation
    # with a fresh clear intruder cell distinct from both candidate robots, using
    # the independent scalar rhoS. Then test every next-intruder value against
    # the actual checker response iterator. No current-arena restriction here.
    sys_evaluations = response_queries = responses = 0
    for a in range(64):
        for b in range(64):
            for h in (0, 1):
                s = state(0, a, b, h)
                base = []
                b_moves = tuple(nb for nb in range(64)
                                if (bool(h) and reference.step(points[b], points[nb])) or b == nb)
                for na in moves[a]:
                    for nb in b_moves:
                        ne = next(e for e in range(64)
                                  if points[e] not in contract.obstacles and e != na and e != nb)
                        for nh in (0, 1):
                            sys_evaluations += 1
                            if contract.rho_s(s, state(ne, na, nb, nh)):
                                base.append((na, nb, nh))
                need(len(base) == len(set(base)), 'reference response uniqueness')
                for ne in range(64):
                    actual = tuple(checker.original_sys_responses(a, b, h, ne))
                    expected = tuple(t for t in base if ne != t[0] and ne != t[1])
                    need(len(actual) <= 25 and len(actual) == len(set(actual))
                         and set(actual) == set(expected), 'complete original SYS responses')
                    response_queries += 1
                    responses += len(actual)
    counts.update(reference_rhoS_factor_evaluations=sys_evaluations,
                  complete_SYS_response_queries=response_queries,
                  actual_SYS_responses_compared=responses)

    initial_counts = []
    for e in range(64):
        actual_env = e % 8 == 7
        need(actual_env == contract.theta_e(state(e, 0, 56, 0)), 'complete ENV initialization')
        if not actual_env:
            continue
        expected = []
        actual = []
        for a in range(64):
            for b in range(64):
                for h in (0, 1):
                    if contract.theta_s(state(e, a, b, h)):
                        expected.append(checker.encode(e, a, b, h))
                    if checker.theta_system(a, b, h) and checker.physical_arena(e, a, b):
                        actual.append(checker.encode(e, a, b, h))
        need(actual == expected == [checker.encode(e, 0, 56, 0)], 'all SYS/aux initial responses')
        initial_counts.append(len(actual))
    counts.update(ENV_initializer_assignments=64, SYS_aux_initial_assignments=8*64*64*2,
                  initial_SYS_aux_counts=initial_counts)

    # Three independent regression witnesses exercise the known semantic risks.
    need(tuple(checker.original_env_actions(54, 46, 53)) == (), 'orthogonal AND dead end')
    need(17 not in checker.original_env_actions(16, 0, 56), 'NEXT obstacle exclusion')
    need((7, 48, 1) not in checker.original_sys_responses(6, 56, 0, 28),
         'newly activated history must not move robot1 this same step')
    after = [pin(path) for path in paths + [source, imported]]
    need(before == after, 'all qualification inputs preserved')
    report = {'schema': 'v53-source-proof-checker-finite-qualification-v1',
              'status': 'PASS_COMPLETE_FINITE_SOURCE_CHECKER_SEMANTICS_AND_RESPONSE_LISTS',
              'counts': counts, 'input_pins': before,
              'known_current_next_AND_history_regression_witnesses': 3,
              'elapsed_seconds': time.monotonic() - started,
              'method': 'Independent pinned scalar original-source reference; complete local movement/adjacency/history factors, all ENV physical valuations and all SYS response input tuples, complete initial quantification and dense index roundtrip.',
              'composition_note': 'rhoS base relation is reference-evaluated with intruder distinct from both next robots; every next intruder value is then checked through its only two rhoS occurrences, the next-state collision conjuncts. rhoE movement completeness follows from all64 next-cell movement tests per current cell.',
              'not_claimed': 'This qualifies the independently written certificate checker. It is not a proof of the generating solver, a new BDD comparison, or a negative certificate acceptance.',
              'native_calls': 0, 'BDD_imports': 0}
    with out.open('x') as stream:
        json.dump(report, stream, indent=2); stream.write('\n')
    print(json.dumps({'status': report['status'], 'report': pin(out)}), flush=True)


if __name__ == '__main__':
    sys.dont_write_bytecode = True
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    def expired(_signum, _frame):
        raise TimeoutError('finite source qualification exceeded150seconds')
    signal.signal(signal.SIGALRM, expired)
    signal.alarm(150)
    main(args.out)
