#!/usr/bin/env python3
"""Check a fixed355 negative certificate using only the exact original source.

This file is an independently written, source-specialized proof checker.  Exact
source/import hashes qualify the direct finite semantics below.  It deliberately
does not parse a general Spectra language, import a producer, read BDD/native W,
read CSR, trust the generator's fixed point, or accept producer successor lists.

Every positive label is checked, not just a sampled/reachable subset.  The only
successful conclusion is failure of the JOINT original strict + all-prefix
cooperation obligation for one original ENV initializer.  No strict-only or
all-initializers-losing conclusion follows.  The environment has no justice.
"""

from __future__ import annotations

import argparse
from array import array
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time


BASE = Path(__file__).resolve().parents[1]
DEFAULT_SOURCE = BASE.parent / "v48_comparative_improvement_20261021/native355/inputs/1673286053.spectra"
DEFAULT_IMPORT = DEFAULT_SOURCE.parent / "imports/DwyerPatterns.spectra"
SOURCE_BYTES = 2071
SOURCE_SHA256 = "6203bdf9a0e65726aa2d46503ae935ba2ac4e9fa27f00650ded83a25a5318c10"
IMPORT_BYTES = 49400
IMPORT_SHA256 = "5c45b64f7b9b9f4f480d3cb485adcd8a772bce6d6c11356345386c5f143333cc"
SCHEMA = "v53-original-source-dual-cobuchi-certificate-v1"
ENCODING = "(((intruderCell*64+robot0Cell)*64+robot1Cell)<<1)|history; cell=x*8+y; history=0:false,1:true"
CANDIDATE_STATUS = "NEGATIVE_COUNTERCERTIFICATE_CANDIDATE"
PASS_STATUS = "PASS_ORIGINAL_SOURCE_JOINT_UNREALIZABILITY_COUNTERCERTIFICATE"
STATE_COUNT = 64 * 64 * 64 * 2
RANK_BYTES = STATE_COUNT * 4
ACTION_BYTES = STATE_COUNT
MANIFEST_LIMIT = 1024 * 1024
REPORT_LIMIT = 1024 * 1024
EXAMPLE_LIMIT = 8
NO_ACTION = 255
Q_UNCOMPUTED = 255
SEMANTICS_ID = "fixed355-original-source-direct-grid-once-env-first-v1"


class Rejected(Exception):
    """A certificate or source qualification failed; never a positive result."""


def require(condition, message):
    if not condition:
        raise Rejected(message)


def exact_int(value, minimum, maximum, field):
    require(type(value) is int and minimum <= value <= maximum,
            f"{field}: expected integer in [{minimum}, {maximum}]")
    return value


def exact_bool(value, field):
    require(type(value) is bool, f"{field}: expected Boolean")
    return value


def unique_object(pairs):
    obj = {}
    for key, value in pairs:
        require(key not in obj, f"duplicate JSON key: {key!r}")
        obj[key] = value
    return obj


def reject_json_constant(value):
    raise Rejected(f"non-finite JSON constant: {value}")


def read_regular(path, exact_size=None, limit=None):
    """One bounded read of a regular final entry, with final symlinks refused."""
    path = Path(path)
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
    require(not path.is_symlink(), f"symlink input refused: {path}")
    require(stat.S_ISREG(path.lstat().st_mode), f"not a regular file: {path}")
    with os.fdopen(os.open(path, flags), "rb") as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode), f"not a regular file: {path}")
        if exact_size is not None:
            require(before.st_size == exact_size, f"incorrect input size: {path}")
            cap = exact_size
        else:
            require(limit is not None and before.st_size <= limit,
                    f"input exceeds size bound: {path}")
            cap = limit
        data = stream.read(cap + 1)
        after = os.fstat(stream.fileno())
        require(len(data) == before.st_size and len(data) <= cap,
                f"incomplete or excessive read: {path}")
        require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns,
                 before.st_ctime_ns) ==
                (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns,
                 after.st_ctime_ns), f"input changed while reading: {path}")
    return data


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin_record(path, data):
    return {"path": str(Path(path).absolute()), "bytes": len(data),
            "sha256": digest(data)}


def require_pin(obj, expected_size, expected_sha, field):
    require(type(obj) is dict, f"{field}: expected object")
    exact_int(obj.get("bytes"), expected_size, expected_size, f"{field}.bytes")
    require(obj.get("sha256") == expected_sha, f"{field}: SHA-256 mismatch")


def load_inputs(certificate_dir, source_path, import_path):
    directory = Path(certificate_dir).absolute()
    require(not directory.is_symlink() and directory.is_dir(),
            "certificate directory must be an existing nonsymlink directory")
    manifest_path = directory / "certificate.json"
    manifest_data = read_regular(manifest_path, limit=MANIFEST_LIMIT)
    try:
        manifest = json.loads(manifest_data.decode("utf-8"),
                              object_pairs_hook=unique_object,
                              parse_constant=reject_json_constant)
    except (UnicodeError, ValueError, RecursionError) as exc:
        raise Rejected(f"invalid manifest JSON: {type(exc).__name__}") from exc
    require(type(manifest) is dict, "manifest must be an object")
    require(manifest.get("schema") == SCHEMA, "wrong certificate schema")
    require(manifest.get("status") == CANDIDATE_STATUS,
            "manifest does not claim a negative candidate; no negative proof")
    require(manifest.get("state_encoding") == ENCODING, "wrong state encoding")
    exact_int(manifest.get("state_count"), STATE_COUNT, STATE_COUNT, "state_count")
    selected_x = exact_int(manifest.get("selected_initial_x"), 0, 7,
                           "selected_initial_x")
    rounds = exact_int(manifest.get("completed_outer_rounds"), 1,
                       STATE_COUNT + 1, "completed_outer_rounds")
    exact_bool(manifest.get("fixed_point_complete"), "fixed_point_complete")
    exact_bool(manifest.get("early_negative_stop"), "early_negative_stop")
    require(exact_bool(manifest.get("source_pins_verified"),
                       "source_pins_verified"), "producer source pin claim is false")
    require_pin(manifest.get("source"), SOURCE_BYTES, SOURCE_SHA256, "source")
    require_pin(manifest.get("import"), IMPORT_BYTES, IMPORT_SHA256, "import")
    source_data = read_regular(source_path, exact_size=SOURCE_BYTES)
    import_data = read_regular(import_path, exact_size=IMPORT_BYTES)
    require(digest(source_data) == SOURCE_SHA256, "actual source hash mismatch")
    require(digest(import_data) == IMPORT_SHA256, "actual import hash mismatch")

    payloads = {}
    pins = [pin_record(manifest_path, manifest_data),
            pin_record(source_path, source_data), pin_record(import_path, import_data)]
    for field, filename, size in (("ranks", "ranks.u32le", RANK_BYTES),
                                  ("actions", "chosen_env.u8", ACTION_BYTES)):
        info = manifest.get(field)
        require(type(info) is dict, f"{field}: expected object")
        require(info.get("file") == filename, f"{field}: filename must be {filename}")
        exact_int(info.get("bytes"), size, size, f"{field}.bytes")
        expected_sha = info.get("sha256")
        require(type(expected_sha) is str and len(expected_sha) == 64 and
                all(ch in "0123456789abcdef" for ch in expected_sha),
                f"{field}: invalid SHA-256")
        path = directory / filename
        data = read_regular(path, exact_size=size)
        require(digest(data) == expected_sha, f"{field}: payload hash mismatch")
        payloads[field] = data
        pins.append(pin_record(path, data))
    ranks = array("I")
    require(ranks.itemsize == 4, "platform unsigned-int width is not 32 bits")
    ranks.frombytes(payloads.pop("ranks"))
    if sys.byteorder != "little":
        ranks.byteswap()
    actions = payloads.pop("actions")
    require(len(ranks) == STATE_COUNT and len(actions) == STATE_COUNT,
            "incorrect decoded array lengths")
    return manifest, selected_x, rounds, ranks, actions, pins


# Direct source semantics.  The only derived table is 64 small, typed lists of
# stay/cardinal moves.  No generated legal-choice or response table is accepted.
COORD = tuple(divmod(cell, 8) for cell in range(64))


def bounded_moves(cell):
    x, y = COORD[cell]
    yield cell
    if x > 0:
        yield (x - 1) * 8 + y
    if x < 7:
        yield (x + 1) * 8 + y
    if y > 0:
        yield x * 8 + y - 1
    if y < 7:
        yield x * 8 + y + 1


MOVES = tuple(tuple(bounded_moves(cell)) for cell in range(64))


def outside_obstacle(cell):
    x, y = COORD[cell]
    return not (2 <= x <= 5 and y == 1)


def adjacent(first, second):
    x1, y1 = COORD[first]
    x2, y2 = COORD[second]
    return abs(x1 - x2) + abs(y1 - y2) == 1


def physical_arena(e, r0, r1):
    return (outside_obstacle(e) and outside_obstacle(r0) and
            outside_obstacle(r1) and e != r0 and e != r1 and r0 != r1)


def original_env_actions(e, r0, r1):
    adjacent0, adjacent1 = adjacent(r0, e), adjacent(r1, e)
    x0, y0 = COORD[r0]
    x1, y1 = COORD[r1]
    for next_e in MOVES[e]:
        if not outside_obstacle(next_e):
            continue
        nx, ny = COORD[next_e]
        # Original implication requires BOTH coordinate inequalities.
        if adjacent0 and (nx == x0 or ny == y0):
            continue
        if adjacent1 and (nx == x1 or ny == y1):
            continue
        yield next_e


def encode(e, r0, r1, history):
    return (((e * 64 + r0) * 64 + r1) << 1) | history


def decode(state_id):
    packed, history = divmod(state_id, 2)
    packed, r1 = divmod(packed, 64)
    e, r0 = divmod(packed, 64)
    return e, r0, r1, history


def original_sys_responses(r0, r1, history, next_e):
    # ONCE is evaluated in the CURRENT state for robot1's movement gate.
    robot1_moves = MOVES[r1] if history else (r1,)
    for next_r0 in MOVES[r0]:
        if not outside_obstacle(next_r0) or next_r0 == next_e:
            continue
        next_history = update_history(history, next_r0)
        for next_r1 in robot1_moves:
            if (not outside_obstacle(next_r1) or next_r1 == next_e or
                    next_r1 == next_r0):
                continue
            yield next_r0, next_r1, next_history


def update_history(history, next_r0):
    return int(bool(history) or next_r0 == 7)  # robot0 corner=(0,7)


def goal(e, r0, r1):
    return adjacent(r0, e) and adjacent(r1, e)


def theta_system(r0, r1, history):
    # ONCE(phi) starts at phi(current); thetaS fixes r0=(0,0), hence false.
    return r0 == 0 and r1 == 56 and history == int(r0 == 7)


def verify_initial(selected_x, ranks):
    e = selected_x * 8 + 7
    require(COORD[e][1] == 7 and outside_obstacle(e), "invalid ENV initializer")
    initializers = []
    # Explicitly enumerate all typed SYS/aux values; no producer roster is used.
    for r0 in range(64):
        for r1 in range(64):
            for history in (0, 1):
                if theta_system(r0, r1, history):
                    require(physical_arena(e, r0, r1), "illegal initial arena")
                    state_id = encode(e, r0, r1, history)
                    require(ranks[state_id] > 0, "selected initializer has no positive rank")
                    initializers.append(state_id)
    require(initializers == [encode(e, 0, 56, 0)],
            "original SYS/aux initialization is not the required singleton")
    return {"environment": {"intruderX": selected_x, "intruderY": 7},
            "all_system_aux_initializers_enumerated": True,
            "system_aux_initializer_count": len(initializers),
            "state_id": initializers[0], "rank": ranks[initializers[0]],
            "system": {"robotX0": 0, "robotY0": 0, "robotX1": 7,
                       "robotY1": 0, "ONCE_robot0AtButtomLeftCorner": False}}


class LocalVerifier:
    def __init__(self, ranks, actions, rounds):
        self.ranks, self.actions, self.rounds = ranks, actions, rounds
        # Q is independent of history.  255 means unknown; values 0..5 are exact.
        self.q_cache = bytearray([Q_UNCOMPUTED]) * (STATE_COUNT // 2)
        self.counts = Counter()
        self.examples = {"q_false_terminal": [], "no_system_response": [],
                         "target_q_false": []}

    def q_count(self, e, r0, r1):
        slot = (e * 64 + r0) * 64 + r1
        count = self.q_cache[slot]
        if count == Q_UNCOMPUTED:
            count = sum(1 for _ in original_env_actions(e, r0, r1))
            self.q_cache[slot] = count
            self.counts["q_distinct_physical_positions_exhausted"] += 1
        return count

    def example(self, kind, value):
        if len(self.examples[kind]) < EXAMPLE_LIMIT:
            self.examples[kind].append(value)

    def check_state(self, state_id):
        rank, action = self.ranks[state_id], self.actions[state_id]
        if rank == 0:
            require(action == NO_ACTION,
                    f"unlabelled state {state_id} has a non-255 action")
            self.counts["unlabelled_states"] += 1
            return
        self.counts["positive_states"] += 1
        self.counts["maximum_rank"] = max(self.counts["maximum_rank"], rank)
        require(rank <= self.rounds, f"state {state_id} rank exceeds completed rounds")
        e, r0, r1, history = decode(state_id)
        require(physical_arena(e, r0, r1),
                f"positive state {state_id} violates the original current arena")
        source_goal = goal(e, r0, r1)
        self.counts["positive_goal_states"] += int(source_goal)
        q_count = self.q_count(e, r0, r1)
        if q_count == 0:
            require(action == NO_ACTION,
                    f"Q-false state {state_id} must have terminal action 255")
            self.counts["q_false_terminal_states"] += 1
            self.example("q_false_terminal", {"state_id": state_id, "rank": rank})
            return
        require(0 <= action < 64, f"nonterminal state {state_id} has invalid action")
        require(action in original_env_actions(e, r0, r1),
                f"state {state_id} chooses an original-illegal ENV action")
        self.counts["legal_selected_environment_actions"] += 1
        self.counts["system_move_products_examined"] += (
            len(MOVES[r0]) * (len(MOVES[r1]) if history else 1))
        responses = 0
        for next_r0, next_r1, next_history in original_sys_responses(
                r0, r1, history, action):
            responses += 1
            self.counts["original_legal_system_responses"] += 1
            require(physical_arena(action, next_r0, next_r1),
                    f"internal source semantics produced illegal target from {state_id}")
            target = encode(action, next_r0, next_r1, next_history)
            if self.q_count(action, next_r0, next_r1) == 0:
                self.counts["target_q_false_responses"] += 1
                self.example("target_q_false", {"source": state_id, "target": target})
                continue
            target_rank = self.ranks[target]
            require(target_rank > 0,
                    f"state {state_id} has Q-true response {target} without a rank")
            require(target_rank <= rank,
                    f"rank increases on response {state_id}->{target}")
            require(not source_goal or target_rank < rank,
                    f"goal-state response {state_id}->{target} does not strictly decrease")
            self.counts["nonincreasing_rank_responses"] += 1
            self.counts["strict_goal_decrease_responses"] += int(source_goal)
        require(responses <= 25, "internal response bound violated")
        if responses == 0:
            self.counts["no_system_response_states"] += 1
            self.example("no_system_response", {"state_id": state_id, "rank": rank,
                                                 "selected_env_cell": action})

    def check_all(self):
        require(len(self.ranks) == STATE_COUNT and len(self.actions) == STATE_COUNT,
                "local verifier requires complete dense arrays")
        for state_id in range(STATE_COUNT):
            self.check_state(state_id)
        require(self.counts["positive_states"] > 0, "certificate has no positive labels")
        require(self.counts["positive_states"] + self.counts["unlabelled_states"] ==
                STATE_COUNT, "incomplete state coverage")
        return {"counts": dict(sorted(self.counts.items())),
                "bounded_failure_examples": self.examples,
                "every_positive_state_checked": True,
                "every_unlabelled_action_checked": True,
                "all_legal_system_responses_independently_enumerated": True}


def verify(certificate_dir, source_path=DEFAULT_SOURCE, import_path=DEFAULT_IMPORT):
    manifest, selected_x, rounds, ranks, actions, pins = load_inputs(
        certificate_dir, source_path, import_path)
    initial = verify_initial(selected_x, ranks)
    local = LocalVerifier(ranks, actions, rounds).check_all()
    return {"status": PASS_STATUS,
            "conclusion": "The original fixed355 contract has no system strategy satisfying both strict correctness and all-prefix cooperation for the certified ENV initializer; therefore its all-initializers joint obligation is unrealizable.",
            "claim_scope": {"joint_strict_and_all_prefix_cooperation_unrealizable": True,
                            "strict_correctness_alone_unrealizable": False,
                            "all_eight_environment_initializers_losing": False,
                            "generator_fixed_point_completeness_certified": False},
            "source_semantics": {"id": SEMANTICS_ID,
                                 "qualified_by_exact_source_and_import_hashes": True,
                                 "original_environment_justice_count": 0,
                                 "environment_moves_first": True,
                                 "history_uses_current_value_for_robot1_move": True,
                                 "history_next": "history OR next_robot0=(0,7)",
                                 "Q": "exists an original legal ENV action",
                                 "goal": "both current robots are orthogonally adjacent to intruder"},
            "initialization": initial, "local_certificate_checks": local,
            "producer_metadata_not_used_as_semantic_proof": {
                "completed_outer_rounds": rounds,
                "fixed_point_complete": manifest["fixed_point_complete"],
                "early_negative_stop": manifest["early_negative_stop"]},
            "proof": "Every system strategy under the certified original-legal ENV policy either reaches a verified cooperation/strict failure, or has an infinite original-legal path with natural ranks nonincreasing and strictly decreasing at every system-goal visit. Such a path visits the goal only finitely often, violating the sole system Buchi justice. Rank-zero states cannot be reached except independently verified Q-false failure targets.",
            "input_pins": pins,
            "no_native_W_BDD_CSR_or_producer_transition_tables_used": True,
            "bounds": {"dense_states": STATE_COUNT,
                       "payload_bytes": RANK_BYTES + ACTION_BYTES,
                       "Q_cache_bytes": STATE_COUNT // 2,
                       "max_environment_moves_per_Q_check": 5,
                       "max_system_response_products_per_label": 25,
                       "max_failure_examples_per_kind": EXAMPLE_LIMIT}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--certificate-dir", type=Path, required=True)
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--import-source", type=Path, default=DEFAULT_IMPORT)
    parser.add_argument("--out", type=Path, required=True,
                        help="fresh report path; existing outputs are never replaced")
    args = parser.parse_args()
    # Reserve a fresh output before potentially expensive checking; never truncate
    # an existing file, including a symlink.  Failure leaves only this new report.
    output_flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    started = time.monotonic()
    with os.fdopen(os.open(args.out, output_flags, 0o644), "w", encoding="utf-8") as out:
        try:
            result = verify(args.certificate_dir, args.source, args.import_source)
            code = 0
        except (Rejected, OSError, ValueError, OverflowError, RecursionError) as exc:
            result = {"status": "REJECTED_OR_UNVERIFIED_CERTIFICATE",
                      "negative_conclusion_established": False,
                      "error_type": type(exc).__name__, "reason": str(exc)[:4096]}
            code = 2
        result.update({"schema": "v53-original-source-countercertificate-verification-v1",
                       "created_utc": datetime.now(timezone.utc).isoformat(),
                       "elapsed_seconds": time.monotonic() - started,
                       "verifier_pin": pin_record(__file__, read_regular(__file__, limit=256*1024))})
        rendered = json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
        require(len(rendered.encode("utf-8")) <= REPORT_LIMIT, "report exceeds size bound")
        out.write(rendered)
        out.flush()
        os.fsync(out.fileno())
    print(json.dumps({"status": result["status"], "report": str(args.out.absolute())},
                     ensure_ascii=False))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
