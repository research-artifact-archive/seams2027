#!/usr/bin/env python3
"""Fresh bounded positive-certificate rejection controls for exact V54 G.

Seed must have the full independent positive PASS and exact finite source GATE.
Every semantic case repins complete arrays, passes load_inputs, then exercises a
selected local checker branch. G has no legal physical Qfalse state: that branch
is structurally inapplicable, bound to the completed finite qualification. No
full verify/check_all, solver, BDD or subprocess call. Root-only180s/2GiB stage.
"""
from __future__ import annotations
import argparse
from array import array
import copy
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import sys
import time
from types import ModuleType
import unicodedata

CHECKER_BYTES=32951
CHECKER_SHA256="e1a2ef75b2fc03eb3463b0278c090781bf02be0f942dfe498f7bc36679319eb7"
QUALIFIER_BYTES=29317
QUALIFIER_SHA256="81304faaa1384e4e3bde0be7d57cae7ebba5d2f07e75d30d8412e1af41a341a6"
INTERNAL_SECONDS=150
MAX_FIXTURE_DIRS=32
MAX_WRITTEN_BYTES=400*1024*1024
MAX_JSON_BYTES=2*1024*1024
MAX_FAILURE_EXAMPLES=5


class HarnessError(Exception):
    pass

class HarnessTimeout(BaseException):
    """Escapes individual-case handlers; only main may record this stop."""

def need(condition, reason):
    if not condition:
        raise HarnessError(reason)

def unique_object(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, "duplicate report JSON key: " + repr(key))
        result[key] = value
    return result

def reject_constant(value):
    raise HarnessError("non-finite report JSON constant: " + value)

def read_regular(path, limit):
    path = Path(path)
    need(not path.is_symlink(), "symlink input refused: " + str(path))
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
    with os.fdopen(os.open(path, flags), "rb") as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_size <= limit,
             "input is not a bounded regular file: " + str(path))
        data = stream.read(limit + 1)
        after = os.fstat(stream.fileno())
        need(len(data) == before.st_size and len(data) <= limit,
             "incomplete or excessive input read: " + str(path))
        fields = lambda item: (item.st_dev, item.st_ino, item.st_size,
                               item.st_mtime_ns, item.st_ctime_ns)
        need(fields(before) == fields(after), "input changed during read: " + str(path))
    return data

def pin(path, data):
    return {"path": str(Path(path).absolute()), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}

def path_key(path):
    return unicodedata.normalize("NFC", str(Path(path).resolve()))

def pin_key(record):
    need(type(record) is dict and type(record.get("path")) is str and
         type(record.get("bytes")) is int and record["bytes"] >= 0 and
         type(record.get("sha256")) is str and len(record["sha256"]) == 64,
         "malformed pin record")
    return path_key(record["path"]), record["bytes"], record["sha256"]

def json_bytes(value):
    raw = (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()
    need(len(raw) <= MAX_JSON_BYTES, "JSON exceeds2MiB bound")
    return raw

def expected_rejection(verifier, operation, substring):
    try:
        operation()
    except Exception as exc:
        if type(exc) is verifier.Rejected and substring in str(exc):
            return {"status": "PASS_EXPECTED_REJECTION", "exception_type": "Rejected",
                    "reason": str(exc)[:4096], "expected_reason_substring": substring}
        return {"status": "FAIL_WRONG_REJECTION", "exception_type": type(exc).__name__,
                "reason": str(exc)[:4096], "expected_reason_substring": substring}
    return {"status": "FAIL_UNEXPECTED_ACCEPTANCE", "expected_reason_substring": substring}


def load_checker():
    path=Path(__file__).resolve().with_name("verify_candidate_certificate.py")
    raw=read_regular(path,256*1024);record=pin(path,raw)
    need((record["bytes"],record["sha256"])==(CHECKER_BYTES,CHECKER_SHA256),"frozen checker pin mismatch")
    sys.dont_write_bytecode=True
    module=ModuleType("frozen_v54_candidate_checker_for_rejection_controls");module.__file__=str(path)
    exec(compile(raw,str(path),"exec"),module.__dict__)
    return module,record


def u32_bytes(values):
    result=array("I",values)
    need(result.itemsize==4,"uint32 array width")
    if sys.byteorder!="little":result.byteswap()
    return result.tobytes()


class FixtureStore:
    def __init__(self,root):
        self.root=root
        root.mkdir(mode=0o755,parents=False,exist_ok=False)
        self.written=0;self.directories=0;self.pins=[]
        self.rank_field="win_ranks"
        self.rank_file="win_ranks.u32le"
        self.choice_field="chosen_sys"
        self.choice_file="chosen_sys.u32le"

    def write(self,path,data):
        data=bytes(data)
        need(self.written+len(data)<=MAX_WRITTEN_BYTES,"fixture disk bound exceeded")
        flags=os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,"O_NOFOLLOW",0)
        with os.fdopen(os.open(path,flags,0o644),"wb") as stream:
            stream.write(data);stream.flush();os.fsync(stream.fileno())
        self.written+=len(data)
        record=pin(path,data);actual=pin(path,read_regular(path,max(len(data),1)))
        need(actual==record,"fresh fixture readback mismatch")
        self.pins.append(actual);return actual

    def repin_manifest(self,seed,ranks,choices,rounds):
        manifest=copy.deepcopy(seed);manifest["completed_outer_rounds"]=rounds
        ranks_raw=u32_bytes(ranks);choices_raw=u32_bytes(choices)
        for field,filename,raw in ((self.rank_field,self.rank_file,ranks_raw),
                                  (self.choice_field,self.choice_file,choices_raw)):
            manifest[field]={"file":filename,"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
        return manifest

    def create(self,name,manifest,ranks,choices,*,raw_manifest=None,raw_ranks=None,
               raw_choices=None,source_raw=None,profile_raw=None):
        need(self.directories<MAX_FIXTURE_DIRS,"fixture directory bound exceeded")
        directory=self.root/name;directory.mkdir(mode=0o755,exist_ok=False);self.directories+=1
        manifest=copy.deepcopy(manifest);records=[];source_override=profile_override=None
        if source_raw is not None:
            source_override=directory/"mutated_source.spectra"
            rec=self.write(source_override,source_raw);records.append(rec);manifest["source"]=rec
        if profile_raw is not None:
            profile_override=directory/"mutated_profile.json"
            rec=self.write(profile_override,profile_raw);records.append(rec)
            manifest["semantic_profile"]={"id":manifest["semantic_profile"]["id"],**rec}
        rank_data=u32_bytes(ranks) if raw_ranks is None else raw_ranks
        choices_data=u32_bytes(choices) if raw_choices is None else raw_choices
        records.extend((self.write(directory/"certificate.json",json_bytes(manifest) if raw_manifest is None else raw_manifest),
                        self.write(directory/self.rank_file,rank_data),
                        self.write(directory/self.choice_file,choices_data)))
        return directory,records,source_override,profile_override


def run(args,result):
    v,checker_pin=load_checker()
    certificate_dir=args.certificate_dir.resolve();fixtures=args.fixtures_dir.absolute()
    need(not fixtures.exists() and not fixtures.is_symlink(),"fixture directory must be fresh")
    need(not fixtures.resolve().is_relative_to(certificate_dir),"fixtures must be outside original certificate")
    report_raw=read_regular(args.verification_result,MAX_JSON_BYTES);report_pin=pin(args.verification_result,report_raw)
    report=json.loads(report_raw,object_pairs_hook=unique_object,parse_constant=reject_constant)
    need(type(report)is dict and report.get("schema")=="v54-source-game-certificate-verification-v1",
         "full seed checker report schema")
    need(pin_key(report.get("verifier_pin"))==pin_key(checker_pin),"seed report verifier mismatch")
    loaded=v.load_inputs(certificate_dir,args.candidate_id,args.source,args.import_source,args.semantic_profile)
    need(args.candidate_id=="deadend_stay_both" and loaded["positive"] is True,
         "exact G positive certificate required")
    ranks=loaded["ranks"];choices=loaded["choices"]
    mask=loaded["mask"];rounds=loaded["rounds"];manifest=loaded["manifest"]
    need(report.get("status")==v.POSITIVE_PASS,"full G positive seed checker PASS required")
    need(report.get("candidate_id")==args.candidate_id and type(report.get("candidate_mask"))is int and
         report["candidate_mask"]==mask and report.get("certificate_kind")==loaded["kind"],
         "seed candidate/mask/kind mismatch")
    reported_pins=report.get("input_pins")
    need(type(reported_pins)is list and len(reported_pins)==6,"seed report must bind six exact inputs")
    keys=[pin_key(p) for p in reported_pins]
    need(len({p[0] for p in keys})==6 and set(keys)=={pin_key(p) for p in loaded["input_pins"]},
         "seed report input pins mismatch")
    need(report.get("all_input_pins_rechecked_after_verification")is True and
         report.get("no_native_W_BDD_CSR_or_producer_transition_tables_used")is True,
         "seed report lacks complete input/independence checks")
    semantics=report.get("source_semantics",{})
    need(semantics.get("id")==v.SEMANTICS_ID and
         semantics.get("exact_candidate_source_import_profile_qualified")is True and
         semantics.get("SYS_initial_history_goal_unchanged")is True and
         semantics.get("Q_original_computed_from_complete_original_ENV_action_set")is True and
         semantics.get("candidate_mask_is_fixed_compatibility_metadata")is True and
         type(semantics.get("original_environment_justice_count"))is int and
         semantics["original_environment_justice_count"]==0,"seed semantic profile mismatch")
    local=report.get("local_certificate_checks",{});scope=report.get("claim_scope",{})
    required=("every_positive_state_checked","every_unlabelled_and_illegal_ENV_slot_checked",
              "every_candidate_legal_ENV_action_covered","each_chosen_SYS_response_independently_checked",
              "candidate_Q_true_at_every_labelled_state")
    need(all(scope.get(x)is True for x in ("joint_strict_and_all_prefix_cooperation_realizable",
         "all_eight_environment_initializers_covered","strict_correctness_established","all_prefix_cooperation_established")),
         "seed positive scope incomplete")
    initials=[v.verify_initial(x,ranks) for x in range(8)]
    need(scope.get("generator_fixed_point_completeness_certified")is False and
         all(local.get(x)is True for x in required),"seed local coverage flags missing")
    need(initials==report.get("initializations"),"seed initializer enumeration differs from report")
    self_pin=pin(__file__,read_regular(__file__,256*1024))
    qualification_raw=read_regular(args.qualification_result,MAX_JSON_BYTES)
    qualification_pin=pin(args.qualification_result,qualification_raw)
    qualification=json.loads(qualification_raw,object_pairs_hook=unique_object,parse_constant=reject_constant)
    need(type(qualification)is dict and qualification.get("schema")=="v54-source-candidate-checker-finite-qualification-v1" and
         qualification.get("status")=="PASS_COMPLETE_FINITE_CANDIDATE_SOURCE_SEMANTICS_AND_RESPONSE_LISTS" and
         qualification.get("candidate_ids")==["deadend_stay_both"] and
         qualification.get("semantic_profile_id")==v.SEMANTICS_ID and
         qualification.get("actual_source_Q0_predicate_evaluated")is True,
         "complete exact G source finite qualification required")
    qc=qualification.get("counts",{})
    need(qc.get("physical_QG_true_queries")==qc.get("legal_physical_valuations")==205320 and
         qc.get("actual_source_Q0_predicate_truth_queries")==qc.get("full_typed_Q_identities")==262144 and
         qualification.get("rhoE_identities",{}).get("Q_G_physical_arena")=="true",
         "G physical Q totality must be fully qualified")
    qualification_pins=qualification.get("input_pins")
    need(type(qualification_pins)is list and len(qualification_pins)==9 and
         len({pin_key(p)[0] for p in qualification_pins})==9,"exact nine finite-qualification input pins")
    qualifier_path=Path(__file__).resolve().with_name("qualify_candidate_semantics.py")
    qualifier_pin=pin(qualifier_path,read_regular(qualifier_path,256*1024))
    need((qualifier_pin["bytes"],qualifier_pin["sha256"])==(QUALIFIER_BYTES,QUALIFIER_SHA256),
         "exact G finite qualifier code pin")
    needed=[checker_pin,qualifier_pin]+[p for p in loaded["input_pins"] if pin_key(p)[0] in
        {path_key(args.source),path_key(args.import_source),path_key(args.semantic_profile)}]
    need(len(needed)==5 and all(pin_key(p) in {pin_key(q) for q in qualification_pins} for p in needed),
         "qualification must bind exact G checker/qualifier/source/import/profile")
    for record in qualification_pins:
        actual=pin(record["path"],read_regular(record["path"],max(record["bytes"],1)))
        need(pin_key(actual)==pin_key(record),"changed qualification input")
    originals=[self_pin,checker_pin,report_pin,qualification_pin]+loaded["input_pins"]+qualification_pins
    result.update(candidate_id=args.candidate_id,candidate_mask=mask,certificate_kind=loaded["kind"],
                  seed_full_verification_report=report_pin,original_input_pins=originals,
                  seed_full_verification_was_not_reexecuted=True,case_results=[],
                  finite_source_qualification=qualification_pin,
                  structurally_inapplicable_branches=[{"branch":"positive physical Qfalse rejection",
                    "reason":"Every legal physical G state has QG=true; invalid-current states reject at the arena check first.",
                    "qualified_physical_coordinate_states":205320,
                    "not_tested_case":False,"evidence":qualification_pin}])
    store=FixtureStore(fixtures);cases=result["case_results"]
    counts={"positive_states":0,"unlabelled_states":0,"maximum_rank":0,"positive_goal_states":0}
    witnesses={}
    for sid,rank in enumerate(ranks):
        if rank==0:
            counts["unlabelled_states"]+=1;witnesses.setdefault("unlabelled",sid)
            if "illegal_current" not in witnesses and not v.physical_arena(*v.decode(sid)[:3]):
                witnesses["illegal_current"]=sid
            continue
        counts["positive_states"]+=1;counts["maximum_rank"]=max(counts["maximum_rank"],rank)
        e,r0,r1,h=v.decode(sid);is_goal=v.goal(e,r0,r1);counts["positive_goal_states"]+=int(is_goal)
        witnesses.setdefault("positive",sid)
        if is_goal:witnesses.setdefault("goal",sid)
        if all(k in witnesses for k in ("policy_edge","non_goal_edge","illegal_slot")):continue
        legal=dict(v.candidate_env_slots(mask,e,r0,r1))
        if len(legal)<5:witnesses.setdefault("illegal_slot",(sid,next(x for x in range(5) if x not in legal)))
        for slot in legal:
            target=choices[sid*5+slot];witnesses.setdefault("policy_edge",(sid,slot,target))
            if not is_goal and target!=sid:witnesses.setdefault("non_goal_edge",(sid,slot,target))
    need(all(local.get("counts",{}).get(k)==value for k,value in counts.items()),"seed dense counts mismatch")
    result["independently_read_seed_counts"]=counts;result["witness_scan_states"]=len(ranks)

    def location(sid):
        e,a,b,h=v.decode(sid);return {"state_id":sid,"intruder":v.COORD[e],"robot0":v.COORD[a],
                                    "robot1":v.COORD[b],"history":h}
    def clone_choices(values):return array("I",values)
    def local_check(rr,cc,bound,sid):
        v.PositiveVerifier(rr,cc,mask).check_state(sid)
    def load_fixture(directory,source_override=None,profile_override=None):
        return v.load_inputs(directory,args.candidate_id,source_override or args.source,args.import_source,
                             profile_override or args.semantic_profile)
    def semantic_case(name,sid,expected,mutate,*,baseline=None,baseline_scope="ORIGINAL_FULL_PASS_CERTIFICATE",initial_x=None):
        record={"name":name,"kind":"SEMANTIC_REJECTION_AFTER_SUCCESSFUL_LOAD","baseline_scope":baseline_scope,
                "full_certificate_validity_claim_for_fixture":False};cases.append(record)
        if sid is None:record.update(status="NOT_TESTED",reason="no suitable bounded witness");return
        rr0,cc0,bound=baseline or (ranks,choices,rounds);record["source"]=location(sid)
        try:
            if initial_x is None:local_check(rr0,cc0,bound,sid)
            else:v.verify_initial(initial_x,rr0)
            record["baseline_selected_check_passed"]=True
            rr,cc=array("I",rr0),clone_choices(cc0);record["mutation"]=mutate(rr,cc)
            changed=store.repin_manifest(manifest,rr,cc,bound)
            directory,pins,_,_=store.create(name,changed,rr,cc)
            record.update(fixture_directory=str(directory),fixture_readback_pins=pins)
            fresh=load_fixture(directory);record.update(fixture_load_inputs_passed=True,loaded_input_pins=fresh["input_pins"])
            operation=(lambda:v.verify_initial(initial_x,fresh["ranks"])) if initial_x is not None else (
                lambda:local_check(fresh["ranks"],fresh["choices"],fresh["rounds"],sid))
            record.update(expected_rejection(v,operation,expected))
        except Exception as exc:record.update(status="FAIL_BASELINE_OR_FIXTURE_LOAD",exception_type=type(exc).__name__,reason=str(exc)[:4096])
    def rank_change(sid,value,clear=False):
        def mutate(rr,cc):
            before=rr[sid];rr[sid]=value
            if clear:
                for slot in range(5):cc[sid*5+slot]=v.UNUSED_TARGET
            return {"state_id":sid,"rank_before":before,"rank_after":value,"cleared_choices":clear}
        return mutate
    def choice_change(index,value):
        def mutate(rr,cc):
            before=cc[index];cc[index]=value;return {"choice_index":index,"before":before,"after":value}
        return mutate
    edge=witnesses.get("policy_edge");ng=witnesses.get("non_goal_edge");illegal=witnesses.get("illegal_slot")
    src,slot,target=edge if edge else (None,None,None)
    semantic_case("positive_missing_legal_ENV_slot",src,"missing or out-of-range SYS target",
                  choice_change(src*5+slot if edge else None,v.UNUSED_TARGET))
    semantic_case("positive_policy_on_illegal_ENV_slot",illegal[0] if illegal else None,
                  "SYS target for illegal ENV slot",choice_change(illegal[0]*5+illegal[1] if illegal else None,0))
    zero=witnesses.get("unlabelled")
    semantic_case("positive_unlabelled_state_has_policy",zero,"has a SYS policy target",choice_change(zero*5 if zero is not None else None,0))
    if edge:
        ne,n0,n1,nh=v.decode(target);wrong_env=v.encode((ne+1)%64,n0,n1,nh)
        illegal_sys=v.encode(ne,ne,n1,nh);wrong_history=target^1
    else:wrong_env=illegal_sys=wrong_history=0
    semantic_case("positive_target_changes_ENV_input",src,"changes selected ENV input",choice_change(src*5+slot if edge else None,wrong_env))
    semantic_case("positive_illegal_SYS_response",src,"not an original legal SYS response",choice_change(src*5+slot if edge else None,illegal_sys))
    semantic_case("positive_wrong_next_history",src,"not an original legal SYS response",choice_change(src*5+slot if edge else None,wrong_history))
    semantic_case("positive_policy_leaves_labelled_set",ng[0] if ng else None,"policy leaves labelled set",
                  rank_change(ng[2] if ng else None,0,True))
    semantic_case("positive_non_goal_rank_not_decreasing",ng[0] if ng else None,"does not strictly decrease",
                  rank_change(ng[2] if ng else None,ranks[ng[0]] if ng else 1))
    goal_sid=witnesses.get("goal")
    semantic_case("positive_goal_rank_convention",goal_sid,"goal/non-goal rank convention violated",rank_change(goal_sid,2))
    semantic_case("positive_non_goal_rank_convention",ng[0] if ng else None,"goal/non-goal rank convention violated",rank_change(ng[0] if ng else None,1))
    # Real dense-certificate state: physical goal e(1,7),r0(0,7),r1(1,6),hfalse.
    # Its physical stay must set history true. This is a full typed local witness,
    # not a claim that history=false at the corner is initializer-reachable.
    gs=v.encode(15,7,14,0)
    need(ranks[gs]==1 and v.goal(15,7,14) and v.physical_arena(15,7,14) and
         tuple(v.candidate_env_slots(3,15,7,14))==((0,15),) and choices[gs*5]==(gs^1),
         "real G goal-stay/history-update witness")
    semantic_case("positive_goal_literal_selfloop_breaks_history",gs,
                  "not an original legal SYS response",choice_change(gs*5,gs))
    invalid=witnesses.get("illegal_current")
    semantic_case("positive_illegal_current_arena",invalid,"violates the original current arena",rank_change(invalid,2))
    last=initials[-1];last_x=last["environment"]["intruderX"]
    semantic_case("positive_last_initializer_missing",last["state_id"],"selected initializer has no positive rank",
                  rank_change(last["state_id"],0,True),initial_x=last_x)
    first=witnesses.get("positive")
    semantic_case("positive_rank_exceeds_finite_bound",first,"rank exceeds finite bound",rank_change(first,v.STATE_COUNT+1))
    expected_semantic=14

    def loader_case(name,expected,changed_manifest=None,**payloads):
        record={"name":name,"kind":"LOAD_INPUTS_REJECTION","baseline_load_inputs_passed":True};cases.append(record)
        try:
            directory,pins,source_override,profile_override=store.create(name,manifest if changed_manifest is None else changed_manifest,
                                                                        ranks,choices,**payloads)
            record.update(fixture_directory=str(directory),fixture_readback_pins=pins,
                          source_or_profile_metadata_repinned=source_override is not None or profile_override is not None)
            record.update(expected_rejection(v,lambda:load_fixture(directory,source_override,profile_override),expected))
        except Exception as exc:record.update(status="FAIL_FIXTURE_CONSTRUCTION",exception_type=type(exc).__name__,reason=str(exc)[:4096])
    ordinary=json_bytes(manifest)
    duplicate=b'{"schema":'+json.dumps(manifest["schema"]).encode()+b','+ordinary[1:]
    loader_case("duplicate_manifest_key","duplicate JSON key",raw_manifest=duplicate)
    changed=copy.deepcopy(manifest);changed["candidate_mask"]=bool(mask)
    loader_case("Boolean_candidate_mask","candidate_mask: expected integer",changed)
    changed=copy.deepcopy(manifest);changed["candidate_id"]="capture_stay_both"
    loader_case("candidate_id_mismatch","certificate candidate_id mismatch",changed)
    changed=copy.deepcopy(manifest);changed["certificate_kind"]=v.NEGATIVE_KIND
    loader_case("certificate_kind_mismatch","certificate kind/status mismatch",changed)
    changed=copy.deepcopy(manifest);changed["semantic_profile"]["id"]="unapproved-profile"
    loader_case("semantic_profile_id_mismatch","wrong semantic profile id",changed)
    raw_choices=bytearray(u32_bytes(choices));raw_choices[0]^=1
    loader_case("choice_payload_hash_mismatch",store.choice_field+": payload hash mismatch",raw_choices=raw_choices)
    loader_case("truncated_rank_payload","incorrect input size",raw_ranks=u32_bytes(ranks)[:-1])
    changed_source=bytearray(read_regular(args.source,8192));changed_source[0]^=1
    loader_case("rehashed_source_byte_flip","actual candidate source hash mismatch",source_raw=changed_source)
    profile_raw=read_regular(args.semantic_profile,1024*1024)
    marker=b'"ENV_justice_count": 0';need(profile_raw.count(marker)==1,"unique profile mutation marker")
    changed_profile=profile_raw.replace(marker,b'"ENV_justice_count": 1')
    need(len(changed_profile)==len(profile_raw),"same-sized profile mutation")
    loader_case("rehashed_profile_byte_flip","actual semantic profile hash mismatch",profile_raw=changed_profile)
    changed=copy.deepcopy(manifest);changed[store.choice_field]["file"]="../"+store.choice_file
    loader_case("invalid_choice_filename",store.choice_field+": filename must be "+store.choice_file,changed)
    changed=copy.deepcopy(manifest);changed["status"]="UNKNOWN"
    loader_case("UNKNOWN_is_not_proof","no positive or negative certificate candidate",changed)
    changed=copy.deepcopy(manifest);changed["candidate_mask"]=0
    loader_case("nonG_numeric_mask","candidate_mask: expected integer",changed)
    expected_total=expected_semantic+12
    need(len(cases)==expected_total,"exact sign-specific control roster")
    for record in originals+store.pins:
        actual=pin(record["path"],read_regular(record["path"],max(record["bytes"],1)))
        need(pin_key(actual)==pin_key(record),"protected input or fixture changed: "+record["path"])
    result.update(expected_semantic_cases=expected_semantic,expected_loader_cases=12,expected_cases=expected_total,
                  all_original_inputs_unchanged=True,all_fixture_pins_rechecked=True,
                  fixture_directories=store.directories,fixture_bytes_written=store.written,
                  passed_cases=sum(c["status"]=="PASS_EXPECTED_REJECTION" for c in cases),
                  not_tested_cases=sum(c["status"]=="NOT_TESTED" for c in cases),
                  bounded_failure_examples=[c for c in cases if c["status"]!="PASS_EXPECTED_REJECTION"][:MAX_FAILURE_EXAMPLES])
    if all(c["status"]=="PASS_EXPECTED_REJECTION" for c in cases):
        result["status"]="PASS_BOUNDED_G_POSITIVE_CERTIFICATE_REJECTION_CONTROLS";return 0
    result["status"]="INCOMPLETE_OR_FAILED_G_POSITIVE_CERTIFICATE_REJECTION_CONTROLS";return 2


def on_timeout(_signum,_frame):raise HarnessTimeout("internal150second rejection-control cap reached")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ("certificate-dir","verification-result","qualification-result","source","import-source","semantic-profile","fixtures-dir","out"):
        parser.add_argument("--"+name,type=Path,required=True)
    parser.add_argument("--candidate-id",required=True);args=parser.parse_args();started=time.monotonic()
    flags=os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,"O_NOFOLLOW",0)
    with os.fdopen(os.open(args.out,flags,0o644),"wb") as output:
        result={"schema":"v54-G-positive-certificate-rejection-controls-v1",
                "status":"UNVERIFIED_REJECTION_CONTROLS","full_proof_claim":False,
                "scope":"Negative controls of selected local and loader branches for a fully verified exact G positive strategy",
                "full_certificate_verification_called":False,"no_native_BDD_CSR_solver_or_subprocess_execution":True,
                "bounds":{"internal_seconds":INTERNAL_SECONDS,"external_seconds":180,"external_rss_gib":2,
                          "max_fixture_directories":MAX_FIXTURE_DIRS,"max_written_bytes":MAX_WRITTEN_BYTES,
                          "max_report_bytes":MAX_JSON_BYTES,"max_failure_examples":MAX_FAILURE_EXAMPLES}}
        previous=signal.signal(signal.SIGALRM,on_timeout);signal.setitimer(signal.ITIMER_REAL,INTERNAL_SECONDS)
        try:code=run(args,result)
        except (Exception,HarnessTimeout) as exc:
            result.update(status="UNKNOWN_OR_FAILED_G_POSITIVE_REJECTION_CONTROLS",exception_type=type(exc).__name__,reason=str(exc)[:4096]);code=2
        finally:signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,previous)
        result.update(elapsed_seconds=time.monotonic()-started,created_utc=datetime.now(timezone.utc).isoformat())
        output.write(json_bytes(result));output.flush();os.fsync(output.fileno())
    print(json.dumps({"status":result["status"],"report":str(args.out.absolute())}));return code


if __name__=="__main__":raise SystemExit(main())

