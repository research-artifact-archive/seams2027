#!/usr/bin/env python3
"""Independent positive/negative certificates for the exact V54 deadend-stay source.

Only the two avoidance assumptions vary. Every candidate is selected by a
reviewed name/mask/source/import/profile binding. No native W, BDD, generator
relation, or producer fixed-point claim is used as semantic evidence.
"""
from __future__ import annotations

import argparse
from array import array
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import sys
import time
import unicodedata

D = Path(__file__).resolve().parent
BASE = D.parent
STATE_COUNT = 64 * 64 * 64 * 2
RANK_BYTES = STATE_COUNT * 4
ACTION_BYTES = STATE_COUNT
POLICY_BYTES = STATE_COUNT * 5 * 4
MANIFEST_LIMIT = 1024 * 1024
REPORT_LIMIT = 2 * 1024 * 1024
EXAMPLE_LIMIT = 8
NO_ACTION = 255
Q_UNCOMPUTED = 255
UNUSED_TARGET = 0xffffffff
INTERNAL_SECONDS = 150
SCHEMA = "v54-source-game-certificate-v1"
ENCODING = "(((intruderCell*64+robot0Cell)*64+robot1Cell)<<1)|history; cell=x*8+y; history=0:false,1:true"
SEMANTICS_ID = "fixed355-deadend-stay-source-game-v1"
PROFILE_BYTES = 7399
PROFILE_SHA256 = "948fe2bff3eec44fc43c156dee776fc0d18032634c7a4f332c665db2f15c5e72"
IMPORT_BYTES = 49400
IMPORT_SHA256 = "5c45b64f7b9b9f4f480d3cb485adcd8a772bce6d6c11356345386c5f143333cc"
CANDIDATES = {
    "deadend_stay_both": (3, 4714, "cd4c04ad1fdfb7454a8c5b5da92558da5496cf1daefe9283673ee13b3aeda9cc"),
}
NEGATIVE_CANDIDATE = "NEGATIVE_COUNTERCERTIFICATE_CANDIDATE"
POSITIVE_CANDIDATE = "POSITIVE_STRATEGY_CERTIFICATE_CANDIDATE"
NEGATIVE_KIND = "environment_joint_cobuchi_counterstrategy"
POSITIVE_KIND = "system_joint_buchi_strategy"
NEGATIVE_PASS = "PASS_CANDIDATE_SOURCE_JOINT_UNREALIZABILITY_COUNTERCERTIFICATE"
POSITIVE_PASS = "PASS_CANDIDATE_SOURCE_JOINT_REALIZABILITY_STRATEGY_CERTIFICATE"


class Rejected(Exception):
    """Malformed, unqualified, or locally invalid certificate."""


class VerificationTimeout(BaseException):
    """Cannot be swallowed by local ordinary-exception handlers."""


def require(condition, message):
    if not condition:
        raise Rejected(message)

def exact_int(value, minimum, maximum, field):
    require(type(value) is int and minimum <= value <= maximum,
            f"{field}: expected integer in [{minimum}, {maximum}]")
    return value

def exact_bool(value, field):
    require(type(value) is bool, f"{field}: expected Boolean")
    return value

def unique_object(pairs):
    obj = {}
    for key, value in pairs:
        require(key not in obj, f"duplicate JSON key: {key!r}")
        obj[key] = value
    return obj

def reject_json_constant(value):
    raise Rejected(f"non-finite JSON constant: {value}")

def read_regular(path, exact_size=None, limit=None):
    """One bounded read of a regular final entry, with final symlinks refused."""
    path = Path(path)
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
    require(not path.is_symlink(), f"symlink input refused: {path}")
    require(stat.S_ISREG(path.lstat().st_mode), f"not a regular file: {path}")
    with os.fdopen(os.open(path, flags), "rb") as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode), f"not a regular file: {path}")
        if exact_size is not None:
            require(before.st_size == exact_size, f"incorrect input size: {path}")
            cap = exact_size
        else:
            require(limit is not None and before.st_size <= limit,
                    f"input exceeds size bound: {path}")
            cap = limit
        data = stream.read(cap + 1)
        after = os.fstat(stream.fileno())
        require(len(data) == before.st_size and len(data) <= cap,
                f"incomplete or excessive read: {path}")
        require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns,
                 before.st_ctime_ns) ==
                (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns,
                 after.st_ctime_ns), f"input changed while reading: {path}")
    return data

def digest(data):
    return hashlib.sha256(data).hexdigest()

def pin_record(path, data):
    return {"path": str(Path(path).absolute()), "bytes": len(data),
            "sha256": digest(data)}

def require_pin(obj, expected_size, expected_sha, field):
    require(type(obj) is dict, f"{field}: expected object")
    exact_int(obj.get("bytes"), expected_size, expected_size, f"{field}.bytes")
    require(obj.get("sha256") == expected_sha, f"{field}: SHA-256 mismatch")


def path_key(path):
    return unicodedata.normalize("NFC", str(Path(path).resolve()))


def require_reference(obj, actual, field):
    require_pin(obj, actual["bytes"], actual["sha256"], field)
    require(type(obj.get("path")) is str and path_key(obj["path"]) == path_key(actual["path"]),
            f"{field}: actual path mismatch")


def parse_json(raw, field):
    try:
        value = json.loads(raw.decode("utf-8"), object_pairs_hook=unique_object,
                           parse_constant=reject_json_constant)
    except (UnicodeError, ValueError, RecursionError) as exc:
        raise Rejected(f"{field}: invalid JSON: {type(exc).__name__}") from exc
    require(type(value) is dict, f"{field}: expected object")
    return value


def qualify_candidate(candidate_id, source_path, import_path, profile_path):
    require(candidate_id in CANDIDATES, "candidate_id is not in the fixed source roster")
    mask, source_bytes, source_sha = CANDIDATES[candidate_id]
    source_data = read_regular(source_path, exact_size=source_bytes)
    import_data = read_regular(import_path, exact_size=IMPORT_BYTES)
    profile_data = read_regular(profile_path, exact_size=PROFILE_BYTES)
    require(digest(source_data) == source_sha, "actual candidate source hash mismatch")
    require(digest(import_data) == IMPORT_SHA256, "actual original import hash mismatch")
    require(digest(profile_data) == PROFILE_SHA256, "actual semantic profile hash mismatch")
    # The profile is a fixed reviewed data artifact, not executable configuration.
    parse_json(profile_data, "semantic profile")
    return mask, [pin_record(source_path, source_data), pin_record(import_path, import_data),
                  pin_record(profile_path, profile_data)]


def decode_u32(raw, count, field):
    values = array("I")
    require(values.itemsize == 4, "platform unsigned-int width is not32bits")
    values.frombytes(raw)
    if sys.byteorder != "little":
        values.byteswap()
    require(len(values) == count, f"{field}: incorrect decoded element count")
    return values


def load_inputs(certificate_dir, candidate_id, source_path, import_path, profile_path):
    mask, qualification_pins = qualify_candidate(candidate_id, source_path, import_path, profile_path)
    directory = Path(certificate_dir).absolute()
    require(not directory.is_symlink() and directory.is_dir(),
            "certificate directory must be an existing nonsymlink directory")
    manifest_path = directory / "certificate.json"
    manifest_data = read_regular(manifest_path, limit=MANIFEST_LIMIT)
    manifest = parse_json(manifest_data, "certificate")
    require(manifest.get("schema") == SCHEMA, "wrong certificate schema")
    require(manifest.get("candidate_id") == candidate_id, "certificate candidate_id mismatch")
    exact_int(manifest.get("candidate_mask"), mask, mask, "candidate_mask")
    require(manifest.get("state_encoding") == ENCODING, "wrong state encoding")
    exact_int(manifest.get("state_count"), STATE_COUNT, STATE_COUNT, "state_count")
    require_reference(manifest.get("source"), qualification_pins[0], "source")
    require_reference(manifest.get("import"), qualification_pins[1], "import")
    require_reference(manifest.get("semantic_profile"), qualification_pins[2], "semantic_profile")
    require(manifest["semantic_profile"].get("id") == SEMANTICS_ID, "wrong semantic profile id")
    require(exact_bool(manifest.get("source_pins_verified"), "source_pins_verified"),
            "producer source pin claim is false")
    exact_bool(manifest.get("fixed_point_complete"), "fixed_point_complete")
    exact_bool(manifest.get("early_negative_stop"), "early_negative_stop")
    status = manifest.get("status")
    require(status in (NEGATIVE_CANDIDATE, POSITIVE_CANDIDATE),
            "no positive or negative certificate candidate; UNKNOWN is not a proof")
    positive = status == POSITIVE_CANDIDATE
    kind = POSITIVE_KIND if positive else NEGATIVE_KIND
    require(manifest.get("certificate_kind") == kind, "certificate kind/status mismatch")
    rounds = exact_int(manifest.get("completed_outer_rounds"), 0 if positive else 1,
                       STATE_COUNT + 1, "completed_outer_rounds")
    if positive:
        require(manifest.get("winning_initial_x") == list(range(8)) and
                all(type(x) is int for x in manifest["winning_initial_x"]),
                "positive initializer metadata must list exact0..7")
        require(manifest.get("ranks") is None and manifest.get("actions") is None,
                "positive certificate must not contain negative payload metadata")
        exact_int(manifest.get("maximum_winning_rank"), 1, STATE_COUNT, "maximum_winning_rank")
        exact_int(manifest.get("winning_state_count"), 1, STATE_COUNT, "winning_state_count")
        payload_spec = (("win_ranks", "win_ranks.u32le", RANK_BYTES),
                        ("chosen_sys", "chosen_sys.u32le", POLICY_BYTES))
        selected_x = None
    else:
        selected_x = exact_int(manifest.get("selected_initial_x"), 0, 7, "selected_initial_x")
        require(manifest.get("win_ranks") is None and manifest.get("chosen_sys") is None,
                "negative certificate must not contain positive payload metadata")
        payload_spec = (("ranks", "ranks.u32le", RANK_BYTES),
                        ("actions", "chosen_env.u8", ACTION_BYTES))
    pins = [pin_record(manifest_path, manifest_data)] + qualification_pins
    payloads = {}
    for field, filename, size in payload_spec:
        info = manifest.get(field)
        require(type(info) is dict and info.get("file") == filename,
                f"{field}: filename must be {filename}")
        exact_int(info.get("bytes"), size, size, f"{field}.bytes")
        expected_sha = info.get("sha256")
        require(type(expected_sha) is str and len(expected_sha) == 64 and
                all(ch in "0123456789abcdef" for ch in expected_sha), f"{field}: invalid SHA256")
        path = directory / filename
        raw = read_regular(path, exact_size=size)
        require(digest(raw) == expected_sha, f"{field}: payload hash mismatch")
        pins.append(pin_record(path, raw))
        payloads[field] = raw
    ranks = decode_u32(payloads.pop("win_ranks" if positive else "ranks"), STATE_COUNT, "ranks")
    choices = (decode_u32(payloads.pop("chosen_sys"), STATE_COUNT * 5, "chosen_sys") if positive
               else payloads.pop("actions"))
    return {"manifest": manifest, "candidate_id": candidate_id, "mask": mask,
            "kind": kind, "positive": positive, "rounds": rounds, "selected_x": selected_x,
            "ranks": ranks, "choices": choices, "input_pins": pins}


# The following finite source factors are unchanged from the qualified V53
# verifier. Only the ENV action iterator below is candidate-specific.
COORD = tuple(divmod(cell, 8) for cell in range(64))


def bounded_moves(cell):
    x, y = COORD[cell]
    yield cell
    if x > 0:
        yield (x - 1) * 8 + y
    if x < 7:
        yield (x + 1) * 8 + y
    if y > 0:
        yield x * 8 + y - 1
    if y < 7:
        yield x * 8 + y + 1

MOVES = tuple(tuple(bounded_moves(cell)) for cell in range(64))
ENV_SLOT_DELTAS = ((0,0),(-1,0),(1,0),(0,-1),(0,1))

def outside_obstacle(cell):
    x, y = COORD[cell]
    return not (2 <= x <= 5 and y == 1)

def adjacent(first, second):
    x1, y1 = COORD[first]
    x2, y2 = COORD[second]
    return abs(x1 - x2) + abs(y1 - y2) == 1

def physical_arena(e, r0, r1):
    return (outside_obstacle(e) and outside_obstacle(r0) and
            outside_obstacle(r1) and e != r0 and e != r1 and r0 != r1)

def encode(e, r0, r1, history):
    return (((e * 64 + r0) * 64 + r1) << 1) | history

def decode(state_id):
    packed, history = divmod(state_id, 2)
    packed, r1 = divmod(packed, 64)
    e, r0 = divmod(packed, 64)
    return e, r0, r1, history

def original_sys_responses(r0, r1, history, next_e):
    # ONCE is evaluated in the CURRENT state for robot1's movement gate.
    robot1_moves = MOVES[r1] if history else (r1,)
    for next_r0 in MOVES[r0]:
        if not outside_obstacle(next_r0) or next_r0 == next_e:
            continue
        next_history = update_history(history, next_r0)
        for next_r1 in robot1_moves:
            if (not outside_obstacle(next_r1) or next_r1 == next_e or
                    next_r1 == next_r0):
                continue
            yield next_r0, next_r1, next_history

def update_history(history, next_r0):
    return int(bool(history) or next_r0 == 7)

def goal(e, r0, r1):
    return adjacent(r0, e) and adjacent(r1, e)

def theta_system(r0, r1, history):
    # ONCE(phi) starts at phi(current); thetaS fixes r0=(0,0), hence false.
    return r0 == 0 and r1 == 56 and history == int(r0 == 7)

def verify_initial(selected_x, ranks):
    e = selected_x * 8 + 7
    require(COORD[e][1] == 7 and outside_obstacle(e), "invalid ENV initializer")
    initializers = []
    # Explicitly enumerate all typed SYS/aux values; no producer roster is used.
    for r0 in range(64):
        for r1 in range(64):
            for history in (0, 1):
                if theta_system(r0, r1, history):
                    require(physical_arena(e, r0, r1), "illegal initial arena")
                    state_id = encode(e, r0, r1, history)
                    require(ranks[state_id] > 0, "selected initializer has no positive rank")
                    initializers.append(state_id)
    require(initializers == [encode(e, 0, 56, 0)],
            "original SYS/aux initialization is not the required singleton")
    return {"environment": {"intruderX": selected_x, "intruderY": 7},
            "all_system_aux_initializers_enumerated": True,
            "system_aux_initializer_count": len(initializers),
            "state_id": initializers[0], "rank": ranks[initializers[0]],
            "system": {"robotX0": 0, "robotY0": 0, "robotX1": 7,
                       "robotY1": 0, "ONCE_robot0AtButtomLeftCorner": False}}


def original_env_slots(e, r0, r1):
    """Complete old rhoE over typed stay/cardinal cells, without a current guard."""
    x, y = COORD[e]
    a0, a1 = adjacent(r0, e), adjacent(r1, e)
    x0, y0 = COORD[r0]
    x1, y1 = COORD[r1]
    for slot, (dx, dy) in enumerate(ENV_SLOT_DELTAS):
        nx, ny = x + dx, y + dy
        if not (0 <= nx <= 7 and 0 <= ny <= 7):
            continue
        next_e = nx * 8 + ny
        if (outside_obstacle(next_e) and
                (not a0 or (nx != x0 and ny != y0)) and
                (not a1 or (nx != x1 and ny != y1))):
            yield slot, next_e


def candidate_env_slots(mask, e, r0, r1):
    """Literal (E0 OR D) AND (E1 OR D), D=!Q_old AND ENVstay.

    Q_old is independently enumerated from the old complete action relation.
    The new relation still applies NEXT-obstacle and typed movement factors;
    current intruder obstacle values are retained in the full typed semantics.
    The mask is fixed compatibility metadata, not a configurable clause family.
    """
    require(type(mask) is int and mask == 3, "deadend-stay candidate mask must be3")
    old_q = bool(tuple(original_env_slots(e, r0, r1)))
    x, y = COORD[e]
    a0, a1 = adjacent(r0, e), adjacent(r1, e)
    x0, y0 = COORD[r0]
    x1, y1 = COORD[r1]
    for slot, (dx, dy) in enumerate(ENV_SLOT_DELTAS):
        nx, ny = x + dx, y + dy
        if not (0 <= nx <= 7 and 0 <= ny <= 7):
            continue
        next_e = nx * 8 + ny
        if not outside_obstacle(next_e):
            continue
        exception = not old_q and slot == 0
        clause0 = (not a0) or (nx != x0 and ny != y0) or exception
        clause1 = (not a1) or (nx != x1 and ny != y1) or exception
        if clause0 and clause1:
            yield slot, next_e


def candidate_env_actions(mask, e, r0, r1):
    for _slot, next_e in candidate_env_slots(mask, e, r0, r1):
        yield next_e


class NegativeVerifier:
    def __init__(self, ranks, actions, rounds, mask):
        exact_int(mask, 3, 3, "candidate mask")
        self.mask = mask
        self.ranks, self.actions, self.rounds = ranks, actions, rounds
        # Q is independent of history.  255 means unknown; values 0..5 are exact.
        self.q_cache = bytearray([Q_UNCOMPUTED]) * (STATE_COUNT // 2)
        self.counts = Counter()
        self.examples = {"q_false_terminal": [], "no_system_response": [],
                         "target_q_false": []}

    def q_count(self, e, r0, r1):
        slot = (e * 64 + r0) * 64 + r1
        count = self.q_cache[slot]
        if count == Q_UNCOMPUTED:
            count = sum(1 for _ in candidate_env_actions(self.mask, e, r0, r1))
            self.q_cache[slot] = count
            self.counts["q_distinct_physical_positions_exhausted"] += 1
        return count

    def example(self, kind, value):
        if len(self.examples[kind]) < EXAMPLE_LIMIT:
            self.examples[kind].append(value)

    def check_state(self, state_id):
        rank, action = self.ranks[state_id], self.actions[state_id]
        if rank == 0:
            require(action == NO_ACTION,
                    f"unlabelled state {state_id} has a non-255 action")
            self.counts["unlabelled_states"] += 1
            return
        self.counts["positive_states"] += 1
        self.counts["maximum_rank"] = max(self.counts["maximum_rank"], rank)
        require(rank <= self.rounds, f"state {state_id} rank exceeds completed rounds")
        e, r0, r1, history = decode(state_id)
        require(physical_arena(e, r0, r1),
                f"positive state {state_id} violates the original current arena")
        source_goal = goal(e, r0, r1)
        self.counts["positive_goal_states"] += int(source_goal)
        q_count = self.q_count(e, r0, r1)
        if q_count == 0:
            require(action == NO_ACTION,
                    f"Q-false state {state_id} must have terminal action 255")
            self.counts["q_false_terminal_states"] += 1
            self.example("q_false_terminal", {"state_id": state_id, "rank": rank})
            return
        require(0 <= action < 64, f"nonterminal state {state_id} has invalid action")
        require(action in candidate_env_actions(self.mask, e, r0, r1),
                f"state {state_id} chooses an original-illegal ENV action")
        self.counts["legal_selected_environment_actions"] += 1
        self.counts["system_move_products_examined"] += (
            len(MOVES[r0]) * (len(MOVES[r1]) if history else 1))
        responses = 0
        for next_r0, next_r1, next_history in original_sys_responses(
                r0, r1, history, action):
            responses += 1
            self.counts["original_legal_system_responses"] += 1
            require(physical_arena(action, next_r0, next_r1),
                    f"internal source semantics produced illegal target from {state_id}")
            target = encode(action, next_r0, next_r1, next_history)
            if self.q_count(action, next_r0, next_r1) == 0:
                self.counts["target_q_false_responses"] += 1
                self.example("target_q_false", {"source": state_id, "target": target})
                continue
            target_rank = self.ranks[target]
            require(target_rank > 0,
                    f"state {state_id} has Q-true response {target} without a rank")
            require(target_rank <= rank,
                    f"rank increases on response {state_id}->{target}")
            require(not source_goal or target_rank < rank,
                    f"goal-state response {state_id}->{target} does not strictly decrease")
            self.counts["nonincreasing_rank_responses"] += 1
            self.counts["strict_goal_decrease_responses"] += int(source_goal)
        require(responses <= 25, "internal response bound violated")
        if responses == 0:
            self.counts["no_system_response_states"] += 1
            self.example("no_system_response", {"state_id": state_id, "rank": rank,
                                                 "selected_env_cell": action})

    def check_all(self):
        require(len(self.ranks) == STATE_COUNT and len(self.actions) == STATE_COUNT,
                "local verifier requires complete dense arrays")
        for state_id in range(STATE_COUNT):
            self.check_state(state_id)
        require(self.counts["positive_states"] > 0, "certificate has no positive labels")
        require(self.counts["positive_states"] + self.counts["unlabelled_states"] ==
                STATE_COUNT, "incomplete state coverage")
        return {"counts": dict(sorted(self.counts.items())),
                "bounded_failure_examples": self.examples,
                "every_positive_state_checked": True,
                "every_unlabelled_action_checked": True,
                "all_legal_system_responses_independently_enumerated": True}


class PositiveVerifier:
    def __init__(self, ranks, policy, mask):
        exact_int(mask, 3, 3, "candidate mask")
        self.ranks, self.policy, self.mask = ranks, policy, mask
        self.counts = Counter()

    def check_state(self, state_id):
        rank = self.ranks[state_id]
        start = state_id * 5
        if rank == 0:
            require(all(self.policy[start + slot] == UNUSED_TARGET for slot in range(5)),
                    f"unlabelled state {state_id} has a SYS policy target")
            self.counts["unlabelled_states"] += 1
            return
        require(rank <= STATE_COUNT, f"positive state {state_id} rank exceeds finite bound")
        e, r0, r1, history = decode(state_id)
        require(physical_arena(e, r0, r1),
                f"positive state {state_id} violates the original current arena")
        source_goal = goal(e, r0, r1)
        require((rank == 1) if source_goal else (rank >= 2),
                f"state {state_id} goal/non-goal rank convention violated")
        legal = dict(candidate_env_slots(self.mask, e, r0, r1))
        require(len(legal) > 0, f"labelled state {state_id} has candidate Q=false")
        self.counts["positive_states"] += 1
        self.counts["maximum_rank"] = max(self.counts["maximum_rank"], rank)
        self.counts["positive_goal_states"] += int(source_goal)
        self.counts["candidate_ENV_actions"] += len(legal)
        for slot in range(5):
            target = self.policy[start + slot]
            if slot not in legal:
                require(target == UNUSED_TARGET,
                        f"state {state_id} has SYS target for illegal ENV slot {slot}")
                self.counts["unused_illegal_ENV_slots"] += 1
                continue
            require(0 <= target < STATE_COUNT,
                    f"state {state_id} missing or out-of-range SYS target for ENV slot {slot}")
            ne, nr0, nr1, nh = decode(target)
            require(ne == legal[slot],
                    f"state {state_id} SYS target changes selected ENV input at slot {slot}")
            require((nr0, nr1, nh) in original_sys_responses(r0, r1, history, ne),
                    f"state {state_id} target {target} is not an original legal SYS response")
            require(physical_arena(ne, nr0, nr1),
                    f"state {state_id} target {target} violates current arena")
            target_rank = self.ranks[target]
            require(target_rank > 0, f"state {state_id} policy leaves labelled set at target {target}")
            require(source_goal or target_rank < rank,
                    f"non-goal state {state_id} target {target} does not strictly decrease")
            self.counts["chosen_original_legal_SYS_responses"] += 1
            self.counts["strict_non_goal_decrease_responses"] += int(not source_goal)
            self.counts["goal_closure_responses"] += int(source_goal)

    def check_all(self):
        require(len(self.ranks) == STATE_COUNT and len(self.policy) == STATE_COUNT * 5,
                "positive verifier requires complete dense arrays")
        for state_id in range(STATE_COUNT):
            self.check_state(state_id)
        require(self.counts["positive_states"] > 0, "positive certificate has no labels")
        require(self.counts["positive_states"] + self.counts["unlabelled_states"] == STATE_COUNT,
                "incomplete positive state coverage")
        return {"counts": dict(sorted(self.counts.items())),
                "every_positive_state_checked": True,
                "every_unlabelled_and_illegal_ENV_slot_checked": True,
                "every_candidate_legal_ENV_action_covered": True,
                "each_chosen_SYS_response_independently_checked": True,
                "candidate_Q_true_at_every_labelled_state": True}


def recheck_pins(pins):
    for expected in pins:
        actual = pin_record(expected["path"], read_regular(expected["path"], exact_size=expected["bytes"]))
        require(actual["bytes"] == expected["bytes"] and actual["sha256"] == expected["sha256"],
                "input changed after checking: " + expected["path"])


def verify(certificate_dir, candidate_id, source_path, import_path, profile_path):
    loaded = load_inputs(certificate_dir, candidate_id, source_path, import_path, profile_path)
    manifest, ranks, choices, mask = (loaded[name] for name in ("manifest", "ranks", "choices", "mask"))
    if loaded["positive"]:
        initializers = [verify_initial(x, ranks) for x in range(8)]
        local = PositiveVerifier(ranks, choices, mask).check_all()
        require(local["counts"]["maximum_rank"] == manifest["maximum_winning_rank"],
                "positive maximum-rank metadata differs from complete check")
        require(local["counts"]["positive_states"] == manifest["winning_state_count"],
                "positive state-count metadata differs from complete check")
        status = POSITIVE_PASS
        conclusion = "The exact candidate source has a system strategy satisfying strict correctness and all-prefix cooperation for every original ENV initializer."
        proof = "All eight original ENV initializers have their independently enumerated singleton SYS/aux initial response in the labelled set. Every labelled state has candidate Q=true; every candidate-legal ENV move has a checked legal SYS response into the labelled set. On every edge from a non-goal state the positive natural rank strictly decreases. Thus every infinite candidate-legal path visits the sole SYS goal infinitely often. With no ENV justice and finite branching, Q plus complete policy closure supplies a candidate-legal infinite continuation after every reachable legal prefix."
        scope = {"joint_strict_and_all_prefix_cooperation_realizable": True,
                 "all_eight_environment_initializers_covered": True,
                 "strict_correctness_established": True, "all_prefix_cooperation_established": True,
                 "all_typed_states_winning": False, "generator_fixed_point_completeness_certified": False}
    else:
        initializers = [verify_initial(loaded["selected_x"], ranks)]
        local = NegativeVerifier(ranks, choices, loaded["rounds"], mask).check_all()
        status = NEGATIVE_PASS
        conclusion = "The exact candidate source has no system strategy satisfying both strict correctness and all-prefix cooperation for the certified ENV initializer; its all-initializers joint obligation is unrealizable."
        proof = "The selected original ENV initializer has its independently enumerated singleton SYS/aux initial response positively ranked. Every chosen candidate-legal ENV action covers all original legal SYS replies. Every reply is either a separately proved candidate-Q-false cooperation failure or reaches a positive natural rank that never increases and strictly decreases at every SYS-goal source. A legal ENV action without a legal SYS reply is an explicit joint failure. Otherwise an infinite candidate-legal path visits the sole SYS goal only finitely often. There is no ENV justice."
        scope = {"joint_strict_and_all_prefix_cooperation_unrealizable": True,
                 "strict_correctness_alone_unrealizable": False,
                 "all_eight_environment_initializers_losing": False,
                 "generator_fixed_point_completeness_certified": False}
    recheck_pins(loaded["input_pins"])
    return {"status": status, "candidate_id": candidate_id, "candidate_mask": mask,
            "certificate_kind": loaded["kind"], "conclusion": conclusion, "claim_scope": scope,
            "initializations": initializers, "local_certificate_checks": local, "proof": proof,
            "source_semantics": {"id": SEMANTICS_ID, "exact_candidate_source_import_profile_qualified": True,
                "original_environment_justice_count": 0, "environment_moves_first": True,
                "Q": "exists a legal ENV move of this exact candidate source",
                "candidate_ENV_change": "both E_i become E_i OR (!Q_original AND ENVstay); no capture conjunct",
                "Q_original_computed_from_complete_original_ENV_action_set": True,
                "candidate_mask_is_fixed_compatibility_metadata": True,
                "SYS_initial_history_goal_unchanged": True,
                "history_next": "history OR next_robot0=(0,7)",
                "positive_goal_edges_do_not_require_literal_state_id_stutter": True},
            "producer_metadata_not_used_as_semantic_proof": {
                "completed_outer_rounds": loaded["rounds"], "fixed_point_complete": manifest["fixed_point_complete"],
                "early_negative_stop": manifest["early_negative_stop"]},
            "input_pins": loaded["input_pins"], "all_input_pins_rechecked_after_verification": True,
            "no_native_W_BDD_CSR_or_producer_transition_tables_used": True,
            "bounds": {"dense_states": STATE_COUNT, "negative_payload_bytes": RANK_BYTES+ACTION_BYTES,
                "positive_payload_bytes": RANK_BYTES+POLICY_BYTES, "max_ENV_moves_per_state": 5,
                "max_SYS_response_products_per_ENV_move": 25, "internal_wall_seconds": INTERNAL_SECONDS}}


def on_timeout(_signum, _frame):
    raise VerificationTimeout("internal150second verification cap reached")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--certificate-dir", type=Path, required=True)
    parser.add_argument("--candidate-id", choices=tuple(CANDIDATES), required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--import-source", type=Path, required=True)
    parser.add_argument("--semantic-profile", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    started = time.monotonic()
    self_pin = pin_record(__file__, read_regular(__file__, limit=256*1024))
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    with os.fdopen(os.open(args.out, flags, 0o644), "w", encoding="utf-8") as out:
        previous = signal.signal(signal.SIGALRM, on_timeout)
        signal.setitimer(signal.ITIMER_REAL, INTERNAL_SECONDS)
        try:
            result = verify(args.certificate_dir, args.candidate_id, args.source,
                            args.import_source, args.semantic_profile)
            recheck_pins([self_pin])
            code = 0
        except (Rejected, OSError, ValueError, OverflowError, RecursionError, VerificationTimeout) as exc:
            result = {"status": "REJECTED_OR_UNVERIFIED_CANDIDATE_CERTIFICATE",
                      "candidate_id": args.candidate_id, "proof_conclusion_established": False,
                      "error_type": type(exc).__name__, "reason": str(exc)[:4096]}
            code = 2
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
            signal.signal(signal.SIGALRM, previous)
        result.update({"schema": "v54-source-game-certificate-verification-v1",
                       "created_utc": datetime.now(timezone.utc).isoformat(),
                       "elapsed_seconds": time.monotonic() - started, "verifier_pin": self_pin})
        rendered = json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
        require(len(rendered.encode()) <= REPORT_LIMIT, "report exceeds2MiB bound")
        out.write(rendered); out.flush(); os.fsync(out.fileno())
    print(json.dumps({"status": result["status"], "report": str(args.out.absolute())}))
    return code


if __name__ == "__main__":
    raise SystemExit(main())

