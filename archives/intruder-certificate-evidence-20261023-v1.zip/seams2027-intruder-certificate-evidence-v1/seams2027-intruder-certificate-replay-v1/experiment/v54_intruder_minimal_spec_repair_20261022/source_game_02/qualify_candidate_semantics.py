#!/usr/bin/env python3
"""Finite independent source-factor qualification for the exact V54 deadend-stay candidate.

Root-only execution. The reference is the separately authored pinned V53 scalar
source semantics, plus the literal per-clause E_i OR (!Q_original AND ENVstay) translation.
No generator, policy, CSR, BDD, native relation or winning-set data is read.
"""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import os
import re
import signal
import stat
import sys
import time
from types import ModuleType
from datetime import datetime, timezone

D = Path(__file__).resolve().parent
B = D.parent
CHECKER_SHA = 'e1a2ef75b2fc03eb3463b0278c090781bf02be0f942dfe498f7bc36679319eb7'
CHECKER_BYTES = 32951
REFERENCE_SHA = '9734504093ee83870c9223e61fe980c9af30fa4b787fe96b7eaafd24ed3ffe78'
REFERENCE_BYTES = 3175
OLD_CHECKER_SHA = '2c74a8dc80aa4dc86626d4a85f432b4a1268112f7a59538e8780a7907ffdea33'
OLD_CHECKER_BYTES = 21773
SHARED_FACTORS = ('bounded_moves','outside_obstacle','adjacent','physical_arena','encode','decode',
                  'original_sys_responses','update_history','goal','theta_system','verify_initial')
INTERNAL_SECONDS = 150
REPORT_BYTES = 2 * 1024 * 1024


class QualificationError(Exception):
    pass


class QualificationTimeout(BaseException):
    pass


def need(value, message):
    if not value:
        raise QualificationError(message)


def read_regular(path, cap):
    path = Path(path)
    need(not path.is_symlink(), 'symlink input refused: ' + str(path))
    flags = os.O_RDONLY | getattr(os,'O_NOFOLLOW',0) | getattr(os,'O_NONBLOCK',0)
    with os.fdopen(os.open(path,flags),'rb') as stream:
        before=os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_size<=cap,'bounded regular input required')
        data=stream.read(cap+1);after=os.fstat(stream.fileno())
        need(len(data)==before.st_size and len(data)<=cap,'complete bounded input read required')
        fields=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
        need(fields(before)==fields(after),'input changed during read')
    return data


def pin(path, raw=None):
    raw=read_regular(path,1024*1024) if raw is None else raw
    return {'path':str(Path(path).absolute()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def load(path,name,size,expected):
    raw=read_regular(path,1024*1024);record=pin(path,raw)
    need(record['bytes']==size and record['sha256']==expected,'exact reviewed code: '+str(path))
    module=ModuleType(name);module.__file__=str(path);sys.modules[name]=module
    exec(compile(raw,str(path),'exec'),module.__dict__)
    return module,record,raw


class PredicateExpressionParser:
    """Small expression grammar for the two exact current-only source predicates.

    This is not a general Spectra parser. Parsed tokens can produce only safe
    integer/Boolean Python expression nodes; no source text is eval'ed or exec'ed.
    The two final lambdas are compiled from that whitelisted AST once for speed.
    """
    TOKEN = re.compile(r'\s*(->|!=|<=|>=|[A-Za-z_][A-Za-z_0-9]*|[0-9]+|[()+\-<>=&|,])')
    COMPARISONS = {'=':ast.Eq,'!=':ast.NotEq,'<':ast.Lt,'>':ast.Gt,'<=':ast.LtE,'>=':ast.GtE}

    def __init__(self, text, parameters, helper):
        self.tokens=[];pos=0
        while pos < len(text):
            if not text[pos:].strip():break
            match=self.TOKEN.match(text,pos)
            need(match is not None,'unsupported source predicate token at offset'+str(pos))
            self.tokens.append(match.group(1));pos=match.end()
        need(0 < len(self.tokens) <= 1600,'bounded actual source predicate tokens')
        self.parameters=set(parameters);self.helper=helper;self.at=0;self.depth=0

    def peek(self):return self.tokens[self.at] if self.at < len(self.tokens) else None
    def accept(self, value):
        if self.peek()==value:self.at+=1;return True
        return False
    def expect(self, value):need(self.accept(value),'expected source predicate token '+value)
    def expression(self):
        self.depth+=1;need(self.depth<=128,'source predicate nesting cap')
        result=self.disjunction()
        if self.accept('->'):
            result=ast.BoolOp(op=ast.Or(),values=[ast.UnaryOp(op=ast.Not(),operand=result),self.expression()])
        self.depth-=1;return result
    def disjunction(self):
        result=self.conjunction()
        while self.accept('|'):result=ast.BoolOp(op=ast.Or(),values=[result,self.conjunction()])
        return result
    def conjunction(self):
        result=self.comparison()
        while self.accept('&'):result=ast.BoolOp(op=ast.And(),values=[result,self.comparison()])
        return result
    def comparison(self):
        result=self.additive();token=self.peek()
        if token in self.COMPARISONS:
            self.at+=1;result=ast.Compare(left=result,ops=[self.COMPARISONS[token]()],comparators=[self.additive()])
            need(self.peek() not in self.COMPARISONS,'chained source comparisons not supported')
        return result
    def additive(self):
        result=self.primary()
        while self.peek() in ('+','-'):
            token=self.peek();self.at+=1
            result=ast.BinOp(left=result,op=ast.Add() if token=='+' else ast.Sub(),right=self.primary())
        return result
    def primary(self):
        token=self.peek();need(token is not None,'incomplete source predicate')
        if self.accept('('):
            result=self.expression();self.expect(')');return result
        self.at+=1
        if token.isdecimal():
            value=int(token);need(0<=value<=7,'predicate integer outside reviewed0..7')
            return ast.Constant(value=value)
        if token==self.helper:
            self.expect('(');args=[self.expression()]
            while self.accept(','):args.append(self.expression())
            self.expect(')');need(len(args)==4,'adjacency helper must have4arguments')
            return ast.Call(func=ast.Name(id=token,ctx=ast.Load()),args=args,keywords=[])
        need(token in self.parameters,'unsupported source predicate name: '+token)
        return ast.Name(id=token,ctx=ast.Load())
    def finish(self):
        result=self.expression();need(self.at==len(self.tokens),'trailing source predicate tokens')
        need(sum(1 for _ in ast.walk(result))<=1024,'bounded predicate AST')
        return result


def source_predicates(appendix, source_path):
    """Extract and interpret the ACTUAL pinned predicate bodies and parameter order."""
    plain=re.sub(r'//[^\r\n]*','',appendix.decode('utf-8'))
    pattern=re.compile(r'predicate\s+([A-Za-z_][A-Za-z_0-9]*)\s*\(([^)]*)\)\s*:\s*(.*?);',re.S)
    found=list(pattern.finditer(plain));need(len(found)==2,'exact two appended predicate declarations')
    need(not pattern.sub('',plain).strip(),'nonpredicate material in actual appendix')
    names=('originalEnvAdjacentForQ0','originalEnvHasNext')
    params=(('ex','ey','rx','ry'),('ex','ey','ax','ay','bx','by'))
    functions={};metadata=[]
    for match,name,wanted in zip(found,names,params):
        need(match.group(1)==name,'exact actual predicate declaration order')
        actual=[]
        for item in match.group(2).split(','):
            pair=item.strip().split();need(len(pair)==2 and pair[0]=='Dim','typed source predicate parameter')
            actual.append(pair[1])
        need(tuple(actual)==wanted,'exact source predicate parameter names and order')
        parser=PredicateExpressionParser(match.group(3),wanted,names[0] if name==names[1] else None)
        body=parser.finish()
        helper_calls=[n for n in ast.walk(body) if isinstance(n,ast.Call)]
        need(len(helper_calls)==(10 if name==names[1] else 0),'all five source Q0 branches each call both robot guards')
        lam=ast.Lambda(args=ast.arguments(posonlyargs=[],args=[ast.arg(arg=x) for x in wanted],
            vararg=None,kwonlyargs=[],kw_defaults=[],kwarg=None,defaults=[]),body=body)
        expression=ast.fix_missing_locations(ast.Expression(body=lam))
        allowed={'__builtins__':{},**functions}
        functions[name]=eval(compile(expression,str(source_path)+'::'+name,'eval'),allowed,{})
        metadata.append({'predicate':name,'parameters':list(wanted),'tokens':len(parser.tokens),
                         'AST_nodes':sum(1 for _ in ast.walk(body)),'helper_calls':len(helper_calls)})
    return functions[names[0]],functions[names[1]],metadata


def scalar_rho_e(reference, obstacles, original_choices, current, robot0, robot1, future):
    # Q0 comes from the separately authored scalar ORIGINAL relation, never
    # from the candidate iterator or the producer. Preserve the literal two
    # disjunctions and the unchanged movement/next-obstacle conjuncts.
    if not reference.step(current, future) or future in obstacles:
        return False
    original0 = (not reference.adjacent(robot0, current) or
                 (future[0] != robot0[0] and future[1] != robot0[1]))
    original1 = (not reference.adjacent(robot1, current) or
                 (future[0] != robot1[0] and future[1] != robot1[1]))
    exception = not original_choices and future == current
    return (original0 or exception) and (original1 or exception)


def qualify():
    started=time.monotonic();sys.dont_write_bytecode=True
    checker_path=D/'verify_candidate_certificate.py'
    v53=B.parent/'v53_intruder_cooperativity_diagnosis_20261022'
    reference_path=v53/'intruder_audit/oracle355/source_semantics.py'
    old_path=v53/'source_certificate_01/verify_certificate.py'
    checker,checker_pin,checker_raw=load(checker_path,'v54_qualified_source_checker',CHECKER_BYTES,CHECKER_SHA)
    reference,reference_pin,_=load(reference_path,'v54_independent_scalar_reference',REFERENCE_BYTES,REFERENCE_SHA)
    old_raw=read_regular(old_path,256*1024);old_pin=pin(old_path,old_raw)
    need((old_pin['bytes'],old_pin['sha256'])==(OLD_CHECKER_BYTES,OLD_CHECKER_SHA),'exact unchanged-factor ancestor')
    old_tree,new_tree=ast.parse(old_raw),ast.parse(checker_raw)
    def function(tree,name):
        return next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name==name)
    for name in SHARED_FACTORS:
        need(ast.dump(function(old_tree,name),include_attributes=False)==
             ast.dump(function(new_tree,name),include_attributes=False),'unchanged shared factor: '+name)
    before=[checker_pin,reference_pin,old_pin,pin(__file__)]
    profile_path=D/'CANDIDATE_SEMANTIC_PROFILE.json'
    need(set(checker.CANDIDATES) == {'deadend_stay_both'}, 'single exact G candidate')
    source=B/'deadend_stay_01/candidate/1673286053.spectra'
    imported=source.parent/'imports/DwyerPatterns.spectra'
    mask,qualified=checker.qualify_candidate('deadend_stay_both',source,imported,profile_path)
    need(mask==3,'fixed compatibility mask3')
    before.extend(qualified)
    source_profile=B/'deadend_stay_01/SOURCE_PROFILE.json'
    source_profile_pin=pin(source_profile)
    need((source_profile_pin['bytes'],source_profile_pin['sha256'])==
         (4849,'38a9666ec6bb682405d1ba28bec1b122708419453cf8fea2259c41f0a68f8480'),
         'exact reviewed G source-edit profile')
    before.append(source_profile_pin)
    original_path=B/'candidates/original/1673286053.spectra'
    original=read_regular(original_path,8192);original_pin=pin(original_path,original)
    need((original_pin['bytes'],original_pin['sha256'])==
         (2071,'6203bdf9a0e65726aa2d46503ae935ba2ac4e9fa27f00650ded83a25a5318c10'),
         'exact original source bytes')
    before.append(original_pin)
    actual_source=read_regular(source,8192)
    marker=b'// Exact original-source Q0.'
    need(actual_source.count(marker)==1,'unique current-only Q0 appendix')
    appendix=actual_source[actual_source.index(marker):]
    need(len(appendix)==2343 and hashlib.sha256(appendix).hexdigest()==
         '7bb4dd716ec11c35fd6b72b8cd7aacdb319d379266be7c83def69d7a65c657ab',
         'exact actual source-predicate appendix')
    expected=original
    for robot in (0,1):
        old_line=(f'asm alw adjecentToIntruder(robotX{robot}, robotY{robot}) -> '
            f'(next(intruderX) != robotX{robot}) & (next(intruderY) != robotY{robot});').encode()
        new_line=(f'asm alw (adjecentToIntruder(robotX{robot}, robotY{robot}) -> '
            f'((next(intruderX) != robotX{robot}) & (next(intruderY) != robotY{robot}))) | '
            '((!originalEnvHasNext(intruderX, intruderY, robotX0, robotY0, robotX1, robotY1)) & '
            '(intruderX = next(intruderX) & intruderY = next(intruderY)));').encode()
        need(original.count(old_line)==1,'unique original avoidance clause')
        expected=expected.replace(old_line,new_line)
    need(expected+appendix==actual_source,'exact G two-line edits and appended predicates only')
    source_adj,source_q0,predicate_metadata=source_predicates(appendix,source)
    contract=reference.Contract()
    points=tuple((x,y) for x in range(8) for y in range(8))
    need(checker.COORD==points,'cell-coordinate encoding')
    counts={}
    def state(e,a,b,h):
        ex,ey=points[e];ax,ay=points[a];bx,by=points[b]
        return {'intruderX':str(ex),'intruderY':str(ey),'robotX0':str(ax),'robotY0':str(ay),
                'robotX1':str(bx),'robotY1':str(by),'ONCE_aux_0':('true' if h else 'false')}
    moves = []
    for cell in range(64):
        expected = tuple(target for target in range(64)
                         if reference.step(points[cell], points[target]))
        actual = tuple(checker.bounded_moves(cell))
        need(len(actual) == len(set(actual)) and set(actual) == set(expected),
             'complete move list')
        need(actual == checker.MOVES[cell], 'production move table')
        need(checker.outside_obstacle(cell) == (points[cell] not in contract.obstacles),
             'obstacle factor')
        moves.append(expected)
        for target in range(64):
            need(checker.adjacent(cell, target) ==
                 reference.adjacent(points[cell], points[target]), 'adjacency factor')
            need(source_adj(*points[cell],*points[target]) is reference.adjacent(points[cell],points[target]),
                 'actual source adjacency-predicate full finite correspondence')
    counts.update(clear_factor=64, complete_move_lists=64, step_assignments=4096,
                  adjacency_assignments=4096)

    # Every typed state index, including both logical history values.
    for sid in range(checker.STATE_COUNT):
        values = checker.decode(sid)
        need(all(0 <= x < 64 for x in values[:3]) and values[3] in (0, 1),
             'decode domains')
        need(checker.encode(*values) == sid, 'complete dense index roundtrip')
    counts['index_roundtrips'] = checker.STATE_COUNT


    # Complete candidate ENV action sets on the entire typed physical carrier,
    # including current obstacles and collisions. History is absent from every
    # exact source rhoE and iterator signature, so both history values share it.
    independent_slots=[]
    for e in range(64):
        x,y=points[e]
        raw=((x,y),(x-1,y),(x+1,y),(x,y-1),(x,y+1))
        independent_slots.append(tuple((slot,nx*8+ny) for slot,(nx,ny) in enumerate(raw)
                                       if 0<=nx<=7 and 0<=ny<=7))
        need({n for _,n in independent_slots[-1]}==set(moves[e]),'all canonical ENV slots')
    env_next=[{'intruderX':str(x),'intruderY':str(y)} for x,y in points]
    env_evaluations=0;old_queries=0;candidate_queries=0;candidate_true=0
    old_true=0;added_actions=0;q_new_true=0;current_obstacle_queries=0
    collision_queries=0;arena_queries=0;changed_on_old_Q_true=0
    for e in range(64):
        for a in range(64):
            for b in range(64):
                s=state(e,a,b,0)
                # moves[e] was exhaustively qualified against all64 possible
                # next positions; original rhoE retains its movement conjunct.
                original_set={n for n in moves[e] if contract.rho_e(s,env_next[n])}
                actual_source_Q=source_q0(*points[e],*points[a],*points[b])
                need(type(actual_source_Q) is bool and actual_source_Q==bool(original_set),
                     'ACTUAL appended source predicate equals complete original rhoE action existence')
                old_actual=tuple(checker.original_env_slots(e,a,b))
                need(len({n for _,n in old_actual})==len(old_actual) and
                     {n for _,n in old_actual}==original_set,
                     'complete independently reconstructed original action set')
                actual=tuple(checker.candidate_env_slots(3,e,a,b))
                expected=tuple((slot,n) for slot,n in independent_slots[e]
                    if scalar_rho_e(reference,contract.obstacles,original_set,
                                    points[e],points[a],points[b],points[n]))
                env_evaluations+=len(independent_slots[e]);old_queries+=1;candidate_queries+=1
                need(actual==expected,'complete ordered literal G ENV slot set')
                need(len({n for _,n in actual})==len(actual),'candidate target uniqueness')
                need(tuple(checker.candidate_env_actions(3,e,a,b))==tuple(n for _,n in actual),
                     'candidate ENV cell/slot agreement')
                actual_set={n for _,n in actual};candidate_true+=int(bool(actual))
                old_true+=int(bool(original_set))
                added_stay={e} if not original_set and points[e] not in contract.obstacles else set()
                need(actual_set==original_set|added_stay,
                     'G equals old relation OR clear-stay only at old Qfalse')
                need(bool(actual)==(bool(original_set) or points[e] not in contract.obstacles),
                     'full typed QG=Q0 OR current_intruder_clear')
                if original_set:
                    need(actual_set==original_set,'no added action when old Qtrue')
                is_goal=contract.justices(s)[1][0]
                need(checker.goal(e,a,b)==is_goal,'unchanged source goal')
                arena=points[e] not in contract.obstacles and all(contract.invariants(s))
                need(checker.physical_arena(e,a,b)==arena,'unchanged current arena')
                if arena:
                    need(bool(actual),'candidate QG true on every legal physical state')
                added_actions+=len(actual_set-original_set)
                q_new_true+=int(bool(actual_set) and not bool(original_set))
                current_obstacle_queries+=int(points[e] in contract.obstacles)
                collision_queries+=int(len({e,a,b})<3);arena_queries+=int(arena)
    counts.update(complete_candidate_ENV_choice_queries=candidate_queries,
                  scalar_candidate_rhoE_evaluations=env_evaluations,
                  original_reference_ENV_queries=old_queries,
                  actual_source_Q0_predicate_truth_queries=old_queries,
                  actual_source_adjacency_predicate_truth_queries=4096,
                  independently_qualified_old_ENV_choice_queries=old_queries,
                  original_Q_true_queries=old_true,candidate_Q_true_queries=candidate_true,
                  G_added_deadend_stay_actions=added_actions,G_new_Q_true_queries=q_new_true,
                  current_obstacle_valuations_checked=current_obstacle_queries,
                  collision_valuations_checked=collision_queries,legal_physical_valuations=arena_queries,
                  goal_assignments=64**3,arena_assignments=64**3,
                  G_exact_OR_action_set_equalities=64**3,full_typed_Q_identities=64**3,
                  original_Q_true_action_sets_unchanged=old_true,
                  physical_QG_true_queries=arena_queries)
    # Qualify all robot1 movement assignments and all history-update assignments.
    # The response iterator below is then checked for EVERY input tuple.
    for h in (0, 1):
        for b in range(64):
            actual_positions = checker.MOVES[b] if h else (b,)
            for nb in range(64):
                expected = (bool(h) and reference.step(points[b], points[nb])) or b == nb
                need((nb in actual_positions) == expected, 'current history movement gate')
        for na in range(64):
            for nh in (0, 1):
                need((checker.update_history(h, na) == nh) ==
                     (bool(nh) == (bool(h) or points[na] == (0, 7))),
                     'deterministic next history')
    counts.update(robot1_movement_assignments=8192, history_update_assignments=256)

    # Factor source rhoS into robot/history constraints and the two NEXT
    # intruder-collision tests. For each (a,b,h), obtain the complete base relation
    # with a fresh clear intruder cell distinct from both candidate robots, using
    # the independent scalar rhoS. Then test every next-intruder value against
    # the actual checker response iterator. No current-arena restriction here.
    sys_evaluations = response_queries = responses = 0
    for a in range(64):
        for b in range(64):
            for h in (0, 1):
                s = state(0, a, b, h)
                base = []
                b_moves = tuple(nb for nb in range(64)
                                if (bool(h) and reference.step(points[b], points[nb])) or b == nb)
                for na in moves[a]:
                    for nb in b_moves:
                        ne = next(e for e in range(64)
                                  if points[e] not in contract.obstacles and e != na and e != nb)
                        for nh in (0, 1):
                            sys_evaluations += 1
                            if contract.rho_s(s, state(ne, na, nb, nh)):
                                base.append((na, nb, nh))
                need(len(base) == len(set(base)), 'reference response uniqueness')
                for ne in range(64):
                    actual = tuple(checker.original_sys_responses(a, b, h, ne))
                    expected = tuple(t for t in base if ne != t[0] and ne != t[1])
                    need(len(actual) <= 25 and len(actual) == len(set(actual))
                         and set(actual) == set(expected), 'complete original SYS responses')
                    response_queries += 1
                    responses += len(actual)
    counts.update(reference_rhoS_factor_evaluations=sys_evaluations,
                  complete_SYS_response_queries=response_queries,
                  actual_SYS_responses_compared=responses)

    initial_counts = []
    for e in range(64):
        actual_env = e % 8 == 7
        need(actual_env == contract.theta_e(state(e, 0, 56, 0)), 'complete ENV initialization')
        if not actual_env:
            continue
        expected = []
        actual = []
        for a in range(64):
            for b in range(64):
                for h in (0, 1):
                    if contract.theta_s(state(e, a, b, h)):
                        expected.append(checker.encode(e, a, b, h))
                    if checker.theta_system(a, b, h) and checker.physical_arena(e, a, b):
                        actual.append(checker.encode(e, a, b, h))
        need(actual == expected == [checker.encode(e, 0, 56, 0)], 'all SYS/aux initial responses')
        initial_counts.append(len(actual))
    counts.update(ENV_initializer_assignments=64, SYS_aux_initial_assignments=8*64*64*2,
                  initial_SYS_aux_counts=initial_counts)


    need(tuple(checker.original_env_slots(54,46,53))==(),
         'original orthogonal-capture dead end')
    need(tuple(checker.candidate_env_slots(3,54,46,53))==((0,54),),'G capture deadend stay')
    need(tuple(checker.original_env_slots(24,16,32))==() and checker.goal(24,16,32),
         'opposed corridor capture is an old deadend')
    need(tuple(checker.candidate_env_slots(3,24,16,32))==((0,24),),
         'G also repairs opposed corridor capture with only stay')
    need(tuple(checker.original_env_slots(27,19,35))==((3,26),(4,28)),
         'open opposed capture has old legal vertical escapes')
    need(tuple(checker.candidate_env_slots(3,27,19,35))==((3,26),(4,28)),
         'G preserves old-Qtrue capture actions and does not add stay')
    need(tuple(checker.original_env_slots(16,8,63))==() and not checker.goal(16,8,63),
         'original single-adjacent non-capture deadend')
    need(tuple(checker.candidate_env_slots(3,16,8,63))==((0,16),),
         'G also repairs non-capture deadend; no capture conjunct')
    need(17 not in checker.candidate_env_actions(3,16,0,56),
         'unchanged NEXT obstacle exclusion')
    need((7,48,1) not in checker.original_sys_responses(6,56,0,28),
         'newly activated history must not move robot1 this same step')
    need(tuple(checker.candidate_env_slots(3,15,7,14))==((0,15),),
         'G goal ENV stay with corner/history-false carrier state')
    need((7,14,1) in checker.original_sys_responses(7,14,0,15) and
         (7,14,0) not in checker.original_sys_responses(7,14,0,15),
         'goal physical stay must still update history; literal ID self-loop is invalid')
    # Keep one record per actual input path after checking repeated profile pins.
    unique={}
    for item in before:
        key=str(Path(item['path']).resolve())
        need(key not in unique or unique[key]==item,'inconsistent repeated input pin')
        unique[key]=item
    before=list(unique.values())
    for item in before:
        need(pin(Path(item['path']))==item,'all qualification inputs preserved')
    return {'schema':'v54-source-candidate-checker-finite-qualification-v1',
            'status':'PASS_COMPLETE_FINITE_CANDIDATE_SOURCE_SEMANTICS_AND_RESPONSE_LISTS',
            'candidate_ids':list(checker.CANDIDATES),'semantic_profile_id':checker.SEMANTICS_ID,
            'input_pins':before,'counts':counts,'actual_source_predicates':predicate_metadata,
            'actual_source_Q0_predicate_evaluated':True,
            'predicate_evaluator':'Whitelisted actual source expression AST; compiled Python lambdas only, no raw source eval and no native compiler','unchanged_V53_AST_factor_names':list(SHARED_FACTORS),
            'source_byte_edit_scope_verified':'Only both avoidance lines plus the exact current-only Q0 helper predicate; all other bytes unchanged',
            'ENV_scope':'All262144 typed coordinate valuations, including current obstacles and collisions; both history values share rhoE because exact source and function signatures contain no history dependence.',
            'rhoE_identities':{'G':'rhoE_original OR (!Q_original AND next_intruder_clear AND ENVstay)',
                'Q_G_full_typed':'Q_original OR currentIntruderClear',
                'Q_G_physical_arena':'true',
                'old_Q_true_states':'exact old ENV action set preserved'},
            'SYS_and_initialization_qualification':'Repeated all V53 finite-factor and complete-response queries against the independent scalar reference after unchanged-function AST checks; no reuse of a producer transition table.',
            'method':'Pinned independent scalar old relation yields the complete old action set; direct scalar (E0 OR D) AND (E1 OR D) with D=!oldQ ANDstay is compared to the separately authored iterator on the full typed carrier.',
            'composition_note':'All64 next-cell movement factors qualified independently; rhoE retains that movement conjunct, so enumeration of complete stay/cardinal slots is exhaustive. SYS response factors use the independently evaluated rhoS base relation followed by its two next-intruder collision factors, for every response input tuple.',
            'elapsed_seconds':time.monotonic()-started,'native_calls':0,'BDD_imports':0,
            'not_claimed':'No positive or negative certificate is accepted and no generator correctness claim is established by this semantic qualification.'}


def expired(_signum,_frame):
    raise QualificationTimeout('finite qualification exceeded150seconds')


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args();flags=os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0)
    started=time.monotonic()
    with os.fdopen(os.open(args.out,flags,0o644),'w',encoding='utf-8') as out:
        previous=signal.signal(signal.SIGALRM,expired);signal.setitimer(signal.ITIMER_REAL,INTERNAL_SECONDS)
        try:
            result=qualify();code=0
        except (Exception,QualificationTimeout) as exc:
            result={'schema':'v54-source-candidate-checker-finite-qualification-v1',
                    'status':'UNKNOWN_OR_FAILED_CANDIDATE_SEMANTICS_QUALIFICATION',
                    'exception_type':type(exc).__name__,'reason':str(exc)[:4096]};code=2
        finally:
            signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,previous)
        result.update(created_utc=datetime.now(timezone.utc).isoformat(),total_elapsed_seconds=time.monotonic()-started)
        rendered=json.dumps(result,indent=2,ensure_ascii=False)+'\n'
        need(len(rendered.encode())<=REPORT_BYTES,'qualification report exceeds2MiB')
        out.write(rendered);out.flush();os.fsync(out.fileno())
    print(json.dumps({'status':result['status'],'report':str(args.out.absolute())}));return code


if __name__=='__main__':
    raise SystemExit(main())
