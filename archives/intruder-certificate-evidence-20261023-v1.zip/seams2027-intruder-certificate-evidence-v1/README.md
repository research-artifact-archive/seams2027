# Intruder certificate evidence

The saved original and repaired Intruder certificates passed the recorded
six-step replay on 2026-10-23 JST from a separate filesystem location. This is
saved-certificate revalidation; no fresh synthesis was performed.

The original obstruction labels **276,829 states** and certifies one allowed
environment initializer, **(0,7)**. It rules out the joint strict/cooperative
obligation for that initializer. It does not claim strict-only unrealizability
or that every one of the eight initializers loses. The exact G repaired strategy
labels **407,172 states** and covers **all eight allowed initializers**. It does
not classify the complete winning region.

Four complete source-qualification/certificate programs passed. Only those
four programs received the recorded Python audit-event access monitoring and
process/network prohibition. The two additional rejection harnesses passed
**17** original and **26** repaired tests of selected loader/local branches;
they were not access-audit covered and do not repeat full certificate checking.

`REPLAY_SUMMARY.json` records the statuses, counts, scope and original evidence
hashes under relative provenance identifiers. Raw local-path execution logs are
not embedded. No external replication or cross-platform validation is claimed.

The directory `seams2027-intruder-certificate-replay-v1/` preserves all **26 files byte-for-byte** from the
replayed kit. Its `MANIFEST.json` retains
`PACKAGING_COMPLETE_REPLAY_NOT_EXECUTED`: this is the immutable construction-time
snapshot written before the later replay. The outer summary records that later
outcome without rewriting the historical kit or its manifest.

For reproduction, enter `seams2027-intruder-certificate-replay-v1/` and follow its `README.md` and
`REPLAY_PLAN.json`, using fresh sibling outputs. The kit needs only Python's
standard library on a suitable POSIX runtime. The outer `MANIFEST.json` hashes
all delivered files except itself; it also binds the exact inner manifest.

Third-party source attribution and redistribution terms are retained in `THIRD_PARTY_NOTICES.txt` and `LICENSE-third-party.txt`.
