#!/usr/bin/env python3
"""Only synthetic models/graphs; imperative clause oracle independent of checker.
No existing cohort controller is loaded or executed by this qualifier.
"""
import copy, hashlib, importlib.util, json, pathlib, sys, subprocess
from itertools import product
from collections import deque
sys.dont_write_bytecode=True
HERE=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('saved_checker',HERE/'check_roots.py');C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)

def dump(path,obj):path.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def hp(path):
    path=pathlib.Path(path);return {'path':str(path.resolve()),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

def manual(s,t=None,key=None):
    b=[s[f'b{i}']=='true' for i in (1,2,3)];f=[s[f'f{i}']=='true' for i in (1,2,3)];c=s['c']=='true'
    if key=='thetaE':return not any(b)
    if key=='thetaS':return f==[True,False,False] and all(s[n]=='S0' for n in C.AUX)
    if key=='rhoE':
        if sum(f)!=1:return False
        return all(not (b[i] and f[i] and t[f'b{i+1}']=='true') and not (b[i] and not f[i] and not c and t[f'b{i+1}']=='false') for i in range(3))
    nf=[t[f'f{i}']=='true' for i in (1,2,3)]
    if f[0] and not((nf[0] and not b[1] and not b[2]) or (nf[1] and (b[1] or b[2])) or (nf[0] and c)):return False
    if f[1] and not((nf[0] and b[0]) or (nf[1] and not b[0] and not b[2]) or (nf[2] and b[2]) or (nf[1] and c)):return False
    if f[2] and not((nf[2] and not b[0] and not b[1]) or (nf[1] and (b[0] or b[1])) or (nf[2] and c)):return False
    for i,n in enumerate(C.AUX):
        pending=(s[n]=='S1' or b[i]) and not(f[i] or c)
        if (t[n]=='S1')!=pending:return False
    return True

def fixture_model(directory,helper):
    directory.mkdir();names=C.ENV+(['~envHelp'] if helper else [])+C.SYS+C.AUX
    fields=[];lookup={}
    for i,n in enumerate(names):
        vals=['S0','S1'] if n in C.AUX else ['false','true'];lookup[n]=(2*i,2*i+1)
        fields.append({'name':n,'owner':'ENV' if n in C.ENV or n=='~envHelp' else 'SYS','role':'AUX' if n in C.AUX else 'ENV' if n in C.ENV or n=='~envHelp' else 'SYS','values':vals,'domain_size':2,'current_bits':[2*i],'next_bits':[2*i+1],'encoding':{v:{'current':{str(2*i):bool(j)},'next':{str(2*i+1):bool(j)}} for j,v in enumerate(vals)}})
    b=C.G.BDD(len(names)*2)
    def build(bits,test):
        assignment={}
        def rec(i):
            if i==len(bits):return int(test(assignment))
            x=bits[i];assignment[x]=False;lo=rec(i+1);assignment[x]=True;hi=rec(i+1);assignment.pop(x)
            return b.mk(x,lo,hi)
        return rec(0)
    def decode(a,prime):return {n:('S1' if a.get(lookup[n][prime],False) else 'S0') if n in C.AUX else ('true' if a.get(lookup[n][prime],False) else 'false') for n in names}
    support={'thetaE':[lookup[n][0] for n in C.ENV[:3]],'thetaS':[lookup[n][0] for n in C.SYS+C.AUX],
      'rhoE':[lookup[n][0] for n in C.ENV+C.SYS]+[lookup[n][1] for n in C.ENV[:3]],
      'rhoS':[lookup[n][0] for n in C.FIELDS]+[lookup[n][1] for n in C.SYS+C.AUX]}
    roots={k:build(sorted(bits),lambda a,k=k:manual(decode(a,0),decode(a,1),k)) for k,bits in support.items()}
    if helper:roots['thetaE']=b.conj(roots['thetaE'],b.neg(b.var(lookup['~envHelp'][0])))
    def save(name,u):
        file=directory/(name+'.bdd');seen=set();rows=[]
        def visit(v):
            if v<2 or v in seen:return
            seen.add(v);bit,lo,hi=b.nodes[v];visit(lo);visit(hi);rows.append(f'{v} {bit} {lo} {hi}')
        visit(u)
        file.write_text(('0 '+str(u)+'\n') if u<2 else str(b.n)+'\n'+' '.join(map(str,range(b.n)))+'\n'+'\n'.join(rows)+'\n')
        p=hp(file);return {'file':file.name,'bytes':p['bytes'],'sha256':p['sha256'],'node_count':len(seen),'zero':u==0,'one':u==1,'support':sorted(b.support(u))}
    predicates={k:save(k,u) for k,u in roots.items()}
    predicates.update({k:save(k,1) for k in ('domain','domain_ENV_next','domain_SYS_next')})
    justices={'ENV':[save('env0',1)] if helper else [],'SYS':[save('sys'+str(i),b.neg(b.var(lookup[n][0]))) for i,n in enumerate(C.AUX)]}
    source=pathlib.Path(__file__).parents[3]/'seams_research_reframing_20261018/runtime_closure_01/sources/lift__trivial_1.spectra'
    inv={phase:{owner:{'variables':[{'name':f['name']} for f in fields if f['role']==owner],'constraints':[],'patterns':[]}for owner in ('ENV','SYS','AUX')} for phase in ('parsed','translated')}
    inv['native_behaviors']={'env_justice_count':len(justices['ENV']),'sys_justice_count':3}
    model={'schema':'k7-native-model-export-v1','fixture_id':'lift__trivial_1','case_id':'lift__trivial_1' if helper else 'lift','variant':'initializers' if helper else 'trivial_1','bdd_variable_count':b.n,'bdd_variable_order':list(range(b.n)),'fields':fields,'all_current_bits':[2*i for i in range(len(names))],'all_next_bits':[2*i+1 for i in range(len(names))],'public_fields':{o:[f['name'] for f in fields if f['role']==o] for o in ('ENV','SYS')},'input':hp(source),'source_inventory':inv,'original_bdds':predicates,'original_justices':justices}
    dump(directory/'model.json',model)
    return model

def synthetic_graph(model,name):
    names=[f['name'] for f in model['fields']]
    s={n:('S0' if n in C.AUX else 'false')for n in names};s['f1']='true';s2=dict(s,c='true')
    states=[s,s2];ids={tuple(s[n] for n in names):'0',tuple(s2[n] for n in names):'1'};nodes=[];queue=deque([0,1]);edges=[]
    while queue:
        i=queue.popleft();s=states[i];f=next(j for j in range(3) if s['f'+str(j+1)]=='true');bs=[s['b'+str(j+1)]=='true' for j in range(3)]
        nf=(1 if bs[1] or bs[2] else 0) if f==0 else ((0 if bs[0] else 2 if bs[2] else 1) if f==1 else (1 if bs[0] or bs[1] else 2))
        succ=[]
        for xs in product(['false','true'],repeat=4):
            t=dict(s,**dict(zip(C.ENV,xs)))
            if not manual(s,t,'rhoE'):continue
            for j,n in enumerate(C.SYS):t[n]='true' if j==nf else 'false'
            for j,n in enumerate(C.AUX):t[n]='S1' if (s[n]=='S1' or bs[j]) and not(s['f'+str(j+1)]=='true' or s['c']=='true') else 'S0'
            assert manual(s,t,'rhoS')
            key=tuple(t[n] for n in names)
            if key not in ids:ids[key]=str(len(states));states.append(t);queue.append(len(states)-1)
            succ.append(ids[key]);edges.append([str(i),ids[key]])
        bits={str(fld['current_bits'][0]):s[fld['name']] in ('true','S1') for fld in model['fields']}
        n={'id':str(i),'native_id':i,'initial':i<2,'rank':0,'rank_class':'tau.smlab.syntech.games.gr1.GR1RankInfo','rank_info':'System Justice 0','valuation':s,'bits':bits,'successors':succ}
        if name!='normalized':n['native_bdd_text']='<'+', '.join(k+':'+s[k] for k in names)+'>'
        nodes.append(n)
    g={k:model[k]for k in ('fixture_id','case_id','variant')};g.update(schema={'native':'released-kind-complete-native-controller-v1','normalized':'released-concrete-controller-export-v2','preference':'experimental-extractor-complete-controller-v1'}[name],complete=True,model_sha256='',rank_domain_size=3,nodes=nodes,edges=edges,api_state_order=[n['id']for n in nodes],api_state_count=len(nodes),api_transition_count=len(edges))
    if name=='normalized':g.update(pipeline='normalized_kind',entry_mode='original_initializer',initialization=C.G.INIT,entry_valuation=None,entry_bits=None,replay_sha256=None,exported_edge_count=len(edges))
    else:
        g['initialization']='source_initializers';g.pop('api_state_order')
    return g

def printer(g,names):
    return ('\n'.join(v for n in g['nodes'] for v in [('Initial State ' if n['initial'] else 'State ')+n['id']+' <'+', '.join(k+':'+n['valuation'][k] for k in names)+'>','\tWith successors : '+', '.join(n['successors'])])+'\n').encode()

def full_cli_fixture(out,fixtures,test):
    """Synthetic complete ten-private-boundary census and real CLI controls."""
    directory=out/'end_to_end';directory.mkdir()
    ctx,g,nodes,_=fixtures['native'];g=copy.deepcopy(g)
    old=json.loads((out/'native/synthetic_old_closure.json').read_text())
    pending=[sid for sid in old['reachable_nodes'] if any(nodes[sid]['valuation'][a]=='S1' for a in C.AUX)]
    assert len(pending)==8
    duplicates={}
    for original in pending[:2]:
        n=copy.deepcopy(nodes[original]);newid=str(len(g['nodes']));n.update(id=newid,native_id=int(newid),rank=1,rank_info='System Justice 1');g['nodes'].append(n);duplicates[newid]=original
        preds=[p for p in g['nodes'][:-1] if original in p['successors']]
        assert len(preds)>=2
        # Replace one source response by the otherwise equivalent distinct
        # synthetic memory state; retain another path to the original state.
        pred=next(p for p in preds if p['id'] in old['reachable_nodes'])
        pred['successors']=[newid if t==original else t for t in pred['successors']]
    g['edges']=[[n['id'],t] for n in g['nodes'] for t in n['successors']];g['api_state_count']=len(g['nodes']);g['api_transition_count']=len(g['edges'])
    gp=directory/'native_controller.json';dump(gp,g);tp=directory/'native_controller.txt';tp.write_bytes(printer(g,list(ctx.by_name)))
    byid={n['id']:n for n in g['nodes']};parents={'0':None};todo=deque(['0'])
    while todo:
        a=todo.popleft()
        for b in byid[a]['successors']:
            if byid[b]['valuation']['b3']=='false' and manual(byid[a]['valuation'],byid[b]['valuation'],'rhoE') and b not in parents:parents[b]=a;todo.append(b)
    pending=[sid for sid in parents if any(byid[sid]['valuation'][a]=='S1' for a in C.AUX)]
    assert len(pending)==10
    rows=[]
    for i,sid in enumerate(pending):
        state=C.source_value(byid[sid]);prefix=[];cur=sid
        while cur is not None:prefix.append(cur);cur=parents[cur]
        prefix.reverse();roots=[]
        for arm,name in C.ARM_GRAPHS.items():
            if arm=='retain_old_native':root=sid;rank=byid[sid]['rank']
            else:
                ns=byid if name=='native' else fixtures[name][2]
                root=next(t for t,n in ns.items() if n['rank']==0 and C.source_value(n)==state);rank=0
            roots.append({'candidate':arm,'graph':name,'root':root,'rank':rank})
        rows.append({'id':'synthetic_boundary_%02d'%i,'source_state':state,'reached_native_node':sid,'reached_rank':byid[sid]['rank'],'prefix_node_ids':prefix,'candidates':roots})
    roster=directory/'COHORT.json';dump(roster,{'boundaries':rows})
    source=pathlib.Path(ctx.model['input']['path']);oldsource=directory/'old_source.spectra';oldsource.write_bytes(source.read_bytes()+b'\n\nassumption -- constructed_old_mode_no_b3\n\talw(b3=false);\n')
    graphs={}
    for name,(c,sg,ns,pt) in fixtures.items():
        d=out/name;graphpath=gp if name=='native' else d/'controller.json';printpath=tp if name=='native' else d/'controller.txt'
        graphs[name]={**hp(graphpath),'model':hp(d/'model.json'),'printer':hp(printpath) if name!='normalized' else None,'source_correspondence':[]}
    input_manifest=directory/'INPUTS.json';dump(input_manifest,{'synthetic_only':True,'graphs':graphs,'source':hp(source)})
    km=out/'normalized/model.json';model=json.loads(km.read_text());kr=directory/'K_result.json';kref=model['original_bdds']['domain'];dump(kr,{'model_export':{'file':'model.json',**{k:v for k,v in hp(km).items() if k!='path'}},'final_region':kref})
    plan={'schema':'v47-noninitial-handoff-plan-v1','source':hp(source),'old_source':hp(oldsource),'graphs':graphs,'roster':hp(roster),'boundaries':rows,'inputs':hp(input_manifest),'old_mode':{'disabled_ENV':'b3','current_value':'false','next_value':'false','source_initializers_preserved':True},'old_gate_adoption_path':str(directory/'adoption.json'),'old_gate_saved_result_path':str(directory/'saved_old.json'),'old_gate_source_result_path':str(directory/'source_old.json'),'region':{'model':hp(km),'bdd':{**kref,'path':str(km.parent/kref['file'])},'result':hp(kr)},'synthetic_only':True}
    pp=directory/'PLAN.json';dump(pp,plan)
    def launch(mode,path,planfile=None):
        cp=subprocess.run([sys.executable,'-I','-B',str(HERE/'check_roots.py'),str(planfile or pp),mode,str(path)],text=True,capture_output=True,timeout=30)
        (directory/(path.stem+'.stdout')).write_text(cp.stdout);(directory/(path.stem+'.stderr')).write_text(cp.stderr)
        return json.loads(path.read_text())
    prior=launch('old_gate',directory/'saved_old.json');test('CLI_old_complete_gate',lambda:C.req(prior['status']=='COMPLETE_OLD_GATE' and all(prior['old_gate'][k] is True for k in ('complete','strict','cooperative','source_coverage')),json.dumps(prior.get('error'))))
    refusal=launch('candidate_roots',directory/'missing_adoption.json');test('CLI_missing_adoption_rejected',lambda:C.req(refusal['status'].startswith('UNKNOWN_'),'Candidate accepted without gate'))
    # Simulated peer certificate is fixture metadata, never source-route evidence.
    peer={'schema':prior['schema'],'status':'COMPLETE_OLD_GATE','route':'source','plan':hp(pp),'old_gate':{'complete':True,'strict':True,'cooperative':True,'source_coverage':True},'synthetic_peer_stub':True};dump(directory/'source_old.json',peer)
    adoption={'status':'ADOPTED_BOTH_OLD_GATE_CERTIFICATES','plan':hp(pp),'certificates':[hp(directory/'saved_old.json'),hp(directory/'source_old.json')],'synthetic_only':True};dump(directory/'adoption.json',adoption)
    candidate=launch('candidate_roots',directory/'candidates.json');test('CLI_all40_rooted_candidates',lambda:C.req(candidate['status']=='COMPLETE_ROOTED_CANDIDATES' and len(candidate['boundaries'])==10 and sum(len(r['candidates']) for r in candidate['boundaries'])==40,json.dumps(candidate.get('error'))))
    test('CLI_K_membership_binding',lambda:C.req(all(candidate['K_membership']['boundaries'].values()),'Synthetic universal region membership'))
    bad=copy.deepcopy(adoption);bad['status']='REJECTED';bad_adoption=directory/'REJECTED_ADOPTION.json';dump(bad_adoption,bad)
    badplan=copy.deepcopy(plan);badplan['old_gate_adoption_path']=str(bad_adoption);badpp=directory/'FALSE_GATE_PLAN.json';dump(badpp,badplan)
    refusal=launch('candidate_roots',directory/'false_adoption.json',badpp);test('CLI_false_gate_rejected',lambda:C.req(refusal['status'].startswith('UNKNOWN_'),'Candidate accepted false gate'))
    # Repin a wrong explicit descriptor to isolate semantic binding from hashes.
    changed=copy.deepcopy(plan);changed['boundaries'][0]['candidates'][1]['rank']=1;badroster=directory/'WRONG_RANK_COHORT.json';dump(badroster,{'boundaries':changed['boundaries']});changed['roster']=hp(badroster);badpp=directory/'WRONG_RANK_PLAN.json';dump(badpp,changed)
    refusal=launch('old_gate',directory/'wrong_root_rank.json',badpp);test('CLI_repinned_wrong_root_rank',lambda:C.req(refusal['status'].startswith('UNKNOWN_'),'Wrong root rank accepted'))
    # Keep the successful PLAN and roster snapshots as independently pinned files.
    dump(directory/'VALID_PLAN_SNAPSHOT.json',plan);dump(directory/'VALID_COHORT_SNAPSHOT.json',{'boundaries':rows})

def main(out):
    out=pathlib.Path(out).resolve();out.mkdir();reports=[];fixtures={}
    def test(label,func,expect='PASS'):
        try:result=func();status='PASS';detail=result
        except Exception as exc:status=type(exc).__name__;detail=str(exc)
        good=status==expect if expect=='PASS' else status!='PASS'
        reports.append({'name':label,'expected':expect,'observed':status,'pass':good,'detail':detail if isinstance(detail,(str,int,bool,type(None))) else None})
    for name,helper in [('normalized',False),('native',True),('preference',True)]:
        directory=out/name;model=fixture_model(directory,helper);ctx=C.G.Context(directory,{**{k:model[k]for k in ('fixture_id','case_id','variant')},'source':model['input']},model)
        test(name+'_typed_model',ctx.audit_model);test(name+'_independent_source_equations',lambda:C.audit_equations(ctx))
        g=synthetic_graph(model,name);g['model_sha256']=hp(directory/'model.json')['sha256'];rawprinter=printer(g,list(ctx.by_name)) if helper else None
        dump(directory/'controller.json',g)
        if helper:(directory/'controller.txt').write_bytes(rawprinter)
        nodes=C.graph_decode(ctx,g,name,g['model_sha256'],rawprinter);fixtures[name]=(ctx,g,nodes,rawprinter)
        test(name+'_full_raw_decode',lambda:C.graph_decode(ctx,g,name,g['model_sha256'],rawprinter))
        old=C.closure_certificate(ctx,nodes,C.initial_roots(ctx,nodes),True);dump(directory/'synthetic_old_closure.json',old)
        test(name+'_old_complete_safe',lambda: C.req(old['complete'] and old['source_coverage'] and old['strict'] is True and old['cooperative'] is True,'Synthetic old policy gate'))
        root=next(s for s in old['reachable_nodes'] if any(nodes[s]['valuation'][a]=='S1' for a in C.AUX));state=C.source_value(nodes[root]);test(name+'_explicit_noninitial_binding',lambda:C.check_root_binding(nodes,root,0,state))
        suffix=C.closure_certificate(ctx,nodes,[root],False);dump(directory/'synthetic_suffix.json',suffix);test(name+'_complete_suffix_coverage',lambda:C.req(suffix['complete'] and suffix['source_coverage'],'Synthetic suffix coverage'))
        test(name+'_wrong_root',lambda:C.check_root_binding(nodes,'99999',0,state),'REJECT')
        test(name+'_wrong_rank',lambda:C.check_root_binding(nodes,root,1,state),'REJECT')
        erased=dict(state);erased[next(n for n in C.AUX if erased[n]=='S1')]='S0'
        test(name+'_erased_monitor',lambda:C.check_root_binding(nodes,root,0,erased),'REJECT')
        missing=copy.deepcopy(nodes);missing[root]['successors']=missing[root]['successors'][1:]
        test(name+'_missing_response',lambda:C.req(C.closure_certificate(ctx,missing,[root],False)['source_coverage'] is False,'Missing input must fail'))
        duplicate=copy.deepcopy(g);duplicate['nodes'][0]['rank_info']='System Justice 2'
        test(name+'_wrong_raw_rank_text',lambda:C.graph_decode(ctx,duplicate,name,g['model_sha256'],rawprinter),'REJECT')
        changed=copy.deepcopy(g);changed['nodes'][0]['bits'][str(ctx.current[0])]=not changed['nodes'][0]['bits'][str(ctx.current[0])]
        test(name+'_wrong_raw_bits',lambda:C.graph_decode(ctx,changed,name,g['model_sha256'],rawprinter),'REJECT')
        if helper:test(name+'_wrong_printer',lambda:C.graph_decode(ctx,g,name,g['model_sha256'],rawprinter+b'X'),'REJECT')
        saved=ctx.formulas['rhoS'];ctx.formulas['rhoS']=1;test(name+'_wrong_saved_predicate',lambda:C.audit_equations(ctx),'REJECT');ctx.formulas['rhoS']=saved
        saved=ctx.justices['SYS'];ctx.justices['SYS']=list(reversed(saved));test(name+'_wrong_justice_order',lambda:C.audit_equations(ctx),'REJECT');ctx.justices['SYS']=saved
    valid={'old_mode':{'disabled_ENV':'b3','current_value':'false','next_value':'false','source_initializers_preserved':True}}
    test('valid_exact_restriction',lambda:C.validate_old_mode(valid))
    wrong=copy.deepcopy(valid);wrong['old_mode']['next_value']='true';test('altered_restriction',lambda:C.validate_old_mode(wrong),'REJECT')
    ref=hp(out/'native/model.json');ref['sha256']='0'*64;test('changed_digest',lambda:C.Inputs().load(ref),'REJECT')
    # Fairness controls include an accepting cycle that omits a guarantee and
    # an acyclic dead end, ensuring both obligations produce real negatives.
    fair=C.G.graph_analyzer()
    test('strict_liveness_negative',lambda:C.req(fair({'states':['0'],'starts':['0'],'edges':[['0','0']],'env_justice':[],'sys_justice':[[]]})['strict_liveness']['pass'] is False,'Strict negative'))
    test('cooperation_deadend_negative',lambda:C.req(fair({'states':['0'],'starts':['0'],'edges':[],'env_justice':[],'sys_justice':[]})['nonconflicting']['pass'] is False,'Cooperation negative'))
    full_cli_fixture(out,fixtures,test)
    report={'schema':'v47-saved-route-synthetic-qualification-v1','status':'PASS' if all(x['pass'] for x in reports) else 'FAIL','synthetic_only':True,'actual_cohort_runs':0,'checks':reports,'passed':sum(x['pass'] for x in reports),'total':len(reports),'checker':hp(HERE/'check_roots.py'),'qualifier':hp(__file__),'fixture_files':[hp(p) for p in sorted(out.rglob('*')) if p.is_file()]}
    dump(out/'RESULT.json',report);print(json.dumps({'status':report['status'],'passed':report['passed'],'total':report['total'],'output':hp(out/'RESULT.json')}))
if __name__=='__main__':main(sys.argv[1])
