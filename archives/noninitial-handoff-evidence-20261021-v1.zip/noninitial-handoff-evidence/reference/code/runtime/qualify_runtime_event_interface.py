"""Synthetic-only qualification of run_handoff; never load the real cohort graphs.

Arguments: NEW_OUTPUT_DIRECTORY EXACT_LIFT_SOURCE_FILE
The source file is copied only to exercise the exact-byte authorization guard.
Every controller, roster, certificate and review below is deliberately synthetic.
Mock certificate verdicts are interface fixtures, never scientific evidence.
"""
from __future__ import annotations
import copy
import datetime
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys

RUNTIME = Path(__file__).with_name('run_handoff.py').resolve()
spec = importlib.util.spec_from_file_location('synthetic_runtime_under_test', RUNTIME)
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(value if isinstance(value, bytes) else r.encode(value))
    return r.pin(path)

def source(env, floor, monitor=None):
    answer = dict(zip(r.ENV, env))
    answer.update({f: 'true' if f == floor else 'false' for f in r.FLOORS})
    answer.update({a: 'S1' if a == monitor else 'S0' for a in r.AUX})
    return answer

def graph_data(label):
    nodes = {}
    def add(n, state, rank=0, initial=False):
        value = dict(state)
        if label != 'normalized': value['~envHelp'] = 'false'
        nodes[n] = {'id':n, 'rank':rank, 'initial':initial, 'valuation':value, 'successors':[]}
    def edge(a,b):
        if b not in nodes[a]['successors']: nodes[a]['successors'].append(b)
    states = [source((b1,'true','false',c), 'f2',r.AUX[1])
              for b1 in r.BOOL for c in r.BOOL]
    states += [source(('true',b2,'false',c), 'f1',r.AUX[0])
               for b2 in r.BOOL for c in r.BOOL]
    roots = []
    for i, s in enumerate(states):
        add('F%d'%i,s);roots.append('F%d'%i)
    if label == 'native':
        add('0',r.initial_source(),initial=True)
        add('P0',source(('false','true','false','false'),'f1'))
        add('P1',source(('false','true','false','true'),'f1'))
        add('P2',source(('false','true','false','false'),'f1'),2)
        add('Q',source(('true','false','false','false'),'f2'))
        edge('0','P0');edge('0','P1');edge('P1','Q');edge('P1','P2')
        for i in range(4):add('A%d'%i,states[i],1);edge('P0','A%d'%i);roots.append('A%d'%i)
        for i in range(4):add('B%d'%i,states[i+4],2);edge('Q','B%d'%i);roots.append('B%d'%i)
        for i in range(2):add('C%d'%i,states[i],0);edge('P2','C%d'%i);roots.append('C%d'%i)
    # Only the exact smallest-input continuation is needed for executor tests.
    # This is intentionally not a universally total scientific controller.
    for root in roots:
        current = root
        seen = {}
        for j in range(16):
            state = {k:nodes[current]['valuation'][k] for k in r.FIELDS}
            key = tuple(state[k] for k in r.FIELDS)
            if key in seen:
                raise AssertionError('Fixture construction loop')
            seen[key] = current
            offered = next(dict(e) for e in r.INPUTS if r.env_legal(state,e,'normal'))
            choices = []
            for floor in r.FLOORS:
                target = {**offered, **{f:'true' if f == floor else 'false' for f in r.FLOORS}, **r.next_monitors(state)}
                if r.sys_legal(state,target): choices.append(target)
            assert choices
            target = choices[0]; targetkey = tuple(target[k] for k in r.FIELDS)
            if targetkey in seen:
                edge(current, seen[targetkey]);break
            nextid = root+'_tail_%d'%j
            add(nextid,target);edge(current,nextid);current=nextid
        else: raise AssertionError('Fixture tail bound')
    data = {'synthetic_only':True, 'complete':True, 'fixture_id':'lift__trivial_1', 'nodes':list(nodes.values()),
            'edges':[[n['id'],t] for n in nodes.values() for t in n['successors']]}
    return data, states

def fixture(base, exact_source):
    base.mkdir()
    data = {}; refs = {}
    for label in ('native','preference','normalized'):
        data[label], states = graph_data(label)
        refs[label] = write(base/label/'controller.json',data[label])
        refs[label]['model'] = write(base/label/'model.json',{'synthetic_only':True})
        refs[label]['result'] = write(base/label/'result.json',{'synthetic_only':True})
        refs[label]['printer'] = None if label == 'normalized' else write(base/label/'controller.txt',b'synthetic-only printer\n')
        refs[label]['model_predicates'] = [write(base/label/'predicate.bdd',b'synthetic-only predicate\n')]
        refs[label]['source_correspondence'] = []
    boundaries = []
    for i in range(10):
        if i < 4: node='A%d'%i; rank=1; path=['0','P0',node];index=i
        elif i < 8: node='B%d'%(i-4);rank=2;path=['0','P1','Q',node];index=i
        else: node='C%d'%(i-8);rank=0;path=['0','P1','P2',node];index=i-8
        boundaries.append({'id':'synthetic_boundary_%02d'%(i+1),'source_state':states[index],
            'reached_native_node':node,'reached_rank':rank,'prefix_node_ids':path,
            'candidates':[{'candidate':name,'graph':r.CANDIDATE_GRAPH[name],
                          'root':node if name=='retain_old_native' else 'F%d'%index,
                          'rank':rank if name=='retain_old_native' else 0} for name in r.ORDER]})
    source_ref = write(base/'source.spectra', exact_source)
    old_ref = write(base/'old.spectra',exact_source+r.OLD_SOURCE_SUFFIX)
    roster_ref = write(base/'ROSTER.json',{'boundaries':boundaries,'synthetic_only':True})
    inputs = {'schema':'v47-staged-immutable-inputs-v1','source':source_ref,'old_source':old_ref,
              'graphs':refs,'roster':roster_ref,'copies':[]}
    inputs_ref=write(base/'INPUTS.json',inputs)
    plan = {'schema':'v47-noninitial-handoff-plan-v1','synthetic_only':True,
        'source':source_ref,'old_source':old_ref,'graphs':refs,'roster':roster_ref,'inputs':inputs_ref,
        'selection':write(base/'SELECTION.json',{'status':'SELECT_N3_SYNTHETIC_INTERFACE_FIXTURE'}),
        'boundaries':boundaries,'candidate_order':list(r.ORDER),'policies':list(r.POLICIES),
        'disabled_button':'b3','old_start_node':'0','continuation_steps_per_episode':32,
        'old_mode':{'disabled_ENV':'b3','current_value':'false','next_value':'false','source_initializers_preserved':True},
        'full_reset_uses':0,'fresh_native_or_compiler_execution':False,
        'hard_stop_utc':(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(hours=1)).isoformat(),
        'region':{'model_predicates':[write(base/'K.bdd',b'synthetic-only region\n')]}}
    plan_ref=write(base/'PLAN.json',plan)
    review={'status':'PASS_SYNTHETIC_REVIEW_FIXTURE_NOT_ACTUAL_APPROVAL','plan':copy.deepcopy(plan_ref),'runtime':r.pin(RUNTIME)}
    review_ref=write(base/'REVIEW.json',review)
    graphs={label:r.SavedGraph(label,refs[label],data[label]) for label in refs}
    rows=r.validate_roster(r.normalized_roster({'boundaries':boundaries},graphs),graphs)
    certs={}
    for route in ('source','saved_model'):
        certs[route]={'schema':'v47-rooted-graph-certificate-bundle-v1','status':'COMPLETE_ROOTED_CANDIDATES',
            'route':route,'plan':copy.deepcopy(plan_ref),'synthetic_only':True,
            'old_gate':{k:True for k in ('complete','strict','cooperative','source_coverage')},'boundaries':[]}
        for b in rows:
            out={k:copy.deepcopy(b[k]) for k in ('id','source_state','reached_native_node','reached_rank')}
            out['candidates']=[{**c,'complete':True,'strict':True,'cooperative':c['candidate'] in ('fresh_normalized','fresh_preference'),
                'source_coverage':True,'large_ignored_evidence':'synthetic '*200} for c in b['candidates']]
            certs[route]['boundaries'].append(out)
    cert_refs={route:write(base/(route+'.json'),cert) for route,cert in certs.items()}
    go={'status':'GO_EXACT_FROZEN_HANDOFF_RUNTIME','synthetic_only':True,'plan':plan_ref,
        'runtime_script':r.pin(RUNTIME),'independent_runtime_review':review_ref,'certificates':cert_refs,
        'runtime_deadline_utc':plan['hard_stop_utc']}
    write(base/'GO.json',go)
    return {'base':base,'plan':plan,'go':go,'review':review,'certs':certs,'graphs':graphs,'boundaries':rows,'data':data}

def refresh(f, key):
    if key=='review':f['go']['independent_runtime_review']=write(f['base']/'REVIEW.json',f['review'])
    elif key in f['certs']:f['go']['certificates'][key]=write(f['base']/(key+'.json'),f['certs'][key])
    write(f['base']/'GO.json',f['go'])

def rebind_plan(f):
    manifest=r.read_json(f['base']/'INPUTS.json')
    for name in ('source','old_source','graphs','roster'):manifest[name]=copy.deepcopy(f['plan'][name])
    f['plan']['inputs']=write(f['base']/'INPUTS.json',manifest)
    ref=write(f['base']/'PLAN.json',f['plan'])
    f['go']['plan']=copy.deepcopy(ref);f['review']['plan']=copy.deepcopy(ref)
    refresh(f,'review')
    for route in f['certs']:
        f['certs'][route]['plan']=copy.deepcopy(ref);refresh(f,route)

def main():
    out=Path(sys.argv[1]).resolve(); src=Path(sys.argv[2]).resolve()
    assert not out.exists();out.mkdir()
    exact=src.read_bytes();assert hashlib.sha256(exact).hexdigest()==r.SOURCE_SHA and len(exact)==r.SOURCE_BYTES
    rows=[]
    def check(name, fn, reject=None):
        try:
            details=fn()
            if reject is not None: raise AssertionError('Expected rejection: '+reject)
            rows.append({'name':name,'status':'PASS','details':details})
        except r.Refusal as error:
            if reject is None or reject not in str(error):
                rows.append({'name':name,'status':'FAIL','error':type(error).__name__+': '+str(error)})
            else:rows.append({'name':name,'status':'PASS_EXPECTED_REJECTION','reason':str(error)})
        except Exception as error:rows.append({'name':name,'status':'FAIL','error':type(error).__name__+': '+str(error)})
    base=fixture(out/'positive',exact)
    def load(f): return r.load_authorized(f['base']/'PLAN.json',f['base']/'GO.json')
    def positive_load():
        bundle=load(base)
        assert len(bundle[5])==10 and len(bundle[6])==10
        assert all(set(c)==set(r.CERTIFICATE_KEYS) for v in bundle[6].values() for c in v)
        for label in base['graphs']:
            assert base['plan']['graphs'][label]['model_predicates'][0]['path'] in bundle[0].files
        assert base['plan']['region']['model_predicates'][0]['path'] in bundle[0].files
        assert base['plan']['old_source']['path'] in bundle[0].files
        return {'bound_files':len(bundle[0].files),'boundaries':10,'compact_certificate_keys':list(r.CERTIFICATE_KEYS),'normalized_printer_is_null':True}
    check('full_authorization_and_compact_certificate_projection',positive_load)
    def all_episodes():
        assert r.main([str(base['base']/'PLAN.json'),str(base['base']/'GO.json'),str(base['base']/'runtime_output')])==0
        result=r.read_json(base['base']/'runtime_output/RESULT.json')
        events=[json.loads(x) for x in (base['base']/'runtime_output/EVENTS.jsonl').read_text().splitlines()]
        assert result['status']=='COMPLETE_EXECUTED_HANDOFF_CENSUS' and len(result['episodes'])==20
        assert all(e['outcome']['status']=='EXECUTED_FAIR_LASSO' for e in result['episodes'])
        for e in result['episodes']:
            assert e['selected_candidate']==('retain_old_native' if e['policy']=='strict_only' else 'fresh_normalized')
            related=[x for x in events if x.get('runtime',{}).get('episode_id')==e['episode_id']]
            changed=next(x for x in related if x['event']=='boundary_paused_and_environment_changed')
            installed=next(x for x in related if x['event'] in ('controller_retained','controller_installed'))
            assert changed['before']['source_state']==changed['runtime']['source_state']==installed['runtime']['source_state']
            assert len({x['runtime']['plant_identity'] for x in related})==len({x['runtime']['state_object_identity'] for x in related})==1
            oldid=changed['runtime']['controller']['instance_identity'];newid=installed['runtime']['controller']['instance_identity']
            assert (oldid==newid)==(e['policy']=='strict_only')
            if e['policy']=='strict_and_cooperative':assert installed['runtime']['controller']['rank']==0
            assert [d['candidate'] for d in e['decisions']]==list(r.ORDER)
        return {'episodes':20,'events':len(events),'all_outcomes':'EXECUTED_FAIR_LASSO','result':r.pin(base['base']/'runtime_output/RESULT.json'),'events_file':r.pin(base['base']/'runtime_output/EVENTS.jsonl')}
    check('twenty_real_step_commit_synthetic_episodes_retention_and_installation',all_episodes)
    def auth_case(name, mutate, rejection):
        f=fixture(out/name,exact);mutate(f)
        check(name,lambda:load(f),rejection)
    auth_case('missing_go',lambda f:(f['go'].update(status='NOT_GO'),refresh(f,'go')),'Missing exact runtime GO')
    auth_case('stale_plan_review',lambda f:(f['review']['plan'].update(sha256='0'*64),refresh(f,'review')),'does not bind current plan')
    auth_case('stale_runtime_review',lambda f:(f['review']['runtime'].update(sha256='0'*64),refresh(f,'review')),'does not bind current plan')
    auth_case('review_not_pass',lambda f:(f['review'].update(status='PENDING'),refresh(f,'review')),'review did not pass')
    auth_case('runtime_go_wrong_hash',lambda f:(f['go']['runtime_script'].update(sha256='0'*64),refresh(f,'go')),'Input pin mismatch')
    auth_case('old_gate_false',lambda f:(f['certs']['source']['old_gate'].update(strict=False),refresh(f,'source')),'Old-mode gate did not pass')
    auth_case('certificate_plan_stale',lambda f:(f['certs']['source']['plan'].update(sha256='0'*64),refresh(f,'source')),'Certificate plan binding differs')
    auth_case('independent_verdict_disagreement',lambda f:(f['certs']['saved_model']['boundaries'][0]['candidates'][0].update(strict=False),refresh(f,'saved_model')),'Independent candidate routes disagree')
    auth_case('candidate_incomplete',lambda f:(f['certs']['source']['boundaries'][0]['candidates'][0].update(complete=False),refresh(f,'source')),'Noncomplete candidate')
    auth_case('candidate_coverage_missing',lambda f:(f['certs']['source']['boundaries'][0]['candidates'][0].update(source_coverage=False),refresh(f,'source')),'Noncomplete candidate')
    auth_case('candidate_root_wrong',lambda f:(f['certs']['source']['boundaries'][0]['candidates'][0].update(root_id='F0'),refresh(f,'source')),'Certificate root binding differs')
    auth_case('candidate_order_wrong',lambda f:(f['certs']['source']['boundaries'][0]['candidates'].reverse(),refresh(f,'source')),'Certificate candidate roster/order differs')
    auth_case('candidate_boolean_type_wrong',lambda f:(f['certs']['source']['boundaries'][0]['candidates'][0].update(strict=1),refresh(f,'source')),'Candidate verdict must be explicit Boolean')
    auth_case('nested_model_predicate_mutation',lambda f:Path(f['plan']['graphs']['native']['model_predicates'][0]['path']).write_bytes(b'changed\n'),'Input pin mismatch')
    auth_case('region_predicate_mutation',lambda f:Path(f['plan']['region']['model_predicates'][0]['path']).write_bytes(b'changed\n'),'Input pin mismatch')
    auth_case('old_source_mutation',lambda f:Path(f['plan']['old_source']['path']).write_bytes(exact),'Input pin mismatch')
    auth_case('input_manifest_mutation',lambda f:Path(f['plan']['inputs']['path']).write_bytes(b'{}\n'),'Input pin mismatch')
    auth_case('saved_graph_mutation',lambda f:Path(f['plan']['graphs']['native']['path']).write_bytes(b'{}\n'),'Input pin mismatch')
    def altered_old_source(f):
        f['plan']['old_source']=write(f['base']/'old.spectra',exact+r.OLD_SOURCE_SUFFIX+b'\nassumption alw(b1=false);\n')
        rebind_plan(f)
    auth_case('repinned_old_source_extra_assumption',altered_old_source,'Old source must append only')
    def null_native_printer(f):
        f['plan']['graphs']['native']['printer']=None;rebind_plan(f)
    auth_case('native_printer_null_refused',null_native_printer,'Native graph printer pin is required')
    def postload_recheck():
        f=fixture(out/'postload_input_recheck',exact);bundle=load(f)
        Path(f['plan']['graphs']['preference']['model_predicates'][0]['path']).write_bytes(b'changed\n');bundle[0].recheck()
    check('postload_input_recheck',postload_recheck,'Bound input changed')
    graphs=base['graphs'];boundary=base['boundaries'][0]
    def episode_with(accept):
        verdicts=[{**c,'complete':True,'source_coverage':True,'strict':c['candidate'] in accept,'cooperative':c['candidate'] in accept} for c in boundary['candidates']]
        stream=io.StringIO();log=r.EventLog(stream,datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(minutes=5));keep=[]
        value=r.run_episode(boundary,'strict_and_cooperative',graphs,verdicts,{},log,keep)
        return value,keep[0],[json.loads(x) for x in stream.getvalue().splitlines()]
    for name in r.ORDER:
        def candidate_test(name=name):
            result,rt,events=episode_with({name});assert result['selected_candidate']==name
            assert result['outcome']['status']=='EXECUTED_FAIR_LASSO'
            assert sum(x['event']=='step_committed' and x['phase']=='frozen_old_native_prefix' for x in events)==2
            install=next(x for x in events if x['event'] in ('controller_retained','controller_installed'))
            assert install['before']['source_state']==install['runtime']['source_state']==boundary['source_state']
            assert (rt.controller is rt.old_controller)==(name=='retain_old_native')
            return {'chosen':name,'installed_rank':install['runtime']['controller']['rank']}
        check('admission_'+name,candidate_test)
    def abstain():
        result,rt,events=episode_with(set());assert result['status']=='COMPLETE_ADMISSION_ABSTAINED' and rt.paused
        assert rt.controller is rt.old_controller and rt.state==boundary['source_state']
        assert len(result['decisions'])==4 and all(d['considered'] for d in result['decisions'])
        assert not any(x['event'] in ('resumed','controller_installed','controller_retained') for x in events)
        return {'paused':True,'selected_candidate':None}
    check('complete_all_candidate_abstention_preserves_pause',abstain)
    def same_root_fresh_instance():
        b=copy.deepcopy(base['boundaries'][8]);b['candidates'][1]['root_id']=b['reached_native_node']
        verdicts=[{**c,'complete':True,'source_coverage':True,'strict':c['candidate']=='fresh_native','cooperative':True} for c in b['candidates']]
        stream=io.StringIO();log=r.EventLog(stream,datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(minutes=5));keep=[]
        value=r.run_episode(b,'strict_only',graphs,verdicts,{},log,keep)
        events=[json.loads(x) for x in stream.getvalue().splitlines()]
        change=next(x for x in events if x['event']=='boundary_paused_and_environment_changed')
        install=next(x for x in events if x['event']=='controller_installed')
        assert value['selected_candidate']=='fresh_native'
        assert change['runtime']['controller']['node_id']==install['runtime']['controller']['node_id']=='C0'
        assert change['runtime']['controller']['rank']==install['runtime']['controller']['rank']==0
        assert change['runtime']['controller']['instance_identity']!=install['runtime']['controller']['instance_identity']
        return {'same_root_and_rank':True,'new_private_instance':True}
    check('fresh_same_root_rank0_uses_new_instance',same_root_fresh_instance)
    check('new_controller_wrong_rank',lambda:r.GraphController(graphs['native'],'A0',boundary['source_state'],0),'Exact source/history/private-root mapping differs')
    wrong=dict(boundary['source_state']);wrong[r.AUX[1]]='S0'
    check('logical_history_reset_rejected',lambda:r.GraphController(graphs['native'],'F0',wrong,0),'Exact source/history/private-root mapping differs')
    def missing_response():
        c=r.GraphController(graphs['native'],'A0',boundary['source_state'],1)
        return c.propose(boundary['source_state'],dict(zip(r.ENV,('false','false','true','false'))))
    check('missing_saved_response_refused',missing_response,'Actual native response missing or nondeterministic')
    def duplicate_response():
        d=copy.deepcopy(base['data']['native']);node=next(x for x in d['nodes'] if x['id']=='A0');target=next(x for x in d['nodes'] if x['id']==node['successors'][0]);other=copy.deepcopy(target);other['id']='duplicate';other['successors']=[];d['nodes'].append(other);node['successors'].append('duplicate');d['edges'].append(['A0','duplicate'])
        g=r.SavedGraph('native',{'sha256':'synthetic'},d);c=r.GraphController(g,'A0',boundary['source_state'],1)
        c.propose(boundary['source_state'],{k:target['valuation'][k] for k in r.ENV})
    check('duplicate_saved_response_refused',duplicate_response,'Actual native response missing or nondeterministic')
    def immutable_graph():
        try: graphs['native'].node('A0')['valuation'][r.AUX[1]]='S0'
        except TypeError:return {'mutation_blocked':True}
        raise AssertionError('Graph mutation permitted')
    check('immutable_source_and_private_graph_records',immutable_graph)
    def env_scope():
        state=boundary['source_state'];offer=dict(zip(r.ENV,('false','false','true','false')))
        assert not r.env_legal(state,offer,'old_no_b3') and r.env_legal(state,offer,'normal')
        return {'only_old_b3_restriction_removed':True}
    check('old_and_new_environment_modes',env_scope)
    def no_next_onehot_shield():
        state=r.initial_source();target=dict(state);target['f2']='true'
        assert r.sys_legal(state,target) # Current-source SYS formula alone allows this next valuation.
        assert not r.env_legal(target,{k:'false' for k in r.ENV},'normal')
        return {'source_SYS_permits_target_original_ENV_deadend':True}
    check('source_semantics_has_no_next_onehot_shield',no_next_onehot_shield)
    bad=out/'duplicate_keys.json';bad.write_text('{"x":1,"x":2}')
    check('duplicate_json_key_rejected',lambda:r.read_json(bad),'Duplicate JSON key')
    status='PASS_SYNTHETIC_RUNTIME_QUALIFICATION' if all(x['status'].startswith('PASS') for x in rows) else 'FAIL_SYNTHETIC_RUNTIME_QUALIFICATION'
    report={'schema':'v47-runtime-synthetic-qualification-v1','status':status,'runtime':r.pin(RUNTIME),'qualifier':r.pin(__file__),
        'qualification_revision':3,'integration_note':'Separate synthetic graph envelope adds complete/fixture_id only for independent event-audit full-CLI qualification; original qualifier and runtime unchanged.','prior_rev01_preserved':'Two negative fixtures shared plan pin dictionaries with GO and hit an earlier guard; fixture deep copies corrected. Runtime unchanged.',
        'scope':'Synthetic graphs/rosters/certificates/reviews only. Exact source bytes copied for authorization guard; no real graph or real certificate execution.',
        'real_cohort_executions':0,'native_or_compiler_executions':0,'full_reset_uses':0,'cases':rows,
        'case_count':len(rows),'passed':sum(x['status'].startswith('PASS') for x in rows),'failed':sum(not x['status'].startswith('PASS') for x in rows),
        'files':[r.pin(p) for p in sorted(out.rglob('*')) if p.is_file()]}
    write(out/'RESULT.json',report)
    print(json.dumps({'status':status,'cases':len(rows),'failed':[x for x in rows if not x['status'].startswith('PASS')],'result':r.pin(out/'RESULT.json')}))
    return 0 if status.startswith('PASS') else 2

if __name__=='__main__':raise SystemExit(main())
