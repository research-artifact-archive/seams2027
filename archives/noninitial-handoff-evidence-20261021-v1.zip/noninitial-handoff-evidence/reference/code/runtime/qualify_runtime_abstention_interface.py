"""One synthetic full-CLI abstention branch for the independent event auditor.
Uses only the preserved artificial-graph event-interface fixture; never real cohort.
"""
from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys

HERE=Path(__file__).resolve().parent
BASE=HERE.parent.parent
FIXTURE=BASE/'qualification_runtime_event_interface_01'/'positive'
OUT=BASE/'qualification_runtime_abstention_interface_01'
def pin(p):
 p=Path(p).resolve();raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def write(p,data):
 with p.open('x') as f:json.dump(data,f,ensure_ascii=False,indent=2);f.write('\n')
 return pin(p)
def load(p):return json.loads(Path(p).read_text())
assert not OUT.exists();OUT.mkdir()
plan=load(FIXTURE/'PLAN.json');go=load(FIXTURE/'GO.json')
assert plan['synthetic_only'] is True and go['synthetic_only'] is True
for ref in plan['graphs'].values():assert load(ref['path'])['synthetic_only'] is True
refs={}
for route,ref in go['certificates'].items():
 bundle=load(ref['path']);assert bundle['synthetic_only'] is True
 for row in bundle['boundaries']:
  for candidate in row['candidates']:
   candidate['strict']=False;candidate['cooperative']=False
 refs[route]=write(OUT/(route+'.json'),bundle)
go=copy.deepcopy(go);go['certificates']=refs;write(OUT/'GO.json',go)
command=[sys.executable,'-I','-S','-B',str(HERE/'run_handoff.py'),str(FIXTURE/'PLAN.json'),str(OUT/'GO.json'),str(OUT/'runtime_output')]
completed=subprocess.run(command,text=True,capture_output=True,timeout=30)
(OUT/'stdout.txt').write_text(completed.stdout);(OUT/'stderr.txt').write_text(completed.stderr)
result=load(OUT/'runtime_output'/'RESULT.json')
assert completed.returncode==0 and result['status']=='COMPLETE_EXECUTED_HANDOFF_CENSUS'
assert len(result['episodes'])==20 and all(e['status']=='COMPLETE_ADMISSION_ABSTAINED' and e['selected_candidate'] is None and e['final_snapshot']['paused'] is True for e in result['episodes'])
events=[json.loads(x) for x in Path(result['events']['path']).read_text().splitlines()]
assert sum(e['event']=='admission_abstained' for e in events)==20
assert not any(e['event'] in ('controller_installed','controller_retained','resumed') for e in events)
report={'status':'PASS_SYNTHETIC_FULL_20_ABSTENTION_CLI','synthetic_only':True,'real_cohort_executions':0,'native_or_compiler_executions':0,'full_reset_uses':0,'plan':pin(FIXTURE/'PLAN.json'),'runtime':pin(HERE/'run_handoff.py'),'qualifier':pin(__file__),'execution_go':pin(OUT/'GO.json'),'runtime_result':pin(OUT/'runtime_output/RESULT.json'),'events':result['events'],'episodes':20,'abstentions':20,'selected_candidates':0,'process':{'argv':command,'exit_code':completed.returncode,'stdout':pin(OUT/'stdout.txt'),'stderr':pin(OUT/'stderr.txt')}}
write(OUT/'RESULT.json',report);print(json.dumps({'status':report['status'],'report':pin(OUT/'RESULT.json'),'runtime_result':report['runtime_result']}))
