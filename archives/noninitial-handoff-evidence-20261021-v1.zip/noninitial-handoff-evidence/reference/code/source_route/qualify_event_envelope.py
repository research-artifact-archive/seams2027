"""Exercise the independent auditor's entire CLI envelope on synthetic runtime data.

Arguments: SYNTHETIC_PLAN SYNTHETIC_RUNTIME_RESULT NEW_OUTPUT_DIRECTORY.
This does not execute/import the runtime or read any actual-cohort result.
"""
from pathlib import Path
import copy
import json
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import audit_handoff_events as auditor
from independent_core import AuditError, pin, decode_json, read_pin, save_new


def main(plan_path, result_path, directory):
    plan_path, result_path, directory = map(lambda x: Path(x).resolve(), (plan_path, result_path, directory))
    # The producer's separate artificial-graph fixture is the only accepted input.
    need = auditor.need
    need('qualification_runtime_event_interface_01' in plan_path.parts
         and 'qualification_runtime_event_interface_01' in result_path.parts, 'Synthetic integration fixture required')
    result = decode_json(result_path.read_bytes()); original_events = [decode_json(x) for x in read_pin(result['events']).decode().splitlines()]
    directory.mkdir(parents=True, exist_ok=False)
    cases = []
    def run_case(name, mutator=None, expected_pass=False, raw_digest_failure=False):
        events, record = copy.deepcopy(original_events), copy.deepcopy(result)
        if mutator: mutator(events, record)
        for seq, event in enumerate(events): event['seq'] = seq
        events_path = directory / (name + '.jsonl')
        with events_path.open('x') as f:
            for e in events: f.write(json.dumps(e, ensure_ascii=False) + '\n')
        record['events'] = pin(events_path); record['event_count'] = len(events)
        if raw_digest_failure: record['events']['sha256'] = 'f' * 64
        record_path = directory / (name + '_runtime_result.json'); save_new(record_path, record)
        try:
            answer = auditor.run(plan_path, record_path)
            passed = expected_pass and answer['status'] == 'PASS_ALL_20_EXECUTED_EPISODES'
            observed = answer['status']; save_new(directory / (name + '_audit.json'), answer)
        except (AuditError, KeyError, TypeError, ValueError, OSError) as error:
            passed = not expected_pass; observed = type(error).__name__ + ': ' + str(error)
        cases.append({'name': name, 'pass': passed, 'expected': 'PASS' if expected_pass else 'REJECT',
                      'observed': observed, 'runtime_result': pin(record_path), 'events': pin(events_path)})
    def event_named(events, name, policy=None):
        return next(e for e in events if e['event'] == name and (policy is None or e['runtime']['policy'] == policy))
    run_case('full_twenty_episode_envelope', expected_pass=True)
    run_case('bad_event_digest', raw_digest_failure=True)
    run_case('wrong_raw_root_rank', lambda es, r: event_named(es, 'boundary_paused_and_environment_changed')['runtime']['controller'].__setitem__('rank', 99))
    run_case('AUX_reset_after_pause', lambda es, r: event_named(es, 'boundary_paused_and_environment_changed')['runtime']['source_state'].__setitem__(auditor.C.aux[1][0], 'S0'))
    run_case('counterfeit_selected_candidate', lambda es, r: event_named(es, 'candidate_admission', 'strict_and_cooperative')['decision'].__setitem__('selected', True))
    run_case('missing_actual_prefix_commit', lambda es, r: es.remove(event_named(es, 'step_committed')))
    run_case('changed_snapshot_graph_digest', lambda es, r: event_named(es, 'episode_boot')['runtime']['controller'].__setitem__('graph_sha256', 'f' * 64))
    run_case('result_selected_candidate_mismatch', lambda es, r: r['episodes'][0].__setitem__('selected_candidate', 'fresh_preference'))
    run_case('missing_last_episode_result', lambda es, r: r['episodes'].pop())
    run_case('different_event_process', lambda es, r: es[1].__setitem__('pid', es[0]['pid'] + 1))
    run_case('nonmonotonic_event_clock', lambda es, r: es[2].__setitem__('monotonic_ns', es[0]['monotonic_ns'] - 1))
    def duplicate_old_instance(events, record):
        boots = [e for e in events if e['event'] == 'episode_boot']; first, second = boots[:2]
        old = second['runtime']['controller']['instance_identity']; replacement = first['runtime']['controller']['instance_identity']
        target_episode = second['runtime']['episode_id']
        def walk(x):
            if isinstance(x, dict):
                if x.get('instance_identity') == old: x['instance_identity'] = replacement
                for value in x.values(): walk(value)
            elif isinstance(x, list):
                for value in x: walk(value)
        for e in events:
            if e.get('runtime', {}).get('episode_id') == target_episode: walk(e)
        for row in record['episodes']:
            if row['episode_id'] == target_episode: walk(row)
    run_case('cross_episode_old_instance_reused', duplicate_old_instance)
    report = {'schema': 'v47-full-source-event-envelope-synthetic-qualification-v1',
              'status': 'PASS' if all(c['pass'] for c in cases) else 'FAIL', 'synthetic_only': True,
              'actual_cohort_semantic_evaluation': False, 'runtime_imports_or_executions': 0,
              'plan': pin(plan_path), 'producer_synthetic_result': pin(result_path),
              'auditor': pin(Path(auditor.__file__)), 'qualifier': pin(__file__),
              'cases': cases, 'counts': {'total': len(cases), 'pass': sum(c['pass'] for c in cases)}}
    save_new(directory / 'RESULT.json', report)
    print(json.dumps({'status': report['status'], 'counts': report['counts'], 'result': pin(directory / 'RESULT.json')}))
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    if len(sys.argv) != 4: raise SystemExit('Usage: qualify_event_envelope.py SYNTHETIC_PLAN SYNTHETIC_RESULT NEW_OUTPUT_DIRECTORY')
    raise SystemExit(main(*sys.argv[1:]))
