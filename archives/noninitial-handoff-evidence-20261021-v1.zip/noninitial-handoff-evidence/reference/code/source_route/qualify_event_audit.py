"""Synthetic-only event-auditor qualification; no runtime import or actual data."""
from pathlib import Path
import copy
import json
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import audit_handoff_events as auditor
from independent_core import AuditError, pin, save_new

C = auditor.C


def fixture(policy):
    s0 = {n: 'false' for n in C.env + C.system}; s0['f1'] = 'true'
    s0.update({n: 'S0' for n, _ in C.aux})
    s1 = dict(s0); s1['b2'] = 'true'
    s2 = dict(s1); s2.update(f1='false', f2='true'); s2[C.aux[1][0]] = 'S1'
    s3 = dict(s2); s3['b2'] = 'false'; s3[C.aux[1][0]] = 'S0'
    def graph(label, vals, ranks, edges):
        nodes = {str(i): {'id': str(i), 'rank': r, 'initial': i == 0 and label == 'native',
                          'valuation': s, 'successors': [str(b) for a, b in edges if a == i]}
                 for i, s, r in zip(vals, vals.values(), ranks)}
        return {'nodes': nodes, 'edges': {(str(a), str(b)) for a, b in edges},
                'pin': {'path': '/synthetic/' + label + '.json', 'bytes': 1,
                        'sha256': {'native': '1', 'normalized': '2', 'preference': '3'}[label] * 64}}
    graphs = {
        'native': graph('native', {0: s0, 1: s1, 2: s2, 3: s3}, [0, 1, 2, 2], [(0, 1), (1, 2), (2, 3), (3, 3)]),
        'normalized': graph('normalized', {20: s2, 21: s3}, [0, 0], [(20, 21), (21, 21)]),
        'preference': graph('preference', {30: s2, 31: s3}, [0, 0], [(30, 31), (31, 31)]),
    }
    # Actual fresh-native rank0 root is represented separately, without rewriting node2.
    graphs['native']['nodes']['10'] = {'id': '10', 'rank': 0, 'initial': False, 'valuation': s2, 'successors': ['3']}
    graphs['native']['edges'].add(('10', '3'))
    roots = ('2', '10', '20', '30'); ranks = (2, 0, 0, 0)
    certs = [{'candidate': a, 'graph_sha256': graphs[auditor.GRAPH_FOR[a]]['pin']['sha256'],
              'root_id': root, 'rank': rank, 'complete': True, 'strict': True,
              'cooperative': a in ('fresh_normalized', 'fresh_preference'), 'source_coverage': True}
             for a, root, rank in zip(auditor.ARMS, roots, ranks)]
    refs = {'source': {'path': '/synthetic/source.json', 'bytes': 1, 'sha256': 'a' * 64},
            'saved_model': {'path': '/synthetic/saved.json', 'bytes': 1, 'sha256': 'b' * 64}}
    row = {'id': 'synthetic_boundary', 'source_state': s2, 'reached_native_node': '2', 'reached_rank': 2,
           'prefix_node_ids': ['0', '1', '2']}
    episode = row['id'] + '__' + policy
    def snap(node='0', label='native', instance=100, created='0', created_rank=0, mode='old_no_b3', epoch=0, paused=False, ticks=0):
        n = graphs[label]['nodes'][node]
        return {'episode_id': episode, 'boundary_id': row['id'], 'policy': policy,
                'plant_identity': 1000, 'state_object_identity': 1001,
                'source_state': dict(n['valuation']), 'contract_mode': mode, 'epoch': epoch, 'paused': paused, 'ticks': ticks,
                'controller': {'instance_identity': instance, 'graph': label, 'graph_sha256': graphs[label]['pin']['sha256'],
                               'node_id': node, 'rank': n['rank'], 'original_initial_flag': n['initial'],
                               'created_root': created, 'created_rank': created_rank}}
    events = []
    def emit(event, snapshot, **extra):
        events.append({'event': event, 'runtime': copy.deepcopy(snapshot), **copy.deepcopy(extra)})
    current = snap(); emit('episode_boot', current)
    for target in ('1', '2'):
        before = current; current = snap(node=target, ticks=before['ticks'] + 1)
        emit('step_committed', current, before=before, offered_env={k: current['source_state'][k] for k in C.env}, phase='frozen_old_native_prefix')
    before = current; current = snap(node='2', mode='normal', epoch=1, paused=True, ticks=2)
    emit('boundary_paused_and_environment_changed', current, before=before, removed_restriction='G !b3')
    decisions, chosen = [], None
    for cert in certs:
        eligible = cert['strict'] and (policy == 'strict_only' or cert['cooperative'])
        d = {**cert, 'considered': chosen is None, 'eligible_under_policy': eligible, 'selected': chosen is None and eligible}
        decisions.append(d); emit('candidate_admission', current, decision=d, certificates=refs)
        if chosen is None and eligible: chosen = cert
    retaining = chosen['candidate'] == 'retain_old_native'
    label = auditor.GRAPH_FOR[chosen['candidate']]; root = chosen['root_id']
    instance = 100 if retaining else 200; created = '0' if retaining else root
    before = current; current = snap(root, label, instance, created, 0, 'normal', 1, True, 2)
    emit('controller_retained' if retaining else 'controller_installed', current, before=before,
         candidate=chosen['candidate'], certified_root=chosen, certificates=refs)
    current = snap(root, label, instance, created, 0, 'normal', 1, False, 2); emit('resumed', current)
    trail = [copy.deepcopy(current)]
    next_node = '3' if retaining else '21'
    for tick in (3, 4):
        before = current; current = snap(next_node, label, instance, created, 0, 'normal', 1, False, tick)
        emit('step_committed', current, before=before, offered_env={n: 'false' for n in C.env},
             phase='lexicographically_smallest_legal_continuation'); trail.append(copy.deepcopy(current))
    hits = {n: True for n, _ in C.aux}; outcome = 'EXECUTED_FAIR_LASSO'
    emit('executed_cycle', current, status=outcome, cycle_start=1, cycle_end=2, SYS_justice_hits=hits, ENV_justice_count=0)
    emit('episode_completed', current, selected_candidate=chosen['candidate'], outcome=outcome)
    result = {'episode_id': episode, 'boundary_id': row['id'], 'policy': policy,
              'status': 'COMPLETE_EXECUTED_HANDOFF', 'prefix_committed_steps': 2,
              'decisions': decisions, 'selected_candidate': chosen['candidate'],
              'old_private_root': {'node_id': '2', 'rank': 2},
              'installed_private_root': {'node_id': root, 'rank': chosen['rank']},
              'outcome': {'status': outcome, 'committed_continuation_steps': 2, 'final_snapshot': current,
                          'cycle_start': 1, 'cycle_end': 2, 'SYS_justice_hits': hits, 'ENV_justice_count': 0, 'trail': trail},
              'final_snapshot': current}
    return {'events': events, 'row': row, 'policy': policy, 'graphs': graphs, 'certificates': certs,
            'certificate_refs': refs, 'episode_result': result}


def main(directory):
    directory = Path(directory).resolve(); directory.mkdir(parents=True, exist_ok=False)
    tests = []
    def check(name, value, reject=False):
        try:
            result = auditor.audit_episode(**value)
            passed = not reject and result['pass']; observed = result
        except (AuditError, KeyError, TypeError, ValueError) as error:
            passed = reject; observed = str(error)
        tests.append({'name': name, 'expected': 'reject' if reject else 'PASS', 'pass': bool(passed), 'observed': observed})
    strict = fixture('strict_only'); coop = fixture('strict_and_cooperative')
    check('actual_prefix_then_retained_private_instance', strict)
    check('actual_prefix_then_new_actual_rank0_instance', coop)
    abstain = copy.deepcopy(coop)
    for cert in abstain['certificates']:
        cert['strict'] = cert['cooperative'] = False
    abstain['events'] = abstain['events'][:8]
    abstain_decisions = []
    for event, cert in zip(abstain['events'][4:8], abstain['certificates']):
        decision = {**cert, 'considered': True, 'eligible_under_policy': False, 'selected': False}
        event['decision'] = decision; abstain_decisions.append(decision)
    paused = copy.deepcopy(abstain['events'][3]['runtime'])
    abstain['events'].append({'event': 'admission_abstained', 'runtime': paused,
                              'reason': 'No candidate satisfies the frozen admission policy'})
    abstain['episode_result'] = {'episode_id': paused['episode_id'], 'boundary_id': paused['boundary_id'],
                                 'policy': paused['policy'], 'status': 'COMPLETE_ADMISSION_ABSTAINED',
                                 'decisions': abstain_decisions, 'selected_candidate': None,
                                 'prefix_committed_steps': 2, 'final_snapshot': paused}
    check('complete_abstention_preserves_pause_and_old_instance', abstain)
    def mutate(name, operation, base=coop):
        value = copy.deepcopy(base); operation(value); check(name, value, True)
    mutate('missing_actual_prefix_commit', lambda v: v['events'].pop(1))
    mutate('source_AUX_reset_at_pause', lambda v: v['events'][3]['runtime']['source_state'].__setitem__(C.aux[1][0], 'S0'))
    mutate('wrong_boundary_private_rank', lambda v: v['events'][3]['runtime']['controller'].__setitem__('rank', 0))
    mutate('altered_graph_digest', lambda v: v['events'][0]['runtime']['controller'].__setitem__('graph_sha256', 'f' * 64))
    mutate('counterfeit_selected_candidate', lambda v: v['events'][4]['decision'].__setitem__('selected', True))
    mutate('counterfeit_certificate_verdict', lambda v: v['events'][4]['decision'].__setitem__('cooperative', True))
    mutate('source_object_replaced_at_pause', lambda v: v['events'][3]['runtime'].__setitem__('state_object_identity', 9000))
    mutate('pause_not_atomic_epoch', lambda v: v['events'][3]['runtime'].__setitem__('epoch', 0))
    mutate('replacement_uses_old_instance', lambda v: v['events'][8]['runtime']['controller'].__setitem__('instance_identity', 100))
    mutate('rank_overwrite_on_new_memory', lambda v: v['events'][8]['runtime']['controller'].__setitem__('rank', 2))
    mutate('changed_original_initial_flag', lambda v: v['events'][8]['runtime']['controller'].__setitem__('original_initial_flag', True))
    mutate('certificate_pin_swapped_in_admission', lambda v: v['events'][4]['certificates']['source'].__setitem__('sha256', 'f' * 64))
    mutate('wrong_continuation_ENV_policy', lambda v: v['events'][10]['offered_env'].__setitem__('c', 'true'))
    mutate('false_cycle_justice_claim', lambda v: v['events'][12]['SYS_justice_hits'].__setitem__(C.aux[0][0], False))
    mutate('result_selected_candidate_differs', lambda v: v['episode_result'].__setitem__('selected_candidate', 'fresh_preference'))
    mutate('result_prefix_count_differs', lambda v: v['episode_result'].__setitem__('prefix_committed_steps', 0))
    mutate('retained_old_instance_replaced', lambda v: v['events'][8]['runtime']['controller'].__setitem__('instance_identity', 222), strict)
    mutate('abstention_cannot_resume_without_installation', lambda v: v['events'][-1]['runtime'].__setitem__('paused', False), abstain)
    # Serialize only fixture data; graph edge sets become arrays for independent readers.
    serial = copy.deepcopy(coop)
    for graph in serial['graphs'].values(): graph['edges'] = sorted(graph['edges'])
    save_new(directory / 'synthetic_episode.json', serial)
    report = {'schema': 'v47-source-event-auditor-synthetic-qualification-v1',
              'status': 'PASS' if all(t['pass'] for t in tests) else 'FAIL',
              'auditor': pin(Path(auditor.__file__)), 'qualification_script': pin(__file__),
              'synthetic_only': True, 'actual_runtime_or_cohort_read': False, 'runtime_imports': 0,
              'tests': tests, 'counts': {'total': len(tests), 'pass': sum(t['pass'] for t in tests)}}
    save_new(directory / 'RESULT.json', report)
    print(json.dumps({'status': report['status'], 'counts': report['counts'], 'result': pin(directory / 'RESULT.json')}))
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    if len(sys.argv) != 2: raise SystemExit('Usage: qualify_event_audit.py NEW_OUTPUT_DIRECTORY')
    raise SystemExit(main(sys.argv[1]))
