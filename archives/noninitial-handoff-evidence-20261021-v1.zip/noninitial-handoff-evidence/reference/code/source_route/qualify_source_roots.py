"""Synthetic-only qualification. Never reads an actual controller/cohort/plan.

Creates a fresh fixture directory and records every expected outcome. Exact source
pin checking is exercised using the already-known source digest and a deliberately
wrong synthetic source; no real experiment checker is invoked by this script.
"""
from pathlib import Path
import copy
import hashlib
import json
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import check_source_roots as checker
from independent_core import AuditError, pin, save_new, finite_fairness

C = checker.C


def synthetic_controller():
    """Serve floors 1/2 deterministically under b3=false; derive AUX from source."""
    states, keys, nodes, edges, queue = [], {}, [], [], []
    def add(s, initial=False):
        key = tuple(s[n] for n in C.names)
        if key not in keys:
            i = str(len(states)); keys[key] = i; states.append(dict(s)); queue.append(i)
            nodes.append({'id': i, 'native_id': int(i), 'initial': initial, 'rank': 0,
                          'rank_class': 'tau.smlab.syntech.games.gr1.GR1RankInfo', 'rank_info': 'System Justice 0',
                          'valuation': dict(s), 'bits': {str(j): (v in ('true', 'S1')) for j, v in enumerate(key)},
                          'successors': []})
        return keys[key]
    for cancel in ('false', 'true'):
        s = {n: 'false' for n in C.env + C.system}
        s.update({n: 'S0' for n, _ in C.aux}); s['f1'] = 'true'; s['c'] = cancel
        add(s, True)
    while queue:
        a = queue.pop(0); s = states[int(a)]
        for e in checker.ENV_INPUTS:
            if not checker.env_legal(s, e, True): continue
            if s['f1'] == 'true': floor = 'f2' if s['b2'] == 'true' else 'f1'
            else: floor = 'f1' if s['b1'] == 'true' else 'f2'
            t = dict(e); t.update({n: 'true' if n == floor else 'false' for n in C.system})
            for (monitor, _), b, f in zip(C.aux, ('b1', 'b2', 'b3'), ('f1', 'f2', 'f3')):
                pending = (s[monitor] == 'S1' or s[b] == 'true') and s[f] == 'false' and s['c'] == 'false'
                t[monitor] = 'S1' if pending else 'S0'
            assert C.rho_s(s, t)
            b = add(t); nodes[int(a)]['successors'].append(b); edges.append([a, b])
    return {'schema': 'synthetic-lift-controller-qualification-only', 'fixture_id': C.candidate,
            'complete': True, 'model_sha256': '0' * 64, 'rank_domain_size': 3,
            'api_state_count': len(nodes), 'api_transition_count': len(edges), 'nodes': nodes, 'edges': edges}


def main(directory):
    directory = Path(directory).resolve(); directory.mkdir(parents=True, exist_ok=False)
    rows = []
    def store(name, graph):
        path = directory / (name + '.json'); save_new(path, graph)
        return {**pin(path), 'model_sha256': graph['model_sha256']}
    def check(name, fn, predicate=lambda x: bool(x), reject=False):
        try:
            actual = fn()
            passed = not reject and predicate(actual)
            observed = actual if isinstance(actual, (bool, str, int, type(None))) else 'returned'
        except (AuditError, KeyError, TypeError, ValueError) as error:
            passed = reject; observed = type(error).__name__ + ': ' + str(error)
        rows.append({'name': name, 'expected': 'reject' if reject else 'specified predicate',
                     'pass': bool(passed), 'observed': observed})
    graph = synthetic_controller()
    ref = store('synthetic_complete_old_controller', graph)
    loaded = checker.load_graph(ref)
    roots, bindings = checker.initial_roots(loaded)
    check('valid_synthetic_old_gate_two_original_initials', lambda: checker.view(loaded, roots, True),
          lambda r: r['complete'] and r['strict'] and r['cooperative'] and r['source_coverage'])
    check('all_16_typed_inputs_examined_each_reached_state', lambda: checker.view(loaded, roots, True),
          lambda r: all(x['all_typed_ENV_inputs_examined'] == 16 for x in r['input_coverage']))
    check('wrong_unknown_root', lambda: checker.root_binding(loaded, '999999', 0), reject=True)
    check('wrong_actual_private_rank', lambda: checker.root_binding(loaded, roots[0], 1), reject=True)
    state = copy.deepcopy(loaded['states'][roots[0]]); state['b1'] = 'true'
    check('wrong_root_source_state', lambda: checker.root_binding(loaded, roots[0], 0, state), reject=True)
    state = copy.deepcopy(loaded['states'][roots[0]]); state[C.aux[0][0]] = 'S1'
    check('wrong_root_AUX_state', lambda: checker.root_binding(loaded, roots[0], 0, state), reject=True)
    missing_state = dict(loaded['states'][roots[0]]); del missing_state[C.aux[2][0]]
    check('missing_source_AUX_field', lambda: checker.source_state(missing_state), reject=True)
    wrong_source_path = directory / 'wrong_source.spectra'; wrong_source_path.write_text('module Wrong\n')
    check('wrong_pinned_source_even_with_self_consistent_hash', lambda: checker.validate_source(pin(wrong_source_path)), reject=True)
    # Manifest-only fixtures exercise the newly required roster and exact append binding.
    roster_path = directory / 'synthetic_roster.json'
    fake_boundaries = [{'id': 'synthetic_' + str(i)} for i in range(10)]
    save_new(roster_path, {'schema': 'v47-noninitial-handoff-roster-v1', 'boundaries': fake_boundaries,
                           'source_fields': list(C.names), 'boundary_count': 10})
    old_source_path = directory / 'synthetic_old_source.spectra'
    old_source_path.write_bytes(wrong_source_path.read_bytes() + checker.OLD_SOURCE_APPEND)
    manifest = {'roster': pin(roster_path), 'boundaries': fake_boundaries,
                'source': pin(wrong_source_path), 'old_source': pin(old_source_path)}
    check('roster_and_append_binding_only_positive', lambda: checker.validate_source_roster_and_old(manifest),
          lambda r: r['exact_old_source_append'])
    mismatch = copy.deepcopy(manifest); mismatch['boundaries'][0]['id'] = 'altered'
    check('roster_inline_mismatch', lambda: checker.validate_source_roster_and_old(mismatch), reject=True)
    wrong_old = directory / 'wrong_old_append.spectra'
    wrong_old.write_bytes(wrong_source_path.read_bytes() + checker.OLD_SOURCE_APPEND.replace(b'b3', b'b2'))
    mismatch = copy.deepcopy(manifest); mismatch['old_source'] = pin(wrong_old)
    check('old_source_append_changed_to_b2', lambda: checker.validate_source_roster_and_old(mismatch), reject=True)
    other = dict(ref); other['sha256'] = 'e' * 64
    check('nested_conflicting_provenance_pin', lambda: checker.manifest_pins({'a': ref, 'b': [other]}), reject=True)
    check('nested_model_printer_predicate_pins_collected',
          lambda: checker.manifest_pins({'graph': {**ref, 'model': pin(roster_path), 'predicates': [pin(wrong_old)]}}),
          lambda r: len(r) == 3)
    valid_mode = {'old_mode': {'disabled_ENV': 'b3', 'current_value': 'false', 'next_value': 'false',
                               'source_initializers_preserved': True}}
    check('correct_restriction', lambda: checker.validate_mode(valid_mode), lambda r: r is None)
    for key, value in [('disabled_ENV', 'b2'), ('current_value', 'true'), ('next_value', 'true'),
                       ('source_initializers_preserved', False)]:
        mode = copy.deepcopy(valid_mode); mode['old_mode'][key] = value
        check('wrong_restriction_' + key, lambda mode=mode: checker.validate_mode(mode), reject=True)
    bad_ref = dict(ref); bad_ref['sha256'] = 'f' * 64
    check('altered_graph_digest', lambda: checker.load_graph(bad_ref), reject=True)
    bad_ref = dict(ref); bad_ref['model_sha256'] = 'f' * 64
    check('wrong_model_digest_binding', lambda: checker.load_graph(bad_ref), reject=True)
    missing = copy.deepcopy(graph)
    a, b = missing['edges'].pop(0); missing['nodes'][int(a)]['successors'].remove(b)
    missing['api_transition_count'] -= 1
    missing_loaded = checker.load_graph(store('missing_legal_response', missing))
    check('missing_legal_response_not_complete_not_cooperative', lambda: checker.view(missing_loaded, roots, True),
          lambda r: not r['complete'] and not r['source_coverage'] and r['strict'] is None and r['cooperative'] is None)
    bad_edge = copy.deepcopy(graph); bad_edge['edges'][0][1] = '999999'
    check('bad_edge_endpoint', lambda: checker.load_graph(store('bad_edge_endpoint', bad_edge)), reject=True)
    bad_successors = copy.deepcopy(graph); bad_successors['nodes'][0]['successors'].pop()
    check('edge_successor_disagreement', lambda: checker.load_graph(store('bad_successors', bad_successors)), reject=True)
    bad_rank = copy.deepcopy(graph); bad_rank['nodes'][0]['rank'] = 1
    check('rank_metadata_disagreement', lambda: checker.load_graph(store('bad_rank_metadata', bad_rank)), reject=True)
    bad_initial = copy.deepcopy(graph); bad_initial['nodes'][0]['initial'] = False
    check('original_initial_flags_preserved', lambda: checker.initial_roots(checker.load_graph(store('bad_initial', bad_initial))), reject=True)
    # Inject a safety-invalid AUX successor while retaining its exact offered ENV input.
    bad_aux = copy.deepcopy(graph); a, b = bad_aux['edges'][0]; new = copy.deepcopy(bad_aux['nodes'][int(b)])
    new_id = str(len(bad_aux['nodes'])); new.update(id=new_id, native_id=int(new_id), initial=False)
    n = C.aux[0][0]; new['valuation'][n] = 'S1' if new['valuation'][n] == 'S0' else 'S0'
    new['bits'][str(list(C.names).index(n))] = new['valuation'][n] == 'S1'
    bad_aux['nodes'].append(new); bad_aux['edges'][0] = [a, new_id]
    bad_aux['nodes'][int(a)]['successors'][0] = new_id
    bad_aux['edges'].extend([[new_id, t] for t in new['successors']])
    bad_aux['api_state_count'] = len(bad_aux['nodes']); bad_aux['api_transition_count'] = len(bad_aux['edges'])
    check('bad_source_AUX_update_edge', lambda: checker.view(checker.load_graph(store('bad_aux_edge', bad_aux)), roots, True),
          lambda r: r['complete'] and not r['source_safety'] and r['strict'] is False and r['cooperative'] is None)
    # A legal SYS move may create a non-one-hot floor, whose ENV current invariant then blocks all moves.
    dead = copy.deepcopy(graph)
    edge_index = next(i for i, (a, b) in enumerate(dead['edges'])
                      if dead['nodes'][int(a)]['valuation']['f1'] == 'true'
                      and dead['nodes'][int(a)]['valuation']['b2'] == 'true'
                      and dead['nodes'][int(b)]['valuation']['f2'] == 'true')
    a, b = dead['edges'][edge_index]; new = copy.deepcopy(dead['nodes'][int(b)])
    new_id = str(len(dead['nodes'])); new.update(id=new_id, native_id=int(new_id), initial=False, successors=[])
    new['valuation']['f1'] = 'true'; new['bits'][str(list(C.names).index('f1'))] = True
    dead['nodes'].append(new); dead['edges'][edge_index] = [a, new_id]
    ix = dead['nodes'][int(a)]['successors'].index(b); dead['nodes'][int(a)]['successors'][ix] = new_id
    dead['api_state_count'] += 1
    check('complete_strict_but_noncooperative_old_gate', lambda: checker.view(checker.load_graph(store('synthetic_deadend', dead)), roots, True),
          lambda r: r['complete'] and r['strict'] is True and r['cooperative'] is False)
    # Candidate admission must reject a false gate even when the envelope claims adoption.
    plan_path = directory / 'synthetic_gate_plan.json'; save_new(plan_path, {'qualification': True})
    plan_pin = pin(plan_path)
    gate_path = directory / 'synthetic_false_gate.json'
    save_new(gate_path, {'status': 'COMPLETE_OLD_GATE', 'route': 'source', 'plan': plan_pin,
                        'old_gate': {'complete': True, 'strict': True, 'cooperative': False, 'source_coverage': True}})
    adoption_path = directory / 'synthetic_false_gate_adoption.json'
    save_new(adoption_path, {'status': 'ADOPTED_BOTH_OLD_GATE_CERTIFICATES', 'plan': plan_pin, 'source': pin(gate_path)})
    gate_plan = {'old_gate_adoption_path': str(adoption_path), 'old_gate_source_result_path': str(gate_path)}
    check('false_old_gate_rejected_before_candidate_audit', lambda: checker.validate_old_adoption(gate_plan, plan_pin), reject=True)
    check('finite_fairness_cycle_without_system_justice', lambda: finite_fairness({'0'}, {('0', '0')}, ['0'], [], [set()]),
          lambda r: not r['strict_liveness']['pass'] and r['nonconflicting']['pass'])
    check('finite_fairness_deadend_is_not_infinite_continuation', lambda: finite_fairness({'0'}, set(), ['0'], [], [{'0'}]),
          lambda r: r['strict_liveness']['pass'] and not r['nonconflicting']['pass'])
    report = {'schema': 'v47-source-route-synthetic-qualification-v1',
              'status': 'PASS' if all(r['pass'] for r in rows) else 'FAIL',
              'synthetic_only': True, 'actual_controller_or_cohort_read': False,
              'actual_semantic_audits': 0, 'native_calls': 0, 'compiler_calls': 0,
              'checker': pin(Path(checker.__file__)), 'tests': rows,
              'counts': {'total': len(rows), 'pass': sum(r['pass'] for r in rows)},
              'positive_fixture': ref, 'fixture_generation': 'New source-equation-derived synthetic floor1/floor2 policy graph; no actual graph loaded.',
              'inputs_unchanged': pin(ref['path'])['sha256'] == ref['sha256']}
    save_new(directory / 'RESULT.json', report)
    print(json.dumps({'status': report['status'], 'counts': report['counts'], 'result': pin(directory / 'RESULT.json')}))
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    if len(sys.argv) != 2: raise SystemExit('Usage: qualify_source_roots.py NEW_OUTPUT_DIRECTORY')
    raise SystemExit(main(sys.argv[1]))
