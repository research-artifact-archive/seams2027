"""Read-only outer reconciliation followed by one exclusive adoption record."""
from pathlib import Path
import collections
import datetime as dt
import hashlib
import json

B = Path(__file__).resolve().parents[2]
verified = {}


def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def check_pins(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            actual = pin(value['path'])
            assert all(actual[k] == value[k] for k in actual), value['path']
            verified[value['path']] = actual
        for child in value.values():
            check_pins(child)
    elif isinstance(value, list):
        for child in value:
            check_pins(child)


def read(name):
    value = json.loads((B / name).read_text())
    check_pins(value)
    return value


def time(value):
    return dt.datetime.fromisoformat(value.replace('Z', '+00:00'))


plan = read('EXPERIMENT_PLAN.json')
protected = read('V46_PROTECTED_INPUTS.json')
old = read('ROOT_OLD_GATE_ADOPTION.json')
roots = read('ROOT_CANDIDATE_CERTIFICATES_ADOPTION.json')
audit = read('execution/INDEPENDENT_EVENT_AUDIT.json')
runtime = read('execution/runtime_01/RESULT.json')
assert old['status'] == 'ADOPTED_BOTH_OLD_GATE_CERTIFICATES'
assert roots['status'] == 'ADOPTED_MATCHING_COMPLETE_40_ROOT_CERTIFICATES'
assert audit['status'] == 'PASS_ALL_20_EXECUTED_EPISODES'
assert runtime['status'] == 'COMPLETE_EXECUTED_HANDOFF_CENSUS'
assert len(audit['episodes']) == len(runtime['episodes']) == 20
assert not runtime['errors'] and runtime['input_integrity'] == 'PASS'
assert all(e['pass'] and e['nonzero_monitors_preserved_at_install'] and
           not e['boundary_source_initializer_compatible'] for e in audit['episodes'])
processes = []
children = {}
expected = {'old_gate_source_01', 'old_gate_saved_model_01',
            'candidate_roots_source_01', 'candidate_roots_saved_model_01',
            'runtime_01', 'event_audit_01'}
assert {p.name for p in (B / 'processes').iterdir()} == expected
for name in sorted(expected):
    prefix = 'processes/' + name + '/'
    receipt = read(prefix + 'RECEIPT.json')
    request = read(prefix + 'REQUEST.json')
    child = read(prefix + 'CHILD.json')
    assert receipt['status'] == 'PROCESS_COMPLETED' and receipt['exit_code'] == 0
    assert receipt['child_reaped'] and receipt['owned_process_group_absent']
    assert not receipt['timeout'] and not receipt['sampled_RSS_limit_exceeded']
    assert not receipt['error'] and not receipt['input_mismatches']
    assert child['command'] == request['argv']
    assert child['pid'] == child['process_group']
    assert request['plan'] == pin(B / 'EXPERIMENT_PLAN.json')
    assert time(child['started_utc']) < time(receipt['finished_utc']) <= time(request['deadline_utc'])
    processes.append({'invocation': name, 'receipt': pin(B / prefix / 'RECEIPT.json'),
                      'request': pin(B / prefix / 'REQUEST.json'),
                      'child': pin(B / prefix / 'CHILD.json'),
                      'status': receipt['status'], 'elapsed_seconds': receipt['elapsed_seconds']})
    children[name] = child
events = [json.loads(line) for line in (B / 'execution/runtime_01/EVENTS.jsonl').read_text().splitlines()]
assert len(events) == runtime['event_count'] == audit['event_count'] == 302
assert [e['seq'] for e in events] == list(range(len(events)))
assert {e['pid'] for e in events} == {children['runtime_01']['pid']}
assert all(events[i]['monotonic_ns'] <= events[i + 1]['monotonic_ns'] for i in range(len(events) - 1))
assert time(children['runtime_01']['started_utc']) <= time(runtime['started_utc'])
assert time(runtime['started_utc']) <= time(events[0]['utc']) <= time(events[-1]['utc']) <= time(runtime['finished_utc'])
rr = read('processes/runtime_01/RECEIPT.json')
assert time(runtime['finished_utc']) <= time(rr['finished_utc'])
steps = [e for e in events if e['event'] == 'step_committed']
post = [e for e in steps if e['runtime']['contract_mode'] != 'old_no_b3']
assert len(steps) == 100 and len(post) == 44
assert all(e['offered_env']['b3'] == 'false' for e in post)
assert sum(e['prefix_steps'] for e in audit['episodes']) == 56
assert sum(e['continuation_steps'] for e in audit['episodes']) == 44
for a, r in zip(audit['episodes'], runtime['episodes']):
    assert a['episode_id'] == r['episode_id']
    assert a['selected_candidate'] == r['selected_candidate']
    assert a['outcome'] == 'EXECUTED_FAIR_LASSO'
    assert a['selected_candidate'] == ('retain_old_native' if r['policy'] == 'strict_only' else 'fresh_normalized')
assert roots['root_review']['all10_K_memberships']
result = {
    'schema': 'v47-scientific-adoption-v1',
    'status': 'ADOPTED_LIMITED_EXECUTED_NONINITIAL_HANDOFF_EVIDENCE',
    'created_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'plan': pin(B / 'EXPERIMENT_PLAN.json'),
    'selection': pin(B / 'RESEARCH_SELECTION.json'),
    'old_gate_adoption': pin(B / 'ROOT_OLD_GATE_ADOPTION.json'),
    'candidate_adoption': pin(B / 'ROOT_CANDIDATE_CERTIFICATES_ADOPTION.json'),
    'runtime_result': pin(B / 'execution/runtime_01/RESULT.json'),
    'event_audit': pin(B / 'execution/INDEPENDENT_EVENT_AUDIT.json'),
    'processes': processes,
    'root_reading': 'All 40 compact semantic candidate rows and all 20 independently audited executed-episode rows were read. Complete graph coverage/vertex/edge records were reconciled mechanically before runtime adoption. Final runtime/auditor implementations and independent static reviews were read before their single actual executions.',
    'outer_checks': {'distinct_pinned_files_verified': len(verified),
                     'process_count': 6, 'actual_runtime_invocations': 1,
                     'actual_event_audit_invocations': 1, 'event_PID_matches_owned_child': True,
                     'event_sequence_and_monotonic_clock': True, 'runtime_UTC_within_process_receipts': True,
                     'all_children_reaped_and_groups_absent': True,
                     'v46_protected_file_pins_verified': len(protected['files'])},
    'observations': {'boundary_private_nodes': 10, 'distinct_source_history_states': 8,
                     'candidate_roots_per_independent_checker': 40,
                     'all_boundaries_in_original_K': True,
                     'old_complete_graph_nodes': 26, 'old_complete_graph_edges': 120,
                     'old_strict_and_cooperative': True,
                     'complete_rooted_graph_results': roots['observed_summary'],
                     'executed_episodes': 20, 'decisions_changed_by_cooperation_filter': 10,
                     'strict_only_retains_old': 10, 'strict_and_cooperative_installs_normalized': 10,
                     'executed_old_prefix_commits': 56, 'executed_post_change_commits': 44,
                     'all_executed_suffixes_fair_lassos': True, 'post_change_b3_true_inputs': 0,
                     'source_and_nonzero_logical_history_preserved': True},
    'interpretation': 'On this constructed same-Lift handoff census, cooperation changes admission at every declared noninitial boundary while the executed source object and ten source/history values are preserved. The universal rooted graph certificates, not a failure observed on the bounded trace, reject retained/native candidates for cooperation.',
    'limits': [
        'All three single-button restrictions were statically inspected before selecting G !b3; selection is outcome-informed, not held out.',
        'The old contract is constructed by adding G !b3 to the same Lift source. This is one model with ten old private nodes/eight source-history valuations, not ten independent applications.',
        'The nonzero response monitors have their response predicates already true at the boundary and clear on the next update. No unserved pending request is carried past the boundary.',
        'Every executed suffix is a fair lasso under the fixed lexicographic input policy, which never chooses b3=true. No measured failure avoidance or behavioral activation by b3=true is established.',
        'Normalized extraction precedes the preference candidate in the frozen pool and is selected in all ten cooperative-policy episodes; preference is eligible but never installed. Necessity of the preference extractor is not supported.',
        'Fresh targets use their actually stored rank-zero private nodes. Source/history continuity does not establish arbitrary transfer of old private controller memory.',
        'The original 11 replacement, 14-pair negative, and 59-case diagnostic cohorts, and the v46 Elevator residual census remain separate and unchanged.',
        'No new native/compiler execution occurred. Public delivery requires a separately audited static snapshot and must not claim the older replay entrypoint executes these new runs.',
        'RSS bounds are sampled process checks, not an operating-system address-space cap; recorded elapsed time is not an end-to-end performance claim.'
    ],
    'frozen_baseline': pin(B / 'V46_PROTECTED_INPUTS.json'),
    'integration_authorized_by_existing_user_scope': True,
    'scientific_reruns_or_further_tuning_authorized': False,
    'full_reset_uses': 0, 'conference_submission': False,
    'adoption_script': pin(Path(__file__).resolve())}
with (B / 'SCIENTIFIC_ADOPTION.json').open('x') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps(pin(B / 'SCIENTIFIC_ADOPTION.json')))
