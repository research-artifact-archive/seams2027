from pathlib import Path
import json,hashlib,shutil,datetime
R=Path.cwd(); B=R/'experiment/v47_bounded_improvement_20261021'; I=B/'inputs'
def pin(p):
 p=Path(p).resolve();return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,d):
 assert not p.exists(),p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def copy(p,t):
 t.parent.mkdir(parents=True,exist_ok=True);assert not t.exists();shutil.copyfile(p,t);return pin(t)
source=copy(R/'experiment/seams_research_reframing_20261018/runtime_closure_01/sources/lift__trivial_1.spectra',I/'lift_new.spectra')
old=I/'lift_old_no_b3.spectra';old.write_bytes(Path(source['path']).read_bytes()+b'\n\nassumption -- constructed_old_mode_no_b3\n\talw(b3=false);\n')
graphs={}; origins=[]
origdirs={'native':R/'experiment/lift_t_causal_diagnosis_20261021/adaptation_episode_04/native_pair_01/lift__trivial_1/native','preference':R/'experiment/lift_t_causal_diagnosis_20261021/adaptation_episode_04/native_pair_01/lift__trivial_1/variant','normalized':R/'experiment/normalized_eleven_execution_20261021/runs/lift__trivial_1/normalized_kind'}
for name,origin in origdirs.items():
 dest=I/name; graphs[name]=copy(origin/'controller.json',dest/'controller.json'); graphs[name]['model']=copy(origin/'model.json',dest/'model.json'); graphs[name]['result']=copy(origin/'result.json',dest/'result.json');graphs[name]['printer']=copy(origin/'controller.txt',dest/'controller.txt') if name!='normalized' else None
 m=json.loads((origin/'model.json').read_text());refs=[]
 def walk(x):
  if isinstance(x,dict):
   if 'file' in x and 'sha256'in x:refs.append(x)
   for v in x.values():walk(v)
  elif isinstance(x,list):
   for v in x:walk(v)
 walk(m);seen=set();pred=[]
 for ref in refs:
  if ref['file'] in seen:continue
  seen.add(ref['file']);p=origin/ref['file'];actual=pin(p);assert actual['sha256']==ref['sha256'] and actual['bytes']==ref['bytes'];pred.append(copy(p,dest/ref['file']))
 graphs[name]['model_predicates']=pred;graphs[name]['model_sha256']=graphs[name]['model']['sha256'];graphs[name]['source_correspondence']=[]
 for fn in ['controller.json','model.json','result.json']+(['controller.txt'] if name!='normalized' else [])+list(seen):origins.append({'origin':pin(origin/fn),'staged':pin(dest/fn)})
source_names=['b1','b2','b3','c','f1','f2','f3']+[f'SYS_CONSTRAINT.{i}.pRespondsToS.state' for i in range(3)]
ng={k:{n['id']:n for n in json.loads(Path(v['path']).read_text())['nodes']} for k,v in graphs.items()}
rows=json.loads((B/'N3_PREFLIGHT_SCOPE_ADDENDUM.json').read_text())['entire_frozen_advisory_roster'];boundaries=[]
for i,r in enumerate(rows):
 v={n:ng['native'][r['old_node']]['valuation'][n] for n in source_names};nr=[n for n in ng['native'].values() if n['rank']==0 and n['valuation'].get('~envHelp')=='false' and {k:n['valuation'][k] for k in source_names}==v];assert len(nr)==1
 candidates=[dict(candidate='retain_old_native',graph='native',root=r['old_node'],rank=r['old_rank']),dict(candidate='fresh_native',graph='native',root=nr[0]['id'],rank=0),dict(candidate='fresh_normalized',graph='normalized',root=r['normalized_rank0_node'],rank=0),dict(candidate='fresh_preference',graph='preference',root=r['variant_rank0_node'],rank=0)]
 for c in candidates:
  node=ng[c['graph']][c['root']];assert node['rank']==c['rank'];assert {k:node['valuation'][k] for k in source_names}==v
 boundaries.append(dict(id=f'boundary_{i+1:02d}',source_state=v,reached_native_node=r['old_node'],reached_rank=r['old_rank'],prefix_node_ids=r['prefix'],candidates=candidates))
roster={'schema':'v47-noninitial-handoff-roster-v1','selection':pin(B/'RESEARCH_SELECTION.json'),'scope_addendum':pin(B/'N3_PREFLIGHT_SCOPE_ADDENDUM.json'),'source_fields':source_names,'boundary_count':10,'distinct_source_valuations':8,'boundaries':boundaries,'selection_rule':'All helper=false native nodes reachable from native 0 under b3=false with any source response monitor S1; retain private rank distinctions. Prefixes and row order from pre-execution feasibility advisory.','monitor_limit':'All S1 monitors already have their corresponding floor response true at the boundary; next source update clears. No unanswered obligation continuing past the boundary is claimed.'}
save(B/'COHORT.json',roster)
manifest={'schema':'v47-staged-immutable-inputs-v1','source':source,'old_source':pin(old),'original_source':pin(R/'experiment/seams_research_reframing_20261018/runtime_closure_01/sources/lift__trivial_1.spectra'),'graphs':graphs,'copies':origins,'roster':pin(B/'COHORT.json')}
save(B/'INPUTS.json',manifest)
plan={'schema':'v47-noninitial-handoff-plan-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selection':pin(B/'RESEARCH_SELECTION.json'),'inputs':pin(B/'INPUTS.json'),'source':source,'old_source':pin(old),'graphs':graphs,'roster':pin(B/'COHORT.json'),'boundaries':boundaries,'old_mode':{'disabled_ENV':'b3','current_value':'false','next_value':'false','source_initializers_preserved':True},'old_start_node':'0','disabled_button':'b3','old_gate_adoption_path':str(B/'ROOT_OLD_GATE_ADOPTION.json'),'old_gate_source_result_path':str(B/'execution/old_gate_source.json'),'old_gate_saved_result_path':str(B/'execution/old_gate_saved_model.json'),'policies':['strict_only','strict_and_cooperative'],'candidate_order':['retain_old_native','fresh_native','fresh_normalized','fresh_preference'],'continuation_steps_per_episode':32,'environment_policy':'lexicographically smallest source-legal next ENV valuation in b1,b2,b3,c order, false before true; respect b3=false before removal','successor_policy':'first saved native successor for that ENV valuation and helper=false; no edge rewriting','old_gate_rule':'Both independent routes complete and strict=true,cooperative=true,source_coverage=true from every original initial node; any failure, unknown,disagreement stops this direction without retuning.','candidate_rule':'All40 roots certified independently under unchanged new Lift source; strict-only accepts strict=true and coverage=true; cooperative also requires cooperative=true; both routes must agree. Failure is a complete semantic outcome; incomplete check is UNKNOWN.','runtime_rule':'20 episodes =10boundaries times2policies. Each independently instantiates old native at0, executes all prefix step/commit operations, pauses, keeps exact10 source fields, removes only G!b3, admits first eligible arm, retains old object and rank or initializes a new private instance at actual saved rank0 root. Continue until first repeat/deadend/UNKNOWN or32steps.','graph_scope':'No synthesis, native extraction, compiler, rank overwrite, initializer reapplication, or arbitrary memory transport. Re-root immutable previously exported graphs.','process_bounds':{'checker_timeout_seconds':180,'runtime_timeout_seconds':120,'qualification_timeout_seconds':90,'max_child_processes_at_once':2,'max_per_process_address_space_bytes':2147483648,'single_scientific_attempt_per_stage':True,'timeout_status':'UNKNOWN_TIMEOUT','cleanup':'terminate exact launched process group only; TERM then KILL after2seconds; save receipts and hashes'},'preparation_checkpoint_utc':'2026-10-21T07:49:45+00:00','hard_stop_utc':'2026-10-21T09:49:45+00:00','research_hard_stop_utc':'2026-10-21T09:49:45+00:00','go_policy':'Code qualification, independent static review, root full code read and separate frozen GO required before real oldgate. Root oldgate adoption required before candidates. Runtime GO pins final dual certificates and independent runtime review.','all_results_preserved':True,'full_reset_uses':0}
save(B/'EXPERIMENT_PLAN.json',plan)
print(json.dumps({'plan':pin(B/'EXPERIMENT_PLAN.json'),'roster':pin(B/'COHORT.json'),'staged_files':len(origins),'graph_pins':{k:{x:v[x] for x in ['bytes','sha256']} for k,v in graphs.items()}},indent=2))
