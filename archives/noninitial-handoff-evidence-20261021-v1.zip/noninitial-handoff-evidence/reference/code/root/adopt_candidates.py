from pathlib import Path
import json,hashlib,datetime
B=Path(__file__).resolve().parents[2]
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def need(v,msg):
 if not v:raise ValueError(msg)
def save(p,d):
 with p.open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
pp=pin(B/'EXPERIMENT_PLAN.json');plan=json.loads(Path(pp['path']).read_text());paths={k:B/'execution'/('candidate_roots_'+k+'.json') for k in ['source','saved_model']};certs={k:json.loads(p.read_text()) for k,p in paths.items()};pins={k:pin(p) for k,p in paths.items()};rows=[]
for k,d in certs.items():
 need(d['plan']==pp and d['route']==k and d['status']=='COMPLETE_ROOTED_CANDIDATES' and len(d['boundaries'])==10,'Complete exact bundle')
 r=json.loads((B/'processes'/('candidate_roots_'+k+'_01')/'RECEIPT.json').read_text());need(r['status']=='PROCESS_COMPLETED' and r['exit_code']==0 and r['child_reaped'] and r['owned_process_group_absent'] and not r['input_mismatches'],'Process complete with no owned group')
km=certs['saved_model']['K_membership'];need(km['status']=='COMPLETE_MEMBERSHIP' and len(km['boundaries'])==10 and all(v is True for v in km['boundaries'].values()),'All ten exact original K memberships')
for planned,s,t in zip(plan['boundaries'],certs['source']['boundaries'],certs['saved_model']['boundaries']):
 for k in ['id','source_state','reached_native_node','reached_rank']:need(planned[k]==s[k]==t[k],'Boundary '+k)
 row={k:planned[k] for k in ['id','source_state','reached_native_node','reached_rank','prefix_node_ids']};row.update(K_membership=True,candidates=[])
 for a,c,d in zip(planned['candidates'],s['candidates'],t['candidates']):
  for k in ['candidate','root_id','rank','complete','strict','cooperative','source_coverage','source_safety']:need(c[k]==d[k],'Dual route '+k)
  need(c['candidate']==a['candidate'] and c['root_id']==a['root'] and c['rank']==a['rank'],'Planned root')
  need(c['graph_sha256']==d['graph_sha256']==plan['graphs'][a['graph']]['sha256'],'Graph identity')
  need(all(c[k] is True for k in ['complete','source_coverage','source_safety']),'Coverage and safety complete')
  need(c['source_initializer_compatible'] is False and c['original_initial_marker'] is False and d['root_original_initial_flag'] is False,'Noninitial binding')
  need(c['reachable_nodes']==d['reachable_nodes'] and c['reachable_state_count']==d['reachable_node_count'] and c['reachable_edge_count']==d['edge_count'],'Reachable graph')
  eh=digest(sorted(d['graph']['edges']));need(c['derived_edges_sha256']==eh,'Entire edge set identity')
  need(set(c['fairness']['nonconflicting']['failing_states'])==set(d['fairness']['nonconflicting']['failing_states']),'Bad states')
  need(sum(v['legal_count'] for v in c['input_coverage'])==d['legal_input_count'] and all(v['pass'] and not v['missing'] and not v['multiple_responses'] for v in c['input_coverage']),'All input rows')
  row['candidates'].append({**{k:c[k] for k in ['candidate','root_id','rank','strict','cooperative','complete','source_coverage','source_safety']},'original_initial_marker':False,'source_initializer_compatible':False,'reachable_nodes':c['reachable_state_count'],'reachable_edges':c['reachable_edge_count'],'derived_edges_sha256':eh,'noncooperative_private_nodes':d['fairness']['nonconflicting']['failing_states'],'first_failing_prefix':d['fairness']['nonconflicting']['first_failing_prefix']})
 rows.append(row)
rv=B/'RUNTIME_INDEPENDENT_STATIC_REVIEW.json';review=json.loads(rv.read_text());need(review['status'].startswith('PASS') and review['plan']==pp and not review['blocking_findings'],'Independent review')
need(review['runtime_script']==pin(Path(review['runtime_script']['path'])),'Runtime code')
qual=json.loads(Path(review['qualification']['path']).read_text());need(qual['status']=='PASS_SYNTHETIC_RUNTIME_QUALIFICATION','Runtime qualification')
for ref in review['checked_pins']:
 need(all(ref[k]==pin(Path(ref['path']))[k] for k in ['bytes','sha256']),'Review input pin')
report={'schema':'v47-root-candidate-certificate-adoption-v1','status':'ADOPTED_MATCHING_COMPLETE_40_ROOT_CERTIFICATES','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'plan':pp,'certificates':pins,'old_gate_adoption':pin(B/'ROOT_OLD_GATE_ADOPTION.json'),'adoption_script':pin(Path(__file__).resolve()),'root_review':{'all40_compact_semantic_rows_read':True,'full_graph_edges_reconciled_by_digest':40,'all_coverage_rows_and_reachable_sets_reconciled':True,'all10_K_memberships':True,'all40_roots_original_initializer_incompatible':True,'runtime_full_code_and_final_changes_read':True,'runtime_synthetic_37_cases_report_status':qual['status'],'independent_runtime_review_read_and_pins_verified':True},'runtime_review':pin(rv),'boundaries':rows,'observed_summary':{'old_mode':{'nodes':26,'edges':120,'strict':True,'cooperative':True},'retained_old':{'roots':10,'strict':10,'cooperative':0},'fresh_native':{'roots':10,'strict':10,'cooperative':0},'fresh_normalized':{'roots':10,'strict':10,'cooperative':10},'fresh_preference':{'roots':10,'strict':10,'cooperative':10}},'runtime_expectation_not_observation':'Fixed order will retainold understrict_only and choosefresh_normalized understrict_and_cooperative. Actualstep/commit andinstallation remainpending. No executed failure or b3=true activation inferred.','preflight_note':'Earlier root adoption draft stopped beforewriting because it expected generic PASS instead of exact PASS_SYNTHETIC_RUNTIME_QUALIFICATION; code nowchecks exact declared successful status. No checker or runtime rerun occurred.','full_reset_uses':0}
ad=B/'ROOT_CANDIDATE_CERTIFICATES_ADOPTION.json';save(ad,report)
go={'schema':'v47-exact-frozen-process-GO-v1','status':'GO_EXACT_FROZEN_HANDOFF_RUNTIME','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'plan':pp,'launcher':pin(B/'code/root/launch_bounded.py'),'runtime_script':pin(B/'code/runtime/run_handoff.py'),'independent_runtime_review':pin(rv),'root_candidate_adoption':pin(ad),'certificates':pins,'independent_launcher_review':pin(B/'INDEPENDENT_SOURCE_AND_LAUNCHER_STATIC_REVIEW.json'),'runtime_qualification':review['qualification'],'deadline_utc':'2026-10-21T07:45:00+00:00','runtime_deadline_utc':'2026-10-21T07:45:00+00:00','attempt_policy':'Exactly one actual20episodecensus. No rerun or policy change afteroutcomes. Singlechild; all failures/UNKNOWN retained. Independent eventaudit beforeadoption.','full_reset_uses':0,'invocations':{}}
gp=B/'ROOT_RUNTIME_GO.json';out=B/'execution/runtime_01';go['invocations']['runtime_01']={'kind':'runtime','script':go['runtime_script'],'arguments':[pp['path'],str(gp),str(out)],'output_target':str(out),'timeout_seconds':120};save(gp,go);print(json.dumps({'go':pin(gp),'adoption':pin(ad)}))
