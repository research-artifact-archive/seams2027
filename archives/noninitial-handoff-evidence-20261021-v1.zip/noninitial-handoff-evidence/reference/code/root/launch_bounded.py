"""Launch exactly one frozen Python invocation with exclusive evidence receipts.

CLI: python3 -I -S -B launch_bounded.py PLAN ROOT_GO INVOCATION RECEIPT_DIRECTORY
No synthesis or shell. Process ownership comes from our Popen handle/session.
"""
from pathlib import Path
import datetime
import hashlib
import json
import os
import resource
import signal
import subprocess
import sys
import time


def need(value, reason):
    if not value:
        raise ValueError(reason)


def pin(path):
    path = Path(path)
    need(path.is_absolute() and path.is_file() and not path.is_symlink(), 'Regular absolute input required')
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read(ref):
    actual = pin(ref['path'])
    need(all(ref[k] == actual[k] for k in ('bytes', 'sha256')), 'Pinned input changed')
    return Path(ref['path']).read_bytes()


def walk_pins(value, collected):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= set(value):
            read(value)
            collected[value['path']] = {k: value[k] for k in ('path', 'bytes', 'sha256')}
        for child in value.values():
            walk_pins(child, collected)
    elif isinstance(value, list):
        for child in value:
            walk_pins(child, collected)


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def utc(value):
    value = datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))
    need(value.tzinfo is not None, 'Naive deadline')
    return value


def group_exists(group):
    # macOS may report EPERM rather than ESRCH for killpg(group, 0) after
    # termination. Inspect only numeric IDs/state, without process arguments.
    result = subprocess.run(['/bin/ps', '-axo', 'pid=,pgid=,stat='], capture_output=True,
                            timeout=2, check=True)
    return any(len(row.split()) == 3 and int(row.split()[1]) == group
               for row in result.stdout.splitlines())


def main():
    need(len(sys.argv) == 5, 'Expected PLAN ROOT_GO INVOCATION RECEIPT_DIRECTORY')
    plan_path, go_path = [Path(p).resolve() for p in sys.argv[1:3]]
    key, directory = sys.argv[3], Path(sys.argv[4]).resolve()
    plan_ref, go_ref = pin(plan_path), pin(go_path)
    plan, go = [json.loads(read(ref)) for ref in (plan_ref, go_ref)]
    need(go.get('status') in ('GO_EXACT_FROZEN_OLD_GATE', 'GO_EXACT_FROZEN_ROOTED_CANDIDATES',
                              'GO_EXACT_FROZEN_HANDOFF_RUNTIME', 'GO_SYNTHETIC_LAUNCHER_QUALIFICATION'), 'No exact GO')
    need(go.get('plan') == plan_ref, 'GO does not bind this exact plan')
    need(go.get('launcher') == pin(Path(__file__).resolve()), 'GO does not bind this launcher')
    need(key in go['invocations'], 'Invocation not authorized')
    specification = go['invocations'][key]
    need(specification['kind'] in ('checker', 'runtime', 'qualification'), 'Unexpected process kind')
    maximum = plan['process_bounds'][specification['kind'] + '_timeout_seconds']
    timeout = specification['timeout_seconds']
    need(type(timeout) is int and 0 < timeout <= maximum, 'Timeout outside frozen bound')
    deadline = min(utc(plan['hard_stop_utc']), utc(go['deadline_utc']))
    remaining = (deadline - datetime.datetime.now(datetime.timezone.utc)).total_seconds()
    need(remaining > 0, 'Deadline has passed')
    timeout = min(timeout, remaining)
    bound = {}
    walk_pins(plan, bound)
    walk_pins(go, bound)
    bound[str(plan_path)] = plan_ref
    bound[str(go_path)] = go_ref
    script = specification['script']
    need(Path(script['path']).suffix == '.py', 'Only pinned Python scripts supported')
    arguments = specification['arguments']
    need(isinstance(arguments, list) and all(type(x) is str for x in arguments), 'Malformed argument vector')
    need(not directory.exists() and directory.parent.is_dir(), 'Receipt directory must be new')
    output_target = Path(specification['output_target'])
    need(output_target.is_absolute() and not output_target.exists(), 'Scientific output already exists')
    directory.mkdir()
    request = {'schema': 'v47-bounded-process-request-v1', 'plan': plan_ref, 'go': go_ref,
               'invocation': key, 'argv': [sys.executable, '-I', '-S', '-B', script['path'], *arguments],
               'timeout_seconds': timeout, 'deadline_utc': deadline.isoformat(),
               'input_pins': list(bound.values()), 'sampled_RSS_limit': plan['process_bounds']['max_per_process_sampled_rss_bytes'],
               'memory_enforcement': 'Exact child PID RSS sampled with0.5s maximum waits plus bounded ps overhead(up to1s); not an OS address-space cap.'}
    save(directory / 'REQUEST.json', request)
    memory_limit = request['sampled_RSS_limit']
    need(type(memory_limit) is int and 0 < memory_limit <= 2147483648, 'Memory bound')
    def set_limits():
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    start = time.monotonic()
    process = None
    timed_out = False
    memory_exceeded = False
    peak_rss = 0
    error = None
    cleanup = []
    group_absent = True
    with (directory / 'stdout.txt').open('xb') as out, (directory / 'stderr.txt').open('xb') as err:
        try:
            process = subprocess.Popen(request['argv'], stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                                       cwd=directory, start_new_session=True, preexec_fn=set_limits)
            save(directory / 'CHILD.json', {'pid': process.pid, 'process_group': process.pid,
                 'parent_pid': os.getpid(), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 'command': request['argv']})
            while process.poll() is None:
                left = timeout - (time.monotonic() - start)
                if left <= 0:
                    timed_out = True
                    break
                sample = subprocess.run(['/bin/ps', '-o', 'rss=', '-p', str(process.pid)],
                                        capture_output=True, timeout=min(1, left), check=False)
                if sample.returncode == 0 and sample.stdout.strip():
                    peak_rss = max(peak_rss, int(sample.stdout.strip()) * 1024)
                    if peak_rss > memory_limit:
                        memory_exceeded = True
                        break
                try:
                    process.wait(timeout=min(0.5, left))
                except subprocess.TimeoutExpired:
                    pass
        except BaseException as exc:
            error = type(exc).__name__ + ': ' + str(exc)
        finally:
            try:
                if process is not None:
                    for sig, grace in ((signal.SIGTERM, 2), (signal.SIGKILL, 2)):
                        if not group_exists(process.pid):
                            break
                        try:
                            os.killpg(process.pid, sig)
                            cleanup.append(signal.Signals(sig).name)
                        except ProcessLookupError:
                            break
                        except PermissionError:
                            process.poll()
                            if not group_exists(process.pid):
                                break
                            error = 'Cannot signal the owned process group'
                            break
                        until = time.monotonic() + grace
                        while group_exists(process.pid) and time.monotonic() < until:
                            process.poll()
                            time.sleep(0.02)
                    group_absent = not group_exists(process.pid)
                    try:
                        process.wait(timeout=0.1)
                    except subprocess.TimeoutExpired:
                        if error is None:
                            error = 'Launched child not reaped after bounded group cleanup'
                    except ChildProcessError:
                            pass
            except BaseException as exc:
                group_absent = False
                error = (error + '; ' if error else '') + 'Cleanup verification: ' + type(exc).__name__ + ': ' + str(exc)
                if process is not None and process.poll() is None:
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                        cleanup.append('SIGKILL_AFTER_CLEANUP_ERROR')
                        process.wait(timeout=2)
                    except BaseException as last:
                        error += '; Final cleanup: ' + type(last).__name__ + ': ' + str(last)
    unchanged = []
    for ref in bound.values():
        try:
            read(ref)
        except BaseException as exc:
            unchanged.append({'input': ref, 'error': str(exc)})
    receipt = {'schema': 'v47-bounded-process-receipt-v1', 'invocation': key,
               'status': 'UNKNOWN_TIMEOUT' if timed_out else 'UNKNOWN_MEMORY_BOUND' if memory_exceeded else 'UNKNOWN_LAUNCH_OR_INPUT' if error or unchanged or not group_absent
                         else 'PROCESS_COMPLETED' if process and process.returncode == 0 else 'PROCESS_NONZERO',
               'request': pin(directory / 'REQUEST.json'), 'exit_code': process.returncode if process else None,
               'elapsed_seconds': time.monotonic() - start, 'timeout': timed_out, 'error': error,
               'sampled_peak_rss_bytes': peak_rss, 'sampled_RSS_limit_exceeded': memory_exceeded,
               'cleanup_signals': cleanup, 'child_reaped': process is None or process.poll() is not None,
               'owned_process_group_absent': group_absent,
               'input_mismatches': unchanged, 'stdout': pin(directory / 'stdout.txt'), 'stderr': pin(directory / 'stderr.txt'),
               'scientific_output_exists': output_target.exists(),
               'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    save(directory / 'RECEIPT.json', receipt)
    print(json.dumps({'status': receipt['status'], 'receipt': pin(directory / 'RECEIPT.json')}))
    return 0 if receipt['status'] == 'PROCESS_COMPLETED' else 2


if __name__ == '__main__':
    raise SystemExit(main())
