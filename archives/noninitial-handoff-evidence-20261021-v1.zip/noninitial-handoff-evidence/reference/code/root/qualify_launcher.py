"""Exercise the launcher only on newly created synthetic child programs."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys


def pin(p):
    return {'path': str(p.resolve()), 'bytes': p.stat().st_size,
            'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}


def save(p, value):
    with p.open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')


def main():
    base = Path(sys.argv[1]).resolve()
    base.mkdir(parents=True, exist_ok=False)
    launcher = Path(__file__).resolve().parent / 'launch_bounded.py'
    deadline = (datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(seconds=80)).isoformat()
    plan = base / 'PLAN.json'
    save(plan, {'hard_stop_utc': deadline, 'process_bounds': {'qualification_timeout_seconds': 5,
          'max_per_process_sampled_rss_bytes': 2147483648}})
    child = base / 'child.py'
    child.write_text('from pathlib import Path\nimport sys,time\ntime.sleep(float(sys.argv[1]))\nPath(sys.argv[2]).write_text("SYNTHETIC_ONLY\\n")\n')
    results = []
    for name, delay, timeout in [('success', '0', 5), ('timeout', '20', 1), ('memory_cap', '20', 5), ('bad_digest', '0', 5), ('existing_output', '0', 5)]:
        current_plan = plan
        if name == 'memory_cap':
            current_plan = base / 'memory_PLAN.json'
            save(current_plan, {'hard_stop_utc': deadline, 'process_bounds': {'qualification_timeout_seconds': 5,
                 'max_per_process_sampled_rss_bytes': 1024}})
        target = base / (name + '.out')
        if name == 'existing_output':
            target.write_text('PRESERVE\n')
        ref = pin(child)
        if name == 'bad_digest':
            ref['sha256'] = '0' * 64
        go = base / (name + '_GO.json')
        save(go, {'status': 'GO_SYNTHETIC_LAUNCHER_QUALIFICATION', 'plan': pin(current_plan), 'launcher': pin(launcher),
             'deadline_utc': deadline, 'invocations': {name: {'kind': 'qualification', 'script': ref,
             'arguments': [delay, str(target)], 'timeout_seconds': timeout, 'output_target': str(target)}}})
        receipt_dir = base / (name + '_receipt')
        proc = subprocess.run([sys.executable, '-I', '-S', '-B', str(launcher), str(current_plan), str(go), name,
                               str(receipt_dir)], capture_output=True, timeout=15)
        (base / (name + '_stdout.txt')).write_bytes(proc.stdout)
        (base / (name + '_stderr.txt')).write_bytes(proc.stderr)
        report = json.loads((receipt_dir / 'RECEIPT.json').read_text()) if (receipt_dir / 'RECEIPT.json').exists() else None
        if name == 'success':
            passed = proc.returncode == 0 and report['status'] == 'PROCESS_COMPLETED' and target.read_text() == 'SYNTHETIC_ONLY\n'
        elif name == 'timeout':
            passed = proc.returncode == 2 and report['status'] == 'UNKNOWN_TIMEOUT' and report['child_reaped'] and not target.exists() and report['cleanup_signals'] == ['SIGTERM']
        elif name == 'memory_cap':
            passed = proc.returncode == 2 and report['status'] == 'UNKNOWN_MEMORY_BOUND' and report['child_reaped'] and not target.exists()
        elif name == 'bad_digest':
            passed = proc.returncode != 0 and not receipt_dir.exists() and not target.exists()
        else:
            passed = proc.returncode != 0 and not receipt_dir.exists() and target.read_text() == 'PRESERVE\n'
        results.append({'test': name, 'pass': passed, 'exit_code': proc.returncode,
                        'receipt': pin(receipt_dir / 'RECEIPT.json') if report else None})
    save(base / 'RESULT.json', {'schema': 'v47-launcher-synthetic-qualification-v1',
         'status': 'PASS' if all(r['pass'] for r in results) else 'FAIL', 'synthetic_only': True,
         'scientific_executions': 0, 'launcher': pin(launcher), 'tests': results})
    print((base / 'RESULT.json').read_text())


if __name__ == '__main__':
    main()
