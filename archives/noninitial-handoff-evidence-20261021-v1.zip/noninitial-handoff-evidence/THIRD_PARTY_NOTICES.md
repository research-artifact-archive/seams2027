# Third-party boundaries

The included LICENSE applies to original artifact contributions, including original checker/runtime/qualification source and original evidence records. It is not an aggregate license for external material.

The Lift specification used here is paper-derived. Unlike the separate Elevator residual census, this archive does not distribute a corpus-licensed specification. Both new and constructed old Lift source bytes, and derived specification files in synthetic fixtures, are omitted. SOURCE_RESTORATION_REFERENCE.json pins the unchanged fourth-archive recipe and the exact restored source identity, plus the original append operation defining the old mode. Readers retrieve source directly from the recorded distributor under its terms; retrieval grants no additional redistribution rights.

Saved models, graphs and BDD exports are retained as in the fourth scientific archive. No full upstream extractor source, Java distribution, JAR, native binary, compiled class, runtime, source cache or third-party paper PDF is included. The Python reference code is original artifact code; copying original local decoder/fairness helpers does not make the two checking routes share an implementation. This archive is an inspection snapshot, not a dependency bundle.
