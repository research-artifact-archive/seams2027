Vehicle188 native strict saved evidence

This package records one outcome-selected public source and one pre-existing
certified reached state, outside the census. On the unchanged source, two
completed native strict3FP calls used the full original and released
syntactic-helper arenas. Source cooperation (K) and initialized reachability
remain supported by separate, earlier source-policy certificates.

Recorded result:
  original: 33,792 typed states; full W=8,064; s in W; initializer true.
  released helper: 67,584 typed states; full W=40,448; (s,false) not in W;
                   initializer true.
The W counts concern different full carriers, including both helper values
for the released arm. No helper-false slice count is claimed here.

Both native initial judgments are true. This is a strict-backend observation,
not an initialized refusal, a selected Kind4FP/default/frontend result, a
cooperative-controller extraction, or a deployment/manager episode. It adds
native implementation evidence for the existing selected source/state; it
does not estimate prevalence or show a speed/scalability advantage.

Portable saved-evidence check (Python 3 standard library only):
  python3 -I -S -B replay.py --bundle . --out ../vehicle188-replay-result.json
The output path must be new and outside this immutable directory. Expected:
  PASS_SAVED_IDENTITY_MEMBERSHIP_INITIALIZATION
The command checks the complete file manifest, exact saved model/function
identity, the full fixed source state and helper=false counterpart, saved W
membership/counts, and forall-ENV exists-SYS initializer quantification. It
does not recompute a winning fixed point or run Java, a solver or a producer.
Historical complete-memory/process/class-origin checks remain recorded
evidence. See OMITTED_HISTORICAL_CHECKS.json for the exact boundary.

data/native/ contains native models, BDD node tables, W, query roots and
completion records. data/reference_models/ contains the corresponding earlier
saved arena models. records/ contains anonymized preregistration, frozen pins,
normal process completion, independent audits and root adoption. Original
historical status labels are preserved; records/ROOT_ADOPTION.json records the
later adoption. Original source and BDD files are byte-identical to the input.

stdout.jsonl is the original lossless dictionary/run-length encoded stream.
Its base64 literal blocks and repeated-line dictionary are preserved exactly.
The checker validates encoded hashes, record completeness and reconstructed
byte lengths without expanding repeated output. There is no expanded raw
stdout file and no raw-stdout SHA-256 claim; raw_sha256 remains null.

TRANSFORMATIONS.json lists original/public hashes and every location/admin
transformation. origin:* aliases name historical private preimages, not local
paths to run; hash fields inside historical records still describe those
preimages. Personal paths and runtime artifacts are not distributed. The
portable semantic core preserves exact DAG/Model/quantifier bodies from the
independent audit with a path-bounded wrapper. Qualification records, when
present in qualification/, describe positive and corrupted-input checks.

source/AutonomousVehicle_sprint02_ver1.spectra is the unchanged 3,924-byte
benchmark from Zenodo 10553249, original archive member
artifact/experiments/specs/syn20/AutonomousVehicle_sprint02_ver1.spectra.
It has no literal imports. Its BSD 3-Clause notice is reproduced unchanged in
licenses/zenodo10553249-LICENSE.txt. The original artifact README declares
BSD 3-Clause; the separate license file accompanies the public artifact.
LICENSE-original.txt states the existing artifact license for original
checker, documentation and research-output contributions; it does not
relicense the third-party source or upstream runtime components.
No upstream JAR, class, primary-paper PDF, manuscript or review is included.

Existing source-policy/continuation evidence is separate:
https://github.com/research-artifact-archive/seams2027/tree/continuation-evidence-20261024-v1
https://github.com/research-artifact-archive/seams2027/tree/saved-evidence-20261020-v1
These links identify earlier immutable releases; the local replay uses only
this package and does not fetch remote content.
