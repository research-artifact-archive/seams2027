#!/usr/bin/env python3
"""Portable checks of saved Vehicle188 functions; never invokes a solver."""
from pathlib import Path
import argparse
import importlib.util
import json
import sys
import time

sys.dont_write_bytecode = True

def module(name, path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

def run(root):
    mt=module('vehicle188_manifest',root/'manifest_tools.py')
    integrity=mt.verify(root)
    core=module('vehicle188_semantic_core',root/'semantic_core.py')
    core.initialize(root)
    need=core.need
    source=core.pin(root/'source/AutonomousVehicle_sprint02_ver1.spectra')
    need(source['bytes']==3924 and source['sha256']=='0e6faaedcd2bf8ab7b80d239231973f4588922ae5ff85a95927894cf78531e3b','unchanged licensed public source identity')
    target=core.read(root/'data/target.json')
    targetpin=core.pin(root/'data/target.json')
    need(targetpin['sha256']=='4e3497108d0f2114e1579cab4d24d80aa62928cf62075116cf0080b6d5ae7362','fixed pre-existing target bytes')
    reports={}
    for arm in ['original','released']:
        armdir=root/'data/native'/arm
        out=armdir/'native_result'
        result=core.read(out/'RESULT.json')
        proc=core.read(armdir/'PROCESS.json')
        independent=core.read(root/'records/independent_audit'/(arm.upper()+'_AUDIT.json'))
        need(result['input_sha256']==source['sha256'] and result['target_sha256']==targetpin['sha256'],'native source and fixed target binding: '+arm)
        d=core.DAG()
        saved=core.Model(root/'data/reference_models'/arm,d)
        m=core.Model(out,d)
        core.check_model_mode(m,arm)
        for key in ['fields','public_fields','all_current_bits','all_next_bits','bdd_variable_count','bdd_variable_order']:
            need(m.model[key]==saved.model[key],'fresh metadata equals saved model: '+key)
        need(m.model['input']['sha256']==saved.model['input']['sha256']==source['sha256'],'saved and native source identity: '+arm)
        need(m.formulas.keys()==saved.formulas.keys(),'complete predicate roster identity')
        for key in m.formulas:
            need(m.formulas[key]==saved.formulas[key],'raw full predicate identity: '+key)
        need(m.justices==saved.justices,'full ordered justice function identity')
        state=dict(target,**({'~envHelp':'false'} if arm=='released' else {}))
        fixed=d.cube(m.bits(state,True))
        roots={key:m.load_ref(result[key]) for key in ['query_domain','pending_full_state','solver_rhoE','solver_rhoS']}
        need(roots['query_domain']==m.D and roots['solver_rhoE']==m.formulas['rhoE'] and roots['solver_rhoS']==m.formulas['rhoS'],'saved executed arena is full and unrestricted')
        need(roots['pending_full_state']==fixed and d.count(fixed,m.cbits)==1,'saved root equals full fixed singleton')
        decoded={}
        for f in m.fields:
            vals=[v for v in f['values'] if d.both(roots['pending_full_state'],d.cube(m.enc[f['name'],v,'current']))!=0]
            need(vals==[state[f['name']]],'decode fixed root field: '+f['name'])
            decoded[f['name']]=vals[0]
        need(result['mode']==arm and result['helper_used']==(arm=='released'),'recorded strict arm identity')
        need(result['syntactic_reduction_calls']==int(arm=='released') and result['semantic_reduction_calls']==0,'recorded reduction counts')
        need(result['native_strict_solver_calls']==1 and result['raw_four_fixed_point_calls']==0 and result['controller_extraction_calls']==0 and result['GUI_execution'] is False,'recorded one strict solve and no extraction/4FP/GUI')
        need(result['all_prequery_gates_pass'] is True and all(result[k] is False for k in ['extra_transition_restrictions','source_initializers_changed','source_or_monitor_reset','private_memory_used']),'recorded prequery and no-restriction flags')
        need(result['status']=='PASS_COMPLETE' and result['strict_memory_complete'] is True and result['stage']=='PROCESS_FINISHED' and result['teardown']=='COMPLETED','recorded complete native memory and teardown')
        need(proc['returncode']==0 and proc['termination_events']==[] and proc['reasons']==[] and proc['remaining_owned_processes']==[],'recorded normal process completion')
        need(proc['elapsed_seconds']<120 and proc['max_sampled_rss_bytes']<=1073741824,'recorded bounded time and sampled RSS')
        need(proc['max_sampled_rss_bytes']==max(s['rss_bytes'] for s in proc['samples']),'recompute recorded sampled RSS maximum')
        capture=core.capture(armdir)
        w=m.load_ref(result['winning_region_raw']); wt=m.load_ref(result['winning_region_typed'])
        need(d.support(w)<=m.cbits,'raw W has only current field bits')
        need(wt==d.both(w,m.D),'typed W equals raw W intersect typed domain')
        membership=d.evaluate(w,m.bits(state,True))
        need(membership==result['pending_state_strict_winning'],'independent W membership agrees with recorded native result')
        answers=d.exists(d.both(w,m.formulas['thetaS']),m.sc)
        initialized=d.forall(d.either(d.neg(m.formulas['thetaE']),answers),m.ec)
        need(initialized in [0,1],'binary initializer quantification fully closed')
        need((initialized==1)==result['actual_initializer_realizable'],'binary forall ENV exists SYS initializer agrees with recorded native result')
        legalinputs=d.both(m.DE,m.formulas['thetaE'])
        typed_answers=d.exists(d.allof([m.DS,m.formulas['thetaS'],w]),m.sc)
        missing=d.both(legalinputs,d.neg(typed_answers))
        need((missing==0)==(initialized==1),'typed and binary initializer judgments agree')
        count=d.count(wt,m.cbits)
        need(membership==(arm=='original') and initialized==1,'saved pair agrees with adopted fixed-state observation')
        need(count==(8064 if arm=='original' else 40448),'saved full typed W count agrees with adopted observation')
        need(independent['status']=='PASS_COMPLETE_EXPECTED' and independent['pending_membership']==membership and independent['initialized_verdict']==(initialized==1) and independent['typed_W_count']==count,'portable results agree with historical independent audit')
        reports[arm]={'typed_carrier_states':m.carrier,'full_typed_W_states':count,'fixed_state':decoded,'fixed_state_membership':membership,'initializer_verdict':initialized==1,'allowed_ENV_initial_values':d.count(legalinputs,m.ec),'unanswered_ENV_initial_values':d.count(missing,m.ec),'capture':capture,'historical_class_origin_audit_reexecuted':False}
    return {'status':'PASS_SAVED_IDENTITY_MEMBERSHIP_INITIALIZATION','integrity':integrity,'arms':reports,'semantic_checks':len(core.checks),'native_solver_calls':0,'game_fixed_point_recomputations':0,'source_certificate_replays':0,'limits':'Saved BDD/model checks only. Native solver correctness, compilation, class origins, source cooperative feasibility and reachability remain recorded or separate evidence.'}

def main():
    if sys.flags.optimize:
        print('FAIL: optimized Python is unsupported',file=sys.stderr)
        return 2
    p=argparse.ArgumentParser()
    p.add_argument('--bundle',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();root=a.bundle.resolve();dest=a.out.resolve()
    if root==dest or root in dest.parents or dest.exists():
        p.error('--out must be a new file outside the immutable bundle')
    began=time.monotonic()
    try:
        report=run(root)
    except Exception as error:
        print('FAIL: '+str(error),file=sys.stderr)
        return 1
    report['elapsed_seconds']=time.monotonic()-began
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'semantic_checks':report['semantic_checks'],'native_solver_calls':0},sort_keys=True))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
