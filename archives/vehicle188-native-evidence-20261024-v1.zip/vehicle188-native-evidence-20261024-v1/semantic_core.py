"""Exact saved-DAG semantic bodies from the independent audit; portable I/O only."""
from pathlib import Path
from functools import lru_cache
import base64, hashlib, json
ROOT = None
checks = []
def initialize(root):
    global ROOT, checks
    ROOT=Path(root).resolve()
    checks=[]
def need(ok,label,details=None):
    checks.append({'check':label,'passed':bool(ok)})
    if not ok:
        raise ValueError(label)
def pin(path):
    path=Path(path)
    resolved=path.resolve()
    need(ROOT in resolved.parents and not path.is_symlink(),'saved input remains inside bundle')
    data=path.read_bytes()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def read(path):
    pin(path)
    return json.loads(Path(path).read_text())

def norm(value):
    return str(value).lower() if type(value) is bool else str(value)


class DAG:
    def __init__(self):
        self.nodes = [None, None]
        self.unique = {}

    def mk(self, var, low, high):
        if low == high:
            return low
        key = var, low, high
        if key not in self.unique:
            self.unique[key] = len(self.nodes)
            self.nodes.append(key)
        return self.unique[key]

    def parse(self, path, ref, variables):
        actual = pin(path)
        need(all(actual[k] == ref[k] for k in ('bytes', 'sha256')), 'saved BDD byte/hash pin: ' + str(path.name))
        rows = [list(map(int, line.split())) for line in path.read_text('ascii').splitlines() if line.strip()]
        if len(rows) == 1:
            need(rows[0] in ([0, 0], [0, 1]), 'constant BDD syntax')
            root = rows[0][1]
            need(ref['node_count'] == 0 and ref['support'] == [], 'constant BDD metadata')
        else:
            need(rows[0] == [variables] and rows[1] == list(range(variables)), 'BDD declared variable count/natural order')
            ids = {0: 0, 1: 1}
            raw = {}
            triples = set()
            for row in rows[2:]:
                need(len(row) == 4, 'BDD four-column node row')
                ident, var, low, high = row
                need(ident > 1 and ident not in ids and 0 <= var < variables, 'BDD node identity and variable')
                need(low in ids and high in ids and low != high and (var, low, high) not in triples, 'BDD acyclic reduced unique node')
                need(all(child < 2 or raw[child][0] > var for child in (low, high)), 'BDD child variable ordering')
                raw[ident] = var, low, high
                triples.add((var, low, high))
                ids[ident] = self.mk(var, ids[low], ids[high])
            need(bool(raw), 'nonconstant BDD has nodes')
            rootid = rows[-1][0]
            todo, reached = [rootid], set()
            while todo:
                node = todo.pop()
                if node < 2 or node in reached:
                    continue
                reached.add(node)
                todo.extend(raw[node][1:])
            need(len(reached) == len(raw) == ref['node_count'], 'all saved BDD nodes reachable from final root')
            need(sorted({raw[u][0] for u in reached}) == ref['support'], 'BDD support metadata exactly decoded')
            root = ids[rootid]
        need(ref.get('zero', root == 0) == (root == 0) and ref.get('one', root == 1) == (root == 1), 'BDD constant flags')
        return root

    @lru_cache(None)
    def neg(self, root):
        if root < 2:
            return 1 - root
        var, low, high = self.nodes[root]
        return self.mk(var, self.neg(low), self.neg(high))

    @lru_cache(None)
    def both(self, a, b):
        if not a or not b:
            return 0
        if a == 1:
            return b
        if b == 1 or a == b:
            return a
        va, la, ha = self.nodes[a]
        vb, lb, hb = self.nodes[b]
        if va < vb:
            return self.mk(va, self.both(la, b), self.both(ha, b))
        if vb < va:
            return self.mk(vb, self.both(a, lb), self.both(a, hb))
        return self.mk(va, self.both(la, lb), self.both(ha, hb))

    def either(self, a, b):
        return self.neg(self.both(self.neg(a), self.neg(b)))

    def allof(self, roots):
        result = 1
        for root in roots:
            result = self.both(result, root)
        return result

    def anyof(self, roots):
        result = 0
        for root in roots:
            result = self.either(result, root)
        return result

    def cube(self, assignment):
        result = 1
        for var, value in sorted(assignment.items(), reverse=True):
            result = self.mk(var, 0, result) if value else self.mk(var, result, 0)
        return result

    def exists(self, root, variables):
        @lru_cache(None)
        def walk(node):
            if node < 2:
                return node
            var, low, high = self.nodes[node]
            low, high = walk(low), walk(high)
            return self.either(low, high) if var in variables else self.mk(var, low, high)
        return walk(root)

    def forall(self, root, variables):
        return self.neg(self.exists(self.neg(root), variables))

    def support(self, root):
        todo, reached, variables = [root], set(), set()
        while todo:
            node = todo.pop()
            if node < 2 or node in reached:
                continue
            reached.add(node)
            var, low, high = self.nodes[node]
            variables.add(var)
            todo.extend((low, high))
        return variables

    def evaluate(self, root, assignment):
        need(self.support(root) <= assignment.keys(), 'evaluation assignment covers every raw root bit')
        while root > 1:
            var, low, high = self.nodes[root]
            root = high if assignment[var] else low
        return bool(root)

    def count(self, root, bits):
        bits = sorted(bits)
        positions = {v: i for i, v in enumerate(bits)}
        need(self.support(root) <= set(bits), 'count variable support contained in declared universe')
        @lru_cache(None)
        def walk(node, pos):
            if node < 2:
                return node * 2 ** (len(bits) - pos)
            var, low, high = self.nodes[node]
            at = positions[var]
            return 2 ** (at - pos) * (walk(low, at + 1) + walk(high, at + 1))
        return walk(root, 0)


class Model:
    def __init__(self, directory, dag):
        self.directory, self.d = directory, dag
        self.model = read(directory / 'model.json')
        m = self.model
        self.fields = m['fields']
        self.byname = {f['name']: f for f in self.fields}
        need(len(self.byname) == len(self.fields), 'unique field roster')
        self.enc, allbits, self.carrier = {}, set(), 1
        for field in self.fields:
            name = field['name']
            need(field['owner'] in ['ENV', 'SYS'] and field['role'] == field['owner'], 'all fields have declared ENV/SYS owner and no AUX')
            need(field['domain_size'] == len(set(field['values'])) == len(field['values']), 'field domain size and distinct values')
            self.carrier *= field['domain_size']
            codes = set()
            for value in field['values']:
                e = field['encoding'][value]
                for phase in ['current', 'next']:
                    bits = {int(k): v for k, v in e[phase].items()}
                    need(set(bits) == set(field[phase + '_bits']) and all(type(v) is bool for v in bits.values()), 'complete Boolean field encoding')
                    self.enc[name, value, phase] = bits
                cbits = tuple(e['current'][str(i)] for i in field['current_bits'])
                nbits = tuple(e['next'][str(i)] for i in field['next_bits'])
                need(cbits == nbits and cbits not in codes, 'injective equal current/next field encoding')
                codes.add(cbits)
            for phase in ['current', 'next']:
                bits = field[phase + '_bits']
                need(len(bits) == len(set(bits)) and not allbits.intersection(bits), 'disjoint bit ownership')
                allbits.update(bits)
        need(allbits == set(range(m['bdd_variable_count'])), 'every declared BDD variable has exactly one field/phase owner')
        need(m['bdd_variable_order'] == list(range(m['bdd_variable_count'])), 'natural variable order with no reorder')
        self.cbits = {b for f in self.fields for b in f['current_bits']}
        self.nbits = {b for f in self.fields for b in f['next_bits']}
        self.env = [f for f in self.fields if f['owner'] == 'ENV']
        self.sys = [f for f in self.fields if f['owner'] == 'SYS']
        self.ec = {b for f in self.env for b in f['current_bits']}
        self.sc = {b for f in self.sys for b in f['current_bits']}
        self.en = {b for f in self.env for b in f['next_bits']}
        need(set(m['all_current_bits']) == self.cbits and set(m['all_next_bits']) == self.nbits, 'declared current/next bit unions exact')
        self.formulas = {k: dag.parse(directory / v['file'], v, m['bdd_variable_count']) for k, v in m['original_bdds'].items()}
        self.justices = {o: [dag.parse(directory / v['file'], v, m['bdd_variable_count']) for v in refs] for o, refs in m['original_justices'].items()}
        need(dag.support(self.formulas['rhoE']) <= self.cbits | self.en, 'ENV relation has no next SYS support')
        need(dag.support(self.formulas['thetaE']) <= self.ec, 'ENV initializer depends only on current ENV')
        need(dag.support(self.formulas['thetaS']) <= self.cbits, 'SYS initializer has no next support')
        need(all(dag.support(j) <= self.cbits for js in self.justices.values() for j in js), 'ordered justices are current predicates')
        self.D = self.domain(self.fields, 'current')
        self.DE = self.domain(self.env, 'current')
        self.DS = self.domain(self.sys, 'current')
        need(self.D == self.formulas['domain'] and self.domain(self.env, 'next') == self.formulas['domain_ENV_next'] and self.domain(self.sys, 'next') == self.formulas['domain_SYS_next'], 'all typed domain factors independently reconstructed')
        need(dag.count(self.D, self.cbits) == self.carrier, 'typed domain cardinality matches complete field Cartesian product')

    def domain(self, fields, phase):
        return self.d.allof(self.d.anyof(self.d.cube(self.enc[f['name'], value, phase]) for value in f['values']) for f in fields)

    def bits(self, values, complete=False):
        if complete:
            need(set(values) == set(self.byname), 'full target contains every field exactly once')
        result = {}
        for name, value in values.items():
            value = norm(value)
            need(name in self.byname and value in self.byname[name]['values'], 'target value typed: ' + name)
            result.update(self.enc[name, value, 'current'])
        return result

    def load_ref(self, ref):
        return self.d.parse(self.directory / ref['file'], ref, self.model['bdd_variable_count'])


def check_model_mode(model, arm):
    released = arm == 'released'
    need(len(model.fields) == 12 + released and len(model.env) == 10 + released and len(model.sys) == 2, 'fixed original/released field ownership counts')
    need(model.carrier == (67584 if released else 33792), 'exact unrestricted typed arena size')
    need([len(model.justices[o]) for o in ['ENV', 'SYS']] == [3 + released, 1], 'exact ordered justice counts')
    need(('~envHelp' in model.byname) == released, 'helper appears only in released arena')
    if released:
        need(model.byname['~envHelp']['owner'] == 'ENV' and model.byname['~envHelp']['values'] == ['false', 'true'], 'helper is complete Boolean ENV field')


def capture(armdir):
    data = (armdir / 'stdout.jsonl').read_bytes()
    pin(armdir / 'stdout.jsonl')
    receipt = read(armdir / 'native_result/EXACT_DIAGNOSTIC_RECEIPT.json')
    dictionary, rawbytes, repeats, end = {}, 0, 0, None
    rows = data.splitlines()
    for index, line in enumerate(rows):
        row = json.loads(line)
        need(end is None, 'no capture records after end')
        kind = row['kind']
        if kind == 'dictionary':
            need(index == 0 and not dictionary and row['id'] == 'cache_lookup', 'single initial capture dictionary')
            dictionary[row['id']] = base64.b64decode(row['data'], validate=True)
        elif kind == 'repeat':
            need(type(row['count']) is int and row['count'] > 0, 'positive capture repeat count')
            rawbytes += len(dictionary[row['id']]) * row['count']
            repeats += row['count']
        elif kind == 'bytes':
            rawbytes += len(base64.b64decode(row['data'], validate=True))
        elif kind == 'end':
            end = row
        else:
            raise AssertionError('Unknown capture record: ' + kind)
    need(end is not None and data.endswith(b'\n'), 'complete terminated capture')
    need(dictionary['cache_lookup'] == b'lookup, class net.sf.javabdd.JTLVJavaFactory$BddCache\n', 'exact capture dictionary text')
    need(end['raw_bytes'] == receipt['raw_bytes'] == rawbytes and end['repeated_lines'] == receipt['repeated_lines'] == repeats, 'exact reconstructed raw byte/repeat counts')
    need(receipt['encoded_bytes'] == len(data) and receipt['records'] == len(rows) and receipt['encoded_sha256'] == hashlib.sha256(data).hexdigest(), 'encoded stream size/records/hash verified')
    need(receipt['capture_complete'] and not receipt['cap_reached'] and receipt['capture_error'] is None and receipt['unflushed_repeated_lines'] == 0 and receipt.get('raw_sha256') is None, 'capture completed without error/cap/truncation or unsupported raw hash claim')
    return dict(encoded_bytes=len(data), raw_bytes=rawbytes, repeated_lines=repeats, records=len(rows), raw_sha256=receipt.get('raw_sha256'))

