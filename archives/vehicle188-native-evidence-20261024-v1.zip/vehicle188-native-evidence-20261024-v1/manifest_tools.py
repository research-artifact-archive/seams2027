"""Byte-integrity checks only; Python standard library."""
from pathlib import Path, PurePosixPath
import hashlib
import json

def require(ok, message):
    if not ok:
        raise ValueError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def safe(name):
    p = PurePosixPath(name)
    require(isinstance(name, str) and name and not p.is_absolute(), 'relative member required')
    require('\\' not in name and all(x not in ('', '.', '..') for x in name.split('/')), 'unsafe member path')
    return name

def verify(root):
    root = Path(root).resolve()
    manifest = json.loads((root/'MANIFEST.json').read_text())
    require(manifest['schema'] == 'vehicle188-native-evidence-manifest-v1', 'manifest schema')
    records = manifest['files']
    require(len(records) == len({r['path'] for r in records}), 'duplicate manifest path')
    expected = {safe(r['path']) for r in records}
    require('MANIFEST.json' not in expected, 'manifest is not self-hashed')
    actual = set()
    for p in root.rglob('*'):
        require(not p.is_symlink(), 'symlink forbidden')
        if p.is_file():
            actual.add(p.relative_to(root).as_posix())
    require(actual == expected | {'MANIFEST.json'}, 'exact manifest file roster')
    for r in records:
        data = (root/r['path']).read_bytes()
        require(len(data) == r['bytes'] and sha(data) == r['sha256'], 'manifest mismatch: '+r['path'])
    return {'status':'PASS_BYTE_INTEGRITY_ONLY','files_checked':len(records),'manifest_sha256':sha((root/'MANIFEST.json').read_bytes())}
