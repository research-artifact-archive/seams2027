# Third-party notices

Original artifact checker code, documentation and research outputs retain
the existing BSD 3-Clause terms in `LICENSE-original.txt`.

The unchanged Vehicle188 benchmark file at
`source/AutonomousVehicle_sprint02_ver1.spectra` comes from Zenodo record
10553249, archive `icse24_artifact.zip`, member
`artifact/experiments/specs/syn20/AutonomousVehicle_sprint02_ver1.spectra`.
The original artifact README declares BSD 3-Clause. The separately supplied
license is reproduced byte-for-byte as
`licenses/zenodo10553249-LICENSE.txt`; retain its Tel Aviv University / Software
Modeling Lab copyright, conditions and disclaimer. The benchmark has no
literal source imports.

Historical records identify runtime and loaded-class hashes for provenance.
No upstream Java source, JAR, class, native library, JDK or primary-paper PDF
is distributed here, and this package grants no additional rights in those
components. The source license is not applied to omitted runtime components.
