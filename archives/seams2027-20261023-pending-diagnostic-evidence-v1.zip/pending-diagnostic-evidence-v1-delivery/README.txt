Pending diagnostic evidence — validated delivery

The inner pending-diagnostic-evidence-v1.zip is the exact archive tested by one
successful relocated saved-evidence recheck. It contains 76 files, including its
manifest. The four reports in validation/ are exact outputs of that check.
VALIDATION_ATTESTATION.json binds the archive, reports, environment and scope.
DELIVERY_MANIFEST.json binds all files in this outer delivery except itself.

Extract the inner archive to obtain pending-diagnostic-evidence-v1/. Follow its
README.md to supply the two exact external Lift sources and run the verifier into
a fresh directory outside the kit. The tested MANIFEST.json SHA-256 is:
a49211ac9a882a0270c9744f7e7338db917fbde94a5030ebf1507808cdd8caaf

The inner manifest and assembly documents retain their assembly-time status.
The separate validation/REPLAY_RECEIPT.json records the subsequent successful
recheck. The tested kit has not been changed to insert a success claim.

Relative-reference contexts in the validation reports:
* Kit input and scientific-file references: extracted inner kit root.
* REPLAY_RECEIPT.json output references: validation/ in this delivery.
* Restored-source references: a reader-supplied external directory, containing
  lift_new.spectra and lift_old_no_b1.spectra with the recorded hashes. Those two
  publisher-derived sources are omitted. The kit documents their restoration.

The author verification used exact previously available source-byte copies; it
did not repeat network retrieval or the source-restoration helper. It ran on the
author's host from a relocated tree with isolated Python imports. The original
workspace remained accessible. This is a saved-source/AST/complete-graph/event
check with focused qualification controls, not independent external replication.
It executes no controller, native translator or saved BDD operation. PIDs, object
identities and clocks inside historical event checks belong to the original
recorded studies, not to this verification process.

43 negative controls were rejected for their expected reasons, and the positive
fairness control passed. Separate readers inspected actual result/pin/cleanup
evidence and public output content; these inspections did not rerun experiments.
Elapsed time and sampled memory in the attestation are execution observations,
not performance measurements. Scientific and application claim limits remain
those stated in the inner kit. Original kit notices and licenses remain intact;
this outer documentation and validation output use LICENSE-original.txt in the
inner kit. No license extends to omitted publisher material or dependencies.
