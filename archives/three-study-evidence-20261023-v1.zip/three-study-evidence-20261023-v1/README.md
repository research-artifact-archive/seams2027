# Certificate and finite-study replay evidence

This archive contains a completed, author-run relocation check for three studies: the six-cell request protocol and seven episodes, the eight-arm Humanoid guard census, and the complete saved Guard arena audit.

**Completed result:** all three studies were run once from a separate directory using the packaged scientific inputs. All owned processes exited successfully, were reaped, and left no process group. All 418 saved-result and integrity comparisons passed. Scientific code, source formulas and frozen study rosters were unchanged. `REPLAY_SUMMARY.json` gives the exact comparison scope and exclusions; `relocated-replay/` retains anonymized binding, process and comparison records with original/delivered hashes in that summary.

The 133 files in `saved-study-inputs/` are the immutable assembled inputs. Their README and MANIFEST say that replay was not yet qualified at their construction time. Those historical statuses are preserved. The outer summary records the later successful checks; it does not rewrite an old receipt.

## Inspect or replay

Start with `REPLAY_SUMMARY.json`, then `saved-study-inputs/README.md`. The latter includes a binding command and the three small portable helper programs. Set BUNDLE to the absolute path of `saved-study-inputs/`, compute its MANIFEST.json SHA-256, choose the Python executable and a new output directory outside the archive, and run its preparation command. Inspect the generated binding bridge and command plan, then execute the three listed study commands sequentially and the listed comparison command. The local operator confirms the exact inputs and destination. The scientific computations use Python's standard library and included local kernels. The included execution supervisor additionally requires a POSIX host with `ps` and sufficient memory/disk headroom; it preserves resource failure as incomplete rather than a semantic result.

The original complete saved results are under `saved-study-inputs/evidence/experiment/v58_submission_20261023/`. The binder changes declared location/pin metadata only and records original, anonymized and runtime hashes. Historical GO and process receipts inside the input tree are not reused as new execution authority. Anonymized records in `relocated-replay/` are inspection records, not directly executable local path configurations.

This is a same-host relocation check by the authors, not external replication or an operating-system sandbox. It does not regenerate the native arenas. The request model is constructed, the Humanoid source family was outcome-informed before its fixed eight-arm study and remains non-cooperative, and the Guard result is a fixed-instance causal audit. No speed, prevalence, deployment or generally better synthesizer claim follows.

Each supplied file is bound by the outer MANIFEST.json. The unchanged inner manifest independently covers the assembled inputs. The exact third-party corpus BSD notice and attribution are in LICENSE-third-party.txt and THIRD_PARTY_NOTICES.txt.
