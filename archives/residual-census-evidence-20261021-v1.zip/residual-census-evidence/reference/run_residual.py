"""A fixed, bounded census of eleven residual entries; no automatic retries."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib
import importlib.util
import json
import os
import sys
import traceback
from urllib.parse import unquote, urlparse

sys.dont_write_bytecode = True
B = Path(__file__).resolve().parent
CLASS = "PairedResidualContinuationDiagnostic"
PREFERENCE = "tau.smlab.syntech.games.gr1.GR1ContinuationPreferenceConstruction"
CHECKERS = ("check_residual_source", "check_residual_saved_model")


def need(ok, message):
    if not ok:
        raise ValueError(message)


def unique(pairs):
    result = {}
    for k, v in pairs:
        need(k not in result, "Duplicate JSON key")
        result[k] = v
    return result


def read(p):
    return json.loads(Path(p).read_text(), object_pairs_hook=unique)


def pin(p):
    p = Path(p).resolve()
    h = hashlib.sha256()
    size = 0
    with p.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
            size += len(block)
    return dict(path=str(p), bytes=size, sha256=h.hexdigest())


def verify(refs):
    for ref in refs:
        need(pin(ref["path"]) == {k: ref[k] for k in ("path", "bytes", "sha256")},
             "Frozen input changed: " + ref["path"])


def save_new(p, value):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("x") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")


def now():
    return datetime.now(timezone.utc)


def utc_datetime(value):
    # Pinned Python 3.10 requires an explicit offset rather than the Z suffix.
    return datetime.fromisoformat(value[:-1] + "+00:00" if value.endswith("Z") else value)


def clean_end(p):
    return (p.get("owned_child_reaped") is True
            and p.get("receipt_persisted") is True
            and p.get("parent_finalization_completed") is True
            and not p.get("parent_aborted")
            and not (p.get("exact_child_wait4") or {}).get("authority_lost")
            and (not p.get("process_started") or
                 ((p.get("exact_child_wait4") or {}).get("exact_child_reaped") is True
                  and (p.get("final_group_observation") or {}).get("state") == "ABSENT")))


def completed(p):
    return (clean_end(p) and p["status"] == "PROCESS_COMPLETED" and p["exit_code"] == 0
            and not p["fatal_reasons"] and not p["resource_reasons"]
            and all(x["complete"] for x in p["capture"].values()))


def verify_jdk(runtime):
    root = Path(runtime["java_home"])
    expected = {x["relative"]: x for x in runtime["jdk_inventory"]}
    actual = {str(p.relative_to(root)): p for p in root.rglob("*") if p.is_file() or p.is_symlink()}
    need(set(actual) == set(expected), "JDK file/symlink roster changed")
    for name, ref in expected.items():
        p = actual[name]
        if "symlink" in ref:
            need(p.is_symlink() and str(p.readlink()) == ref["symlink"], "JDK symlink changed")
        else:
            need(not p.is_symlink(), "JDK regular file became symlink")


def prepare(mode):
    runtime, cohort = read(B / "RUNTIME_INPUTS.json"), read(B / "COHORT.json")
    plan, freeze = read(B / "EXPERIMENT_PLAN.json"), read(B / "EXECUTABLE_FREEZE.json")
    need(plan["hard_stop_utc"] == "2026-10-21T08:21:00Z", "Fixed overall deadline")
    need(cohort["state_count"] == 11 and cohort["source_count"] == 1
         and cohort["original_I_M_K"] is False, "Frozen cohort scope")
    need(len(cohort["entries"]) == 11, "Exactly eleven entries")
    verify(freeze["files"])
    verify(runtime["all_runtime_refs"] + runtime["protected_v45"] + cohort["entries"])
    verify_jdk(runtime)
    verify([cohort["source"], cohort["original_source"], cohort["design_report"]])
    go = read(B / ("ROOT_BUILD_GO.json" if mode == "build" else "ROOT_EXECUTION_GO.json"))
    need(go["status"] == "GO" and go["plan"] == pin(B / "EXPERIMENT_PLAN.json")
         and go["freeze"] == pin(B / "EXECUTABLE_FREEZE.json"), "Exact root authorization")
    audit = read(go["independent_static_audit"]["path"])
    verify([go["independent_static_audit"]])
    need(audit["status"].startswith("PASS"), "Independent static audit")
    need(audit["executable_freeze"] == pin(B / "EXECUTABLE_FREEZE.json"), "Static review binds exact executable freeze")
    need(now() < utc_datetime(plan["hard_stop_utc"]), "Deadline reached")
    # javac also accepts this variable; the reused child supervisor removes the
    # Java launcher variables, but this javac-specific name is handled here.
    injection_removed = "JDK_JAVAC_OPTIONS" in os.environ
    os.environ.pop("JDK_JAVAC_OPTIONS", None)
    spec = importlib.util.spec_from_file_location("v46_bounded_process", B / "code/dispatch/bounded_process.py")
    supervisor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(supervisor)
    return runtime, cohort, plan, freeze, go, supervisor, injection_removed


def invoke(stage, plan, argv, folder, wall, tree, watch=()):
    hard = utc_datetime(plan["hard_stop_utc"])
    deadline = min(hard - timedelta(seconds=20), now() + timedelta(seconds=wall + 20))
    need((hard - now()).total_seconds() > wall + 25, "Insufficient time for bounded process and cleanup")
    return stage.run_bounded(
        argv, folder, deadline.isoformat(), wall_seconds=wall,
        rss_bytes=1073741824, stream_bytes=8388608, file_bytes=16777216,
        watch_files=watch, output_tree=tree, output_tree_bytes=134217728,
        aggregate_tree=B, aggregate_tree_bytes=1073741824, min_free_bytes=1073741824)


def classpath(runtime):
    return ":".join([str(B / "build/classes")] + [x["path"] for x in runtime["ordered_jars"]])


def postverify(runtime, cohort, freeze, generated=()):
    verify(freeze["files"])
    verify(runtime["all_runtime_refs"] + runtime["protected_v45"] + cohort["entries"])
    verify_jdk(runtime)
    verify([cohort["source"], cohort["original_source"], cohort["design_report"]])
    verify(generated)


def class_origins(run, build_record, require_preference):
    expected = {Path(x["path"]).relative_to(B / "build/classes").as_posix()[:-6].replace("/", "."): x
                for x in build_record["classes"]}
    observed = {}
    for line in (run / "native_class_load.log").read_text().splitlines():
        if "[class,load] " not in line or " source: " not in line:
            continue
        name, origin = line.split("[class,load] ", 1)[1].split(" source: ", 1)
        if name in expected:
            parsed = urlparse(origin)
            need(parsed.scheme == "file" and not parsed.netloc
                 and Path(unquote(parsed.path)).samefile(B / "build/classes"),
                 "Custom class came from outside fresh build: " + name)
            need(name not in observed or observed[name] == origin, "Inconsistent custom class origins")
            observed[name] = origin
    need(CLASS in observed and (not require_preference or PREFERENCE in observed),
         "Actual custom class loading evidence incomplete")
    verify(build_record["classes"])
    record = dict(status="PASS_ACTUAL_FRESH_CLASS_ORIGINS", classes=observed,
                  expected_class_bytes=build_record["classes"], log=pin(run / "native_class_load.log"))
    save_new(run / "CLASS_ORIGIN_CHECK.json", record)
    return pin(run / "CLASS_ORIGIN_CHECK.json")


def build():
    runtime, cohort, plan, freeze, go, stage, removed = prepare("build")
    folder = B / "build"
    folder.mkdir(exist_ok=False)
    (folder / "classes").mkdir()
    (folder / "empty_sourcepath").mkdir()
    result = dict(schema="v46-residual-build-v1", status="RUNNING", started_utc=now().isoformat(),
                  attempts=1, JDK_JAVAC_OPTIONS_removed=removed, errors=[])
    try:
        sources = [B / "src" / (CLASS + ".java"),
                   B / "src" / (PREFERENCE.replace(".", "/") + ".java")]
        command = [runtime["javac"]["path"], "-J-Xmx512m", "-encoding", "UTF-8", "-proc:none",
                   "-implicit:none", "-sourcepath", str(folder / "empty_sourcepath"),
                   "-cp", ":".join(x["path"] for x in runtime["ordered_jars"]),
                   "-d", str(folder / "classes")] + [str(p) for p in sources]
        p = invoke(stage, plan, command, folder / "compile_process", 120, folder)
        result["process"] = pin(folder / "compile_process/PROCESS_RECEIPT.json")
        need(completed(p), "Compile did not complete cleanly")
        classes = sorted((folder / "classes").rglob("*.class"))
        expected = set(plan["expected_class_files"])
        need({str(p.relative_to(folder / "classes")) for p in classes} == expected,
             "Unexpected compiled class roster")
        result["sources"] = [pin(p) for p in sources]
        result["classes"] = [pin(p) for p in classes]
        result["status"] = "PASS_FRESH_RESIDUAL_PRODUCER_BUILD"
    except BaseException as exc:
        result["status"] = "UNKNOWN_BUILD_FAILURE_NO_NATIVE_LAUNCH"
        result["errors"].append(dict(type=type(exc).__name__, message=str(exc), traceback=traceback.format_exc()))
    finally:
        try:
            postverify(runtime, cohort, freeze)
            result["input_integrity"] = "PASS"
        except BaseException as exc:
            result["status"] = "UNKNOWN_INPUT_MUTATION"
            result["errors"].append(dict(message=str(exc)))
        result["finished_utc"] = now().isoformat()
        save_new(B / "BUILD_RECEIPT.json", result)
        print(json.dumps(result))


def execute():
    runtime, cohort, plan, freeze, go, stage, removed = prepare("execute")
    build_record = read(B / "BUILD_RECEIPT.json")
    need(go["build"] == pin(B / "BUILD_RECEIPT.json"), "Exact reviewed build")
    need(build_record["status"] == "PASS_FRESH_RESIDUAL_PRODUCER_BUILD", "Build pass required")
    verify(build_record["classes"])
    (B / "runs").mkdir(exist_ok=False)
    rows = [dict(id=read(x["path"])["id"], entry=x,
                 status="NOT_ATTEMPTED", native_attempts=0, audits=[]) for x in cohort["entries"]]
    result = dict(schema="v46-fixed-residual-census-result-v1", status="RUNNING",
                  started_utc=now().isoformat(), JDK_JAVAC_OPTIONS_removed=removed,
                  cohort=pin(B / "COHORT.json"), rows=rows, errors=[])
    try:
        for row in rows:
            postverify(runtime, cohort, freeze, build_record["classes"])
            entry = read(row["entry"]["path"])
            need(entry["id"] == row["id"] and entry["original_I_M_K"] is False,
                 "Exact residual entry identity")
            if (utc_datetime(plan["hard_stop_utc"]) - now()).total_seconds() < 200:
                row["status"] = "UNKNOWN_NOT_ATTEMPTED_DEADLINE_RESERVE"
                continue
            run = B / "runs" / row["id"]
            run.mkdir(exist_ok=False)
            native, variant = run / "native", run / "variant"
            state = entry["full_original_state"]
            command = [runtime["java"]["path"], "-Xmx512m", "-XX:MaxDirectMemorySize=128m",
                       "-Xlog:class+load=info:file=" + str(run / "native_class_load.log"),
                       "-cp", classpath(runtime), CLASS, "corpus032__original",
                       entry["source"]["path"], str(native / "result.json"), runtime["origins"]["path"],
                       state["floor"], state["elevMot"]]
            save_new(run / "INPUTS.json", dict(entry=row["entry"], command=command,
                       source=entry["source"], classes=build_record["classes"], attempts=1,
                       automatic_retries=0, hard_stop_utc=plan["hard_stop_utc"]))
            row["native_attempts"] = 1
            row["status"] = "UNKNOWN_NATIVE_OR_AUDIT_INCOMPLETE"
            p = invoke(stage, plan, command, native, 30, run,
                       [f / n for f in (native, variant) for n in ("result.json", "model.json", "controller.json", "controller.txt")])
            row["process"] = pin(native / "PROCESS_RECEIPT.json")
            need(clean_end(p), "Native process not confirmed reaped/absent; stop all later rows")
            row["process_complete"] = completed(p)
            if not completed(p):
                row["status"] = "UNKNOWN_NATIVE_PROCESS"
                save_new(run / "ROW_RESULT.json", row)
                continue
            pair_has_graphs = all((f / "controller.json").exists() for f in (native, variant))
            row["class_origin_check"] = class_origins(run, build_record, pair_has_graphs)
            arms = [f for f in (native, variant)
                    if (f / "result.json").exists() and (f / "model.json").exists()]
            row["producer_outcomes"] = {f.name: read(f / "result.json").get("status") for f in arms}
            # Also audit a completed native no-controller declaration against its
            # source/model/entry. It is not evidence of source infeasibility.
            # A semantic failure in one audit never suppresses the other route.
            for arm in arms:
                for checker in CHECKERS:
                    output = run / "audits" / (arm.name + "_" + checker + ".json")
                    command = [runtime["python"]["path"], "-I", "-S", "-B",
                               str(B / "code" / (checker + ".py")), str(arm), row["entry"]["path"], str(output)]
                    folder = run / "audits" / (arm.name + "_" + checker + "_process")
                    ap = invoke(stage, plan, command, folder, 30, run, [output])
                    audit = dict(arm=arm.name, checker=checker, process=pin(folder / "PROCESS_RECEIPT.json"),
                                 process_complete=completed(ap))
                    need(clean_end(ap), "Audit process not confirmed reaped/absent; stop")
                    if output.exists():
                        audit["result"] = pin(output)
                        audit["reported_status"] = read(output).get("status")
                    row["audits"].append(audit)
            # Final scientific adoption requires independent reconciliation of
            # these four retained outputs and producer pairing evidence.
            row["status"] = ("COMPLETE_PAIR_CAPTURED_AWAITING_INDEPENDENT_RECONCILIATION" if pair_has_graphs
                             else "INCOMPLETE_PAIR_OR_DECLARED_NO_CONTROLLER_AWAITING_RECONCILIATION")
            save_new(run / "ROW_RESULT.json", row)
        result["status"] = "FIXED_CENSUS_EXECUTION_FINISHED_AWAITING_RECONCILIATION"
    except BaseException as exc:
        result["status"] = "UNKNOWN_CENSUS_INTERRUPTED"
        result["errors"].append(dict(type=type(exc).__name__, message=str(exc), traceback=traceback.format_exc()))
    finally:
        for row in rows:
            if row["status"] == "NOT_ATTEMPTED":
                row["status"] = "UNKNOWN_NOT_ATTEMPTED_AFTER_STOP"
        try:
            postverify(runtime, cohort, freeze, build_record["classes"])
            result["input_integrity"] = "PASS"
        except BaseException as exc:
            result["status"] = "UNKNOWN_INPUT_MUTATION"
            result["errors"].append(dict(message=str(exc)))
        result["finished_utc"] = now().isoformat()
        save_new(B / "EXECUTION_RESULT.json", result)
        print(json.dumps(result))


if __name__ == "__main__":
    need(len(sys.argv) == 2 and sys.argv[1] in ("build", "execute"), "Explicit build or execute required")
    build() if sys.argv[1] == "build" else execute()
