import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.io.*;
import java.time.Instant;
import java.util.*;
import net.sf.javabdd.*;
import org.apache.log4j.*;
import org.apache.log4j.spi.LoggingEvent;
import tau.smlab.syntech.jtlv.env.module.ModuleBDDField;
import tau.smlab.syntech.spectragameinput.SpectraInputProviderNoIDE;
import tau.smlab.syntech.gameinputtrans.TranslationProvider;
import tau.smlab.syntech.gameinput.model.*;
import tau.smlab.syntech.gameinput.spec.*;
import tau.smlab.syntech.bddgenerator.BDDGenerator;
import tau.smlab.syntech.bddgenerator.BDDGenerator.TraceInfo;
import tau.smlab.syntech.gamemodel.*;
import tau.smlab.syntech.games.gr1.*;
import tau.smlab.syntech.games.controller.enumerate.*;
import tau.smlab.syntech.gameinput.kind.PitermanSyntacticReduction;
import tau.smlab.syntech.games.controller.enumerate.printers.SimpleTextPrinter;
import tau.smlab.syntech.jtlv.*;

/** Prospective exact-state residual experiment: one pinned source, one solve, two extractions.
 * Original source feasibility is separate saved evidence. No source initializer replay or repair.
 */
public final class PairedResidualContinuationDiagnostic {
  static final String SOURCE_SHA256="b80b321c90e862fd688d85bd9bc93fe1a6b6aa12e7f039d44d0437bc84d9da15";
  static final List<String> FLOOR_VALUES=Arrays.asList("LOWER","MIDDLE","UPPER","NONE");
  static final List<String> MOTOR_VALUES=Arrays.asList("FWD","BWD","STOP");
  static Map<String,Object> residualEntry;
  static Map<String,Object> sourceInitializerBDDs;
  static Object sourceNativeInventory;
  static SavedState pairedBefore;
  static Map<String,Object> baselineParity;
  static Map<String,Object> savedSourceInitialVerdict(){return m(
    "predicate","I_M(K)","value",false,"recomputed_in_this_process",false,
    "evidence_relative_path","experiment/seams_research_reframing_20261017/kind_corpus_symbolic_independent/runs/v2/corpus032__original/RESULT.json",
    "evidence_sha256","23c42a41ab32cf5aa0009fc30beebda1995c59ae3121481385162dbbed278436",
    "scope","Saved original-source region feasibility; residual extraction results do not replace this verdict.");}
  static final Map<String,Object> out = new LinkedHashMap<>();
  static Path receipt;
  static Map<String,Object> pendingVariantOutcome;
  static Path pendingVariantPath;
  static volatile String stage = "START";
  static long start;
  static String fixtureId,caseId,variant,pipeline,selectedSolver;
  static java.math.BigInteger carrierSize=java.math.BigInteger.ONE;
  static final List<Object> stageEvents=new ArrayList<>();
  static final Map<String,Long> sampledPeakHeap=new LinkedHashMap<>();
  static Timer heapSampler;
  static void sampleHeap(){long used=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();synchronized(sampledPeakHeap){sampledPeakHeap.put(stage,Math.max(sampledPeakHeap.getOrDefault(stage,0L),used));}}
  static void startHeapSampler(){heapSampler=new Timer("k7-heap-sampler",true);heapSampler.scheduleAtFixedRate(new TimerTask(){public void run(){sampleHeap();}},0,20);}

  static Map<String,Object> m(Object... kv) {
    Map<String,Object> x = new LinkedHashMap<>();
    for(int i=0;i<kv.length;i+=2) x.put((String)kv[i],kv[i+1]);
    return x;
  }
  static String q(String s) {
    StringBuilder b=new StringBuilder("\"");
    for(char c:s.toCharArray()) switch(c) {
      case '"': b.append("\\\""); break;
      case '\\': b.append("\\\\"); break;
      case '\n': b.append("\\n"); break;
      case '\r': b.append("\\r"); break;
      case '\t': b.append("\\t"); break;
      default: if(c<32) b.append(String.format("\\u%04x",(int)c)); else b.append(c);
    }
    return b.append('"').toString();
  }
  static String json(Object x) {
    if(x==null) return "null";
    if(x instanceof Boolean || x instanceof Number) return x.toString();
    if(x instanceof Map) {
      List<String> z=new ArrayList<>();
      for(Object e0:((Map<?,?>)x).entrySet()) {
        Map.Entry<?,?> e=(Map.Entry<?,?>)e0; z.add(q(String.valueOf(e.getKey()))+":"+json(e.getValue()));
      }
      return "{"+String.join(",",z)+"}";
    }
    if(x instanceof Iterable) {
      List<String> z=new ArrayList<>(); for(Object v:(Iterable<?>)x) z.add(json(v));
      return "["+String.join(",",z)+"]";
    }
    return q(String.valueOf(x));
  }
  static String sha(byte[] b) throws Exception {
    byte[] h=MessageDigest.getInstance("SHA-256").digest(b);
    StringBuilder s=new StringBuilder(); for(byte x:h) s.append(String.format("%02x",x&255)); return s.toString();
  }
  static void checkpoint(String s) throws Exception {
    sampleHeap();long elapsed=(System.nanoTime()-start)/1000000;
    Runtime rt=Runtime.getRuntime();
    stageEvents.add(m("stage",s,"elapsed_ms",elapsed,"heap_used_bytes",rt.totalMemory()-rt.freeMemory(),"heap_committed_bytes",rt.totalMemory(),"heap_max_bytes",rt.maxMemory()));
    stage=s; out.put("stage",stage); out.put("elapsed_ms",elapsed);out.put("stage_events",stageEvents);
    synchronized(sampledPeakHeap){out.put("sampled_peak_heap_by_stage",new LinkedHashMap<>(sampledPeakHeap));}
    out.put("heap_measurement",m("period_ms",20,"scope","sampled JVM heap used, excludes direct memory and OS RSS"));
    Path t=receipt.resolveSibling(receipt.getFileName()+".tmp");
    Files.writeString(t,json(out)+"\n",StandardCharsets.UTF_8);
    Files.move(t,receipt,StandardCopyOption.REPLACE_EXISTING);
  }
  static Object identity(Class<?> c) throws Exception {
    String r="/"+c.getName().replace('.','/')+".class";
    try(InputStream in=c.getResourceAsStream(r)) {
      return m("class",c.getName(),"code_source",String.valueOf(c.getProtectionDomain().getCodeSource()),"class_sha256",sha(in.readAllBytes()));
    }
  }
  static Object constraint(Constraint c) {
    return m("name",c.getName(),"kind",String.valueOf(c.getKind()),"trace_id",c.getTraceId(),"spec",String.valueOf(c.getSpec()),"spec_ast",specTree(c.getSpec()),"text",c.toString());
  }
  static Object player(Player p) {
    List<Object> vars=new ArrayList<>(), cons=new ArrayList<>(), pats=new ArrayList<>(), triggers=new ArrayList<>();
    for(Variable v:p.getVars()) vars.add(m("name",v.getName(),"type",String.valueOf(v.getType()),"trace_id",v.getTraceId()));
    for(Constraint c:p.getConstraints()) cons.add(constraint(c));
    for(PatternConstraint c:p.getPatterns()) pats.add(m("name",c.getName(),"trace_id",c.getTraceId(),"pattern",String.valueOf(c.getPattern()),"actuals",String.valueOf(c.getParameters()),"actuals_ast",specTrees(c.getParameters()),"text",c.toString()));
    for(TriggerConstraint c:p.getTriggers()) triggers.add(constraint(c));
    return m("variables",vars,"constraints",cons,"patterns",pats,"triggers",triggers,"existential_count",p.getExistentialConstraints().size());
  }
  static Object inventory(GameInput gi) { return m("ENV",player(gi.getEnv()),"SYS",player(gi.getSys()),"AUX",player(gi.getAux())); }
  static Object behaviors(List<BehaviorInfo> bs) {
    List<Object> a=new ArrayList<>();
    for(BehaviorInfo b:bs) a.add(m("trace_id",b.traceId,"aux",b.aux,"initial",b.isInitial(),"safety",b.isSafety(),"justice",b.isJustice(),"existential",b.isExistential()));
    return a;
  }
  static Object modelInventory(GameModel gm) {
    return m("ENV",behaviors(gm.getEnvBehaviorInfo()),"SYS",behaviors(gm.getSysBehaviorInfo()),"AUX",behaviors(gm.getAuxBehaviorInfo()),"env_fields",gm.getEnv().getAllFields().toString(),"sys_fields",gm.getSys().getAllFields().toString(),"env_justice_count",gm.getEnv().justiceNum(),"sys_justice_count",gm.getSys().justiceNum(),"env_initial_false",gm.getEnv().initial().isZero(),"sys_initial_false",gm.getSys().initial().isZero());
  }
  static String backend() {
    BDD t=Env.TRUE(); String c=t.getFactory().getClass().getName(); t.free();
    if(!c.equals("net.sf.javabdd.JTLVJavaFactory")) throw new IllegalStateException("Unexpected BDD backend: "+c);
    return c;
  }
  static final List<String> validatorErrors = Collections.synchronizedList(new ArrayList<>());
  static final class ValidationLogWatch extends AppenderSkeleton {
    protected void append(LoggingEvent e) {
      String n=e.getLoggerName();
      if(n!=null && n.contains("validation") && e.getLevel().isGreaterOrEqual(Level.ERROR)) {
        validatorErrors.add(n+": "+e.getRenderedMessage());
      }
    }
    public void close() {} public boolean requiresLayout() { return false; }
  }
  static void validationHealthy() {
    if(!validatorErrors.isEmpty()) throw new IllegalStateException("VALIDATOR_ERROR_LOG: "+validatorErrors);
  }
  static final class UnsupportedDomain extends RuntimeException {
    UnsupportedDomain(String message) { super(message); }
  }
  static void auditSpec(Spec s,boolean prime,boolean initial,Set<String> sys,List<String> violations) {
    if(s instanceof SpecExp) {
      SpecExp e=(SpecExp)s;
      for(Spec child:e.getChildren())auditSpec(child,prime||e.getOperator()==Operator.PRIME,initial,sys,violations);
    } else if(s instanceof VariableReference) {
      VariableReference r=(VariableReference)s;
      String n=r.getVariable().getName();
      boolean p=prime||r.getReferenceName().endsWith("'");
      if(sys.contains(n)&&(p||initial))violations.add((initial?"ENV initial references SYS ":"ENV next references SYS ")+n);
      if(r.getIndexSpecs()!=null)for(Spec idx:r.getIndexSpecs())auditSpec(idx,prime,initial,sys,violations);
    } else if(!(s instanceof PrimitiveValue)) {
      violations.add("Unsupported translated ENV expression class: "+s.getClass().getName());
    }
  }
  static void auditTranslated(GameInput gi) {
    Set<String> sys=new HashSet<>();
    for(Variable v:gi.getSys().getVars())sys.add(v.getName());
    for(Variable v:gi.getAux().getVars())sys.add(v.getName());
    List<String> violations=new ArrayList<>();
    for(Constraint c:gi.getEnv().getConstraints()) {
      if(c.getKind()==Constraint.Kind.INI||c.getKind()==Constraint.Kind.SAFETY)
        auditSpec(c.getSpec(),false,c.getKind()==Constraint.Kind.INI,sys,violations);
    }
    out.put("translated_turn_audit",m("SYS_and_AUX_names",sys,"violations",violations));
    if(!violations.isEmpty())throw new UnsupportedDomain(String.join("; ",violations));
  }
  static List<Integer> ints(int[] xs) { List<Integer> a=new ArrayList<>(); for(int x:xs)a.add(x); return a; }
  static List<Integer> support(BDD b) { BDDVarSet s=b.support(); List<Integer> r=ints(s.toArray()); s.free(); return r; }
  static void currentOnly(String name,BDD b) {
    if(Env.containPrimeVars(b)) throw new IllegalStateException(name+" contains next-state support: "+support(b));
  }
  static boolean subset(BDD a,BDD b) { BDD n=b.not(),x=a.and(n);boolean ok=x.isZero();x.free();n.free();return ok; }
  static Map<String,Object> snapshot(String name,BDD b) throws Exception {
    Path f=receipt.getParent().resolve(name+".bdd");Env.saveBDD(f.toString(),b,false);
    return m("file",f.getFileName().toString(),"bytes",Files.size(f),"sha256",sha(Files.readAllBytes(f)),"node_count",b.nodeCount(),"zero",b.isZero(),"one",b.isOne(),"support",support(b));
  }
  static BDD domain(PlayerModule pm,boolean next) {
    BDD d=Env.TRUE();
    for(ModuleBDDField f:pm.getAllFields()) d.andWith((next?f.other():f).getDomain().domain());
    return d;
  }
  static Object fields(PlayerModule pm) {
    List<Object> a=new ArrayList<>();
    for(ModuleBDDField f:pm.getAllFields()) a.add(m("field",f.toString(),"domain_size",f.getDomain().size().toString(),"current_bits",ints(f.getDomain().vars()),"next_bits",ints(f.other().getDomain().vars())));
    return a;
  }
  static void checkOrigins(Path file)throws Exception{Properties ps=new Properties();try(Reader r=Files.newBufferedReader(file)){ps.load(r);}require(ps.size()==22,"origin roster count");List<Object> ids=new ArrayList<>();for(String n:new TreeSet<>(ps.stringPropertyNames())){Class<?> c=Class.forName(n,false,ClassLoader.getSystemClassLoader());Path a=Paths.get(c.getProtectionDomain().getCodeSource().getLocation().toURI());require(Files.isSameFile(a,Paths.get(ps.getProperty(n))),"wrong class origin "+n);ids.add(identity(c));}out.put("class_identities",ids);}
  static final class InvariantMismatch extends RuntimeException{InvariantMismatch(String s){super(s);}}
  static void require(boolean b,String s){if(!b)throw new InvariantMismatch(s);}
  static Object specTree(Spec s){
    if(s==null)return null;
    if(s instanceof SpecExp){SpecExp e=(SpecExp)s;List<Object>children=new ArrayList<>();for(Spec c:e.getChildren())children.add(specTree(c));return m("kind","operator","operator",e.getOperator().toString(),"children",children);}
    if(s instanceof VariableReference){VariableReference v=(VariableReference)s;return m("kind","variable","name",v.getVariable().getName(),"reference_name",v.getReferenceName(),"trace_id",v.getVariable().getTraceId());}
    if(s instanceof PrimitiveValue)return m("kind","primitive","value",((PrimitiveValue)s).getValue());
    return m("kind","other","class",s.getClass().getName(),"text",s.toString());
  }
  static List<Object>specTrees(Iterable<Spec> xs){List<Object>r=new ArrayList<>();for(Spec x:xs)r.add(specTree(x));return r;}
  static Map<String,Object> filePin(Path p)throws Exception{return m("file",p.getFileName().toString(),"bytes",Files.size(p),"sha256",sha(Files.readAllBytes(p)));}
  static Map<String,Object> writeJson(String file,Map<String,Object> data)throws Exception{Path p=receipt.getParent().resolve(file);Files.writeString(p,json(data)+"\n",StandardCharsets.UTF_8);return filePin(p);}
  static Map<String,Object> identityFields(){return m("fixture_id",fixtureId,"case_id",caseId,"variant",variant);}
  static void equality(String label,BDD actual,BDD expected)throws Exception{BDD diff=actual.xor(expected);out.put(label,m("equal",diff.isZero(),"actual",snapshot(label+"_actual",actual),"expected",snapshot(label+"_expected",expected),"xor",snapshot(label+"_xor",diff)));boolean ok=diff.isZero();diff.free();expected.free();require(ok,label+" BDD equality failed");}
  static List<ModuleBDDField> allFields(GameModel gm){List<ModuleBDDField>x=new ArrayList<>();x.addAll(gm.getEnv().getAllFields());x.addAll(gm.getSys().getAllFields());return x;}
  static Map<String,Object> fixedBits(BDD b,int[]indices){Map<String,Object>r=new TreeMap<>();for(int bit:indices){BDD yes=b.getFactory().ithVar(bit),no=b.getFactory().nithVar(bit);boolean y=subset(b,yes),n=subset(b,no);yes.free();no.free();require(y!=n,"Incomplete or empty bit assignment "+bit);r.put(String.valueOf(bit),y);}return r;}
  static Map<String,Object> stateBits(BDD b,GameModel gm){BDDVarSet vars=gm.getEnv().moduleUnprimeVars().union(gm.getSys().moduleUnprimeVars());Map<String,Object>r=fixedBits(b,vars.toArray());vars.free();return r;}
  static Map<String,Object> singletonValuation(BDD b,GameModel gm){
    currentOnly("complete valuation",b);if(b.isZero())return null;Map<String,Object>r=new LinkedHashMap<>();BDD cube=Env.TRUE();
    for(ModuleBDDField field:allFields(gm)){String name=field.getName(),chosen=null;List<String>values=Env.getValueNames(name);int count=0;
      for(String value:values){BDD literal=Env.getBDDValue(name,value);require(literal!=null,"Missing native domain value");if(subset(b,literal)){chosen=value;count++;}}
      if(count!=1){cube.free();return null;}r.put(name,chosen);cube.andWith(Env.getBDDValue(name,chosen).id());
    }
    boolean full=b.equals(cube);cube.free();return full?r:null;
  }
  static List<Object> modelFields(GameModel gm,Set<String>publicEnv,Set<String>publicSys){
    List<Object>r=new ArrayList<>();Set<String>seen=new HashSet<>();Set<Integer>bits=new HashSet<>();carrierSize=java.math.BigInteger.ONE;
    for(ModuleBDDField f:allFields(gm)){String name=f.getName();require(seen.add(name),"Duplicate native field");List<String>values=Env.getValueNames(name);Collections.sort(values);require(java.math.BigInteger.valueOf(values.size()).equals(f.getDomain().size()),"Native value roster/domain mismatch");Map<String,Object>enc=new LinkedHashMap<>();
      for(int bit:f.getDomain().vars())require(bits.add(bit),"Duplicate current field bit");for(int bit:f.other().getDomain().vars())require(bits.add(bit),"Duplicate next field bit");
      for(String value:values){BDD lit=Env.getBDDValue(name,value);require(lit!=null&&!lit.isZero(),"Native field encoding missing");BDD prime=Env.prime(lit);enc.put(value,m("current",fixedBits(lit,f.getDomain().vars()),"next",fixedBits(prime,f.other().getDomain().vars())));prime.free();}
      String owner=gm.getEnv().getAllFields().contains(f)?"ENV":"SYS";String role=publicEnv.contains(name)?"ENV":publicSys.contains(name)?"SYS":"AUX";require(!owner.equals("ENV")||role.equals("ENV"),"Unexpected ENV auxiliary ownership");
      r.add(m("name",name,"owner",owner,"role",role,"domain_size",f.getDomain().size().intValueExact(),"values",values,"current_bits",ints(f.getDomain().vars()),"next_bits",ints(f.other().getDomain().vars()),"encoding",enc));carrierSize=carrierSize.multiply(f.getDomain().size());
    }return r;
  }
  static List<Object> justiceSnapshots(PlayerModule module,String prefix)throws Exception{List<Object>x=new ArrayList<>();for(int i=0;i<module.justiceNum();i++){currentOnly(prefix,module.justiceAt(i));x.add(snapshot(prefix+"_"+i,module.justiceAt(i)));}return x;}
  static Map<String,Object> modelExport(GameModel gm,Set<String>pe,Set<String>ps,Object parsed,Object translated,Path input)throws Exception{
    Map<String,Object>r=identityFields();r.put("schema","residual-entry-native-model-v1");r.put("initialization","exact_full_state_residual_entry");r.put("initializers_replaced",true);r.put("entry",residualEntry);r.put("source_initializer_bdds",sourceInitializerBDDs);r.put("source_initializer_semantics","Original transformed theta after released syntactic reduction/default translators, saved before residual override");r.put("saved_original_source_initial_verdict",savedSourceInitialVerdict());r.put("input",m("path",input.toString(),"bytes",Files.size(input),"sha256",sha(Files.readAllBytes(input))));r.put("fields",modelFields(gm,pe,ps));r.put("public_fields",m("ENV",pe,"SYS",ps));
    BDDVarSet curr=gm.getEnv().moduleUnprimeVars().union(gm.getSys().moduleUnprimeVars()),next=gm.getEnv().modulePrimeVars().union(gm.getSys().modulePrimeVars());r.put("all_current_bits",ints(curr.toArray()));r.put("all_next_bits",ints(next.toArray()));curr.free();next.free();
    BDD de=domain(gm.getEnv(),false),ds=domain(gm.getSys(),false),dep=domain(gm.getEnv(),true),dsp=domain(gm.getSys(),true),d=de.and(ds);
    r.put("bdd_variable_count",d.getFactory().varNum());List<Integer>varOrder=new ArrayList<>();for(int level=0;level<d.getFactory().varNum();level++)varOrder.add(d.getFactory().level2Var(level));r.put("bdd_variable_order",varOrder);r.put("residual_bdds",m("thetaE",snapshot("residual_thetaE",gm.getEnv().initial()),"thetaS",snapshot("residual_thetaS",gm.getSys().initial()),"rhoE",snapshot("original_rhoE",gm.getEnv().trans()),"rhoS",snapshot("original_rhoS",gm.getSys().trans()),"domain",snapshot("domain",d),"domain_ENV_next",snapshot("domain_ENV_next",dep),"domain_SYS_next",snapshot("domain_SYS_next",dsp)));
    r.put("original_justices",m("ENV",justiceSnapshots(gm.getEnv(),"original_ENV_justice"),"SYS",justiceSnapshots(gm.getSys(),"original_SYS_justice")));r.put("source_inventory",m("parsed",parsed,"translated",translated,"native_behaviors_before_initializer_override",sourceNativeInventory));de.free();ds.free();dep.free();dsp.free();d.free();return r;
  }

  static Map<String,Object> controllerSnapshot(EnumStrategyI c,GameModel gm)throws Exception{
    require(c.numOfStates()>0&&c.numOfStates()<=4096,"Controller state cap/nonempty");
    require(!c.isCalcStats(),"Unexpected controller statistics mode");
    List<Object> nodes=new ArrayList<>(),edges=new ArrayList<>();Set<Integer> ids=new HashSet<>();int initialCount=0;
    for(int i=0;i<c.numOfStates();i++){
      EnumStateI st=c.getState(i);require(st.getStateId()==i&&ids.add(i),"Printer index/native ID mismatch");
      Map<String,Object> value=singletonValuation(st.getData(),gm);require(value!=null,"Non-singleton native controller valuation");
      List<String> succ=new ArrayList<>();Set<Integer> seenSucc=new HashSet<>();
      for(EnumStateI to:st.getSuccessors()){int j=to.getStateId();require(j>=0&&j<c.numOfStates(),"Unknown successor ID");require(c.getState(j)==to,"Successor object/ID mismatch");require(seenSucc.add(j),"Duplicate successor");succ.add(String.valueOf(j));edges.add(Arrays.asList(String.valueOf(i),String.valueOf(j)));require(edges.size()<=65536,"Controller edge cap");}
      AbstractRankInfo rank=st.get_rank_info();require(rank instanceof GR1RankInfo,"Unexpected rank type");
      if(st.isInitial()){initialCount++;require(value.equals(residualEntry.get("valuation")),"Initial graph valuation differs from residual entry");require(rank.memVal()==0,"New controller private rank must start at zero");}
      nodes.add(m("id",String.valueOf(i),"native_id",i,"initial",st.isInitial(),"rank",rank.memVal(),"rank_class",rank.getClass().getName(),"rank_info",rank.rankInfoString(),"valuation",value,"bits",stateBits(st.getData(),gm),"native_bdd_text",st.getData().toStringWithDomains(Env.stringer),"successors",succ));
    }
    require(initialCount==1,"Exact residual singleton must yield one initial graph state");require(c.enumController().size()==c.numOfStates(),"Controller vector size");require(edges.size()==c.numOfTransitions(),"Native/export edge count");
    Map<String,Object> result=identityFields();result.putAll(m("schema","residual-entry-complete-native-controller-v1","complete",true,"initialization","exact_full_state_residual_entry","initializers_replaced",true,"entry",residualEntry,"helper_policy","unchanged_native_graph_with_helper","controller_identity",System.identityHashCode(c),"model_sha256",sha(Files.readAllBytes(receipt.getParent().resolve("model.json"))),"native_memory_identity",out.get("native_memory_identity"),"rank_domain_size",gm.getSys().justiceNum(),"api_state_count",c.numOfStates(),"api_transition_count",c.numOfTransitions(),"nodes",nodes,"edges",edges));return result;
  }
  static void extraOrigins()throws Exception{
    Class<?>[]cs={GR1ConceteControllerConstructionSkip.class,GR1Memory.class,GR1RankInfo.class,EnumStrategyImpl.class,EnumStateI.class,SimpleTextPrinter.class};List<Object>x=new ArrayList<>();
    for(Class<?>c:cs){Class<?>anchor=c.getName().contains(".gr1.")?GR1Game.class:tau.smlab.syntech.games.GameMemory.class;require(c.getProtectionDomain().getCodeSource().getLocation().equals(anchor.getProtectionDomain().getCodeSource().getLocation()),"Unexpected class origin "+c.getName());x.add(identity(c));}out.put("extractor_printer_origins",x);
  }
  static void setNoneOptimizationEffects(){
    GR1GameExperiments.DETECT_FIX_POINT_EARLY=false;GR1GameExperiments.USE_FIXPOINT_RECYCLE=false;GR1GameExperiments.STOP_WHEN_INITIALS_LOST=false;GR1GameExperiments.SIMULTANEOUS_CONJUNCTION_ABSTRACTION=false;
    tau.smlab.syntech.games.rabin.RabinGame.DETECT_FIX_POINT_EARLY=false;tau.smlab.syntech.games.rabin.RabinGame.USE_FIXPOINT_RECYCLE=false;tau.smlab.syntech.games.rabin.RabinGame.STOP_WHEN_WIN_FROM_SOME_INITIALS=false;tau.smlab.syntech.games.rabin.RabinGame.SIMULTANEOUS_CONJUNCTION_ABSTRACTION=false;
  }
  public static void main(String[]args)throws Exception{
    if(args.length!=6)throw new IllegalArgumentException("fixture input result origins floor elevMot");
    fixtureId=args[0];caseId=fixtureId;variant="residual_entry";pipeline="residual_entry_released_syntactic_4fp_paired_extraction";selectedSolver="4fp";
    receipt=Paths.get(args[2]).toAbsolutePath();start=System.nanoTime();startHeapSampler();int exit=0;BDDFactory factory=null;GR1SeparatedGame game=null;GameModel gm=null;
    out.putAll(identityFields());out.putAll(m("schema","residual-entry-native-result-v1","pipeline",pipeline,"solver","4fp","status","RUNNING","native_solver_calls",0,"controller_extraction_calls",0,"native_printer_calls",0,"initializers_replaced",false,"initializer_replacement_requested",true,"initialization","exact_full_state_residual_entry","saved_original_source_initial_verdict",savedSourceInitialVerdict(),"semantic_reduction_used",false,"ENV_justice_normalization_used",false,"GUI_execution",false));
    out.put("runtime",m("java_version",System.getProperty("java.version"),"java_home",System.getProperty("java.home"),"os_arch",System.getProperty("os.arch")));
    out.put("configuration",m("release","1.0.0.202402072123","BDDPackage","JTLV","BDDPackageVersion","DEFAULT","synthesisMethod","synthesisPitermanReduction","ConcreteControllerFormat","JTLV","optChoice","none","reorderChoice","none","groupVars",false,"TraceInfo","NONE","TransFuncType","SINGLE_FUNC","extractor_strategy","native_two_argument_default_ZYX"));
    Logger.getRootLogger().addAppender(new ValidationLogWatch());
    try{
      checkOrigins(Paths.get(args[3]));extraOrigins();Path input=Paths.get(args[1]).toRealPath();out.put("input",input.toString());out.put("input_sha256",sha(Files.readAllBytes(input)));require(Files.size(input)==732&&SOURCE_SHA256.equals(out.get("input_sha256")),"Only the exact frozen Elevator032 source is supported");require(FLOOR_VALUES.contains(args[4])&&MOTOR_VALUES.contains(args[5]),"Entry CLI value outside exact source type");
      checkpoint("PARSE_VALIDATE");GameInput gi=new SpectraInputProviderNoIDE().getGameInput(input.toString());validationHealthy();validateSourceInventory(gi);Object parsed=inventory(gi);out.put("parsed_inventory",parsed);Set<String>pe=new LinkedHashSet<>(),ps=new LinkedHashSet<>();for(Variable v:gi.getEnv().getVars())pe.add(v.getName());for(Variable v:gi.getSys().getVars())ps.add(v.getName());out.put("original_public_fields",m("ENV",new ArrayList<>(pe),"SYS",new ArrayList<>(ps)));
      checkpoint("RELEASED_SYNTACTIC_REDUCTION_BEFORE_TRANSLATORS");PitermanSyntacticReduction.doReduction(gi);out.put("reduced_inventory",inventory(gi));
      checkpoint("FULL_DEFAULT_TRANSLATORS");TranslationProvider.translate(gi,tau.smlab.syntech.gameinputtrans.translator.DefaultTranslators.getDefaultTranslators());validationHealthy();Object translated=inventory(gi);out.put("translated_inventory",translated);auditTranslated(gi);require(gi.getAux().getVars().isEmpty(),"Unexpected translated source AUX");
      checkpoint("JTLV_BACKEND_AND_SOURCE_INITIAL_MODEL");BDDPackage.setCurrPackage(BDDPackage.JTLV,BDDPackage.BBDPackageVersion.DEFAULT);Env.disableReorder();BDD one=Env.TRUE();factory=one.getFactory();one.free();out.put("observed_backend",backend());
      gm=BDDGenerator.generateGameModel(gi,TraceInfo.NONE,false,PlayerModule.TransFuncType.SINGLE_FUNC);
      boolean helper=Env.getVar("~envHelp")!=null;out.put("helper_added",helper);if(helper)pe.add("~envHelp");out.put("helper_is_native_nonaux_ENV",helper&&gm.getEnv().getNonAuxFields().contains(Env.getVar("~envHelp")));
      require(helper&&gm.getEnv().getNonAuxFields().contains(Env.getVar("~envHelp")),"Expected released native ENV helper");
      checkpoint("EXACT_RESIDUAL_INITIALIZER_OVERRIDE");prepareResidualEntry(gm,args[4],args[5]);
      out.put("model_export",writeJson("model.json",modelExport(gm,pe,ps,parsed,translated,input)));require(!Env.hasVars(gm.getEnv().trans(),gm.getSys().modulePrimeVars()),"Transformed ENV next SYS");
      out.put("preconstructor_justices",m("ENV",justiceSnapshots(gm.getEnv(),"preconstructor_ENV_justice"),"SYS",justiceSnapshots(gm.getSys(),"preconstructor_SYS_justice")));
      checkpoint("SOLVER_CONSTRUCTION");setNoneOptimizationEffects();game=new GR1SeparatedGame(gm);out.put("solver_class_identity",identity(game.getClass()));out.put("native_model_identity",System.identityHashCode(gm));out.put("native_memory_identity",System.identityHashCode(game.getMem()));out.put("solver_justices",m("ENV",justiceSnapshots(gm.getEnv(),"solver_ENV_justice"),"SYS",justiceSnapshots(gm.getSys(),"solver_SYS_justice")));
      checkpoint("NATIVE_KIND_SOLVER");out.put("native_solver_calls",1);boolean realizable=game.checkRealizability();out.put("native_residual_initial_verdict",realizable);out.put("memory_complete",game.getMem().isComplete());out.put("final_region",snapshot("final_region",game.sysWinningStates()));
      if(!realizable){out.put("status","JOB_UNREALIZABLE_NO_CONTROLLER");out.put("memory_empty_guard_called",false);}
      else{
        Env.disableReorder();checkpoint("RELEASED_MEMORY_EMPTY_GUARD");out.put("memory_empty_guard_called",true);boolean empty=game.getMem().isEmptyController();out.put("memory_empty",empty);
        if(empty){out.put("status","JOB_EMPTY_MEMORY_NO_CONTROLLER");}
        else{
          checkpoint("CAPTURE_BEFORE_ANY_EXTRACTION");GR1Memory mem=game.getMem();pairedBefore=captureMemoryAndModel(mem,gm);out.put("before_any_extraction",exportState("before_any_extraction",pairedBefore));
          checkpoint("UNCHANGED_GENERIC_EXTRACTION");GR1ConceteControllerConstructionSkip cc=new GR1ConceteControllerConstructionSkip(mem,gm);out.put("same_native_memory_passed_to_constructor",System.identityHashCode(mem)==((Number)out.get("native_memory_identity")).intValue());out.put("same_native_model_passed_to_constructor",System.identityHashCode(gm)==((Number)out.get("native_model_identity")).intValue());out.put("controller_extraction_calls",1);EnumStrategyI controller=cc.calculateConcreteController();baselineParity=verifyUnchanged("after_baseline_extraction",pairedBefore,captureMemoryAndModel(mem,gm));out.put("baseline_memory_model_parity",baselineParity);
          Map<String,Object>before=controllerSnapshot(controller,gm);String beforeJSON=json(before);out.put("controller_before_print_sha256",sha(beforeJSON.getBytes(StandardCharsets.UTF_8)));
          checkpoint("RELEASED_SIMPLE_TEXT_PRINTER");Path printed=receipt.getParent().resolve("controller.txt");out.put("native_printer_calls",1);try(PrintStream stream=new PrintStream(Files.newOutputStream(printed),false,StandardCharsets.UTF_8)){new SimpleTextPrinter().printController(stream,controller);if(stream.checkError())throw new IOException("Printer output stream error");}
          out.put("printed_controller",filePin(printed));Map<String,Object>after=controllerSnapshot(controller,gm);String afterJSON=json(after);out.put("controller_after_print_sha256",sha(afterJSON.getBytes(StandardCharsets.UTF_8)));require(beforeJSON.equals(afterJSON),"Native printer mutated controller graph");out.put("controller_export",writeJson("controller.json",after));out.put("status","JOB_CONTROLLER_PRINTED");
          pairedDiagnostics(mem,gm,controller);
        }
      }
      validationHealthy();checkOrigins(Paths.get(args[3]));extraOrigins();checkpoint("JOB_COMPLETE");
    }catch(Throwable e){exit=2;out.put("failed_stage",stage);out.put("status","UNKNOWN_RUNTIME_EXCEPTION");out.put("exception",e.toString());StringWriter sw=new StringWriter();e.printStackTrace(new PrintWriter(sw));out.put("stacktrace",sw.toString());checkpoint("UNKNOWN");}
    finally{checkpoint("TEARDOWN");try{if(pairedBefore!=null){pairedBefore.free();pairedBefore=null;}if(game!=null)game.free();if(gm!=null)gm.free();if(factory!=null)factory.done();out.put("teardown","COMPLETED");}catch(Throwable t){exit=3;out.put("status","UNKNOWN_TEARDOWN_EXCEPTION");out.put("teardown","FAILED");out.put("teardown_error",t.toString());}if(heapSampler!=null)heapSampler.cancel();checkpoint("PROCESS_FINISHED");
      Object variantReceipt=out.get("paired_intervention_result");
      if(variantReceipt!=null) {
        // Finish the actual variant result only after the one shared teardown.
        pendingVariantOutcome.put("teardown",out.get("teardown"));
        pendingVariantOutcome.put("stage","PROCESS_FINISHED");
        pendingVariantOutcome.put("shared_teardown_primary_result",filePin(receipt));
        if(exit!=0)pendingVariantOutcome.put("status","UNKNOWN_SHARED_PROCESS_FAILURE");
        Files.writeString(pendingVariantPath,json(pendingVariantOutcome)+"\n",StandardCharsets.UTF_8);
        Path shared=Paths.get(String.valueOf(variantReceipt)).getParent().resolve("SHARED_TEARDOWN.json");
        Files.writeString(shared,json(m("teardown",out.get("teardown"),"primary_result",filePin(receipt),
          "paired_process_total_controller_extractions",2,"process_exit_code",exit))+"\n",StandardCharsets.UTF_8);
      }
    }System.exit(exit);
  }

  static void validateEnum(Variable v,String name,List<String> values){
    TypeDef t=v.getType();require(v.getName().equals(name)&&!t.isBoolean()&&!t.isInteger()&&!t.isArray()&&values.equals(t.getValues()),"Unexpected exact source variable/type "+name);
  }
  static void validateSourceInventory(GameInput gi){
    require(gi.getEnv().getVars().size()==1&&gi.getSys().getVars().size()==1&&gi.getAux().getVars().isEmpty(),"Expected exactly one ENV and one SYS source field, no AUX");
    validateEnum(gi.getEnv().getVars().get(0),"floor",FLOOR_VALUES);validateEnum(gi.getSys().getVars().get(0),"elevMot",MOTOR_VALUES);
    for(Player p:Arrays.asList(gi.getEnv(),gi.getSys(),gi.getAux()))require(p.getPatterns().isEmpty()&&p.getTriggers().isEmpty()&&p.getExistentialConstraints().isEmpty(),"Unexpected source pattern/trigger/existential state");
  }
  static Set<String> names(PlayerModule p){Set<String>r=new LinkedHashSet<>();for(ModuleBDDField f:p.getAllFields())r.add(f.getName());return r;}
  static void nativeValues(String name,List<String> expected){require(new HashSet<>(Env.getValueNames(name)).equals(new HashSet<>(expected)),"Unexpected native typed values for "+name);}
  static void prepareResidualEntry(GameModel gm,String floor,String motor)throws Exception{
    require(names(gm.getEnv()).equals(new LinkedHashSet<>(Arrays.asList("floor","~envHelp")))&&names(gm.getSys()).equals(Collections.singleton("elevMot")),"Native field inventory differs from exact source plus helper");
    require(gm.getEnv().getAuxFields().isEmpty()&&gm.getSys().getAuxFields().isEmpty(),"Unexpected native AUX state");
    nativeValues("floor",FLOOR_VALUES);nativeValues("elevMot",MOTOR_VALUES);nativeValues("~envHelp",Arrays.asList("false","true"));
    sourceNativeInventory=modelInventory(gm);
    sourceInitializerBDDs=m("thetaE",snapshot("source_initializer_thetaE",gm.getEnv().initial()),"thetaS",snapshot("source_initializer_thetaS",gm.getSys().initial()));
    SavedState preserved=captureModel(gm,false);out.put("source_before_initializer_override",exportState("source_before_initializer_override",preserved));
    BDD entry=Env.TRUE();Map<String,Object>requested=m("floor",floor,"elevMot",motor,"~envHelp","false");
    for(Map.Entry<String,Object> e:requested.entrySet()){ModuleBDDField f=Env.getVar(e.getKey());require(f!=null&&!f.isPrime(),"Entry field not current");BDD literal=Env.getBDDValue(e.getKey(),String.valueOf(e.getValue()));require(literal!=null&&!literal.isZero(),"Entry literal absent");entry.andWith(literal.id());}
    currentOnly("residual entry",entry);require(!entry.isZero()&&requested.equals(singletonValuation(entry,gm)),"Entry not an exact full typed native valuation");
    BDD de=domain(gm.getEnv(),false),ds=domain(gm.getSys(),false),d=de.and(ds);require(subset(entry,d),"Residual entry outside typed domain");de.free();ds.free();d.free();
    BDDVarSet ev=gm.getEnv().moduleUnprimeVars(),sv=gm.getSys().moduleUnprimeVars();BDD entryE=entry.exist(sv),entryS=entry.exist(ev),join=entryE.and(entryS); // Module variable sets are borrowed caches; do not free them.
    require(join.equals(entry),"ENV/SYS entry projection join differs from singleton");join.free();
    boolean eMatch=subset(entry,gm.getEnv().initial()),sMatch=subset(entry,gm.getSys().initial());
    residualEntry=m("mode","exact_full_source_state_plus_native_helper_false","source_valuation",m("floor",floor,"elevMot",motor),"valuation",requested,"bits",stateBits(entry,gm),
      "source_initializer_match",m("ENV",eMatch,"SYS",sMatch,"joint",eMatch&&sMatch),"source_initializer_match_scope","Original transformed theta evaluated at exact source state plus helper=false","private_memory",m("policy","new_controller_rank0","rank",0,"source_history_reset",false),
      "complete_cube",snapshot("entry_cube",entry),"ENV_projection",snapshot("entry_ENV",entryE),"SYS_projection",snapshot("entry_SYS",entryS),"projection_join_equal",true,"typed_singleton",true,"helper_initial_value","false","original_initializers_reapplied",false);
    // Only these two setters change the generated game. All source histories are in entry.
    gm.getEnv().resetInitial();gm.getEnv().conjunctInitial(entryE.id());gm.getSys().resetInitial();gm.getSys().conjunctInitial(entryS.id());
    require(gm.getEnv().initial().equals(entryE)&&gm.getSys().initial().equals(entryS),"Residual initializers differ from exact projections");
    out.put("initializer_override_preservation",verifyUnchanged("source_after_initializer_override",preserved,captureModel(gm,false)));preserved.free();
    out.put("entry",residualEntry);out.put("source_initializer_bdds",sourceInitializerBDDs);out.put("source_initializer_semantics","Original transformed theta after released syntactic reduction/default translators, saved before residual override");out.put("initializers_replaced",true);entry.free();entryE.free();entryS.free();
  }
  static final class SavedState {
    final Map<String,BDD> bdds=new LinkedHashMap<>();
    final Map<String,Object> structure=new LinkedHashMap<>();
    void free(){for(BDD b:bdds.values())b.free();bdds.clear();}
  }
  static void collectMemory(String label,Object value,SavedState saved) {
    if(value==null){saved.structure.put(label,"null");return;}
    if(value instanceof BDD){saved.structure.put(label,"BDD");saved.bdds.put(label,((BDD)value).id());return;}
    if(value.getClass().isArray()) {
      int n=java.lang.reflect.Array.getLength(value);saved.structure.put(label,m("array_class",value.getClass().getName(),"length",n));
      for(int i=0;i<n;i++)collectMemory(label+"_"+i,java.lang.reflect.Array.get(value,i),saved);
    }else if(value instanceof List){List<?>xs=(List<?>)value;saved.structure.put(label,m("list_size",xs.size()));for(int i=0;i<xs.size();i++)collectMemory(label+"_"+i,xs.get(i),saved);
    }else if(value instanceof Boolean||value instanceof Number||value instanceof String){saved.structure.put(label,value);
    }else throw new IllegalArgumentException("Unexpected memory field "+label+" "+value.getClass().getName());
  }
  static SavedState captureModel(GameModel gm,boolean initial) {
    SavedState saved=new SavedState();
    for(boolean e:Arrays.asList(true,false)) {
      PlayerModule p=e?gm.getEnv():gm.getSys();String side=e?"ENV":"SYS";
      saved.structure.put(side+"_fields",fields(p));saved.structure.put(side+"_justice_count",p.justiceNum());
      if(initial)saved.bdds.put(side+"_initial",p.initial().id());saved.bdds.put(side+"_trans",p.trans().id());
      saved.bdds.put(side+"_current_domain",domain(p,false));saved.bdds.put(side+"_next_domain",domain(p,true));
      for(int i=0;i<p.justiceNum();i++)saved.bdds.put(side+"_justice_"+i,p.justiceAt(i).id());
    }
    saved.structure.put("bdd_variable_order",variableOrder(gm.getEnv().trans()));
    saved.structure.put("native_behavior_inventory",m("ENV",behaviors(gm.getEnvBehaviorInfo()),"SYS",behaviors(gm.getSysBehaviorInfo()),"AUX",behaviors(gm.getAuxBehaviorInfo())));
    return saved;
  }
  static SavedState captureMemoryAndModel(GR1Memory mem,GameModel gm)throws Exception {
    SavedState saved=captureModel(gm,true);saved.structure.put("memory_identity",System.identityHashCode(mem));saved.structure.put("model_identity",System.identityHashCode(gm));
    for(Class<?> c=mem.getClass();c!=Object.class;c=c.getSuperclass()) {
      java.lang.reflect.Field[] fs=c.getDeclaredFields();Arrays.sort(fs,Comparator.comparing(java.lang.reflect.Field::getName));
      for(java.lang.reflect.Field f:fs){if(java.lang.reflect.Modifier.isStatic(f.getModifiers()))continue;f.setAccessible(true);collectMemory(c.getSimpleName()+"_"+f.getName(),f.get(mem),saved);}
    }
    return saved;
  }
  static Map<String,Object> exportState(String label,SavedState saved)throws Exception{
    Map<String,Object>refs=new LinkedHashMap<>();for(Map.Entry<String,BDD>e:saved.bdds.entrySet())refs.put(e.getKey(),snapshot(label+"_"+e.getKey(),e.getValue()));
    return m("structure",saved.structure,"bdd_count",refs.size(),"bdds",refs);
  }
  static Map<String,Object> verifyUnchanged(String label,SavedState before,SavedState after)throws Exception{
    Map<String,Object>checks=new LinkedHashMap<>();boolean equal=before.bdds.keySet().equals(after.bdds.keySet()),shape=json(before.structure).equals(json(after.structure));
    for(String name:before.bdds.keySet()){boolean same=after.bdds.containsKey(name)&&before.bdds.get(name).equals(after.bdds.get(name));checks.put(name,same);equal &= same;}
    Map<String,Object>r=m("equal",equal&&shape,"structure_equal",shape,"BDD_equality_checks",checks,"snapshot",exportState(label,after));after.free();out.put(label,r);require(equal&&shape,label+" mutated memory/model/domain/order or structure");return r;
  }
  static List<Integer> variableOrder(BDD b) {
    List<Integer> order=new ArrayList<>();
    for(int i=0;i<b.getFactory().varNum();i++)order.add(b.getFactory().level2Var(i));
    return order;
  }

  static void pairedDiagnostics(GR1Memory mem,GameModel gm,EnumStrategyI nativeController)throws Exception {
    final String variantName="final_candidate_original_env_continuation_preference_v1";
    checkpoint("PAIRED_SELECTION_INTERVENTION_SAME_MEMORY_AND_MODEL");
    require(pairedBefore!=null,"Missing snapshot before baseline extraction");
    List<Integer> order=(List<Integer>)pairedBefore.structure.get("bdd_variable_order");
    GR1ContinuationPreferenceConstruction extractor=new GR1ContinuationPreferenceConstruction(mem,gm);
    out.put("paired_process_total_controller_extractions",2);EnumStrategyI changed=extractor.calculateConcreteController();
    Map<String,Object> variantParity=verifyUnchanged("after_variant_extraction",pairedBefore,captureMemoryAndModel(mem,gm));
    boolean memoryParity=Boolean.TRUE.equals(variantParity.get("equal"))&&Boolean.TRUE.equals(baselineParity.get("equal"));
    Object checks=variantParity.get("BDD_equality_checks");boolean orderParity=order.equals(variableOrder(mem.getWin()));
    require(memoryParity&&orderParity,"Paired extraction mutated saved pre-baseline memory/model/order");
    Path nativeReceipt=receipt, nativeDir=receipt.getParent();
    Path variantDir=nativeDir.getParent().resolve("variant");Files.createDirectory(variantDir);
    try(java.nio.file.DirectoryStream<Path> files=Files.newDirectoryStream(nativeDir)) {
      for(Path file:files)if(file.getFileName().toString().endsWith(".bdd")||file.getFileName().toString().equals("model.json"))
        Files.copy(file,variantDir.resolve(file.getFileName()));
    }
    Map<String,Object> nativeOut=new LinkedHashMap<>(out);
    Map<String,Object> configuration=new LinkedHashMap<>((Map<String,Object>)out.get("configuration"));
    configuration.put("extractor_strategy","experimental:"+variantName);
    out.put("configuration",configuration);
    out.put("schema","residual-entry-experimental-result-v1");
    out.put("pipeline","residual_entry_released_syntactic_4fp_experimental_extractor");
    out.put("nonrelease_extractor",true);
    out.put("variant_name",variantName);
    out.put("extractor_variant",variantName);
    out.put("experimental_extractor_class_identity",identity(extractor.getClass()));
    out.put("experimental_class_identities",Arrays.asList(identity(extractor.getClass())));
    out.put("paired_process_total_controller_extractions",2);
    out.put("counts_scope","This variant arm; same process also performed one unchanged baseline extraction.");
    out.put("baseline_controller_pin",filePin(nativeDir.resolve("controller.json")));
    receipt=variantDir.resolve("result.json");
    Map<String,Object> graph=controllerSnapshot(changed,gm);
    graph.put("schema","residual-entry-experimental-complete-controller-v1");
    graph.put("nonrelease_extractor",true);
    graph.put("variant_name",variantName);
    graph.put("extractor_variant",variantName);
    graph.put("helper_policy","complete_experimental_graph_with_native_helper");
    String beforeJSON=json(graph);
    out.put("controller_before_print_sha256",sha(beforeJSON.getBytes(StandardCharsets.UTF_8)));
    Path printer=variantDir.resolve("controller.txt");
    try(PrintStream stream=new PrintStream(Files.newOutputStream(printer),false,StandardCharsets.UTF_8)){
      new SimpleTextPrinter().printController(stream,changed);
      if(stream.checkError())throw new IOException("Variant printer output stream error");
    }
    Map<String,Object> graphAfter=controllerSnapshot(changed,gm);
    graphAfter.put("schema","residual-entry-experimental-complete-controller-v1");
    graphAfter.put("nonrelease_extractor",true);graphAfter.put("variant_name",variantName);
    graphAfter.put("extractor_variant",variantName);
    graphAfter.put("helper_policy","complete_experimental_graph_with_native_helper");
    String afterJSON=json(graphAfter);
    require(beforeJSON.equals(afterJSON),"Variant printer mutated graph");
    out.put("controller_after_print_sha256",sha(afterJSON.getBytes(StandardCharsets.UTF_8)));
    out.put("controller_export",writeJson("controller.json",graphAfter));
    out.put("printed_controller",filePin(printer));
    out.put("selection_preference",snapshot("selection_preference",extractor.getContinuationPreference()));
    Map<String,Object> diagnostic=m("variant_name",variantName,"nonrelease_extractor",true,
      "intervention","conditional preference immediately before transition satOne only",
      "same_memory_object",pairedBefore.structure.get("memory_identity").equals(System.identityHashCode(mem)),"same_model_object",pairedBefore.structure.get("model_identity").equals(System.identityHashCode(gm)),
      "memory_and_model_all_BDDs_equal",memoryParity,"BDD_equality_checks",checks,"comparison_reference","before_any_extraction","baseline_BDD_equality_checks",baselineParity.get("BDD_equality_checks"),"baseline_parity",baselineParity,"variant_parity",variantParity,
      "before_baseline_snapshot_BDD_count",pairedBefore.bdds.size(),"after_baseline_snapshot_BDD_count",((Map<?,?>)baselineParity.get("snapshot")).get("bdd_count"),"after_variant_snapshot_BDD_count",((Map<?,?>)variantParity.get("snapshot")).get("bdd_count"),
      "variable_order_unchanged",orderParity,"bdd_variable_order",order,
      "experimental_extractor_class",identity(extractor.getClass()),
      "examined_candidates",extractor.getExaminedCandidates(),
      "refined_candidates",extractor.getRefinedCandidates(),
      "no_preferred_candidate_fallbacks",extractor.getNoPreferredCandidate(),
      "native_graph_states",nativeController.numOfStates(),"native_graph_edges",nativeController.numOfTransitions(),
      "variant_graph_states",changed.numOfStates(),"variant_graph_edges",changed.numOfTransitions(),
      "claim_scope","Instance-directed choice intervention; one-step continuation preference is not a general fair-continuation proof.");
    out.put("paired_intervention",writeJson("paired_intervention.json",diagnostic));
    out.put("status","JOB_CONTROLLER_PRINTED");
    // Shared teardown follows once both records are complete. Parent verifies
    // the primary final receipt before accepting this variant's paired binding.
    out.put("teardown","SHARED_TEARDOWN_PENDING");
    checkpoint("VARIANT_EXPORTED_AWAITING_SHARED_TEARDOWN");
    Path pendingVariantReceipt=receipt;
    pendingVariantPath=receipt;pendingVariantOutcome=new LinkedHashMap<>(out);
    receipt=nativeReceipt;out.clear();out.putAll(nativeOut);
    out.put("paired_intervention_result",pendingVariantReceipt.toString());
    out.put("paired_process_total_controller_extractions",2);
    out.put("counts_scope","This baseline arm; same process also performed one experimental extraction.");
    pairedBefore.free();pairedBefore=null;
  }
}
