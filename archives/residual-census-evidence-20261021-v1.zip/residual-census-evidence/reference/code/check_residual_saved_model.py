"""Residual-entry audit against pinned saved original BDDs; no producer calls.

CLI: python -I -S -B check_residual_saved_model.py ARM ENTRY_JSON OUTPUT_JSON
This checker preserves public residual schemas. An internal copy maps only
residual_bdds to the generic decoder's formula slot; no artifact is rewritten.
The other audit route derives source equations and uses a different evaluator.
"""
from collections import defaultdict, deque
from itertools import product
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import re
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
VENDOR = HERE / 'vendor_saved_model'
HELPER_PINS = {
    'generic_base.py': '3c465e4253712c6f021920e6a164ef48c63c5bf6cfb3432d17ab95fb5778ebda',
    'vendor/bdd_core.py': 'f9497519b8a073a29e5748c908cadc804f437080cf12d36558d9e0210462dbac',
    'vendor/graph_fairness.py': '3da6d64631bd88ae0bda4ad71ccc37c46f48de233a51dcc843a476e391981d45',
}
SOURCE_SHA = 'b80b321c90e862fd688d85bd9bc93fe1a6b6aa12e7f039d44d0437bc84d9da15'
SOURCE_BYTES = 732
ORIGINAL = WORK / 'experiment/seams_research_reframing_20261017/kind_corpus_rle/runs/corpus032__original'
ORIGINAL_MODEL_SHA = '2e390c9b790d464f354dc77b2c7b11a3561739c4042ac33d8a67da98579aaf2e'
REGION = WORK / 'experiment/seams_research_reframing_20261017/kind_corpus_symbolic_independent/runs/v2/corpus032__original/RESULT.json'
REGION_SHA = '23c42a41ab32cf5aa0009fc30beebda1995c59ae3121481385162dbbed278436'
CASE = 'corpus032__original'
HELPER = '~envHelp'
EXPERIMENT = 'final_candidate_original_env_continuation_preference_v1'
FLOORS = {'LOWER', 'MIDDLE', 'UPPER', 'NONE'}
MOTORS = {'FWD', 'BWD', 'STOP'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def pin(path):
    path = Path(path).resolve()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


for _name, _digest in HELPER_PINS.items():
    if sha(VENDOR / _name) != _digest:
        raise ValueError('Frozen saved-model helper drift: ' + _name)
_spec = importlib.util.spec_from_file_location('v46_saved_generic', VENDOR / 'generic_base.py')
base = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(base)
need, read, pinned = base.require, base.read_json, base.pinned_file


class ControllerDefect(ValueError):
    pass


def obligation(condition, message):
    if not condition:
        raise ControllerDefect(message)


def reach(starts, edges):
    adj = defaultdict(list)
    for a, z in edges:
        adj[a].append(z)
    seen, todo = set(starts), deque(starts)
    while todo:
        for nxt in adj[todo.popleft()]:
            if nxt not in seen:
                seen.add(nxt)
                todo.append(nxt)
    return seen


def assignments(ctx, names=None):
    names = list(ctx.by_name) if names is None else list(names)
    return [dict(zip(names, xs)) for xs in product(*(ctx.by_name[n]['values'] for n in names))]


def evaluate(ctx, formula, current, successor=None):
    bits = ctx.bits(current)
    if successor is not None:
        bits.update(ctx.bits(successor, True))
    return ctx.b.evaluate(formula, bits)


def read_entry(path):
    entry = read(path)
    need(entry.get('schema') == 'v46-residual-entry-v1', 'Entry manifest schema')
    need(type(entry.get('id')) is str and entry['id'], 'Entry ID')
    state = entry['full_original_state']
    need(isinstance(state, dict) and set(state) == {'floor', 'elevMot'}, 'Complete source entry fields')
    need(state['floor'] in FLOORS and state['elevMot'] in MOTORS, 'Typed source entry')
    need(entry.get('source_valuation', state) == state, 'Conflicting entry aliases')
    need(entry.get('logical_AUX') == {}, 'No source AUX in exact032')
    need(entry.get('helper_at_residual_entry') is False, 'Residual helper false')
    need(entry.get('original_I_M_K') is False, 'Original source initializer verdict remains false')
    need(entry.get('private_memory_policy') == 'new_controller_rank0', 'Declared new private rank policy')
    need(type(entry.get('original_initializer_compatible')) is bool, 'Initial compatibility metadata')
    source = entry['source']
    need(source['sha256'] == SOURCE_SHA and source['bytes'] == SOURCE_BYTES, 'Exact original source pin')
    base.pin_path(source)
    original_source = entry['original_source']
    need(original_source['sha256'] == SOURCE_SHA and original_source['bytes'] == SOURCE_BYTES, 'Historical original source pin')
    base.pin_path(original_source)
    return entry, state


def residual_identity(item):
    need(item.get('fixture_id') == item.get('case_id') == CASE and item.get('variant') == 'residual_entry', 'Residual case identity')
    need(item.get('initializers_replaced') is True and item.get('initialization') == 'exact_full_state_residual_entry', 'Explicit residual initialization')
    verdict = item.get('saved_original_source_initial_verdict')
    if item.get('schema') in ('residual-entry-native-model-v1', 'residual-entry-native-result-v1', 'residual-entry-experimental-result-v1'):
        need(isinstance(verdict, dict), 'Explicit saved original initializer verdict required')
    if verdict is not None:
        need(verdict.get('predicate') == 'I_M(K)' and verdict.get('value') is False
             and verdict.get('recomputed_in_this_process') is False
             and verdict.get('evidence_sha256') == REGION_SHA, 'Saved source initial verdict binding')


def audit_models(arm, result, entry, state, certificate):
    need(sha(ORIGINAL / 'model.json') == ORIGINAL_MODEL_SHA, 'Saved original model byte identity')
    need(sha(REGION) == REGION_SHA, 'Saved region certificate byte identity')
    prior = read(REGION)
    need(prior['status'] == 'PASS' and prior['initial_quantification']['K']['value'] is False, 'Saved original I_M(K)=false')
    original_model = read(ORIGINAL / 'model.json')
    profile = {k: original_model[k] for k in ('fixture_id', 'case_id', 'variant')}
    profile['source'] = entry['original_source']
    original = base.Context(ORIGINAL, profile, original_model)
    certificate['saved_original_model_audit'] = original.audit_model()
    need(original.carrier == 12 and set(original.by_name) == {'floor', 'elevMot'}, 'Exact saved032 carrier')
    need(original.by_name['floor']['owner'] == 'ENV' and original.by_name['floor']['role'] == 'ENV'
         and set(original.by_name['floor']['values']) == FLOORS, 'Saved floor field')
    need(original.by_name['elevMot']['owner'] == 'SYS' and original.by_name['elevMot']['role'] == 'SYS'
         and set(original.by_name['elevMot']['values']) == MOTORS, 'Saved motor field')
    model_path = pinned(arm, result['model_export'])
    need(model_path.name == 'model.json', 'Canonical model filename')
    model = read(model_path)
    need(model.get('schema') == 'residual-entry-native-model-v1', 'Residual model schema')
    residual_identity(model)
    need('original_bdds' not in model, 'Residual artifact must not claim source original initializers')
    internal = copy.deepcopy(model)
    internal['schema'] = 'k7-native-model-export-v1'
    internal['original_bdds'] = internal.pop('residual_bdds')
    need('native_behaviors' not in model['source_inventory'], 'Residual native inventory must retain pre-override provenance')
    internal['source_inventory']['native_behaviors'] = internal['source_inventory'].pop('native_behaviors_before_initializer_override')
    job_profile = {k: model[k] for k in ('fixture_id', 'case_id', 'variant')}
    job_profile['source'] = entry['source']
    job = base.Context(arm, job_profile, internal)
    certificate['residual_typed_model_audit'] = job.audit_model()
    need(job.carrier == 24 and set(job.by_name) == {'floor', 'elevMot', HELPER}, 'Exact residual carrier with native helper')
    for name, field in original.by_name.items():
        changed = job.by_name[name]
        need((field['owner'], field['role'], set(field['values'])) ==
             (changed['owner'], changed['role'], set(changed['values'])), 'Preserved typed source field ' + name)
    helper = job.by_name[HELPER]
    need((helper['owner'], helper['role'], set(helper['values'])) == ('ENV', 'ENV', {'false', 'true'}), 'Native helper type/ownership')
    need(result.get('helper_added') is True and result.get('helper_is_native_nonaux_ENV') is True, 'Observed native helper')
    need(result.get('input_sha256') == SOURCE_SHA and model['input']['sha256'] == SOURCE_SHA, 'Result/model source identity')
    need(model['source_inventory']['parsed'] == original_model['source_inventory']['parsed'], 'Unchanged parsed source inventory')

    current_states = assignments(job)
    source_initial = model['source_initializer_bdds']
    need(set(source_initial) == {'thetaE', 'thetaS'}, 'Original source initializer roster')
    initial = {k: job.read_bdd(source_initial[k], job.current_env if k == 'thetaE' else job.current) for k in source_initial}
    # Entire typed domain, including both helper values. The reduction equation
    # is applied to saved original predicates, not re-derived source syntax.
    for s in current_states:
        os = {k: s[k] for k in original.by_name}
        h = s[HELPER] == 'true'
        need(evaluate(job, initial['thetaE'], s) ==
             (evaluate(original, original.formulas['thetaE'], os) and not h), 'Saved original ENV initializer correspondence')
        need(evaluate(job, initial['thetaS'], s) == evaluate(original, original.formulas['thetaS'], os), 'Saved original SYS initializer correspondence')
        for t in current_states:
            ot = {k: t[k] for k in original.by_name}
            hn = t[HELPER] == 'true'
            expected_e = (evaluate(original, original.formulas['rhoE'], os, ot) or hn) and (not h or hn)
            expected_s = evaluate(original, original.formulas['rhoS'], os, ot)
            need(evaluate(job, job.formulas['rhoE'], s, t) == expected_e, 'Whole typed original/reduced rhoE correspondence')
            need(evaluate(job, job.formulas['rhoS'], s, t) == expected_s, 'Whole typed original/reduced rhoS correspondence')
    need(len(original.justices['ENV']) == 0 and len(original.justices['SYS']) == 3, 'Saved original ordered justice counts')
    need(len(job.justices['ENV']) == 1 and len(job.justices['SYS']) == 3, 'Residual ordered justice counts')
    for s in current_states:
        os = {k: s[k] for k in original.by_name}
        need(evaluate(job, job.justices['ENV'][0], s) == (s[HELPER] == 'false'), 'Exact inserted helper justice')
        for index, oldj in enumerate(original.justices['SYS']):
            need(evaluate(job, job.justices['SYS'][index], s) == evaluate(original, oldj, os), 'Saved original SYS justice identity/order')
    for owner in ('ENV', 'SYS'):
        for label in ('preconstructor_justices', 'solver_justices'):
            refs = result[label][owner]
            need(len(refs) == len(job.justices[owner]), 'Ordered native justice roster')
            need([job.read_bdd(ref, job.current) for ref in refs] == job.justices[owner], 'Exact native justice BDD identity/order')

    expected = {**state, HELPER: 'false'}
    need(result['entry'] == model['entry'], 'Result/model complete entry metadata')
    e = model['entry']
    need(e['mode'] == 'exact_full_source_state_plus_native_helper_false'
         and e['source_valuation'] == state and e['valuation'] == expected, 'Exact residual source/helper entry')
    need(e['private_memory'] == {'policy': 'new_controller_rank0', 'rank': 0, 'source_history_reset': False}, 'Only fresh private rank initialized')
    need(e['typed_singleton'] is True and e['projection_join_equal'] is True
         and e['helper_initial_value'] == 'false' and e['original_initializers_reapplied'] is False, 'Residual entry semantics')
    need(base.bit_map(e['bits'], job.current, 'Entry bits') == job.bits(expected), 'Entry value/bit identity')
    cube = job.cube(expected)
    env_cube = job.cube({n: expected[n] for n in job.env})
    sys_cube = job.cube({n: expected[n] for n in job.sys})
    need(job.formulas['thetaE'] == env_cube and job.formulas['thetaS'] == sys_cube, 'Exact singleton residual initializers')
    need(job.b.conj(env_cube, sys_cube) == cube, 'Residual initializer projection join')
    for key, value, allowed in [('complete_cube', cube, job.current), ('ENV_projection', env_cube, job.current_env), ('SYS_projection', sys_cube, job.current_sys)]:
        need(job.read_bdd(e[key], allowed) == value, 'Entry BDD pin/equation ' + key)
    matches = {o: evaluate(job, initial['theta' + o[0]], expected) for o in ('ENV', 'SYS')}
    matches['joint'] = matches['ENV'] and matches['SYS']
    need(e['source_initializer_match'] == matches and entry['original_initializer_compatible'] is matches['joint'], 'Source initializer compatibility independently checked')
    certificate['model_correspondence'] = {
        'status': 'PASS', 'typed_current_states': 24, 'typed_transition_pairs': 576,
        'original_source_initializers_bound_separately': True,
        'residual_initializers_exact_singleton': True,
        'original_rho_and_ordered_justice_correspondence': 'Whole typed domain, with exact native helper reduction',
        'decoder_adapter': 'Internal deep copy only: residual_bdds becomes generic Context formula slot and native_behaviors_before_initializer_override becomes its inventory slot; public artifacts unchanged.',
        'source_initializer_match': matches,
    }
    return original, job, model


def audit_snapshots(job, result, has_graph=True):
    def snapshot_values(snapshot):
        need(isinstance(snapshot['structure'], dict) and isinstance(snapshot['bdds'], dict) and snapshot['bdds'], 'Complete snapshot structure/BDD roster')
        need(type(snapshot.get('bdd_count')) is int and snapshot['bdd_count'] == len(snapshot['bdds']), 'Exact snapshot BDD count')
        return {k: job.read_bdd(v) for k, v in snapshot['bdds'].items()}

    def compare(before, after):
        need(after.get('equal') is True and after.get('structure_equal') is True, 'Producer parity receipt')
        need(before['structure'] == after['snapshot']['structure'], 'Exact model/memory structure parity')
        a, b = snapshot_values(before), snapshot_values(after['snapshot'])
        need(a == b, 'Independent saved model/memory BDD parity')
        need(after['BDD_equality_checks'] == {k: True for k in a}, 'Exact parity check roster')
        return len(a)

    before_body = result['source_before_initializer_override']
    count_body = compare(before_body, result['source_after_initializer_override'])
    need(result['initializer_override_preservation'] == result['source_after_initializer_override'], 'Initializer preservation receipt identity')
    expected_body = {'ENV_trans': job.formulas['rhoE'], 'SYS_trans': job.formulas['rhoS'],
        'ENV_current_domain': job.domain_ec, 'SYS_current_domain': job.domain_sc,
        'ENV_next_domain': job.domain_en, 'SYS_next_domain': job.domain_sn}
    for owner in ('ENV', 'SYS'):
        expected_body.update({owner + '_justice_' + str(i): j for i, j in enumerate(job.justices[owner])})
    need(snapshot_values(before_body) == expected_body, 'Complete unchanged-body snapshot bound to residual model')
    if not has_graph:
        return {'status': 'PASS', 'body_snapshot_BDDs': count_body, 'memory_model_snapshot_BDDs': None,
                'no_extraction_snapshots_expected': True}
    before = result['before_any_extraction']
    structure = before['structure']
    need(structure['memory_identity'] == result['native_memory_identity']
         and structure['model_identity'] == result['native_model_identity'], 'Pre-baseline solver object identity')
    need(structure['bdd_variable_order'] == job.model['bdd_variable_order'], 'Snapshot variable order/model identity')
    for prefix in ('GR1Memory_x_mem', 'GR1Memory_y_mem', 'GR1Memory_z_mem'):
        need(prefix in structure, 'Missing complete memory array structure ' + prefix)
    count_memory = compare(before, result['after_baseline_extraction'])
    compare(before, result['after_variant_extraction'])
    need(result['baseline_memory_model_parity'] == result['after_baseline_extraction'], 'Baseline parity receipt identity')
    roots = snapshot_values(before)
    need(all(roots.get(k) == v for k, v in expected_body.items()),
         'Pre-baseline complete model body/domain snapshot bound to residual model')
    expected_roots = set(expected_body) | {'ENV_initial', 'SYS_initial'}
    memory_roots = {k for k, v in structure.items() if v == 'BDD'}
    need(memory_roots and set(roots) == expected_roots | memory_roots,
         'Exact complete model and memory snapshot BDD roster')
    for prefix in ('GR1Memory_x_mem', 'GR1Memory_y_mem', 'GR1Memory_z_mem'):
        need(any(k.startswith(prefix + '_') for k in memory_roots), 'Nonempty native fixed-point memory ' + prefix)
    for owner, short in [('ENV', 'E'), ('SYS', 'S')]:
        need(roots[owner + '_initial'] == job.formulas['theta' + short], 'Snapshot residual initializer binding')
        need(roots[owner + '_trans'] == job.formulas['rho' + short], 'Snapshot original transition binding')
        need(structure[owner + '_justice_count'] == len(job.justices[owner]), 'Snapshot justice count')
        for i, j in enumerate(job.justices[owner]):
            need(roots[owner + '_justice_' + str(i)] == j, 'Snapshot ordered justice binding')
    return {'status': 'PASS', 'body_snapshot_BDDs': count_body, 'memory_model_snapshot_BDDs': count_memory,
            'comparison_reference': 'before_any_extraction', 'checked_after_baseline_and_after_variant': True}


def parse_printed(text, nodes):
    lines = text.splitlines()
    need(len(lines) == 2 * len(nodes), 'Complete printer line count')
    for index, node in enumerate(nodes):
        match = re.fullmatch(r'(Initial )?State ([0-9]+) (<[^<>]*>)', lines[2 * index])
        need(match is not None, 'Printer state syntax')
        need((match.group(1) is not None) == node['initial'] and int(match.group(2)) == index, 'Printer initial/ID binding')
        pairs = [x.split(':') for x in match.group(3)[1:-1].split(', ')]
        need(all(len(x) == 2 for x in pairs) and len(dict(pairs)) == len(pairs), 'Printer unique complete fields')
        need(dict(pairs) == node['valuation'] and match.group(3) == node['native_bdd_text'], 'Printer exact typed valuation')
        expected = '\tWith successors : ' + ', '.join(node['successors']) if node['successors'] else '\tWith no successors.'
        need(lines[2 * index + 1] == expected, 'Printer exact successor order')


def certify_graph(arm, result, original, job, state, experimental, certificate):
    graph_path = pinned(arm, result['controller_export'])
    need(graph_path.name == 'controller.json', 'Canonical graph filename')
    graph = read(graph_path)
    schema = 'residual-entry-experimental-complete-controller-v1' if experimental else 'residual-entry-complete-native-controller-v1'
    need(graph.get('schema') == schema and graph.get('complete') is True, 'Complete residual graph schema')
    residual_identity(graph)
    need(graph['entry'] == result['entry'], 'Graph/result entry binding')
    need(graph['model_sha256'] == sha(arm / 'model.json')
         and graph['native_memory_identity'] == result['native_memory_identity'], 'Graph/model/private memory binding')
    need(graph['rank_domain_size'] == 3 and type(graph['rank_domain_size']) is int, 'Exact native private rank domain')
    if experimental:
        need(graph.get('nonrelease_extractor') is True and graph.get('variant_name') == graph.get('extractor_variant') == EXPERIMENT, 'Experimental graph identity')
    need(result['controller_before_print_sha256'] == result['controller_after_print_sha256'], 'Printer did not mutate graph')
    # Producer hashes the exact emitted compact object without its final newline.
    raw = graph_path.read_bytes()
    need(raw.endswith(b'\n') and hashlib.sha256(raw[:-1]).hexdigest() == result['controller_after_print_sha256'], 'Printed graph digest binds actual bytes')
    nodes = graph['nodes']
    need(isinstance(nodes, list) and 0 < len(nodes) <= 4096 and len(nodes) == graph['api_state_count'], 'Complete graph node count/cap')
    index, pairs, memory = {}, [], set()
    for i, n in enumerate(nodes):
        need(n['id'] == str(i) and type(n['native_id']) is int and n['native_id'] == i, 'Canonical raw native IDs')
        need(type(n['initial']) is bool and type(n['rank']) is int and 0 <= n['rank'] < 3, 'Typed initial/private rank')
        need(n['rank_class'] == 'tau.smlab.syntech.games.gr1.GR1RankInfo' and n['rank_info'] == 'System Justice ' + str(n['rank']), 'Private rank class/text identity')
        job.valuation(n['valuation'], 'Full native graph node')
        key = (tuple(n['valuation'][k] for k in job.by_name), n['rank'])
        need(key not in memory, 'Duplicate source/helper/private-memory node')
        memory.add(key)
        need(base.bit_map(n['bits'], job.current, 'Node bits') == job.bits(n['valuation']), 'Graph typed value/bit identity')
        need(isinstance(n['successors'], list) and all(type(x) is str for x in n['successors'])
             and len(n['successors']) == len(set(n['successors'])), 'Unique typed successor roster')
        index[n['id']] = n
        pairs.extend([[n['id'], x] for x in n['successors']])
    need(len(pairs) <= 65536 and pairs == graph['edges'] and len(pairs) == graph['api_transition_count'], 'Complete edge export/count/cap')
    need(all(z in index for _, z in pairs), 'Known edge targets')
    starts = [n['id'] for n in nodes if n['initial']]
    obligation(len(starts) == 1 and index[starts[0]]['rank'] == 0
               and index[starts[0]]['valuation'] == {**state, HELPER: 'false'}, 'Exact residual initial state and fresh private rank0')
    need(reach(starts, pairs) == set(index), 'Every exported raw node reachable from residual initial')
    printed = pinned(arm, result['printed_controller'])
    parse_printed(printed.read_text(), nodes)

    def coverage(ctx, selected, edges, project):
        inputs = assignments(ctx, ctx.env)
        adjacency = defaultdict(list)
        for a, z in edges:
            adjacency[a].append(z)
        checks = 0
        for sid in sorted(selected):
            s = project(index[sid]['valuation'])
            expected = {tuple(e[n] for n in ctx.env) for e in inputs if evaluate(ctx, ctx.formulas['rhoE'], s, e)}
            seen = defaultdict(list)
            checks += len(inputs)
            for tid in adjacency[sid]:
                t = project(index[tid]['valuation'])
                obligation(evaluate(ctx, ctx.formulas['rhoE'], s, t), 'Graph retained edge violates ENV safety')
                obligation(evaluate(ctx, ctx.formulas['rhoS'], s, t), 'Graph retained edge violates SYS/source-history safety')
                seen[tuple(t[n] for n in ctx.env)].append(tid)
            obligation(set(seen) == expected, 'Graph missing or adding legal ENV responses')
            obligation(all(len(v) == 1 for v in seen.values()), 'Graph nondeterministic response/private-memory update')
        return checks

    raw_checks = coverage(job, set(index), pairs, lambda s: s)
    keep = {sid for sid, n in index.items() if n['valuation'][HELPER] == 'false'}
    zero = [e for e in pairs if e[0] in keep and e[1] in keep]
    reachable = reach(starts, zero)
    edges = [e for e in zero if e[0] in reachable]
    source = lambda s: {k: s[k] for k in original.by_name}
    original_checks = coverage(original, reachable, edges, source)
    view = {'states': sorted(reachable), 'starts': starts, 'edges': edges, 'env_justice': [], 'sys_justice': []}
    for owner, key in [('ENV', 'env_justice'), ('SYS', 'sys_justice')]:
        view[key] = [[sid for sid in sorted(reachable) if evaluate(original, j, source(index[sid]['valuation']))] for j in original.justices[owner]]
    fair = base.graph_analyzer()(view)
    certificate.update(derived_original_view=view, derived_fairness=fair,
                       strict_controller_pass=fair['strict_liveness']['pass'],
                       nonconflicting_pass=fair['nonconflicting']['pass'])
    certificate['graph_audit'] = {'raw_states': len(nodes), 'raw_edges': len(pairs),
        'original_states': len(reachable), 'original_edges': len(edges), 'initial_states': 1,
        'raw_input_checks': raw_checks, 'original_input_checks': original_checks,
        'all_fields_and_private_rank_preserved': True, 'graph_printer_identity': True,
        'mapping': 'Residual-singleton-reachable helper=false view; no state, edge or memory repair'}


def audit_result_identity(arm, r):
    experimental = r.get('schema') == 'residual-entry-experimental-result-v1'
    need(r.get('schema') in ('residual-entry-native-result-v1', 'residual-entry-experimental-result-v1'), 'Residual result schema')
    residual_identity(r)
    pipeline = 'residual_entry_released_syntactic_4fp_experimental_extractor' if experimental else 'residual_entry_released_syntactic_4fp_paired_extraction'
    need(r.get('pipeline') == pipeline and r.get('solver') == '4fp', 'Residual pipeline identity')
    status = r.get('status')
    need(status in ('JOB_CONTROLLER_PRINTED', 'JOB_UNREALIZABLE_NO_CONTROLLER', 'JOB_EMPTY_MEMORY_NO_CONTROLLER')
         and r.get('teardown') == 'COMPLETED' and r.get('native_solver_calls') == 1, 'Complete native residual route')
    if status == 'JOB_CONTROLLER_PRINTED':
        need(r.get('paired_process_total_controller_extractions') == 2, 'Complete two-extraction pair')
        need(r.get('native_residual_initial_verdict') is True and r.get('memory_complete') is True
             and r.get('memory_empty_guard_called') is True and r.get('memory_empty') is False, 'Residual extraction guard')
        need(r.get('controller_extraction_calls') == r.get('native_printer_calls') == 1, 'One extraction/printer per arm')
        need(r.get('same_native_memory_passed_to_constructor') is True and r.get('same_native_model_passed_to_constructor') is True, 'Live memory/model constructor identity')
    else:
        need(not experimental and r.get('controller_extraction_calls') == r.get('native_printer_calls') == 0
             and r.get('controller_export') is None and not (arm / 'controller.json').exists(), 'No-controller route has no graph/extraction')
        if status == 'JOB_UNREALIZABLE_NO_CONTROLLER':
            need(r.get('native_residual_initial_verdict') is False and r.get('memory_empty_guard_called') is False, 'Declared native false route')
        else:
            need(r.get('native_residual_initial_verdict') is True and r.get('memory_empty_guard_called') is True
                 and r.get('memory_empty') is True, 'Declared empty-memory route')
    need(r.get('semantic_reduction_used') is False and r.get('ENV_justice_normalization_used') is False
         and r.get('GUI_execution') is False, 'No additional reduction or justice normalization')
    expected = {'release': '1.0.0.202402072123', 'BDDPackage': 'JTLV', 'BDDPackageVersion': 'DEFAULT',
        'synthesisMethod': 'synthesisPitermanReduction', 'ConcreteControllerFormat': 'JTLV',
        'optChoice': 'none', 'reorderChoice': 'none', 'groupVars': False, 'TraceInfo': 'NONE',
        'TransFuncType': 'SINGLE_FUNC', 'extractor_strategy': 'experimental:' + EXPERIMENT if experimental else 'native_two_argument_default_ZYX'}
    need(r.get('configuration') == expected and r.get('observed_backend') == 'net.sf.javabdd.JTLVJavaFactory', 'Exact frozen native configuration/Java backend')
    if experimental:
        need(r.get('nonrelease_extractor') is True and r.get('variant_name') == r.get('extractor_variant') == EXPERIMENT, 'Experimental result identity')
        diagnostic = read(pinned(arm, r['paired_intervention']))
        need(diagnostic.get('variant_name') == EXPERIMENT and diagnostic.get('nonrelease_extractor') is True
             and diagnostic.get('comparison_reference') == 'before_any_extraction'
             and diagnostic.get('same_memory_object') is True and diagnostic.get('same_model_object') is True
             and diagnostic.get('memory_and_model_all_BDDs_equal') is True and diagnostic.get('variable_order_unchanged') is True, 'Paired intervention evidence')
        need(diagnostic['baseline_parity'] == r['after_baseline_extraction']
             and diagnostic['variant_parity'] == r['after_variant_extraction'], 'Diagnostic exact parity bindings')
        need(r['experimental_extractor_class_identity']['class'] == 'tau.smlab.syntech.games.gr1.GR1ContinuationPreferenceConstruction'
             and r['experimental_class_identities'] == [r['experimental_extractor_class_identity']]
             and diagnostic['experimental_extractor_class'] == r['experimental_extractor_class_identity'], 'Exact experimental class metadata')
        native = arm.parent / 'native'
        primary = read(pinned(native, r['shared_teardown_primary_result']))
        need(primary.get('schema') == 'residual-entry-native-result-v1' and primary.get('status') == 'JOB_CONTROLLER_PRINTED'
             and primary.get('teardown') == 'COMPLETED' and primary['entry'] == r['entry'], 'Shared primary completion/entry')
        need(primary['native_memory_identity'] == r['native_memory_identity']
             and primary['native_model_identity'] == r['native_model_identity'], 'Shared primary object identity')
        need(pinned(native, r['baseline_controller_pin']).name == 'controller.json', 'Actual baseline controller pin')
        shared = read(arm / 'SHARED_TEARDOWN.json')
        need(shared.get('teardown') == 'COMPLETED' and shared.get('process_exit_code') == 0
             and shared.get('paired_process_total_controller_extractions') == 2
             and shared.get('primary_result') == r['shared_teardown_primary_result'], 'Shared pair teardown receipt')
    return experimental


def check(arm, entry_path):
    arm, entry_path = Path(arm).resolve(), Path(entry_path).resolve()
    certificate = {'schema': 'v46-residual-saved-model-graph-certificate-v1', 'status': 'UNKNOWN_INTEGRITY',
        'source_initial_K_verdict': False, 'strict_controller_pass': None, 'nonconflicting_pass': None,
        'native_runs': 0, 'trust_boundary': 'Exact saved original source BDDs and shared source compilation; independent typed decoding, whole-domain correspondence and generic finite-graph fairness. This route does not independently compile source syntax.',
        'scope': 'Exact residual entry with new private rank0; no executed old-controller handoff or changed original initial-feasibility verdict.'}
    stage = 'integrity'
    try:
        entry, state = read_entry(entry_path)
        certificate['entry_id'] = entry['id']
        paths = [entry_path, Path(entry['source']['path']), Path(entry['original_source']['path']), ORIGINAL / 'model.json', REGION]
        paths += sorted(ORIGINAL.glob('*.bdd'))
        paths += [p for p in sorted(arm.iterdir()) if p.is_file() and p.suffix in ('.json', '.bdd', '.txt')]
        if arm.name == 'variant':
            paths += [arm.parent / 'native' / name for name in ('result.json', 'controller.json')]
        frozen = [pin(p) for p in paths]
        r = read(arm / 'result.json')
        experimental = audit_result_identity(arm, r)
        stage = 'model'
        original, job, model = audit_models(arm, r, entry, state, certificate)
        stage = 'integrity'
        has_graph = r['status'] == 'JOB_CONTROLLER_PRINTED'
        certificate['memory_model_parity'] = audit_snapshots(job, r, has_graph)
        stage = 'graph'
        if has_graph:
            certify_graph(arm, r, original, job, state, experimental, certificate)
        need([pin(Path(x['path'])) for x in frozen] == frozen, 'Audit inputs changed during evaluation')
        certificate.update(status='COMPLETE_RESIDUAL_GRAPH_CERTIFICATE' if has_graph else 'COMPLETE_RESIDUAL_NO_CONTROLLER_DECLARED', input_pins=frozen,
                           bound_artifacts_unchanged_after_audit=True)
        if not has_graph:
            certificate['refusal_scope'] = 'Selected native route returned no controller; no independent residual-source infeasibility or solver truth claim.'
    except ControllerDefect as error:
        try:
            need([pin(Path(x['path'])) for x in frozen] == frozen, 'Audit inputs changed during graph evaluation')
            certificate.update(status='COMPLETE_RESIDUAL_CONTROLLER_DEFECT', controller_defect=str(error),
                               input_pins=frozen, bound_artifacts_unchanged_after_audit=True)
        except (OSError, ValueError, base.Invalid) as integrity_error:
            certificate.update(status='UNKNOWN_INTEGRITY', error=str(integrity_error))
    except base.ResourceRefusal as error:
        certificate.update(status='UNKNOWN_RESOURCE', error=str(error))
    except (base.Invalid, OSError, UnicodeError, ValueError, KeyError, TypeError, IndexError, AttributeError, RecursionError) as error:
        certificate.update(status='UNKNOWN_MODEL_BINDING' if stage == 'model' else 'UNKNOWN_INTEGRITY', error=type(error).__name__ + ': ' + str(error), failure_stage=stage)
    return certificate


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) != 3:
        raise SystemExit('usage: check_residual_saved_model.py ARM ENTRY_JSON OUTPUT_JSON')
    result = check(argv[0], argv[1])
    output = Path(argv[2])
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x') as stream:
        json.dump(result, stream, indent=2, ensure_ascii=False)
        stream.write('\n')
    print(json.dumps({k: result.get(k) for k in ('status', 'entry_id', 'strict_controller_pass', 'nonconflicting_pass', 'error', 'controller_defect')}))
    return 0 if result['status'] in ('COMPLETE_RESIDUAL_GRAPH_CERTIFICATE', 'COMPLETE_RESIDUAL_CONTROLLER_DEFECT', 'COMPLETE_RESIDUAL_NO_CONTROLLER_DECLARED') else 2


if __name__ == '__main__':
    raise SystemExit(main())
