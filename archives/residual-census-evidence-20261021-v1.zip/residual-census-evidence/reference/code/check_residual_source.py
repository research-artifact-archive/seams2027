#!/usr/bin/env python3
"""Source-specific residual graph certificate for the pinned public Elevator032.

CLI: check_residual_source.py arm_dir entry_json output_json

This is an independent finite semantic oracle, not a Spectra compiler. It reads
the exact pinned source, evaluates manually transcribed source equations, reads
native BDD dumps without a BDD library, and implements graph analysis locally.
It does not invoke a solver, producer, compiler, or another graph checker.
"""
from __future__ import annotations

import argparse
from collections import defaultdict, deque
import datetime
import hashlib
import itertools
import json
from pathlib import Path
import re

SOURCE_SHA = "b80b321c90e862fd688d85bd9bc93fe1a6b6aa12e7f039d44d0437bc84d9da15"
SOURCE_BYTES = 732
FLOORS = ("LOWER", "MIDDLE", "NONE", "UPPER")
MOTORS = ("BWD", "FWD", "STOP")
HELPER = "~envHelp"
VALUES = {"floor": FLOORS, HELPER: ("false", "true"), "elevMot": MOTORS}
OWNERS = {"floor": "ENV", HELPER: "ENV", "elevMot": "SYS"}
MAX_FILE = 8 * 1024 * 1024
MAX_STATES = 4096
MAX_EDGES = 65536


class CheckError(Exception):
    def __init__(self, code, detail=None, status="UNKNOWN_INTEGRITY"):
        super().__init__(code)
        self.code, self.detail, self.status = code, detail, status


def require(test, code, detail=None, status="UNKNOWN_INTEGRITY"):
    if not test:
        raise CheckError(code, detail, status)


def defect(test, code, detail=None):
    require(test, code, detail, "COMPLETE_RESIDUAL_CONTROLLER_DEFECT")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def file_pin(path):
    path = Path(path)
    data = path.read_bytes()
    require(len(data) <= MAX_FILE, "FILE_BUDGET", str(path), "UNKNOWN_RESOURCE")
    return {"path": str(path.resolve()), "bytes": len(data), "sha256": sha(data)}


def read_json(path):
    path = Path(path)
    data = path.read_bytes()
    require(len(data) <= MAX_FILE, "JSON_BUDGET", str(path), "UNKNOWN_RESOURCE")
    def unique(pairs):
        out = {}
        for key, value in pairs:
            require(key not in out, "DUPLICATE_JSON_KEY", key)
            out[key] = value
        return out
    return json.loads(data, object_pairs_hook=unique)


def pinned_path(folder, ref):
    require(isinstance(ref, dict), "PIN_NOT_OBJECT")
    name = ref.get("file")
    require(type(name) is str and Path(name).name == name and name not in ("", ".", ".."), "PIN_NOT_LOCAL_FILE", name)
    path = folder / name
    actual = file_pin(path)
    require(type(ref.get("bytes")) is int and ref["bytes"] == actual["bytes"] and ref.get("sha256") == actual["sha256"], "PIN_MISMATCH", name)
    return path


class NativeTruth:
    """Strict JTLV native text reader and direct decision-tree evaluation.

    No canonicalization, variable elimination, native library or solver calls.
    The final row is the root. A complete declaration/order/reachability audit
    precedes evaluation. Integer variable order may differ from numeric order.
    """
    def __init__(self, raw, nvars):
        require(len(raw) <= MAX_FILE, "BDD_BUDGET", status="UNKNOWN_RESOURCE")
        rows = [line.split() for line in raw.decode("ascii").splitlines() if line.strip()]
        self.nodes = {}
        self.order = None
        if len(rows) == 1 and rows[0] in (["0", "0"], ["0", "1"]):
            self.root = int(rows[0][1])
            self.support = set()
            return
        require(len(rows) >= 3 and rows[0] == [str(nvars)], "BDD_VARIABLE_COUNT")
        self.order = [int(v) for v in rows[1]]
        require(len(self.order) == nvars and set(self.order) == set(range(nvars)), "BDD_ORDER")
        levels = {v: i for i, v in enumerate(self.order)}
        signatures = set()
        for row in rows[2:]:
            require(len(row) == 4, "BDD_ROW_WIDTH")
            ident, var, low, high = map(int, row)
            require(ident > 1 and ident not in self.nodes and var in levels, "BDD_NODE_ID")
            require(low != high and all(c in (0, 1) or c in self.nodes for c in (low, high)), "BDD_CHILD")
            signature = (var, low, high)
            require(signature not in signatures, "BDD_DUPLICATE_NODE")
            signatures.add(signature)
            for child in (low, high):
                require(child < 2 or levels[self.nodes[child][0]] > levels[var], "BDD_CHILD_ORDER")
            self.nodes[ident] = signature
        self.root = ident
        todo, reachable = [self.root], set()
        while todo:
            node = todo.pop()
            if node < 2 or node in reachable:
                continue
            reachable.add(node)
            todo.extend(self.nodes[node][1:])
        require(reachable == set(self.nodes), "BDD_UNREACHABLE_NODE")
        self.support = {row[0] for row in self.nodes.values()}

    def evaluate(self, bits):
        node = self.root
        while node > 1:
            var, low, high = self.nodes[node]
            require(var in bits and type(bits[var]) is bool, "BDD_INCOMPLETE_ASSIGNMENT", var)
            node = high if bits[var] else low
        return bool(node)


class Encoding:
    def __init__(self, model):
        require(model.get("bdd_variable_count") == 10, "EXACT_VARIABLE_COUNT")
        self.n = 10
        self.fields = model.get("fields")
        require(isinstance(self.fields, list) and len(self.fields) == 3, "EXACT_SOURCE_FIELDS")
        self.by_name, self.current, self.next, used = {}, [], [], set()
        self.enc = {}
        for field in self.fields:
            name = field.get("name")
            require(name in VALUES and name not in self.by_name, "EXACT_FIELD_NAMES", name)
            require(field.get("owner") == OWNERS[name] and field.get("role") == OWNERS[name], "FIELD_OWNER_ROLE", name)
            require(field.get("values") == list(VALUES[name]) and field.get("domain_size") == len(VALUES[name]), "FIELD_DOMAIN", name)
            self.by_name[name] = field
            self.enc[name] = {}
            for prime, label in ((False, "current_bits"), (True, "next_bits")):
                bits = field.get(label)
                width = 1 if name == HELPER else 2
                require(isinstance(bits, list) and len(bits) == width and all(type(v) is int and 0 <= v < self.n for v in bits), "FIELD_BITS", name)
                require(len(set(bits)) == len(bits) and not set(bits) & used, "OVERLAPPING_FIELD_BITS", name)
                used.update(bits)
                (self.next if prime else self.current).extend(bits)
                signatures = set()
                for value in VALUES[name]:
                    item = field.get("encoding", {}).get(value, {}).get("next" if prime else "current")
                    require(isinstance(item, dict) and set(item) == {str(v) for v in bits} and all(type(v) is bool for v in item.values()), "FIELD_ENCODING", [name, value])
                    mapped = {int(k): v for k, v in item.items()}
                    signature = tuple(mapped[v] for v in bits)
                    require(signature not in signatures, "NONBIJECTIVE_ENCODING", name)
                    signatures.add(signature)
                    self.enc[name][value, prime] = mapped
            require(set(field.get("encoding", {})) == set(VALUES[name]), "EXTRA_ENCODING_VALUE", name)
        require(used == set(range(self.n)), "UNACCOUNTED_VARIABLES")
        require(model.get("all_current_bits") == sorted(self.current) and model.get("all_next_bits") == sorted(self.next), "CURRENT_NEXT_ROSTERS")
        require(model.get("bdd_variable_order") == list(range(self.n)), "FROZEN_VARIABLE_ORDER")
        require(model.get("public_fields") == {"ENV": ["floor", HELPER], "SYS": ["elevMot"]}, "PUBLIC_FIELDS")
        self.current, self.next = sorted(self.current), sorted(self.next)
        self.env_current = sorted(v for n in ("floor", HELPER) for v in self.by_name[n]["current_bits"])
        self.sys_current = sorted(self.by_name["elevMot"]["current_bits"])
        self.env_next = sorted(v for n in ("floor", HELPER) for v in self.by_name[n]["next_bits"])
        self.sys_next = sorted(self.by_name["elevMot"]["next_bits"])

    def bits(self, state, prime=False):
        require(set(state) == set(VALUES), "STATE_FIELD_ROSTER")
        result = {}
        for name in VALUES:
            require(state[name] in VALUES[name], "UNTYPED_STATE", [name, state[name]])
            result.update(self.enc[name][state[name], prime])
        return result

    def domain(self, bits, names, prime=False):
        return all(any(all(bits[k] == v for k, v in self.enc[name][value, prime].items()) for value in VALUES[name]) for name in names)


def states():
    return [dict(zip(("floor", HELPER, "elevMot"), values)) for values in itertools.product(FLOORS, ("false", "true"), MOTORS)]


def original_alive(state):
    return state["elevMot"] != "STOP" or state["floor"] != "NONE"


def native_rho_e(current, following):
    h, hp = current[HELPER] == "true", following[HELPER] == "true"
    return (original_alive(current) or hp) and (not h or hp)


def source_justices(state):
    return (state["elevMot"] == "FWD",
            state["floor"] != "LOWER" or state["elevMot"] == "FWD",
            state["floor"] != "UPPER" or state["elevMot"] == "BWD")


def audit_entry(entry):
    require(entry.get("schema") == "v46-residual-entry-v1", "ENTRY_SCHEMA")
    require(type(entry.get("id")) is str and entry["id"], "ENTRY_ID")
    state = entry.get("full_original_state")
    require(isinstance(state, dict) and set(state) == {"floor", "elevMot"}, "FROZEN_ENTRY_FIELDS")
    require(state["floor"] in FLOORS and state["elevMot"] in MOTORS and original_alive(state), "FROZEN_ENTRY_NOT_IN_K")
    if "source_valuation" in entry:
        require(entry["source_valuation"] == state, "CONFLICTING_ENTRY_VALUES")
    require(entry.get("original_initializer_compatible") is (state["elevMot"] == "STOP"), "ORIGINAL_INITIAL_COMPATIBILITY")
    require(entry.get("original_I_M_K") is False, "ORIGINAL_K_VERDICT_RETAINED")
    require(entry.get("helper_at_residual_entry") is False and entry.get("logical_AUX") == {}, "ENTRY_HELPER_AUX")
    require(entry.get("private_memory_policy") == "new_controller_rank0", "ENTRY_MEMORY_POLICY")
    source = entry.get("source")
    require(isinstance(source, dict) and source.get("sha256") == SOURCE_SHA and source.get("bytes") == SOURCE_BYTES, "SOURCE_NOT_PINNED_032")
    path = Path(source["path"])
    actual = file_pin(path)
    require(actual["sha256"] == SOURCE_SHA and actual["bytes"] == SOURCE_BYTES, "PINNED_SOURCE_CHANGED")
    return state, path


def audit_model(folder, model, result, entry, cert):
    require(model.get("schema") == "residual-entry-native-model-v1", "MODEL_SCHEMA")
    source_state, source_path = audit_entry(entry)
    actual_source = file_pin(source_path)
    require(model.get("input", {}).get("sha256") == SOURCE_SHA and model["input"].get("bytes") == SOURCE_BYTES, "MODEL_SOURCE_PIN")
    # Java toRealPath may return NFC while the workspace spelling is NFD on
    # macOS. Identity is the actual file; exact source bytes/hash remain above.
    require(Path(model["input"]["path"]).samefile(source_path), "MODEL_SOURCE_PATH")
    require(result.get("input_sha256") == SOURCE_SHA, "RESULT_SOURCE_PIN")
    enc = Encoding(model)
    expected = {**source_state, HELPER: "false"}
    actual_entry = model.get("entry")
    require(isinstance(actual_entry, dict) and actual_entry.get("mode") == "exact_full_source_state_plus_native_helper_false", "MODEL_ENTRY_MODE")
    require(actual_entry.get("source_valuation") == source_state and actual_entry.get("valuation") == expected, "MODEL_ENTRY_VALUATION")
    require(actual_entry.get("bits") == {str(k): v for k, v in enc.bits(expected).items()}, "MODEL_ENTRY_BITS")
    require(actual_entry.get("private_memory") == {"policy": "new_controller_rank0", "rank": 0, "source_history_reset": False}, "MODEL_ENTRY_MEMORY")
    source_init = {"ENV": True, "SYS": source_state["elevMot"] == "STOP", "joint": source_state["elevMot"] == "STOP"}
    require(actual_entry.get("source_initializer_match") == source_init, "MODEL_SOURCE_INITIAL_MATCH")
    require(result.get("entry") == actual_entry, "RESULT_ENTRY_BINDING")
    require(result.get("initializers_replaced") is True, "RESULT_RESIDUAL_MODE")
    require(result.get("helper_added") is True and result.get("helper_is_native_nonaux_ENV") is True, "HELPER_ROLE")
    inv = model.get("source_inventory")
    require(isinstance(inv, dict), "SOURCE_INVENTORY_MISSING")
    for stage in ("parsed", "translated"):
        require(inv.get(stage, {}).get("AUX", {}).get("variables") == [] and inv[stage]["AUX"].get("constraints") == [], "UNDECLARED_SOURCE_AUX", stage)
    parsed_names = {o: [v.get("name") for v in inv["parsed"].get(o, {}).get("variables", [])] for o in ("ENV", "SYS")}
    translated_names = {o: [v.get("name") for v in inv["translated"].get(o, {}).get("variables", [])] for o in ("ENV", "SYS")}
    require(parsed_names == {"ENV": ["floor"], "SYS": ["elevMot"]}, "PARSED_SOURCE_FIELDS")
    require(set(translated_names["ENV"]) == {"floor", HELPER} and translated_names["SYS"] == ["elevMot"], "TRANSLATED_SOURCE_FIELDS")
    loaded, pins = {}, []
    def load(label, ref, allowed):
        path = pinned_path(folder, ref)
        truth = NativeTruth(path.read_bytes(), enc.n)
        require(truth.support <= set(allowed), "BDD_SUPPORT", label, "UNKNOWN_MODEL_BINDING")
        require(truth.order is None or truth.order == model["bdd_variable_order"], "BDD_ORDER_MODEL_BINDING", label)
        require(type(ref.get("node_count")) is int and ref["node_count"] == len(truth.nodes), "BDD_NODE_METADATA", label)
        require(type(ref.get("zero")) is bool and ref["zero"] == (truth.root == 0) and type(ref.get("one")) is bool and ref["one"] == (truth.root == 1), "BDD_TERMINAL_METADATA", label)
        require(ref.get("support") == sorted(truth.support), "BDD_SUPPORT_METADATA", label)
        loaded[label] = truth
        pins.append(file_pin(path))
        return truth
    refs = model.get("residual_bdds")
    require(isinstance(refs, dict) and set(refs) == {"thetaE", "thetaS", "rhoE", "rhoS", "domain", "domain_ENV_next", "domain_SYS_next"}, "RESIDUAL_BDD_ROSTER")
    supports = {"thetaE": enc.env_current, "thetaS": enc.current, "rhoE": enc.current + enc.env_next, "rhoS": enc.current + enc.next, "domain": enc.current, "domain_ENV_next": enc.env_next, "domain_SYS_next": enc.sys_next}
    for name, ref in refs.items():
        load(name, ref, supports[name])
    require(set(model.get("source_initializer_bdds", {})) == {"thetaE", "thetaS"}, "SOURCE_INITIALIZER_ROSTER")
    for name, ref in model["source_initializer_bdds"].items():
        load("source_" + name, ref, enc.env_current if name == "thetaE" else enc.current)
    for label, allowed in (("complete_cube", enc.current), ("ENV_projection", enc.env_current), ("SYS_projection", enc.sys_current)):
        load(label, actual_entry[label], allowed)
    justice = model.get("original_justices")
    require(isinstance(justice, dict) and set(justice) == {"ENV", "SYS"} and len(justice["ENV"]) == 1 and len(justice["SYS"]) == 3, "JUSTICE_ROSTER")
    for owner in ("ENV", "SYS"):
        for idx, ref in enumerate(justice[owner]):
            load(owner + "_justice_" + str(idx), ref, enc.current)
    checks = defaultdict(int)
    def equal(label, bits, expected_value, witness):
        actual = loaded[label].evaluate(bits)
        require(actual == bool(expected_value), "SOURCE_EQUATION_MISMATCH", {"equation": label, "valuation": witness, "expected": bool(expected_value), "actual": actual}, "UNKNOWN_MODEL_BINDING")
        checks[label] += 1
    # Exact raw Boolean domain checks include the one invalid motor encoding.
    for values in itertools.product((False, True), repeat=len(enc.current)):
        bits = dict(zip(enc.current, values))
        equal("domain", bits, enc.domain(bits, VALUES), bits)
        full = all(bits[k] == v for k, v in enc.bits(expected).items())
        equal("complete_cube", bits, full, bits)
        env_match = all(bits[k] == v for k, v in enc.bits(expected).items() if k in enc.env_current)
        sys_match = all(bits[k] == v for k, v in enc.bits(expected).items() if k in enc.sys_current)
        equal("ENV_projection", bits, env_match, bits)
        equal("SYS_projection", bits, sys_match, bits)
        equal("thetaE", bits, env_match, bits)
        equal("thetaS", bits, sys_match, bits)
        equal("source_thetaE", bits, all(bits[k] == v for k, v in enc.enc[HELPER]["false", False].items()), bits)
        equal("source_thetaS", bits, all(bits[k] == v for k, v in enc.enc["elevMot"]["STOP", False].items()), bits)
    for values in itertools.product((False, True), repeat=len(enc.next)):
        bits = dict(zip(enc.next, values))
        equal("domain_ENV_next", bits, enc.domain(bits, ("floor", HELPER), True), bits)
        equal("domain_SYS_next", bits, enc.domain(bits, ("elevMot",), True), bits)
    typed = states()
    for current in typed:
        bits = enc.bits(current)
        equal("ENV_justice_0", bits, current[HELPER] == "false", current)
        for idx, expected_value in enumerate(source_justices(current)):
            equal("SYS_justice_" + str(idx), bits, expected_value, current)
        for following in typed:
            both = {**bits, **enc.bits(following, True)}
            equal("rhoE", both, native_rho_e(current, following), [current, following])
            equal("rhoS", both, True, [current, following])
    # Preconstructor/solver formulas are checked independently, not by hashes or
    # the producer's equality booleans. The source has exactly 1/3 native goals.
    for location in ("preconstructor_justices", "solver_justices"):
        require(set(result.get(location, {})) == {"ENV", "SYS"}, "RESULT_JUSTICE_ROSTER", location)
        for owner, count in (("ENV", 1), ("SYS", 3)):
            require(len(result[location][owner]) == count, "RESULT_JUSTICE_COUNT", [location, owner])
            for idx, ref in enumerate(result[location][owner]):
                label = location + "_" + owner + "_" + str(idx)
                load(label, ref, enc.current)
                for current in typed:
                    equal(label, enc.bits(current), current[HELPER] == "false" if owner == "ENV" else source_justices(current)[idx], current)
    cert["source_model_audit"] = {"status": "PASS", "source": actual_source, "source_specific_oracle": True, "general_source_compiler": False, "typed_transformed_states": 24, "typed_transformed_edges": 576, "raw_current_boolean_states": 32, "equation_checks": dict(checks), "original_source_initial_K_verdict": False, "residual_full_state": source_state, "source_initializer_compatible": source_state["elevMot"] == "STOP", "source_logical_AUX": [], "new_private_memory": {"policy": "new_controller_rank0", "rank": 0}}
    cert["BDD_pins"] = pins
    return enc, actual_entry


def reach(starts, adjacency):
    found, todo = set(starts), list(starts)
    while todo:
        for target in adjacency.get(todo.pop(), ()):
            if target not in found:
                found.add(target)
                todo.append(target)
    return found


def components(vertices, edges):
    """Iterative Kosaraju; this implementation is local to this checker."""
    vertices = set(vertices)
    adj, rev = defaultdict(list), defaultdict(list)
    for source, target in edges:
        if source in vertices and target in vertices:
            adj[source].append(target)
            rev[target].append(source)
    seen, order = set(), []
    for start in sorted(vertices):
        if start in seen:
            continue
        seen.add(start)
        stack = [(start, 0)]
        while stack:
            node, index = stack[-1]
            if index == len(adj[node]):
                order.append(node)
                stack.pop()
                continue
            nxt = adj[node][index]
            stack[-1] = (node, index + 1)
            if nxt not in seen:
                seen.add(nxt)
                stack.append((nxt, 0))
    done, result = set(), []
    for start in reversed(order):
        if start in done:
            continue
        component = reach([start], {v: [w for w in rev[v] if w not in done] for v in vertices - done})
        done.update(component)
        result.append(sorted(component))
    return result


def cyclic(component, edge_set):
    return len(component) > 1 or (component[0], component[0]) in edge_set


def first_path(starts, adjacency, targets):
    queue, parent = deque(starts), {s: None for s in starts}
    while queue:
        node = queue.popleft()
        if node in targets:
            path = []
            while node is not None:
                path.append(node)
                node = parent[node]
            return list(reversed(path))
        for nxt in adjacency.get(node, ()):
            if nxt not in parent:
                parent[nxt] = node
                queue.append(nxt)
    return None


def graph_fairness(nodes, starts, edges, valuations):
    edge_set = {tuple(e) for e in edges}
    adj, reverse = defaultdict(list), defaultdict(list)
    for source, target in edges:
        adj[source].append(target)
        reverse[target].append(source)
    sccs = components(nodes, edges)
    fair = [component for component in sccs if cyclic(component, edge_set)]
    can_continue = reach([v for component in fair for v in component], reverse)
    bad = set(nodes) - can_continue
    liveness = []
    for justice in range(3):
        violating = {node for node in nodes if not source_justices(valuations[node])[justice]}
        for component in components(violating, edges):
            if cyclic(component, edge_set):
                liveness.append({"system_justice": justice, "violating_cyclic_component": component, "legal_prefix": first_path(starts, adj, set(component))})
    return {"scope": "Complete original-legal residual graph; source ENV justice list is empty; a fair continuation still requires an infinite directed cycle.", "nonconflicting": {"pass": not bad, "failing_states": sorted(bad), "first_failing_prefix": first_path(starts, adj, bad), "fair_cyclic_components": fair}, "strict_liveness": {"pass": not liveness, "counterexamples": liveness}, "original_view_state_count": len(nodes), "original_view_edge_count": len(edges)}


def audit_printed(path, graph):
    lines = [line.strip() for line in path.read_text().splitlines() if line.strip()]
    require(len(lines) == 2 * len(graph["nodes"]), "PRINTER_LINE_COUNT")
    for idx, node in enumerate(graph["nodes"]):
        match = re.fullmatch(r"(Initial )?State (\d+) <(.*)>", lines[2 * idx])
        require(match is not None, "PRINTER_STATE_SYNTAX")
        require(bool(match.group(1)) == node["initial"] and match.group(2) == node["id"], "PRINTER_ID_INITIAL")
        parts = [part.strip().split(":", 1) for part in match.group(3).split(",")]
        require(all(len(part) == 2 for part in parts) and len(dict(parts)) == len(parts) and dict(parts) == node["valuation"], "PRINTER_VALUATION")
        require(node.get("native_bdd_text") == "<" + match.group(3) + ">", "PRINTER_NATIVE_BDD_TEXT")
        expected = "With successors : " + ", ".join(node["successors"])
        require(lines[2 * idx + 1] == expected.strip(), "PRINTER_SUCCESSORS")


def audit_graph(folder, graph, result, enc, actual_entry, cert):
    expected_schema = "residual-entry-experimental-complete-controller-v1" if result["schema"] == "residual-entry-experimental-result-v1" else "residual-entry-complete-native-controller-v1"
    require(graph.get("schema") == expected_schema and graph.get("complete") is True, "GRAPH_SCHEMA_COMPLETE")
    require(graph.get("initialization") == "exact_full_state_residual_entry" and graph.get("initializers_replaced") is True, "GRAPH_RESIDUAL_MODE")
    require(graph.get("entry") == actual_entry, "GRAPH_ENTRY_BINDING")
    require(graph.get("model_sha256") == file_pin(folder / "model.json")["sha256"], "GRAPH_MODEL_PIN")
    for key in ("fixture_id", "case_id", "variant"):
        require(graph.get(key) == result.get(key) and type(graph.get(key)) is str, "GRAPH_IDENTITY", key)
    require(type(graph.get("native_memory_identity")) is int and graph["native_memory_identity"] == result.get("native_memory_identity"), "GRAPH_MEMORY_BINDING")
    require(type(graph.get("controller_identity")) is int, "CONTROLLER_IDENTITY")
    require(graph.get("rank_domain_size") == 3, "NATIVE_RANK_DOMAIN")
    nodes, edges = graph.get("nodes"), graph.get("edges")
    require(isinstance(nodes, list) and nodes and len(nodes) <= MAX_STATES and isinstance(edges, list) and len(edges) <= MAX_EDGES, "GRAPH_SIZE_CAP", status="UNKNOWN_RESOURCE")
    require(graph.get("api_state_count") == len(nodes) and graph.get("api_transition_count") == len(edges), "GRAPH_API_COUNTS")
    by_id, memory_keys, flat = {}, set(), []
    for idx, node in enumerate(nodes):
        require(node.get("id") == str(idx) and node.get("native_id") == idx, "NATIVE_NODE_ID")
        require(type(node.get("initial")) is bool and type(node.get("rank")) is int and 0 <= node["rank"] < 3, "NATIVE_RANK_TYPE_RANGE")
        require(node.get("rank_class") == "tau.smlab.syntech.games.gr1.GR1RankInfo" and node.get("rank_info") == "System Justice " + str(node["rank"]), "NATIVE_RANK_IDENTITY")
        valuation = node.get("valuation")
        require(isinstance(valuation, dict), "NODE_VALUATION")
        expected_bits = {str(k): v for k, v in enc.bits(valuation).items()}
        require(node.get("bits") == expected_bits, "NODE_ENCODING")
        identity = (tuple(valuation[name] for name in VALUES), node["rank"])
        require(identity not in memory_keys, "DUPLICATE_NATIVE_MEMORY")
        memory_keys.add(identity)
        successors = node.get("successors")
        require(isinstance(successors, list) and all(type(v) is str for v in successors) and len(set(successors)) == len(successors), "SUCCESSOR_IDENTITY")
        flat.extend([[node["id"], target] for target in successors])
        by_id[node["id"]] = node
    require(flat == edges and all(target in by_id for _, target in edges), "COMPLETE_ORDERED_EDGE_EXPORT")
    starts = [node["id"] for node in nodes if node["initial"]]
    defect(len(starts) == 1, "RESIDUAL_SINGLETON_START", starts)
    defect(by_id[starts[0]]["valuation"] == actual_entry["valuation"] and by_id[starts[0]]["rank"] == 0, "RESIDUAL_FULL_ENTRY_OR_MEMORY")
    adj = {node["id"]: node["successors"] for node in nodes}
    require(reach(starts, adj) == set(by_id), "RAW_UNREACHABLE_NODE")
    # Complete native capture is checked before any helper-false projection.
    raw_input_checks = 0
    for node in nodes:
        current = node["valuation"]
        expected_inputs = {(floor, helper) for floor in FLOORS for helper in ("false", "true") if native_rho_e(current, {"floor": floor, HELPER: helper, "elevMot": "FWD"})}
        responses = defaultdict(list)
        for target in node["successors"]:
            following = by_id[target]["valuation"]
            responses[following["floor"], following[HELPER]].append(target)
        defect(set(responses) == expected_inputs, "RAW_LEGAL_INPUT_COVERAGE", {"node": node["id"], "missing": sorted(expected_inputs - set(responses)), "illegal": sorted(set(responses) - expected_inputs)})
        defect(all(len(v) == 1 for v in responses.values()), "RAW_RESPONSE_MEMORY_UNIQUENESS", node["id"])
        raw_input_checks += len(expected_inputs)
    kept = {ident for ident, node in by_id.items() if node["valuation"][HELPER] == "false"}
    false_adj = {ident: [target for target in by_id[ident]["successors"] if target in kept] for ident in kept}
    original_nodes = reach(starts, false_adj)
    original_edges = [[source, target] for source, target in edges if source in original_nodes and target in kept]
    original_inputs = 0
    for ident in sorted(original_nodes):
        expected_inputs = set(FLOORS) if original_alive(by_id[ident]["valuation"]) else set()
        responses = defaultdict(list)
        for target in false_adj[ident]:
            responses[by_id[target]["valuation"]["floor"]].append(target)
        defect(set(responses) == expected_inputs, "ORIGINAL_LEGAL_INPUT_COVERAGE", ident)
        defect(all(len(v) == 1 for v in responses.values()), "ORIGINAL_RESPONSE_MEMORY_UNIQUENESS", ident)
        original_inputs += len(expected_inputs)
    fairness = graph_fairness(original_nodes, starts, original_edges, {ident: node["valuation"] for ident, node in by_id.items()})
    cert["native_graph"] = {"states": len(nodes), "edges": len(edges), "starts": starts, "source_equation_legal_input_checks": raw_input_checks, "all_raw_nodes_reachable": True, "ranks_and_native_ids_retained": True}
    cert["original_view_mapping"] = {"status": "PASS", "initialization": "exact full-state residual singleton; original initializer not reapplied", "states": len(original_nodes), "edges": len(original_edges), "source_legal_input_checks": original_inputs, "helper_false_projection_only": True, "V_or_K_graph_restriction": False, "edge_or_memory_repair": False, "new_private_memory_at_entry_only": True}
    cert["derived_fairness"] = fairness
    cert["strict_controller_pass"] = fairness["strict_liveness"]["pass"]
    cert["nonconflicting_pass"] = fairness["nonconflicting"]["pass"]
    cert["status"] = "COMPLETE_RESIDUAL_GRAPH_CERTIFICATE"


def check(arm_dir, entry_path):
    folder, entry_path = Path(arm_dir).resolve(), Path(entry_path).resolve()
    cert = {"schema": "source-derived-elevator032-residual-certificate-v1", "status": "UNKNOWN_INTEGRITY", "strict_controller_pass": None, "nonconflicting_pass": None, "source_initial_K_verdict": False, "native_runs": 0, "solver_runs": 0, "trust_boundary": "Exact pinned Elevator032 source and manually transcribed finite source equations. Independent native BDD text reader and independent local SCC code. Native capture and actual class/process provenance must additionally be certified by orchestration; no arbitrary source compiler, runtime handoff or old-private-memory transfer claim."}
    try:
        cert["entry_pin"] = file_pin(entry_path)
        entry = read_json(entry_path)
        cert["entry_id"] = entry.get("id")
        model_path, result_path = folder / "model.json", folder / "result.json"
        model, result = read_json(model_path), read_json(result_path)
        cert["model_pin"], cert["result_pin"] = file_pin(model_path), file_pin(result_path)
        require(result.get("schema") in ("residual-entry-native-result-v1", "residual-entry-experimental-result-v1"), "RESULT_SCHEMA")
        require(result.get("stage") == "PROCESS_FINISHED", "NATIVE_PROCESS_NOT_FINISHED")
        require(result.get("semantic_reduction_used") is False and result.get("ENV_justice_normalization_used") is False, "ROUTE_IDENTITY")
        require(pinned_path(folder, result["model_export"]).resolve() == model_path, "RESULT_MODEL_BINDING")
        for key in ("fixture_id", "case_id", "variant"):
            require(type(result.get(key)) is str and result[key] == model.get(key), "MODEL_RESULT_IDENTITY", key)
        enc, actual_entry = audit_model(folder, model, result, entry, cert)
        if result.get("status") not in ("JOB_CONTROLLER_PRINTED", "COMPLETE_CONTROLLER_EXPORTED"):
            cert["native_outcome"] = result.get("status")
            require("controller_export" not in result, "UNEXPECTED_CONTROLLER_AFTER_REFUSAL")
            require(result.get("status") in ("JOB_UNREALIZABLE_NO_CONTROLLER", "JOB_EMPTY_MEMORY_NO_CONTROLLER"), "UNRECOGNIZED_NATIVE_TERMINAL_OUTCOME")
            cert["status"] = "COMPLETE_RESIDUAL_NO_CONTROLLER_DECLARED"
            cert["refusal_scope"] = "Selected native route returned no controller; not a proof that the residual source contract is infeasible."
            return cert
        require(result.get("native_residual_initial_verdict") is True, "NATIVE_RESIDUAL_VERDICT")
        graph_path = pinned_path(folder, result["controller_export"])
        printer_path = pinned_path(folder, result["printed_controller"])
        require(graph_path.name == "controller.json" and printer_path.name == "controller.txt", "GRAPH_OUTPUT_FILENAMES")
        graph = read_json(graph_path)
        cert["graph_pin"], cert["printer_pin"] = file_pin(graph_path), file_pin(printer_path)
        audit_graph(folder, graph, result, enc, actual_entry, cert)
        audit_printed(printer_path, graph)
        cert["printer_binding"] = {"status": "PASS", "all_states_successors_and_initial_markers": True}
    except CheckError as error:
        cert.update(status=error.status, error=error.code, detail=error.detail, strict_controller_pass=None, nonconflicting_pass=None)
    except (OSError, ValueError, TypeError, KeyError, IndexError, UnicodeError, RecursionError) as error:
        cert.update(status="UNKNOWN_INTEGRITY", error=type(error).__name__, detail=str(error), strict_controller_pass=None, nonconflicting_pass=None)
    return cert


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("arm_dir", type=Path)
    parser.add_argument("entry_json", type=Path)
    parser.add_argument("output_json", type=Path)
    args = parser.parse_args()
    cert = check(args.arm_dir, args.entry_json)
    cert["created_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    cert["checker_pin"] = file_pin(Path(__file__))
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(cert, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"status": cert["status"], "strict_controller_pass": cert["strict_controller_pass"], "nonconflicting_pass": cert["nonconflicting_pass"], "output": str(args.output_json.resolve()), "error": cert.get("error")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
