Technical Appendix: Controller Admission and Helper-Game Preservation

This anonymous technical appendix supplies extended derivations, source arguments,
row-level results and evidence navigation. The main manuscript and its title are
not included in this public document bundle.

Read technical-appendix.pdf (41 pages). The source directory contains the
complete 25-file TeX input closure. Compile source/main.tex with pdfLaTeX at least
twice; standard TeX packages including xurl and longtable are required.
MANIFEST.json binds every other file by relative path, byte count and SHA-256.

This is a document snapshot, not an executable scientific archive. Section K
distinguishes saved-input replay, fresh public-source native regeneration and
the focused saved-state certificate. Each cited versioned evidence package has
its own commands, exact identities and qualification limits. This document
packaging performs no scientific execution and changes no historical evidence,
failed attempt or UNKNOWN result.

Original documentation is covered by LICENSE. Cited third-party work and source
fragments retain their attribution and their own terms. No third-party paper PDF,
compiled producer, upstream JAR or native library is bundled.
