Technical Appendix: Controller Admission and Helper-Game Preservation
Anonymous document snapshot v46

This package contains the generic-title 45-page technical appendix, its complete 27-file TeX input closure, the original-contribution license and an exact file manifest. Compile main.tex with pdfLaTeX at least twice in this directory; standard TeX packages are host supplied. No main-manuscript PDF or source is included.

Section M reports the full eleven-state residual-entry census for one public Elevator source: three original-initializer-compatible entries and eight noninitial entries. Both extraction arms pass at every entry; the preference refines none of 836 examined candidate sets. The original initializer verdict stays false. This adds no active rescue, executed old-controller handoff or fresh-host qualification.

Scientific evidence archives are separate downloads. Section K and the public repository indexes give their exact scopes, restoration requirements and replay limits.
https://github.com/research-artifact-archive/seams2027/tree/residual-census-evidence-20261021-v1

All 45 pages of this PDF were visually inspected at 120 dpi. The PDF has blank author/title metadata; the displayed document uses a generic appendix title and anonymous authors.
