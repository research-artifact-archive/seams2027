Technical Appendix: Controller Admission and Helper-Game Preservation
Anonymous document snapshot v47

This package contains the generic-title 49-page technical appendix, its complete 28-file TeX input closure, the original-contribution license and an exact file manifest. Compile main.tex with pdfLaTeX at least twice in this directory; standard TeX packages are host supplied. No main-manuscript PDF or source is included.

Section H adds a constructed noninitial Lift handoff census after the separate historical maintenance episode. Ten reached private nodes represent eight source/history states. Forty roots are checked by two independent routes. Strict-only admission retains the old controller in ten runs; requiring cooperation installs the existing normalized candidate in ten paired runs. All twenty executed suffixes reach fair lassos and no post-change input sets b3=true. The nonzero monitors already have their response predicates satisfied at each boundary. No executed failure avoidance, unanswered-request carryover, preference necessity, or arbitrary private-memory migration is established.

Section M retains the full eleven-state residual-entry Elevator census and its zero refinements among 836 candidate sets. The original initializer verdict remains false. Existing cohorts and complete proofs are preserved.

Scientific evidence archives are separate downloads. Section K and the public repository indexes give their exact scopes, restoration requirements and replay limits. The eighth archive is static handoff evidence; the previous public replay entrypoint does not execute these new handoffs.
https://github.com/research-artifact-archive/seams2027/tree/noninitial-handoff-evidence-20261021-v1

All 49 pages of this PDF were visually inspected at 120 dpi. The PDF has blank author/title metadata; the displayed document uses a generic appendix title and anonymous authors.
