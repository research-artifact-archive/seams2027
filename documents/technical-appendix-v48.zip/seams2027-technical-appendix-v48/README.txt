Technical Appendix: Controller Admission and Helper-Game Preservation
Anonymous document snapshot v48

This package contains the generic-title 53-page technical appendix, its complete 29-file TeX input closure, the original-contribution license and an exact file manifest. Compile main.tex with pdfLaTeX at least twice in this directory; standard TeX packages are host supplied. No main-manuscript PDF or source is included.

Section H adds a constructed noninitial Lift handoff census after the separate historical maintenance episode. Ten reached private nodes represent eight source/history states. Forty roots are checked by two independent routes. Strict-only admission retains the old controller in ten runs; requiring cooperation installs the existing normalized candidate in ten paired runs. All twenty executed suffixes reach fair lassos and no post-change input sets b3=true. The nonzero monitors already have their response predicates satisfied at each boundary. No executed failure avoidance, unanswered-request carryover, preference necessity, or arbitrary private-memory migration is established.

Section N adds one preselected CatchingIntruder source outside the 59 qualified models. The native paired attempt reached its 44-second cap before extraction; normalization failed at the 16-MiB relation-file limit before its native solver. All three controller graph verdicts remain UNKNOWN. Only the separately pinned historical original model passed independent source-function correspondence. A static typed-state example distinguishes actual helper-false from original input availability; it proves no controller activity or reachability. No additional qualified controller, generalization result, or practical benefit of preservation is claimed.

Section M retains the full eleven-state residual-entry Elevator census and its zero refinements among 836 candidate sets. The original initializer verdict remains false. Existing cohorts and complete proofs are preserved.

Scientific evidence archives are separate downloads. Section K and the public repository indexes give their exact scopes, restoration requirements and replay limits. The eighth archive is static handoff evidence; the ninth adds bounded Intruder evidence. The previous public replay entrypoint does not execute these handoffs or Intruder attempts.
https://github.com/research-artifact-archive/seams2027/tree/intruder-bounded-evidence-20261021-v1

All 53 pages of this PDF were visually inspected at 120 dpi. The PDF has blank author/title metadata; the displayed document uses a generic appendix title and anonymous authors.
